#!/usr/bin/env python3
"""iter15 状态 + cam041 光栅化诊断。"""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

import torch
from random import choice
from argparse import ArgumentParser
from arguments import ModelParams, OptimizationParams, PipelineParams
from scene import Scene, GaussianModel
from gaussian_renderer import render
from train import prepare_output_and_logger, ACTIVE_SAR_CONFIG, _build_azimuth_strata
from utils.general_utils import safe_state
import train_sar_complete as tsc
from sar.sar_seed_refine_bg_shadow import maybe_seed_sar_refine_bg_shadow_at_init
from sar.cuda_preprocess import project_gaussians_sdgr_cuda
from diff_sar_rasterization import _C


def train_n(n):
    sys.argv = ["x", "-s", "data/360-1", "-m", "output/d", "--no_sar_fast_mode", "--sar_sdgr_cuda"]
    args = tsc.parse_sar_arguments()
    safe_state(True)
    lp = ModelParams(ArgumentParser()); op = OptimizationParams(ArgumentParser()); pp = PipelineParams(ArgumentParser())
    dataset = lp.extract(args); opt = op.extract(args); pipe = pp.extract(args)
    g = GaussianModel(dataset.sh_degree)
    scene = Scene(dataset, g, shuffle=False)
    g.training_setup(opt)
    maybe_seed_sar_refine_bg_shadow_at_init(g, opt, dataset_sar_mode=True, checkpoint_was_loaded=False, scene=scene)
    bg = torch.zeros(3, device="cuda")
    cams = scene.getTrainCameras().copy()
    bins, _ = _build_azimuth_strata(cams, len(cams))
    for it in range(1, n + 1):
        g.update_learning_rate(it)
        bi = choice([i for i, b in enumerate(bins) if b])
        cam = cams[choice(bins[bi])]
        pkg = render(cam, g, pipe, bg, sar_mode=True)
        loss = (pkg["render"] - cam.original_image.cuda()).abs().mean()
        loss.backward()
        g.optimizer.step(); g.optimizer.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
    return g, cams


def diagnose(g, cam_name, cams):
    cam = next(c for c in cams if c.image_name == cam_name)
    R = torch.as_tensor(cam.R_world_to_radar, device="cuda", dtype=torch.float32)
    cc = torch.as_tensor(cam.camera_center, device="cuda", dtype=torch.float32)
    H, W = cam.image_height, cam.image_width
    out = project_gaussians_sdgr_cuda(g.get_xyz, g.get_scaling, g.get_rotation, R, cc, W, H, 0.2031, 0.2021)
    m2d, conics, depths = out["means2D"], out["conics"], out["depths"]
    N = m2d.shape[0]
    print(f"cam={cam_name} N={N}")
    for label, sl in [("target", slice(0, 50000)), ("plates", slice(50000, N))]:
        c = conics[sl]; m = m2d[sl]; d = depths[sl]
        print(f"  {label}: nonfinite_conic={(~torch.isfinite(c)).sum().item()} "
              f"means2D=[{m.min().item():.1f},{m.max().item():.1f}] "
              f"conic_max={c.abs().max().item():.3e}")
    op = g.get_opacity
    col = torch.rand(N, 3, device="cuda")
    try:
        nr, oc, rad, gb, bb, ib, invd = _C.rasterize_sar_forward(
            m2d.contiguous(), conics.contiguous(), op.contiguous(), col,
            (-depths).contiguous(), torch.zeros(3, device="cuda"), W, H, True)
        print(f"  rasterize OK num_rendered={nr} radii_max={int(rad.max())} radii>0={(rad>0).sum().item()}")
    except Exception as e:
        print(f"  rasterize FAIL: {e}")
        # bisect plates
        for n in [50000, 50100, 50200, 50244]:
            sl = slice(0, n)
            try:
                nr, *_ = _C.rasterize_sar_forward(
                    m2d[sl].contiguous(), conics[sl].contiguous(), op[sl].contiguous(),
                    col[sl], (-depths[sl]).contiguous(), torch.zeros(3, device="cuda"), W, H, True)
                print(f"    prefix {n}: OK nr={nr}")
            except Exception as e2:
                print(f"    prefix {n}: FAIL {e2}")


if __name__ == "__main__":
    g, cams = train_n(15)
    diagnose(g, "BTR70-15-041.jpg", cams)
