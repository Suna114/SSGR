#!/usr/bin/env python3
"""Compare source target renders, refiner target output, final renders, and GT.

This diagnostic answers two practical questions:

1. Did the refiner materially change the Gaussian target-only render?
2. Did those changes move the result toward the real SAR GT, especially in
   target dark/layover regions and target-near shadow regions?
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def _image_files(root: Path) -> list[Path]:
    if not root.is_dir():
        return []
    return sorted(p for p in root.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS)


def _azimuth_from_name(path: Path) -> int | None:
    text = path.stem.lower()
    m = re.search(r"azimuth[_-]?(\d{1,3})", text)
    if m:
        return int(m.group(1)) % 360
    nums = re.findall(r"\d+", text)
    if not nums:
        return None
    # SAR GT names are usually object-depression-azimuth, e.g. T72-15-030.
    return int(nums[-1]) % 360


def _index_by_azimuth(root: Path) -> dict[int, Path]:
    out: dict[int, Path] = {}
    for path in _image_files(root):
        az = _azimuth_from_name(path)
        if az is not None:
            out.setdefault(az, path)
    return out


def _read_rgb(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGB"), dtype=np.float32) / 255.0


def _resize_like(img: np.ndarray, ref: np.ndarray) -> np.ndarray:
    if img.shape[:2] == ref.shape[:2]:
        return img
    h, w = ref.shape[:2]
    return cv2.resize(img, (w, h), interpolation=cv2.INTER_LINEAR)


def _gray(img: np.ndarray) -> np.ndarray:
    return img.mean(axis=2).astype(np.float32)


def _log_img(img: np.ndarray, scale: float) -> np.ndarray:
    return np.log1p(np.clip(img, 0.0, 1.0) * float(scale)) / math.log1p(float(scale))


def _morph(mask: np.ndarray, pixels: int) -> np.ndarray:
    pixels = int(pixels)
    if pixels == 0:
        return mask.astype(np.float32)
    kernel = np.ones((3, 3), np.uint8)
    out = mask.astype(np.float32)
    if pixels > 0:
        for _ in range(pixels):
            out = cv2.dilate(out, kernel)
    else:
        for _ in range(-pixels):
            out = cv2.erode(out, kernel)
    return np.clip(out, 0.0, 1.0).astype(np.float32)


def _blur(mask: np.ndarray, radius: int) -> np.ndarray:
    radius = int(radius)
    if radius <= 0:
        return mask.astype(np.float32)
    k = 2 * radius + 1
    return cv2.GaussianBlur(mask.astype(np.float32), (k, k), sigmaX=radius / 2.0 + 1e-6)


def _make_target_mask(mask_img: np.ndarray, threshold: float, quantile: float, dilate: int) -> np.ndarray:
    g = _gray(mask_img)
    nz = g[g > 1e-6]
    q = float(np.quantile(nz, float(quantile))) if nz.size else 1.0
    th = max(float(threshold), q)
    mask = (g >= th).astype(np.float32)
    return _morph(mask, int(dilate))


def _masked_mean(x: np.ndarray, mask: np.ndarray) -> float:
    w = mask.astype(np.float32)
    denom = float(w.sum())
    if denom <= 1e-6:
        return 0.0
    if x.ndim == 3:
        w = w[..., None]
        denom *= x.shape[2]
    return float((x * w).sum() / denom)


def _masked_ratio(mask: np.ndarray, support: np.ndarray) -> float:
    denom = float(support.sum())
    if denom <= 1e-6:
        return 0.0
    return float((mask.astype(np.float32) * support.astype(np.float32)).sum() / denom)


def _mse(a: np.ndarray, b: np.ndarray, mask: np.ndarray) -> float:
    return _masked_mean((a - b) ** 2, mask)


def _mae(a: np.ndarray, b: np.ndarray, mask: np.ndarray) -> float:
    return _masked_mean(np.abs(a - b), mask)


def _psnr(a: np.ndarray, b: np.ndarray, mask: np.ndarray) -> float:
    v = _mse(a, b, mask)
    if v <= 1e-12:
        return 99.0
    return float(-10.0 * math.log10(v))


def _ssim_gray(a: np.ndarray, b: np.ndarray, mask: np.ndarray | None = None) -> float:
    a = _gray(a).astype(np.float32)
    b = _gray(b).astype(np.float32)
    c1 = 0.01**2
    c2 = 0.03**2
    mu_a = cv2.GaussianBlur(a, (11, 11), 1.5)
    mu_b = cv2.GaussianBlur(b, (11, 11), 1.5)
    mu_a2 = mu_a * mu_a
    mu_b2 = mu_b * mu_b
    mu_ab = mu_a * mu_b
    sig_a2 = cv2.GaussianBlur(a * a, (11, 11), 1.5) - mu_a2
    sig_b2 = cv2.GaussianBlur(b * b, (11, 11), 1.5) - mu_b2
    sig_ab = cv2.GaussianBlur(a * b, (11, 11), 1.5) - mu_ab
    val = ((2 * mu_ab + c1) * (2 * sig_ab + c2)) / ((mu_a2 + mu_b2 + c1) * (sig_a2 + sig_b2 + c2) + 1e-12)
    if mask is None:
        return float(np.clip(val.mean(), -1.0, 1.0))
    return float(np.clip(_masked_mean(val, mask), -1.0, 1.0))


def _to_u8(img: np.ndarray) -> np.ndarray:
    return np.clip(img * 255.0 + 0.5, 0, 255).astype(np.uint8)


def _heat_abs(a: np.ndarray, b: np.ndarray, gain: float = 5.0) -> np.ndarray:
    d = np.clip(np.abs(_gray(a) - _gray(b)) * gain, 0.0, 1.0)
    heat = cv2.applyColorMap(_to_u8(d), cv2.COLORMAP_INFERNO)
    return cv2.cvtColor(heat, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0


def _overlay_mask(img: np.ndarray, mask: np.ndarray, color: tuple[float, float, float]) -> np.ndarray:
    out = img.copy()
    alpha = np.clip(mask, 0.0, 1.0) * 0.55
    c = np.asarray(color, dtype=np.float32)
    out = out * (1.0 - alpha[..., None]) + c[None, None, :] * alpha[..., None]
    return np.clip(out, 0.0, 1.0)


def _label(tile: np.ndarray, text: str) -> Image.Image:
    im = Image.fromarray(_to_u8(tile))
    draw = ImageDraw.Draw(im)
    draw.rectangle([0, 0, im.width, 18], fill=(0, 0, 0))
    draw.text((4, 3), text, fill=(255, 255, 255))
    return im


def _save_panel(path: Path, az: int, source: np.ndarray, refiner: np.ndarray, final: np.ndarray, gt: np.ndarray, target_mask: np.ndarray, shadow_mask: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    log_source = _log_img(source, 20.0)
    log_refiner = _log_img(refiner, 20.0)
    log_final = _log_img(final, 20.0)
    log_gt = _log_img(gt, 20.0)
    dark_gt = (_gray(log_gt) < 0.18).astype(np.float32) * target_mask
    tiles = [
        _label(log_source, f"source target az={az:03d}"),
        _label(log_refiner, "refiner target"),
        _label(log_final, "final render"),
        _label(log_gt, "GT"),
        _label(_heat_abs(log_source, log_refiner, 4.0), "|source-refiner|"),
        _label(_heat_abs(log_refiner, log_gt, 4.0), "|refiner-GT|"),
        _label(_overlay_mask(log_refiner, dark_gt, (1.0, 0.0, 1.0)), "GT-dark leak check"),
        _label(_overlay_mask(log_final, shadow_mask, (1.0, 1.0, 0.0)), "shadow search mask"),
    ]
    w, h = tiles[0].size
    canvas = Image.new("RGB", (w * 4, h * 2), (0, 0, 0))
    for i, tile in enumerate(tiles):
        canvas.paste(tile, ((i % 4) * w, (i // 4) * h))
    canvas.save(path)


def _summarize(rows: list[dict]) -> dict:
    keys = [
        "src_ref_mae_log_target",
        "src_ref_changed_ratio_target",
        "src_gt_mae_log_target",
        "ref_gt_mae_log_target",
        "final_gt_mae_log_target",
        "refiner_vs_source_improvement_mae",
        "dark_leak_ratio_refiner",
        "dark_leak_ratio_final",
        "shadow_mae_final_gt",
        "shadow_dark_match_ratio",
    ]
    summary = {"count": len(rows)}
    for key in keys:
        vals = [float(r[key]) for r in rows if key in r and math.isfinite(float(r[key]))]
        if vals:
            summary[key] = {
                "mean": float(np.mean(vals)),
                "median": float(np.median(vals)),
                "min": float(np.min(vals)),
                "max": float(np.max(vals)),
            }
    no_work = [r for r in rows if float(r["src_ref_changed_ratio_target"]) < 0.01 and float(r["src_ref_mae_log_target"]) < 0.01]
    summary["probably_unchanged_count"] = len(no_work)
    summary["probably_unchanged_ratio"] = float(len(no_work) / max(len(rows), 1))
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--source_target_dir", type=Path, required=True)
    parser.add_argument("--refiner_target_dir", type=Path, required=True)
    parser.add_argument("--final_render_dir", type=Path, required=True)
    parser.add_argument("--gt_dir", type=Path, required=True)
    parser.add_argument("--output_dir", type=Path, required=True)
    parser.add_argument("--target_mask_dir", type=Path, default=None)
    parser.add_argument("--target_mask_threshold", type=float, default=0.08)
    parser.add_argument("--target_mask_quantile", type=float, default=0.35)
    parser.add_argument("--target_mask_dilate", type=int, default=0)
    parser.add_argument("--log_scale", type=float, default=20.0)
    parser.add_argument("--delta_threshold", type=float, default=0.025)
    parser.add_argument("--dark_threshold", type=float, default=0.18)
    parser.add_argument("--leak_threshold", type=float, default=0.20)
    parser.add_argument("--shadow_search_dilate", type=int, default=55)
    parser.add_argument("--shadow_target_exclude_dilate", type=int, default=2)
    parser.add_argument("--top_k", type=int, default=12)
    parser.add_argument("--save_panels", action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args()

    source_idx = _index_by_azimuth(args.source_target_dir)
    refiner_idx = _index_by_azimuth(args.refiner_target_dir)
    final_idx = _index_by_azimuth(args.final_render_dir)
    gt_idx = _index_by_azimuth(args.gt_dir)
    mask_idx = _index_by_azimuth(args.target_mask_dir) if args.target_mask_dir else source_idx

    azimuths = sorted(set(source_idx) & set(refiner_idx) & set(final_idx) & set(gt_idx))
    if not azimuths:
        raise RuntimeError("No matched azimuths found across source/refiner/final/GT directories.")

    rows: list[dict] = []
    args.output_dir.mkdir(parents=True, exist_ok=True)
    panel_dir = args.output_dir / "panels"

    for az in azimuths:
        source = _read_rgb(source_idx[az])
        refiner = _resize_like(_read_rgb(refiner_idx[az]), source)
        final = _resize_like(_read_rgb(final_idx[az]), source)
        gt = _resize_like(_read_rgb(gt_idx[az]), source)
        mask_img = _resize_like(_read_rgb(mask_idx.get(az, source_idx[az])), source)
        target_mask = _make_target_mask(mask_img, args.target_mask_threshold, args.target_mask_quantile, args.target_mask_dilate)
        if target_mask.sum() <= 1:
            target_mask = (_gray(source) > args.target_mask_threshold).astype(np.float32)

        log_source = _log_img(source, args.log_scale)
        log_refiner = _log_img(refiner, args.log_scale)
        log_final = _log_img(final, args.log_scale)
        log_gt = _log_img(gt, args.log_scale)
        src_ref_delta = np.abs(log_source - log_refiner)
        changed = (_gray(src_ref_delta) >= args.delta_threshold).astype(np.float32)

        gt_dark = ((_gray(log_gt) < args.dark_threshold) * target_mask).astype(np.float32)
        ref_leak = ((_gray(log_refiner) > args.leak_threshold) * gt_dark).astype(np.float32)
        final_leak = ((_gray(log_final) > args.leak_threshold) * gt_dark).astype(np.float32)

        target_outer = _morph(target_mask, args.shadow_search_dilate)
        target_block = _morph(target_mask, args.shadow_target_exclude_dilate)
        shadow_search = np.clip(target_outer * (1.0 - target_block), 0.0, 1.0)
        gt_shadow_dark = ((_gray(log_gt) < args.dark_threshold) * shadow_search).astype(np.float32)
        final_shadow_dark = ((_gray(log_final) < args.dark_threshold) * shadow_search).astype(np.float32)

        src_gt_mae = _mae(log_source, log_gt, target_mask)
        ref_gt_mae = _mae(log_refiner, log_gt, target_mask)
        final_gt_mae = _mae(log_final, log_gt, target_mask)
        row = {
            "azimuth": az,
            "source_file": str(source_idx[az]),
            "refiner_file": str(refiner_idx[az]),
            "final_file": str(final_idx[az]),
            "gt_file": str(gt_idx[az]),
            "target_mask_ratio": float(target_mask.mean()),
            "src_ref_mae_log_target": _mae(log_source, log_refiner, target_mask),
            "src_ref_psnr_log_target": _psnr(log_source, log_refiner, target_mask),
            "src_ref_ssim_log_target": _ssim_gray(log_source, log_refiner, target_mask),
            "src_ref_changed_ratio_target": _masked_ratio(changed, target_mask),
            "src_gt_mae_log_target": src_gt_mae,
            "ref_gt_mae_log_target": ref_gt_mae,
            "final_gt_mae_log_target": final_gt_mae,
            "refiner_vs_source_improvement_mae": src_gt_mae - ref_gt_mae,
            "final_vs_source_improvement_mae": src_gt_mae - final_gt_mae,
            "src_gt_ssim_log_target": _ssim_gray(log_source, log_gt, target_mask),
            "ref_gt_ssim_log_target": _ssim_gray(log_refiner, log_gt, target_mask),
            "final_gt_ssim_log_target": _ssim_gray(log_final, log_gt, target_mask),
            "gt_dark_target_ratio": float(gt_dark.sum() / max(target_mask.sum(), 1.0)),
            "dark_leak_ratio_refiner": _masked_ratio(ref_leak, gt_dark),
            "dark_leak_ratio_final": _masked_ratio(final_leak, gt_dark),
            "shadow_search_ratio": float(shadow_search.mean()),
            "gt_shadow_dark_ratio": _masked_ratio(gt_shadow_dark, shadow_search),
            "final_shadow_dark_ratio": _masked_ratio(final_shadow_dark, shadow_search),
            "shadow_dark_match_ratio": _masked_ratio(final_shadow_dark, gt_shadow_dark),
            "shadow_mae_final_gt": _mae(log_final, log_gt, shadow_search),
        }
        rows.append(row)

    rows.sort(key=lambda r: (float(r["src_ref_changed_ratio_target"]), float(r["src_ref_mae_log_target"])))
    summary = _summarize(rows)

    with open(args.output_dir / "refiner_delta_metrics.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with open(args.output_dir / "refiner_delta_metrics.json", "w", encoding="utf-8") as f:
        json.dump({"summary": summary, "per_image": rows}, f, indent=2, ensure_ascii=False)

    worst_unchanged = rows[: args.top_k]
    worst_gt = sorted(rows, key=lambda r: float(r["ref_gt_mae_log_target"]), reverse=True)[: args.top_k]
    worst_shadow = sorted(rows, key=lambda r: float(r["shadow_mae_final_gt"]), reverse=True)[: args.top_k]
    panel_az = []
    for row in [*worst_unchanged, *worst_gt, *worst_shadow]:
        az = int(row["azimuth"])
        if az not in panel_az:
            panel_az.append(az)
    if args.save_panels:
        for az in panel_az[: max(args.top_k, 12)]:
            source = _read_rgb(source_idx[az])
            refiner = _resize_like(_read_rgb(refiner_idx[az]), source)
            final = _resize_like(_read_rgb(final_idx[az]), source)
            gt = _resize_like(_read_rgb(gt_idx[az]), source)
            mask_img = _resize_like(_read_rgb(mask_idx.get(az, source_idx[az])), source)
            target_mask = _make_target_mask(mask_img, args.target_mask_threshold, args.target_mask_quantile, args.target_mask_dilate)
            shadow_mask = np.clip(_morph(target_mask, args.shadow_search_dilate) * (1.0 - _morph(target_mask, args.shadow_target_exclude_dilate)), 0.0, 1.0)
            _save_panel(panel_dir / f"delta_azimuth_{az:03d}.png", az, source, refiner, final, gt, target_mask, shadow_mask)

    lines = [
        "Refiner target delta diagnosis",
        "=" * 80,
        f"matched images: {len(rows)}",
        f"source_target_dir: {args.source_target_dir}",
        f"refiner_target_dir: {args.refiner_target_dir}",
        f"final_render_dir: {args.final_render_dir}",
        f"gt_dir: {args.gt_dir}",
        "",
        "[summary]",
        f"source-refiner target MAE(log) mean: {summary['src_ref_mae_log_target']['mean']:.6f}",
        f"source-refiner changed target ratio mean: {summary['src_ref_changed_ratio_target']['mean']:.6f}",
        f"probably unchanged: {summary['probably_unchanged_count']}/{summary['count']} ({summary['probably_unchanged_ratio']:.3f})",
        f"source->GT target MAE(log) mean: {summary['src_gt_mae_log_target']['mean']:.6f}",
        f"refiner->GT target MAE(log) mean: {summary['ref_gt_mae_log_target']['mean']:.6f}",
        f"final->GT target MAE(log) mean: {summary['final_gt_mae_log_target']['mean']:.6f}",
        f"refiner improvement vs source MAE mean: {summary['refiner_vs_source_improvement_mae']['mean']:.6f}",
        f"dark leak refiner mean: {summary['dark_leak_ratio_refiner']['mean']:.6f}",
        f"dark leak final mean: {summary['dark_leak_ratio_final']['mean']:.6f}",
        f"shadow final-vs-GT MAE mean: {summary['shadow_mae_final_gt']['mean']:.6f}",
        f"shadow dark match ratio mean: {summary['shadow_dark_match_ratio']['mean']:.6f}",
        "",
        "[least changed by refiner]",
    ]
    for r in worst_unchanged:
        lines.append(
            f"azimuth_{int(r['azimuth']):03d}: changed={float(r['src_ref_changed_ratio_target']):.4f}, "
            f"src_ref_mae={float(r['src_ref_mae_log_target']):.5f}, "
            f"ref_improve={float(r['refiner_vs_source_improvement_mae']):+.5f}, "
            f"dark_leak_ref={float(r['dark_leak_ratio_refiner']):.4f}"
        )
    lines += ["", "[worst refiner target vs GT]"]
    for r in worst_gt:
        lines.append(
            f"azimuth_{int(r['azimuth']):03d}: ref_gt_mae={float(r['ref_gt_mae_log_target']):.5f}, "
            f"src_gt_mae={float(r['src_gt_mae_log_target']):.5f}, "
            f"changed={float(r['src_ref_changed_ratio_target']):.4f}, "
            f"dark_leak_ref={float(r['dark_leak_ratio_refiner']):.4f}"
        )
    lines += ["", "[worst final shadow vs GT]"]
    for r in worst_shadow:
        lines.append(
            f"azimuth_{int(r['azimuth']):03d}: shadow_mae={float(r['shadow_mae_final_gt']):.5f}, "
            f"gt_shadow_dark={float(r['gt_shadow_dark_ratio']):.4f}, "
            f"final_shadow_dark={float(r['final_shadow_dark_ratio']):.4f}, "
            f"match={float(r['shadow_dark_match_ratio']):.4f}"
        )
    if args.save_panels:
        lines += ["", f"panels: {panel_dir}"]

    text = "\n".join(lines) + "\n"
    (args.output_dir / "summary.txt").write_text(text, encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
