#!/usr/bin/env python3
"""Integrated SAR novel-view refiner workflow.

The full training workflow keeps every stage output under
``<model_path>/output``:

1. Train a base image refiner from scratch.
2. Fine-tune background from the base checkpoint.
3. Apply the fine-tuned checkpoint to novel target renders.
4. Run local target/shadow postprocess.
5. Optionally evaluate against GT with train/novel-view split summaries.

The shorter apply/eval workflow is still available for existing checkpoints.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def _find_repo_root(start: Path) -> Path:
    for p in [start, *start.parents]:
        if (p / "scripts" / "rendering" / "learn_sar_target_modulation_refiner.py").is_file():
            return p
        if (p / "train.py").is_file():
            return p
    return Path.cwd()


def _default_work_dir(model_path: Path) -> Path:
    return model_path / "output"


def _default_target_mask_dir(model_path: Path, work_dir: Path) -> Path:
    candidates = [
        model_path / "novel_target_only" / "target_renders",
        model_path / "\u65b0\u5efa\u6587\u4ef6\u5939" / "novel_target_only" / "target_renders",
        work_dir / "novel_target_only" / "target_renders",
    ]
    for path in candidates:
        if path.exists():
            return path
    return work_dir / "novel_target_only" / "target_renders"


def _resolve_user_path(path: Path | None, base_dir: Path) -> Path | None:
    """Resolve relative CLI paths against the user's launch directory."""
    if path is None:
        return None
    path = Path(path)
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


def _repo_relative_script(repo_root: Path, relative: str) -> str:
    return str((repo_root / relative).resolve())


def _run(cmd: list[str], cwd: Path, dry_run: bool = False) -> None:
    print("\n" + "=" * 96)
    print(_format_cmd(cmd))
    print("=" * 96)
    if dry_run:
        return
    subprocess.run(cmd, cwd=str(cwd), check=True)


def _format_cmd(cmd: list[str]) -> str:
    return " ".join(f'"{x}"' if (" " in x or "\t" in x) else x for x in cmd)


def _json_safe(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(v) for v in value]
    return str(value)


def _unique_result_dir(result_root: Path, timestamp: str, stage: str) -> Path:
    stem = f"{timestamp}_{stage}"
    path = result_root / stem
    idx = 2
    while path.exists():
        path = result_root / f"{stem}_{idx:02d}"
        idx += 1
    return path


def _copy_metric_artifacts(src_dir: Path, dst_dir: Path) -> list[str]:
    copied: list[str] = []
    if not src_dir.exists():
        return copied
    for path in src_dir.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".json", ".txt", ".csv"}:
            continue
        rel = path.relative_to(src_dir)
        out = dst_dir / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, out)
        copied.append(str(rel))
    return copied


def _copy_metric_artifacts_flat(src_dir: Path, dst_dir: Path) -> list[str]:
    copied: list[str] = []
    if not src_dir.exists():
        return copied
    dst_dir.mkdir(parents=True, exist_ok=True)
    for path in src_dir.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".json", ".txt", ".csv"}:
            continue
        rel = path.relative_to(src_dir)
        out = dst_dir / path.name
        if out.exists():
            prefix = "__".join(rel.parts[:-1])
            out = dst_dir / f"{prefix}__{path.name}" if prefix else out
        shutil.copy2(path, out)
        copied.append(out.name)
    return copied


def _load_metric_summary(eval_output: Path) -> dict:
    path = eval_output / "comparison_results.json"
    if not path.is_file():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        return {"error": f"could not read {path}: {e}"}
    return {
        "comparison_json": str(path),
        "summary": data.get("summary", {}),
        "summary_by_view_split": data.get("summary_by_view_split", {}),
        "image_count": len(data.get("per_image", []) or []),
    }


def _write_run_archive(
    args: argparse.Namespace,
    *,
    model_path: Path,
    work_dir: Path,
    result_root: Path,
    eval_output: Path,
    delta_output: Path | None,
    eval_ran: bool,
    output_paths: dict,
    executed_commands: list[dict],
    dry_run: bool = False,
) -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = _unique_result_dir(result_root, timestamp, str(args.stage))
    metrics_dir = run_dir / "metrics"
    delta_dir = run_dir / "refiner_delta"
    run_dir.mkdir(parents=True, exist_ok=True)
    metrics_dir.mkdir(parents=True, exist_ok=True)

    copied_metrics = [] if dry_run or not eval_ran else _copy_metric_artifacts(eval_output, metrics_dir)
    copied_delta = (
        []
        if dry_run or not eval_ran or delta_output is None
        else _copy_metric_artifacts(delta_output, delta_dir)
    )
    copied_flat_metrics = [] if dry_run or not eval_ran else _copy_metric_artifacts_flat(eval_output, run_dir)
    copied_flat_delta = (
        []
        if dry_run or not eval_ran or delta_output is None
        else _copy_metric_artifacts_flat(delta_output, run_dir)
    )
    metric_summary = {} if dry_run or not eval_ran else _load_metric_summary(eval_output)
    archive = {
        "timestamp": timestamp,
        "stage": args.stage,
        "dry_run": bool(dry_run),
        "eval_ran": bool(eval_ran),
        "model_path": str(model_path),
        "work_dir": str(work_dir),
        "result_dir": str(run_dir),
        "effective_args": _json_safe(vars(args)),
        "output_paths": _json_safe(output_paths),
        "executed_commands": executed_commands,
        "metrics": metric_summary,
        "copied_metric_files": copied_metrics,
        "copied_delta_files": copied_delta,
        "copied_flat_metric_files": copied_flat_metrics,
        "copied_flat_delta_files": copied_flat_delta,
    }
    with open(run_dir / "run_record.json", "w", encoding="utf-8") as f:
        json.dump(archive, f, indent=2, ensure_ascii=False)
    with open(run_dir / "parameters.json", "w", encoding="utf-8") as f:
        json.dump(_json_safe(vars(args)), f, indent=2, ensure_ascii=False)
    with open(run_dir / "metrics_summary.json", "w", encoding="utf-8") as f:
        json.dump(metric_summary, f, indent=2, ensure_ascii=False)
    with open(run_dir / "commands.txt", "w", encoding="utf-8") as f:
        for item in executed_commands:
            f.write(f"[{item.get('stage', 'stage')}]\n")
            f.write(item.get("command", "") + "\n\n")
    return run_dir


def _supported_cli_options(python: str, cwd: Path, script: str) -> set[str]:
    try:
        proc = subprocess.run(
            [python, script, "--help"],
            cwd=str(cwd),
            check=False,
            text=True,
            capture_output=True,
        )
    except Exception as e:
        print(f"[compat] warning: could not inspect {script}: {e}")
        return set()
    text = (proc.stdout or "") + "\n" + (proc.stderr or "")
    opts = set(re.findall(r"--[A-Za-z0-9][A-Za-z0-9_-]*", text))
    if proc.returncode not in {0, 1}:
        print(f"[compat] warning: {script} --help returned {proc.returncode}; using conservative CLI args")
    return opts


def _append_if_supported(cmd: list[str], supported: set[str], *items: str) -> list[str]:
    if not items:
        return cmd
    option = items[0]
    if option.startswith("--") and option not in supported:
        print(f"[compat] skipped unsupported option: {option}")
        return cmd
    return cmd + list(items)


def _add_common_apply_defaults(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    if bool(getattr(args, "target_only_refiner", False)):
        cmd = cmd + ["--refiner_mode", str(args.refiner_mode), "--conv_padding_mode", "reflect"]
        if str(getattr(args, "refiner_ablation", "none") or "none").lower().strip() not in {"", "none"}:
            cmd = _append_if_supported(cmd, supported, "--refiner_ablation", str(args.refiner_ablation))
        if bool(getattr(args, "target_only_compose_context", False)):
            cmd += [
                "--compose_order",
                "background_then_target_shadow",
                "--empirical_background_strength",
                str(args.empirical_background_strength),
                "--empirical_background_mode",
                str(args.empirical_background_mode),
                "--empirical_background_patch_size",
                str(args.empirical_background_patch_size),
                "--empirical_background_patch_overlap",
                str(args.empirical_background_patch_overlap),
                "--empirical_background_patch_smooth",
                str(args.empirical_background_patch_smooth),
                "--empirical_background_patch_fallback_weight",
                str(args.empirical_background_patch_fallback_weight),
                "--empirical_background_clean_reference" if bool(args.empirical_background_clean_reference) else "--no-empirical_background_clean_reference",
                "--empirical_background_blend_blur",
                "2",
                "--empirical_background_target_dilate",
                "2",
                "--empirical_background_reference_exclude_dilate",
                "24",
                "--target_extinction_apply_gamma",
                str(args.target_extinction_apply_gamma),
                "--target_extinction_apply_mode",
                str(args.target_extinction_apply_mode),
                "--target_extinction_apply_threshold",
                str(args.target_extinction_apply_threshold),
                "--target_extinction_apply_softness",
                str(args.target_extinction_apply_softness),
                "--target_extinction_apply_sigmoid_mix",
                str(args.target_extinction_apply_sigmoid_mix),
                "--target_extinction_strength",
                str(args.target_extinction_strength),
                "--target_extinction_floor",
                str(args.target_extinction_floor),
                "--dark_patch_strength",
                str(args.dark_patch_strength),
                "--dark_patch_floor",
                str(args.dark_patch_floor),
                "--target_preserve_strength",
                str(args.target_preserve_strength),
                "--target_preserve_threshold",
                str(args.target_preserve_threshold),
                "--target_preserve_blur_radius",
                str(args.target_preserve_blur_radius),
                "--target_preserve_occlusion_cut",
                str(args.target_preserve_occlusion_cut),
                "--multiplier_min",
                str(args.multiplier_min),
                "--multiplier_max",
                str(args.multiplier_max),
                "--visibility_min",
                str(args.visibility_min),
                "--visibility_max",
                str(args.visibility_max),
                "--layover_spatial_only" if bool(args.layover_spatial_only) else "--no-layover_spatial_only",
                "--layover_spatial_baseline",
                str(args.layover_spatial_baseline),
                "--layover_spatial_gain",
                str(args.layover_spatial_gain),
                "--layover_spatial_bias",
                str(args.layover_spatial_bias),
                "--layover_spatial_blur_radius",
                str(args.layover_spatial_blur_radius),
                "--dark_patch_spatial_floor",
                str(args.dark_patch_spatial_floor),
                "--target_extinction_spatial_floor",
                str(args.target_extinction_spatial_floor),
                "--layer_target_dilate",
                "0",
                "--layer_target_blur",
                "0",
                "--layer_target_strength",
                "1.0",
            ]
            shadow_restore_strength = float(getattr(args, "shadow_restore_strength", 0.0) or 0.0)
            if shadow_restore_strength > 0.0:
                cmd += [
                    "--shadow_restore_source",
                    "reference",
                    "--shadow_restore_strength",
                    str(shadow_restore_strength),
                    "--shadow_restore_mode",
                    "extinguish",
                    "--shadow_restore_threshold",
                    "0.20",
                    "--shadow_restore_target_dilate",
                    "34",
                    "--shadow_restore_target_protect_dilate",
                    str(args.shadow_restore_target_protect_dilate),
                    "--shadow_restore_clean_reference" if bool(args.shadow_restore_clean_reference) else "--no-shadow_restore_clean_reference",
                    "--shadow_restore_reference_blur",
                    "8",
                    "--shadow_restore_blur",
                    "4",
                    "--shadow_restore_context_blur",
                    "15",
                    "--shadow_restore_ratio_mix",
                    "0.8",
                    "--shadow_restore_min_attenuation",
                    "0.05",
                    "--shadow_restore_attenuation_power",
                    "1.8",
                    "--shadow_restore_max_coverage",
                    "0.22",
                    "--shadow_restore_coverage_softness",
                    "0.12",
                    "--shadow_restore_coverage_blur",
                    "5",
                    "--shadow_restore_floor",
                    "0",
                ]
            else:
                cmd += ["--shadow_restore_strength", "0.0"]
        else:
            cmd += [
                "--compose_order",
                "refiner_then_background",
                "--empirical_background_strength",
                "0.0",
                "--shadow_restore_strength",
                "0.0",
                "--target_extinction_apply_gamma",
                str(args.target_extinction_apply_gamma),
                "--target_extinction_apply_mode",
                str(args.target_extinction_apply_mode),
                "--target_extinction_apply_threshold",
                str(args.target_extinction_apply_threshold),
                "--target_extinction_apply_softness",
                str(args.target_extinction_apply_softness),
                "--target_extinction_apply_sigmoid_mix",
                str(args.target_extinction_apply_sigmoid_mix),
                "--target_extinction_strength",
                str(args.target_extinction_strength),
                "--target_extinction_floor",
                str(args.target_extinction_floor),
                "--dark_patch_strength",
                str(args.dark_patch_strength),
                "--dark_patch_floor",
                str(args.dark_patch_floor),
                "--target_preserve_strength",
                str(args.target_preserve_strength),
                "--target_preserve_threshold",
                str(args.target_preserve_threshold),
                "--target_preserve_blur_radius",
                str(args.target_preserve_blur_radius),
                "--target_preserve_occlusion_cut",
                str(args.target_preserve_occlusion_cut),
                "--multiplier_min",
                str(args.multiplier_min),
                "--multiplier_max",
                str(args.multiplier_max),
                "--visibility_min",
                str(args.visibility_min),
                "--visibility_max",
                str(args.visibility_max),
                "--layover_spatial_only" if bool(args.layover_spatial_only) else "--no-layover_spatial_only",
                "--layover_spatial_baseline",
                str(args.layover_spatial_baseline),
                "--layover_spatial_gain",
                str(args.layover_spatial_gain),
                "--layover_spatial_bias",
                str(args.layover_spatial_bias),
                "--layover_spatial_blur_radius",
                str(args.layover_spatial_blur_radius),
                "--dark_patch_spatial_floor",
                str(args.dark_patch_spatial_floor),
                "--target_extinction_spatial_floor",
                str(args.target_extinction_spatial_floor),
                "--layer_target_dilate",
                "0",
                "--layer_target_blur",
                "0",
            ]
        cmd = _append_if_supported(cmd, supported, "--target_only_refiner")
        cmd = _append_if_supported(cmd, supported, "--layer_target_use_preserve" if bool(args.layer_target_use_preserve) else "--no-layer_target_use_preserve")
        cmd += ["--save_maps" if bool(args.save_maps) else "--no-save_maps"]
        return cmd

    # These mirror the stable apply settings now also used as script defaults.
    cmd = cmd + [
        "--refiner_mode",
        "image",
        "--conv_padding_mode",
        "reflect",
        "--compose_order",
        "background_then_target_shadow",
        "--empirical_background_strength",
        str(args.empirical_background_strength),
        "--empirical_background_mode",
        str(args.empirical_background_mode),
        "--empirical_background_patch_size",
        str(args.empirical_background_patch_size),
        "--empirical_background_patch_overlap",
        str(args.empirical_background_patch_overlap),
        "--empirical_background_patch_smooth",
        str(args.empirical_background_patch_smooth),
        "--empirical_background_patch_fallback_weight",
        str(args.empirical_background_patch_fallback_weight),
        "--empirical_background_blend_blur",
        "2",
        "--empirical_background_target_dilate",
        "2",
        "--empirical_background_reference_exclude_dilate",
        "20",
        "--target_preserve_strength",
        str(args.target_preserve_strength),
        "--target_preserve_threshold",
        str(args.target_preserve_threshold),
        "--target_preserve_blur_radius",
        str(args.target_preserve_blur_radius),
        "--target_preserve_occlusion_cut",
        str(args.target_preserve_occlusion_cut),
        "--shadow_restore_source",
        "mod_target",
        "--shadow_restore_strength",
        str(args.shadow_restore_strength),
        "--shadow_restore_mode",
        "extinguish",
        "--shadow_restore_threshold",
        "0.22",
        "--shadow_restore_target_dilate",
        "80",
        "--shadow_restore_blur",
        "2",
        "--shadow_restore_context_blur",
        "15",
        "--shadow_restore_ratio_mix",
        "0.9",
        "--shadow_restore_min_attenuation",
        "0.01",
        "--shadow_restore_attenuation_power",
        "2.5",
        "--shadow_restore_floor",
        "0",
        "--layer_target_dilate",
        "0",
        "--layer_target_blur",
        "1",
        "--layer_target_strength",
        "1.0",
    ]
    cmd = _append_if_supported(cmd, supported, "--layer_target_use_preserve" if bool(args.layer_target_use_preserve) else "--no-layer_target_use_preserve")
    if int(args.empirical_background_patch_smooth) > 0:
        cmd = _append_if_supported(
            cmd,
            supported,
            "--empirical_background_patch_smooth_mix",
            str(args.empirical_background_patch_smooth_mix),
        )
    cmd = _append_if_supported(
        cmd,
        supported,
        "--empirical_background_lowfreq_smooth_strength",
        str(args.empirical_background_lowfreq_smooth_strength),
    )
    cmd = _append_if_supported(
        cmd,
        supported,
        "--empirical_background_lowfreq_radius",
        str(args.empirical_background_lowfreq_radius),
    )
    cmd = _append_if_supported(
        cmd,
        supported,
        "--empirical_background_lowfreq_extra_radius",
        str(args.empirical_background_lowfreq_extra_radius),
    )
    cmd = _append_if_supported(
        cmd,
        supported,
        "--empirical_background_highfreq_keep",
        str(args.empirical_background_highfreq_keep),
    )
    cmd += ["--save_maps" if bool(args.save_maps) else "--no-save_maps"]
    return cmd


def _add_postprocess_defaults(cmd: list[str], args: argparse.Namespace) -> list[str]:
    return cmd + [
        "--target_strength",
        str(args.target_strength),
        "--target_alpha_dilate",
        "0",
        "--target_alpha_blur",
        "0",
        "--target_alpha_gamma",
        "1.0",
        "--shadow_strength",
        str(args.shadow_strength),
        "--shadow_mode",
        "min_reference",
        "--shadow_search_dilate",
        str(args.shadow_search_dilate),
        "--shadow_target_exclude_dilate",
        "1",
        "--shadow_dark_threshold",
        "0.18",
        "--shadow_ratio_threshold",
        "0.16",
        "--shadow_context_blur",
        "17",
        "--shadow_soft_blur",
        "1",
        "--save_maps",
    ]


def _add_refiner_postprocess_defaults(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    passthrough = [
        ("--postprocess_target_strength", str(args.target_strength)),
        ("--postprocess_target_alpha_dilate", "0"),
        ("--postprocess_target_alpha_blur", "0"),
        ("--postprocess_target_alpha_gamma", "1.0"),
        ("--postprocess_shadow_strength", str(args.shadow_strength)),
        ("--postprocess_shadow_mode", "min_reference"),
        ("--postprocess_shadow_search_dilate", str(args.shadow_search_dilate)),
        ("--postprocess_shadow_target_exclude_dilate", "1"),
        ("--postprocess_shadow_dark_threshold", "0.18"),
        ("--postprocess_shadow_ratio_threshold", "0.16"),
        ("--postprocess_shadow_context_blur", "17"),
        ("--postprocess_shadow_soft_blur", "1"),
        ("--postprocess_save_maps",),
    ]
    for items in passthrough:
        cmd = _append_if_supported(cmd, supported, *items)
    return cmd


def _add_training_runtime_flags(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    cmd += [
        "--device",
        str(args.device),
    ]
    cmd = _append_if_supported(cmd, supported, "--allow_tf32" if bool(args.allow_tf32) else "--no-allow_tf32")
    cmd = _append_if_supported(
        cmd,
        supported,
        "--cudnn_benchmark" if bool(args.cudnn_benchmark) else "--no-cudnn_benchmark",
    )
    if bool(args.amp):
        cmd = _append_if_supported(cmd, supported, "--amp")
    cmd = _append_if_supported(cmd, supported, "--progress_metrics", str(args.progress_metrics))
    cmd = _append_if_supported(cmd, supported, "--progress_interval", str(args.progress_interval))
    cmd = _append_if_supported(cmd, supported, "--progress_refresh_seconds", str(args.progress_refresh_seconds))
    cmd = _append_if_supported(cmd, supported, "--max_grad_norm", str(args.max_grad_norm))
    return cmd


def _add_target_layover_training_flags(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    passthrough = [
        ("--refiner_ablation", str(args.refiner_ablation)),
        ("--focus_azimuths", str(args.focus_azimuths)),
        ("--focus_azimuth_repeat", str(args.focus_azimuth_repeat)),
        ("--focus_azimuth_tolerance", str(args.focus_azimuth_tolerance)),
        ("--mask_dilate", str(args.mask_dilate)),
        ("--full_image_l1_weight", str(args.full_image_l1_weight)),
        ("--target_l1_weight", str(args.target_l1_weight)),
        ("--ssim_loss_weight", str(args.ssim_loss_weight)),
        ("--intensity_mse_weight", str(args.intensity_mse_weight)),
        ("--quantile_loss_weight", str(args.quantile_loss_weight)),
        ("--target_loss_mask_threshold", str(args.target_loss_mask_threshold)),
        ("--target_loss_mask_quantile", str(args.target_loss_mask_quantile)),
        ("--target_loss_mask_dilate", str(args.target_loss_mask_dilate)),
        ("--target_loss_mask_min_pixels", str(args.target_loss_mask_min_pixels)),
        ("--target_compose_mask_dilate", str(args.target_compose_mask_dilate)),
        ("--target_extinction_strength", str(args.target_extinction_strength)),
        ("--target_extinction_floor", str(args.target_extinction_floor)),
        ("--dark_patch_strength", str(args.dark_patch_strength)),
        ("--dark_patch_floor", str(args.dark_patch_floor)),
        ("--target_preserve_strength", str(args.target_preserve_strength)),
        ("--target_preserve_threshold", str(args.target_preserve_threshold)),
        ("--target_preserve_blur_radius", str(args.target_preserve_blur_radius)),
        ("--target_preserve_occlusion_cut", str(args.target_preserve_occlusion_cut)),
        ("--multiplier_min", str(args.multiplier_min)),
        ("--multiplier_max", str(args.multiplier_max)),
        ("--visibility_min", str(args.visibility_min)),
        ("--visibility_max", str(args.visibility_max)),
        ("--layover_spatial_only" if bool(args.layover_spatial_only) else "--no-layover_spatial_only",),
        ("--layover_spatial_baseline", str(args.layover_spatial_baseline)),
        ("--layover_spatial_gain", str(args.layover_spatial_gain)),
        ("--layover_spatial_bias", str(args.layover_spatial_bias)),
        ("--layover_spatial_blur_radius", str(args.layover_spatial_blur_radius)),
        ("--dark_patch_spatial_floor", str(args.dark_patch_spatial_floor)),
        ("--target_extinction_spatial_floor", str(args.target_extinction_spatial_floor)),
        ("--target_extinction_gate_loss_weight", str(args.target_extinction_gate_loss_weight)),
        ("--target_extinction_neighbor_reduce", str(args.target_extinction_neighbor_reduce)),
        ("--target_extinction_dice_loss_weight", str(args.target_extinction_dice_loss_weight)),
        ("--target_extinction_focal_loss_weight", str(args.target_extinction_focal_loss_weight)),
        ("--target_extinction_focal_gamma", str(args.target_extinction_focal_gamma)),
        ("--target_extinction_render_gate_floor", str(args.target_extinction_render_gate_floor)),
        ("--target_extinction_apply_gamma", str(args.target_extinction_apply_gamma)),
        ("--target_extinction_apply_mode", str(args.target_extinction_apply_mode)),
        ("--target_extinction_apply_threshold", str(args.target_extinction_apply_threshold)),
        ("--target_extinction_apply_softness", str(args.target_extinction_apply_softness)),
        ("--target_extinction_apply_sigmoid_mix", str(args.target_extinction_apply_sigmoid_mix)),
        ("--target_extinction_residual_loss_weight", str(args.target_extinction_residual_loss_weight)),
        ("--target_extinction_residual_power", str(args.target_extinction_residual_power)),
        ("--target_extinction_ceiling_loss_weight", str(args.target_extinction_ceiling_loss_weight)),
        ("--target_extinction_ceiling_max_intensity", str(args.target_extinction_ceiling_max_intensity)),
        ("--target_extinction_ceiling_margin", str(args.target_extinction_ceiling_margin)),
        ("--target_extinction_ceiling_context_ratio", str(args.target_extinction_ceiling_context_ratio)),
        ("--target_extinction_ceiling_context_blur", str(args.target_extinction_ceiling_context_blur)),
        ("--target_extinction_ceiling_power", str(args.target_extinction_ceiling_power)),
        ("--target_extinction_positive_gain", str(args.target_extinction_positive_gain)),
        ("--target_extinction_sparsity_weight", str(args.target_extinction_sparsity_weight)),
        ("--target_extinction_target_threshold", str(args.target_extinction_target_threshold)),
        ("--target_extinction_target_high", str(args.target_extinction_target_high)),
        ("--target_extinction_dark_threshold", str(args.target_extinction_dark_threshold)),
        ("--target_extinction_ratio_threshold", str(args.target_extinction_ratio_threshold)),
        ("--target_extinction_context_blur", str(args.target_extinction_context_blur)),
        ("--target_extinction_soft_blur", str(args.target_extinction_soft_blur)),
        ("--target_extinction_gamma", str(args.target_extinction_gamma)),
        ("--target_geometry_loss_weight", str(args.target_geometry_loss_weight)),
        ("--target_geometry_min_visible", str(args.target_geometry_min_visible)),
        ("--rotated_structure_prior_weight", str(args.rotated_structure_prior_weight)),
        ("--rotated_structure_prior_strength", str(args.rotated_structure_prior_strength)),
        ("--rotated_structure_prior_reduce", str(args.rotated_structure_prior_reduce)),
        ("--rotated_structure_prior_angle_sign", str(args.rotated_structure_prior_angle_sign)),
        ("--rotated_structure_prior_max_delta", str(args.rotated_structure_prior_max_delta)),
        ("--rotated_structure_prior_dilate", str(args.rotated_structure_prior_dilate)),
        ("--rotated_structure_prior_blur", str(args.rotated_structure_prior_blur)),
        ("--rotated_structure_prior_padding_mode", str(args.rotated_structure_prior_padding_mode)),
        ("--rotated_structure_prior_gate_loss_weight", str(args.rotated_structure_prior_gate_loss_weight)),
        ("--rotated_structure_prior_dice_loss_weight", str(args.rotated_structure_prior_dice_loss_weight)),
        ("--rotated_structure_prior_positive_gain", str(args.rotated_structure_prior_positive_gain)),
        ("--rotated_structure_prior_residual_loss_weight", str(args.rotated_structure_prior_residual_loss_weight)),
        ("--rotated_structure_prior_residual_power", str(args.rotated_structure_prior_residual_power)),
        ("--rotated_structure_prior_max_intensity", str(args.rotated_structure_prior_max_intensity)),
        ("--rotated_structure_prior_margin", str(args.rotated_structure_prior_margin)),
        ("--rotated_structure_prior_edge_loss_weight", str(args.rotated_structure_prior_edge_loss_weight)),
        ("--rotated_structure_prior_edge_dilate", str(args.rotated_structure_prior_edge_dilate)),
        ("--rotated_structure_prior_local_ratio_weight", str(args.rotated_structure_prior_local_ratio_weight)),
        ("--rotated_structure_prior_local_ratio_pool", str(args.rotated_structure_prior_local_ratio_pool)),
        ("--rotated_structure_prior_dark_threshold", str(args.rotated_structure_prior_dark_threshold)),
        ("--rotated_structure_prior_dark_softness", str(args.rotated_structure_prior_dark_softness)),
        ("--target_speckle_loss_weight", str(args.target_speckle_loss_weight)),
        ("--target_speckle_stat_quantiles", str(args.target_speckle_stat_quantiles)),
        ("--target_speckle_std_quantile_weight", str(args.target_speckle_std_quantile_weight)),
        ("--target_speckle_highfreq_quantile_weight", str(args.target_speckle_highfreq_quantile_weight)),
        ("--target_speckle_intensity_quantile_weight", str(args.target_speckle_intensity_quantile_weight)),
        ("--target_speckle_dark_ratio_weight", str(args.target_speckle_dark_ratio_weight)),
        ("--target_speckle_dark_threshold", str(args.target_speckle_dark_threshold)),
        ("--target_speckle_dark_softness", str(args.target_speckle_dark_softness)),
        ("--multiplier_identity_weight", str(args.multiplier_identity_weight)),
        ("--visibility_identity_weight", str(args.visibility_identity_weight)),
        ("--dark_patch_sparsity_weight", str(args.dark_patch_sparsity_weight)),
        ("--target_shadow_mse_weight", str(args.target_shadow_mse_weight)),
        ("--target_shadow_ssim_loss_weight", str(args.target_shadow_ssim_loss_weight)),
        ("--target_shadow_quantile_loss_weight", str(args.target_shadow_quantile_loss_weight)),
        ("--target_shadow_patchgan_weight", str(args.target_shadow_patchgan_weight)),
        ("--target_occlusion_l1_weight", str(args.target_occlusion_l1_weight)),
        ("--target_occlusion_linear_l1_weight", str(args.target_occlusion_linear_l1_weight)),
        ("--target_occlusion_mse_weight", str(args.target_occlusion_mse_weight)),
        ("--target_occlusion_extinction_weight", str(args.target_occlusion_extinction_weight)),
        ("--target_occlusion_texture_loss_weight", str(args.target_occlusion_texture_loss_weight)),
        ("--target_occlusion_gradient_loss_weight", str(args.target_occlusion_gradient_loss_weight)),
        ("--target_occlusion_quantile_loss_weight", str(args.target_occlusion_quantile_loss_weight)),
        ("--target_occlusion_target_threshold", str(args.target_occlusion_target_threshold)),
        ("--target_occlusion_target_high", str(args.target_occlusion_target_high)),
        ("--target_occlusion_dark_threshold", str(args.target_occlusion_dark_threshold)),
        ("--target_occlusion_ratio_threshold", str(args.target_occlusion_ratio_threshold)),
        ("--target_occlusion_context_blur", str(args.target_occlusion_context_blur)),
        ("--target_occlusion_soft_blur", str(args.target_occlusion_soft_blur)),
        ("--target_occlusion_gamma", str(args.target_occlusion_gamma)),
        ("--target_occlusion_max_intensity", str(args.target_occlusion_max_intensity)),
        ("--target_occlusion_dark_margin", str(args.target_occlusion_dark_margin)),
        ("--target_occlusion_context_ratio", str(args.target_occlusion_context_ratio)),
        ("--train_gt_neighbor_mode", str(args.train_gt_neighbor_mode)),
        ("--train_gt_neighbor_angle_source", str(args.train_gt_neighbor_angle_source)),
        ("--train_gt_neighbor_mix_domain", str(args.train_gt_neighbor_mix_domain)),
        ("--train_gt_neighbor_supervision", str(args.train_gt_neighbor_supervision)),
    ]
    for items in passthrough:
        if len(items) == 1:
            cmd = _append_if_supported(cmd, supported, items[0])
            continue
        option, value = items
        if option == "--focus_azimuths" and not value.strip():
            continue
        if option == "--refiner_ablation" and value.strip().lower() in {"", "none"}:
            continue
        cmd = _append_if_supported(cmd, supported, option, value)
    merge_option = (
        "--rotated_structure_prior_merge_extinction"
        if bool(args.rotated_structure_prior_merge_extinction)
        else "--no-rotated_structure_prior_merge_extinction"
    )
    cmd = _append_if_supported(cmd, supported, merge_option)
    return cmd


def _specified_options(argv: list[str]) -> set[str]:
    """Return canonical --option names that were explicitly set by the user."""
    out = set()
    for item in argv:
        if not item.startswith("--"):
            continue
        opt = item.split("=", 1)[0]
        if opt.startswith("--no-"):
            opt = "--" + opt[5:]
        out.add(opt)
    return out


def _set_if_unset(args: argparse.Namespace, specified: set[str], name: str, value) -> None:
    option = "--" + name.replace("_", "-")
    alt_option = "--" + name
    if option in specified or alt_option in specified:
        return
    setattr(args, name, value)


def _any_specified(specified: set[str], *names: str) -> bool:
    for name in names:
        option = "--" + name.replace("_", "-")
        alt_option = "--" + name
        if option in specified or alt_option in specified:
            return True
    return False


def _apply_sar_structure_stat_preset(args: argparse.Namespace, specified: set[str]) -> None:
    """Prefer the best known target-region baseline over aggressive dark gating."""
    if not bool(getattr(args, "sar_structure_stat_preset", False)):
        return

    # These defaults intentionally match the v14 target-quality baseline.  Later
    # experiments made extinction gating harder, but target SAR-SSIM and edge
    # quality regressed, so the preset now favors the stable target baseline.
    _set_if_unset(args, specified, "target_l1_weight", 0.35)
    _set_if_unset(args, specified, "full_image_l1_weight", 0.0)
    _set_if_unset(args, specified, "ssim_loss_weight", 0.0)
    _set_if_unset(args, specified, "target_ssim_loss_weight", 0.24)
    _set_if_unset(args, specified, "target_mse_weight", 0.0)
    _set_if_unset(args, specified, "intensity_mse_weight", 0.10)

    # Keep bright scatterers as a distribution, not as exact pixels.
    _set_if_unset(args, specified, "bright_loss_weight", 0.42)
    _set_if_unset(args, specified, "texture_loss_weight", 1.65)
    _set_if_unset(args, specified, "gradient_loss_weight", 0.45)
    _set_if_unset(args, specified, "target_speckle_loss_weight", 0.22)
    _set_if_unset(args, specified, "target_speckle_std_quantile_weight", 1.0)
    _set_if_unset(args, specified, "target_speckle_highfreq_quantile_weight", 0.8)
    _set_if_unset(args, specified, "target_speckle_intensity_quantile_weight", 0.55)
    _set_if_unset(args, specified, "target_speckle_dark_ratio_weight", 0.65)
    _set_if_unset(args, specified, "target_speckle_dark_threshold", 0.22)
    _set_if_unset(args, specified, "target_speckle_dark_softness", 0.03)

    # Keep extinction structural, but avoid the v17 over-hard gate that reduced
    # target quality and increased edge error.
    _set_if_unset(args, specified, "target_extinction_gate_loss_weight", 0.80)
    _set_if_unset(args, specified, "target_extinction_dice_loss_weight", 0.55)
    _set_if_unset(args, specified, "target_extinction_focal_loss_weight", 0.30)
    _set_if_unset(args, specified, "target_extinction_residual_loss_weight", 0.45)
    _set_if_unset(args, specified, "target_extinction_ceiling_loss_weight", 0.55)
    _set_if_unset(args, specified, "target_extinction_ceiling_max_intensity", 0.06)
    _set_if_unset(args, specified, "target_extinction_ceiling_margin", 0.008)
    _set_if_unset(args, specified, "target_extinction_ceiling_context_ratio", 0.35)
    _set_if_unset(args, specified, "target_extinction_ceiling_context_blur", 9)
    _set_if_unset(args, specified, "target_extinction_ceiling_power", 2.0)
    _set_if_unset(args, specified, "target_extinction_positive_gain", 3.0)
    _set_if_unset(args, specified, "target_extinction_sparsity_weight", 0.001)
    _set_if_unset(args, specified, "target_extinction_neighbor_reduce", "max")
    _set_if_unset(args, specified, "target_extinction_render_gate_floor", 0.30)
    _set_if_unset(args, specified, "target_extinction_apply_gamma", 0.70)
    _set_if_unset(args, specified, "target_extinction_apply_mode", "power")
    _set_if_unset(args, specified, "target_extinction_apply_threshold", 0.0)
    _set_if_unset(args, specified, "target_extinction_apply_softness", 0.08)
    _set_if_unset(args, specified, "target_extinction_apply_sigmoid_mix", 0.5)
    _set_if_unset(args, specified, "target_extinction_strength", 1.0)
    _set_if_unset(args, specified, "target_extinction_floor", 0.0)
    _set_if_unset(args, specified, "target_extinction_dark_threshold", 0.17)
    _set_if_unset(args, specified, "target_extinction_ratio_threshold", 0.10)
    _set_if_unset(args, specified, "target_geometry_loss_weight", 0.06)
    _set_if_unset(args, specified, "target_geometry_min_visible", 8.0)
    _set_if_unset(args, specified, "rotated_structure_prior_weight", 0.70)
    _set_if_unset(args, specified, "rotated_structure_prior_strength", 0.90)
    _set_if_unset(args, specified, "rotated_structure_prior_reduce", "weighted_max")
    _set_if_unset(args, specified, "rotated_structure_prior_max_delta", 15.0)
    _set_if_unset(args, specified, "rotated_structure_prior_dilate", 0)
    _set_if_unset(args, specified, "rotated_structure_prior_blur", 1)
    _set_if_unset(args, specified, "rotated_structure_prior_merge_extinction", True)
    _set_if_unset(args, specified, "rotated_structure_prior_gate_loss_weight", 0.42)
    _set_if_unset(args, specified, "rotated_structure_prior_dice_loss_weight", 0.28)
    _set_if_unset(args, specified, "rotated_structure_prior_positive_gain", 2.8)
    _set_if_unset(args, specified, "rotated_structure_prior_residual_loss_weight", 0.35)
    _set_if_unset(args, specified, "rotated_structure_prior_max_intensity", 0.055)
    _set_if_unset(args, specified, "rotated_structure_prior_edge_loss_weight", 0.18)
    _set_if_unset(args, specified, "rotated_structure_prior_local_ratio_weight", 0.20)
    _set_if_unset(args, specified, "rotated_structure_prior_dark_threshold", 0.14)

    # Adjacent GTs should support the dark shape without averaging it away.
    _set_if_unset(args, specified, "train_gt_neighbor_mode", "linear")
    _set_if_unset(args, specified, "train_gt_neighbor_angle_source", "target")
    _set_if_unset(args, specified, "train_gt_neighbor_supervision", "mix")
    _set_if_unset(args, specified, "train_gt_neighbor_mix_domain", "log")
    _set_if_unset(args, specified, "target_loss_mask_dilate", 1)
    _set_if_unset(args, specified, "target_compose_mask_dilate", 0)


def _normalize_refiner_mode(args: argparse.Namespace, specified: set[str]) -> None:
    mode = str(getattr(args, "refiner_mode", "auto") or "auto").lower().strip()
    aliases = {
        "modulation": "target_modulation",
        "target": "target_modulation",
        "layover": "target_layover",
        "target-layover": "target_layover",
        "direct": "image",
        "full": "image",
    }
    mode = aliases.get(mode, mode)
    if mode == "auto":
        mode = "target_modulation" if bool(getattr(args, "target_only_refiner", False)) else "image"
    if mode == "target_layover":
        args.target_only_refiner = True
    args.refiner_mode = mode


def _apply_target_layover_pipeline_defaults(args: argparse.Namespace, specified: set[str]) -> None:
    if str(getattr(args, "refiner_mode", "image") or "image") != "target_layover":
        return

    args.target_only_refiner = True
    args.skip_bg_finetune = True
    _set_if_unset(args, specified, "target_only_compose_context", False)
    _set_if_unset(args, specified, "train_gt_neighbor_mode", "linear")
    _set_if_unset(args, specified, "train_gt_neighbor_angle_source", "target")
    _set_if_unset(args, specified, "train_gt_neighbor_supervision", "mix")
    _set_if_unset(args, specified, "train_gt_neighbor_mix_domain", "log")

    _set_if_unset(args, specified, "target_preserve_strength", 0.0)
    if "--layer_target_use_preserve" not in specified and "--no-layer_target_use_preserve" not in specified:
        args.layer_target_use_preserve = False
    if "--postprocess_after_apply" not in specified and "--no-postprocess_after_apply" not in specified:
        args.final_postprocess = False
    _set_if_unset(args, specified, "shadow_restore_strength", 0.0)
    _set_if_unset(args, specified, "empirical_background_strength", 0.0)

    _set_if_unset(args, specified, "multiplier_min", 0.55)
    _set_if_unset(args, specified, "multiplier_max", 1.20)
    _set_if_unset(args, specified, "visibility_min", 0.28)
    _set_if_unset(args, specified, "visibility_max", 1.0)
    _set_if_unset(args, specified, "dark_patch_strength", 0.40)
    _set_if_unset(args, specified, "dark_patch_floor", 0.0)
    _set_if_unset(args, specified, "target_extinction_strength", 0.60)
    _set_if_unset(args, specified, "target_extinction_floor", 0.0)
    _set_if_unset(args, specified, "target_extinction_apply_gamma", 0.85)
    _set_if_unset(args, specified, "target_extinction_apply_mode", "power")
    _set_if_unset(args, specified, "target_extinction_apply_threshold", 0.0)
    _set_if_unset(args, specified, "target_extinction_apply_softness", 0.08)
    _set_if_unset(args, specified, "target_extinction_apply_sigmoid_mix", 0.35)
    _set_if_unset(args, specified, "layover_spatial_only", True)
    _set_if_unset(args, specified, "layover_spatial_baseline", "masked_mean")
    _set_if_unset(args, specified, "layover_spatial_gain", 4.0)
    _set_if_unset(args, specified, "layover_spatial_bias", 0.0)
    _set_if_unset(args, specified, "layover_spatial_blur_radius", 9)
    _set_if_unset(args, specified, "dark_patch_spatial_floor", 0.0)
    _set_if_unset(args, specified, "target_extinction_spatial_floor", 0.0)

    _set_if_unset(args, specified, "target_l1_weight", 0.55)
    _set_if_unset(args, specified, "target_ssim_loss_weight", 0.18)
    _set_if_unset(args, specified, "intensity_mse_weight", 0.10)
    _set_if_unset(args, specified, "quantile_loss_weight", 0.12)
    _set_if_unset(args, specified, "texture_loss_weight", 1.25)
    _set_if_unset(args, specified, "gradient_loss_weight", 0.35)
    _set_if_unset(args, specified, "full_image_l1_weight", 0.0)
    _set_if_unset(args, specified, "ssim_loss_weight", 0.0)
    _set_if_unset(args, specified, "bright_loss_weight", 0.30)
    _set_if_unset(args, specified, "bright_loss_gain", 5.0)

    _set_if_unset(args, specified, "target_extinction_gate_loss_weight", 0.22)
    _set_if_unset(args, specified, "target_extinction_dice_loss_weight", 0.14)
    _set_if_unset(args, specified, "target_extinction_focal_loss_weight", 0.08)
    _set_if_unset(args, specified, "target_extinction_residual_loss_weight", 0.08)
    _set_if_unset(args, specified, "target_extinction_ceiling_loss_weight", 0.0)
    _set_if_unset(args, specified, "target_extinction_positive_gain", 2.0)
    _set_if_unset(args, specified, "target_extinction_sparsity_weight", 0.008)
    _set_if_unset(args, specified, "target_extinction_neighbor_reduce", "weighted_max")
    _set_if_unset(args, specified, "target_extinction_render_gate_floor", 0.32)
    _set_if_unset(args, specified, "target_occlusion_l1_weight", 0.05)
    _set_if_unset(args, specified, "target_occlusion_extinction_weight", 0.08)
    _set_if_unset(args, specified, "target_occlusion_texture_loss_weight", 0.02)
    _set_if_unset(args, specified, "target_occlusion_gradient_loss_weight", 0.02)
    _set_if_unset(args, specified, "target_speckle_loss_weight", 0.10)
    _set_if_unset(args, specified, "target_speckle_std_quantile_weight", 0.9)
    _set_if_unset(args, specified, "target_speckle_highfreq_quantile_weight", 0.7)
    _set_if_unset(args, specified, "target_speckle_intensity_quantile_weight", 0.45)
    _set_if_unset(args, specified, "target_speckle_dark_ratio_weight", 0.30)
    _set_if_unset(args, specified, "target_geometry_loss_weight", 0.03)

    _set_if_unset(args, specified, "multiplier_identity_weight", 0.020)
    _set_if_unset(args, specified, "visibility_identity_weight", 0.012)
    _set_if_unset(args, specified, "dark_patch_sparsity_weight", 0.010)
    _set_if_unset(args, specified, "rotated_structure_prior_weight", 0.0)
    _set_if_unset(args, specified, "save_maps", True)


def _apply_refiner_ablation_pipeline_defaults(args: argparse.Namespace, specified: set[str]) -> None:
    mode = str(getattr(args, "refiner_ablation", "none") or "none").lower().strip()
    if mode in {"", "none"}:
        return

    args.target_only_refiner = True
    args.skip_bg_finetune = True

    def setv(name: str, value) -> None:
        setattr(args, name, value)

    if mode == "no_spatial_gate":
        setv("layover_spatial_only", False)
        setv("dark_patch_spatial_floor", 0.0)
        setv("target_extinction_spatial_floor", 0.0)
        print("[refiner ablation] no_spatial_gate: disabled spatial-only dark/extinction gate.")
        return

    if mode == "wide_maps":
        setv("multiplier_min", 0.35)
        setv("multiplier_max", 1.85)
        setv("visibility_min", 0.12)
        setv("visibility_max", 1.0)
        setv("dark_patch_strength", 0.85)
        setv("target_extinction_strength", 1.0)
        print("[refiner ablation] wide_maps: restored v11-style modulation ranges.")
        return

    if mode == "no_extinction_losses":
        for name in (
            "target_extinction_gate_loss_weight",
            "target_extinction_dice_loss_weight",
            "target_extinction_focal_loss_weight",
            "target_extinction_residual_loss_weight",
            "target_extinction_ceiling_loss_weight",
            "target_occlusion_extinction_weight",
        ):
            setv(name, 0.0)
        print("[refiner ablation] no_extinction_losses: disabled explicit extinction/occlusion gate losses.")
        return

    if mode == "nearest_gt":
        setv("train_gt_neighbor_mode", "nearest")
        setv("train_gt_neighbor_supervision", "sample")
        setv("train_gt_neighbor_mix_domain", "pixel")
        setv("target_extinction_neighbor_reduce", "max")
        print("[refiner ablation] nearest_gt: using old nearest/sample GT supervision.")
        return

    if mode == "old_structure_stat":
        # Recreate the older v11 structure/stat behavior as closely as possible:
        # target_modulation, no spatial-only gate, wide modulation maps, strong
        # extinction supervision, and statistical target losses.
        setv("refiner_mode", "target_modulation")
        setv("layover_spatial_only", False)
        setv("multiplier_min", 0.35)
        setv("multiplier_max", 1.85)
        setv("visibility_min", 0.12)
        setv("visibility_max", 1.0)
        setv("dark_patch_strength", 0.85)
        setv("dark_patch_floor", 0.02)
        setv("dark_patch_sparsity_weight", 0.006)
        setv("target_extinction_strength", 1.0)
        setv("target_extinction_apply_gamma", 0.70)
        setv("target_extinction_gate_loss_weight", 0.80)
        setv("target_extinction_dice_loss_weight", 0.55)
        setv("target_extinction_focal_loss_weight", 0.30)
        setv("target_extinction_residual_loss_weight", 0.45)
        setv("target_extinction_ceiling_loss_weight", 0.0)
        setv("target_extinction_positive_gain", 3.0)
        setv("target_extinction_sparsity_weight", 0.001)
        setv("target_extinction_neighbor_reduce", "max")
        setv("target_extinction_render_gate_floor", 0.30)
        setv("target_extinction_dark_threshold", 0.17)
        setv("target_extinction_ratio_threshold", 0.10)
        setv("target_l1_weight", 0.35)
        setv("target_ssim_loss_weight", 0.24)
        setv("bright_loss_weight", 0.42)
        setv("bright_loss_gain", 7.0)
        setv("quantile_loss_weight", 0.45)
        setv("texture_loss_weight", 1.65)
        setv("gradient_loss_weight", 0.45)
        setv("target_speckle_loss_weight", 0.22)
        setv("target_speckle_std_quantile_weight", 1.0)
        setv("target_speckle_highfreq_quantile_weight", 0.8)
        setv("target_speckle_intensity_quantile_weight", 0.55)
        setv("target_speckle_dark_ratio_weight", 0.65)
        setv("target_speckle_dark_threshold", 0.22)
        setv("target_speckle_dark_softness", 0.03)
        setv("target_geometry_loss_weight", 0.0)
        setv("rotated_structure_prior_weight", 0.0)
        for name in (
            "target_occlusion_l1_weight",
            "target_occlusion_linear_l1_weight",
            "target_occlusion_mse_weight",
            "target_occlusion_extinction_weight",
            "target_occlusion_texture_loss_weight",
            "target_occlusion_gradient_loss_weight",
            "target_occlusion_quantile_loss_weight",
        ):
            setv(name, 0.0)
        print("[refiner ablation] old_structure_stat: using v11-style target_modulation structure/stat settings.")
        return

    raise ValueError(f"Unknown --refiner_ablation: {mode}")


def _warn_ablation_workdir_mismatch(work_dir: Path, args: argparse.Namespace) -> None:
    ablation = str(getattr(args, "refiner_ablation", "none") or "none").lower().strip()
    if ablation in {"", "none"}:
        return
    name = work_dir.name.lower()
    known = {
        "no_spatial_gate",
        "wide_maps",
        "no_extinction_losses",
        "nearest_gt",
        "old_structure_stat",
    }
    mentioned = [item for item in known if item in name]
    if mentioned and ablation not in mentioned:
        print(
            "[refiner ablation] warning: work_dir name suggests "
            f"{mentioned}, but --refiner_ablation is {ablation}. "
            "The CLI flag controls the actual run."
        )


def _apply_target_only_pipeline_defaults(args: argparse.Namespace, specified: set[str] | None = None) -> None:
    if not bool(getattr(args, "target_only_refiner", False)):
        return
    specified = specified or set()
    args.skip_bg_finetune = True
    _set_if_unset(args, specified, "mask_dilate", 1)
    _set_if_unset(args, specified, "loss_mask_dilate", 0)
    _set_if_unset(args, specified, "target_loss_mask_dilate", 1)
    _set_if_unset(args, specified, "target_compose_mask_dilate", 0)
    args.target_ring_width = 0
    args.target_ring_l1_weight = 0.0
    args.target_ring_texture_loss_weight = 0.0
    args.target_ring_gradient_loss_weight = 0.0
    args.target_ring_quantile_loss_weight = 0.0
    args.target_ring_patchgan_weight = 0.0

    shadow_loss_names = (
        "target_shadow_l1_weight",
        "target_shadow_linear_l1_weight",
        "target_shadow_mse_weight",
        "target_shadow_extinction_weight",
        "target_shadow_texture_loss_weight",
        "target_shadow_gradient_loss_weight",
        "target_shadow_ssim_loss_weight",
        "target_shadow_quantile_loss_weight",
        "target_shadow_patchgan_weight",
    )
    if _any_specified(specified, *shadow_loss_names):
        _set_if_unset(args, specified, "target_shadow_width", 18)
    else:
        args.target_shadow_width = 0
        for name in shadow_loss_names:
            setattr(args, name, 0.0)

    occlusion_loss_names = (
        "target_occlusion_l1_weight",
        "target_occlusion_linear_l1_weight",
        "target_occlusion_mse_weight",
        "target_occlusion_extinction_weight",
        "target_occlusion_texture_loss_weight",
        "target_occlusion_gradient_loss_weight",
        "target_occlusion_quantile_loss_weight",
    )
    if not _any_specified(specified, *occlusion_loss_names):
        for name in occlusion_loss_names:
            setattr(args, name, 0.0)

    args.background_patchgan_weight = 0.0
    _set_if_unset(args, specified, "target_preserve_strength", 0.0)
    if "--layer_target_use_preserve" not in specified and "--no-layer_target_use_preserve" not in specified:
        args.layer_target_use_preserve = False
    if bool(getattr(args, "target_only_compose_context", False)):
        if "--empirical_background_strength" not in specified and float(args.empirical_background_strength) >= 1.0:
            args.empirical_background_strength = 0.62
        args.empirical_background_mode = "patch"
        if "--empirical_background_patch_smooth" not in specified:
            args.empirical_background_patch_smooth = 1
        if "--empirical_background_patch_smooth_mix" not in specified:
            args.empirical_background_patch_smooth_mix = 0.30
        if "--empirical_background_patch_fallback_weight" not in specified:
            args.empirical_background_patch_fallback_weight = 1.0
    else:
        args.empirical_background_strength = 0.0
    _set_if_unset(args, specified, "shadow_restore_strength", 0.0)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="SAR refiner pipeline: train base -> bg finetune -> apply -> optional postprocess/eval.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--repo_root", type=Path, default=None)
    parser.add_argument("--python", type=str, default=sys.executable)
    parser.add_argument(
        "--stage",
        choices=[
            "full_train",
            "train_base",
            "finetune_bg",
            "apply",
            "postprocess",
            "eval",
            "apply_eval",
        ],
        default="apply_eval",
        help="full_train runs base training, background finetune, final apply, and optional eval.",
    )
    parser.add_argument("--dry_run", action="store_true")
    parser.add_argument(
        "--keep_intermediate_apply",
        action="store_true",
        default=False,
        help="Also apply/postprocess after base and background training. Disabled by default to avoid weak/repeated stages.",
    )
    parser.add_argument(
        "--final_postprocess",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Run the final local target/shadow postprocess after apply. Disabled by default because it is usually nearly identical.",
    )
    parser.add_argument(
        "--postprocess_after_apply",
        dest="final_postprocess",
        action=argparse.BooleanOptionalAction,
        default=argparse.SUPPRESS,
        help="Alias for --final_postprocess/--no-final_postprocess, accepted for refiner CLI compatibility.",
    )
    parser.add_argument(
        "--skip_bg_finetune",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Skip background fine-tuning and apply the base refiner checkpoint directly.",
    )
    parser.add_argument(
        "--target_only_refiner",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Train/apply the target-layover modulation path. Background/ring/PatchGAN losses "
            "are disabled by default; target shadow/occlusion losses are opt-in via explicit weights."
        ),
    )
    parser.add_argument(
        "--refiner_mode",
        choices=[
            "auto",
            "image",
            "residual",
            "target_modulation",
            "target_layover",
            "modulation",
            "target",
            "layover",
            "target-layover",
            "direct",
            "full",
        ],
        default="auto",
        help=(
            "auto keeps existing behavior. target_layover trains/applies the clean target SAR "
            "layover mode: adjacent-GT supervision, no strong preserve, no postprocess shadow painting."
        ),
    )
    parser.add_argument(
        "--target_only_compose_context",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="For target-only apply, synthesize empirical background around the refiner-modulated target layer.",
    )
    parser.add_argument(
        "--sar_structure_stat_preset",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Use a robust SAR target preset: reduce pixel/SSIM averaging and emphasize "
            "extinction structure plus speckle/statistical losses. Explicit CLI weights still win."
        ),
    )
    parser.add_argument(
        "--refiner_ablation",
        choices=[
            "none",
            "no_spatial_gate",
            "wide_maps",
            "no_extinction_losses",
            "nearest_gt",
            "old_structure_stat",
        ],
        default="none",
        help=(
            "One-change-at-a-time debug preset for refiner regression checks. "
            "old_structure_stat restores the v11-style target_modulation structure/stat setup."
        ),
    )

    parser.add_argument("-m", "--model_path", type=Path, default=Path("output/360-2-target-nofilm-5000"))
    parser.add_argument("--work_dir", type=Path, default=None)
    parser.add_argument(
        "--record_results",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Record each run's effective parameters, commands, paths, and metric artifacts under <model_path>/result.",
    )
    parser.add_argument(
        "--result_dir",
        type=Path,
        default=None,
        help="Override the run archive directory. Defaults to <model_path>/result.",
    )

    parser.add_argument("--base_checkpoint", type=Path, default=None)
    parser.add_argument("--bg_checkpoint", type=Path, default=None)
    parser.add_argument("--checkpoint", type=Path, default=None, help="Checkpoint used by apply/apply_eval.")

    parser.add_argument("--base_output", type=Path, default=None)
    parser.add_argument("--base_post_output", type=Path, default=None)
    parser.add_argument("--bg_output", type=Path, default=None)
    parser.add_argument("--bg_post_output", type=Path, default=None)
    parser.add_argument("--apply_output", type=Path, default=None)
    parser.add_argument("--final_render_dir", type=Path, default=None)

    parser.add_argument("--target_mask_dir", type=Path, default=None)
    parser.add_argument("--gt_dir", type=Path, default=None)
    parser.add_argument("--train_target_dir", type=Path, default=None)
    parser.add_argument("--train_gt_dir", type=Path, default=None)
    parser.add_argument("--eval_output", type=Path, default=None)

    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--amp", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--allow_tf32", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--cudnn_benchmark", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument(
        "--progress_metrics",
        choices=["compact", "full", "none"],
        default="compact",
        help="Refiner training progress postfix verbosity. compact avoids long tqdm lines on Windows terminals.",
    )
    parser.add_argument("--progress_interval", type=int, default=20)
    parser.add_argument("--progress_refresh_seconds", type=float, default=0.5)
    parser.add_argument(
        "--max_grad_norm",
        type=float,
        default=1.0,
        help="Clip refiner gradients; prevents NaN checkpoints in aggressive layover training.",
    )
    parser.add_argument("--view_split_train_angle_step", type=int, default=10)
    parser.add_argument("--view_split_train_angles", type=str, default=None)
    parser.add_argument("--view_split_train_dir", type=Path, default=None)

    parser.add_argument("--base_iterations", type=int, default=5000)
    parser.add_argument("--bg_iterations", type=int, default=3000)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--base_lr", type=float, default=3e-5)
    parser.add_argument("--bg_lr", type=float, default=3e-5)
    parser.add_argument("--train_azimuth_step", type=float, default=10.0)
    parser.add_argument("--train_azimuth_unique", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--train_use_all_targets", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--train_gt_neighbor_mode", choices=["nearest", "linear"], default="nearest")
    parser.add_argument("--train_gt_neighbor_angle_source", choices=["target", "slot"], default="target")
    parser.add_argument("--train_gt_neighbor_mix_domain", choices=["pixel", "log"], default="pixel")
    parser.add_argument("--train_gt_neighbor_supervision", choices=["sample", "mix"], default="sample")
    parser.add_argument("--focus_azimuths", type=str, default="")
    parser.add_argument("--focus_azimuth_repeat", type=int, default=1)
    parser.add_argument("--focus_azimuth_tolerance", type=float, default=2.5)
    parser.add_argument("--target_l1_weight", type=float, default=1.0)
    parser.add_argument("--dark_patch_strength", type=float, default=0.85)
    parser.add_argument("--dark_patch_floor", type=float, default=0.02)
    parser.add_argument("--target_extinction_strength", type=float, default=1.0)
    parser.add_argument("--target_extinction_floor", type=float, default=0.0)
    parser.add_argument("--target_extinction_gate_loss_weight", type=float, default=0.65)
    parser.add_argument("--target_extinction_neighbor_reduce", choices=["max", "weighted_max", "weighted_mean", "mix"], default="max")
    parser.add_argument("--target_extinction_dice_loss_weight", type=float, default=0.45)
    parser.add_argument("--target_extinction_focal_loss_weight", type=float, default=0.25)
    parser.add_argument("--target_extinction_focal_gamma", type=float, default=2.0)
    parser.add_argument("--target_extinction_render_gate_floor", type=float, default=0.35)
    parser.add_argument("--target_extinction_apply_gamma", type=float, default=0.70)
    parser.add_argument("--target_extinction_apply_mode", choices=["power", "sigmoid", "threshold", "power_sigmoid", "sigmoid_power"], default="power")
    parser.add_argument("--target_extinction_apply_threshold", type=float, default=0.0)
    parser.add_argument("--target_extinction_apply_softness", type=float, default=0.08)
    parser.add_argument("--target_extinction_apply_sigmoid_mix", type=float, default=0.5)
    parser.add_argument("--target_extinction_residual_loss_weight", type=float, default=0.35)
    parser.add_argument("--target_extinction_residual_power", type=float, default=2.0)
    parser.add_argument("--target_extinction_ceiling_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_extinction_ceiling_max_intensity", type=float, default=0.07)
    parser.add_argument("--target_extinction_ceiling_margin", type=float, default=0.01)
    parser.add_argument("--target_extinction_ceiling_context_ratio", type=float, default=0.40)
    parser.add_argument("--target_extinction_ceiling_context_blur", type=int, default=9)
    parser.add_argument("--target_extinction_ceiling_power", type=float, default=2.0)
    parser.add_argument("--target_extinction_positive_gain", type=float, default=2.0)
    parser.add_argument("--target_extinction_sparsity_weight", type=float, default=0.002)
    parser.add_argument("--target_extinction_target_threshold", type=float, default=0.08)
    parser.add_argument("--target_extinction_target_high", type=float, default=0.28)
    parser.add_argument("--target_extinction_dark_threshold", type=float, default=0.16)
    parser.add_argument("--target_extinction_ratio_threshold", type=float, default=0.12)
    parser.add_argument("--target_extinction_context_blur", type=int, default=9)
    parser.add_argument("--target_extinction_soft_blur", type=int, default=1)
    parser.add_argument("--target_extinction_gamma", type=float, default=1.0)
    parser.add_argument("--target_geometry_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_geometry_min_visible", type=float, default=8.0)
    parser.add_argument("--rotated_structure_prior_weight", type=float, default=0.0)
    parser.add_argument("--rotated_structure_prior_strength", type=float, default=1.0)
    parser.add_argument("--rotated_structure_prior_reduce", choices=["max", "mean", "weighted_max", "weighted_mean"], default="weighted_max")
    parser.add_argument("--rotated_structure_prior_angle_sign", type=float, default=1.0)
    parser.add_argument("--rotated_structure_prior_max_delta", type=float, default=15.0)
    parser.add_argument("--rotated_structure_prior_dilate", type=int, default=0)
    parser.add_argument("--rotated_structure_prior_blur", type=int, default=1)
    parser.add_argument("--rotated_structure_prior_padding_mode", choices=["zeros", "border", "reflection"], default="border")
    parser.add_argument("--rotated_structure_prior_merge_extinction", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--rotated_structure_prior_gate_loss_weight", type=float, default=0.45)
    parser.add_argument("--rotated_structure_prior_dice_loss_weight", type=float, default=0.30)
    parser.add_argument("--rotated_structure_prior_positive_gain", type=float, default=2.5)
    parser.add_argument("--rotated_structure_prior_residual_loss_weight", type=float, default=0.35)
    parser.add_argument("--rotated_structure_prior_residual_power", type=float, default=2.0)
    parser.add_argument("--rotated_structure_prior_max_intensity", type=float, default=0.055)
    parser.add_argument("--rotated_structure_prior_margin", type=float, default=0.005)
    parser.add_argument("--rotated_structure_prior_edge_loss_weight", type=float, default=0.18)
    parser.add_argument("--rotated_structure_prior_edge_dilate", type=int, default=2)
    parser.add_argument("--rotated_structure_prior_local_ratio_weight", type=float, default=0.20)
    parser.add_argument("--rotated_structure_prior_local_ratio_pool", type=int, default=9)
    parser.add_argument("--rotated_structure_prior_dark_threshold", type=float, default=0.14)
    parser.add_argument("--rotated_structure_prior_dark_softness", type=float, default=0.035)
    parser.add_argument("--full_image_l1_weight", type=float, default=0.55)
    parser.add_argument("--ssim_loss_weight", type=float, default=0.65)
    parser.add_argument("--intensity_mse_weight", type=float, default=0.20)
    parser.add_argument("--target_ssim_loss_weight", type=float, default=0.35)
    parser.add_argument("--target_mse_weight", type=float, default=0.0)
    parser.add_argument("--mask_dilate", type=int, default=1)
    parser.add_argument("--loss_mask_dilate", type=int, default=6)
    parser.add_argument("--target_loss_mask_threshold", type=float, default=0.08)
    parser.add_argument("--target_loss_mask_quantile", type=float, default=0.0)
    parser.add_argument("--target_loss_mask_dilate", type=int, default=0)
    parser.add_argument("--target_loss_mask_min_pixels", type=float, default=16.0)
    parser.add_argument("--target_compose_mask_dilate", type=int, default=0)
    parser.add_argument("--bright_loss_weight", type=float, default=0.50)
    parser.add_argument("--bright_loss_gain", type=float, default=7.0)
    parser.add_argument("--quantile_loss_weight", type=float, default=0.45)
    parser.add_argument("--texture_loss_weight", type=float, default=1.6)
    parser.add_argument("--gradient_loss_weight", type=float, default=0.45)
    parser.add_argument("--target_speckle_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_speckle_stat_quantiles", type=str, default="0.05,0.10,0.25,0.50,0.75,0.90,0.97")
    parser.add_argument("--target_speckle_std_quantile_weight", type=float, default=1.0)
    parser.add_argument("--target_speckle_highfreq_quantile_weight", type=float, default=0.8)
    parser.add_argument("--target_speckle_intensity_quantile_weight", type=float, default=0.6)
    parser.add_argument("--target_speckle_dark_ratio_weight", type=float, default=0.6)
    parser.add_argument("--target_speckle_dark_threshold", type=float, default=0.22)
    parser.add_argument("--target_speckle_dark_softness", type=float, default=0.035)
    parser.add_argument("--multiplier_identity_weight", type=float, default=0.015)
    parser.add_argument("--visibility_identity_weight", type=float, default=0.010)
    parser.add_argument("--dark_patch_sparsity_weight", type=float, default=0.006)
    parser.add_argument("--target_ring_width", type=int, default=10)
    parser.add_argument("--target_ring_inner_dilate", type=int, default=0)
    parser.add_argument("--target_ring_l1_weight", type=float, default=0.45)
    parser.add_argument("--target_ring_texture_loss_weight", type=float, default=0.35)
    parser.add_argument("--target_ring_gradient_loss_weight", type=float, default=0.18)
    parser.add_argument("--target_ring_quantile_loss_weight", type=float, default=0.25)
    parser.add_argument("--target_ring_patchgan_weight", type=float, default=0.015)
    parser.add_argument("--target_shadow_width", type=int, default=18)
    parser.add_argument("--target_shadow_l1_weight", type=float, default=0.35)
    parser.add_argument("--target_shadow_linear_l1_weight", type=float, default=0.25)
    parser.add_argument("--target_shadow_mse_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_extinction_weight", type=float, default=0.18)
    parser.add_argument("--target_shadow_texture_loss_weight", type=float, default=0.20)
    parser.add_argument("--target_shadow_gradient_loss_weight", type=float, default=0.10)
    parser.add_argument("--target_shadow_ssim_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_quantile_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_patchgan_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_l1_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_linear_l1_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_mse_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_extinction_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_texture_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_gradient_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_quantile_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_target_threshold", type=float, default=0.08)
    parser.add_argument("--target_occlusion_target_high", type=float, default=0.28)
    parser.add_argument("--target_occlusion_dark_threshold", type=float, default=0.16)
    parser.add_argument("--target_occlusion_ratio_threshold", type=float, default=0.12)
    parser.add_argument("--target_occlusion_context_blur", type=int, default=9)
    parser.add_argument("--target_occlusion_soft_blur", type=int, default=1)
    parser.add_argument("--target_occlusion_gamma", type=float, default=1.0)
    parser.add_argument("--target_occlusion_max_intensity", type=float, default=0.08)
    parser.add_argument("--target_occlusion_dark_margin", type=float, default=0.005)
    parser.add_argument("--target_occlusion_context_ratio", type=float, default=0.40)
    parser.add_argument("--azimuth_consistency_weight", type=float, default=0.0)
    parser.add_argument("--azimuth_consistency_max_gap", type=float, default=12.0)
    parser.add_argument("--azimuth_consistency_samples", type=int, default=1)
    parser.add_argument("--azimuth_consistency_texture_weight", type=float, default=0.25)
    parser.add_argument("--background_patchgan_weight", type=float, default=0.04)
    parser.add_argument("--patchgan_lr", type=float, default=1e-4)
    parser.add_argument("--patchgan_base", type=int, default=32)

    parser.add_argument("--target_strength", type=float, default=0.6)
    parser.add_argument("--shadow_strength", type=float, default=0.9)
    parser.add_argument("--shadow_search_dilate", type=int, default=45)
    parser.add_argument("--shadow_restore_strength", type=float, default=0.0)
    parser.add_argument("--shadow_restore_target_protect_dilate", type=int, default=3)
    parser.add_argument("--empirical_background_strength", type=float, default=1.0)
    parser.add_argument("--empirical_background_mode", choices=["patch", "reference", "pixel"], default="reference")
    parser.add_argument("--empirical_background_patch_size", type=int, default=6)
    parser.add_argument("--empirical_background_patch_overlap", type=int, default=2)
    parser.add_argument("--empirical_background_patch_smooth", type=int, default=0)
    parser.add_argument("--empirical_background_patch_smooth_mix", type=float, default=0.35)
    parser.add_argument("--empirical_background_patch_fallback_weight", type=float, default=1.0)
    parser.add_argument("--empirical_background_clean_reference", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--shadow_restore_clean_reference", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--empirical_background_lowfreq_smooth_strength", type=float, default=0.35)
    parser.add_argument("--empirical_background_lowfreq_radius", type=int, default=3)
    parser.add_argument("--empirical_background_lowfreq_extra_radius", type=int, default=7)
    parser.add_argument("--empirical_background_highfreq_keep", type=float, default=0.90)
    parser.add_argument("--save_maps", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--save_training_masks", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--target_preserve_strength", type=float, default=0.0)
    parser.add_argument("--target_preserve_threshold", type=float, default=0.45)
    parser.add_argument("--target_preserve_blur_radius", type=int, default=1)
    parser.add_argument("--target_preserve_occlusion_cut", type=float, default=0.85)
    parser.add_argument("--layer_target_use_preserve", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--multiplier_min", type=float, default=0.35)
    parser.add_argument("--multiplier_max", type=float, default=1.85)
    parser.add_argument("--visibility_min", type=float, default=0.12)
    parser.add_argument("--visibility_max", type=float, default=1.0)
    parser.add_argument("--layover_spatial_only", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--layover_spatial_baseline", choices=["masked_mean", "blur"], default="masked_mean")
    parser.add_argument("--layover_spatial_gain", type=float, default=4.0)
    parser.add_argument("--layover_spatial_bias", type=float, default=0.0)
    parser.add_argument("--layover_spatial_blur_radius", type=int, default=9)
    parser.add_argument("--dark_patch_spatial_floor", type=float, default=0.0)
    parser.add_argument("--target_extinction_spatial_floor", type=float, default=0.0)

    specified_options = _specified_options(sys.argv[1:])
    args = parser.parse_args()
    _normalize_refiner_mode(args, specified_options)
    _apply_sar_structure_stat_preset(args, specified_options)
    _apply_target_only_pipeline_defaults(args, specified_options)
    _apply_target_layover_pipeline_defaults(args, specified_options)
    _apply_refiner_ablation_pipeline_defaults(args, specified_options)

    launch_dir = Path.cwd()
    repo_root = _find_repo_root(Path(__file__).resolve())
    if args.repo_root:
        requested_repo_root = _resolve_user_path(args.repo_root, launch_dir)
        if requested_repo_root and requested_repo_root.resolve() != repo_root.resolve():
            print(
                f"[compat] ignoring --repo_root {requested_repo_root}; "
                f"pipeline now runs only from its own repo {repo_root}"
            )
    refiner_script = _repo_relative_script(repo_root, "scripts/rendering/learn_sar_target_modulation_refiner.py")
    postprocess_script = _repo_relative_script(repo_root, "scripts/rendering/postprocess_sar_target_shadow.py")
    eval_script = _repo_relative_script(repo_root, "scripts/evaluation/compare_render_gt.py")
    delta_eval_script = _repo_relative_script(repo_root, "scripts/evaluation/compare_refiner_target_delta.py")
    refiner_supported = _supported_cli_options(
        args.python,
        repo_root,
        refiner_script,
    )
    model_path = _resolve_user_path(args.model_path, launch_dir)
    work_dir = _resolve_user_path(args.work_dir, launch_dir) if args.work_dir else _default_work_dir(model_path)
    _warn_ablation_workdir_mismatch(work_dir, args)
    target_mask_dir = (
        _resolve_user_path(args.target_mask_dir, launch_dir)
        if args.target_mask_dir
        else _default_target_mask_dir(model_path, work_dir)
    )
    train_target_dir = _resolve_user_path(args.train_target_dir, launch_dir)
    train_gt_dir = _resolve_user_path(args.train_gt_dir, launch_dir)
    gt_dir = _resolve_user_path(args.gt_dir, launch_dir)
    view_split_train_dir = _resolve_user_path(args.view_split_train_dir, launch_dir)

    stage01_dir = work_dir / "01.refiner"
    stage02_dir = work_dir / "02.background_finetune"
    stage03_dir = work_dir / "03.apply_postprocess"
    stage04_dir = work_dir / "04.evaluation"

    base_checkpoint = _resolve_user_path(args.base_checkpoint, launch_dir) if args.base_checkpoint else stage01_dir / "sar_target_modulation_refiner_patchgan_no_ring.pth"
    bg_checkpoint = _resolve_user_path(args.bg_checkpoint, launch_dir) if args.bg_checkpoint else stage02_dir / "sar_target_modulation_refiner_bg_finetune.pth"
    explicit_checkpoint = _resolve_user_path(args.checkpoint, launch_dir)
    apply_checkpoint = explicit_checkpoint or (
        base_checkpoint if bool(args.skip_bg_finetune) or bool(args.target_only_refiner) else bg_checkpoint
    )

    base_output = _resolve_user_path(args.base_output, launch_dir) if args.base_output else stage01_dir / "apply"
    base_post_output = _resolve_user_path(args.base_post_output, launch_dir) if args.base_post_output else stage01_dir / "postprocess" / "renders"
    bg_output = _resolve_user_path(args.bg_output, launch_dir) if args.bg_output else stage02_dir / "apply"
    bg_post_output = _resolve_user_path(args.bg_post_output, launch_dir) if args.bg_post_output else stage02_dir / "postprocess" / "renders"
    apply_output = _resolve_user_path(args.apply_output, launch_dir) if args.apply_output else stage03_dir / "apply"
    if args.final_render_dir:
        final_render_dir = _resolve_user_path(args.final_render_dir, launch_dir)
    elif bool(args.final_postprocess):
        final_render_dir = stage03_dir / "postprocess" / "renders"
    else:
        final_render_dir = apply_output / "renders"
    eval_output = _resolve_user_path(args.eval_output, launch_dir) if args.eval_output else stage04_dir / "novel_metrics"
    delta_output = stage04_dir / "refiner_delta"
    result_root = _resolve_user_path(args.result_dir, launch_dir) if args.result_dir else model_path / "result"
    refiner_mode = str(args.refiner_mode)
    executed_commands: list[dict] = []
    eval_skipped_reason: str | None = None
    eval_ran = False

    output_paths = {
        "base_checkpoint": base_checkpoint,
        "base_apply": base_output,
        "base_post": base_post_output,
        "background_checkpoint": bg_checkpoint,
        "background_apply": bg_output,
        "background_post": bg_post_output,
        "apply_checkpoint": apply_checkpoint,
        "final_apply": apply_output,
        "final_renders": final_render_dir,
        "eval": eval_output,
        "refiner_delta": delta_output,
        "result_root": result_root,
        "target_mask_dir": target_mask_dir,
        "train_target_dir": train_target_dir,
        "train_gt_dir": train_gt_dir,
        "gt_dir": gt_dir,
    }

    if args.stage in {"full_train", "train_base"}:
        cmd = [
            args.python,
            refiner_script,
            "-m",
            str(model_path),
            "--refiner_mode",
            refiner_mode,
        ]
        if train_target_dir is not None:
            cmd += ["--train_target_dir", str(train_target_dir)]
        if train_gt_dir is not None:
            cmd += ["--train_gt_dir", str(train_gt_dir)]
        cmd += [
            "--checkpoint",
            str(base_checkpoint),
            "--output_dir",
            str(base_output),
            "--postprocess_output_dir",
            str(base_post_output),
            "--iterations",
            str(args.base_iterations),
            "--batch_size",
            str(args.batch_size),
            "--lr",
            str(args.base_lr),
            "--train_azimuth_step",
            str(args.train_azimuth_step),
            "--conv_padding_mode",
            "reflect",
            "--deterministic_train_noise",
            "--target_ring_width",
            str(args.target_ring_width),
            "--target_ring_inner_dilate",
            str(args.target_ring_inner_dilate),
            "--target_ring_l1_weight",
            str(args.target_ring_l1_weight),
            "--target_ring_texture_loss_weight",
            str(args.target_ring_texture_loss_weight),
            "--target_ring_gradient_loss_weight",
            str(args.target_ring_gradient_loss_weight),
            "--target_ring_quantile_loss_weight",
            str(args.target_ring_quantile_loss_weight),
            "--target_ring_patchgan_weight",
            str(args.target_ring_patchgan_weight),
            "--target_shadow_width",
            str(args.target_shadow_width),
            "--target_shadow_l1_weight",
            str(args.target_shadow_l1_weight),
            "--target_shadow_linear_l1_weight",
            str(args.target_shadow_linear_l1_weight),
            "--target_shadow_extinction_weight",
            str(args.target_shadow_extinction_weight),
            "--target_shadow_texture_loss_weight",
            str(args.target_shadow_texture_loss_weight),
            "--target_shadow_gradient_loss_weight",
            str(args.target_shadow_gradient_loss_weight),
            "--loss_mask_dilate",
            str(args.loss_mask_dilate),
            "--bright_loss_weight",
            str(args.bright_loss_weight),
            "--bright_loss_gain",
            str(args.bright_loss_gain),
            "--texture_loss_weight",
            str(args.texture_loss_weight),
            "--gradient_loss_weight",
            str(args.gradient_loss_weight),
            "--target_ssim_loss_weight",
            str(args.target_ssim_loss_weight),
            "--target_mse_weight",
            str(args.target_mse_weight),
            "--azimuth_consistency_weight",
            str(args.azimuth_consistency_weight),
            "--azimuth_consistency_max_gap",
            str(args.azimuth_consistency_max_gap),
            "--azimuth_consistency_samples",
            str(args.azimuth_consistency_samples),
            "--azimuth_consistency_texture_weight",
            str(args.azimuth_consistency_texture_weight),
            "--background_patchgan_weight",
            str(args.background_patchgan_weight),
            "--patchgan_lr",
            str(args.patchgan_lr),
            "--patchgan_base",
            str(args.patchgan_base),
        ]
        if bool(args.save_training_masks):
            cmd = _append_if_supported(cmd, refiner_supported, "--save_training_masks")
        cmd = _add_training_runtime_flags(cmd, args, refiner_supported)
        cmd = _add_target_layover_training_flags(cmd, args, refiner_supported)
        if bool(args.target_only_refiner):
            cmd = _append_if_supported(cmd, refiner_supported, "--target_only_refiner")
        if bool(args.train_use_all_targets):
            cmd = _append_if_supported(cmd, refiner_supported, "--train_use_all_targets")
        if bool(args.train_azimuth_unique):
            cmd += ["--train_azimuth_unique"]
        if not bool(args.keep_intermediate_apply):
            cmd += ["--train_only"]
        executed_commands.append({"stage": "train_base", "command": _format_cmd(cmd), "cwd": str(repo_root)})
        _run(cmd, repo_root, dry_run=args.dry_run)

    if args.stage in {"full_train", "finetune_bg"} and not bool(args.skip_bg_finetune) and not bool(args.target_only_refiner):
        cmd = [
            args.python,
            refiner_script,
            "-m",
            str(model_path),
            "--refiner_mode",
            "image",
        ]
        if train_target_dir is not None:
            cmd += ["--train_target_dir", str(train_target_dir)]
        if train_gt_dir is not None:
            cmd += ["--train_gt_dir", str(train_gt_dir)]
        cmd += [
            "--init_checkpoint",
            str(base_checkpoint),
            "--checkpoint",
            str(bg_checkpoint),
            "--output_dir",
            str(bg_output),
            "--postprocess_output_dir",
            str(bg_post_output),
            "--background_finetune",
            "--iterations",
            str(args.bg_iterations),
            "--batch_size",
            str(args.batch_size),
            "--lr",
            str(args.bg_lr),
            "--train_azimuth_step",
            str(args.train_azimuth_step),
            "--conv_padding_mode",
            "reflect",
            "--deterministic_train_noise",
            "--target_ring_width",
            str(args.target_ring_width),
            "--target_ring_inner_dilate",
            str(args.target_ring_inner_dilate),
            "--target_ring_l1_weight",
            str(args.target_ring_l1_weight),
            "--target_ring_texture_loss_weight",
            str(args.target_ring_texture_loss_weight),
            "--target_ring_gradient_loss_weight",
            str(args.target_ring_gradient_loss_weight),
            "--target_ring_quantile_loss_weight",
            str(args.target_ring_quantile_loss_weight),
            "--target_ring_patchgan_weight",
            str(args.target_ring_patchgan_weight),
            "--target_shadow_width",
            str(args.target_shadow_width),
            "--target_shadow_l1_weight",
            str(args.target_shadow_l1_weight),
            "--target_shadow_linear_l1_weight",
            str(args.target_shadow_linear_l1_weight),
            "--target_shadow_extinction_weight",
            str(args.target_shadow_extinction_weight),
            "--target_shadow_texture_loss_weight",
            str(args.target_shadow_texture_loss_weight),
            "--target_shadow_gradient_loss_weight",
            str(args.target_shadow_gradient_loss_weight),
            "--loss_mask_dilate",
            str(args.loss_mask_dilate),
            "--bright_loss_weight",
            str(args.bright_loss_weight),
            "--bright_loss_gain",
            str(args.bright_loss_gain),
            "--texture_loss_weight",
            str(args.texture_loss_weight),
            "--gradient_loss_weight",
            str(args.gradient_loss_weight),
            "--target_ssim_loss_weight",
            str(args.target_ssim_loss_weight),
            "--target_mse_weight",
            str(args.target_mse_weight),
            "--azimuth_consistency_weight",
            str(args.azimuth_consistency_weight),
            "--azimuth_consistency_max_gap",
            str(args.azimuth_consistency_max_gap),
            "--azimuth_consistency_samples",
            str(args.azimuth_consistency_samples),
            "--azimuth_consistency_texture_weight",
            str(args.azimuth_consistency_texture_weight),
            "--background_patchgan_weight",
            str(args.background_patchgan_weight),
            "--patchgan_lr",
            str(args.patchgan_lr),
            "--patchgan_base",
            str(args.patchgan_base),
        ]
        cmd = _add_training_runtime_flags(cmd, args, refiner_supported)
        cmd = _add_target_layover_training_flags(cmd, args, refiner_supported)
        if bool(args.target_only_refiner):
            cmd = _append_if_supported(cmd, refiner_supported, "--target_only_refiner")
        if bool(args.train_use_all_targets):
            cmd = _append_if_supported(cmd, refiner_supported, "--train_use_all_targets")
        if bool(args.train_azimuth_unique):
            cmd += ["--train_azimuth_unique"]
        if not bool(args.keep_intermediate_apply):
            cmd += ["--train_only"]
        executed_commands.append({"stage": "finetune_bg", "command": _format_cmd(cmd), "cwd": str(repo_root)})
        _run(cmd, repo_root, dry_run=args.dry_run)
    elif args.stage in {"full_train", "finetune_bg"}:
        reason = "target-only refiner has no background stage" if bool(args.target_only_refiner) else "using base checkpoint for apply"
        print(f"\n[bg finetune] skipped: {reason}.")

    if args.stage in {"full_train", "apply", "apply_eval"}:
        cmd = [
            args.python,
            refiner_script,
            "-m",
            str(model_path),
            "--apply_only",
            "--checkpoint",
            str(apply_checkpoint),
            "--output_dir",
            str(apply_output),
            "--postprocess_output_dir",
            str(final_render_dir),
        ]
        if train_gt_dir is not None:
            cmd += [
                "--train_gt_dir",
                str(train_gt_dir),
                "--background_reference_dir",
                str(train_gt_dir),
            ]
        cmd = _add_common_apply_defaults(cmd, args, refiner_supported)
        if not bool(args.final_postprocess):
            cmd += ["--no-postprocess_after_apply"]
        else:
            cmd = _add_refiner_postprocess_defaults(cmd, args, refiner_supported)
        executed_commands.append({"stage": "apply", "command": _format_cmd(cmd), "cwd": str(repo_root)})
        _run(cmd, repo_root, dry_run=args.dry_run)

    if args.stage == "postprocess":
        cmd = [
            args.python,
            postprocess_script,
            "--render_dir",
            str(apply_output / "renders"),
            "--output_dir",
            str(final_render_dir),
            "--target_mask_dir",
            str(target_mask_dir),
            "--target_source_dir",
            str(apply_output / "target_modulated_renders"),
            "--shadow_source_dir",
            str(apply_output / "target_modulated_renders"),
        ]
        cmd = _add_postprocess_defaults(cmd, args)
        executed_commands.append({"stage": "postprocess", "command": _format_cmd(cmd), "cwd": str(repo_root)})
        _run(cmd, repo_root, dry_run=args.dry_run)

    if args.stage in {"full_train", "eval", "apply_eval"}:
        if gt_dir is None:
            print("\n[eval] skipped: pass --gt_dir to compute PSNR/SSIM/SAR metrics.")
            eval_skipped_reason = "missing --gt_dir"
        else:
            cmd = [
                args.python,
                eval_script,
                "--render_dir",
                str(final_render_dir),
                "--gt_dir",
                str(gt_dir),
                "--output_dir",
                str(eval_output),
                "--device",
                args.device,
                "--sar_metrics",
                "--target_only",
                "--target_mask_dir",
                str(target_mask_dir),
                "--target_mask_threshold",
                "0.08",
                "--target_mask_quantile",
                "0.35",
                "--target_mask_dilate",
                "0",
                "--sar_metric_log_scale",
                "20",
                "--sar_metric_smooth_radius",
                "0",
                "--sar_tolerant_radius",
                "1",
                "--visual_diagnosis",
                "--azimuth_match_tolerance",
                "0",
            ]
            if args.view_split_train_angle_step:
                cmd += ["--view_split_train_angle_step", str(args.view_split_train_angle_step)]
            if args.view_split_train_angles:
                cmd += ["--view_split_train_angles", args.view_split_train_angles]
            if view_split_train_dir:
                cmd += ["--view_split_train_dir", str(view_split_train_dir)]
            executed_commands.append({"stage": "eval", "command": _format_cmd(cmd), "cwd": str(repo_root)})
            _run(cmd, repo_root, dry_run=args.dry_run)
            eval_ran = not bool(args.dry_run)

            cmd = [
                args.python,
                delta_eval_script,
                "--source_target_dir",
                str(model_path / "novel_target_only" / "target_renders"),
                "--refiner_target_dir",
                str(apply_output / "target_modulated_renders"),
                "--final_render_dir",
                str(final_render_dir),
                "--gt_dir",
                str(gt_dir),
                "--output_dir",
                str(delta_output),
                "--target_mask_dir",
                str(target_mask_dir),
                "--target_mask_threshold",
                "0.08",
                "--target_mask_quantile",
                "0.35",
                "--target_mask_dilate",
                "0",
                "--log_scale",
                "20",
                "--delta_threshold",
                "0.025",
                "--save_panels",
            ]
            executed_commands.append({"stage": "refiner_delta", "command": _format_cmd(cmd), "cwd": str(repo_root)})
            _run(cmd, repo_root, dry_run=args.dry_run)

    if eval_skipped_reason:
        output_paths["eval_skipped_reason"] = eval_skipped_reason

    result_run_dir = None
    if bool(args.record_results):
        result_run_dir = _write_run_archive(
            args,
            model_path=model_path,
            work_dir=work_dir,
            result_root=result_root,
            eval_output=eval_output,
            delta_output=delta_output,
            eval_ran=eval_ran,
            output_paths=output_paths,
            executed_commands=executed_commands,
            dry_run=args.dry_run,
        )
        print(f"\n[result archive] {result_run_dir}")

    print("\n[pipeline outputs]")
    print(f"  base checkpoint : {base_checkpoint}")
    print(f"  base apply      : {base_output}")
    print(f"  base post       : {base_post_output}")
    print(f"  bg checkpoint   : {bg_checkpoint}")
    print(f"  bg apply        : {bg_output}")
    print(f"  bg post         : {bg_post_output}")
    print(f"  final apply     : {apply_output}")
    print(f"  final renders   : {final_render_dir}")
    print(f"  eval            : {eval_output}")
    if result_run_dir is not None:
        print(f"  result archive  : {result_run_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
