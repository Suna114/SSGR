"""Stress-test SDGR CUDA forward/backward (scatter + shadow pass)."""
import os
import sys
import torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from sar.rasterizer import alpha_blend_sar, sar_cuda_rasterization_enabled


def run_pass(n: int, H: int, W: int, far_first: bool, tag: str) -> None:
    device = "cuda"
    means2D = torch.randn(n, 2, device=device) * 40 + 64
    means2D.requires_grad_(True)
    a = torch.rand(n, device=device) * 0.5 + 0.1
    b = torch.randn(n, device=device) * 0.01
    cov2d = torch.zeros(n, 2, 2, device=device)
    cov2d[:, 0, 0] = a
    cov2d[:, 0, 1] = b
    cov2d[:, 1, 0] = b
    cov2d[:, 1, 1] = a
    opacities = torch.sigmoid(torch.randn(n, 1, device=device))
    colors = torch.rand(n, 3, device=device)
    depths = torch.rand(n, device=device) * 100 + 1.0
    bg = torch.zeros(3, device=device)
    out = alpha_blend_sar(
        means2D, cov2d, opacities, colors, depths, bg, H, W,
        prefer_cuda=True, far_first=far_first, return_depth=not far_first,
    )
    if isinstance(out, tuple):
        img = out[0]
    else:
        img = out
    loss = img.sum()
    loss.backward()
    torch.cuda.synchronize()
    print(f"  [{tag}] ok  loss={loss.item():.4f}  cuda={sar_cuda_rasterization_enabled()}")


def main():
    os.environ.pop("SAR_SDGR_FORCE_PYTHON", None)
    print("CUDA enabled:", sar_cuda_rasterization_enabled())
    n, H, W = 327, 128, 128
    for it in range(120):
        run_pass(n, H, W, far_first=True, tag=f"iter{it} scatter")
        run_pass(n, H, W, far_first=False, tag=f"iter{it} shadow")
    print("All 120 iters OK")


if __name__ == "__main__":
    main()
