#!/usr/bin/env python3
"""Learn an azimuth-conditioned SAR shadow opacity layer.

This module is intentionally separate from the target refiner.  It predicts a
single shadow opacity map outside the target mask, constrained by an
azimuth-derived candidate region.  The predicted opacity is applied after the
target/background render, so target bright scatterers are not part of this
model's job.
"""

from __future__ import annotations

import argparse
import csv
import math
import re
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from tqdm import tqdm

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from scripts.rendering.learn_sar_image_refiner import (  # noqa: E402
    _blur01,
    _dilate01_batch,
    _image_files,
    _load_image,
    _parse_azimuth,
    _resize_chw,
)


def _chw1(mask: torch.Tensor) -> torch.Tensor:
    if mask.dim() == 2:
        return mask[None]
    if mask.dim() == 3:
        return mask[:1]
    raise ValueError(f"Expected 2D/3D mask, got shape {tuple(mask.shape)}")


def _region_classification_rgb(target_mask: torch.Tensor, shadow_mask: torch.Tensor | None = None) -> tuple[torch.Tensor, torch.Tensor]:
    """Return SFM-like RGB classes: R=target, B=shadow, K=background."""
    target = (_chw1(target_mask).float().clamp(0.0, 1.0) > 0.5).float()
    if shadow_mask is None:
        shadow = torch.zeros_like(target)
    else:
        shadow = _chw1(shadow_mask).float().clamp(0.0, 1.0) * (1.0 - target)
    background = (1.0 - torch.maximum(target, (shadow > 0.05).float())).clamp(0.0, 1.0)
    rgb = torch.cat([target, torch.zeros_like(target), shadow], dim=0).clamp(0.0, 1.0)
    return rgb, background


class ConvBlock(nn.Module):
    def __init__(self, cin: int, cout: int, padding_mode: str = "reflect"):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(cin, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
            nn.Conv2d(cout, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class AzimuthShadowUNet(nn.Module):
    def __init__(self, in_ch: int = 10, base: int = 32, padding_mode: str = "reflect"):
        super().__init__()
        self.e1 = ConvBlock(in_ch, base, padding_mode)
        self.e2 = ConvBlock(base, base * 2, padding_mode)
        self.e3 = ConvBlock(base * 2, base * 4, padding_mode)
        self.mid = ConvBlock(base * 4, base * 4, padding_mode)
        self.d2 = ConvBlock(base * 6, base * 2, padding_mode)
        self.d1 = ConvBlock(base * 3, base, padding_mode)
        self.out = nn.Conv2d(base, 1, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e1 = self.e1(x)
        e2 = self.e2(F.avg_pool2d(e1, 2))
        e3 = self.e3(F.avg_pool2d(e2, 2))
        y = self.mid(e3)
        y = F.interpolate(y, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d2(torch.cat([y, e2], dim=1))
        y = F.interpolate(y, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d1(torch.cat([y, e1], dim=1))
        return self.out(y)


def _configure_torch(args, device: torch.device) -> None:
    if device.type != "cuda":
        return
    allow_tf32 = bool(getattr(args, "allow_tf32", True))
    if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
        torch.backends.cuda.matmul.allow_tf32 = allow_tf32
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.allow_tf32 = allow_tf32
        torch.backends.cudnn.benchmark = bool(getattr(args, "cudnn_benchmark", True))
    try:
        torch.set_float32_matmul_precision("high" if allow_tf32 else "highest")
    except Exception:
        pass


def _ld(x: torch.Tensor, scale: float) -> torch.Tensor:
    return torch.log1p(x.clamp(0.0, 1.0) * scale) / math.log1p(scale)


def _angle_dist(a: float, b: float) -> float:
    d = abs(float(a) - float(b)) % 360.0
    return min(d, 360.0 - d)


def _azimuth_prefix(path: Path) -> str:
    stem = path.stem
    m = re.search(r"(?i)azimuth[_-]?(\d+(?:\.\d+)?)", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    m = re.search(r"(\d+(?:\.\d+)?)$", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    return stem


def _candidates(path: Path) -> list[dict]:
    return [{"path": p, "azimuth": _parse_azimuth(p), "prefix": _azimuth_prefix(p)} for p in _image_files(path)]


def _nearest(cands: list[dict], az: float) -> dict:
    if not cands:
        raise RuntimeError("No azimuth candidates")
    return min(cands, key=lambda c: (_angle_dist(float(c["azimuth"]), az), c["path"].name))


def _bracket(cands: list[dict], az: float) -> tuple[dict, dict, float, float]:
    ordered = sorted(cands, key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    if not ordered:
        raise RuntimeError("No GT candidates")
    if len(ordered) == 1:
        return ordered[0], ordered[0], 1.0, 0.0
    target = float(az) % 360.0
    exact = [c for c in ordered if _angle_dist(float(c["azimuth"]), target) <= 1e-6]
    if exact:
        return exact[0], exact[0], 1.0, 0.0
    back = [((target - float(c["azimuth"])) % 360.0, c) for c in ordered]
    fwd = [((float(c["azimuth"]) - target) % 360.0, c) for c in ordered]
    prev_gap, prev = min((x for x in back if x[0] > 1e-6), key=lambda x: (x[0], x[1]["path"].name))
    next_gap, nxt = min((x for x in fwd if x[0] > 1e-6), key=lambda x: (x[0], x[1]["path"].name))
    total = max(prev_gap + next_gap, 1e-6)
    return prev, nxt, next_gap / total, prev_gap / total


def _select_pairs(target_dir: Path, gt_dir: Path, args) -> list[dict]:
    targets = sorted(_candidates(target_dir), key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    gts = _candidates(gt_dir)
    if not targets or not gts:
        raise RuntimeError(f"No training images found: {target_dir} vs {gt_dir}")
    gt_by_prefix: dict[str, list[dict]] = {}
    for g in gts:
        gt_by_prefix.setdefault(g["prefix"], []).append(g)
    if not bool(getattr(args, "train_use_all_targets", False)):
        step = max(float(getattr(args, "train_azimuth_step", 10.0) or 10.0), 1e-6)
        slots = {round((i * step) % 360.0, 6) for i in range(int(math.ceil(360.0 / step)))}
        targets = [_nearest(targets, s) for s in sorted(slots)]
    out = []
    for t in targets:
        az = float(t["azimuth"]) % 360.0
        pool = gt_by_prefix.get(t["prefix"], gts)
        lo, hi, wlo, whi = _bracket(pool, az)
        out.append({"target": t["path"], "azimuth": az, "lo": lo, "hi": hi, "wlo": wlo, "whi": whi})
    return out


def _write_train_pair_report(pairs: list[dict], output_dir: Path) -> None:
    path = output_dir / "shadow_train_azimuth_pairs.txt"
    lines = ["target\tazimuth\tgt_lo\tlo_az\tlo_w\tgt_hi\thi_az\thi_w"]
    for p in pairs:
        lo = p["lo"]
        hi = p["hi"]
        lines.append(
            f"{Path(p['target']).name}\t{float(p['azimuth']):.3f}\t"
            f"{Path(lo['path']).name}\t{float(lo['azimuth']):.3f}\t{float(p['wlo']):.6f}\t"
            f"{Path(hi['path']).name}\t{float(hi['azimuth']):.3f}\t{float(p['whi']):.6f}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[azimuth shadow] train azimuth report: {path}")


def _mix_gt(gt_lo: torch.Tensor, gt_hi: torch.Tensor, wlo: float, whi: float, scale: float) -> torch.Tensor:
    lo = _ld(gt_lo, scale)
    hi = _ld(gt_hi, scale)
    mixed = lo * float(wlo) + hi * float(whi)
    return (torch.expm1(mixed.clamp(0.0, 1.0) * math.log1p(scale)) / scale).clamp(0.0, 1.0)


def _target_mask(target: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    threshold = float(getattr(args, "target_mask_threshold", 0.08) or 0.08)
    quantile = float(getattr(args, "target_mask_quantile", 0.35) or 0.35)
    vals = gray[gray > 0]
    q = torch.quantile(vals, quantile) if int(vals.numel()) > 0 else gray.new_tensor(0.0)
    mask = (gray >= max(threshold, float(q.item()))).float()
    if float(mask.sum()) < float(getattr(args, "target_mask_min_pixels", 16.0) or 16.0) and int(vals.numel()) > 0:
        mask = (gray >= torch.quantile(vals, 0.15)).float()
    dilate = int(getattr(args, "target_mask_dilate", 0) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    return mask.clamp(0.0, 1.0)


def _gt_anchor_mask(gt: torch.Tensor, fallback_mask: torch.Tensor, args) -> torch.Tensor:
    """Extract a real-GT bright target/layover anchor for shadow supervision."""
    gray = gt.mean(dim=0).clamp(0.0, 1.0)
    fallback_bool = (fallback_mask.float().clamp(0.0, 1.0) > 0.5).float()
    valid = fallback_bool > 0.5
    vals = gray[valid & (gray > 0)]
    quantile = min(max(float(getattr(args, "shadow_gt_anchor_quantile", 0.95) or 0.95), 0.0), 1.0)
    threshold = max(float(getattr(args, "shadow_gt_anchor_threshold", 0.12) or 0.12), 0.0)
    q = torch.quantile(vals, quantile) if int(vals.numel()) > 0 else gray.new_tensor(0.0)
    anchor = ((gray >= max(threshold, float(q.item()))) & valid).float()
    min_pixels = float(getattr(args, "shadow_gt_anchor_min_pixels", 12.0) or 12.0)
    if float(anchor.sum()) < min_pixels and int(vals.numel()) > 0:
        loose_q = min(max(float(getattr(args, "shadow_gt_anchor_fallback_quantile", 0.90) or 0.90), 0.0), 1.0)
        anchor = ((gray >= max(threshold * 0.5, float(torch.quantile(vals, loose_q).item()))) & valid).float()
    anchor = (anchor > 0.05).float()
    dilate = max(int(getattr(args, "shadow_gt_anchor_dilate", 2) or 0), 0)
    if dilate > 0:
        anchor = _dilate01_batch(anchor[None], dilate)[0] * fallback_bool
    return anchor.clamp(0.0, 1.0)


def _direction_maps(mask: torch.Tensor, azimuth_deg: float, args) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    length = max(int(getattr(args, "shadow_candidate_length", 48) or 48), 1)
    decay = max(float(getattr(args, "shadow_candidate_decay", 22.0) or 22.0), 1e-6)
    lateral_blur = max(int(getattr(args, "shadow_candidate_lateral_blur", 5) or 0), 0)
    offset = float(getattr(args, "shadow_direction_offset_deg", 180.0) or 0.0)
    sign = float(getattr(args, "shadow_direction_sign", 1.0) or 1.0)
    rad = math.radians((float(azimuth_deg) + offset) % 360.0)
    dx = int(round(math.cos(rad) * sign))
    dy = int(round(math.sin(rad) * sign))
    if dx == 0 and dy == 0:
        dx = 1
    hmask = mask.float().clamp(0.0, 1.0)
    protect = int(getattr(args, "shadow_target_protect_dilate", 1) or 0)
    block = _dilate01_batch(hmask[None], protect)[0] if protect > 0 else hmask
    accum = torch.zeros_like(hmask)
    dist = torch.zeros_like(hmask)
    weight = torch.zeros_like(hmask)
    for step in range(1, length + 1):
        shifted = torch.roll(hmask, shifts=(dy * step, dx * step), dims=(-2, -1))
        if dy > 0:
            shifted[: dy * step, :] = 0
        elif dy < 0:
            shifted[dy * step :, :] = 0
        if dx > 0:
            shifted[:, : dx * step] = 0
        elif dx < 0:
            shifted[:, dx * step :] = 0
        w = math.exp(-float(step) / decay)
        candidate_step = shifted * w
        better = candidate_step > accum
        accum = torch.maximum(accum, candidate_step)
        dist = torch.where(better, dist.new_tensor(float(step) / float(length)), dist)
        weight = torch.maximum(weight, shifted)
    if lateral_blur > 0:
        accum = _blur01(accum, lateral_blur)
        weight = _blur01(weight, lateral_blur)
    candidate = (accum * (1.0 - block)).clamp(0.0, 1.0)
    distance = (dist * (candidate > 0).float()).clamp(0.0, 1.0)
    support = (weight * (1.0 - block)).clamp(0.0, 1.0)
    return candidate, distance, support


def _fixed_shadow_direction_deg(azimuth_deg: float, args) -> float:
    fixed = getattr(args, "shadow_fixed_direction_deg", None)
    if fixed is None:
        fixed = getattr(args, "_shadow_global_direction_deg", None)
    if fixed is None:
        fixed = float(azimuth_deg) + float(getattr(args, "shadow_direction_offset_deg", 180.0) or 0.0)
    return float(fixed) % 360.0


def _fixed_direction_maps(mask: torch.Tensor, azimuth_deg: float, args) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    fixed = _fixed_shadow_direction_deg(azimuth_deg, args)
    offset = float(getattr(args, "shadow_direction_offset_deg", 180.0) or 0.0)
    proxy_azimuth = (fixed - offset) % 360.0
    return _direction_maps(mask, proxy_azimuth, args)


def _omni_shadow_maps(mask: torch.Tensor, args) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    length = max(int(getattr(args, "shadow_candidate_length", 58) or 58), 1)
    decay = max(float(getattr(args, "shadow_candidate_decay", 24.0) or 24.0), 1e-6)
    protect = int(getattr(args, "shadow_target_protect_dilate", 1) or 0)
    hmask = mask.float().clamp(0.0, 1.0)
    block = _dilate01_batch(hmask[None], protect)[0] if protect > 0 else hmask
    frontier = block
    candidate = torch.zeros_like(hmask)
    distance = torch.zeros_like(hmask)
    support = torch.zeros_like(hmask)
    for step in range(1, length + 1):
        grown = _dilate01_batch(frontier[None], 1)[0]
        ring = (grown - frontier).clamp(0.0, 1.0)
        w = math.exp(-float(step) / decay)
        candidate = torch.maximum(candidate, ring * w)
        distance = torch.where(ring > 0.0, distance.new_tensor(float(step) / float(length)), distance)
        support = torch.maximum(support, ring)
        frontier = grown
    return candidate.clamp(0.0, 1.0), distance.clamp(0.0, 1.0), support.clamp(0.0, 1.0)


def _circular_angle_diff_deg(a: float, b: float) -> float:
    return abs((float(a) - float(b) + 180.0) % 360.0 - 180.0)


def _target_bbox_np(target: np.ndarray) -> dict | None:
    ys, xs = np.where(target)
    if ys.size == 0:
        return None
    return {
        "x_min": int(xs.min()),
        "x_max": int(xs.max()),
        "y_min": int(ys.min()),
        "y_max": int(ys.max()),
        "center_x": float(xs.mean()),
        "center_y": float(ys.mean()),
        "width": float(xs.max() - xs.min() + 1),
        "height": float(ys.max() - ys.min() + 1),
        "area": float(target.sum()),
    }


def _mask_direction_deg(mask: torch.Tensor, target_mask: torch.Tensor) -> tuple[float | None, float]:
    m = mask.detach().float().cpu().numpy() > 0.05
    t = target_mask.detach().float().cpu().numpy() > 0.5
    geom = _target_bbox_np(t)
    ys, xs = np.where(m)
    if geom is None or ys.size == 0:
        return None, 0.0
    dx = xs.astype(np.float32) - float(geom["center_x"])
    dy = ys.astype(np.float32) - float(geom["center_y"])
    direction = (math.degrees(math.atan2(float(dy.mean()), float(dx.mean()))) + 360.0) % 360.0
    return float(direction), float(ys.size)


def _weighted_circular_mean_deg(items: list[tuple[float | None, float]]) -> float | None:
    mean, _concentration, _total = _weighted_circular_stats_deg(items)
    return mean


def _weighted_circular_stats_deg(items: list[tuple[float | None, float]]) -> tuple[float | None, float, float]:
    sx = 0.0
    sy = 0.0
    total = 0.0
    for angle, weight in items:
        if angle is None or weight <= 0:
            continue
        rad = math.radians(float(angle))
        sx += math.cos(rad) * float(weight)
        sy += math.sin(rad) * float(weight)
        total += float(weight)
    if total <= 0.0:
        return None, 0.0, 0.0
    mean = (math.degrees(math.atan2(sy, sx)) + 360.0) % 360.0
    concentration = math.sqrt(sx * sx + sy * sy) / max(total, 1e-6)
    return mean, concentration, total


def _connected_shadow_component_mask(
    evidence: torch.Tensor,
    target_mask: torch.Tensor,
    search_mask: torch.Tensor,
    args,
    *,
    prefix: str = "shadow_gt",
    seed_mask: torch.Tensor | None = None,
) -> torch.Tensor:
    """Select SAR-shadow-like connected dark regions instead of a target ring."""
    if not bool(getattr(args, f"{prefix}_component_filter", True)):
        return search_mask.clamp(0.0, 1.0)
    try:
        from scipy import ndimage
    except Exception:
        return search_mask.clamp(0.0, 1.0)

    device = evidence.device
    ev = evidence.detach().float().clamp(0.0, 1.0).cpu().numpy()
    tgt = target_mask.detach().float().cpu().numpy() > 0.5
    search = search_mask.detach().float().cpu().numpy() > 0.05
    seed = None
    if seed_mask is not None:
        seed = seed_mask.detach().float().cpu().numpy() > 0.5
    geom = _target_bbox_np(tgt)
    if geom is None or not np.any(search):
        return torch.zeros_like(evidence)

    threshold = float(getattr(args, f"{prefix}_component_threshold", 0.22) or 0.22)
    threshold = min(max(threshold, 1e-4), 1.0)
    pool = ((seed if seed is not None else (ev >= threshold)) & search & ~tgt)
    density_radius = max(int(getattr(args, f"{prefix}_component_density_radius", 2) or 0), 0)
    min_density = min(max(float(getattr(args, f"{prefix}_component_min_density", 0.22) or 0.0), 0.0), 1.0)
    if seed is None and density_radius > 0 and min_density > 0.0:
        size = 2 * density_radius + 1
        density = ndimage.uniform_filter(pool.astype(np.float32), size=size, mode="constant", cval=0.0)
        pool = pool & (density >= min_density)
    open_iter = max(int(getattr(args, f"{prefix}_component_open", 0) or 0), 0)
    if seed is None and open_iter > 0:
        pool = ndimage.binary_opening(pool, structure=np.ones((3, 3), dtype=bool), iterations=open_iter)
    if not np.any(pool):
        return torch.zeros_like(evidence)

    labeled, num = ndimage.label(pool, structure=np.ones((3, 3), dtype=np.uint8))
    if num <= 0:
        return torch.zeros_like(evidence)

    target_area = max(float(geom["area"]), 1.0)
    min_ratio = max(float(getattr(args, f"{prefix}_min_component_area_ratio", 0.08) or 0.08), 0.0)
    max_ratio = max(float(getattr(args, f"{prefix}_max_component_area_ratio", 2.5) or 2.5), min_ratio + 1e-6)
    min_px = max(float(getattr(args, f"{prefix}_min_component_pixels", 8.0) or 8.0), min_ratio * target_area)
    score_min = float(getattr(args, f"{prefix}_component_score_min", 0.34) or 0.34)
    max_components = max(int(getattr(args, f"{prefix}_max_components", 1) or 1), 1)
    direction_tol = max(float(getattr(args, f"{prefix}_direction_tolerance_deg", 55.0) or 55.0), 1.0)
    global_direction = getattr(args, f"{prefix}_global_direction_deg", None)
    if global_direction is None:
        global_direction = getattr(args, "_shadow_global_direction_deg", None)
    global_direction_tol = max(
        float(getattr(args, f"{prefix}_global_direction_tolerance_deg", direction_tol) or direction_tol),
        1.0,
    )
    contact_iter = max(int(getattr(args, f"{prefix}_contact_dilate", 4) or 4), 1)
    min_bbox_density = min(max(float(getattr(args, f"{prefix}_component_min_bbox_density", 0.12) or 0.0), 0.0), 1.0)
    contact_band = ndimage.binary_dilation(tgt, structure=np.ones((3, 3), dtype=bool), iterations=contact_iter)
    dist_to_target = ndimage.distance_transform_edt(~tgt)
    tx_min, tx_max = int(geom["x_min"]), int(geom["x_max"])
    ty_min, ty_max = int(geom["y_min"]), int(geom["y_max"])
    target_w = max(float(geom["width"]), 1.0)
    target_h = max(float(geom["height"]), 1.0)

    comps: list[tuple[float, float, int, np.ndarray]] = []
    for label_id in range(1, num + 1):
        region = labeled == label_id
        area = float(region.sum())
        if area < min_px:
            continue
        area_ratio = area / target_area
        if area_ratio > max_ratio:
            continue
        ys, xs = np.where(region)
        if ys.size == 0:
            continue
        sx_min, sx_max = int(xs.min()), int(xs.max())
        sy_min, sy_max = int(ys.min()), int(ys.max())
        bbox_area = max(float((sx_max - sx_min + 1) * (sy_max - sy_min + 1)), 1.0)
        bbox_density = area / bbox_area
        if bbox_density < min_bbox_density:
            continue

        left = sx_max < tx_min
        right = sx_min > tx_max
        above = sy_max < ty_min
        below = sy_min > ty_max
        crosses_x = sx_min <= tx_min and sx_max >= tx_max
        crosses_y = sy_min <= ty_min and sy_max >= ty_max
        side_count = int(left) + int(right) + int(above) + int(below)
        if side_count >= 3 or (crosses_x and crosses_y):
            continue

        min_dist = float(dist_to_target[region].min())
        near_score = math.exp(-min_dist / max(3.0, 0.35 * max(target_w, target_h)))
        contact_score = min(1.0, float((region & contact_band).sum()) / max(3.0, 0.08 * math.sqrt(target_area)))
        overlap_x = max(0.0, float(min(sx_max, tx_max) - max(sx_min, tx_min) + 1)) / target_w
        overlap_y = max(0.0, float(min(sy_max, ty_max) - max(sy_min, ty_min) + 1)) / target_h
        axis_score = min(1.0, max(overlap_x, overlap_y))
        band_margin_x = 0.35 * target_w
        band_margin_y = 0.35 * target_h
        band_x = max(0.0, float(min(sx_max, tx_max + band_margin_x) - max(sx_min, tx_min - band_margin_x) + 1))
        band_y = max(0.0, float(min(sy_max, ty_max + band_margin_y) - max(sy_min, ty_min - band_margin_y) + 1))
        band_score = max(
            min(1.0, band_x / max(float(sx_max - sx_min + 1), 1.0)),
            min(1.0, band_y / max(float(sy_max - sy_min + 1), 1.0)),
        )
        if area_ratio <= 1.0:
            area_score = min(1.0, area_ratio / max(min_ratio, 1e-6))
        else:
            area_score = max(0.0, 1.0 - (area_ratio - 1.0) / max(max_ratio - 1.0, 1e-6))
        dark_score = float(ev[region].mean())
        dx = xs.astype(np.float32) - float(geom["center_x"])
        dy = ys.astype(np.float32) - float(geom["center_y"])
        ang = np.arctan2(dy, dx)
        concentration = float(np.hypot(np.cos(ang).mean(), np.sin(ang).mean()))
        direction_deg = (math.degrees(math.atan2(float(dy.mean()), float(dx.mean()))) + 360.0) % 360.0
        direction_score = 1.0
        if global_direction is not None:
            diff = _circular_angle_diff_deg(direction_deg, float(global_direction))
            if diff > global_direction_tol:
                continue
            direction_score = max(0.0, 1.0 - diff / max(global_direction_tol, 1e-6))

        score = (
            0.24 * near_score
            + 0.22 * contact_score
            + 0.14 * axis_score
            + 0.12 * band_score
            + 0.10 * area_score
            + 0.08 * dark_score
            + 0.08 * concentration
            + 0.02 * min(1.0, bbox_density / max(min_bbox_density, 1e-6))
            + 0.08 * direction_score
        )
        if (left and right) or (above and below):
            score *= 0.35
        if concentration < 0.25 and area_ratio > 0.4:
            score *= 0.35
        if near_score < 0.18 and contact_score <= 0.0:
            score *= 0.25
        comps.append((float(score), float(direction_deg), int(area), region))

    if not comps:
        return torch.zeros_like(evidence)

    comps.sort(key=lambda x: (x[0], x[2]), reverse=True)
    selected = np.zeros_like(pool, dtype=bool)
    best_score, best_dir, _best_area, _ = comps[0]
    selected_count = 0
    for score, direction, _area, region in comps:
        if score < score_min and selected.any():
            continue
        if score < score_min * 0.75 and not selected.any():
            continue
        if selected.any() and _circular_angle_diff_deg(direction, best_dir) > direction_tol:
            continue
        selected |= region
        selected_count += 1
        if selected_count >= max_components:
            break

    if not np.any(selected):
        return torch.zeros_like(evidence)
    grow_iter = max(int(getattr(args, f"{prefix}_component_grow", 0) or 0), 0)
    if grow_iter > 0:
        grow_threshold = float(getattr(args, f"{prefix}_component_grow_threshold", threshold * 0.70) or (threshold * 0.70))
        grown = ndimage.binary_dilation(selected, structure=np.ones((3, 3), dtype=bool), iterations=grow_iter)
        selected = grown & (ev >= max(1e-4, grow_threshold)) & search & ~tgt
        labeled_sel, num_sel = ndimage.label(selected, structure=np.ones((3, 3), dtype=np.uint8))
        if num_sel > 1:
            sizes = ndimage.sum(selected, labeled_sel, index=np.arange(1, num_sel + 1))
            keep_label = int(np.argmax(sizes)) + 1
            selected = labeled_sel == keep_label
    out = torch.from_numpy(selected.astype(np.float32)).to(device=device, dtype=evidence.dtype)
    return out.clamp(0.0, 1.0)


def _shadow_gt_from_gt(gt: torch.Tensor, target_mask: torch.Tensor, candidate: torch.Tensor, args) -> torch.Tensor:
    gray = gt.mean(dim=0).clamp(0.0, 1.0)
    context_blur = int(getattr(args, "shadow_gt_context_blur", 21) or 0)
    context = _blur01(gray, context_blur).clamp_min(1e-4) if context_blur > 0 else gray.mean().clamp_min(1e-4)
    dark_threshold = max(float(getattr(args, "shadow_gt_dark_threshold", 0.18) or 0.18), 1e-6)
    ratio_threshold = max(float(getattr(args, "shadow_gt_ratio_threshold", 0.16) or 0.16), 1e-6)
    absolute = ((dark_threshold - gray) / dark_threshold).clamp(0.0, 1.0)
    relative = ((context - gray) / ratio_threshold).clamp(0.0, 1.0)
    ratio_mix = min(max(float(getattr(args, "shadow_gt_ratio_mix", 0.70) or 0.70), 0.0), 1.0)
    evidence = (absolute * (1.0 - ratio_mix) + relative * ratio_mix).clamp(0.0, 1.0)
    search_dilate = max(int(getattr(args, "shadow_search_dilate", 55) or 55), 1)
    exclude = max(int(getattr(args, "shadow_target_exclude_dilate", 1) or 0), 0)
    search = _dilate01_batch(target_mask[None], search_dilate)[0]
    block = _dilate01_batch(target_mask[None], exclude)[0] if exclude > 0 else target_mask
    search = (search * (1.0 - block)).clamp(0.0, 1.0)
    fixed_gate = None
    if bool(getattr(args, "shadow_gt_use_fixed_direction_gate", False)):
        fixed_gate = _fixed_direction_gate_mask(target_mask, args)
        search = (search * fixed_gate).clamp(0.0, 1.0)
    gate_mix = min(max(float(getattr(args, "shadow_candidate_supervision_mix", 0.85) or 0.85), 0.0), 1.0)
    gate = (candidate.clamp(0.0, 1.0) * gate_mix + search * (1.0 - gate_mix)).clamp(0.0, 1.0)
    if fixed_gate is not None:
        gate = (gate * fixed_gate).clamp(0.0, 1.0)
    low_percentile = min(max(float(getattr(args, "shadow_gt_low_percentile", 5.0) or 5.0), 0.0), 100.0)
    valid_dark = (gate > 0.05) & (target_mask <= 0.5)
    vals = gray[valid_dark]
    if int(vals.numel()) > 0:
        cut = torch.quantile(vals, low_percentile / 100.0)
        low_seed = ((gray <= cut) & valid_dark).float()
        min_seed_evidence = float(getattr(args, "shadow_gt_low_seed_min_evidence", 0.0) or 0.0)
        if min_seed_evidence > 0.0:
            low_seed = low_seed * (evidence >= min_seed_evidence).float()
    else:
        low_seed = torch.zeros_like(gray)
    pre_component_gate = gate
    component_gate = _connected_shadow_component_mask(evidence, target_mask, gate, args, prefix="shadow_gt", seed_mask=low_seed)
    if bool(getattr(args, "shadow_gt_component_filter", True)):
        # Component filtering is a cleanup step, not a license to erase all
        # supervision.  If it fails to find a component, keep the soft candidate
        # gate so the refiner does not learn an all-empty shadow target.
        gate = component_gate if float(component_gate.sum()) > 0.0 else pre_component_gate
    soft = int(getattr(args, "shadow_gt_soft_blur", 1) or 0)
    out = evidence * gate
    if bool(getattr(args, "shadow_gt_fixed_direction_fallback", False)) and float(out.sum()) <= 1e-6:
        fallback_gate = _fixed_direction_shadow_fallback(evidence, target_mask, gray, args)
        if float(fallback_gate.sum()) > 0.0:
            out = evidence * fallback_gate
            gate = fallback_gate
    if soft > 0:
        out = _blur01(out, soft) * gate
    gamma = max(float(getattr(args, "shadow_gt_gamma", 1.0) or 1.0), 0.05)
    return out.clamp(0.0, 1.0).pow(gamma)


def _fixed_direction_gate_mask(target_mask: torch.Tensor, args) -> torch.Tensor:
    direction = getattr(args, "shadow_gt_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "_shadow_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "shadow_fixed_direction_deg", None)
    if direction is None:
        return torch.ones_like(target_mask).float()

    mask = target_mask.float().clamp(0.0, 1.0)
    ys, xs = torch.where(mask > 0.5)
    if int(xs.numel()) == 0:
        return torch.ones_like(mask)

    cx = xs.float().mean()
    cy = ys.float().mean()
    h, w = mask.shape[-2:]
    yy = torch.arange(h, device=mask.device, dtype=mask.dtype)[:, None].expand(h, w)
    xx = torch.arange(w, device=mask.device, dtype=mask.dtype)[None, :].expand(h, w)
    dx = xx - cx
    dy = yy - cy
    rad = math.radians(float(direction) % 360.0)
    cos_v = math.cos(rad)
    sin_v = math.sin(rad)
    along = dx * cos_v + dy * sin_v
    perp = torch.abs(-dx * sin_v + dy * cos_v)
    dist = torch.sqrt(dx * dx + dy * dy).clamp_min(1e-6)
    angle_diff = torch.rad2deg(torch.atan2(perp, along.clamp_min(1e-6)))

    tol = max(float(getattr(args, "shadow_gt_fixed_direction_gate_tolerance_deg", 28.0) or 28.0), 1.0)
    max_dist = max(float(getattr(args, "shadow_search_dilate", 65) or 65), 1.0)
    min_dist = max(float(getattr(args, "shadow_gt_fixed_direction_gate_min_dist", 1.0) or 0.0), 0.0)
    max_width = float(getattr(args, "shadow_gt_fixed_direction_gate_max_width", 0.0) or 0.0)
    gate = (along > min_dist) & (dist <= max_dist) & (angle_diff <= tol)
    if max_width > 0.0:
        gate = gate & (perp <= max_width)
    return gate.float().clamp(0.0, 1.0)


def _fixed_direction_shadow_fallback(
    evidence: torch.Tensor,
    target_mask: torch.Tensor,
    gray: torch.Tensor,
    args,
) -> torch.Tensor:
    """Recover missed GT shadows using the dataset-level shadow side prior."""
    direction = getattr(args, "shadow_gt_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "_shadow_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "shadow_fixed_direction_deg", None)
    if direction is None:
        return torch.zeros_like(evidence)

    try:
        from scipy import ndimage
    except Exception:
        return torch.zeros_like(evidence)

    tgt = target_mask.detach().float().cpu().numpy() > 0.5
    geom = _target_bbox_np(tgt)
    if geom is None:
        return torch.zeros_like(evidence)

    h, w = tgt.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    dx = xx - float(geom["center_x"])
    dy = yy - float(geom["center_y"])
    dist = np.hypot(dx, dy)
    angles = (np.degrees(np.arctan2(dy, dx)) + 360.0) % 360.0
    diff = np.abs((angles - float(direction) + 180.0) % 360.0 - 180.0)
    tol = max(float(getattr(args, "shadow_gt_fixed_direction_fallback_tolerance_deg", 35.0) or 35.0), 1.0)
    max_dist = max(float(getattr(args, "shadow_search_dilate", 65) or 65), 1.0)
    exclude = max(int(getattr(args, "shadow_target_exclude_dilate", 1) or 0), 0)
    block = ndimage.binary_dilation(tgt, structure=np.ones((3, 3), dtype=bool), iterations=exclude) if exclude > 0 else tgt
    contact = ndimage.binary_dilation(tgt, structure=np.ones((3, 3), dtype=bool), iterations=max(int(getattr(args, "shadow_gt_contact_dilate", 4) or 4), 1))

    ev = evidence.detach().float().clamp(0.0, 1.0).cpu().numpy()
    gr = gray.detach().float().clamp(0.0, 1.0).cpu().numpy()
    band = (diff <= tol) & (dist <= max_dist) & ~block
    vals = gr[band]
    if vals.size == 0:
        return torch.zeros_like(evidence)

    low_percentile = min(max(float(getattr(args, "shadow_gt_low_percentile", 5.0) or 5.0), 0.0), 100.0)
    cut = float(np.percentile(vals, low_percentile))
    threshold = min(max(float(getattr(args, "shadow_gt_fixed_direction_fallback_threshold", 0.10) or 0.10), 1e-4), 1.0)
    pool = band & ((gr <= cut) | (ev >= threshold))
    if not np.any(pool):
        return torch.zeros_like(evidence)

    labeled, num = ndimage.label(pool, structure=np.ones((3, 3), dtype=np.uint8))
    if num <= 0:
        return torch.zeros_like(evidence)

    min_px = max(float(getattr(args, "shadow_gt_min_component_pixels", 8.0) or 8.0), 1.0)
    max_components = max(int(getattr(args, "shadow_gt_fixed_direction_fallback_components", 1) or 1), 1)
    comps: list[tuple[float, int, np.ndarray]] = []
    for label_id in range(1, num + 1):
        region = labeled == label_id
        area = int(region.sum())
        if area < min_px:
            continue
        near = float((region & contact).sum()) / max(float(area), 1.0)
        score = float(ev[region].mean()) + 0.5 * near + min(area / max(float(geom["area"]), 1.0), 1.0) * 0.15
        comps.append((score, area, region))
    if not comps:
        return torch.zeros_like(evidence)

    comps.sort(key=lambda x: (x[0], x[1]), reverse=True)
    selected = np.zeros_like(pool, dtype=bool)
    for _, _, region in comps[:max_components]:
        selected |= region
    grow = max(int(getattr(args, "shadow_gt_fixed_direction_fallback_grow", 1) or 0), 0)
    if grow > 0:
        grown = ndimage.binary_dilation(selected, structure=np.ones((3, 3), dtype=bool), iterations=grow)
        selected = grown & band & ~block & (ev >= max(1e-4, threshold * 0.5))
    return torch.from_numpy(selected.astype(np.float32)).to(device=evidence.device, dtype=evidence.dtype).clamp(0.0, 1.0)


def _input_tensor(
    target: torch.Tensor,
    mask: torch.Tensor,
    azimuth: float,
    args,
    in_ch: int = 10,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    directional, direction_distance, direction_support = _direction_maps(mask, azimuth, args)
    fixed_directional, fixed_distance, fixed_support = _fixed_direction_maps(mask, azimuth, args)
    mode = str(getattr(args, "shadow_candidate_mode", "directional_prior") or "directional_prior").lower().strip()
    if mode == "directional":
        candidate, distance, support = directional, direction_distance, direction_support
        direction_prior = directional
    elif mode == "fixed_direction":
        candidate, distance, support = fixed_directional, fixed_distance, fixed_support
        direction_prior = fixed_directional
    elif mode == "fixed_direction_prior":
        candidate, distance, support = _omni_shadow_maps(mask, args)
        direction_prior = fixed_directional
    else:
        candidate, distance, support = _omni_shadow_maps(mask, args)
        direction_prior = directional
    gray = target.mean(dim=0, keepdim=True).clamp(0.0, 1.0)
    log_gray = _ld(gray, float(getattr(args, "log_scale", 20.0) or 20.0))
    rad = math.radians(float(azimuth) % 360.0)
    sin_map = torch.full_like(gray, math.sin(rad))
    cos_map = torch.full_like(gray, math.cos(rad))
    inv_dist = (1.0 - distance).clamp(0.0, 1.0)[None]
    if int(in_ch) <= 9:
        x = torch.cat([log_gray, gray, mask[None], candidate[None], distance[None], inv_dist, support[None], sin_map, cos_map], dim=0)
    else:
        x = torch.cat(
            [log_gray, gray, mask[None], candidate[None], distance[None], inv_dist, direction_prior[None], support[None], sin_map, cos_map],
            dim=0,
        )
    maps = {
        "candidate": candidate,
        "distance": distance,
        "support": support,
        "direction_prior": direction_prior,
    }
    return x, maps


def _dice_loss(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    p = (pred * mask).reshape(pred.shape[0], -1)
    t = (target * mask).reshape(target.shape[0], -1)
    inter = (p * t).sum(dim=1)
    den = p.sum(dim=1) + t.sum(dim=1)
    return (1.0 - (2.0 * inter + 1e-6) / (den + 1e-6)).mean()


def _masked_l1(a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    return ((a - b).abs() * mask).sum() / mask.sum().clamp_min(1.0)


def _apply_shadow(image: torch.Tensor, opacity: torch.Tensor, args) -> torch.Tensor:
    strength = min(max(float(getattr(args, "shadow_apply_strength", 0.95) or 0.95), 0.0), 1.0)
    max_darken = min(max(float(getattr(args, "shadow_apply_max_darken", 0.92) or 0.92), 0.0), 1.0)
    floor = min(max(float(getattr(args, "shadow_apply_floor", 0.0) or 0.0), 0.0), 1.0)
    mode = str(getattr(args, "shadow_apply_mode", "multiply") or "multiply").lower().strip()
    amount = opacity.clamp(0.0, 1.0) * strength
    amount = amount[:, None] if amount.ndim == 3 else amount[None]
    att = (1.0 - amount * max_darken).clamp(0.0, 1.0)
    attenuated = (image * att + floor * (1.0 - att)).clamp(0.0, 1.0)
    if mode == "subtract":
        subtract = min(max(float(getattr(args, "shadow_apply_subtract", 0.08) or 0.08), 0.0), 1.0)
        return torch.minimum(attenuated, image - amount * subtract).clamp(0.0, 1.0)
    if mode == "ceiling":
        ceiling = min(max(float(getattr(args, "shadow_apply_ceiling", 0.025) or 0.025), 0.0), 1.0)
        ceiling_target = torch.minimum(image, image.new_tensor(ceiling))
        ceiling_blend = (image * (1.0 - amount) + ceiling_target * amount).clamp(0.0, 1.0)
        return torch.minimum(attenuated, ceiling_blend).clamp(0.0, 1.0)
    return attenuated


def _train(args) -> None:
    device = torch.device(args.device if torch.cuda.is_available() or str(args.device) == "cpu" else "cpu")
    _configure_torch(args, device)
    pairs = _select_pairs(Path(args.train_target_dir), Path(args.train_gt_dir), args)
    if not pairs:
        raise RuntimeError("No shadow training pairs")
    in_ch = 10
    model = AzimuthShadowUNet(in_ch=in_ch, base=int(args.model_base), padding_mode=str(args.conv_padding_mode)).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
    checkpoint = Path(args.checkpoint)
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    _write_train_pair_report(pairs, out_dir)
    maps_dir = out_dir / "training_maps"
    if bool(args.save_maps):
        maps_dir.mkdir(parents=True, exist_ok=True)
    scale = float(args.log_scale)

    def _make_training_item(p: dict) -> dict[str, torch.Tensor]:
        target = _load_image(p["target"], args).to(device)
        gt_lo = _load_image(p["lo"]["path"], args).to(device)
        gt_hi = _load_image(p["hi"]["path"], args).to(device)
        gt = _mix_gt(gt_lo, gt_hi, float(p["wlo"]), float(p["whi"]), scale)
        mask = _target_mask(target, args)
        gt_anchor = _gt_anchor_mask(gt, mask, args)
        x, imaps = _input_tensor(target, mask, float(p["azimuth"]), args, in_ch=in_ch)
        y = _shadow_gt_from_gt(gt, gt_anchor, imaps["candidate"], args)
        support = torch.maximum((imaps["support"] > 0.01).float(), (y > 0.005).float())
        return {
            "x": x,
            "target": y[None],
            "target_mask": mask[None],
            "gt_anchor_mask": gt_anchor[None],
            "candidate": imaps["candidate"][None],
            "support": support[None],
            "base": target,
            "gt": gt,
        }

    cached_items: list[dict[str, torch.Tensor]] | None = None
    if bool(getattr(args, "cache_training_pairs", True)):
        cached_items = [_make_training_item(p) for p in tqdm(pairs, desc="cache shadow pairs", unit="img")]
        if bool(getattr(args, "shadow_gt_use_global_direction", True)):
            directions = [_mask_direction_deg(item["target"][0], item["gt_anchor_mask"][0]) for item in cached_items]
            global_dir, concentration, total_weight = _weighted_circular_stats_deg(directions)
            if global_dir is not None:
                setattr(args, "_shadow_global_direction_deg", float(global_dir))
                setattr(args, "shadow_gt_global_direction_deg", float(global_dir))
                setattr(args, "shadow_pred_global_direction_deg", float(global_dir))
                setattr(args, "_shadow_global_direction_concentration", float(concentration))
                min_conc = float(getattr(args, "shadow_gt_fixed_direction_min_concentration", 0.90) or 0.90)
                if bool(getattr(args, "shadow_gt_auto_fixed_direction_gate", False)):
                    use_gate = float(concentration) >= min_conc
                    setattr(args, "shadow_gt_use_fixed_direction_gate", bool(use_gate))
                print(
                    f"[azimuth shadow] estimated train-set shadow direction: {global_dir:.1f} deg, "
                    f"R={concentration:.3f}, weight={total_weight:.1f}, "
                    f"fixed_gate={bool(getattr(args, 'shadow_gt_use_fixed_direction_gate', False))}"
                )
                cached_items = [_make_training_item(p) for p in tqdm(pairs, desc="recache shadow pairs with direction", unit="img")]

    rows = []
    pbar = tqdm(range(int(args.iterations)), desc="train azimuth shadow", unit="it")
    for it in pbar:
        batch_idx = [(it * int(args.batch_size) + j) % len(pairs) for j in range(int(args.batch_size))]
        xs, targets, target_masks, gt_anchor_masks, masks, candidates, base_imgs, gt_imgs = [], [], [], [], [], [], [], []
        for idx in batch_idx:
            item = cached_items[idx] if cached_items is not None else _make_training_item(pairs[idx])
            xs.append(item["x"])
            targets.append(item["target"])
            target_masks.append(item["target_mask"])
            gt_anchor_masks.append(item["gt_anchor_mask"])
            candidates.append(item["candidate"])
            masks.append(item["support"])
            base_imgs.append(item["base"])
            gt_imgs.append(item["gt"])
        xb = torch.stack(xs, dim=0)
        yb = torch.stack(targets, dim=0)
        target_mask_b = torch.stack(target_masks, dim=0)
        gt_anchor_b = torch.stack(gt_anchor_masks, dim=0)
        cb = torch.stack(candidates, dim=0)
        support = torch.stack(masks, dim=0)
        base = torch.stack(base_imgs, dim=0)
        gt = torch.stack(gt_imgs, dim=0)
        logits = model(xb)
        pred = torch.sigmoid(logits) * cb
        loss_mask = ((support > 0.01) | (yb > 0.005)).float()
        bce = F.binary_cross_entropy(pred.clamp(1e-5, 1.0 - 1e-5), yb.clamp(0.0, 1.0), reduction="none")
        bce_weight = yb * float(args.shadow_positive_weight) + (1.0 - yb) * float(args.shadow_negative_weight)
        bce = (bce * bce_weight * loss_mask).sum() / (bce_weight * loss_mask).sum().clamp_min(1.0)
        dice = _dice_loss(pred, yb, support)
        l1 = _masked_l1(pred, yb, support)
        rendered = _apply_shadow(base, pred[:, 0], args)
        render_l1 = _masked_l1(_ld(rendered, scale), _ld(gt, scale), support)
        pred_area = (pred * support).sum(dim=(1, 2, 3)) / support.sum(dim=(1, 2, 3)).clamp_min(1.0)
        target_area = (yb * support).sum(dim=(1, 2, 3)) / support.sum(dim=(1, 2, 3)).clamp_min(1.0)
        area_loss = (pred_area - target_area).abs().mean()
        leak = _masked_l1(pred * (1.0 - cb), torch.zeros_like(pred), torch.ones_like(pred))
        loss = (
            float(args.shadow_bce_weight) * bce
            + float(args.shadow_dice_weight) * dice
            + float(args.shadow_l1_weight) * l1
            + float(args.shadow_render_l1_weight) * render_l1
            + float(args.shadow_area_weight) * area_loss
            + float(args.shadow_leak_weight) * leak
        )
        opt.zero_grad(set_to_none=True)
        loss.backward()
        if float(args.max_grad_norm) > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(args.max_grad_norm))
        opt.step()
        if it % max(int(args.progress_interval), 1) == 0 or it + 1 == int(args.iterations):
            pbar.set_postfix(loss=f"{float(loss.detach()):.4f}", dice=f"{float(dice.detach()):.4f}", r=f"{float(render_l1.detach()):.4f}")
            rows.append({
                "iteration": it + 1,
                "loss": float(loss.detach().cpu()),
                "bce": float(bce.detach().cpu()),
                "dice": float(dice.detach().cpu()),
                "opacity_l1": float(l1.detach().cpu()),
                "render_l1": float(render_l1.detach().cpu()),
                "area_l1": float(area_loss.detach().cpu()),
            })
            if bool(args.save_maps):
                stem = f"iter_{it + 1:06d}"
                torchvision.utils.save_image(pred[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_pred_shadow.png"))
                torchvision.utils.save_image(yb[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_gt_shadow.png"))
                torchvision.utils.save_image(cb[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_candidate.png"))
                torchvision.utils.save_image(rendered[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_rendered.png"))
                pred_rgb, pred_bg = _region_classification_rgb(target_mask_b[0, 0], pred[0, 0])
                gt_rgb, gt_bg = _region_classification_rgb(gt_anchor_b[0, 0], yb[0, 0])
                torchvision.utils.save_image(pred_rgb, str(maps_dir / f"{stem}_pred_region_classification.png"))
                torchvision.utils.save_image(gt_rgb, str(maps_dir / f"{stem}_gt_region_classification.png"))
                torchvision.utils.save_image(pred_bg, str(maps_dir / f"{stem}_pred_background_mask.png"))
                torchvision.utils.save_image(gt_bg, str(maps_dir / f"{stem}_gt_background_mask.png"))
                torchvision.utils.save_image(gt_anchor_b[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_gt_anchor_mask.png"))
    torch.save({"model": model.state_dict(), "args": vars(args), "in_ch": in_ch, "model_base": int(args.model_base)}, checkpoint)
    if rows:
        with (out_dir / "shadow_training_metrics.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    print(f"[azimuth shadow] checkpoint: {checkpoint}")


def _load_model(args, device: torch.device) -> AzimuthShadowUNet:
    ckpt = torch.load(args.checkpoint, map_location=device)
    ckpt_args = ckpt.get("args", {}) if isinstance(ckpt, dict) else {}
    if isinstance(ckpt_args, dict):
        for key in ("_shadow_global_direction_deg", "shadow_gt_global_direction_deg", "shadow_pred_global_direction_deg"):
            if key in ckpt_args and ckpt_args[key] is not None and getattr(args, key, None) is None:
                setattr(args, key, float(ckpt_args[key]))
    base = int(ckpt.get("model_base", getattr(args, "model_base", 32)))
    in_ch = int(ckpt.get("in_ch", 9))
    setattr(args, "_model_in_ch", in_ch)
    model = AzimuthShadowUNet(in_ch=in_ch, base=base, padding_mode=str(getattr(args, "conv_padding_mode", "reflect"))).to(device)
    model.load_state_dict(ckpt["model"], strict=True)
    model.eval()
    return model


def _apply(args) -> None:
    device = torch.device(args.device if torch.cuda.is_available() or str(args.device) == "cpu" else "cpu")
    _configure_torch(args, device)
    model = _load_model(args, device)
    render_dir = Path(args.render_dir)
    target_dir = Path(args.apply_target_dir or args.target_mask_dir or render_dir)
    output_dir = Path(args.output_dir)
    render_out = output_dir / "renders"
    maps_dir = output_dir / "maps"
    render_out.mkdir(parents=True, exist_ok=True)
    if bool(args.save_maps):
        maps_dir.mkdir(parents=True, exist_ok=True)
    targets = _candidates(target_dir)
    target_by_stem = {t["path"].stem: t for t in targets}
    target_by_az = targets
    count = 0
    for render_path in tqdm(_image_files(render_dir), desc="apply azimuth shadow", unit="img"):
        render = _load_image(render_path, args).to(device)
        az = _parse_azimuth(render_path)
        titem = target_by_stem.get(render_path.stem) or _nearest(target_by_az, az)
        target = _resize_chw(_load_image(titem["path"], args).to(device), tuple(render.shape[-2:]))
        mask = _target_mask(target, args)
        x, imaps = _input_tensor(target, mask, az, args, in_ch=int(getattr(args, "_model_in_ch", 10)))
        with torch.no_grad():
            pred = torch.sigmoid(model(x[None]))[0, 0] * imaps["candidate"]
            gain = max(float(getattr(args, "shadow_output_gain", 1.0) or 1.0), 0.0)
            if gain != 1.0:
                pred = pred * gain
            prior = min(max(float(getattr(args, "shadow_candidate_prior_strength", 0.0) or 0.0), 0.0), 1.0)
            if prior > 0.0:
                pred = torch.maximum(pred, imaps.get("direction_prior", imaps["candidate"]) * prior)
            dilate = int(getattr(args, "shadow_output_dilate", 0) or 0)
            if dilate > 0:
                pred = _dilate01_batch(pred[None], dilate)[0] * (imaps["support"] > 0.001).float()
            blur = int(getattr(args, "shadow_output_blur", 1) or 0)
            if blur > 0:
                pred = _blur01(pred, blur) * imaps["candidate"]
            gamma = max(float(getattr(args, "shadow_output_gamma", 1.0) or 1.0), 0.05)
            pred = pred.clamp(0.0, 1.0).pow(gamma)
            if bool(getattr(args, "shadow_pred_component_filter", True)):
                pred_gate = _connected_shadow_component_mask(
                    pred,
                    mask,
                    (imaps["support"] > 0.001).float(),
                    args,
                    prefix="shadow_pred",
                )
                pred = (pred * pred_gate).clamp(0.0, 1.0)
            out = _apply_shadow(render, pred, args)
        torchvision.utils.save_image(out.clamp(0.0, 1.0), str(render_out / render_path.name))
        if bool(args.save_maps):
            stem = render_path.stem
            torchvision.utils.save_image(pred[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_azimuth_shadow_opacity.png"))
            torchvision.utils.save_image(imaps["candidate"][None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_azimuth_shadow_candidate.png"))
            torchvision.utils.save_image(imaps.get("direction_prior", imaps["candidate"])[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_azimuth_shadow_direction_prior.png"))
            torchvision.utils.save_image(mask[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_mask.png"))
            torchvision.utils.save_image(render.clamp(0.0, 1.0), str(maps_dir / f"{stem}_pre_shadow_render.png"))
            cls_rgb, bg_mask = _region_classification_rgb(mask, pred)
            torchvision.utils.save_image(cls_rgb, str(maps_dir / f"{stem}_region_classification.png"))
            torchvision.utils.save_image(bg_mask, str(maps_dir / f"{stem}_background_mask.png"))
        count += 1
    print(f"[azimuth shadow] applied {count} images -> {render_out}")


def main() -> int:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("-m", "--model_path", type=str, default=None)
    parser.add_argument("--train_target_dir", type=str, default=None)
    parser.add_argument("--train_gt_dir", type=str, default=None)
    parser.add_argument("--apply_target_dir", type=str, default=None)
    parser.add_argument("--target_mask_dir", type=str, default=None)
    parser.add_argument("--render_dir", type=str, default=None)
    parser.add_argument("--output_dir", type=str, default=None)
    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--apply_only", action="store_true", default=False)
    parser.add_argument("--train_only", action="store_true", default=False)
    parser.add_argument("--iterations", type=int, default=2500)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--model_base", type=int, default=32)
    parser.add_argument("--conv_padding_mode", choices=["reflect", "replicate", "zeros"], default="reflect")
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--allow_tf32", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--cudnn_benchmark", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--progress_interval", type=int, default=50)
    parser.add_argument("--train_azimuth_step", type=float, default=10.0)
    parser.add_argument("--train_use_all_targets", action="store_true", default=False)
    parser.add_argument("--cache_training_pairs", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--log_scale", type=float, default=20.0)
    parser.add_argument("--target_mask_threshold", type=float, default=0.08)
    parser.add_argument("--target_mask_quantile", type=float, default=0.35)
    parser.add_argument("--target_mask_dilate", type=int, default=0)
    parser.add_argument("--target_mask_min_pixels", type=float, default=16.0)
    parser.add_argument("--shadow_candidate_length", type=int, default=58)
    parser.add_argument("--shadow_candidate_decay", type=float, default=24.0)
    parser.add_argument("--shadow_candidate_lateral_blur", type=int, default=5)
    parser.add_argument("--shadow_direction_offset_deg", type=float, default=180.0)
    parser.add_argument("--shadow_direction_sign", type=float, default=1.0)
    parser.add_argument("--shadow_target_protect_dilate", type=int, default=1)
    parser.add_argument("--shadow_search_dilate", type=int, default=65)
    parser.add_argument("--shadow_target_exclude_dilate", type=int, default=1)
    parser.add_argument("--shadow_gt_dark_threshold", type=float, default=0.18)
    parser.add_argument("--shadow_gt_ratio_threshold", type=float, default=0.16)
    parser.add_argument("--shadow_gt_low_percentile", type=float, default=5.0)
    parser.add_argument("--shadow_gt_use_global_direction", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--shadow_gt_global_direction_deg", type=float, default=None)
    parser.add_argument("--shadow_gt_global_direction_tolerance_deg", type=float, default=65.0)
    parser.add_argument("--shadow_gt_ratio_mix", type=float, default=0.70)
    parser.add_argument("--shadow_gt_context_blur", type=int, default=21)
    parser.add_argument("--shadow_gt_soft_blur", type=int, default=1)
    parser.add_argument("--shadow_gt_gamma", type=float, default=1.0)
    parser.add_argument("--shadow_gt_anchor_threshold", type=float, default=0.12)
    parser.add_argument("--shadow_gt_anchor_quantile", type=float, default=0.95)
    parser.add_argument("--shadow_gt_anchor_fallback_quantile", type=float, default=0.90)
    parser.add_argument("--shadow_gt_anchor_min_pixels", type=float, default=12.0)
    parser.add_argument("--shadow_gt_anchor_search_dilate", type=int, default=0)
    parser.add_argument("--shadow_gt_anchor_dilate", type=int, default=2)
    parser.add_argument("--shadow_gt_anchor_render_mask_mix", type=float, default=0.0)
    parser.add_argument("--shadow_gt_component_filter", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_gt_component_threshold", type=float, default=0.22)
    parser.add_argument("--shadow_gt_component_score_min", type=float, default=0.34)
    parser.add_argument("--shadow_gt_min_component_area_ratio", type=float, default=0.08)
    parser.add_argument("--shadow_gt_max_component_area_ratio", type=float, default=2.5)
    parser.add_argument("--shadow_gt_min_component_pixels", type=float, default=8.0)
    parser.add_argument("--shadow_gt_max_components", type=int, default=1)
    parser.add_argument("--shadow_gt_direction_tolerance_deg", type=float, default=55.0)
    parser.add_argument("--shadow_gt_contact_dilate", type=int, default=4)
    parser.add_argument("--shadow_gt_component_open", type=int, default=1)
    parser.add_argument("--shadow_gt_component_density_radius", type=int, default=2)
    parser.add_argument("--shadow_gt_component_min_density", type=float, default=0.22)
    parser.add_argument("--shadow_gt_component_min_bbox_density", type=float, default=0.12)
    parser.add_argument("--shadow_gt_component_grow", type=int, default=0)
    parser.add_argument("--shadow_gt_component_grow_threshold", type=float, default=None)
    parser.add_argument(
        "--shadow_candidate_mode",
        choices=["directional", "directional_prior", "fixed_direction", "fixed_direction_prior"],
        default="directional_prior",
    )
    parser.add_argument("--shadow_fixed_direction_deg", type=float, default=None)
    parser.add_argument("--shadow_gt_auto_fixed_direction_gate", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_gt_use_fixed_direction_gate", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_gt_fixed_direction_min_concentration", type=float, default=0.90)
    parser.add_argument("--shadow_gt_fixed_direction_gate_tolerance_deg", type=float, default=28.0)
    parser.add_argument("--shadow_gt_fixed_direction_gate_min_dist", type=float, default=1.0)
    parser.add_argument("--shadow_gt_fixed_direction_gate_max_width", type=float, default=0.0)
    parser.add_argument("--shadow_gt_low_seed_min_evidence", type=float, default=0.0)
    parser.add_argument("--shadow_gt_fixed_direction_fallback", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_gt_fixed_direction_fallback_tolerance_deg", type=float, default=35.0)
    parser.add_argument("--shadow_gt_fixed_direction_fallback_threshold", type=float, default=0.10)
    parser.add_argument("--shadow_gt_fixed_direction_fallback_components", type=int, default=1)
    parser.add_argument("--shadow_gt_fixed_direction_fallback_grow", type=int, default=1)
    parser.add_argument("--shadow_candidate_supervision_mix", type=float, default=1.0)
    parser.add_argument("--shadow_bce_weight", type=float, default=0.45)
    parser.add_argument("--shadow_dice_weight", type=float, default=0.85)
    parser.add_argument("--shadow_l1_weight", type=float, default=0.55)
    parser.add_argument("--shadow_render_l1_weight", type=float, default=0.0)
    parser.add_argument("--shadow_area_weight", type=float, default=0.35)
    parser.add_argument("--shadow_leak_weight", type=float, default=0.05)
    parser.add_argument("--shadow_positive_weight", type=float, default=4.0)
    parser.add_argument("--shadow_negative_weight", type=float, default=0.15)
    parser.add_argument("--shadow_apply_strength", type=float, default=0.95)
    parser.add_argument("--shadow_apply_max_darken", type=float, default=0.92)
    parser.add_argument("--shadow_apply_floor", type=float, default=0.0)
    parser.add_argument("--shadow_apply_mode", choices=["multiply", "subtract", "ceiling"], default="multiply")
    parser.add_argument("--shadow_apply_subtract", type=float, default=0.08)
    parser.add_argument("--shadow_apply_ceiling", type=float, default=0.025)
    parser.add_argument("--shadow_output_gain", type=float, default=1.0)
    parser.add_argument("--shadow_candidate_prior_strength", type=float, default=0.0)
    parser.add_argument("--shadow_output_dilate", type=int, default=0)
    parser.add_argument("--shadow_output_blur", type=int, default=1)
    parser.add_argument("--shadow_output_gamma", type=float, default=1.0)
    parser.add_argument("--shadow_pred_component_filter", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_pred_global_direction_deg", type=float, default=None)
    parser.add_argument("--shadow_pred_global_direction_tolerance_deg", type=float, default=65.0)
    parser.add_argument("--shadow_pred_component_threshold", type=float, default=0.08)
    parser.add_argument("--shadow_pred_component_score_min", type=float, default=0.28)
    parser.add_argument("--shadow_pred_min_component_area_ratio", type=float, default=0.06)
    parser.add_argument("--shadow_pred_max_component_area_ratio", type=float, default=2.5)
    parser.add_argument("--shadow_pred_min_component_pixels", type=float, default=8.0)
    parser.add_argument("--shadow_pred_max_components", type=int, default=1)
    parser.add_argument("--shadow_pred_direction_tolerance_deg", type=float, default=55.0)
    parser.add_argument("--shadow_pred_contact_dilate", type=int, default=4)
    parser.add_argument("--shadow_pred_component_open", type=int, default=1)
    parser.add_argument("--shadow_pred_component_density_radius", type=int, default=2)
    parser.add_argument("--shadow_pred_component_min_density", type=float, default=0.18)
    parser.add_argument("--shadow_pred_component_min_bbox_density", type=float, default=0.10)
    parser.add_argument("--shadow_pred_component_grow", type=int, default=0)
    parser.add_argument("--shadow_pred_component_grow_threshold", type=float, default=None)
    parser.add_argument("--save_maps", action=argparse.BooleanOptionalAction, default=False)
    args = parser.parse_args()

    if args.model_path:
        root = Path(args.model_path)
        args.train_target_dir = args.train_target_dir or str(root / "train_renders")
        args.train_gt_dir = args.train_gt_dir or str(root / "train_gt")
        args.apply_target_dir = args.apply_target_dir or str(root / "novel_target_only" / "target_renders")
        args.render_dir = args.render_dir or str(root / "novel_target_only" / "target_renders")
        args.output_dir = args.output_dir or str(root / "azimuth_shadow_refiner" / "apply")
        args.checkpoint = args.checkpoint or str(root / "azimuth_shadow_refiner" / "azimuth_shadow_refiner.pth")
    if not args.output_dir:
        args.output_dir = "azimuth_shadow_refiner_apply" if args.apply_only else "azimuth_shadow_refiner_train"
    if not args.checkpoint:
        args.checkpoint = str(Path(args.output_dir) / "azimuth_shadow_refiner.pth")

    if args.apply_only:
        if not args.render_dir:
            raise RuntimeError("--apply_only requires --render_dir")
        if not Path(args.checkpoint).is_file():
            raise RuntimeError(f"--apply_only requires checkpoint: {args.checkpoint}")
        _apply(args)
    else:
        if not args.train_target_dir or not args.train_gt_dir:
            raise RuntimeError("training requires --train_target_dir and --train_gt_dir")
        _train(args)
        if not args.train_only:
            _apply(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
