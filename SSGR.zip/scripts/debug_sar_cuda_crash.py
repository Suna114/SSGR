#!/usr/bin/env python3
"""复现 SAR CUDA crash（对齐 train.py 初始化 + 方位分层）。"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

import random
from random import choice, randint

import torch

from argparse import ArgumentParser
from arguments import ModelParams, OptimizationParams, PipelineParams
from scene import Scene, GaussianModel
from gaussian_renderer import render
from train import prepare_output_and_logger, ACTIVE_SAR_CONFIG
from utils.general_utils import safe_state
import train_sar_complete as tsc


def main():
    sys.argv = [
        "train_sar_complete.py",
        "-s", "data/360-1",
        "-m", "output/debug-crash",
        "--no_sar_fast_mode",
        "--sar_sdgr_cuda",
        "--iterations", "50",
    ]
    args = tsc.parse_sar_arguments()
    safe_state(False)
    lp = ModelParams(ArgumentParser())
    op = OptimizationParams(ArgumentParser())
    pp = PipelineParams(ArgumentParser())
    dataset = lp.extract(args)
    opt = op.extract(args)
    pipe = pp.extract(args)
    prepare_output_and_logger(dataset)

    gaussians = GaussianModel(dataset.sh_degree)
    scene = Scene(dataset, gaussians, shuffle=False)
    gaussians.training_setup(opt)

    from sar.sar_seed_refine_bg_shadow import maybe_seed_sar_refine_bg_shadow_at_init
    maybe_seed_sar_refine_bg_shadow_at_init(
        gaussians, opt,
        dataset_sar_mode=bool(getattr(dataset, "sar_mode", False)),
        checkpoint_was_loaded=False,
        scene=scene,
    )
    print(f"N gaussians after refine seed: {gaussians.get_xyz.shape[0]}")

    background = torch.tensor([0, 0, 0], dtype=torch.float32, device="cuda")
    train_cameras_list = scene.getTrainCameras().copy()

    # stratified azimuth bins (same as train.py)
    sar_stratify_bins = None
    if getattr(opt, "sar_stratify_azimuth", False):
        from train import _build_azimuth_strata
        nb = max(1, len(train_cameras_list))
        sar_stratify_bins, _ = _build_azimuth_strata(train_cameras_list, nb)

    viewpoint_stack = train_cameras_list.copy()
    viewpoint_indices = list(range(len(viewpoint_stack)))

    for iteration in range(1, 51):
        gaussians.update_learning_rate(iteration)
        if sar_stratify_bins is not None:
            nonempty_bins = [i for i, b in enumerate(sar_stratify_bins) if len(b) > 0]
            bi = choice(nonempty_bins)
            ci = choice(sar_stratify_bins[bi])
            viewpoint_cam = train_cameras_list[ci]
        else:
            if not viewpoint_stack:
                viewpoint_stack = train_cameras_list.copy()
                viewpoint_indices = list(range(len(viewpoint_stack)))
            ri = randint(0, len(viewpoint_indices) - 1)
            viewpoint_cam = viewpoint_stack.pop(ri)
            viewpoint_indices.pop(ri)

        use_sar_mode = (
            getattr(dataset, "sar_mode", False)
            and getattr(viewpoint_cam, "use_sar_rendering", False)
            and ACTIVE_SAR_CONFIG.get("use_sar_rendering", False)
        )

        try:
            render_pkg = render(
                viewpoint_cam, gaussians, pipe, background,
                sar_mode=use_sar_mode,
            )
            gt = viewpoint_cam.original_image.cuda()
            loss = (render_pkg["render"] - gt).abs().mean()
            loss.backward()
            gaussians.optimizer.step()
            gaussians.optimizer.zero_grad(set_to_none=True)
            torch.cuda.synchronize()
            print(f"iter {iteration} OK cam={viewpoint_cam.image_name} loss={loss.item():.4f} N={gaussians.get_xyz.shape[0]}")
        except Exception as e:
            print(f"iter {iteration} FAIL cam={viewpoint_cam.image_name}: {e}")
            from sar.cuda_preprocess import project_gaussians_sdgr_cuda
            R = torch.as_tensor(viewpoint_cam.R_world_to_radar, device="cuda", dtype=torch.float32)
            cc = torch.as_tensor(viewpoint_cam.camera_center, device="cuda", dtype=torch.float32)
            H, W = viewpoint_cam.image_height, viewpoint_cam.image_width
            out = project_gaussians_sdgr_cuda(
                gaussians.get_xyz, gaussians.get_scaling, gaussians.get_rotation,
                R, cc, W, H, 0.2031, 0.2021,
            )
            c = out["conics"]
            print(f"  conics nonfinite={(~torch.isfinite(c)).sum().item()} max={c.abs().max().item():.3e}")
            return 1

    print("All 50 OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
