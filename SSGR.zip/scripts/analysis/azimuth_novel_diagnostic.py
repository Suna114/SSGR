#!/usr/bin/env python3
"""
新视角方位质量诊断：方位–清晰度曲线、与最近训练图相似度。

用法（需已渲染 novel_views；建议先按 10° 步长渲染以节省时间）:

  # 1) 渲染 0–350° 每 10°（colmap_track）
  python scripts/rendering/render_novel_sar_views.py -m output/360-1 --iteration 30000 \\
    --same_depression_only --azimuth_start 0 --azimuth_end 360 --azimuth_step 10 \\
    --novel_pose_mode colmap_track --output_dir output/360-1/diag_colmap_track

  # 2) 同上，sar 位姿
  python scripts/rendering/render_novel_sar_views.py -m output/360-1 --iteration 30000 \\
    --same_depression_only --azimuth_start 0 --azimuth_end 360 --azimuth_step 10 \\
    --novel_pose_mode sar --output_dir output/360-1/diag_sar

  # 3) 分析
  python scripts/analysis/azimuth_novel_diagnostic.py \\
    --data data/360-1 --novel-dir output/360-1/diag_colmap_track/novel_views \\
    --out output/360-1/diag_colmap_track/analysis

  python scripts/analysis/azimuth_novel_diagnostic.py \\
    --data data/360-1 --novel-dir output/360-1/diag_sar/novel_views \\
    --out output/360-1/diag_sar/analysis
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path

import cv2
import numpy as np

_REPO = Path(__file__).resolve().parents[2]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

try:
    from sar_utils import parse_mstar_filename
except ImportError:
    parse_mstar_filename = None


def _parse_azimuth_from_name(name: str) -> float | None:
    stem = Path(name).stem
    if parse_mstar_filename is not None:
        try:
            _, _, az = parse_mstar_filename(stem + ".jpg")
            return float(az) % 360.0
        except Exception:
            pass
    m = re.search(r"-(\d{1,3})(?:\.\d+)?$", stem)
    if m:
        return float(m.group(1)) % 360.0
    m = re.search(r"azimuth[_-]?(\d+)", stem, re.I)
    if m:
        return float(m.group(1)) % 360.0
    return None


def _circular_dist(a: float, b: float) -> float:
    d = abs((a - b) % 360.0)
    return min(d, 360.0 - d)


def _load_gray(path: Path) -> np.ndarray:
    im = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if im is None:
        raise FileNotFoundError(path)
    return im.astype(np.float32) / 255.0


def _target_roi_mask(data_dir: Path, train_name: str, shape: tuple[int, int]) -> np.ndarray:
    """目标 ROI：mask 标签 1 或 2；优先 from_convert 最新批次。"""
    h, w = shape
    stem = Path(train_name).stem
    masks_root = data_dir / "scattering_masks" / "from_convert"
    candidates: list[Path] = []
    if masks_root.is_dir():
        latest = masks_root / "latest.json"
        if latest.is_file():
            try:
                meta = json.loads(latest.read_text(encoding="utf-8"))
                sub = meta.get("subdir") or meta.get("batch") or meta.get("path")
                if sub:
                    candidates.append(masks_root / str(sub))
            except Exception:
                pass
        for d in sorted(masks_root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
            if d.is_dir():
                candidates.append(d)
    for batch in candidates:
        for pat in (f"{stem}_mask.npy", f"{stem}.npy", f"{stem}_scattering_mask.npy"):
            p = batch / pat
            if p.is_file():
                m = np.load(p)
                if m.shape[:2] != (h, w):
                    m = cv2.resize(m.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST)
                return (m == 1) | (m == 2)
    return np.ones((h, w), dtype=bool)


def _laplacian_sharpness(gray: np.ndarray, roi: np.ndarray) -> float:
    lap = cv2.Laplacian(gray, cv2.CV_32F)
    v = lap[roi]
    if v.size == 0:
        return 0.0
    return float(np.var(v))


def _roi_l1(a: np.ndarray, b: np.ndarray, roi: np.ndarray) -> float:
    d = np.abs(a - b)[roi]
    return float(np.mean(d)) if d.size else float("nan")


def _collect_train_images(data_dir: Path) -> dict[float, Path]:
    img_dir = data_dir / "images"
    out: dict[float, Path] = {}
    for p in sorted(img_dir.iterdir()):
        if p.suffix.lower() not in {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}:
            continue
        az = _parse_azimuth_from_name(p.name)
        if az is None:
            continue
        out[az] = p
    return out


def _find_novel_renders(novel_dir: Path) -> list[tuple[float, Path]]:
    novel_dir = Path(novel_dir)
    items: list[tuple[float, Path]] = []
    for p in novel_dir.rglob("*"):
        if p.suffix.lower() not in {".jpg", ".jpeg", ".png"}:
            continue
        az = _parse_azimuth_from_name(p.name)
        if az is None:
            continue
        items.append((az, p))
    return sorted(items, key=lambda x: x[0])


def _nearest_train_az(az: float, train_azs: list[float]) -> float:
    return min(train_azs, key=lambda t: _circular_dist(az, t))


def analyze(data_dir: Path, novel_dir: Path, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    train_map = _collect_train_images(data_dir)
    if not train_map:
        raise SystemExit(f"未在 {data_dir / 'images'} 找到可解析方位的训练图")
    train_azs = sorted(train_map.keys())
    train_gray: dict[float, np.ndarray] = {}
    train_roi: dict[float, np.ndarray] = {}
    ref_shape = None
    for az, path in train_map.items():
        g = _load_gray(path)
        ref_shape = g.shape
        train_gray[az] = g
        train_roi[az] = _target_roi_mask(data_dir, path.name, g.shape)

    novel_items = _find_novel_renders(novel_dir)
    if not novel_items:
        raise SystemExit(f"未在 {novel_dir} 下找到新视角渲染图")

    rows = []
    for az, path in novel_items:
        g = _load_gray(path)
        if ref_shape and g.shape != ref_shape:
            g = cv2.resize(g, (ref_shape[1], ref_shape[0]), interpolation=cv2.INTER_AREA)
        n_az = _nearest_train_az(az, train_azs)
        roi = train_roi[n_az]
        sharp = _laplacian_sharpness(g, roi)
        l1_near = _roi_l1(g, train_gray[n_az], roi)
        offset = _circular_dist(az, n_az)
        is_train = offset < 0.5
        mid_between = False
        if not is_train and len(train_azs) >= 2:
            best_mid_dist = 999.0
            best_span = 20.0
            for i, t0 in enumerate(train_azs):
                t1 = train_azs[(i + 1) % len(train_azs)]
                span = (t1 - t0) % 360.0
                if span <= 0:
                    continue
                mid = (t0 + span * 0.5) % 360.0
                d_mid = _circular_dist(az, mid)
                d0 = _circular_dist(az, t0)
                d1 = _circular_dist(az, t1)
                if d0 < span * 0.45 and d1 < span * 0.45 and d_mid < best_mid_dist:
                    best_mid_dist = d_mid
                    best_span = span
            if best_mid_dist < max(2.0, min(6.0, best_span * 0.15)):
                mid_between = True
        rows.append({
            "azimuth": az,
            "file": str(path),
            "nearest_train_az": n_az,
            "offset_deg": offset,
            "is_train_az": int(is_train),
            "is_mid_between_train": int(mid_between),
            "roi_laplacian_var": sharp,
            "roi_l1_to_nearest_train": l1_near,
        })

    csv_path = out_dir / "azimuth_quality.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    try:
        import matplotlib.pyplot as plt

        azs = [r["azimuth"] for r in rows]
        sharp = [r["roi_laplacian_var"] for r in rows]
        l1s = [r["roi_l1_to_nearest_train"] for r in rows]
        fig, ax1 = plt.subplots(figsize=(12, 4))
        ax1.plot(azs, sharp, "b.-", label="ROI Laplacian var (↑ clearer)")
        ax1.set_xlabel("Azimuth (deg)")
        ax1.set_ylabel("Sharpness")
        for t in train_azs:
            ax1.axvline(t, color="green", alpha=0.25, linestyle="--")
        ax1.legend(loc="upper left")
        ax2 = ax1.twinx()
        ax2.plot(azs, l1s, "r.-", alpha=0.7, label="L1 to nearest train (↓ more novel)")
        ax2.set_ylabel("ROI L1 vs nearest train")
        ax2.legend(loc="upper right")
        plt.title("Novel view quality vs azimuth")
        plt.tight_layout()
        fig.savefig(out_dir / "azimuth_quality_curve.png", dpi=150)
        plt.close()

        train_sharp = [r["roi_laplacian_var"] for r in rows if r["is_train_az"]]
        mid_sharp = [r["roi_laplacian_var"] for r in rows if r["is_mid_between_train"]]
        other_sharp = [
            r["roi_laplacian_var"] for r in rows
            if not r["is_train_az"] and not r["is_mid_between_train"]
        ]
        summary = {
            "n_novel": len(rows),
            "train_azimuths": train_azs,
            "mean_sharp_train_az": float(np.mean(train_sharp)) if train_sharp else None,
            "mean_sharp_mid_between": float(np.mean(mid_sharp)) if mid_sharp else None,
            "mean_sharp_other": float(np.mean(other_sharp)) if other_sharp else None,
            "mean_l1_train_az": float(np.mean([r["roi_l1_to_nearest_train"] for r in rows if r["is_train_az"]])) or None,
            "mean_l1_mid_between": float(np.mean([r["roi_l1_to_nearest_train"] for r in rows if r["is_mid_between_train"]])) or None,
        }
        (out_dir / "summary.json").write_text(
            json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        print(json.dumps(summary, indent=2, ensure_ascii=False))
        print(f"曲线: {out_dir / 'azimuth_quality_curve.png'}")
    except ImportError:
        print("未安装 matplotlib，仅写出 CSV:", csv_path)

    print(f"CSV: {csv_path}")


def main() -> None:
    p = argparse.ArgumentParser(description="新视角方位–清晰度诊断")
    p.add_argument("--data", type=str, required=True, help="数据集目录，如 data/360-1")
    p.add_argument("--novel-dir", type=str, required=True, help="含 depression_*/renders 的 novel_views 根目录")
    p.add_argument("--out", type=str, required=True, help="分析结果输出目录")
    args = p.parse_args()
    analyze(Path(args.data), Path(args.novel_dir), Path(args.out))


if __name__ == "__main__":
    main()
