#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
深入分析radius_scale计算公式的物理意义和问题
"""

import json
import math

print("="*70)
print("radius_scale计算公式深度分析")
print("="*70)

# 读取配置
with open("data/25/sar_scale_params.json", 'r') as f:
    scale_params = json.load(f)

# 参数
camera_height = scale_params.get('camera_height', 12000.0)
scene_scale = scale_params.get('scene_scale', 0.1)
image_size = 128
avg_dep_deg = scale_params.get('average_depression_angle', 30.0)
R0 = camera_height / math.sin(math.radians(avg_dep_deg))
point_max_extent = scale_params.get('point_cloud_max_extent', 20.22)

unified_radius_scale = scale_params.get('unified_radius_scale', 0.084268)
estimated_radius_scale = scale_params.get('estimated_radius_scale', 0.084268)

print("\n【1. 参数设置】")
print("-"*70)
print(f"相机高度: {camera_height:.1f}m")
print(f"平均俯视角: {avg_dep_deg:.1f}°")
print(f"理论斜距R0: {R0:.2f}m")
print(f"图像尺寸: {image_size}像素")
print(f"场景缩放因子: {scene_scale}")
print(f"点云最大扩展: {point_max_extent:.2f}m")

print("\n【2. unified_radius_scale计算分析】")
print("-"*70)
print(f"公式: unified_radius_scale = (image_size × scene_scale) / R0")
print(f"计算: ({image_size} × {scene_scale}) / {R0:.2f} = {(image_size * scene_scale) / R0:.6f}")

# 分析物理意义
sphere_radius_unified = R0 * unified_radius_scale
print(f"\n物理意义:")
print(f"  - 球面半径 = R0 × unified_radius_scale")
print(f"  - 球面半径 = {R0:.2f} × {unified_radius_scale:.6f} = {sphere_radius_unified:.2f}m")
print(f"  - 这意味着相机位置在距离原点 {sphere_radius_unified:.2f}m 的球面上")

print("\n【3. estimated_radius_scale计算分析】")
print("-"*70)
print(f"公式: estimated_radius_scale = (point_cloud_max_extent × 100) / R0_avg")
print(f"计算: ({point_max_extent:.2f} × 100) / {R0:.2f} = {(point_max_extent * 100) / R0:.6f}")

# 分析物理意义
sphere_radius_estimated = R0 * estimated_radius_scale
print(f"\n物理意义:")
print(f"  - 球面半径 = R0 × estimated_radius_scale")
print(f"  - 球面半径 = {R0:.2f} × {estimated_radius_scale:.6f} = {sphere_radius_estimated:.2f}m")
print(f"  - 这意味着相机位置在距离原点 {sphere_radius_estimated:.2f}m 的球面上")

print("\n【4. 问题分析】")
print("-"*70)
print("1. unified_radius_scale公式的问题:")
print(f"   - 计算结果: {(image_size * scene_scale) / R0:.6f}")
print(f"   - 球面半径: {sphere_radius_unified:.2f}m")
print(f"   - 问题: 球面半径只有 {sphere_radius_unified:.2f}m，太小了！")
print(f"   - 相机高度是 {camera_height:.1f}m，但球面半径只有 {sphere_radius_unified:.2f}m")
print(f"   - 这导致相机位置过近，点云被投影过远")

print("\n2. estimated_radius_scale公式的问题:")
print(f"   - 计算结果: {(point_max_extent * 100) / R0:.6f}")
print(f"   - 球面半径: {sphere_radius_estimated:.2f}m")
print(f"   - 问题: 公式中的 '× 100' 系数来源不明")
print(f"   - 如果不使用×100: ({point_max_extent:.2f} / {R0:.2f}) = {point_max_extent / R0:.6f}")
print(f"   - 球面半径 = {R0 * (point_max_extent / R0):.2f}m = {point_max_extent:.2f}m")
print(f"   - 这意味着相机位置在距离原点 {point_max_extent:.2f}m 的球面上")
print(f"   - 但点云最大扩展也是 {point_max_extent:.2f}m，这会导致相机和点云重叠！")

print("\n3. 正确的物理关系应该是:")
print(f"   - 相机距离（球面半径）应该远大于点云尺度")
print(f"   - 如果点云尺度是 {point_max_extent:.2f}m，相机距离应该是 {point_max_extent * 10:.0f}-{point_max_extent * 100:.0f}m")
print(f"   - 当前R0 = {R0:.0f}m，所以合理的radius_scale应该是:")
print(f"     * 最小: {point_max_extent * 10 / R0:.6f} (相机距离 = 点云尺度 × 10)")
print(f"     * 最大: {point_max_extent * 100 / R0:.6f} (相机距离 = 点云尺度 × 100)")
print(f"   - estimated_radius_scale = {(point_max_extent * 100) / R0:.6f} 正好在这个范围内")

print("\n【5. 公式推导】")
print("-"*70)
print("根据SAR几何:")
print("  - 球面半径 = R0 × radius_scale")
print("  - 点云尺度应该与球面半径成比例")
print("  - 如果点云尺度是 point_extent，相机距离应该是 point_extent × k (k > 1)")
print("  - 所以: R0 × radius_scale = point_extent × k")
print("  - 因此: radius_scale = (point_extent × k) / R0")
print(f"\n当前公式中的 k = 100，这意味着:")
print(f"  - 相机距离 = 点云尺度 × 100")
print(f"  - 相机距离 = {point_max_extent:.2f} × 100 = {point_max_extent * 100:.2f}m")
print(f"  - 这比R0 = {R0:.0f}m 小得多，所以radius_scale < 1")
print(f"  - 实际: radius_scale = {estimated_radius_scale:.6f}")

print("\n【6. 建议】")
print("-"*70)
print("1. unified_radius_scale公式可能有问题:")
print("   - 公式: (image_size × scene_scale) / R0")
print("   - 这个公式没有考虑点云的实际尺度")
print("   - 建议: 应该基于点云尺度计算，而不是图像尺寸")

print("\n2. estimated_radius_scale公式中的×100:")
print("   - 这个系数表示'相机距离应该是点云尺度的100倍'")
print("   - 这个假设可能合理，但需要验证")
print("   - 建议: 可以尝试不同的系数（如50、100、200）看效果")

print("\n3. 更好的公式可能是:")
print("   - radius_scale = (point_extent × k) / R0")
print("   - 其中k是相机距离与点云尺度的比例（如50-200）")
print("   - 或者: radius_scale = point_extent / (R0 / k)")
print("   - 这样相机距离 = R0 × radius_scale = point_extent × k")

print("\n" + "="*70)
print("分析完成")
print("="*70)

