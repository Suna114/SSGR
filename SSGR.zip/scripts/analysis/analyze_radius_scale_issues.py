#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
分析radius_scale和焦距配置问题
"""

import json
import os

# 读取scale_params.json
scale_params_file = "data/25/sar_scale_params.json"
cameras_file = "output/1/cameras.json"

print("="*70)
print("radius_scale和焦距配置问题分析")
print("="*70)

# 1. 读取scale_params.json
print("\n【1. scale_params.json 配置】")
print("-"*70)
with open(scale_params_file, 'r') as f:
    scale_params = json.load(f)

unified_radius_scale = scale_params.get('unified_radius_scale', None)
estimated_radius_scale = scale_params.get('estimated_radius_scale', None)
unified_focal_azimuth = scale_params.get('unified_focal_azimuth', None)
unified_focal_range = scale_params.get('unified_focal_range', None)
R0 = scale_params.get('radius_scale_calculation', {}).get('R0', None)
sphere_radius = scale_params.get('radius_scale_calculation', {}).get('sphere_radius', None)
image_size = scale_params.get('radius_scale_calculation', {}).get('image_size', None)
scene_scale = scale_params.get('scene_scale', None)

print(f"unified_radius_scale: {unified_radius_scale}")
print(f"estimated_radius_scale: {estimated_radius_scale}")
print(f"unified_focal_azimuth: {unified_focal_azimuth}")
print(f"unified_focal_range: {unified_focal_range}")
print(f"R0 (参考斜距): {R0}")
print(f"sphere_radius: {sphere_radius}")
print(f"image_size: {image_size}")
print(f"scene_scale: {scene_scale}")

# 2. 读取cameras.json
print("\n【2. cameras.json 实际焦距统计】")
print("-"*70)
with open(cameras_file, 'r') as f:
    cameras = json.load(f)

fx_list = [c['fx'] for c in cameras]
fy_list = [c['fy'] for c in cameras]
positions = [[c['position'][0], c['position'][1], c['position'][2]] for c in cameras]

fx_mean = sum(fx_list) / len(fx_list)
fx_min = min(fx_list)
fx_max = max(fx_list)
fx_std = (sum([(x - fx_mean)**2 for x in fx_list]) / len(fx_list))**0.5

print(f"实际焦距统计 (fx):")
print(f"  均值: {fx_mean:.2f}")
print(f"  最小值: {fx_min:.2f}")
print(f"  最大值: {fx_max:.2f}")
print(f"  标准差: {fx_std:.2f}")
print(f"  变异系数: {fx_std/fx_mean:.4f}")

print(f"\n统一焦距配置: {unified_focal_azimuth}")
print(f"实际焦距均值: {fx_mean:.2f}")
print(f"差异: {abs(fx_mean - unified_focal_azimuth):.2f} ({abs(fx_mean - unified_focal_azimuth)/unified_focal_azimuth*100:.1f}%)")

# 3. 分析相机位置
print("\n【3. 相机位置统计】")
print("-"*70)

# 计算相机中心
pos_x = [p[0] for p in positions]
pos_y = [p[1] for p in positions]
pos_z = [p[2] for p in positions]

center_x = sum(pos_x) / len(pos_x)
center_y = sum(pos_y) / len(pos_y)
center_z = sum(pos_z) / len(pos_z)

# 计算距离
distances = []
for p in positions:
    dist = ((p[0] - center_x)**2 + (p[1] - center_y)**2 + (p[2] - center_z)**2)**0.5
    distances.append(dist)

mean_dist = sum(distances) / len(distances)
min_dist = min(distances)
max_dist = max(distances)

print(f"相机中心: ({center_x:.2f}, {center_y:.2f}, {center_z:.2f})")
print(f"平均距离: {mean_dist:.2f}")
print(f"距离范围: [{min_dist:.2f}, {max_dist:.2f}]")
print(f"\nY坐标统计:")
print(f"  Y均值: {sum(pos_y)/len(pos_y):.2f}")
print(f"  Y范围: [{min(pos_y):.2f}, {max(pos_y):.2f}]")

# 4. 问题分析
print("\n【4. 问题分析】")
print("-"*70)

issues = []

# 问题1: radius_scale值差异巨大
if unified_radius_scale and estimated_radius_scale:
    ratio = estimated_radius_scale / unified_radius_scale
    print(f"\n⚠️  问题1: radius_scale值差异巨大")
    print(f"  unified_radius_scale: {unified_radius_scale:.6f}")
    print(f"  estimated_radius_scale: {estimated_radius_scale:.6f}")
    print(f"  差异倍数: {ratio:.1f}倍")
    print(f"  说明: estimated_radius_scale是基于SO-RCG优化后的点云尺度估算的，")
    print(f"        而unified_radius_scale是基于公式计算的，两者差异巨大！")
    issues.append(f"radius_scale值差异巨大 ({ratio:.1f}倍)")

# 问题2: 统一焦距与实际焦距不匹配
if unified_focal_azimuth:
    focal_diff_pct = abs(fx_mean - unified_focal_azimuth) / unified_focal_azimuth * 100
    if focal_diff_pct > 10:
        print(f"\n⚠️  问题2: 统一焦距与实际焦距不匹配")
        print(f"  统一焦距: {unified_focal_azimuth}")
        print(f"  实际焦距均值: {fx_mean:.2f}")
        print(f"  差异: {focal_diff_pct:.1f}%")
        print(f"  说明: 训练时使用的焦距与SfM重建时的统一焦距不一致")
        issues.append(f"统一焦距与实际焦距不匹配 ({focal_diff_pct:.1f}%)")

# 问题3: radius_scale太小
if unified_radius_scale:
    if unified_radius_scale < 0.01:
        print(f"\n⚠️  问题3: unified_radius_scale太小")
        print(f"  当前值: {unified_radius_scale:.6f}")
        print(f"  说明: radius_scale太小会导致相机位置被缩放得非常近，")
        print(f"        点云会被投影得太远，导致目标点在外围")
        issues.append(f"unified_radius_scale太小 ({unified_radius_scale:.6f})")

# 问题4: 焦距范围过大
fx_range = fx_max - fx_min
if fx_range > 30:
    print(f"\n⚠️  问题4: 焦距范围过大")
    print(f"  焦距范围: [{fx_min:.2f}, {fx_max:.2f}]")
    print(f"  跨度: {fx_range:.2f}")
    print(f"  说明: 虽然焦距一致性良好（变异系数<0.1），但存在异常值")
    print(f"        最小焦距 {fx_min:.2f} 和最大焦距 {fx_max:.2f} 差异很大")
    issues.append(f"焦距范围过大 (跨度{fx_range:.2f})")

# 问题5: radius_scale计算公式
if unified_radius_scale and R0 and image_size and scene_scale:
    calculated = (image_size * scene_scale) / R0
    print(f"\n📐 radius_scale计算公式验证:")
    print(f"  公式: (image_size × scene_scale) / R0")
    print(f"  计算: ({image_size} × {scene_scale}) / {R0} = {calculated:.6f}")
    print(f"  实际值: {unified_radius_scale:.6f}")
    if abs(calculated - unified_radius_scale) < 1e-6:
        print(f"  ✅ 公式计算正确")
    else:
        print(f"  ⚠️  公式计算与实际值不一致")

# 5. 推荐修复方案
print("\n【5. 推荐修复方案】")
print("-"*70)

if issues:
    print(f"\n检测到 {len(issues)} 个问题:")
    for i, issue in enumerate(issues, 1):
        print(f"  {i}. {issue}")
    
    print(f"\n推荐修复步骤:")
    
    if unified_radius_scale and estimated_radius_scale:
        print(f"\n1. 使用estimated_radius_scale替代unified_radius_scale")
        print(f"   原因: estimated_radius_scale是基于SO-RCG优化后的点云尺度估算的，更准确")
        print(f"   操作: 将sar_scale_params.json中的radius_scale改为estimated_radius_scale的值")
        print(f"   建议值: {estimated_radius_scale:.6f}")
    
    if unified_focal_azimuth and abs(fx_mean - unified_focal_azimuth) / unified_focal_azimuth > 0.1:
        print(f"\n2. 调整统一焦距或重新训练")
        print(f"   选项A: 使用实际焦距均值作为统一焦距")
        print(f"   建议值: {fx_mean:.2f}")
        print(f"   选项B: 重新运行SfM重建，确保使用统一的焦距参数")
    
    if unified_radius_scale and unified_radius_scale < 0.01:
        print(f"\n3. 增大radius_scale")
        print(f"   当前值: {unified_radius_scale:.6f}")
        print(f"   建议值: {estimated_radius_scale:.6f} (使用estimated_radius_scale)")
        print(f"   或者: {unified_radius_scale * 10:.6f} (当前值的10倍)")
        print(f"   或者: {unified_radius_scale * 100:.6f} (当前值的100倍)")
    
    print(f"\n4. 重新训练")
    print(f"   修改sar_scale_params.json后，重新运行训练:")
    print(f"   python train.py -s data/25 -m output/<model>")
else:
    print("\n✅ 未检测到明显问题")

print("\n" + "="*70)
print("分析完成")
print("="*70)

