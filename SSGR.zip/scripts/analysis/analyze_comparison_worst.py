#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
从 compare_render_gt.py 生成的 comparison_results.json 中，
按 PSNR 排序，找出最差/最好若干张，并解析 MSTAR 风格文件名中的俯视角与方位角。

用法:
  python analyze_comparison_worst.py --json comparison_results/comparison_results.json
  python analyze_comparison_worst.py --json comparison_results/comparison_results.json --worst 8 --best 3
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path


def parse_mstar_silent(filename: str):
    """与 sar_utils.parse_mstar_filename 一致，但不打印。"""
    basename = os.path.splitext(os.path.basename(filename))[0]
    pattern = r"([A-Za-z0-9]+)-(\d+)-(\d+)"
    match = re.search(pattern, basename)
    if match:
        return (
            match.group(1),
            int(match.group(2)),
            int(match.group(3)),
        )
    return None, None, None


def load_per_image(path: Path) -> list:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    items = data.get("per_image") or data.get("per_image_metrics")
    if not items:
        raise ValueError("JSON 中未找到 per_image 列表，请确认是 compare_render_gt 生成的文件")
    return items


def main():
    p = argparse.ArgumentParser(description="分析对比结果中 PSNR 最差/最好视角与方位角")
    p.add_argument(
        "--json",
        type=str,
        default="comparison_results/comparison_results.json",
        help="comparison_results.json 路径",
    )
    p.add_argument("--worst", type=int, default=8, help="列出 PSNR 最低的 N 张")
    p.add_argument("--best", type=int, default=3, help="列出 PSNR 最高的 N 张")
    args = p.parse_args()

    json_path = Path(args.json)
    if not json_path.is_file():
        print(f"❌ 文件不存在: {json_path.resolve()}")
        sys.exit(1)

    items = load_per_image(json_path)
    # 按 PSNR 升序（差→好）
    def psnr_key(x):
        v = x.get("PSNR")
        return float("inf") if v is None else float(v)

    sorted_bad = sorted(items, key=psnr_key)  # 最差在前
    sorted_good = sorted(items, key=psnr_key, reverse=True)

    print("=" * 88)
    print("PSNR 最低（重建相对最难）的视角 — 结合方位角/俯视角看是否集中在某些角度")
    print("=" * 88)
    print(f"{'排名':^4} {'文件名':<36} {'PSNR':>8} {'SSIM':>7} {'俯视角°':>8} {'方位角°':>8} {'目标':<6}")
    print("-" * 88)

    worst = sorted_bad[: max(0, args.worst)]
    for i, m in enumerate(worst, 1):
        name = m.get("image_name", "?")
        tgt, dep, azi = parse_mstar_silent(name)
        psnr = m.get("PSNR")
        ssim = m.get("SSIM")
        psnr_s = f"{psnr:.2f}" if psnr is not None else "N/A"
        ssim_s = f"{ssim:.3f}" if ssim is not None else "N/A"
        dep_s = str(dep) if dep is not None else "?"
        azi_s = str(azi) if azi is not None else "?"
        tgt_s = (tgt or "?")[:6]
        print(f"{i:^4} {name:<36} {psnr_s:>8} {ssim_s:>7} {dep_s:>8} {azi_s:>8} {tgt_s:<6}")

    print()
    print("=" * 88)
    print("PSNR 最高（重建相对最容易）的视角 — 对照参考")
    print("=" * 88)
    print(f"{'排名':^4} {'文件名':<36} {'PSNR':>8} {'SSIM':>7} {'俯视角°':>8} {'方位角°':>8} {'目标':<6}")
    print("-" * 88)

    best = sorted_good[: max(0, args.best)]
    for i, m in enumerate(best, 1):
        name = m.get("image_name", "?")
        tgt, dep, azi = parse_mstar_silent(name)
        psnr = m.get("PSNR")
        ssim = m.get("SSIM")
        psnr_s = f"{psnr:.2f}" if psnr is not None else "N/A"
        ssim_s = f"{ssim:.3f}" if ssim is not None else "N/A"
        dep_s = str(dep) if dep is not None else "?"
        azi_s = str(azi) if azi is not None else "?"
        tgt_s = (tgt or "?")[:6]
        print(f"{i:^4} {name:<36} {psnr_s:>8} {ssim_s:>7} {dep_s:>8} {azi_s:>8} {tgt_s:<6}")

    # 简单统计：最差组的方位角范围
    print()
    print("=" * 88)
    print("简要解读（自动统计）")
    print("=" * 88)
    azis_w = [parse_mstar_silent(m.get("image_name", ""))[2] for m in worst]
    azis_w = [a for a in azis_w if a is not None]
    if len(azis_w) >= 2:
        print(
            f"  最差 {len(worst)} 张的方位角范围: {min(azis_w)}° ~ {max(azis_w)}° "
            f"(跨度 {max(azis_w) - min(azis_w)}°)"
        )
        print(
            "  · 若最差视角明显集中在某段方位角，可能与阴影/叠掩、侧视几何或训练视角覆盖不足有关。"
        )
        print(
            "  · 若俯视角在文件名里一致而只有方位角变化，差异多半来自方位向成像与 3D 结构可见性。"
        )
    else:
        print("  未能从文件名解析方位角（需 MSTAR 风格：目标-俯视角-方位角，如 T72-15-002.jpg）")

    print()
    print("  手动核对：打开 output/.../train/renders 与 gt 下同名的最差几张，看是否偏暗、模糊或几何错位。")
    print("=" * 88)


if __name__ == "__main__":
    main()
