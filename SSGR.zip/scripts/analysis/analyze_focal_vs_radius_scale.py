#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
分析焦距与k值（radius_scale）的关系
"""

import json
import math

print("="*70)
print("焦距与k值（radius_scale）关系分析")
print("="*70)

# 读取配置
with open("data/25/sar_scale_params.json", 'r') as f:
    scale_params = json.load(f)

# 参数
camera_height = scale_params.get('camera_height', 12000.0)
avg_dep_deg = scale_params.get('average_depression_angle', 30.0)
R0 = camera_height / math.sin(math.radians(avg_dep_deg))
point_max_extent = scale_params.get('point_cloud_max_extent', 20.22)

# 计算k值
k_theoretical = R0 / point_max_extent if point_max_extent > 0 else 100.0
estimated_radius_scale = scale_params.get('estimated_radius_scale', 0.084268)

# 计算球面半径
sphere_radius = R0 * estimated_radius_scale

print("\n【1. k值与radius_scale的关系】")
print("-"*70)
print(f"理论k值: k = R0 / point_extent = {R0:.1f} / {point_max_extent:.2f} = {k_theoretical:.1f}")
print(f"estimated_radius_scale: {estimated_radius_scale:.6f}")
print(f"球面半径 = R0 × radius_scale = {R0:.1f} × {estimated_radius_scale:.6f} = {sphere_radius:.2f}m")
print(f"相机距离/点云尺度 = {sphere_radius:.2f} / {point_max_extent:.2f} = {sphere_radius / point_max_extent:.1f}倍")

print("\n【2. 焦距计算流程】")
print("-"*70)
print("在SO-RCG优化过程中：")
print("1. 使用新的radius_scale计算相机位置：")
print(f"   - sphere_radius = R0 × radius_scale = {R0:.1f} × {estimated_radius_scale:.6f} = {sphere_radius:.2f}m")
print(f"   - 相机位置 = sphere_radius × [sin(dep)cos(azi), -cos(dep), sin(dep)sin(azi)]")
print()
print("2. 从优化后的相机位置计算实际R0：")
print(f"   - actual_R0 = ||相机位置|| = {sphere_radius:.2f}m（对于球面分布）")
print()
print("3. 基于actual_R0计算焦距：")
print(f"   - reference_R0 = camera_height / sin(dep) = {R0:.1f}m")
print(f"   - focal_scale_ratio = actual_R0 / reference_R0 = {sphere_radius:.2f} / {R0:.1f} = {sphere_radius / R0:.6f}")
print(f"   - focal = reference_focal × focal_scale_ratio")
print(f"   - 如果reference_focal = 128 × 1.5 = 192.0")
print(f"   - 则 focal = 192.0 × {sphere_radius / R0:.6f} = {192.0 * sphere_radius / R0:.2f}")

print("\n【3. 关键发现】")
print("-"*70)
print("✅ 焦距确实使用了新的k值（通过radius_scale）：")
print(f"   - k值影响radius_scale: radius_scale = (point_extent × k) / R0")
print(f"   - radius_scale影响相机位置: sphere_radius = R0 × radius_scale")
print(f"   - 相机位置影响actual_R0: actual_R0 = ||相机位置||")
print(f"   - actual_R0影响焦距: focal = reference_focal × (actual_R0 / reference_R0)")
print()
print("✅ 关系链：")
print(f"   k → radius_scale → 相机位置 → actual_R0 → 焦距")
print()
print(f"   当前值：")
print(f"   - k = {k_theoretical:.1f} (理论值)")
print(f"   - radius_scale = {estimated_radius_scale:.6f}")
print(f"   - sphere_radius = {sphere_radius:.2f}m")
print(f"   - actual_R0 ≈ {sphere_radius:.2f}m")
print(f"   - focal_scale_ratio = {sphere_radius / R0:.6f}")
print(f"   - 如果reference_focal = 192.0，则实际焦距 ≈ {192.0 * sphere_radius / R0:.2f}")

print("\n【4. 验证】")
print("-"*70)
print("从cameras.json中看到的实际焦距均值: 62.82")
print(f"如果使用新的radius_scale计算：")
print(f"   - focal_scale_ratio = {sphere_radius / R0:.6f}")
print(f"   - 焦距 = 192.0 × {sphere_radius / R0:.6f} = {192.0 * sphere_radius / R0:.2f}")
print()
if abs(192.0 * sphere_radius / R0 - 62.82) < 5:
    print("✅ 计算值与实际值接近，说明焦距确实使用了新的radius_scale")
else:
    print("⚠️  计算值与实际值差异较大，可能需要进一步检查")

print("\n" + "="*70)
print("分析完成")
print("="*70)

