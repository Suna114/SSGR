#!/usr/bin/env python3
"""
为留角实验生成 sparse/0/test.txt：列出不参与训练的图像（仅用于 --eval 模式）。

示例（MSTAR 360-1 方位为 1,9,20,31… 非整 10°；推荐 odd_sorted 隔一张留角）:
  python scripts/analysis/make_holdout_test_txt.py --data data/360-1 --mode odd_sorted
  python train_sar_complete.py -s data/360-1 -m output/360-1-holdout --eval --iterations 30000

渲染留角（例如 15°）:
  python scripts/rendering/render_novel_sar_views.py -m output/360-1-holdout --iteration 30000 \\
    --same_depression_only --azimuth_start 15 --azimuth_end 16 --azimuth_step 1 \\
    --novel_pose_mode colmap_track --output_dir output/360-1-holdout/render_azi15
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parents[2]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from scripts.analysis.azimuth_novel_diagnostic import _parse_azimuth_from_name


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True, help="如 data/360-1")
    p.add_argument(
        "--mode",
        choices=("odd_sorted", "mid10"),
        default="odd_sorted",
        help="odd_sorted: 按方位排序后隔一张留测试(推荐); mid10: 方位整除10余5(仅当数据为0/10/20°时)",
    )
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()
    data = Path(args.data)
    img_dir = data / "images"
    hold: list[str] = []
    train_names: list[str] = []
    items: list[tuple[float, str]] = []
    for pth in sorted(img_dir.iterdir()):
        if pth.suffix.lower() not in {".jpg", ".jpeg", ".png", ".bmp"}:
            continue
        az = _parse_azimuth_from_name(pth.name)
        if az is None:
            continue
        items.append((az, pth.name))

    items.sort(key=lambda x: x[0])
    if args.mode == "odd_sorted":
        for i, (_, name) in enumerate(items):
            if i % 2 == 1:
                hold.append(name)
            else:
                train_names.append(name)
    else:
        for az, name in items:
            if int(round(az)) % 10 == 5:
                hold.append(name)
            else:
                train_names.append(name)

    sparse = data / "sparse" / "0"
    sparse.mkdir(parents=True, exist_ok=True)
    out = sparse / "test.txt"
    print(f"训练 ({len(train_names)} 张), 方位示例:", [int(a) for a, _ in items if _[1] in train_names][:8], "...")
    print(f"留角 ({len(hold)} 张), 方位:", sorted(int(_parse_azimuth_from_name(n) or -1) for n in hold))
    if not args.dry_run:
        out.write_text("\n".join(hold) + ("\n" if hold else ""), encoding="utf-8")
        print(f"已写入: {out}")
    print("\n训练命令:")
    print(f"  python train_sar_complete.py -s {data} -m output/{data.name}-holdout --eval --iterations 30000")


if __name__ == "__main__":
    main()
