# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
分析SFM重建的点云形状
检查点云是否正确（T72坦克应该是平放在XOY面上的长方体）
"""
import numpy as np
import json
import os
from plyfile import PlyData

def analyze_pointcloud(ply_path, cameras_json_path=None):
    """分析点云形状"""
    print("="*60)
    print("SFM点云形状分析")
    print("="*60)
    
    # 读取点云
    print(f"\n📂 加载点云: {ply_path}")
    plydata = PlyData.read(ply_path)
    vertices = plydata['vertex']
    xyz = np.vstack([vertices['x'], vertices['y'], vertices['z']]).T
    print(f"   点数: {len(xyz)}")
    
    # 计算包围盒
    min_xyz = np.min(xyz, axis=0)
    max_xyz = np.max(xyz, axis=0)
    size = max_xyz - min_xyz
    center = (min_xyz + max_xyz) / 2
    
    print(f"\n📦 点云包围盒:")
    print(f"   最小值: X={min_xyz[0]:.2f}, Y={min_xyz[1]:.2f}, Z={min_xyz[2]:.2f}")
    print(f"   最大值: X={max_xyz[0]:.2f}, Y={max_xyz[1]:.2f}, Z={max_xyz[2]:.2f}")
    print(f"   尺寸:   X={size[0]:.2f}, Y={size[1]:.2f}, Z={size[2]:.2f}")
    print(f"   中心:   X={center[0]:.2f}, Y={center[1]:.2f}, Z={center[2]:.2f}")
    
    # 判断点云形状
    print(f"\n🔍 形状分析:")
    # 按尺寸排序
    sorted_dims = np.argsort(size)[::-1]
    dim_names = ['X', 'Y', 'Z']
    print(f"   尺寸排序: {dim_names[sorted_dims[0]]}({size[sorted_dims[0]]:.2f}) > "
          f"{dim_names[sorted_dims[1]]}({size[sorted_dims[1]]:.2f}) > "
          f"{dim_names[sorted_dims[2]]}({size[sorted_dims[2]]:.2f})")
    
    # T72坦克应该是：长度>宽度>高度，且高度应该最小
    aspect_xy = size[0] / size[1] if size[1] > 0 else 0
    aspect_xz = size[0] / size[2] if size[2] > 0 else 0
    aspect_yz = size[1] / size[2] if size[2] > 0 else 0
    
    print(f"   长宽比: X/Y={aspect_xy:.2f}, X/Z={aspect_xz:.2f}, Y/Z={aspect_yz:.2f}")
    
    # 判断是否是"竖起来的圆柱"形状
    if sorted_dims[0] == 2:  # Z方向最大
        print(f"\n   ⚠️ 问题: Z方向尺寸最大 ({size[2]:.2f})")
        print(f"      这表明点云是'竖起来'的形状")
        print(f"      T72坦克应该是平放的，Z方向应该最小（高度）")
    elif sorted_dims[2] != 2:  # Z方向不是最小
        print(f"\n   ⚠️ 问题: Z方向尺寸不是最小")
        print(f"      坦克高度应该在Z方向，且应该是最小尺寸")
    else:
        print(f"\n   ✅ 点云形状看起来合理")
        print(f"      Z方向（高度）是最小尺寸")
    
    # 分析相机位置
    if cameras_json_path and os.path.exists(cameras_json_path):
        print(f"\n📷 相机位置分析:")
        with open(cameras_json_path, 'r') as f:
            cameras = json.load(f)
        
        positions = np.array([c['position'] for c in cameras])
        
        cam_min = np.min(positions, axis=0)
        cam_max = np.max(positions, axis=0)
        cam_center = np.mean(positions, axis=0)
        cam_size = cam_max - cam_min
        
        print(f"   相机位置范围:")
        print(f"     X: [{cam_min[0]:.2f}, {cam_max[0]:.2f}], 范围={cam_size[0]:.2f}")
        print(f"     Y: [{cam_min[1]:.2f}, {cam_max[1]:.2f}], 范围={cam_size[1]:.2f}")
        print(f"     Z: [{cam_min[2]:.2f}, {cam_max[2]:.2f}], 范围={cam_size[2]:.2f}")
        print(f"   相机中心: [{cam_center[0]:.2f}, {cam_center[1]:.2f}, {cam_center[2]:.2f}]")
        
        # 分析相机分布
        # 计算相机到原点的距离
        distances = np.linalg.norm(positions, axis=1)
        print(f"   相机到原点距离: [{np.min(distances):.2f}, {np.max(distances):.2f}], 均值={np.mean(distances):.2f}")
        
        # 计算相机在各个方向上的分布
        # 计算相机的仰角（相对于XY平面）
        xy_dist = np.sqrt(positions[:, 0]**2 + positions[:, 1]**2)
        elevation = np.arctan2(positions[:, 2], xy_dist) * 180 / np.pi
        print(f"   相机仰角范围: [{np.min(elevation):.1f}°, {np.max(elevation):.1f}°]")
        
        # 计算相机的方位角
        azimuth = np.arctan2(positions[:, 1], positions[:, 0]) * 180 / np.pi
        print(f"   相机方位角范围: [{np.min(azimuth):.1f}°, {np.max(azimuth):.1f}°]")
        
        # 判断相机是否在Z轴正方向的半球上
        z_positive_count = np.sum(positions[:, 2] > 0)
        z_negative_count = np.sum(positions[:, 2] <= 0)
        print(f"\n   相机分布:")
        print(f"     Z > 0 的相机: {z_positive_count}")
        print(f"     Z <= 0 的相机: {z_negative_count}")
        
        if z_positive_count > 0.8 * len(positions):
            print(f"   ⚠️ 大部分相机在Z正半空间，这符合'半球分布'")
    
    print("\n" + "="*60)
    print("分析完成")
    print("="*60)

if __name__ == "__main__":
    import sys
    
    # 默认路径
    ply_path = "./output/sar_reconstruction1/input.ply"
    cameras_json_path = "./output/sar_reconstruction1/cameras.json"
    
    if len(sys.argv) > 1:
        ply_path = sys.argv[1]
    if len(sys.argv) > 2:
        cameras_json_path = sys.argv[2]
    
    if os.path.exists(ply_path):
        analyze_pointcloud(ply_path, cameras_json_path)
    else:
        # 尝试找其他点云
        alt_paths = [
            "./data/24/sparse/0/points3D.ply",
            "./data/23/sparse/0/points3D.ply",
            "./data/22/sparse/0/points3D.ply",
        ]
        for alt in alt_paths:
            if os.path.exists(alt):
                ply_path = alt
                cameras_json_path = None
                print(f"使用替代点云: {alt}")
                analyze_pointcloud(ply_path, cameras_json_path)
                break
        else:
            print(f"未找到点云文件: {ply_path}")

