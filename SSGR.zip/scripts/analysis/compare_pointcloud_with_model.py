#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
点云与3D模型对比工具
用于将高斯泼溅生成的目标点云与真实的T72坦克模型进行对比
支持自动缩放和对齐
"""

import numpy as np
import open3d as o3d
import argparse
import os
import json
import copy
from pathlib import Path


def load_point_cloud(ply_path):
    """加载PLY点云文件"""
    if not os.path.exists(ply_path):
        raise FileNotFoundError(f"点云文件不存在: {ply_path}")
    
    print(f"📂 加载点云: {ply_path}")
    pcd = o3d.io.read_point_cloud(ply_path)
    
    if len(pcd.points) == 0:
        raise ValueError(f"点云文件为空: {ply_path}")
    
    print(f"   ✅ 成功加载 {len(pcd.points)} 个点")
    return pcd


def load_model(model_path):
    """加载3D模型（支持PLY, OBJ, STL等格式）"""
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"模型文件不存在: {model_path}")
    
    print(f"📂 加载模型: {model_path}")
    
    ext = os.path.splitext(model_path)[1].lower()
    
    if ext == '.ply':
        mesh = o3d.io.read_triangle_mesh(model_path)
        if len(mesh.vertices) == 0:
            # 如果是点云格式的PLY
            pcd = o3d.io.read_point_cloud(model_path)
            return pcd
        return mesh
    elif ext in ['.obj', '.stl', '.off']:
        mesh = o3d.io.read_triangle_mesh(model_path)
        if len(mesh.vertices) == 0:
            raise ValueError(f"模型文件为空: {model_path}")
        return mesh
    else:
        raise ValueError(f"不支持的模型格式: {ext}")


def get_bounding_box(geometry, remove_outliers_flag=False):
    """
    获取几何体的边界框和尺寸
    
    Args:
        geometry: 点云或网格几何体
        remove_outliers_flag: 是否先移除离散点（仅对点云有效）
    """
    # 如果需要对点云过滤离散点
    if remove_outliers_flag and isinstance(geometry, o3d.geometry.PointCloud):
        filtered_geometry, _ = remove_outliers(geometry, nb_neighbors=20, std_ratio=2.0)
        bbox = filtered_geometry.get_axis_aligned_bounding_box()
    else:
        bbox = geometry.get_axis_aligned_bounding_box()
    
    min_bound = bbox.min_bound
    max_bound = bbox.max_bound
    size = max_bound - min_bound
    center = bbox.get_center()
    
    return {
        'min': min_bound,
        'max': max_bound,
        'size': size,
        'center': center,
        'bbox': bbox
    }


def calculate_scale_factor(source_bbox, target_bbox, scale_mode='fit', scale_what='auto'):
    """
    计算缩放因子
    
    Args:
        source_bbox: 源几何体的边界框信息（点云）
        target_bbox: 目标几何体的边界框信息（模型）
        scale_mode: 缩放模式
            - 'fit': 缩放源以匹配目标的最大尺寸
            - 'match_x': 匹配X轴
            - 'match_y': 匹配Y轴
            - 'match_z': 匹配Z轴
        scale_what: 缩放哪个对象
            - 'auto': 自动选择（如果模型大很多则缩小模型，否则放大点云）
            - 'pointcloud': 缩放点云
            - 'model': 缩放模型
    
    Returns:
        (scale_factor, scale_target) - 缩放因子和缩放目标('pointcloud'或'model')
    """
    source_size = source_bbox['size']
    target_size = target_bbox['size']
    
    print(f"\n📐 尺寸信息:")
    print(f"   点云尺寸: [{source_size[0]:.4f}, {source_size[1]:.4f}, {source_size[2]:.4f}]")
    print(f"   模型尺寸: [{target_size[0]:.4f}, {target_size[1]:.4f}, {target_size[2]:.4f}]")
    
    # 计算尺寸比例
    size_ratio = np.max(target_size) / (np.max(source_size) + 1e-10)
    print(f"   尺寸比例（模型/点云）: {size_ratio:.2f}")
    
    if scale_mode == 'fit':
        # 使用最大尺寸比例
        scale_ratios = target_size / (source_size + 1e-10)
        scale_factor = np.min(scale_ratios[source_size > 1e-10])
        print(f"   缩放模式: 匹配最大尺寸")
    elif scale_mode == 'match_x':
        scale_factor = target_size[0] / (source_size[0] + 1e-10)
        print(f"   缩放模式: 匹配X轴")
    elif scale_mode == 'match_y':
        scale_factor = target_size[1] / (source_size[1] + 1e-10)
        print(f"   缩放模式: 匹配Y轴")
    elif scale_mode == 'match_z':
        scale_factor = target_size[2] / (source_size[2] + 1e-10)
        print(f"   缩放模式: 匹配Z轴")
    else:
        scale_factor = 1.0
        print(f"   缩放模式: 无缩放")
    
    # 决定缩放哪个对象
    if scale_what == 'auto':
        # 默认缩小模型（因为点云通常比完整模型小，且缺少部分如炮筒）
        # 只有当点云明显大于模型时才放大点云
        if size_ratio < 0.5:  # 模型比点云小很多（<0.5倍），才放大点云
            # 放大点云
            scale_target = 'pointcloud'
            print(f"   💡 检测到点云比模型大（{1.0/size_ratio:.2f}倍），将放大点云")
        else:
            # 默认缩小模型（适用于大多数情况）
            scale_factor = 1.0 / scale_factor
            scale_target = 'model'
            print(f"   💡 默认缩小模型以匹配点云（模型/点云 = {size_ratio:.2f}倍）")
    elif scale_what == 'pointcloud':
        scale_target = 'pointcloud'
    elif scale_what == 'model':
        # 如果缩放模型，需要反转缩放因子
        scale_factor = 1.0 / scale_factor
        scale_target = 'model'
    else:
        scale_target = 'pointcloud'
    
    print(f"   ✅ 计算得到的缩放因子: {scale_factor:.6f}")
    print(f"   🎯 缩放目标: {scale_target}")
    
    return scale_factor, scale_target


def scale_geometry(geometry, scale_factor, center=None):
    """缩放几何体"""
    if center is None:
        center = geometry.get_axis_aligned_bounding_box().get_center()
    
    # 移动到原点
    geometry.translate(-center)
    # 缩放
    geometry.scale(scale_factor, center=(0, 0, 0))
    # 移回原位置
    geometry.translate(center)
    
    return geometry


def remove_outliers(geometry, nb_neighbors=20, std_ratio=2.0):
    """
    移除几何体中的离散点（噪声点）
    
    Args:
        geometry: 点云或网格几何体
        nb_neighbors: 统计邻域点数
        std_ratio: 标准差倍数阈值
    
    Returns:
        过滤后的几何体和过滤掩码
    """
    if isinstance(geometry, o3d.geometry.PointCloud):
        # 使用统计滤波移除离散点
        filtered_cloud, ind = geometry.remove_statistical_outlier(
            nb_neighbors=nb_neighbors, 
            std_ratio=std_ratio
        )
        return filtered_cloud, ind
    elif isinstance(geometry, o3d.geometry.TriangleMesh):
        # 对于网格，先转换为点云进行过滤
        pcd = geometry.sample_points_uniformly(number_of_points=len(geometry.vertices) * 10)
        filtered_cloud, ind = pcd.remove_statistical_outlier(
            nb_neighbors=nb_neighbors,
            std_ratio=std_ratio
        )
        # 返回原始网格（网格通常没有离散点问题）
        return geometry, list(range(len(geometry.vertices)))
    else:
        return geometry, list(range(len(geometry.points) if hasattr(geometry, 'points') else 0))


def compute_principal_axes(geometry, remove_outliers_flag=True):
    """
    计算几何体的主方向（PCA）
    
    Args:
        geometry: 点云或网格几何体
        remove_outliers_flag: 是否先移除离散点
    
    Returns:
        (centroid, eigenvectors, eigenvalues) - 质心、主方向向量、特征值
    """
    # 获取点坐标
    if isinstance(geometry, o3d.geometry.PointCloud):
        original_points = np.asarray(geometry.points)
    elif isinstance(geometry, o3d.geometry.TriangleMesh):
        original_points = np.asarray(geometry.vertices)
    else:
        raise ValueError(f"不支持的几何类型: {type(geometry)}")
    
    if len(original_points) == 0:
        raise ValueError("几何体为空")
    
    # 先移除离散点（仅对点云）
    if remove_outliers_flag and isinstance(geometry, o3d.geometry.PointCloud):
        print(f"   🔍 过滤离散点（原始点数: {len(original_points)}）...")
        filtered_geometry, inlier_indices = remove_outliers(geometry, nb_neighbors=20, std_ratio=2.0)
        points = np.asarray(filtered_geometry.points)
        num_outliers = len(original_points) - len(points)
        print(f"   ✅ 过滤完成（移除 {num_outliers} 个离散点，保留 {len(points)} 个点）")
    else:
        points = original_points
    
    if len(points) == 0:
        raise ValueError("过滤后几何体为空")
    
    # 计算质心
    centroid = np.mean(points, axis=0)
    
    # 中心化点云
    centered_points = points - centroid
    
    # 计算协方差矩阵
    cov_matrix = np.cov(centered_points.T)
    
    # 计算特征值和特征向量
    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
    
    # 按特征值降序排序
    idx = eigenvalues.argsort()[::-1]
    eigenvalues = eigenvalues[idx]
    eigenvectors = eigenvectors[:, idx]
    
    return centroid, eigenvectors, eigenvalues


def align_orientation(source_geometry, target_geometry, compensate_centroid_offset=True):
    """
    根据主方向对齐两个几何体的方向，并补偿质心偏移
    
    Args:
        source_geometry: 源几何体（点云）
        target_geometry: 目标几何体（模型）
        compensate_centroid_offset: 是否补偿质心偏移（点云缺少部分时有用）
    
    Returns:
        对齐后的源几何体
    """
    print(f"\n🔄 开始方向对齐...")
    
    # 计算主方向（点云先过滤离散点，模型不需要）
    print(f"   计算点云主方向（先过滤离散点）...")
    source_centroid, source_eigenvectors, source_eigenvalues = compute_principal_axes(
        source_geometry, remove_outliers_flag=True
    )
    print(f"   计算模型主方向...")
    target_centroid, target_eigenvectors, target_eigenvalues = compute_principal_axes(
        target_geometry, remove_outliers_flag=False
    )
    
    print(f"   点云质心: [{source_centroid[0]:.4f}, {source_centroid[1]:.4f}, {source_centroid[2]:.4f}]")
    print(f"   模型质心: [{target_centroid[0]:.4f}, {target_centroid[1]:.4f}, {target_centroid[2]:.4f}]")
    print(f"   点云主方向特征值: [{source_eigenvalues[0]:.4f}, {source_eigenvalues[1]:.4f}, {source_eigenvalues[2]:.4f}]")
    print(f"   模型主方向特征值: [{target_eigenvalues[0]:.4f}, {target_eigenvalues[1]:.4f}, {target_eigenvalues[2]:.4f}]")
    
    # 计算质心偏移（在模型的主方向坐标系中）
    centroid_offset = target_centroid - source_centroid
    print(f"   质心偏移: [{centroid_offset[0]:.4f}, {centroid_offset[1]:.4f}, {centroid_offset[2]:.4f}]")
    
    # 计算旋转矩阵，使源几何体的主方向与目标几何体的主方向对齐
    # 使用Kabsch算法计算最优旋转
    # R = V * U^T，其中U是源的主方向，V是目标的主方向
    
    # 确保特征向量构成右手坐标系
    source_basis = source_eigenvectors.copy()
    target_basis = target_eigenvectors.copy()
    
    # 确保行列式为1（右手坐标系）
    if np.linalg.det(source_basis) < 0:
        source_basis[:, -1] *= -1
    if np.linalg.det(target_basis) < 0:
        target_basis[:, -1] *= -1
    
    # 计算旋转矩阵：R = target_basis * source_basis^T
    rotation_matrix = target_basis @ source_basis.T
    
    # 检查是否需要翻转（处理镜像情况）
    if np.linalg.det(rotation_matrix) < 0:
        # 如果行列式为负，翻转最后一个轴
        target_basis[:, -1] *= -1
        rotation_matrix = target_basis @ source_basis.T
    
    print(f"   旋转矩阵:")
    print(f"     [{rotation_matrix[0,0]:.4f}, {rotation_matrix[0,1]:.4f}, {rotation_matrix[0,2]:.4f}]")
    print(f"     [{rotation_matrix[1,0]:.4f}, {rotation_matrix[1,1]:.4f}, {rotation_matrix[1,2]:.4f}]")
    print(f"     [{rotation_matrix[2,0]:.4f}, {rotation_matrix[2,1]:.4f}, {rotation_matrix[2,2]:.4f}]")
    
    # 应用旋转：先移动到原点，旋转，再移回
    if isinstance(source_geometry, o3d.geometry.PointCloud):
        points = np.asarray(source_geometry.points)
        # 移动到原点
        points = points - source_centroid
        # 应用旋转
        points = (rotation_matrix @ points.T).T
        
        # 如果补偿质心偏移，将点云移动到模型质心位置
        # 这样可以补偿点云缺少部分（如炮筒）导致的质心偏移
        if compensate_centroid_offset:
            # 计算旋转后的质心偏移（在主方向坐标系中）
            # 将偏移投影到主方向上，只补偿主要方向的偏移
            offset_in_basis = rotation_matrix @ centroid_offset
            
            # 只补偿主要方向（最大特征值对应的方向）的偏移
            # 这样可以避免过度补偿
            main_axis_idx = np.argmax(target_eigenvalues)
            compensation = target_eigenvectors[:, main_axis_idx] * np.dot(offset_in_basis, target_eigenvectors[:, main_axis_idx])
            
            # 将点云移动到补偿后的位置
            points = points + target_centroid - compensation
            print(f"   💡 已补偿质心偏移（主要方向），补偿量: [{compensation[0]:.4f}, {compensation[1]:.4f}, {compensation[2]:.4f}]")
        else:
            # 不移回原位置，保持旋转后的位置
            points = points + source_centroid
        
        source_geometry.points = o3d.utility.Vector3dVector(points)
    elif isinstance(source_geometry, o3d.geometry.TriangleMesh):
        vertices = np.asarray(source_geometry.vertices)
        # 移动到原点
        vertices = vertices - source_centroid
        # 应用旋转
        vertices = (rotation_matrix @ vertices.T).T
        
        if compensate_centroid_offset:
            offset_in_basis = rotation_matrix @ centroid_offset
            main_axis_idx = np.argmax(target_eigenvalues)
            compensation = target_eigenvectors[:, main_axis_idx] * np.dot(offset_in_basis, target_eigenvectors[:, main_axis_idx])
            vertices = vertices + target_centroid - compensation
        else:
            vertices = vertices + source_centroid
        
        source_geometry.vertices = o3d.utility.Vector3dVector(vertices)
        # 更新法线
        source_geometry.compute_vertex_normals()
    
    print(f"   ✅ 方向对齐完成")
    
    return source_geometry, rotation_matrix


def align_geometries(source_geometry, target_geometry, align_mode='center'):
    """
    对齐两个几何体的位置
    
    Args:
        source_geometry: 源几何体
        target_geometry: 目标几何体
        align_mode: 对齐模式
            - 'center': 中心对齐
            - 'min': 最小边界对齐
            - 'max': 最大边界对齐
    """
    source_bbox = get_bounding_box(source_geometry)
    target_bbox = get_bounding_box(target_geometry)
    
    if align_mode == 'center':
        source_center = source_bbox['center']
        target_center = target_bbox['center']
        translation = target_center - source_center
    elif align_mode == 'min':
        translation = target_bbox['min'] - source_bbox['min']
    elif align_mode == 'max':
        translation = target_bbox['max'] - source_bbox['max']
    else:
        translation = np.array([0, 0, 0])
    
    source_geometry.translate(translation)
    print(f"\n🔄 位置对齐完成 (模式: {align_mode})")
    print(f"   平移向量: [{translation[0]:.4f}, {translation[1]:.4f}, {translation[2]:.4f}]")
    
    return source_geometry


def visualize_comparison(point_cloud, model, save_path=None, model_opacity=0.3, enable_adjustment=True):
    """可视化对比结果，支持交互式调整模型位置和大小"""
    print(f"\n🎨 准备可视化...")
    
    # 获取边界框以设置合适的视角
    pc_bbox = get_bounding_box(point_cloud)
    model_bbox = get_bounding_box(model)
    
    # 计算整体边界框
    all_min = np.minimum(pc_bbox['min'], model_bbox['min'])
    all_max = np.maximum(pc_bbox['max'], model_bbox['max'])
    all_center = (all_min + all_max) / 2
    all_size = all_max - all_min
    max_size = np.max(all_size)
    
    # 设置点云颜色（红色，更醒目）
    point_cloud.paint_uniform_color([1, 0, 0])  # 红色点云
    
    # 为模型设置颜色（创建副本以便调整）
    if isinstance(model, o3d.geometry.TriangleMesh):
        # 使用深拷贝创建副本
        import copy
        model_adjustable = copy.deepcopy(model)
        model_adjustable.paint_uniform_color([0, 0.5, 1])  # 蓝色模型
    else:
        import copy
        model_adjustable = copy.deepcopy(model)
        model_adjustable.paint_uniform_color([0, 0.5, 1])  # 蓝色点云
    
    # 添加坐标轴（根据整体尺寸调整大小）
    coord_frame_size = max_size * 0.1  # 坐标轴大小为整体尺寸的10%
    coord_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=coord_frame_size)
    
    # 准备几何体列表
    geometries = [point_cloud]
    
    # 处理模型：如果是网格，转换为线框模式以便透过看到点云
    if isinstance(model_adjustable, o3d.geometry.TriangleMesh):
        # 创建线框版本（可以透过看到点云）
        wireframe = o3d.geometry.LineSet.create_from_triangle_mesh(model_adjustable)
        wireframe.paint_uniform_color([0, 0.5, 1])  # 蓝色线框
        geometries.append(wireframe)
    else:
        geometries.append(model_adjustable)
    
    geometries.append(coord_frame)
    
    # 交互式调整参数
    class AdjustmentState:
        def __init__(self):
            self.translation = np.array([0.0, 0.0, 0.0])  # 平移量
            self.scale_factor = 1.0  # 缩放因子
            # 增大步长，使调整更明显
            self.step_size = max_size * 0.05  # 平移步长（整体尺寸的5%，原来是1%）
            self.scale_step = 0.05  # 缩放步长（5%，原来是1%）
            import copy
            self.model_original = copy.deepcopy(model_adjustable)  # 保存原始模型
            self.wireframe = wireframe if isinstance(model_adjustable, o3d.geometry.TriangleMesh) else None
            self.wireframe_id = None  # 保存线框的ID
    
    adjustment = AdjustmentState()
    
    # 键盘回调函数 - 处理按键逻辑
    def handle_key_action(key_code, key_name):
        """处理按键动作的通用函数"""
        # 平移控制（WASD + QE）
        if key_code == ord('W') or key_code == ord('w'):
            adjustment.translation[1] += adjustment.step_size  # Y轴向上
            print(f"   ⬆️  模型向上移动: {adjustment.translation[1]:.4f} (步长: {adjustment.step_size:.4f})")
        elif key_code == ord('S') or key_code == ord('s'):
            adjustment.translation[1] -= adjustment.step_size  # Y轴向下
            print(f"   ⬇️  模型向下移动: {adjustment.translation[1]:.4f} (步长: {adjustment.step_size:.4f})")
        elif key_code == ord('A') or key_code == ord('a'):
            adjustment.translation[0] -= adjustment.step_size  # X轴向左
            print(f"   ⬅️  模型向左移动: {adjustment.translation[0]:.4f} (步长: {adjustment.step_size:.4f})")
        elif key_code == ord('D') or key_code == ord('d'):
            adjustment.translation[0] += adjustment.step_size  # X轴向右
            print(f"   ➡️  模型向右移动: {adjustment.translation[0]:.4f} (步长: {adjustment.step_size:.4f})")
        elif key_code == ord('Q') or key_code == ord('q'):
            adjustment.translation[2] += adjustment.step_size  # Z轴向前
            print(f"   🔼 模型向前移动: {adjustment.translation[2]:.4f} (步长: {adjustment.step_size:.4f})")
        elif key_code == ord('E') or key_code == ord('e'):
            adjustment.translation[2] -= adjustment.step_size  # Z轴向后
            print(f"   🔽 模型向后移动: {adjustment.translation[2]:.4f} (步长: {adjustment.step_size:.4f})")
        
        # 缩放控制（+/- 或 =/-）
        elif key_code == ord('+') or key_code == ord('='):
            adjustment.scale_factor += adjustment.scale_step
            print(f"   🔍 模型放大: {adjustment.scale_factor:.4f} (步长: {adjustment.scale_step:.4f})")
        elif key_code == ord('-') or key_code == ord('_'):
            adjustment.scale_factor = max(0.1, adjustment.scale_factor - adjustment.scale_step)
            print(f"   🔎 模型缩小: {adjustment.scale_factor:.4f} (步长: {adjustment.scale_step:.4f})")
        
        # 重置
        elif key_code == ord('R') or key_code == ord('r'):
            adjustment.translation = np.array([0.0, 0.0, 0.0])
            adjustment.scale_factor = 1.0
            print(f"   🔄 重置调整参数")
        else:
            return False
        
        # 应用变换
        # 重置模型到原始状态（每次调整都从原始状态开始）
        if isinstance(model_adjustable, o3d.geometry.TriangleMesh):
            model_adjustable.vertices = copy.deepcopy(adjustment.model_original.vertices)
            model_adjustable.triangles = copy.deepcopy(adjustment.model_original.triangles)
        else:
            model_adjustable.points = copy.deepcopy(adjustment.model_original.points)
        
        # 应用缩放
        if adjustment.scale_factor != 1.0:
            model_center = model_adjustable.get_axis_aligned_bounding_box().get_center()
            model_adjustable.translate(-model_center)
            model_adjustable.scale(adjustment.scale_factor, center=(0, 0, 0))
            model_adjustable.translate(model_center)
        
        # 应用平移
        if np.any(adjustment.translation != 0):
            model_adjustable.translate(adjustment.translation)
        
        return True
    
    # 创建按键回调函数工厂
    def create_key_callback(key_code, key_name):
        """为每个按键创建独立的回调函数"""
        def callback(*args, **kwargs):
            """按键回调函数 - 兼容不同的Open3D版本"""
            # 解析参数 - Open3D可能传递 (vis_obj, key, action) 或只传递 (vis_obj)
            vis_obj = args[0] if len(args) > 0 else kwargs.get('vis_obj')
            key = args[1] if len(args) > 1 else kwargs.get('key', key_code)
            action = args[2] if len(args) > 2 else kwargs.get('action', 1)
            
            # 打印调试信息
            print(f"   🔑 检测到按键: {key_name} (key={key}, action={action}, args={len(args)})")
            
            # 只处理按键按下事件
            if action != 1:
                return False
            
            # 处理按键动作（使用已知的key_code，不依赖参数中的key）
            if handle_key_action(key_code, key_name):
                # 更新线框
                if adjustment.wireframe is not None:
                    # 移除旧的线框
                    try:
                        vis_obj.remove_geometry(adjustment.wireframe, reset_bounding_box=False)
                    except:
                        pass
                    
                    # 创建新的线框
                    adjustment.wireframe = o3d.geometry.LineSet.create_from_triangle_mesh(model_adjustable)
                    adjustment.wireframe.paint_uniform_color([0, 0.5, 1])
                    vis_obj.add_geometry(adjustment.wireframe, reset_bounding_box=False)
                    print(f"   ✅ 线框已更新")
                else:
                    vis_obj.update_geometry(model_adjustable, reset_bounding_box=False)
                    print(f"   ✅ 模型已更新")
                
                vis_obj.poll_events()
                vis_obj.update_renderer()
                return True
            
            return False
        
        return callback
    
    # 自定义渲染函数
    def custom_draw_geometry_with_adjustment(geometries):
        """自定义渲染函数，支持交互式调整"""
        vis = o3d.visualization.VisualizerWithKeyCallback()
        vis.create_window(window_name="点云与模型对比（按H查看帮助）", width=1920, height=1080)
        
        # 先添加几何体
        for geom in geometries:
            vis.add_geometry(geom)
        
        # 保存线框的引用（如果存在）
        if adjustment.wireframe is not None:
            adjustment.wireframe_id = len(geometries) - 1  # 线框是倒数第二个
        
        # 注册键盘回调 - 为每个按键创建独立的回调函数
        key_mappings = [
            (ord('W'), 'W'), (ord('w'), 'w'),
            (ord('S'), 'S'), (ord('s'), 's'),
            (ord('A'), 'A'), (ord('a'), 'a'),
            (ord('D'), 'D'), (ord('d'), 'd'),
            (ord('Q'), 'Q'), (ord('q'), 'q'),
            (ord('E'), 'E'), (ord('e'), 'e'),
            (ord('+'), '+'), (ord('='), '='),
            (ord('-'), '-'), (ord('_'), '_'),
            (ord('R'), 'R'), (ord('r'), 'r'),
        ]
        
        try:
            for key_code, key_name in key_mappings:
                callback = create_key_callback(key_code, key_name)
                vis.register_key_callback(key_code, callback)
        except Exception as e:
            print(f"   ⚠️  注册键盘回调时出错: {e}")
            print(f"   将使用非交互模式")
        
        print(f"   ✅ 键盘回调已注册（步长: 平移={adjustment.step_size:.4f}, 缩放={adjustment.scale_step:.4f}）")
        
        # 设置渲染选项
        render_option = vis.get_render_option()
        point_size = max(2.0, min(10.0, max_size * 0.01))
        render_option.point_size = point_size
        render_option.background_color = np.array([1.0, 1.0, 1.0])
        
        if isinstance(model_adjustable, o3d.geometry.TriangleMesh):
            render_option.mesh_show_wireframe = True
            render_option.mesh_show_back_face = True
        
        # 设置视角
        view_control = vis.get_view_control()
        view_control.set_front([0, 0, -1])
        view_control.set_lookat(all_center)
        view_control.set_up([0, 1, 0])
        view_control.set_zoom(0.7)
        
        print(f"   ✅ 可视化窗口已打开")
        print(f"   📊 整体边界框尺寸: [{all_size[0]:.4f}, {all_size[1]:.4f}, {all_size[2]:.4f}]")
        print(f"   📍 整体中心: [{all_center[0]:.4f}, {all_center[1]:.4f}, {all_center[2]:.4f}]")
        print(f"\n   🎮 交互式调整控制:")
        print(f"      📍 位置调整:")
        print(f"         W/S - 上/下移动")
        print(f"         A/D - 左/右移动")
        print(f"         Q/E - 前/后移动")
        print(f"      📏 大小调整:")
        print(f"         +/- - 放大/缩小模型")
        print(f"      🔄 其他:")
        print(f"         R - 重置所有调整")
        print(f"      💡 鼠标操作:")
        print(f"         左键拖拽 - 旋转视角")
        print(f"         右键拖拽 - 平移视角")
        print(f"         滚轮 - 缩放视角")
        print(f"   🔴 红色 = 点云, 🔵 蓝色线框 = 模型")
        
        if save_path:
            vis.capture_screen_image(save_path, do_render=True)
            print(f"   ✅ 截图已保存: {save_path}")
        
        vis.run()
        vis.destroy_window()
        
        # 返回调整后的模型
        return model_adjustable, adjustment.translation, adjustment.scale_factor
    
    # 调用自定义渲染函数
    if enable_adjustment:
        adjusted_model, final_translation, final_scale = custom_draw_geometry_with_adjustment(geometries)
        print(f"\n   📊 最终调整参数:")
        print(f"      平移: [{final_translation[0]:.4f}, {final_translation[1]:.4f}, {final_translation[2]:.4f}]")
        print(f"      缩放: {final_scale:.4f}")
        return adjusted_model, final_translation, final_scale
    else:
        # 非交互模式
        def simple_draw(geometries):
            vis = o3d.visualization.Visualizer()
            vis.create_window(window_name="点云与模型对比", width=1920, height=1080)
            for geom in geometries:
                vis.add_geometry(geom)
            render_option = vis.get_render_option()
            render_option.point_size = max(2.0, min(10.0, max_size * 0.01))
            render_option.background_color = np.array([1.0, 1.0, 1.0])
            if isinstance(model_adjustable, o3d.geometry.TriangleMesh):
                render_option.mesh_show_wireframe = True
            view_control = vis.get_view_control()
            view_control.set_front([0, 0, -1])
            view_control.set_lookat(all_center)
            view_control.set_up([0, 1, 0])
            view_control.set_zoom(0.7)
            if save_path:
                vis.capture_screen_image(save_path, do_render=True)
            vis.run()
            vis.destroy_window()
        simple_draw(geometries)
        return model_adjustable, np.array([0.0, 0.0, 0.0]), 1.0


def save_aligned_point_cloud(point_cloud, output_path):
    """保存对齐后的点云"""
    print(f"\n💾 保存对齐后的点云: {output_path}")
    o3d.io.write_point_cloud(output_path, point_cloud)
    print(f"   ✅ 保存成功")


def main():
    parser = argparse.ArgumentParser(description='点云与3D模型对比工具')
    parser.add_argument('--pointcloud', '-p', type=str, required=True,
                        help='目标点云文件路径 (.ply)')
    parser.add_argument('--model', '-m', type=str, required=True,
                        help='T72模型文件路径 (.ply, .obj, .stl)')
    parser.add_argument('--scale-mode', type=str, default='fit',
                        choices=['fit', 'match_x', 'match_y', 'match_z', 'none'],
                        help='缩放模式: fit(匹配最大尺寸), match_x/y/z(匹配特定轴), none(不缩放)')
    parser.add_argument('--scale-factor', type=float, default=None,
                        help='自定义缩放因子（如果指定，将覆盖scale-mode）')
    parser.add_argument('--scale-what', type=str, default='auto',
                        choices=['auto', 'pointcloud', 'model'],
                        help='缩放哪个对象: auto(自动选择), pointcloud(缩放点云), model(缩放模型)')
    parser.add_argument('--align-mode', type=str, default='center',
                        choices=['center', 'min', 'max'],
                        help='对齐模式: center(中心对齐), min(最小边界对齐), max(最大边界对齐)')
    parser.add_argument('--output', '-o', type=str, default=None,
                        help='输出对齐后的点云路径（可选）')
    parser.add_argument('--save-screenshot', type=str, default=None,
                        help='保存截图路径（可选）')
    parser.add_argument('--no-visualization', action='store_true',
                        help='不显示可视化窗口')
    parser.add_argument('--model-opacity', type=float, default=0.3,
                        help='模型透明度（0.0-1.0，0.0完全透明，1.0不透明）')
    parser.add_argument('--wireframe', action='store_true',
                        help='使用线框模式显示模型（便于观察内部点云）')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("🔍 点云与3D模型对比工具")
    print("=" * 60)
    
    # 加载点云和模型
    try:
        point_cloud = load_point_cloud(args.pointcloud)
        model = load_model(args.model)
    except Exception as e:
        print(f"❌ 错误: {e}")
        return
    
    # 步骤1: 方向对齐（根据主方向）
    print(f"\n" + "=" * 60)
    print("步骤1: 方向对齐（补偿质心偏移）")
    print("=" * 60)
    # 补偿质心偏移，适用于点云缺少部分（如炮筒）的情况
    point_cloud, rotation_matrix = align_orientation(point_cloud, model, compensate_centroid_offset=True)
    
    # 获取边界框信息（对齐方向后，点云先过滤离散点）
    print(f"\n📐 计算边界框（点云先过滤离散点）...")
    pc_bbox = get_bounding_box(point_cloud, remove_outliers_flag=True)
    model_bbox = get_bounding_box(model, remove_outliers_flag=False)
    
    # 步骤2: 计算缩放因子
    print(f"\n" + "=" * 60)
    print("步骤2: 尺寸缩放")
    print("=" * 60)
    scale_target = 'pointcloud'  # 默认缩放点云
    if args.scale_factor is not None:
        scale_factor = args.scale_factor
        scale_target = 'pointcloud'  # 自定义缩放因子默认缩放点云
        print(f"\n📐 使用自定义缩放因子: {scale_factor:.6f}")
    elif args.scale_mode != 'none':
        # 获取scale_what参数（如果存在）
        scale_what = getattr(args, 'scale_what', 'auto')
        scale_factor, scale_target = calculate_scale_factor(pc_bbox, model_bbox, args.scale_mode, scale_what)
    else:
        scale_factor = 1.0
        print(f"\n📐 不进行缩放")
    
    # 根据缩放目标缩放相应的几何体
    if scale_factor != 1.0:
        if scale_target == 'pointcloud':
            print(f"\n🔄 缩放点云 (因子: {scale_factor:.6f})...")
            pc_center = pc_bbox['center']
            point_cloud = scale_geometry(point_cloud, scale_factor, pc_center)
            print(f"   ✅ 缩放完成")
            
            # 更新边界框
            pc_bbox = get_bounding_box(point_cloud)
            print(f"   缩放后点云尺寸: [{pc_bbox['size'][0]:.4f}, {pc_bbox['size'][1]:.4f}, {pc_bbox['size'][2]:.4f}]")
        else:  # scale_target == 'model'
            print(f"\n🔄 缩放模型 (因子: {scale_factor:.6f})...")
            model_center = model_bbox['center']
            model = scale_geometry(model, scale_factor, model_center)
            print(f"   ✅ 缩放完成")
            
            # 更新边界框
            model_bbox = get_bounding_box(model)
            print(f"   缩放后模型尺寸: [{model_bbox['size'][0]:.4f}, {model_bbox['size'][1]:.4f}, {model_bbox['size'][2]:.4f}]")
    
    # 步骤3: 位置对齐
    print(f"\n" + "=" * 60)
    print("步骤3: 位置对齐")
    print("=" * 60)
    point_cloud = align_geometries(point_cloud, model, args.align_mode)
    
    # 保存对齐后的点云
    if args.output:
        save_aligned_point_cloud(point_cloud, args.output)
    
    # 可视化（支持交互式调整）
    if not args.no_visualization:
        adjusted_model, final_translation, final_scale = visualize_comparison(
            point_cloud, model, args.save_screenshot, 
            model_opacity=args.model_opacity,
            enable_adjustment=True
        )
        
        # 如果用户进行了调整，询问是否保存调整后的模型
        if np.any(final_translation != 0) or final_scale != 1.0:
            print(f"\n💾 检测到模型调整，调整参数:")
            print(f"   平移: [{final_translation[0]:.4f}, {final_translation[1]:.4f}, {final_translation[2]:.4f}]")
            print(f"   缩放: {final_scale:.4f}")
            if args.output:
                # 保存调整后的模型（如果输出路径指定）
                model_output_path = args.output.replace('.ply', '_adjusted_model.ply')
                if isinstance(adjusted_model, o3d.geometry.TriangleMesh):
                    o3d.io.write_triangle_mesh(model_output_path, adjusted_model)
                else:
                    o3d.io.write_point_cloud(model_output_path, adjusted_model)
                print(f"   ✅ 调整后的模型已保存: {model_output_path}")
    elif args.save_screenshot:
        # 即使不显示窗口，也创建可视化来截图
        vis = o3d.visualization.Visualizer()
        vis.create_window(visible=False)
        vis.add_geometry(point_cloud)
        vis.add_geometry(model)
        vis.capture_screen_image(args.save_screenshot, do_render=True)
        vis.destroy_window()
        print(f"   ✅ 截图已保存: {args.save_screenshot}")
    
    print("\n" + "=" * 60)
    print("✅ 处理完成！")
    print("=" * 60)


if __name__ == '__main__':
    main()

