#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
分析Gaussian Splatting最终训练成果的尺寸比例
"""

import os
import sys

def analyze_final_pointcloud():
    """分析最终训练成果的目标点云尺寸比例"""

    # 尝试导入必要的模块
    try:
        import numpy as np
    except ImportError:
        print("错误: 需要安装numpy")
        print("请运行: pip install numpy")
        return

    try:
        import plyfile
    except ImportError:
        print("错误: 需要安装plyfile")
        print("请运行: pip install plyfile")
        return

    # 查找目标点云文件
    possible_paths = [
        r'output\V1\point_cloud\iteration_30000\point_cloud_target_only.ply',
        r'output\V1\point_cloud\iteration_30000\point_cloud_target_only_30000.ply',
        r'output\V1\point_cloud\iteration_30000\point_cloud.ply'
    ]

    ply_path = None
    for path in possible_paths:
        if os.path.exists(path):
            ply_path = path
            break

    if not ply_path:
        print("错误: 找不到目标点云文件")
        print("搜索路径:")
        for path in possible_paths:
            print(f"  - {path}")
        return

    print(f"📂 正在分析文件: {ply_path}")

    try:
        # 读取PLY文件
        plydata = plyfile.PlyData.read(ply_path)

        # 获取点云坐标
        x = plydata['vertex']['x']
        y = plydata['vertex']['y']
        z = plydata['vertex']['z']

        points = np.column_stack([x, y, z])

        # 计算边界框
        min_coords = points.min(axis=0)
        max_coords = points.max(axis=0)
        bbox_size = max_coords - min_coords

        # 在COLMAP坐标系中：X=右，Y=下(高度)，Z=前
        length = bbox_size[0]  # X方向长度
        height = bbox_size[1]  # Y方向高度
        width = bbox_size[2]   # Z方向宽度

        # 计算比例
        eps = 1e-8
        h_l_ratio = abs(height) / (length + eps)
        h_w_ratio = abs(height) / (width + eps)
        l_w_ratio = length / (width + eps)

        print("\n" + "="*70)
        print("🎯 最终训练成果 - 目标尺寸比例")
        print("="*70)
        print(f"   点云尺寸: H={abs(height):.3f}, L={length:.3f}, W={width:.3f}")
        print(f"   总点数: {len(points):,}")
        print()
        print("   📏 尺寸比例:")
        print(f"   高度/长度比例 (H/L): {h_l_ratio:.4f}")
        print(f"   高度/宽度比例 (H/W): {h_w_ratio:.4f}")
        print(f"   长度/宽度比例 (L/W): {l_w_ratio:.4f}")

        # 从约束文件中读取目标值进行比较
        target_h_l = 0.4577  # 从约束文件中的推荐值
        target_h_w = 0.7736
        target_l_w = 1.7612

        print("\n📊 与SFM约束比较:")
        print(f"   目标H/L: {target_h_l:.4f} (实际: {h_l_ratio:.4f}) 差异: {abs(h_l_ratio-target_h_l):.4f}")
        print(f"   目标H/W: {target_h_w:.4f} (实际: {h_w_ratio:.4f}) 差异: {abs(h_w_ratio-target_h_w):.4f}")
        print(f"   目标L/W: {target_l_w:.4f} (实际: {l_w_ratio:.4f}) 差异: {abs(l_w_ratio-target_l_w):.4f}")

        # 计算匹配度
        h_l_match = 1.0 - min(abs(h_l_ratio - target_h_l) / target_h_l, 1.0)
        h_w_match = 1.0 - min(abs(h_w_ratio - target_h_w) / target_h_w, 1.0)
        l_w_match = 1.0 - min(abs(l_w_ratio - target_l_w) / target_l_w, 1.0)
        avg_match = (h_l_match + h_w_match + l_w_match) / 3.0

        print("\n✅ 约束匹配度:")
        print(f"   H/L匹配度: {h_l_match:.1%}")
        print(f"   H/W匹配度: {h_w_match:.1%}")
        print(f"   L/W匹配度: {l_w_match:.1%}")
        print(f"   平均匹配度: {avg_match:.1%}")

        print("\n" + "="*70)

    except Exception as e:
        print(f"错误: 读取PLY文件时出错: {e}")

if __name__ == "__main__":
    analyze_final_pointcloud()
