#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
简单分析最终训练成果的尺寸比例
"""

import os
import struct

def analyze_ply_bbox():
    """分析PLY文件的边界框"""

    ply_path = r'output\V1\point_cloud\iteration_30000\point_cloud_target_only.ply'

    if not os.path.exists(ply_path):
        print(f"错误: 找不到文件 {ply_path}")
        return

    print(f"📂 正在分析文件: {ply_path}")

    try:
        with open(ply_path, 'rb') as f:
            # 读取头部
            header_lines = []
            while True:
                line = f.readline().decode('utf-8').strip()
                header_lines.append(line)
                if line == 'end_header':
                    break

            # 解析顶点数量
            vertex_count = 0
            for line in header_lines:
                if line.startswith('element vertex'):
                    vertex_count = int(line.split()[-1])
                    break

            print(f"   顶点数量: {vertex_count}")

            # 每个顶点有15个float (x,y,z,nx,ny,nz,f_dc_0,f_dc_1,f_dc_2,f_rest_0-7)
            vertex_size = 15 * 4  # 15 floats * 4 bytes each

            # 读取所有顶点数据
            vertices = []
            for i in range(vertex_count):
                vertex_data = f.read(vertex_size)
                if len(vertex_data) != vertex_size:
                    break

                # 解包前3个float (x, y, z)
                x, y, z = struct.unpack('<fff', vertex_data[:12])
                vertices.append((x, y, z))

            if not vertices:
                print("错误: 无法读取顶点数据")
                return

            # 计算边界框
            xs = [v[0] for v in vertices]
            ys = [v[1] for v in vertices]
            zs = [v[2] for v in vertices]

            min_x, max_x = min(xs), max(xs)
            min_y, max_y = min(ys), max(ys)
            min_z, max_z = min(zs), max(zs)

            # 在COLMAP坐标系中：X=右，Y=下(高度)，Z=前
            length = max_x - min_x  # X方向长度
            height = max_y - min_y  # Y方向高度
            width = max_z - min_z   # Z方向宽度

            # 计算比例
            eps = 1e-8
            h_l_ratio = abs(height) / (length + eps)
            h_w_ratio = abs(height) / (width + eps)
            l_w_ratio = length / (width + eps)

            print("\n" + "="*70)
            print("🎯 最终训练成果 - 目标尺寸比例")
            print("="*70)
            print(f"   点云尺寸: H={abs(height):.3f}, L={length:.3f}, W={width:.3f}")
            print(f"   总点数: {len(vertices):,}")
            print()
            print("   📏 尺寸比例:")
            print(f"   高度/长度比例 (H/L): {h_l_ratio:.4f}")
            print(f"   高度/宽度比例 (H/W): {h_w_ratio:.4f}")
            print(f"   长度/宽度比例 (L/W): {l_w_ratio:.4f}")

            # 从约束文件中读取目标值进行比较
            target_h_l = 0.4577  # 从约束文件中的推荐值
            target_h_w = 0.7736
            target_l_w = 1.7612

            print("\n📊 与SFM约束比较:")
            print(f"   目标H/L: {target_h_l:.4f} (实际: {h_l_ratio:.4f}) 差异: {abs(h_l_ratio-target_h_l):.4f}")
            print(f"   目标H/W: {target_h_w:.4f} (实际: {h_w_ratio:.4f}) 差异: {abs(h_w_ratio-target_h_w):.4f}")
            print(f"   目标L/W: {target_l_w:.4f} (实际: {l_w_ratio:.4f}) 差异: {abs(l_w_ratio-target_l_w):.4f}")

            # 计算匹配度
            h_l_match = 1.0 - min(abs(h_l_ratio - target_h_l) / target_h_l, 1.0)
            h_w_match = 1.0 - min(abs(h_w_ratio - target_h_w) / target_h_w, 1.0)
            l_w_match = 1.0 - min(abs(l_w_ratio - target_l_w) / target_l_w, 1.0)
            avg_match = (h_l_match + h_w_match + l_w_match) / 3.0

            print("\n✅ 约束匹配度:")
            print(".1%")
            print(".1%")
            print(".1%")
            print(".1%")

            print("\n" + "="*70)

    except Exception as e:
        print(f"错误: 处理PLY文件时出错: {e}")

if __name__ == "__main__":
    analyze_ply_bbox()
