#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
伪彩色图像转灰度图像工具

支持多种转换方法：
1. RGB加权平均（标准方法）
2. 反向colormap映射（如果知道使用的colormap）
3. 亮度提取（从HSV色彩空间）
4. 自适应方法（自动选择最佳方法）

支持的图像格式：PNG, JPG, JPEG, TIFF, BMP等
"""

import os
import numpy as np
from PIL import Image
import argparse
from pathlib import Path


def rgb_to_grayscale_weighted(rgb_image):
    """
    使用加权平均将RGB图像转换为灰度图像（ITU-R BT.601标准）
    
    Args:
        rgb_image: numpy数组，形状为(H, W, 3)，dtype为uint8或float
    
    Returns:
        grayscale: numpy数组，形状为(H, W)，dtype与输入相同
    """
    if rgb_image.dtype == np.uint8:
        weights = np.array([0.299, 0.587, 0.114], dtype=np.float32)
        grayscale = np.dot(rgb_image.astype(np.float32), weights).astype(np.uint8)
    else:
        weights = np.array([0.299, 0.587, 0.114], dtype=np.float32)
        grayscale = np.dot(rgb_image, weights)
    
    return grayscale


def rgb_to_grayscale_from_hsv(rgb_image):
    """
    从HSV色彩空间提取亮度（Value）通道作为灰度图像
    
    Args:
        rgb_image: numpy数组，形状为(H, W, 3)
    
    Returns:
        grayscale: numpy数组，形状为(H, W)
    """
    from PIL import Image
    
    # 将numpy数组转换为PIL Image
    if rgb_image.dtype != np.uint8:
        rgb_image = (rgb_image * 255).astype(np.uint8)
    
    img_pil = Image.fromarray(rgb_image, mode='RGB')
    img_hsv = img_pil.convert('HSV')
    
    # 提取V通道（亮度）
    hsv_array = np.array(img_hsv)
    grayscale = hsv_array[:, :, 2]  # V通道
    
    return grayscale


def rgb_to_grayscale_from_lab(rgb_image):
    """
    从LAB色彩空间提取亮度（L）通道作为灰度图像
    
    LAB色彩空间的L通道更接近人眼感知的亮度，通常比HSV的V通道更准确
    
    Args:
        rgb_image: numpy数组，形状为(H, W, 3)
    
    Returns:
        grayscale: numpy数组，形状为(H, W)
    """
    from PIL import Image
    
    # 将numpy数组转换为PIL Image
    if rgb_image.dtype != np.uint8:
        rgb_image = (rgb_image * 255).astype(np.uint8)
    
    img_pil = Image.fromarray(rgb_image, mode='RGB')
    
    # 转换为LAB色彩空间
    try:
        img_lab = img_pil.convert('LAB')
        lab_array = np.array(img_lab)
        # 提取L通道（亮度）
        grayscale = lab_array[:, :, 0]  # L通道
    except:
        # 如果LAB转换失败，回退到HSV
        return rgb_to_grayscale_from_hsv(rgb_image)
    
    return grayscale


def reverse_colormap_mapping(rgb_image, colormap_name='jet', use_improved=True):
    """
    反向colormap映射：尝试从RGB颜色反向映射回原始数据值
    
    改进版本：使用更高精度的查找表和优化的搜索算法
    
    Args:
        rgb_image: numpy数组，形状为(H, W, 3)
        colormap_name: colormap名称，如'jet', 'viridis', 'plasma', 'hot'等
        use_improved: 是否使用改进的高精度方法（默认True）
    
    Returns:
        grayscale: numpy数组，形状为(H, W)，值在0-255范围内
    """
    try:
        import matplotlib.pyplot as plt
        import matplotlib.colors as mcolors
    except ImportError:
        print("警告：需要matplotlib库进行反向colormap映射，使用标准RGB到灰度转换")
        return rgb_to_grayscale_weighted(rgb_image)
    
    try:
        # 获取colormap
        if isinstance(colormap_name, str):
            cmap = plt.get_cmap(colormap_name)
        else:
            cmap = colormap_name
        
        # 归一化RGB到[0, 1]
        if rgb_image.dtype == np.uint8:
            rgb_normalized = rgb_image.astype(np.float32) / 255.0
        else:
            rgb_normalized = np.clip(rgb_image, 0, 1)
        
        height, width = rgb_normalized.shape[:2]
        total_pixels = height * width
        
        if use_improved:
            # 改进方法：使用更高精度的查找表（1024个值）
            # 对于大图像，使用分块处理以避免内存问题
            lookup_size = 1024
            colormap_values = np.linspace(0, 1, lookup_size)
            colormap_colors = cmap(colormap_values)[:, :3]  # 只取RGB，忽略alpha
            
            # 将RGB图像展平
            rgb_flat = rgb_normalized.reshape(-1, 3)
            
            # 计算分块大小：确保每块不超过50万像素，避免内存溢出
            # 对于1024个colormap值，每块50万像素需要约2GB内存（float32）
            # 可以根据可用内存调整这个值
            chunk_size = min(500000, total_pixels)  # 每块最多50万像素
            
            if total_pixels > chunk_size:
                # 大图像：使用分块处理
                grayscale_flat = np.zeros(total_pixels, dtype=np.float32)
                num_chunks = (total_pixels + chunk_size - 1) // chunk_size
                
                # 预计算colormap颜色的平方和（用于优化距离计算）
                colormap_sq_sum = np.sum(colormap_colors ** 2, axis=1)  # (M,)
                
                for i in range(num_chunks):
                    start_idx = i * chunk_size
                    end_idx = min((i + 1) * chunk_size, total_pixels)
                    chunk_rgb = rgb_flat[start_idx:end_idx]
                    chunk_size_actual = end_idx - start_idx
                    
                    # 优化方法：使用矩阵乘法计算距离
                    # 距离^2 = ||rgb - cmap||^2 = ||rgb||^2 + ||cmap||^2 - 2*rgb·cmap
                    chunk_rgb_sq_sum = np.sum(chunk_rgb ** 2, axis=1, keepdims=True)  # (N, 1)
                    
                    # 计算点积：chunk_rgb @ colormap_colors^T
                    dot_product = np.dot(chunk_rgb, colormap_colors.T)  # (N, M)
                    
                    # 计算距离平方
                    chunk_distances = chunk_rgb_sq_sum + colormap_sq_sum - 2 * dot_product  # (N, M)
                    
                    # 找到每个像素最接近的colormap索引
                    closest_indices = np.argmin(chunk_distances, axis=1)
                    
                    # 映射回灰度值
                    grayscale_flat[start_idx:end_idx] = colormap_values[closest_indices]
                    
                    # 显示进度（对于大图像）
                    if num_chunks > 1 and (i + 1) % max(1, num_chunks // 10) == 0:
                        print(f"  处理进度: {i + 1}/{num_chunks} 块 ({100 * (i + 1) // num_chunks}%)")
                
                grayscale = grayscale_flat.reshape(height, width)
            else:
                # 小图像：直接使用向量化操作
                # 向量化计算：计算每个像素与所有colormap颜色的距离
                # 使用广播机制
                rgb_flat_expanded = rgb_flat[:, np.newaxis, :]  # (N, 1, 3)
                colormap_colors_expanded = colormap_colors[np.newaxis, :, :]  # (1, M, 3)
                
                # 计算欧氏距离（使用L2距离）
                distances = np.sum((rgb_flat_expanded - colormap_colors_expanded) ** 2, axis=2)  # (N, M)
                
                # 找到每个像素最接近的colormap索引
                closest_indices = np.argmin(distances, axis=1)  # (N,)
                
                # 映射回灰度值
                grayscale_flat = colormap_values[closest_indices]
                grayscale = grayscale_flat.reshape(height, width)
        else:
            # 原始方法（保留作为备选）
            grayscale = np.zeros((height, width), dtype=np.float32)
            colormap_values = np.linspace(0, 1, 256)
            colormap_colors = cmap(colormap_values)[:, :3]
            
            rgb_flat = rgb_normalized.reshape(-1, 3)
            
            # 对于大图像，也使用分块处理
            chunk_size = 100000  # 每块10万像素
            if total_pixels > chunk_size:
                num_chunks = (total_pixels + chunk_size - 1) // chunk_size
                for chunk_idx in range(num_chunks):
                    start_idx = chunk_idx * chunk_size
                    end_idx = min((chunk_idx + 1) * chunk_size, total_pixels)
                    chunk_rgb = rgb_flat[start_idx:end_idx]
                    
                    # 使用向量化计算chunk中所有像素的距离
                    chunk_distances = np.zeros((end_idx - start_idx, 256), dtype=np.float32)
                    for j in range(256):
                        diff = chunk_rgb - colormap_colors[j]
                        chunk_distances[:, j] = np.sum(diff ** 2, axis=1)
                    
                    closest_indices = np.argmin(chunk_distances, axis=1)
                    for local_idx, global_idx in enumerate(range(start_idx, end_idx)):
                        grayscale.flat[global_idx] = colormap_values[closest_indices[local_idx]]
                    
                    # 显示进度
                    if num_chunks > 1 and (chunk_idx + 1) % max(1, num_chunks // 10) == 0:
                        print(f"  处理进度: {chunk_idx + 1}/{num_chunks} 块 ({100 * (chunk_idx + 1) // num_chunks}%)")
            else:
                # 小图像：逐个像素处理
                for i, rgb_pixel in enumerate(rgb_flat):
                    distances = np.sum((colormap_colors - rgb_pixel) ** 2, axis=1)
                    closest_idx = np.argmin(distances)
                    grayscale.flat[i] = colormap_values[closest_idx]
        
        # 转换到0-255范围
        grayscale = (grayscale * 255).astype(np.uint8)
        
        return grayscale
    
    except Exception as e:
        print(f"警告：反向colormap映射失败 ({e})，使用标准RGB到灰度转换")
        return rgb_to_grayscale_weighted(rgb_image)


def auto_detect_colormap(rgb_image):
    """
    自动检测伪彩色图像使用的colormap
    
    Args:
        rgb_image: numpy数组，形状为(H, W, 3)
    
    Returns:
        best_colormap: 最佳匹配的colormap名称，如果无法确定则返回None
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    
    # 归一化RGB
    if rgb_image.dtype == np.uint8:
        rgb_normalized = rgb_image.astype(np.float32) / 255.0
    else:
        rgb_normalized = np.clip(rgb_image, 0, 1)
    
    # 常见的colormap列表
    colormap_candidates = ['jet', 'viridis', 'plasma', 'hot', 'cool', 'rainbow', 
                          'turbo', 'inferno', 'magma', 'cividis', 'parula']
    
    best_match = None
    best_score = float('inf')
    
    # 采样图像中的一些像素点进行匹配（提高速度）
    height, width = rgb_normalized.shape[:2]
    sample_size = min(1000, height * width)
    sample_indices = np.random.choice(height * width, sample_size, replace=False)
    rgb_samples = rgb_normalized.reshape(-1, 3)[sample_indices]
    
    for cmap_name in colormap_candidates:
        try:
            cmap = plt.get_cmap(cmap_name)
            # 创建colormap查找表
            colormap_values = np.linspace(0, 1, 256)
            colormap_colors = cmap(colormap_values)[:, :3]
            
            # 计算样本像素与colormap的平均距离
            rgb_samples_expanded = rgb_samples[:, np.newaxis, :]
            colormap_colors_expanded = colormap_colors[np.newaxis, :, :]
            distances = np.sum((rgb_samples_expanded - colormap_colors_expanded) ** 2, axis=2)
            min_distances = np.min(distances, axis=1)
            avg_distance = np.mean(min_distances)
            
            if avg_distance < best_score:
                best_score = avg_distance
                best_match = cmap_name
        except:
            continue
    
    # 如果平均距离太大，可能不是伪彩色图像
    if best_score > 0.1:  # 阈值可调
        return None
    
    return best_match


def adaptive_convert_to_grayscale(rgb_image):
    """
    自适应方法：根据图像特征自动选择最佳转换方法
    
    改进版本：自动检测colormap并尝试多种方法，选择最佳结果
    
    Args:
        rgb_image: numpy数组，形状为(H, W, 3)
    
    Returns:
        grayscale: numpy数组，形状为(H, W)
    """
    # 方法1：尝试自动检测colormap并反向映射
    detected_colormap = auto_detect_colormap(rgb_image)
    if detected_colormap:
        try:
            grayscale_colormap = reverse_colormap_mapping(rgb_image, detected_colormap, use_improved=True)
            # 如果成功，优先使用此方法
            return grayscale_colormap
        except:
            pass
    
    # 方法2：尝试常见的colormap（如果自动检测失败）
    common_colormaps = ['jet', 'viridis', 'plasma', 'hot']
    best_grayscale = None
    best_std = -1
    
    for cmap_name in common_colormaps:
        try:
            grayscale = reverse_colormap_mapping(rgb_image, cmap_name, use_improved=True)
            std = np.std(grayscale)
            # 选择标准差最大的（保留更多信息）
            if std > best_std:
                best_std = std
                best_grayscale = grayscale
        except:
            continue
    
    if best_grayscale is not None:
        return best_grayscale
    
    # 方法3：使用HSV的V通道（保留更多原始信息）
    grayscale_hsv = rgb_to_grayscale_from_hsv(rgb_image)
    
    # 方法4：使用加权平均
    grayscale_weighted = rgb_to_grayscale_weighted(rgb_image)
    
    # 计算两种方法的标准差，选择标准差较大的（保留更多信息）
    std_hsv = np.std(grayscale_hsv)
    std_weighted = np.std(grayscale_weighted)
    
    if std_hsv > std_weighted:
        return grayscale_hsv
    else:
        return grayscale_weighted


def convert_pseudocolor_to_grayscale(input_path, output_path=None, method='adaptive'):
    """
    将伪彩色图像转换为灰度图像
    
    Args:
        input_path: 输入图像路径
        output_path: 输出图像路径（如果为None，则在输入文件名后添加'_grayscale'）
        method: 转换方法，可选：
            - 'adaptive': 自适应选择（自动检测colormap，推荐，默认）
            - 'weighted': RGB加权平均
            - 'hsv': 从HSV提取亮度
            - 'lab': 从LAB色彩空间提取亮度（通常比HSV更准确）
            - 'reverse_colormap': 反向colormap映射（默认使用jet）
            - 'colormap_<name>': 指定colormap名称进行反向映射，如'colormap_jet'
    
    Returns:
        output_path: 输出文件路径
    """
    # 读取图像
    try:
        img = Image.open(input_path)
    except Exception as e:
        raise ValueError(f"无法读取图像文件 {input_path}: {e}")
    
    # 转换为RGB（如果是RGBA或其他格式）
    if img.mode != 'RGB':
        img = img.convert('RGB')
    
    # 转换为numpy数组
    rgb_array = np.array(img)
    
    # 根据方法选择转换函数
    if method == 'weighted':
        grayscale = rgb_to_grayscale_weighted(rgb_array)
    elif method == 'hsv':
        grayscale = rgb_to_grayscale_from_hsv(rgb_array)
    elif method == 'lab':
        grayscale = rgb_to_grayscale_from_lab(rgb_array)
    elif method == 'adaptive':
        grayscale = adaptive_convert_to_grayscale(rgb_array)
    elif method.startswith('colormap_'):
        colormap_name = method.split('_', 1)[1]
        grayscale = reverse_colormap_mapping(rgb_array, colormap_name, use_improved=True)
    elif method == 'reverse_colormap':
        # 默认使用'jet' colormap
        grayscale = reverse_colormap_mapping(rgb_array, 'jet', use_improved=True)
    else:
        raise ValueError(f"未知的转换方法: {method}")
    
    # 确保输出是uint8格式
    if grayscale.dtype != np.uint8:
        grayscale = np.clip(grayscale, 0, 255).astype(np.uint8)
    
    # 创建PIL图像
    grayscale_img = Image.fromarray(grayscale, mode='L')
    
    # 确定输出路径
    if output_path is None:
        input_path_obj = Path(input_path)
        output_path = str(input_path_obj.parent / f"{input_path_obj.stem}_grayscale{input_path_obj.suffix}")
    
    # 保存图像
    grayscale_img.save(output_path)
    print(f"✅ 转换完成: {input_path} -> {output_path}")
    
    return output_path


def batch_convert(input_dir, output_dir=None, method='adaptive', pattern=None, recursive=True):
    """
    批量转换伪彩色图像为灰度图像
    
    Args:
        input_dir: 输入目录
        output_dir: 输出目录（如果为None，则在输入目录下创建'grayscale'子目录）
        method: 转换方法
        pattern: 文件匹配模式（如'*.png', '*.jpg'等）。如果为None，则查找所有常见图像格式
        recursive: 是否递归处理子文件夹（默认True，自动处理所有子文件夹）
    """
    input_dir = Path(input_dir)
    
    if not input_dir.exists():
        raise ValueError(f"输入目录不存在: {input_dir}")
    
    if output_dir is None:
        output_dir = input_dir / 'grayscale'
    else:
        output_dir = Path(output_dir)
    
    # 创建输出目录
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 定义支持的图像格式
    # Windows系统glob不区分大小写，Linux/Mac需要分别查找
    supported_extensions = ['png', 'jpg', 'jpeg', 'tiff', 'tif', 'bmp', 'gif']
    
    # 查找所有匹配的图像文件
    image_files = []
    seen_files = set()  # 用于去重（使用小写路径字符串）
    
    if recursive:
        # 递归模式：查找所有子文件夹中的图像
        if pattern:
            # 如果指定了pattern，递归查找匹配的文件
            image_files = list(input_dir.rglob(pattern))
        else:
            # 如果未指定pattern，递归查找所有支持的图像格式
            for ext in supported_extensions:
                # 查找小写扩展名（递归）
                for f in input_dir.rglob(f'*.{ext}'):
                    key = str(f).lower()
                    if key not in seen_files:
                        seen_files.add(key)
                        image_files.append(f)
                # 查找大写扩展名（递归，Linux/Mac系统需要）
                for f in input_dir.rglob(f'*.{ext.upper()}'):
                    key = str(f).lower()
                    if key not in seen_files:
                        seen_files.add(key)
                        image_files.append(f)
    else:
        # 非递归模式：只查找当前目录中的图像
        if pattern:
            # 如果指定了pattern，只查找匹配的文件
            image_files = list(input_dir.glob(pattern))
        else:
            # 如果未指定pattern，查找所有支持的图像格式
            for ext in supported_extensions:
                # 查找小写扩展名
                for f in input_dir.glob(f'*.{ext}'):
                    key = str(f).lower()
                    if key not in seen_files:
                        seen_files.add(key)
                        image_files.append(f)
                # 查找大写扩展名（Linux/Mac系统需要）
                for f in input_dir.glob(f'*.{ext.upper()}'):
                    key = str(f).lower()
                    if key not in seen_files:
                        seen_files.add(key)
                        image_files.append(f)
    
    # 排序
    image_files = sorted(image_files)
    
    if not image_files:
        if pattern:
            print(f"⚠️ 在 {input_dir} {'及其子文件夹' if recursive else ''} 中未找到匹配 {pattern} 的图像文件")
        else:
            print(f"⚠️ 在 {input_dir} {'及其子文件夹' if recursive else ''} 中未找到任何支持的图像文件（支持的格式：{', '.join(supported_extensions)}）")
        return
    
    print(f"找到 {len(image_files)} 个图像文件{'（包括子文件夹）' if recursive else ''}，开始批量转换...")
    
    success_count = 0
    for img_file in image_files:
        try:
            if recursive:
                # 递归模式：保持目录结构
                # 计算相对路径
                relative_path = img_file.relative_to(input_dir)
                # 创建对应的输出路径，保持目录结构
                output_path = output_dir / relative_path
                # 确保输出目录存在
                output_path.parent.mkdir(parents=True, exist_ok=True)
            else:
                # 非递归模式：所有文件放在输出目录根目录
                output_path = output_dir / img_file.name
            
            convert_pseudocolor_to_grayscale(str(img_file), str(output_path), method)
            success_count += 1
        except Exception as e:
            print(f"❌ 转换失败 {img_file}: {e}")
    
    print(f"\n批量转换完成: {success_count}/{len(image_files)} 个文件成功转换")


def main():
    parser = argparse.ArgumentParser(
        description='将伪彩色图像转换为灰度图像',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 单文件转换（默认使用自适应方法，自动检测colormap）
  python convert_pseudocolor_to_grayscale.py input.png output.png
  
  # 使用LAB方法（通常比HSV更准确）
  python convert_pseudocolor_to_grayscale.py input.png -m lab
  
  # 使用HSV方法
  python convert_pseudocolor_to_grayscale.py input.png -m hsv
  
  # 反向colormap映射（假设原图使用jet colormap）
  python convert_pseudocolor_to_grayscale.py input.png -m colormap_jet
  
  # 自适应方法（推荐，自动检测最佳colormap）
  python convert_pseudocolor_to_grayscale.py input.png -m adaptive
  
  # 批量转换（默认递归处理所有子文件夹，自动查找所有支持的图像格式）
  python convert_pseudocolor_to_grayscale.py input_dir/ -b
  
  # 批量转换（仅处理当前目录，不递归子文件夹）
  python convert_pseudocolor_to_grayscale.py input_dir/ -b --no-recursive
  
  # 批量转换（仅查找特定格式）
  python convert_pseudocolor_to_grayscale.py input_dir/ -b -p "*.png"
  python convert_pseudocolor_to_grayscale.py input_dir/ -b -p "*.jpg"
        """
    )
    
    parser.add_argument('input', help='输入图像文件或目录路径')
    parser.add_argument('-o', '--output', default=None, help='输出图像文件或目录路径（可选）')
    parser.add_argument('-m', '--method', default='adaptive',
                        choices=['weighted', 'hsv', 'lab', 'reverse_colormap', 'adaptive', 
                                'colormap_jet', 'colormap_viridis', 'colormap_plasma', 
                                'colormap_hot', 'colormap_cool', 'colormap_rainbow', 'colormap_turbo'],
                        help='转换方法（默认: adaptive，自动检测colormap并选择最佳方法）')
    parser.add_argument('-b', '--batch', action='store_true',
                        help='批量处理模式（输入为目录）')
    parser.add_argument('--no-recursive', action='store_true',
                        help='禁用递归处理（默认会递归处理所有子文件夹）')
    parser.add_argument('-p', '--pattern', default=None,
                        help='批量处理时的文件匹配模式（如"*.png", "*.jpg"）。如果不指定，则查找所有支持的图像格式（png, jpg, jpeg, tiff, bmp, gif等）')
    
    args = parser.parse_args()
    
    try:
        if args.batch or os.path.isdir(args.input):
            # 批量处理模式
            # 默认启用递归，除非用户明确指定 --no-recursive
            recursive = not args.no_recursive
            batch_convert(args.input, args.output, args.method, args.pattern, recursive)
        else:
            # 单文件处理模式
            convert_pseudocolor_to_grayscale(args.input, args.output, args.method)
    
    except Exception as e:
        print(f"❌ 错误: {e}")
        return 1
    
    return 0


if __name__ == '__main__':
    exit(main())

