"""保留条目：均匀 AABB 体素密化（无剪影时更轻量）。完整方案请用 scheme_a_geometry_prior。"""

from __future__ import annotations

from post_sfm.context import PostSfmContext
from post_sfm.modules.scheme_a_geometry_prior import run_uniform_grid_only


def run(ctx: PostSfmContext) -> None:
    run_uniform_grid_only(ctx)
