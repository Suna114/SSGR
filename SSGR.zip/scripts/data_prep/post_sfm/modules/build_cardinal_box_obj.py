"""由 target_dimension_constraints_summary.txt（优选方位角 L/W + 阴影 H）写出轴对齐长方体 OBJ，不写 sparse。"""

from __future__ import annotations

import os

from post_sfm.cardinal_box_from_summary import run_cardinal_box_pipeline
from post_sfm.context import PostSfmContext


def _resolve_user_path(base_dir: str, p: str) -> str:
    p = (p or "").strip()
    if not p:
        return ""
    if os.path.isfile(p):
        return os.path.abspath(p)
    cand = os.path.join(base_dir, p)
    if os.path.isfile(cand):
        return os.path.abspath(cand)
    return os.path.abspath(os.path.normpath(os.path.join(base_dir, p)))


def run(ctx: PostSfmContext) -> None:
    args = ctx.args
    viz = os.path.join(
        ctx.source_path, getattr(args, "visualization_dir", "adaptive_threshold_visualization")
    )
    summary_path = os.path.join(viz, "target_dimension_constraints_summary.txt")
    if not os.path.isfile(summary_path):
        raise RuntimeError(
            "build_cardinal_box_obj 需要阴影几何汇总：\n"
            f"  期望: {summary_path}\n"
            "请先完成 convert 特征提取并生成 target_dimension_constraints_summary.txt。"
        )

    rel_out = (getattr(args, "post_sfm_cardinal_box_out", "") or "").strip()
    if not rel_out:
        rel_out = os.path.join("geometry_prior", "box_cardinal.obj")
    out_obj = _resolve_user_path(ctx.source_path, rel_out)

    depth_scale = float(getattr(args, "post_sfm_cardinal_box_depth_scale", 1.0) or 1.0)
    az_tol = float(getattr(args, "post_sfm_cardinal_box_azimuth_tolerance", 5.0) or 5.0)
    aggregate = str(getattr(args, "post_sfm_cardinal_box_aggregate", "weighted_mean") or "weighted_mean")
    wf = float(getattr(args, "post_sfm_cardinal_box_azimuth_weight_floor", 0.05) or 0.05)
    height_mode = str(getattr(args, "post_sfm_cardinal_box_height_mode", "cardinal") or "cardinal")
    include_all = bool(getattr(args, "post_sfm_cardinal_box_include_all_for_lw", False))
    json_sidecar = (getattr(args, "post_sfm_cardinal_box_json", "") or "").strip()
    if json_sidecar:
        json_sidecar = _resolve_user_path(ctx.source_path, json_sidecar)
    ascii_only = bool(getattr(args, "post_sfm_cardinal_box_ascii_only", False))
    azimuth_lane = str(getattr(args, "post_sfm_cardinal_box_azimuth_lane", "cardinal") or "cardinal")

    print(
        f"   build_cardinal_box_obj: summary={summary_path}\n"
        f"      -> {out_obj} (depth_scale={depth_scale}, lane={azimuth_lane}, azimuth_tol={az_tol}°)"
    )

    run_cardinal_box_pipeline(
        summary_path,
        out_obj,
        azimuth_tolerance=az_tol,
        aggregate=aggregate,
        height_mode=height_mode,
        include_all_for_lw=include_all,
        depth_scale=depth_scale,
        json_sidecar=json_sidecar,
        ascii_obj_only=ascii_only,
        print_report=True,
        azimuth_weight_floor=wf,
        azimuth_lane=azimuth_lane,
    )
