"""OBJ / 三角网格几何先验：与 sparse 对齐、表面采样后合并进 points3D（方案 A）。

`replace_sparse` 时写入的采样点与 `build_mesh_prior_pointcloud` 输出的 `xyz_world` 一致，均为
**COLMAP 世界系**（与三角化原点及 `readColmapSceneInfo` 读入坐标相同）；仅 mesh→world 的轴约定
差异需用 `mesh_vertex_axis_sign` 等在采样前消化，勿在写回 sparse 后再做全局坐标变换。
"""

from __future__ import annotations

import os

import numpy as np

from post_sfm.colmap_points import read_points3d_binary_full, sync_colmap_point_outputs, point3d_records_from_mesh_samples
from post_sfm.context import PostSfmContext
from post_sfm.mesh_obj_prior_core import append_prior_xyz_to_records, build_mesh_prior_pointcloud
from post_sfm.sar_colmap_geom import camera_center_world, load_colmap_views


def _resolve_user_path(base_dir: str, p: str) -> str:
    p = (p or "").strip()
    if not p:
        return ""
    if os.path.isfile(p):
        return os.path.abspath(p)
    cand = os.path.join(base_dir, p)
    if os.path.isfile(cand):
        return os.path.abspath(cand)
    return os.path.abspath(p)


def run(ctx: PostSfmContext) -> None:
    rel = (getattr(ctx.args, "post_sfm_mesh_obj", "") or "").strip()
    if not rel:
        raise ValueError("merge_mesh_obj_prior 需要 --post_sfm_mesh_obj（OBJ/PLY/STL/OFF 网格路径）")

    mesh_path = _resolve_user_path(ctx.source_path, rel)
    if not os.path.isfile(mesh_path):
        raise FileNotFoundError(f"网格不存在: {mesh_path}")

    sample_count = int(getattr(ctx.args, "post_sfm_mesh_sample_count", 200_000) or 200_000)
    icp_n = int(getattr(ctx.args, "post_sfm_mesh_icp_source_samples", 80_000) or 80_000)
    skip_icp = bool(getattr(ctx.args, "post_sfm_mesh_skip_icp", False))
    use_poisson = bool(getattr(ctx.args, "post_sfm_mesh_poisson_disk", False))
    scale_ov = float(getattr(ctx.args, "post_sfm_mesh_scale_override", 0.0) or 0.0)
    crop_margin = float(getattr(ctx.args, "post_sfm_mesh_crop_margin", 1.45) or 1.45)
    icp_iters = int(getattr(ctx.args, "post_sfm_mesh_icp_max_iters", 40) or 40)
    seed = int(getattr(ctx.args, "post_sfm_mesh_seed", 0) or 0)

    save_json = (getattr(ctx.args, "post_sfm_mesh_save_transform_json", "") or "").strip()
    if save_json:
        save_json = _resolve_user_path(ctx.source_path, save_json)

    save_ply_dbg = (getattr(ctx.args, "post_sfm_mesh_save_aligned_ply", "") or "").strip()
    if save_ply_dbg:
        save_ply_dbg = _resolve_user_path(ctx.source_path, save_ply_dbg)

    merge_min = float(getattr(ctx.args, "post_sfm_merge_min_dist", 0.0) or 0.0)
    max_sp = int(getattr(ctx.args, "post_sfm_mesh_max_sparse_read", 500_000) or 500_000)
    replace_sparse = bool(getattr(ctx.args, "post_sfm_mesh_replace_sparse", False))
    crop_eff = float(0.0 if replace_sparse else crop_margin)
    bin_path = os.path.join(ctx.sparse_dir, "points3D.bin")
    rec0 = read_points3d_binary_full(bin_path)
    sparse_xyz = np.stack([r.xyz for r in rec0], axis=0) if rec0 else None
    no_cam = bool(getattr(ctx.args, "post_sfm_mesh_no_align_camera_centers", False))
    align_extra = None
    if not no_cam:
        try:
            views = load_colmap_views(ctx.sparse_dir)
            if views:
                align_extra = np.stack([camera_center_world(v) for v in views], axis=0)
        except Exception:
            align_extra = None

    print(
        f"   mesh prior: {mesh_path}\n"
        f"   sample_count={sample_count}, icp_source={icp_n}, skip_icp={skip_icp}, "
        f"poisson_disk={use_poisson}, crop_margin={crop_eff}, replace_sparse={replace_sparse}, "
        f"align_cameras={0 if align_extra is None else int(align_extra.shape[0])}"
    )

    result = build_mesh_prior_pointcloud(
        mesh_path,
        ctx.sparse_dir,
        sparse_xyz=sparse_xyz,
        alignment_extra_xyz=align_extra,
        sample_count=sample_count,
        icp_source_samples=icp_n,
        use_poisson_disk=use_poisson,
        skip_icp=skip_icp,
        icp_max_iters=icp_iters,
        scale_override=scale_ov,
        crop_margin_factor=crop_eff,
        seed=seed,
        save_transform_json=save_json or None,
        max_sparse_points=max_sp,
        use_normal_rgb=bool(getattr(ctx.args, "post_sfm_mesh_pseudocolor_normals", False)),
    )

    if result.fitness_rmse is not None:
        print(f"   ICP（最后一级）fitness={result.fitness_rmse[0]:.6f}, inlier_rmse={result.fitness_rmse[1]:.6f}")

    if save_ply_dbg:
        from post_sfm.colmap_points import store_ply_ascii

        parent = os.path.dirname(save_ply_dbg)
        if parent:
            os.makedirs(parent, exist_ok=True)
        store_ply_ascii(save_ply_dbg, result.xyz_world, result.rgb)
        print(f"   已写出调试 PLY: {save_ply_dbg}（{result.xyz_world.shape[0]} 点）")

    if replace_sparse:
        # xyz_world：mesh(local)→COLMAP world（含 ICP）；与 cameras/images 同系，训练端不再旋场景。
        rec_only = point3d_records_from_mesh_samples(result.xyz_world, result.rgb, start_id=1)
        sync_colmap_point_outputs(ctx.sparse_dir, rec_only)
        print(f"   replace_sparse: points3D 已完全替换为表面采样（{len(rec_only)} 点）")
        return

    records = read_points3d_binary_full(bin_path)
    before = len(records)
    records, added = append_prior_xyz_to_records(records, result.xyz_world, result.rgb, merge_min)
    sync_colmap_point_outputs(ctx.sparse_dir, records)
    print(f"   合并后点数: {len(records)}（新增 {added}，合并前 {before}，merge_min_dist={merge_min}）")
