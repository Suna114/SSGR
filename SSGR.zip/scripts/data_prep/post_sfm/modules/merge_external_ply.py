"""合并外部 PLY（方案 A 常见：独立先验/补洞点云）到当前 reconstruction。"""

from __future__ import annotations

import os

import numpy as np

from post_sfm.colmap_points import Point3DRecord, read_points3d_binary_full, sync_colmap_point_outputs
from post_sfm.context import PostSfmContext


def _load_xyz_rgb_from_ply(path: str):
    try:
        from plyfile import PlyData
    except ImportError as e:
        raise ImportError("merge_external_ply 需要 plyfile：pip install plyfile") from e
    ply = PlyData.read(path)
    v = ply["vertex"]
    x = np.asarray(v["x"], dtype=np.float64)
    y = np.asarray(v["y"], dtype=np.float64)
    z = np.asarray(v["z"], dtype=np.float64)
    xyz = np.stack([x, y, z], axis=1)
    if "red" in v.dtype.names:
        r = np.asarray(v["red"])
        g = np.asarray(v["green"])
        b = np.asarray(v["blue"])
    else:
        r = np.full(x.shape, 128, dtype=np.uint8)
        g = np.full(x.shape, 128, dtype=np.uint8)
        b = np.full(x.shape, 128, dtype=np.uint8)
    rgb = np.stack([r, g, b], axis=1).astype(np.uint8)
    return xyz, rgb


def run(ctx: PostSfmContext) -> None:
    ply_path = (getattr(ctx.args, "post_sfm_external_ply", "") or "").strip()
    if not ply_path:
        raise ValueError("merge_external_ply 需要 --post_sfm_external_ply 路径")
    if not os.path.isfile(ply_path):
        raise FileNotFoundError(ply_path)

    records = read_points3d_binary_full(os.path.join(ctx.sparse_dir, "points3D.bin"))
    max_id = max((p.point_id for p in records), default=0)

    ex_xyz, ex_rgb = _load_xyz_rgb_from_ply(ply_path)
    if ex_xyz.size == 0:
        print("   外部 PLY 无顶点，跳过合并")
        return

    min_dist = float(getattr(ctx.args, "post_sfm_merge_min_dist", 0.0) or 0.0)
    if min_dist > 0 and records:
        ref = np.stack([p.xyz for p in records], axis=0)
        keep_rows = []
        for i in range(ex_xyz.shape[0]):
            d = np.linalg.norm(ref - ex_xyz[i], axis=1).min()
            if d >= min_dist:
                keep_rows.append(i)
        if not keep_rows:
            print("   外部点均在 min_dist 内，未添加新点")
            return
        ex_xyz = ex_xyz[keep_rows]
        ex_rgb = ex_rgb[keep_rows]

    next_id = max_id + 1
    for i in range(ex_xyz.shape[0]):
        records.append(
            Point3DRecord(
                point_id=next_id,
                xyz=ex_xyz[i].astype(np.float64),
                rgb=ex_rgb[i].astype(np.uint8),
                error=0.0,
                track=[],
            )
        )
        next_id += 1

    sync_colmap_point_outputs(ctx.sparse_dir, records)
    print(f"   合并后点数: {len(records)}（新增 {ex_xyz.shape[0]}）")
