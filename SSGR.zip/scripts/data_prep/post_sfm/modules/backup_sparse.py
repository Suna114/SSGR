"""将 sparse/0 备份到同级目录（时间戳），便于尝试破坏性后处理。"""

from __future__ import annotations

import datetime
import os
import shutil

from post_sfm.context import PostSfmContext


def run(ctx: PostSfmContext) -> None:
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    parent = os.path.dirname(ctx.sparse_dir)
    base = os.path.basename(ctx.sparse_dir.rstrip("/\\"))
    dest = os.path.join(parent, f"{base}_backup_{ts}")
    if os.path.exists(dest):
        raise FileExistsError(dest)
    shutil.copytree(ctx.sparse_dir, dest)
    print(f"   已备份: {ctx.sparse_dir} -> {dest}")
