"""注册 post_sfm 模块名 -> run(ctx) 函数。"""

from __future__ import annotations

from typing import Callable, Dict

from post_sfm.context import PostSfmContext

from . import (
    backup_sparse,
    build_cardinal_box_obj,
    merge_external_ply,
    merge_mesh_obj_prior,
    merge_summary_box_mesh_prior,
    scheme_a_geometry_prior,
    scheme_a_height_band,
)

REGISTRY: Dict[str, Callable[[PostSfmContext], None]] = {
    "backup_sparse": backup_sparse.run,
    "build_cardinal_box_obj": build_cardinal_box_obj.run,
    "merge_external_ply": merge_external_ply.run,
    "merge_mesh_obj_prior": merge_mesh_obj_prior.run,
    "merge_summary_box_mesh_prior": merge_summary_box_mesh_prior.run,
    "scheme_a_geometry_prior": scheme_a_geometry_prior.run,
    "scheme_a_height_band": scheme_a_height_band.run,
}

__all__ = ["REGISTRY"]
