"""阴影汇总 L/W/H 比例长方体：轴对齐模板 + 名义半轴粗尺度 + build_mesh_prior_pointcloud。

默认对齐目标仅 sparse（与 SfM 内 --sfm_mesh_prior_mode replace 一致）；需相机参与时加
--post_sfm_summary_box_align_camera_centers。

与 SfM 内 --sfm_summary_box_mesh_prior_mode 共用 post_sfm/summary_box_mesh_prior_core。

replace_sparse 写回的采样点为 **COLMAP 世界坐标**，与同目录 cameras/images 及 3DGS
`readColmapSceneInfo` 一致；勿在替换点云后再对场景施加与 COLMAP 冲突的旋转。
"""

from __future__ import annotations

import os

import numpy as np

from post_sfm.colmap_points import (
    append_prior_xyz_to_records,
    point3d_records_from_mesh_samples,
    read_points3d_binary_full,
    sync_colmap_point_outputs,
)
from post_sfm.context import PostSfmContext
from post_sfm.summary_box_mesh_prior_core import run_summary_box_mesh_prior_core


def _resolve_user_path(base_dir: str, p: str) -> str:
    p = (p or "").strip()
    if not p:
        return ""
    if os.path.isfile(p):
        return os.path.abspath(p)
    cand = os.path.join(base_dir, p)
    if os.path.isfile(cand):
        return os.path.abspath(cand)
    return os.path.abspath(os.path.normpath(os.path.join(base_dir, p)))


def run(ctx: PostSfmContext) -> None:
    args = ctx.args
    if str(getattr(args, "post_sfm_summary_box_orient_mode", "")).strip().lower() not in (
        "",
        "none",
        "off",
    ):
        print(
            "   ℹ️ post_sfm_summary_box_orient_mode 已忽略：比例盒采用轴对齐网格 + 名义半轴粗尺度 + ICP；"
            "预旋转会破坏包围盒尺度估计。朝向由多尺度 ICP 校正。"
        )

    bin_path = os.path.join(ctx.sparse_dir, "points3D.bin")
    records0 = read_points3d_binary_full(bin_path)
    pts = np.stack([p.xyz for p in records0], axis=0) if records0 else np.zeros((0, 3), dtype=np.float64)

    crop_margin = float(getattr(args, "post_sfm_mesh_crop_margin", 1.45) or 1.45)
    replace_sparse = bool(getattr(args, "post_sfm_mesh_replace_sparse", False))
    no_crop_replace = bool(getattr(args, "post_sfm_summary_box_no_crop_on_replace", False))
    if replace_sparse:
        crop_eff = float(0.0 if no_crop_replace else crop_margin)
    else:
        crop_eff = float(crop_margin)

    print(
        f"   merge_summary_box_mesh_prior: crop_margin={crop_eff}, replace_sparse={replace_sparse}, "
        f"no_crop_on_replace={no_crop_replace}"
    )

    result, mesh_path, _mesh, rx, ry, rz = run_summary_box_mesh_prior_core(
        source_path=ctx.source_path,
        sparse_dir=ctx.sparse_dir,
        sparse_xyz_for_align=pts,
        args=args,
        mesh_param_source="post_sfm_mesh",
        crop_margin_factor=crop_eff,
    )

    print(
        f"   merge_summary_box_mesh_prior: 名义半轴(rx,ry,rz)=({rx:.6f},{ry:.6f},{rz:.6f})\n"
        f"      网格: {mesh_path}\n"
        f"      对齐目标: "
        f"{'sparse + 相机光心' if bool(getattr(args, 'post_sfm_summary_box_align_camera_centers', False)) else 'sparse（与 SfM 网格 replace 一致）'}"
    )
    sample_count = int(getattr(args, "post_sfm_mesh_sample_count", 200_000) or 200_000)
    icp_n = int(getattr(args, "post_sfm_mesh_icp_source_samples", 80_000) or 80_000)
    skip_icp = bool(getattr(args, "post_sfm_mesh_skip_icp", False))
    use_poisson = bool(getattr(args, "post_sfm_mesh_poisson_disk", False))
    print(
        f"   align+sample sample_count={sample_count}, icp_source={icp_n}, skip_icp={skip_icp}, "
        f"poisson_disk={use_poisson}, crop_margin={crop_eff}, replace_sparse={replace_sparse}"
    )

    if result.fitness_rmse is not None:
        print(f"   ICP（最后一级）fitness={result.fitness_rmse[0]:.6f}, inlier_rmse={result.fitness_rmse[1]:.6f}")

    save_ply_dbg = (getattr(args, "post_sfm_mesh_save_aligned_ply", "") or "").strip()
    if save_ply_dbg:
        from post_sfm.colmap_points import store_ply_ascii

        save_ply_dbg = _resolve_user_path(ctx.source_path, save_ply_dbg)
        pd = os.path.dirname(save_ply_dbg)
        if pd:
            os.makedirs(pd, exist_ok=True)
        store_ply_ascii(save_ply_dbg, result.xyz_world, result.rgb)
        print(f"   已写出调试 PLY: {save_ply_dbg}（{result.xyz_world.shape[0]} 点）")

    merge_min = float(getattr(args, "post_sfm_merge_min_dist", 0.0) or 0.0)

    if replace_sparse:
        # result.xyz_world 与 sparse 原三角化点同属 COLMAP world。
        rec_only = point3d_records_from_mesh_samples(result.xyz_world, result.rgb, start_id=1)
        sync_colmap_point_outputs(ctx.sparse_dir, rec_only)
        print(f"   replace_sparse: points3D 已完全替换为表面采样（{len(rec_only)} 点）")
        return

    records = read_points3d_binary_full(bin_path)
    before = len(records)
    records, added = append_prior_xyz_to_records(records, result.xyz_world, result.rgb, merge_min)
    sync_colmap_point_outputs(ctx.sparse_dir, records)
    print(f"   合并后点数: {len(records)}（新增 {added}，合并前 {before}，merge_min_dist={merge_min}）")
