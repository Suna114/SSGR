"""
方案 A 完整几何先验（post-SfM）：多视剪影一致 (visual hull) + 剪影锥射线采样
+ 阴影汇总高度带约束 + 必要时 AABB 均匀退火密化。

无 CAD 但希望点云更接近「表面一层」：加 --post_sfm_scheme_a_surface_shell_only
（visual hull 体素外壳，依赖 scipy）。

依赖 convert 已生成的 *_mask.npy 与可选 target_dimension_constraints_summary.txt。
无掩码时若汇总含 L/W，默认用阴影比例近似均匀椭球表面采样（Fibonacci）；可选长方体六面网格。
"""

from __future__ import annotations

import os
from typing import Dict, List, Optional, Set, Tuple

import cv2
import numpy as np

from post_sfm.colmap_points import Point3DRecord, read_points3d_binary_full, sync_colmap_point_outputs
from post_sfm.context import PostSfmContext
from post_sfm.masks_io import discover_mask_arrays, match_mask_for_image
from post_sfm.sar_colmap_geom import (
    camera_center_world,
    estimate_depth_scale_from_sparse,
    load_colmap_views,
    ray_sample_points,
    world_to_pixel,
)
from post_sfm.summary_parser import ShadowSummaryStats, parse_target_dimension_summary, shadow_summary_semiaxes_xyz


def _parse_int_set(s: str) -> Set[int]:
    out: Set[int] = set()
    for part in s.replace(" ", "").split(","):
        if not part:
            continue
        out.add(int(part))
    return out if out else {1, 2}


def _prepare_target_mask(
    raw: np.ndarray, labels: Set[int], dilate_iter: int, w: int, h: int
) -> Optional[np.ndarray]:
    if raw is None:
        return None
    m = np.asarray(raw)
    if m.ndim != 2:
        return None
    if m.shape[1] != w or m.shape[0] != h:
        m = cv2.resize(m.astype(np.float32), (w, h), interpolation=cv2.INTER_NEAREST)
    m = m.astype(np.int32)
    tgt = np.zeros_like(m, dtype=bool)
    for lb in labels:
        tgt |= m == lb
    if not np.any(tgt):
        return None
    if dilate_iter > 0:
        ker = np.ones((3, 3), np.uint8)
        tgt = cv2.dilate(tgt.astype(np.uint8), ker, iterations=dilate_iter).astype(bool)
    return tgt


def _aabb_from_points(pts: np.ndarray, cams: np.ndarray, margin_ratio: float) -> Tuple[np.ndarray, np.ndarray]:
    allp = np.concatenate([pts, cams], axis=0) if pts.shape[0] else cams
    lo = allp.min(axis=0)
    hi = allp.max(axis=0)
    span = hi - lo
    pad = span * margin_ratio + (span.max() * 1e-6)
    return lo - pad, hi + pad


def _build_voxel_centers(lo: np.ndarray, hi: np.ndarray, voxel_div: int) -> np.ndarray:
    voxel_div = max(3, int(voxel_div))
    xs = np.linspace(lo[0], hi[0], voxel_div + 1)
    ys = np.linspace(lo[1], hi[1], voxel_div + 1)
    zs = np.linspace(lo[2], hi[2], voxel_div + 1)
    cx = 0.5 * (xs[:-1] + xs[1:])
    cy = 0.5 * (ys[:-1] + ys[1:])
    cz = 0.5 * (zs[:-1] + zs[1:])
    gx, gy, gz = np.meshgrid(cx, cy, cz, indexing="ij")
    return np.stack([gx.ravel(), gy.ravel(), gz.ravel()], axis=1)


def _height_slab_mask(
    P: np.ndarray,
    pts: np.ndarray,
    H_world: Optional[float],
    centroid: np.ndarray,
    upper_scale: float,
    lower_scale: float,
) -> np.ndarray:
    """COLMAP：物理“向上”为 -Y；相对高度 h_up = -(y - cy)。"""
    if H_world is None or H_world <= 0:
        return np.ones(P.shape[0], dtype=bool)
    if pts.shape[0]:
        h_ref = float(np.median(-(pts - centroid)[:, 1]))
    else:
        h_ref = 0.0
    rel = P - centroid.reshape(1, 3)
    h_up = -rel[:, 1]
    lo_b = h_ref - lower_scale * H_world
    hi_b = h_ref + upper_scale * H_world
    return (h_up >= lo_b) & (h_up <= hi_b)


def _subsample_indices(n: int, max_n: int, seed: int = 0) -> np.ndarray:
    if n <= max_n:
        return np.arange(n, dtype=np.int64)
    rng = np.random.default_rng(seed)
    return np.sort(rng.choice(n, size=max_n, replace=False))


def _effective_voxel_div_for_cap(voxel_div: int, cap_eval: int) -> int:
    """使 voxel_div**3 <= cap_eval，便于 surface_shell 保持规则网格。"""
    voxel_div = max(3, int(voxel_div))
    cap_eval = max(27, int(cap_eval))
    if voxel_div**3 <= cap_eval:
        return voxel_div
    vd = max(3, int(np.floor(cap_eval ** (1.0 / 3.0))))
    while vd**3 > cap_eval and vd > 3:
        vd -= 1
    return min(voxel_div, vd)


def _visual_hull_surface_shell_mask(
    votes: np.ndarray,
    slab_ok: np.ndarray,
    nx: int,
    ny: int,
    nz: int,
    min_views: int,
) -> np.ndarray:
    """
    形态学边界：inside = votes>=min_views 且 slab_ok；外壳 = inside ∧ ¬erosion(inside)。
    返回与 grid 同长度的 flat bool。
    """
    from scipy import ndimage

    inside = (votes >= min_views) & slab_ok
    vol = inside.reshape(nx, ny, nz)
    struct = np.ones((3, 3, 3), dtype=bool)
    core = ndimage.binary_erosion(vol, structure=struct)
    shell = vol & (~core)
    return shell.reshape(-1)


def _dedupe_points(
    candidates: np.ndarray,
    pts_fixed: np.ndarray,
    max_new: int,
    min_dist: float,
) -> np.ndarray:
    if candidates.shape[0] == 0:
        return candidates
    if min_dist <= 0:
        rng = np.random.default_rng(0)
        perm = rng.permutation(candidates.shape[0])
        take = min(max_new, candidates.shape[0])
        return candidates[perm[:take]]

    try:
        from scipy.spatial import cKDTree
    except ImportError:
        cKDTree = None  # type: ignore

    rng = np.random.default_rng(0)
    perm = rng.permutation(candidates.shape[0])
    selected: List[np.ndarray] = []
    accum = pts_fixed.astype(np.float64).copy() if pts_fixed.shape[0] else np.zeros((0, 3), dtype=np.float64)
    tree = cKDTree(accum) if (cKDTree is not None and accum.shape[0]) else None
    recent_cap = 256
    recent: List[np.ndarray] = []

    for j in perm:
        if len(selected) >= max_new:
            break
        p = candidates[j].astype(np.float64)
        if tree is not None:
            d, _ = tree.query(p, k=1)
            if float(d) < min_dist:
                continue
        elif accum.shape[0]:
            if float(np.linalg.norm(accum - p, axis=1).min()) < min_dist:
                continue
        if recent:
            arr = np.stack(recent, axis=0)
            if float(np.linalg.norm(arr - p, axis=1).min()) < min_dist:
                continue
        selected.append(p.copy())
        accum = np.vstack([accum, p.reshape(1, 3)])
        recent.append(p.copy())
        if len(recent) >= recent_cap:
            if cKDTree is not None:
                tree = cKDTree(accum)
            recent.clear()

    if not selected:
        return np.zeros((0, 3), dtype=np.float64)
    return np.stack(selected, axis=0)


def _fibonacci_unit_sphere_dirs(n: int) -> np.ndarray:
    """≈均匀的球面方向（Fibonacci 球格），用作椭球单层表面采样的经纬线替代。"""
    n = max(0, int(n))
    if n <= 0:
        return np.zeros((0, 3), dtype=np.float64)
    i = np.arange(n, dtype=np.float64)
    y = 1.0 - (2.0 * i + 1.0) / float(n)
    y = np.clip(y, -1.0 + 1e-12, 1.0 - 1e-12)
    r_xy = np.sqrt(np.maximum(0.0, 1.0 - y * y))
    theta = np.pi * (3.0 - np.sqrt(5.0)) * i
    x = np.cos(theta) * r_xy
    z = np.sin(theta) * r_xy
    dirs = np.stack([x, y, z], axis=1)
    nrm = np.linalg.norm(dirs, axis=1, keepdims=True)
    dirs = np.divide(dirs, np.maximum(nrm, 1e-12))
    return dirs


def _ellipsoid_surface_fibonacci(
    centroid: np.ndarray,
    rx: float,
    ry: float,
    rz: float,
    n_points: int,
) -> np.ndarray:
    """
    标准椭球 (x²/rx² + y²/ry² + z²/rz² = 1) 单层表面采样。
    对单位向量 d，射线 td 首交点为 t·d：t² ∑(dᵢ²/rᵢ²)=1 → t = 1/√∑。
    COLMAP「向上」为 -Y：ry 仍为高度半轴距。
    """
    rx = max(float(rx), 1e-9)
    ry = max(float(ry), 1e-9)
    rz = max(float(rz), 1e-9)
    n_points = max(100, min(int(n_points), 600_000))
    dirs = _fibonacci_unit_sphere_dirs(n_points)
    denom = (
        dirs[:, 0] ** 2 / (rx * rx) + dirs[:, 1] ** 2 / (ry * ry) + dirs[:, 2] ** 2 / (rz * rz)
    )
    t = np.sqrt(1.0 / np.maximum(denom, 1e-30))
    pts = dirs * t.reshape(-1, 1)
    c = centroid.reshape(3).astype(np.float64)
    pts += c.reshape(1, 3)
    return pts


def _summary_dimension_ellipsoid_shell_points(
    centroid: np.ndarray,
    stats: ShadowSummaryStats,
    depth_scale: float,
    pf_scale: float,
    H_world: Optional[float],
    upper_h: float,
    lower_h: float,
    n_points: int,
) -> np.ndarray:
    """无掩码兜底：按比例椭球单层密点表层（阴影 L/W/H 半轴）。"""
    ax = shadow_summary_semiaxes_xyz(stats, depth_scale, pf_scale, H_world, upper_h, lower_h)
    if ax is None:
        return np.zeros((0, 3), dtype=np.float64)
    rx, ry, rz = ax
    return _ellipsoid_surface_fibonacci(centroid, rx, ry, rz, n_points)


def _planform_clip(
    P: np.ndarray,
    centroid: np.ndarray,
    stats,
    depth_scale: float,
    scale: float,
) -> np.ndarray:
    """用汇总中 L/W 像素 × 深度尺度 在 XZ 平面裁剪（俯视平面范围）。"""
    if P.shape[0] == 0 or stats is None:
        return P
    if stats.length_median_px is None or stats.width_median_px is None:
        return P
    lx = float(stats.length_median_px) * depth_scale * scale
    wz = float(stats.width_median_px) * depth_scale * scale
    c = centroid.reshape(3)
    m = (
        (P[:, 0] >= c[0] - 0.5 * lx)
        & (P[:, 0] <= c[0] + 0.5 * lx)
        & (P[:, 2] >= c[2] - 0.5 * wz)
        & (P[:, 2] <= c[2] + 0.5 * wz)
    )
    return P[m]


def _summary_dimension_box_shell_points(
    centroid: np.ndarray,
    stats: ShadowSummaryStats,
    depth_scale: float,
    pf_scale: float,
    H_world: Optional[float],
    upper_h: float,
    lower_h: float,
    total_target: int,
) -> np.ndarray:
    """
    无剪影掩码时：用 target_dimension 汇总的 L/W（米级）与 H 估计竖直尺度，
    在 centroid 处生成长方体 6 个面上规则网格点（近似「比例盒子的表面采样」）。
    """
    axes = shadow_summary_semiaxes_xyz(stats, depth_scale, pf_scale, H_world, upper_h, lower_h)
    if axes is None:
        return np.zeros((0, 3), dtype=np.float64)
    hx, hy, hz = axes
    c = centroid.reshape(3).astype(np.float64)
    cx, cy, cz = float(c[0]), float(c[1]), float(c[2])

    total_target = max(600, int(total_target))
    n_face = max(500, total_target // 6)
    nu = max(12, int(np.sqrt(n_face)))
    nv = max(12, int(np.ceil(n_face / max(1, nu))))

    faces: List[np.ndarray] = []

    def face_x(sgn: float) -> None:
        yy = np.linspace(cy - hy, cy + hy, nu)
        zz = np.linspace(cz - hz, cz + hz, nv)
        Y, Z = np.meshgrid(yy, zz)
        X = np.full_like(Y, cx + sgn * hx)
        faces.append(np.column_stack([X.ravel(), Y.ravel(), Z.ravel()]))

    def face_y(sgn: float) -> None:
        xx = np.linspace(cx - hx, cx + hx, nu)
        zz = np.linspace(cz - hz, cz + hz, nv)
        X, Z = np.meshgrid(xx, zz)
        Y = np.full_like(X, cy + sgn * hy)
        faces.append(np.column_stack([X.ravel(), Y.ravel(), Z.ravel()]))

    def face_z(sgn: float) -> None:
        xx = np.linspace(cx - hx, cx + hx, nu)
        yy = np.linspace(cy - hy, cy + hy, nv)
        X, Y = np.meshgrid(xx, yy)
        Z = np.full_like(X, cz + sgn * hz)
        faces.append(np.column_stack([X.ravel(), Y.ravel(), Z.ravel()]))

    face_x(1.0)
    face_x(-1.0)
    face_y(1.0)
    face_y(-1.0)
    face_z(1.0)
    face_z(-1.0)

    pts = np.vstack(faces) if faces else np.zeros((0, 3), dtype=np.float64)
    if pts.shape[0] > total_target * 2:
        rng = np.random.default_rng(0)
        idx = rng.choice(pts.shape[0], size=total_target, replace=False)
        pts = pts[np.sort(idx)]
    return pts


def run_uniform_grid_only(ctx: PostSfmContext) -> None:
    """仅 AABB 内均匀体素（旧 scheme_a_height_band 行为）。"""
    args = ctx.args
    voxel_div = int(getattr(args, "post_sfm_scheme_a_grid", 12) or 12)
    margin_pct = float(getattr(args, "post_sfm_scheme_a_aabb_margin_pct", 5.0) or 0.0) / 100.0
    min_dist = float(getattr(args, "post_sfm_scheme_a_min_dist_to_existing", 0.02) or 0.0)

    records = read_points3d_binary_full(os.path.join(ctx.sparse_dir, "points3D.bin"))
    max_id = max((p.point_id for p in records), default=0)
    pts = np.stack([p.xyz for p in records], axis=0) if records else np.zeros((0, 3), dtype=np.float64)
    views = load_colmap_views(ctx.sparse_dir)
    cams = np.stack([camera_center_world(v) for v in views], axis=0)
    lo, hi = _aabb_from_points(pts, cams, margin_pct)
    grid = _build_voxel_centers(lo, hi, max(3, min(voxel_div, 64)))
    if getattr(args, "post_sfm_scheme_a_planform_clip_uniform", True) and getattr(
        args, "post_sfm_scheme_a_enable_planform_from_summary", True
    ):
        viz = os.path.join(ctx.source_path, getattr(args, "visualization_dir", "adaptive_threshold_visualization"))
        st = parse_target_dimension_summary(os.path.join(viz, "target_dimension_constraints_summary.txt"))
        ds = estimate_depth_scale_from_sparse(pts, views)
        cent = np.median(pts, axis=0) if pts.shape[0] else np.mean(cams, axis=0)
        grid = _planform_clip(
            grid,
            cent,
            st,
            ds,
            float(getattr(args, "post_sfm_scheme_a_planform_scale", 1.0) or 1.0),
        )
    ref = pts if pts.shape[0] else cams
    gray = np.array([140, 140, 140], dtype=np.uint8)
    new_pts: List[np.ndarray] = []
    for p in grid:
        if ref.shape[0] and min_dist > 0 and np.linalg.norm(ref - p, axis=1).min() < min_dist:
            continue
        new_pts.append(p)
    if not new_pts:
        print("   scheme_a_height_band: 未添加网格点")
        return
    next_id = max_id + 1
    arr = np.stack(new_pts, axis=0)
    for row in arr:
        records.append(Point3DRecord(point_id=next_id, xyz=row, rgb=gray.copy(), error=0.0, track=[]))
        next_id += 1
    sync_colmap_point_outputs(ctx.sparse_dir, records)
    print(f"   scheme_a_height_band: 增加 {len(new_pts)} 个均匀体素点，总点数 {len(records)}")


def run(ctx: PostSfmContext) -> None:
    args = ctx.args
    enable_hull = getattr(args, "post_sfm_scheme_a_enable_visual_hull", True)
    enable_cone = getattr(args, "post_sfm_scheme_a_enable_cone_samples", True)
    enable_slab = getattr(args, "post_sfm_scheme_a_enable_height_slab", True)
    min_views = max(1, int(getattr(args, "post_sfm_scheme_a_min_views", 2) or 1))
    voxel_div = max(3, min(int(getattr(args, "post_sfm_scheme_a_voxel_div", 36) or 36), 128))
    max_new = int(getattr(args, "post_sfm_scheme_a_max_new_points", 250000) or 250000)
    margin_pct = float(getattr(args, "post_sfm_scheme_a_aabb_margin_pct", 5.0) or 0.0) / 100.0
    dilate = max(0, int(getattr(args, "post_sfm_scheme_a_mask_dilate", 1) or 0))
    labels = _parse_int_set(getattr(args, "post_sfm_scheme_a_mask_labels", "1,2") or "1,2")
    cone_stride = max(1, int(getattr(args, "post_sfm_scheme_a_cone_stride", 3) or 1))
    cone_steps = max(3, int(getattr(args, "post_sfm_scheme_a_cone_depth_steps", 16) or 8))
    cone_max_rays = int(getattr(args, "post_sfm_scheme_a_cone_max_rays_per_view", 4000) or 4000)
    shadow_h_scale = float(getattr(args, "post_sfm_scheme_a_shadow_height_scale", 1.0) or 1.0)
    upper_h = float(getattr(args, "post_sfm_scheme_a_height_slab_upper_scale", 1.25) or 1.0)
    lower_h = float(getattr(args, "post_sfm_scheme_a_height_slab_lower_scale", 0.35) or 0.0)
    chunk = max(4096, int(getattr(args, "post_sfm_scheme_a_eval_chunk", 65536) or 65536))
    min_dist_merge = float(getattr(args, "post_sfm_scheme_a_min_dist_new", 0.015) or 0.0)
    fallback_uniform = getattr(args, "post_sfm_scheme_a_fallback_uniform_fill", True)
    surface_shell_only = bool(getattr(args, "post_sfm_scheme_a_surface_shell_only", False))
    if surface_shell_only:
        enable_cone = False
        fallback_uniform = False
        print(
            "   surface_shell_only: 关闭剪影锥与均匀退火；visual hull 仅保留外壳一层体素（需 scipy）"
        )

    extra_dirs_raw = getattr(args, "post_sfm_mask_dirs", "") or ""
    extra_dirs = [d for d in extra_dirs_raw.split(",") if d.strip()]

    records = read_points3d_binary_full(os.path.join(ctx.sparse_dir, "points3D.bin"))
    max_id = max((p.point_id for p in records), default=0)
    pts = np.stack([p.xyz for p in records], axis=0) if records else np.zeros((0, 3), dtype=np.float64)
    views = load_colmap_views(ctx.sparse_dir)
    if not views:
        raise RuntimeError("scheme_a_geometry_prior: 无相机")
    cams = np.stack([camera_center_world(v) for v in views], axis=0)
    depth_scale = estimate_depth_scale_from_sparse(pts, views)

    viz_dir_name = getattr(args, "visualization_dir", "adaptive_threshold_visualization")
    summary_path = os.path.join(ctx.source_path, viz_dir_name, "target_dimension_constraints_summary.txt")
    stats = parse_target_dimension_summary(summary_path)
    H_world: Optional[float] = None
    if stats is not None and stats.height_median_px is not None and enable_slab:
        H_world = float(stats.height_median_px) * depth_scale * shadow_h_scale
        print(
            f"   阴影汇总: H_med={stats.height_median_px:.2f} px, depth_scale={depth_scale:.6f} "
            f"→ H_world≈{H_world:.6f}"
        )
    elif enable_slab:
        print("   阴影汇总: 未解析到高度中位数，关闭高度带")

    centroid = np.median(pts, axis=0) if pts.shape[0] else np.mean(cams, axis=0)

    mask_cache = discover_mask_arrays(ctx.source_path, extra_dirs if extra_dirs else None)
    if len(mask_cache) > 0:
        print(
            f"   掩码文件: 磁盘上检出 {len(mask_cache)} 个键；image_name 需与 stem 一致 "
            f"（例 BTR70-15-094.jpg ↔ …/BTR70-15-094_mask.npy）"
        )
    view_masks: Dict[str, np.ndarray] = {}
    for v in views:
        raw = match_mask_for_image(v.name, mask_cache)
        pm = _prepare_target_mask(raw, labels, dilate, v.width, v.height) if raw is not None else None
        if pm is not None:
            view_masks[v.name] = pm
    print(f"   掩码: {len(view_masks)}/{len(views)} 视图有目标标签 {sorted(labels)}")

    lo, hi = _aabb_from_points(pts, cams, margin_pct)
    cap_eval = int(getattr(args, "post_sfm_scheme_a_max_voxel_eval", 350000) or 350000)
    vd_use = voxel_div
    if surface_shell_only:
        vd_was = vd_use
        vd_use = _effective_voxel_div_for_cap(voxel_div, cap_eval)
        if vd_use < vd_was:
            print(
                f"   surface_shell_only: voxel_div {vd_was} → {vd_use} "
                f"（保证规则网格且体素数≤{cap_eval}）"
            )
    grid = _build_voxel_centers(lo, hi, vd_use)
    n_vox = grid.shape[0]
    nx = ny = nz = vd_use

    if not surface_shell_only:
        if n_vox > cap_eval:
            idx = _subsample_indices(n_vox, cap_eval, seed=0)
            grid = grid[idx]
            print(f"   体素中心: {n_vox} → 子采样 {grid.shape[0]}（post_sfm_scheme_a_max_voxel_eval）")
            nx = ny = nz = 0

    use_pf = getattr(args, "post_sfm_scheme_a_enable_planform_from_summary", True)
    pf_scale = float(getattr(args, "post_sfm_scheme_a_planform_scale", 1.0) or 1.0)
    if not surface_shell_only:
        if use_pf and stats is not None:
            n0 = grid.shape[0]
            grid = _planform_clip(grid, centroid, stats, depth_scale, pf_scale)
            if n0 != grid.shape[0]:
                print(f"   平面尺度裁剪 (汇总 L/W×深度尺度): 体素 {n0} → {grid.shape[0]}")

    hull_xyz = np.zeros((0, 3), dtype=np.float64)
    if enable_hull and len(view_masks) >= min_views:
        votes = np.zeros(grid.shape[0], dtype=np.int16)
        for v in views:
            if v.name not in view_masks:
                continue
            m = view_masks[v.name]
            for s in range(0, grid.shape[0], chunk):
                e = min(grid.shape[0], s + chunk)
                Xc = grid[s:e]
                u, vv, valid = world_to_pixel(Xc, v)
                ui = np.rint(u).astype(np.int32)
                vi = np.rint(vv).astype(np.int32)
                inbound = valid & (ui >= 0) & (ui < v.width) & (vi >= 0) & (vi < v.height)
                hit = np.zeros(Xc.shape[0], dtype=bool)
                hit[inbound] = m[vi[inbound], ui[inbound]]
                votes[s:e] += hit.astype(np.int16)

        if surface_shell_only:
            if grid.shape[0] != nx * ny * nz:
                raise RuntimeError(
                    "scheme_a surface_shell_only: 内部网格尺寸不一致（请勿与非规则 grid 混用）"
                )
            slab_ok = np.ones(grid.shape[0], dtype=bool)
            if enable_slab and H_world is not None:
                slab_ok = _height_slab_mask(grid, pts, H_world, centroid, upper_h, lower_h)
            shell_flat = _visual_hull_surface_shell_mask(votes, slab_ok, nx, ny, nz, min_views)
            hull_xyz = grid[shell_flat]
            if use_pf and stats is not None and hull_xyz.shape[0]:
                hull_xyz = _planform_clip(hull_xyz, centroid, stats, depth_scale, pf_scale)
            print(
                f"   Visual hull (surface_shell): 保留 {hull_xyz.shape[0]}/{grid.shape[0]} 个外壳体素 "
                f"（≥{min_views} 视一致 + 高度带）"
            )
        else:
            accept = votes >= min_views
            if enable_slab and H_world is not None:
                accept &= _height_slab_mask(grid, pts, H_world, centroid, upper_h, lower_h)
            hull_xyz = grid[accept]
            print(
                f"   Visual hull: 保留 {hull_xyz.shape[0]}/{grid.shape[0]} 个体素 "
                f"（≥{min_views} 视一致）"
            )
    elif enable_hull:
        print(f"   Visual hull: 有效掩码视图 {len(view_masks)} < min_views={min_views}，跳过")

    cone_all = np.zeros((0, 3), dtype=np.float64)
    if enable_cone and view_masks:
        z_lo_l: List[float] = []
        z_hi_l: List[float] = []
        if pts.shape[0]:
            for v in views:
                Xc = (v.R_w2c @ pts.T) + v.t_w2c.reshape(3, 1)
                z = Xc[2, :]
                m = z > 1e-6
                if m.any():
                    z_lo_l.append(float(np.percentile(z[m], 3)))
                    z_hi_l.append(float(np.percentile(z[m], 97)))
        if z_lo_l:
            g_lo = float(np.median(z_lo_l))
            g_hi = float(np.median(z_hi_l))
        else:
            g_lo, g_hi = 0.5, 15.0
        depths = np.linspace(g_lo, g_hi, cone_steps)
        clist: List[np.ndarray] = []
        for v in views:
            if v.name not in view_masks:
                continue
            m = view_masks[v.name]
            ys, xs = np.where(m)
            if xs.size == 0:
                continue
            pick = _subsample_indices(xs.size, cone_max_rays, seed=abs(hash(v.name)) % (2**31))
            xs_s = xs[pick][::cone_stride]
            ys_s = ys[pick][::cone_stride]
            for uu, vv in zip(xs_s, ys_s):
                samp = ray_sample_points(v, float(uu), float(vv), depths)
                if samp.shape[0]:
                    clist.append(samp)
        if clist:
            cone_all = np.concatenate(clist, axis=0)
            if enable_slab and H_world is not None:
                cone_all = cone_all[_height_slab_mask(cone_all, pts, H_world, centroid, upper_h, lower_h)]
            if use_pf and stats is not None and cone_all.shape[0]:
                cone_all = _planform_clip(cone_all, centroid, stats, depth_scale, pf_scale)
        print(f"   剪影锥射线: {cone_all.shape[0]} 点（每视最多 {cone_max_rays} 条射线 × 步长 {cone_stride}）")

    uniform = np.zeros((0, 3), dtype=np.float64)
    need_uniform = fallback_uniform and (
        hull_xyz.shape[0] + cone_all.shape[0] == 0 or len(view_masks) < min_views
    )
    if need_uniform:
        box_target = int(getattr(args, "post_sfm_scheme_a_fallback_summary_box_shell_points", 0) or 0)
        if box_target <= 0:
            box_target = max(8000, min(max_new, 50_000))
        use_box_fallback = not bool(
            getattr(args, "post_sfm_scheme_a_disable_summary_box_shell", False)
        )
        box_shell = np.zeros((0, 3), dtype=np.float64)
        surf_mode = "ellipsoid"
        if (
            use_box_fallback
            and stats is not None
            and stats.length_median_px is not None
            and stats.width_median_px is not None
        ):
            surf_mode_raw = getattr(args, "post_sfm_scheme_a_summary_prior_surface_mode", "ellipsoid") or "ellipsoid"
            surf_mode = str(surf_mode_raw).strip().lower()
            if surf_mode == "box":
                box_shell = _summary_dimension_box_shell_points(
                    centroid,
                    stats,
                    depth_scale,
                    pf_scale,
                    H_world,
                    upper_h,
                    lower_h,
                    box_target,
                )
            else:
                box_shell = _summary_dimension_ellipsoid_shell_points(
                    centroid,
                    stats,
                    depth_scale,
                    pf_scale,
                    H_world,
                    upper_h,
                    lower_h,
                    box_target,
                )

        surface_ok_floor = max(48, box_target // 80)
        if box_shell.shape[0] >= surface_ok_floor:
            uniform = box_shell
            shape_desc = "长方体 six-face" if surf_mode == "box" else "椭球单层（Fibonacci）"
            print(
                f"   无/缺掩码兜底: {shape_desc} 比例表面采 {uniform.shape[0]} 点（阴影汇总 L/W×深度 + H）；"
                f"非真实剪影 hull；可加 *_mask.npy 或使用 --post_sfm_scheme_a_summary_prior_surface_mode box 对比直角盒"
            )
        else:
            n_u = max(4, int(getattr(args, "post_sfm_scheme_a_grid", 10) or 10))
            ug = _build_voxel_centers(lo, hi, min(n_u, 32))
            ok = (
                _height_slab_mask(ug, pts, H_world if enable_slab else None, centroid, upper_h, lower_h)
                if enable_slab
                else np.ones(ug.shape[0], dtype=bool)
            )
            uniform = ug[ok]
            if use_pf and stats is not None and uniform.shape[0]:
                uniform = _planform_clip(uniform, centroid, stats, depth_scale, pf_scale)
            print(
                f"   均匀退火: {uniform.shape[0]} 点（掩码不足且无汇总长方体外壳或非 L/W）"
            )

    parts: List[np.ndarray] = []
    if hull_xyz.shape[0]:
        parts.append(hull_xyz)
    if cone_all.shape[0]:
        parts.append(cone_all)
    if uniform.shape[0]:
        parts.append(uniform)
    if not parts:
        print("   scheme_a_geometry_prior: 无任何候选点")
        return

    candidates = np.concatenate(parts, axis=0)
    new_xyz = _dedupe_points(candidates, pts, max_new=max_new, min_dist=min_dist_merge)
    if new_xyz.shape[0] == 0:
        print("   scheme_a_geometry_prior: 去冗后无新点（调大 max_new 或减小 min_dist）")
        return

    rgb_hull = np.array([90, 200, 110], dtype=np.uint8)
    next_id = max_id + 1
    for row in new_xyz:
        records.append(
            Point3DRecord(
                point_id=next_id,
                xyz=row.astype(np.float64),
                rgb=rgb_hull.copy(),
                error=0.0,
                track=[],
            )
        )
        next_id += 1
    sync_colmap_point_outputs(ctx.sparse_dir, records)
    print(
        f"   scheme_a_geometry_prior: 写入 {new_xyz.shape[0]} 个先验点，总点数 {len(records)} "
        f"（hull={hull_xyz.shape[0]}, cone={cone_all.shape[0]}, uniform={uniform.shape[0]}）"
    )
