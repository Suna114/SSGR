"""优选方位角汇总 → 轴对齐长方体 OBJ（供独立脚本与 post_sfm 模块共用）。"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np


@dataclass
class ImageRow:
    filename: str
    azimuth_deg: float
    length_px: float
    width_px: float
    height_px: float
    shadow_length_px: Optional[float]


_AZ_LINE = re.compile(r"^\s*方位角:\s*([\d.]+)\s*°")
_L = re.compile(r"长度 \(L\):\s*([\d.]+)\s*像素")
_W = re.compile(r"宽度 \(W\):\s*([\d.]+)\s*像素")
_H = re.compile(r"高度 \(H\):\s*([\d.]+)\s*像素")
_SHADOW = re.compile(r"阴影长度:\s*([\d.]+)\s*像素")
_IMG = re.compile(r"^图像\s+\d+:\s*(.+)$")


def _preferred_azimuth(azimuth_deg: float, tolerance: float) -> Tuple[bool, Optional[float]]:
    if azimuth_deg is None or np.isnan(azimuth_deg):
        return False, None
    azimuth_normalized = float(azimuth_deg) % 360.0
    preferred_angles = [0.0, 90.0, 180.0, 270.0, 360.0]
    for preferred_angle in preferred_angles:
        diff = abs(azimuth_normalized - preferred_angle)
        if diff > 180:
            diff = 360.0 - diff
        if diff <= tolerance:
            return True, float(preferred_angle)
    return False, None


def _preferred_azimuth_diagonal(azimuth_deg: float, tolerance: float) -> Tuple[bool, Optional[float]]:
    """45°、135°、225°、315°±容差（与 feature_extraction.is_preferred_azimuth_diagonal_45 一致）。"""
    if azimuth_deg is None or np.isnan(azimuth_deg):
        return False, None
    a = float(azimuth_deg) % 360.0
    preferred = (45.0, 135.0, 225.0, 315.0)
    best_pa = None
    best_d = float("inf")
    for pa in preferred:
        d = abs(a - pa)
        if d > 180.0:
            d = 360.0 - d
        if d < best_d:
            best_d = d
            best_pa = pa
    if best_pa is not None and best_d <= float(tolerance):
        return True, float(best_pa)
    return False, None


def _format_cardinal_label(pa: Optional[float]) -> str:
    if pa is None:
        return "-"
    if abs(pa - 360.0) < 1e-6:
        return "0/360"
    return f"{pa:.0f}"


def parse_summary_per_image(text: str) -> List[ImageRow]:
    lines = text.splitlines()
    rows: List[ImageRow] = []
    cur_name: Optional[str] = None
    buf: List[str] = []
    for line in lines:
        mimg = _IMG.match(line.strip())
        if mimg:
            if cur_name is not None and buf:
                r = _parse_block(cur_name, buf)
                if r is not None:
                    rows.append(r)
            cur_name = mimg.group(1).strip()
            buf = []
            continue
        if cur_name is not None:
            buf.append(line)
    if cur_name is not None and buf:
        r = _parse_block(cur_name, buf)
        if r is not None:
            rows.append(r)
    return rows


def _parse_block(filename: str, buf: List[str]) -> Optional[ImageRow]:
    block = "\n".join(buf)
    ma = _AZ_LINE.search(block)
    ml = _L.search(block)
    mw = _W.search(block)
    mh = _H.search(block)
    ms = _SHADOW.search(block)
    if not all([ma, ml, mw, mh]):
        return None
    return ImageRow(
        filename=filename,
        azimuth_deg=float(ma.group(1)),
        length_px=float(ml.group(1)),
        width_px=float(mw.group(1)),
        height_px=float(mh.group(1)),
        shadow_length_px=float(ms.group(1)) if ms else None,
    )


def _min_dist_to_cardinal_deg(azimuth_deg: float) -> float:
    """到 0/90/180/270°（360° 与 0° 等价）的最小角距 [0, 180]。"""
    a = float(azimuth_deg) % 360.0
    best = 180.0
    for c in (0.0, 90.0, 180.0, 270.0):
        d = abs(a - c)
        if d > 180.0:
            d = 360.0 - d
        best = min(best, d)
    return float(best)


def _min_dist_to_diagonal_deg(azimuth_deg: float) -> float:
    """到 45/135/225/315° 的最小角距 [0, 180]。"""
    a = float(azimuth_deg) % 360.0
    best = 180.0
    for c in (45.0, 135.0, 225.0, 315.0):
        d = abs(a - c)
        if d > 180.0:
            d = 360.0 - d
        best = min(best, d)
    return float(best)


def _format_diagonal_label(pa: Optional[float]) -> str:
    if pa is None:
        return "-"
    return f"{pa:.0f}"


def _azimuth_aggregate_weight(dist_deg: float, tol_deg: float, floor: float) -> float:
    """
    越接近主方向角 dist→0，权重越接近 1；dist≥tol 时权重为 floor。
    tol 与 --azimuth_tolerance 一致，用于标定「贴近主方向的带宽」。
    """
    fl = float(max(1e-6, min(floor, 1.0)))
    scale = float(max(tol_deg, 1e-6))
    t = min(max(dist_deg / scale, 0.0), 1.0)
    return float(fl + (1.0 - fl) * (1.0 - t))


def _weighted_mean(values: Sequence[float], weights: Sequence[float]) -> float:
    v = np.asarray(values, dtype=np.float64)
    w = np.asarray(weights, dtype=np.float64)
    s = float(np.sum(w))
    if s <= 1e-18:
        return float(np.mean(v))
    return float(np.sum(v * w) / s)


def _agg(xs: Sequence[float], how: str) -> float:
    a = np.asarray(xs, dtype=np.float64)
    if a.size == 0:
        raise ValueError("空集合，无法聚合")
    if how == "mean":
        return float(np.mean(a))
    return float(np.median(a))


def _write_box_obj_ascii(path: str, rx: float, ry: float, rz: float) -> None:
    rx = float(max(rx, 1e-15))
    ry = float(max(ry, 1e-15))
    rz = float(max(rz, 1e-15))
    verts = [
        (-rx, -ry, -rz),
        (rx, -ry, -rz),
        (rx, ry, -rz),
        (-rx, ry, -rz),
        (-rx, -ry, rz),
        (rx, -ry, rz),
        (rx, ry, rz),
        (-rx, ry, rz),
    ]
    faces = [
        (0, 1, 2),
        (0, 2, 3),
        (4, 6, 5),
        (4, 7, 6),
        (0, 4, 5),
        (0, 5, 1),
        (2, 6, 7),
        (2, 7, 3),
        (0, 3, 7),
        (0, 7, 4),
        (1, 5, 6),
        (1, 6, 2),
    ]
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    lines = ["# axis-aligned box centered at origin", f"# half_axes rx,ry,rz = {rx} {ry} {rz}"]
    for v in verts:
        lines.append(f"v {v[0]:.17g} {v[1]:.17g} {v[2]:.17g}")
    for a, b, c in faces:
        lines.append(f"f {a+1} {b+1} {c+1}")
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")


def write_box_obj(path: str, rx: float, ry: float, rz: float, *, prefer_open3d: bool = True) -> None:
    if prefer_open3d:
        try:
            from post_sfm.mesh_obj_prior_core import make_axis_aligned_box_mesh

            import open3d as o3d

            mesh = make_axis_aligned_box_mesh(rx, ry, rz)
            parent = os.path.dirname(os.path.abspath(path))
            if parent:
                os.makedirs(parent, exist_ok=True)
            if o3d.io.write_triangle_mesh(path, mesh, write_triangle_uvs=False, print_progress=False):
                return
        except Exception:
            pass
    _write_box_obj_ascii(path, rx, ry, rz)


def run_cardinal_box_pipeline(
    summary_path: str,
    out_obj: str,
    *,
    azimuth_tolerance: float = 10.0,
    aggregate: str = "weighted_mean",
    height_mode: str = "cardinal",
    include_all_for_lw: bool = False,
    depth_scale: float = 1.0,
    json_sidecar: str = "",
    ascii_obj_only: bool = False,
    print_report: bool = True,
    azimuth_weight_floor: float = 0.05,
    azimuth_lane: str = "cardinal",
) -> Dict[str, Any]:
    """
    读取 target_dimension_constraints_summary.txt，聚合 L/W/H，写出长方体 OBJ。
    返回 diagnostics 字典。

    azimuth_lane:
      - cardinal: 仅 0/90/180/270/360°±容差（与 convert 汇总 mode=cardinal 一致）
      - diagonal: 仅 45/135/225/315°±容差（斜视，常减轻叠掩—阴影邻带分割误判）；
        聚合得到的 L/W 为斜视图下的表观尺寸，与轴对齐视图不完全同一几何量。
    """
    summary_path = os.path.abspath(summary_path)
    if not os.path.isfile(summary_path):
        raise FileNotFoundError(f"汇总文件不存在: {summary_path}")

    with open(summary_path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()

    all_rows = parse_summary_per_image(text)
    if not all_rows:
        raise RuntimeError(
            "未能从汇总中解析到任何「详细数据」图像块；请确认文件含「图像 N: xxx」段及 L/W/H 像素行。"
        )

    lane = (azimuth_lane or "cardinal").strip().lower()
    if lane not in ("cardinal", "diagonal"):
        raise ValueError(f"azimuth_lane 须为 cardinal | diagonal，收到: {azimuth_lane!r}")

    tol = float(azimuth_tolerance)
    wf = float(max(1e-6, min(float(azimuth_weight_floor), 0.999)))

    def _match_lane(r: ImageRow) -> Tuple[bool, Optional[float]]:
        if lane == "diagonal":
            return _preferred_azimuth_diagonal(r.azimuth_deg, tol)
        return _preferred_azimuth(r.azimuth_deg, tol)

    def _dist_lane(r: ImageRow) -> float:
        if lane == "diagonal":
            return _min_dist_to_diagonal_deg(r.azimuth_deg)
        return _min_dist_to_cardinal_deg(r.azimuth_deg)

    preferred_pairs: List[Tuple[ImageRow, float]] = []
    for r in all_rows:
        ok, pa = _match_lane(r)
        if ok and pa is not None:
            preferred_pairs.append((r, pa))

    if include_all_for_lw:
        use_lw = list(all_rows)
        if print_report:
            print("[WARN] 已使用 include_all_for_lw：L/W 未限制在优选方位角。")
    else:
        use_lw = [t[0] for t in preferred_pairs]
        if not use_lw:
            raise RuntimeError(
                f"优选方位（lane={lane}，容差 {tol}°）下无可用图像（共解析 {len(all_rows)} 张）。"
                f"请增大 azimuth_tolerance 或检查方位角。"
            )

    how = aggregate
    if how not in ("median", "mean", "weighted_mean"):
        raise ValueError(f"aggregate 须为 median | mean | weighted_mean，收到: {how}")

    if how == "weighted_mean":
        w_lw = [_azimuth_aggregate_weight(_dist_lane(r), tol, wf) for r in use_lw]
        Lpx = _weighted_mean([x.length_px for x in use_lw], w_lw)
        Wpx = _weighted_mean([x.width_px for x in use_lw], w_lw)
    else:
        Lpx = _agg([x.length_px for x in use_lw], how)
        Wpx = _agg([x.width_px for x in use_lw], how)

    if height_mode == "cardinal":
        if not preferred_pairs and not include_all_for_lw:
            raise RuntimeError("cardinal 高度模式需要至少一张优选方位图像；当前无。")
        h_src = [t[0] for t in preferred_pairs] if preferred_pairs else use_lw
    else:
        h_src = list(all_rows)

    if how == "weighted_mean":
        w_h = [_azimuth_aggregate_weight(_dist_lane(r), tol, wf) for r in h_src]
        Hpx = _weighted_mean([x.height_px for x in h_src], w_h)
    else:
        Hpx = _agg([x.height_px for x in h_src], how)

    s = float(depth_scale)
    Lw = Lpx * s
    Ww = Wpx * s
    Hw = Hpx * s
    rx, ry, rz = 0.5 * Lw, 0.5 * Hw, 0.5 * Ww

    ref_label = "45/135/225/315°" if lane == "diagonal" else "0/90/180/270°"

    if print_report:
        print("")
        print("========== build_cardinal_azimuth_box_obj 测算播报 ==========")
        print(f"汇总文件: {summary_path}")
        print(f"方位 lane: {lane} | 优选参考: {ref_label} | 容差: {tol}° | L/W/H 聚合: {how} | depth-scale: {s}")
        if how == "weighted_mean":
            print(
                f"  方位权重: 到最近参考角角距 d，线性 w = {wf} + (1-{wf})*(1-min(d/{tol},1))，"
                f"d=0 时 w=1，d≥{tol}° 时 w={wf}"
            )
        if lane == "diagonal":
            print(
                "  说明: diagonal 下 L/W 为斜视图投影尺寸；与 cardinal 轴对齐视图的长宽不完全相同，"
                "若需车体真 L/W 请用多视角联合或仍以 cardinal 为主、diagonal 作叠掩稳健性补充。"
            )
        print("")
        print(f"[1] 用于 长度L、宽度W 的图像（共 {len(use_lw)} 张）:")
        for idx, r in enumerate(use_lw, start=1):
            ok_pa, pa = _match_lane(r)
            if lane == "diagonal":
                near = _format_diagonal_label(pa if ok_pa else None)
            else:
                near = _format_cardinal_label(pa if ok_pa else None)
            sh = f"{r.shadow_length_px:.2f}" if r.shadow_length_px is not None else "-"
            d_ref = _dist_lane(r)
            w_s = _azimuth_aggregate_weight(d_ref, tol, wf) if how == "weighted_mean" else None
            w_str = f" | 到参考角角距={d_ref:.2f}° 权重={w_s:.4f}" if w_s is not None else ""
            print(f"    ({idx}) {r.filename}")
            print(
                f"        方位角={r.azimuth_deg:.2f}° (邻近 {near}°){w_str} | "
                f"L={r.length_px:.4f}  W={r.width_px:.4f}  H={r.height_px:.4f} 像素 | 阴影长度={sh} 像素"
            )
        print("")
        print(f"[2] 用于 高度H 聚合的图像（height_mode={height_mode}，共 {len(h_src)} 张）:")
        same_h_as_lw = height_mode == "cardinal" and (not include_all_for_lw)
        if same_h_as_lw:
            print("    (与 [1] 相同: 均为优选方位角样本上的 H；加权与 [1] 一致)")
        else:
            for hi, r in enumerate(h_src, start=1):
                ok_pa, pa = _match_lane(r)
                if lane == "diagonal":
                    near = _format_diagonal_label(pa if ok_pa else None)
                else:
                    near = _format_cardinal_label(pa if ok_pa else None)
                d_ref = _dist_lane(r)
                w_s = _azimuth_aggregate_weight(d_ref, tol, wf) if how == "weighted_mean" else None
                w_str = f" 角距={d_ref:.2f}° w={w_s:.4f}" if w_s is not None else ""
                print(
                    f"    ({hi}) {r.filename}  方位={r.azimuth_deg:.2f}° 邻近{near}°{w_str}  "
                    f"H={r.height_px:.4f} 像素"
                )
        print("")
        print("[3] 聚合后的长宽高（用于写 OBJ 长方体）:")
        print(f"    像素域: L={Lpx:.6f}  W={Wpx:.6f}  H={Hpx:.6f}  ({how})")
        if abs(s - 1.0) > 1e-12:
            print(f"    世界尺度 (× depth-scale={s}): L={Lw:.8f}  W={Ww:.8f}  H={Hw:.8f}")
        print(f"    半轴 rx=L/2, ry=H/2, rz=W/2: {rx:.8f}  {ry:.8f}  {rz:.8f}")
        print("==============================================================")
        print("")

    per_img_lw = []
    for r in use_lw:
        ok_pa, pa = _match_lane(r)
        d_c = _dist_lane(r)
        w_agg = _azimuth_aggregate_weight(d_c, tol, wf) if how == "weighted_mean" else 1.0
        mref = float(pa) if ok_pa and pa is not None else None
        rec: Dict[str, Any] = {
            "filename": r.filename,
            "azimuth_deg": r.azimuth_deg,
            "azimuth_lane": lane,
            "matched_reference_deg": mref,
            "dist_to_reference_deg": d_c,
            "aggregate_weight": w_agg,
            "L_px": r.length_px,
            "W_px": r.width_px,
            "H_px": r.height_px,
            "shadow_length_px": r.shadow_length_px,
        }
        if lane == "cardinal":
            rec["matched_cardinal_deg"] = mref
            rec["dist_to_cardinal_deg"] = d_c
        per_img_lw.append(rec)
    per_img_h = []
    for r in h_src:
        d_c = _dist_lane(r)
        w_agg = _azimuth_aggregate_weight(d_c, tol, wf) if how == "weighted_mean" else 1.0
        per_img_h.append(
            {
                "filename": r.filename,
                "azimuth_deg": r.azimuth_deg,
                "azimuth_lane": lane,
                "dist_to_reference_deg": d_c,
                "aggregate_weight": w_agg,
                "H_px": r.height_px,
            }
        )
        if lane == "cardinal":
            per_img_h[-1]["dist_to_cardinal_deg"] = d_c

    diag: Dict[str, Any] = {
        "summary_file": summary_path,
        "azimuth_lane": lane,
        "azimuth_tolerance_deg": tol,
        "aggregate": how,
        "azimuth_weight_floor": wf,
        "height_mode": height_mode,
        "include_all_for_lw": bool(include_all_for_lw),
        "num_parsed_images": len(all_rows),
        "num_lane_filtered_images": len(preferred_pairs),
        # 兼容旧诊断脚本字段名（lane=diagonal 时仍为 lane 优选样本数）
        "num_cardinal_images": len(preferred_pairs),
        "num_used_for_lw": len(use_lw),
        "used_filenames_for_lw": [x.filename for x in use_lw],
        "per_image_for_lw": per_img_lw,
        "per_image_for_height": per_img_h,
        "aggregated_lwh_pixels": {"L": Lpx, "W": Wpx, "H": Hpx},
        "aggregated_lwh_world": {"L": Lw, "W": Ww, "H": Hw},
        "length_width_height_pixels": {"L": Lpx, "W": Wpx, "H": Hpx},
        "half_axes_world_xyz": {"rx": rx, "ry": ry, "rz": rz},
        "depth_scale": s,
        "colmap_box_notes": {
            "X": "半轴 rx = L/2，长度向",
            "Y": "半轴 ry = H/2，竖直向（高度）",
            "Z": "半轴 rz = W/2，宽度向",
            "cameras_typically": "若约定视线沿 -Y，相机常在 Y<0；网格仍居中于原点",
            "diagonal_lane_caveat": (
                "lane=diagonal 时 L/W 来自斜视投影；轴对齐车体尺寸应以 cardinal 或多视角反投影为准。"
                if lane == "diagonal"
                else ""
            ),
        },
    }

    out_abs = os.path.abspath(out_obj)
    write_box_obj(out_abs, rx, ry, rz, prefer_open3d=not ascii_obj_only)
    if print_report:
        print(f"[OK] 已写出长方体 OBJ: {out_abs}")
        print(
            f"    汇总: L×W×H（世界）= {Lw:.8f} x {Ww:.8f} x {Hw:.8f} | "
            f"lane样本={len(preferred_pairs)} | H聚合张数={len(h_src)}"
        )

    js = (json_sidecar or "").strip()
    if js:
        jp = os.path.abspath(js)
        parent = os.path.dirname(jp)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(jp, "w", encoding="utf-8") as jf:
            json.dump(diag, jf, indent=2, ensure_ascii=False)
        if print_report:
            print(f"   诊断 JSON: {jp}")

    diag["out_obj"] = out_abs
    return diag
