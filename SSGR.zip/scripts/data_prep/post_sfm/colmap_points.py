"""读写 COLMAP points3D.bin / points3D.txt（保留点 ID 与 track）。

约定（与本仓库 SfM / 训练一致）：
- `Point3DRecord.xyz`、写回的 `points3D.*` 均在 **COLMAP 稀疏重建世界坐标系**中，与同一
  `sparse/0` 下的 `cameras.bin`、`images.bin` 外参一致（OpenCV/COLMAP：`X_cam = R @ X_world + t`）。
- `scene/dataset_readers.readColmapSceneInfo` 等训练入口直接读上述 `points3D`，**无额外全局旋转**。
  因此：**表面采样替换原点云**时，传入 `point3d_records_from_mesh_samples` 的坐标必须已是 COLMAP world
 （例如 `build_mesh_prior_pointcloud` 的 `xyz_world`）；若网格来自其他软件坐标系，应仅通过 mesh→world
  的相似/刚体链（及可选顶点轴镜像 `mesh_vertex_axis_sign`）对齐，勿在写回 sparse 后再套一层「场景变换」。
"""

from __future__ import annotations

import os
import struct
from dataclasses import dataclass, field
from typing import List, Tuple

import numpy as np


@dataclass
class Point3DRecord:
    point_id: int
    xyz: np.ndarray
    rgb: np.ndarray  # uint8 shape (3,)
    error: float
    track: List[Tuple[int, int]] = field(default_factory=list)


def read_next_bytes(fid, num_bytes, format_char_sequence, endian_character="<"):
    data = fid.read(num_bytes)
    return struct.unpack(endian_character + format_char_sequence, data)


def read_points3d_binary_full(path: str) -> List[Point3DRecord]:
    out: List[Point3DRecord] = []
    with open(path, "rb") as fid:
        num_points = read_next_bytes(fid, 8, "Q")[0]
        for _ in range(num_points):
            props = read_next_bytes(fid, 43, "QdddBBBd")
            pid = int(props[0])
            xyz = np.array(props[1:4], dtype=np.float64)
            rgb = np.array(props[4:7], dtype=np.uint8)
            err = float(props[7])
            track_len = read_next_bytes(fid, 8, "Q")[0]
            if track_len:
                raw = read_next_bytes(fid, int(8 * track_len), "ii" * int(track_len))
                track = [(int(raw[i]), int(raw[i + 1])) for i in range(0, len(raw), 2)]
            else:
                track = []
            out.append(Point3DRecord(point_id=pid, xyz=xyz, rgb=rgb, error=err, track=track))
    return out


def write_points3d_binary(path: str, records: List[Point3DRecord]) -> None:
    with open(path, "wb") as fid:
        fid.write(struct.pack("<Q", len(records)))
        for p in records:
            fid.write(struct.pack("<Q", int(p.point_id)))
            fid.write(struct.pack("<ddd", float(p.xyz[0]), float(p.xyz[1]), float(p.xyz[2])))
            r, g, b = int(p.rgb[0]), int(p.rgb[1]), int(p.rgb[2])
            fid.write(struct.pack("<BBB", r, g, b))
            fid.write(struct.pack("<d", float(p.error)))
            fid.write(struct.pack("<Q", len(p.track)))
            for img_id, feat_idx in p.track:
                fid.write(struct.pack("<ii", int(img_id), int(feat_idx)))


def write_points3d_text(path: str, records: List[Point3DRecord]) -> None:
    with open(path, "w", encoding="utf-8") as fid:
        fid.write("# POINT3D_ID, X, Y, Z, R, G, B, ERROR, TRACK[] as (IMAGE_ID, POINT2D_IDX)\n")
        for p in records:
            track_parts = []
            for img_id, p2d in p.track:
                track_parts.append(str(int(img_id)))
                track_parts.append(str(int(p2d)))
            track_str = " ".join(track_parts)
            r, g, b = int(p.rgb[0]), int(p.rgb[1]), int(p.rgb[2])
            line = (
                f"{int(p.point_id)} {p.xyz[0]:.8e} {p.xyz[1]:.8e} {p.xyz[2]:.8e} "
                f"{r} {g} {b} {p.error:.8e} {track_str}\n"
            )
            fid.write(line)


def store_ply_ascii(path: str, xyz: np.ndarray, rgb_u8: np.ndarray) -> None:
    """与训练侧类似：写含零法向的 PLY（ascii 较慢但依赖少；点数通常 <1e6）。"""
    n = xyz.shape[0]
    rgb_u8 = np.asarray(rgb_u8, dtype=np.uint8).reshape(n, 3)
    with open(path, "w", encoding="utf-8") as f:
        f.write("ply\nformat ascii 1.0\n")
        f.write(f"element vertex {n}\n")
        f.write("property float x\nproperty float y\nproperty float z\n")
        f.write("property float nx\nproperty float ny\nproperty float nz\n")
        f.write("property uchar red\nproperty uchar green\nproperty uchar blue\n")
        f.write("end_header\n")
        for i in range(n):
            x, y, z = float(xyz[i, 0]), float(xyz[i, 1]), float(xyz[i, 2])
            r, g, b = int(rgb_u8[i, 0]), int(rgb_u8[i, 1]), int(rgb_u8[i, 2])
            f.write(f"{x} {y} {z} 0 0 0 {r} {g} {b}\n")


def point3d_records_from_mesh_samples(
    xyz: np.ndarray, rgb: np.ndarray, start_id: int = 1
) -> List[Point3DRecord]:
    """仅以表面采样点替换/重建 points3D（无 track，误差 0）；ID 从 start_id 递增。

    `xyz` 必须为 COLMAP world，与 replace 前 `sparse` 中三角化点同一坐标系。
    """
    xyz = np.asarray(xyz, dtype=np.float64).reshape(-1, 3)
    rgb = np.asarray(rgb, dtype=np.uint8).reshape(-1, 3)
    n = int(xyz.shape[0])
    out: List[Point3DRecord] = []
    for i in range(n):
        pid = int(start_id + i)
        out.append(
            Point3DRecord(
                point_id=pid,
                xyz=xyz[i].copy(),
                rgb=rgb[i].copy(),
                error=0.0,
                track=[],
            )
        )
    return out


def sync_colmap_point_outputs(sparse_dir: str, records: List[Point3DRecord]) -> None:
    """同步写 points3D.bin / .txt / .ply；坐标系须为 COLMAP world（见模块说明）。"""
    xyz = np.stack([p.xyz for p in records], axis=0)
    rgb = np.stack([p.rgb.astype(np.uint8) for p in records], axis=0)
    write_points3d_binary(os.path.join(sparse_dir, "points3D.bin"), records)
    write_points3d_text(os.path.join(sparse_dir, "points3D.txt"), records)
    store_ply_ascii(os.path.join(sparse_dir, "points3D.ply"), xyz, rgb)
