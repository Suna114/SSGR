"""
OBJ / 三角网格 → 与 COLMAP sparse 对齐 → 表面采样点云（方案 A：仅几何初始化）。

流程：
  1) 从 sparse/0 读取现有三角化点的 XYZ；
  2) 在模型坐标下对网格均匀采样；
  3) 包络盒粗对齐（统一尺度 + 平移，使与 sparse AABB 同级）；
  4) 可选 Open3D 多阶段 ICP 细化刚体增量（叠乘到相似变换上）；
  5) 变换后可选按 sparse 扩张 AABB 裁剪；若给定名义半轴（比例盒路径），会与变换后名义盒世界 AABB
    取并集，避免因稀疏在竖直方向过薄而切掉 ±Y 顶面；
  6) 输出 N×3 点与 RGB：默认 **uniform 中性灰**（非 SAR 强度、非法向伪彩），与 COLMAP
    「无图像采样的点」惯例一致；训练时由 SH/图像学习颜色。可选法向伪彩仅用于调试。

替换 `points3D` 时：`xyz_world` 即为 **COLMAP sparse 世界系**（与 `cameras.bin`/`images.bin`
及本仓库 `readColmapSceneInfo` 一致）；跨软件 mesh 轴向用 `mesh_vertex_axis_sign` 等在 local 端修正，
勿在写回 sparse 之后再对整场景做与 COLMAP 定义不一致的二次变换。

依赖：numpy；ICP 与网格读写需要 open3d（pip install open3d）。
"""

from __future__ import annotations

import itertools
import json
import math
import os
from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np


def parse_vertex_axis_sign(spec: Optional[str]) -> np.ndarray:
    """将 'sx,sy,sz' 解析为各轴 ±1，对齐前按 v*=sign 作用在网格顶点（与 COLMAP 世界 Y≈向上的 CAD 轴向统一）。"""
    raw = (spec or "").strip()
    if not raw:
        raw = "1,1,1"
    parts = [p.strip() for p in raw.split(",")]
    if len(parts) != 3:
        raise ValueError(f"vertex_axis_sign 需要三个逗号分隔分量（±1），收到: {spec!r}")
    out: list[float] = []
    for p in parts:
        if not p:
            raise ValueError(f"vertex_axis_sign 分量无效: {spec!r}")
        v = float(p)
        if abs(abs(v) - 1.0) > 1e-6:
            raise ValueError(f"vertex_axis_sign 每项须为 ±1，收到 {p!r}")
        out.append(-1.0 if v < 0 else 1.0)
    return np.asarray(out, dtype=np.float64)


def apply_vertex_axis_sign_to_triangle_mesh(mesh: Any, sign_xyz: np.ndarray) -> None:
    """原地 v *= sign；不改变三角索引。单轴镜像后重算法向。"""
    _require_open3d()
    import open3d as o3d

    s = np.asarray(sign_xyz, dtype=np.float64).reshape(3)
    s = np.sign(s)
    s[np.abs(s) < 1e-12] = 1.0
    if np.allclose(s, np.ones(3)):
        return
    v = np.asarray(mesh.vertices, dtype=np.float64)
    mesh.vertices = o3d.utility.Vector3dVector(v * s.reshape(1, 3))
    mesh.compute_triangle_normals()
    mesh.compute_vertex_normals()


def _require_open3d():
    try:
        import open3d as o3d  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "mesh OBJ 先验需要 open3d：pip install open3d\n"
            "若仅想跳过 ICP，可设 --post_sfm_mesh_skip_icp，仍需要 open3d 读 OBJ。"
        ) from e


def _read_points3d_text_xyz(path: str) -> np.ndarray:
    """仅解析 COLMAP points3D.txt 的 XYZ，避免 `import scene` 触发额外依赖。"""
    rows: list[list[float]] = []
    with open(path, "r", encoding="utf-8") as fid:
        for line in fid:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            elems = line.split()
            if len(elems) < 4:
                continue
            rows.append([float(elems[1]), float(elems[2]), float(elems[3])])
    if not rows:
        return np.zeros((0, 3), dtype=np.float64)
    return np.asarray(rows, dtype=np.float64)


def load_sparse_xyz_from_colmap_sparse_dir(sparse_dir: str, max_points: int = 500_000) -> np.ndarray:
    """优先 points3D.bin，否则 points3D.txt。"""
    from post_sfm.colmap_points import read_points3d_binary_full

    bin_path = os.path.join(sparse_dir, "points3D.bin")
    txt_path = os.path.join(sparse_dir, "points3D.txt")
    if os.path.isfile(bin_path):
        recs = read_points3d_binary_full(bin_path)
        if not recs:
            return np.zeros((0, 3), dtype=np.float64)
        xyz = np.stack([r.xyz for r in recs], axis=0)
    elif os.path.isfile(txt_path):
        xyz = _read_points3d_text_xyz(txt_path)
    else:
        return np.zeros((0, 3), dtype=np.float64)

    if xyz.shape[0] > max_points:
        rng = np.random.default_rng(0)
        idx = rng.choice(xyz.shape[0], size=max_points, replace=False)
        xyz = xyz[idx]
    return xyz.astype(np.float64)


def make_axis_aligned_box_mesh(rx: float, ry: float, rz: float, *, ground_contact_at_origin: bool = True):
    """
    轴对齐长方体三角网格（12 个三角面），各轴半边长 rx, ry, rz。
    与 COLMAP 世界系一致：X≈目标长度、Y≈竖直、Z≈宽度。

    ground_contact_at_origin=True（默认）：底面中心在局部原点，目标向上沿 -Y 延伸（SAR 接地点语义）。
    False：几何中心在原点（旧行为）。
    """
    _require_open3d()
    import open3d as o3d

    rx = float(max(rx, 1e-12))
    ry = float(max(ry, 1e-12))
    rz = float(max(rz, 1e-12))
    mesh = o3d.geometry.TriangleMesh.create_box(
        width=2.0 * rx, height=2.0 * ry, depth=2.0 * rz
    )
    mesh.translate(-mesh.get_center())
    if ground_contact_at_origin:
        reanchor_triangle_mesh_bottom_center_to_local_origin(mesh)
    mesh.compute_vertex_normals()
    mesh.compute_triangle_normals()
    return mesh


def make_axis_aligned_ground_plane_mesh(rx: float, rz: float):
    """
    XZ 成像/接地平面三角网格，局部原点为平面中心。

    与 ground_contact 盒模型兼容：底面中心在 (0,0,0)，Y 不提供厚度。
    适合 SAR-like 目标散射图作为近似平面纹理/散射支撑，而不是可见光实体六面体表面。
    """
    _require_open3d()
    import open3d as o3d

    rx = float(max(rx, 1e-12))
    rz = float(max(rz, 1e-12))
    vertices = np.asarray(
        [
            [-rx, 0.0, -rz],
            [rx, 0.0, -rz],
            [rx, 0.0, rz],
            [-rx, 0.0, rz],
        ],
        dtype=np.float64,
    )
    triangles = np.asarray([[0, 1, 2], [0, 2, 3]], dtype=np.int32)
    mesh = o3d.geometry.TriangleMesh(
        o3d.utility.Vector3dVector(vertices),
        o3d.utility.Vector3iVector(triangles),
    )
    mesh.compute_vertex_normals()
    mesh.compute_triangle_normals()
    return mesh


def reanchor_triangle_mesh_bottom_center_to_local_origin(mesh: Any) -> np.ndarray:
    """
    平移网格使底面中心（XZ 中点 + Y 最大）位于局部 (0,0,0)。返回应用的平移向量。
    """
    _require_open3d()
    v = np.asarray(mesh.vertices, dtype=np.float64)
    if v.size == 0:
        return np.zeros(3, dtype=np.float64)
    lo = v.min(axis=0)
    hi = v.max(axis=0)
    bottom = np.array(
        [0.5 * (lo[0] + hi[0]), float(hi[1]), 0.5 * (lo[2] + hi[2])],
        dtype=np.float64,
    )
    v2 = v - bottom.reshape(1, 3)
    mesh.vertices = __import__("open3d").utility.Vector3dVector(v2)
    mesh.compute_vertex_normals()
    mesh.compute_triangle_normals()
    return bottom


def horizontal_elongation_direction_xz(
    xyz: np.ndarray,
    *,
    centroid: Optional[np.ndarray] = None,
    min_std_ratio: float = 1.12,
    min_samples: int = 8,
) -> Tuple[Optional[np.ndarray], float]:
    """
    XZ 平面内主伸长方向（近似地面长轴），返回单位向量 (dx, 0, dz) 与 √λ_max/√λ_min；
    比值 < min_std_ratio 时认为各向同性。
    """
    if xyz is None or xyz.ndim != 2 or xyz.shape[1] != 3 or xyz.shape[0] < min_samples:
        return None, 1.0
    c = np.median(xyz, axis=0) if centroid is None else centroid
    xz = xyz[:, [0, 2]] - np.asarray([[float(c[0]), float(c[2])]])
    if np.allclose(xz.std(axis=0), 0.0):
        return None, 1.0
    cov = np.cov(xz.T)
    ew, ev = np.linalg.eigh(cov)
    ii = int(np.argmax(ew))
    jj = 1 - ii
    r = float(np.sqrt(max(float(ew[ii]), 1e-30) / max(float(ew[jj]), 1e-30)))
    if r < min_std_ratio:
        return None, r
    v2 = np.asarray(ev[:, ii], dtype=np.float64).ravel()
    d = np.array([float(v2[0]), 0.0, float(v2[1])], dtype=np.float64)
    ln = float(np.linalg.norm(d))
    if ln < 1e-12:
        return None, r
    d /= ln
    return d, r


def rotation_world_y(phi_rad: float) -> np.ndarray:
    """世界系绕 +Y：v' = R @ v；Ry @ e_x = (cos φ, 0, -sin φ)。"""
    c = float(np.cos(phi_rad))
    s = float(np.sin(phi_rad))
    return np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]], dtype=np.float64)


def rotation_y_align_mesh_local_x_to_xz_direction(direction_xz_unit: np.ndarray) -> np.ndarray:
    """将车体长方体模型的局部长度轴（+X）旋到给定水平向量 (dx,0,dz)（单位）。"""
    d = np.asarray(direction_xz_unit, dtype=np.float64).reshape(3)
    dx, dz = float(d[0]), float(d[2])
    ln = (dx * dx + dz * dz) ** 0.5
    if ln < 1e-12:
        return np.eye(3, dtype=np.float64)
    phi = float(np.arctan2(-dz / ln, dx / ln))
    return rotation_world_y(phi)


def rotation_y_align_mesh_local_from_summary_gamma_deg(gamma_deg: float) -> np.ndarray:
    """SAR「朝向角 γ」：长方体模版本地 +X 与距离向一致时再绕世界 Y 转 γ°。"""
    return rotation_world_y(float(np.deg2rad(float(gamma_deg))))


def oriented_shadow_box_triangle_mesh(
    rx: float,
    ry: float,
    rz: float,
    R_yaw_world: Optional[np.ndarray] = None,
):
    """中心原点长方体网格；可选先乘旋转再规范化法向。"""
    mesh = make_axis_aligned_box_mesh(rx, ry, rz)
    if R_yaw_world is not None:
        R = np.asarray(R_yaw_world, dtype=np.float64).reshape(3, 3)
        mesh.rotate(R, center=np.zeros(3))
        mesh.compute_vertex_normals()
        mesh.compute_triangle_normals()
    return mesh


def sample_axis_aligned_box_mesh_surface(
    rx: float,
    ry: float,
    rz: float,
    centroid: np.ndarray,
    n_target: int,
    *,
    use_poisson_disk: bool = False,
    seed: int = 0,
) -> np.ndarray:
    """
    与 merge_mesh_obj_prior 相同：Open3D 在三角网格表面均匀或泊松盘采样，再平移到 centroid。
    返回世界系 (N,3)。
    """
    mesh = make_axis_aligned_box_mesh(rx, ry, rz)
    c = np.asarray(centroid, dtype=np.float64).reshape(3)
    n_target = int(max(1, n_target))
    if use_poisson_disk:
        xyz_loc, _ = sample_mesh_surface_poisson(mesh, n_target, seed=int(seed))
    else:
        xyz_loc, _ = sample_mesh_surface_uniform(mesh, n_target, seed=int(seed))
    return xyz_loc + c.reshape(1, 3)


def load_triangle_mesh(path: str):
    _require_open3d()
    import open3d as o3d

    ext = os.path.splitext(path)[1].lower()
    if ext not in (".obj", ".ply", ".stl", ".off"):
        raise ValueError(f"不支持的网格扩展名: {ext}（支持 .obj .ply .stl .off）")
    mesh = o3d.io.read_triangle_mesh(path)
    if len(mesh.vertices) == 0 or len(mesh.triangles) == 0:
        raise ValueError(f"网格无有效顶点或三角面: {path}")
    mesh.compute_vertex_normals()
    mesh.remove_duplicated_vertices()
    mesh.remove_duplicated_triangles()
    mesh.remove_degenerate_triangles()
    mesh.remove_unreferenced_vertices()
    return mesh


def _bbox_axes_diag(pts: np.ndarray) -> Tuple[np.ndarray, float]:
    if pts.shape[0] == 0:
        return np.zeros(3, dtype=np.float64), 1.0
    lo = pts.min(axis=0)
    hi = pts.max(axis=0)
    ctr = 0.5 * (lo + hi)
    ext = hi - lo
    diag = float(np.linalg.norm(ext))
    if diag < 1e-9:
        diag = 1.0
    return ctr, diag


def coarse_similarity_translation_scale(src_pts: np.ndarray, tgt_pts: np.ndarray) -> np.ndarray:
    """
    相似变换（旋转为单位阵）：x' = s * x + t，使 src 包络与 tgt 包络尺度、中心对齐。
    t = c_tgt - s * c_src

    src_pts 应对齐**完整几何的外包络**（建议网格全部顶点）；若仅用表面子采样，
    对角线常小于真实 CAD 外包络 → s 偏大 → 整模在世上显得过大（此前靠 crop 才会「看起来合适」）。
    """
    c_s, d_s = _bbox_axes_diag(src_pts)
    c_t, d_t = _bbox_axes_diag(tgt_pts)
    if d_s < 1e-9:
        s = 1.0
    else:
        s = d_t / d_s
    t = c_t - s * c_s
    T = np.eye(4, dtype=np.float64)
    T[0, 0] = T[1, 1] = T[2, 2] = s
    T[:3, 3] = t
    return T


def coarse_similarity_nominal_box_semi_axes(
    rx: float,
    ry: float,
    rz: float,
    tgt_pts: np.ndarray,
) -> np.ndarray:
    """
    与 coarse_similarity_translation_scale 相同形式，但源网格用名义轴长 2*rx,2*ry,2*rz 的对角线
    代替「表面采样点 AABB」（预旋转盒面采样会夸大 AABB，导致 s 严重失真）。
    假定网格已居中于原点（与 make_axis_aligned_box_mesh 一致）。
    """
    c_t, d_t = _bbox_axes_diag(tgt_pts)
    ext = np.array([2.0 * float(rx), 2.0 * float(ry), 2.0 * float(rz)], dtype=np.float64)
    d_s = float(np.linalg.norm(ext))
    if d_s < 1e-18:
        s = 1.0
    else:
        s = d_t / d_s
    c_s = np.zeros(3, dtype=np.float64)
    t = c_t - s * c_s
    T = np.eye(4, dtype=np.float64)
    T[0, 0] = T[1, 1] = T[2, 2] = float(s)
    T[:3, 3] = t
    return T


def coarse_translate_centroid_identity_scale(tgt_pts: np.ndarray) -> np.ndarray:
    """
    网格已按名义半轴建盒并 centered at origin；不对模型做整体缩放，
    仅平移使盒心与目标点集 AABB 几何中心重合，世界系边长保持名义 2rx×2ry×2rz。
    """
    c_t, _ = _bbox_axes_diag(tgt_pts)
    T = np.eye(4, dtype=np.float64)
    T[:3, 3] = c_t
    return T


def coarse_translate_ground_contact_to_anchor(
    tgt_pts: np.ndarray,
    anchor: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    假定网格底面中心已在局部原点：仅平移使接地点落在 anchor（默认 sparse footprint 底面中心）。
    """
    try:
        from sar.scene_anchor import sar_footprint_bottom_center
    except ImportError:
        sar_footprint_bottom_center = None  # type: ignore

    if anchor is None:
        if sar_footprint_bottom_center is not None:
            anchor = sar_footprint_bottom_center(tgt_pts)
        else:
            anchor = _bbox_axes_diag(tgt_pts)[0]
            anchor = np.array([anchor[0], float(np.max(tgt_pts[:, 1])), anchor[2]])
    anchor = np.asarray(anchor, dtype=np.float64).reshape(3)
    T = np.eye(4, dtype=np.float64)
    T[:3, 3] = anchor
    return T, anchor


def coarse_similarity_nominal_box_ground_contact(
    rx: float,
    ry: float,
    rz: float,
    tgt_pts: np.ndarray,
    anchor: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """名义盒底面在原点：按稀疏对角线缩放，接地点对齐 anchor。"""
    _, d_t = _bbox_axes_diag(tgt_pts)
    ext = np.array([2.0 * float(rx), 2.0 * float(ry), 2.0 * float(rz)], dtype=np.float64)
    d_s = float(np.linalg.norm(ext))
    s = (d_t / d_s) if d_s > 1e-18 else 1.0
    T, anchor_out = coarse_translate_ground_contact_to_anchor(tgt_pts, anchor=anchor)
    T = T.copy()
    T[0, 0] = T[1, 1] = T[2, 2] = float(s)
    return T, anchor_out


def transform_points(T: np.ndarray, xyz: np.ndarray) -> np.ndarray:
    R = T[:3, :3]
    t = T[:3, 3]
    return (xyz @ R.T) + t


def _similarity_uniform_scale_about_point(
    T: np.ndarray,
    scale: float,
    pivot_xyz: np.ndarray,
) -> np.ndarray:
    """各向缩放 s（保持旋转）；pivot 为缩放不动点（SAR 接地点 / 原点）。"""
    Tf = np.asarray(T, dtype=np.float64).copy()
    s = float(scale)
    c = np.asarray(pivot_xyz, dtype=np.float64).reshape(3)
    Rpart = Tf[:3, :3].astype(np.float64)
    tpart = Tf[:3, 3].astype(np.float64)
    Tf[:3, :3] = s * Rpart
    Tf[:3, 3] = s * tpart + (1.0 - s) * c
    return Tf


def _similarity_uniform_scale_about_centroid(
    T: np.ndarray,
    scale: float,
    centroid_xyz: np.ndarray,
) -> np.ndarray:
    """兼容旧名：同 _similarity_uniform_scale_about_point。"""
    return _similarity_uniform_scale_about_point(T, scale, centroid_xyz)


def _import_compute_sar_camera_pose():
    try:
        from sar.geometry import compute_sar_camera_pose as pose_fn

        return pose_fn
    except Exception:
        pass
    try:
        from sfm.deps import compute_sar_camera_pose as pose_fn

        return pose_fn
    except Exception:
        return None


def _sar_pixel_spacing_from_params(sar_params: dict) -> Tuple[float, float]:
    """与 sar/rasterizer._project_sar 相同的距离向/方位向米/像素标尺。"""
    if "range_pixel_spacing" in sar_params and "azimuth_pixel_spacing" in sar_params:
        return float(sar_params["range_pixel_spacing"]), float(sar_params["azimuth_pixel_spacing"])
    Va = float(sar_params.get("Va", 250.0))
    prf = float(sar_params.get("prf", 2500.0))
    C_sp = float(sar_params.get("C", 3e8))
    fs = float(sar_params.get("fs", 500e6))
    d_az = Va / max(prf, 1e-12)
    d_rng = C_sp / (2.0 * max(fs, 1e-12))
    return d_rng, d_az


def _sar_project_world_to_pixels_xy(
    xyz_w: np.ndarray,
    *,
    sar_params: dict,
    depression_deg: float,
    azimuth_deg: float,
) -> Optional[np.ndarray]:
    """
    投影到 SAR 近似图像像素平面 (x_image, y_image)，与 rasterizer._project_sar / 训练 SAR 成像一致。
    返回形状 (N,2) float64；失败时 None。
    """
    pose_fn = _import_compute_sar_camera_pose()
    if pose_fn is None:
        return None
    try:
        R_w2r, t, _K = pose_fn(float(depression_deg), float(azimuth_deg), sar_params)
    except Exception:
        return None
    R_w2r = np.asarray(R_w2r, dtype=np.float64).reshape(3, 3)
    tvec = np.asarray(t, dtype=np.float64).reshape(3)

    xyz = np.asarray(xyz_w, dtype=np.float64).reshape(-1, 3)
    if xyz.shape[0] == 0:
        return np.zeros((0, 2), dtype=np.float64)

    means3d_radar = (xyz @ R_w2r.T).astype(np.float64)
    x_az = means3d_radar[:, 0]
    y_rng = means3d_radar[:, 1]
    z_height = means3d_radar[:, 2]

    cam_center_world = -(R_w2r.T @ tvec.reshape(3, 1)).ravel()
    plat = (R_w2r @ cam_center_world.reshape(3, 1)).ravel()

    pt = np.stack([x_az, y_rng, z_height], axis=1).astype(np.float64)
    slant = np.linalg.norm(pt - plat.reshape(1, 3), axis=1)
    platform_z = float(plat[2])
    height_diff = platform_z - z_height
    ground_range = np.sqrt(np.maximum(slant ** 2 - height_diff ** 2, 0.0))

    ref_gr = float(np.median(ground_range))
    delta_rng, delta_az = _sar_pixel_spacing_from_params(sar_params)
    Na = int(sar_params.get("Na", 128))
    Nr = int(sar_params.get("Nr", 128))
    rng_pixel = (ground_range - ref_gr) / max(delta_rng, 1e-18)
    az_pixel = x_az / max(delta_az, 1e-18)
    x_image = az_pixel + float(Na) / 2.0
    y_image = rng_pixel + float(Nr) / 2.0
    return np.stack([x_image, y_image], axis=1)


def _robust_xy_span_px(uv: np.ndarray, *, lo_pct: float = 5.0, hi_pct: float = 95.0) -> Tuple[float, float]:
    if uv is None or uv.size == 0:
        return 0.0, 0.0
    xy = np.asarray(uv, dtype=np.float64).reshape(-1, 2)
    n = xy.shape[0]
    if n < 8:
        u = xy[:, 0]
        v = xy[:, 1]
        return float(np.max(u) - np.min(u)), float(np.max(v) - np.min(v))
    u_span = float(np.percentile(xy[:, 0], hi_pct) - np.percentile(xy[:, 0], lo_pct))
    v_span = float(np.percentile(xy[:, 1], hi_pct) - np.percentile(xy[:, 1], lo_pct))
    return max(abs(u_span), 1e-18), max(abs(v_span), 1e-18)


def _mesh_vertices_local_maybe_subsample(mesh: Any, cap: int, seed: int) -> np.ndarray:
    _require_open3d()
    v = np.asarray(mesh.vertices, dtype=np.float64)
    if cap <= 0 or v.shape[0] <= cap:
        return v.copy()
    rng = np.random.default_rng(int(seed))
    idx = rng.choice(v.shape[0], size=int(cap), replace=False)
    return np.asarray(v[idx], dtype=np.float64)


def _estimate_sar_imaging_uniform_scale(
    *,
    sparse_world: np.ndarray,
    mesh_local_vertices: np.ndarray,
    T_final: np.ndarray,
    coarse_centroid_for_scale: np.ndarray,
    sar_params: dict,
    depression_deg: float,
    azimuth_deg: float,
    seed: int,
    sparse_cap: int = 15_000,
    mesh_vertex_cap: int = 65_536,
    min_mesh_px_span: float = 0.25,
    min_sparse_px_span: float = 0.15,
    gamma_min: float = 0.12,
    gamma_max: float = 8.0,
) -> Tuple[float, Dict[str, Any]]:
    """
    在参考俯角/方位下将稀疏点与变换后模型顶点投影到 SAR 像素域，用包络比估计各向均匀缩放因子。
    返回 (gamma, diagnostics)；失败时 gamma=1.0。
    """
    diag: Dict[str, Any] = {"enabled": True}
    rng = np.random.default_rng(int(seed) + 901)
    sp = np.asarray(sparse_world, dtype=np.float64).reshape(-1, 3)
    if sp.shape[0] < 5:
        diag["skipped"] = True
        diag["reason"] = "too_few_sparse"
        return 1.0, diag
    if sp.shape[0] > sparse_cap:
        idx = rng.choice(sp.shape[0], size=int(sparse_cap), replace=False)
        sp = sp[idx]

    V = np.asarray(mesh_local_vertices, dtype=np.float64).reshape(-1, 3)
    if V.shape[0] < 4:
        diag["skipped"] = True
        diag["reason"] = "too_few_mesh_vertices"
        return 1.0, diag
    if mesh_vertex_cap > 0 and V.shape[0] > mesh_vertex_cap:
        idxv = rng.choice(V.shape[0], size=int(mesh_vertex_cap), replace=False)
        V = V[idxv]

    mesh_world = transform_points(np.asarray(T_final, dtype=np.float64), V)
    pix_s = _sar_project_world_to_pixels_xy(
        sp,
        sar_params=sar_params,
        depression_deg=depression_deg,
        azimuth_deg=azimuth_deg,
    )
    pix_m = _sar_project_world_to_pixels_xy(
        mesh_world,
        sar_params=sar_params,
        depression_deg=depression_deg,
        azimuth_deg=azimuth_deg,
    )
    if pix_s is None or pix_m is None:
        diag["skipped"] = True
        diag["reason"] = "project_sar_unavailable_or_failed"
        return 1.0, diag

    wsu, wsv = _robust_xy_span_px(pix_s)
    emu, emv = _robust_xy_span_px(pix_m)
    diag["sparse_pixel_span_xy"] = [float(wsu), float(wsv)]
    diag["mesh_pixel_span_xy"] = [float(emu), float(emv)]
    diag["reference_depression_deg"] = float(depression_deg)
    diag["reference_azimuth_deg"] = float(azimuth_deg)

    if wsu < min_sparse_px_span or wsv < min_sparse_px_span:
        diag["skipped"] = True
        diag["reason"] = "sparse_pixel_span_too_small"
        return 1.0, diag
    if emu < min_mesh_px_span or emv < min_mesh_px_span:
        diag["skipped"] = True
        diag["reason"] = "mesh_pixel_span_too_small"
        return 1.0, diag

    gamma_u = wsu / emu
    gamma_v = wsv / emv
    gamma_geom = math.sqrt(max(gamma_u * gamma_v, 1e-30))
    gamma_geom = float(np.clip(gamma_geom, gamma_min, gamma_max))
    diag["gamma_u"] = float(gamma_u)
    diag["gamma_v"] = float(gamma_v)
    diag["gamma_uniform"] = float(gamma_geom)

    c = np.asarray(coarse_centroid_for_scale, dtype=np.float64).reshape(3)
    T_test = _similarity_uniform_scale_about_centroid(np.asarray(T_final, dtype=np.float64), gamma_geom, c)
    mesh_world2 = transform_points(T_test, V)
    pix_m2 = _sar_project_world_to_pixels_xy(
        mesh_world2,
        sar_params=sar_params,
        depression_deg=depression_deg,
        azimuth_deg=azimuth_deg,
    )
    if pix_m2 is not None:
        e2u, e2v = _robust_xy_span_px(pix_m2)
        diag["mesh_pixel_span_xy_after_gamma"] = [float(e2u), float(e2v)]
    return gamma_geom, diag


def normals_to_rgb(normals: np.ndarray) -> np.ndarray:
    """[-1,1] 法向 → 可视化 RGB uint8。"""
    n = np.asarray(normals, dtype=np.float64)
    ln = np.linalg.norm(n, axis=1, keepdims=True)
    ln = np.maximum(ln, 1e-9)
    n = n / ln
    rgb = ((n + 1.0) * 0.5 * 255.0).clip(0, 255).astype(np.uint8)
    return rgb


def sample_mesh_surface_uniform(mesh, n_target: int, seed: int = 0) -> Tuple[np.ndarray, np.ndarray]:
    """返回模型坐标系 xyz (N,3) 与顶点法向插值或 Open3D 估计法向。"""
    _require_open3d()
    import open3d as o3d

    if n_target <= 0:
        return np.zeros((0, 3), dtype=np.float64), np.zeros((0, 3), dtype=np.float64)
    n = int(max(100, n_target))
    rng = np.random.default_rng(seed)
    pcd = mesh.sample_points_uniformly(number_of_points=n, use_triangle_normal=True)
    xyz = np.asarray(pcd.points, dtype=np.float64)
    if not pcd.has_normals():
        pcd.estimate_normals()
    nrm = np.asarray(pcd.normals, dtype=np.float64)
    if xyz.shape[0] > n_target:
        idx = rng.choice(xyz.shape[0], size=n_target, replace=False)
        xyz = xyz[idx]
        nrm = nrm[idx]
    return xyz, nrm


def sample_mesh_surface_poisson(mesh, n_target: int, init_factor: float = 5.0, seed: int = 0) -> Tuple[np.ndarray, np.ndarray]:
    """三角网格表面泊松盘采样（点距更均匀）。依赖 Open3D TriangleMesh.sample_points_poisson_disk。"""
    _require_open3d()
    import open3d as o3d

    if n_target <= 0:
        return np.zeros((0, 3), dtype=np.float64), np.zeros((0, 3), dtype=np.float64)
    rng = np.random.default_rng(seed)
    init_f = float(max(1.5, min(50.0, init_factor)))
    pcd = mesh.sample_points_poisson_disk(number_of_points=int(n_target), init_factor=init_f)
    if len(pcd.points) == 0:
        return sample_mesh_surface_uniform(mesh, n_target, seed=seed)
    if not pcd.has_normals():
        pcd.estimate_normals()
    xyz = np.asarray(pcd.points, dtype=np.float64)
    nrm = np.asarray(pcd.normals, dtype=np.float64)
    if xyz.shape[0] > n_target:
        idx = rng.choice(xyz.shape[0], size=n_target, replace=False)
        xyz = xyz[idx]
        nrm = nrm[idx]
    elif xyz.shape[0] < max(50, n_target // 2):
        need = int(n_target) - int(xyz.shape[0])
        u_xyz, u_nrm = sample_mesh_surface_uniform(mesh, need, seed=seed + 11)
        if u_xyz.shape[0] > 0:
            xyz = np.vstack([xyz, u_xyz])
            nrm = np.vstack([nrm, u_nrm])
        if xyz.shape[0] > n_target:
            xyz = np.vstack([xyz, u_xyz])
            nrm = np.vstack([nrm, u_nrm])
        if xyz.shape[0] > n_target:
            idx = rng.choice(xyz.shape[0], size=n_target, replace=False)
            xyz = xyz[idx]
            nrm = nrm[idx]
    return xyz, nrm


def icp_multiscale_refinement(
    src_xyz: np.ndarray,
    tgt_xyz: np.ndarray,
    T_init: np.ndarray,
    voxel_sizes: Tuple[float, ...],
    max_iters: int = 40,
    relative_fitness: float = 1.0e-6,
    relative_rmse: float = 1.0e-6,
) -> Tuple[np.ndarray, Any]:
    """在刚体假设下叠乘 ICP 增量：T_refined = T_icp * T_init。输入已为同尺度粗对齐后的点。"""
    _require_open3d()
    import open3d as o3d

    if src_xyz.shape[0] < 10 or tgt_xyz.shape[0] < 10:
        return T_init.copy(), None

    cur = T_init.copy()
    last_reg = None
    for vox in voxel_sizes:
        s = o3d.geometry.PointCloud()
        s.points = o3d.utility.Vector3dVector(src_xyz)
        t = o3d.geometry.PointCloud()
        t.points = o3d.utility.Vector3dVector(tgt_xyz)
        if vox > 1e-9:
            s_ds = s.voxel_down_sample(vox)
            t_ds = t.voxel_down_sample(vox)
            if len(s_ds.points) < 20 or len(t_ds.points) < 20:
                s_ds, t_ds = s, t
            s, t = s_ds, t_ds
        s.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=vox * 3, max_nn=30))
        t.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=vox * 3, max_nn=30))
        dist = float(np.linalg.norm(np.asarray(t.get_max_bound()) - np.asarray(t.get_min_bound())))
        thr = max(vox * 2.5, dist * 0.03)
        reg = o3d.pipelines.registration.registration_icp(
            s,
            t,
            thr,
            cur,
            o3d.pipelines.registration.TransformationEstimationPointToPlane(),
            o3d.pipelines.registration.ICPConvergenceCriteria(
                relative_fitness=relative_fitness, relative_rmse=relative_rmse, max_iteration=max_iters
            ),
        )
        cur = reg.transformation @ cur
        last_reg = reg
    return cur, last_reg


def filter_points_in_sparse_aabb(
    xyz: np.ndarray, sparse_tgt: np.ndarray, margin_factor: float
) -> np.ndarray:
    """margin_factor>1 时在 sparse AABB 各轴半长上乘以 margin。"""
    if xyz.shape[0] == 0 or sparse_tgt.shape[0] == 0 or margin_factor <= 0:
        return np.ones(xyz.shape[0], dtype=bool)
    lo = sparse_tgt.min(axis=0)
    hi = sparse_tgt.max(axis=0)
    c = 0.5 * (lo + hi)
    half = 0.5 * (hi - lo) * float(margin_factor)
    half = np.maximum(half, 1e-6)
    inside = np.all((xyz >= c - half) & (xyz <= c + half), axis=1)
    return inside


def _sparse_expanded_bounds(sparse_tgt: np.ndarray, margin_factor: float) -> Tuple[np.ndarray, np.ndarray]:
    lo = sparse_tgt.min(axis=0)
    hi = sparse_tgt.max(axis=0)
    c = 0.5 * (lo + hi)
    half = 0.5 * (hi - lo) * float(margin_factor)
    half = np.maximum(half, 1e-6)
    return c - half, c + half


def filter_points_in_sparse_aabb_union_nominal_box(
    xyz: np.ndarray,
    sparse_tgt: np.ndarray,
    margin_factor: float,
    T_final: np.ndarray,
    nominal_semi_axes: Tuple[float, float, float],
) -> np.ndarray:
    """
    阴影比例盒等「名义半轴」路径：稀疏在 Y（高度）上常比盒体薄，仅用 sparse 扩张 AABB 裁剪会切掉
    ±Y 两个顶面采样。本函数取 **sparse 扩张盒** 与 **T_final 下局部 ±(rx,ry,rz) 角点世界 AABB** 的并集
    再判内点，从而保留六个面的表面点（ICP 含旋转时角点仍包容真实壳）。
    """
    if xyz.shape[0] == 0 or sparse_tgt.shape[0] == 0 or margin_factor <= 0:
        return np.ones(xyz.shape[0], dtype=bool)
    lo_s, hi_s = _sparse_expanded_bounds(sparse_tgt, margin_factor)
    rx, ry, rz = (float(nominal_semi_axes[0]), float(nominal_semi_axes[1]), float(nominal_semi_axes[2]))
    corners = np.array(list(itertools.product([-rx, rx], [-ry, ry], [-rz, rz])), dtype=np.float64)
    cw = transform_points(np.asarray(T_final, dtype=np.float64), corners)
    lo_n = cw.min(axis=0)
    hi_n = cw.max(axis=0)
    ext_n = hi_n - lo_n
    pad = np.maximum(ext_n * 1e-4, 1e-9)
    lo_n = lo_n - pad
    hi_n = hi_n + pad
    lo_c = np.minimum(lo_s, lo_n)
    hi_c = np.maximum(hi_s, hi_n)
    return np.all((xyz >= lo_c) & (xyz <= hi_c), axis=1)


@dataclass
class MeshPriorResult:
    transform_4x4: np.ndarray  # mesh(local) -> colmap world（x_cam = R @ x_world + t）
    xyz_world: np.ndarray  # COLMAP world，可直接写入 sparse 或与 readColmapSceneInfo 一致地训练
    rgb: np.ndarray
    fitness_rmse: Optional[Tuple[float, float]]
    diagnostics: Dict[str, Any]


def build_mesh_prior_pointcloud(
    mesh_path: str,
    sparse_dir: str,
    *,
    sparse_xyz: Optional[np.ndarray] = None,
    sample_count: int = 200_000,
    icp_source_samples: int = 80_000,
    use_poisson_disk: bool = False,
    skip_icp: bool = False,
    icp_voxel_chain: Optional[Tuple[float, ...]] = None,
    icp_max_iters: int = 40,
    scale_override: float = 0.0,
    crop_margin_factor: float = 1.45,
    seed: int = 0,
    save_transform_json: Optional[str] = None,
    max_sparse_points: int = 500_000,
    use_normal_rgb: bool = False,
    uniform_rgb: Tuple[int, int, int] = (128, 128, 128),
    triangle_mesh: Optional[Any] = None,
    alignment_extra_xyz: Optional[np.ndarray] = None,
    coarse_nominal_semi_axes: Optional[Tuple[float, float, float]] = None,
    nominal_coarse_mode: str = "ground_contact",
    mesh_vertex_axis_sign: Sequence[float] = (1.0, -1.0, 1.0),
    extra_world_yaw_deg: float = 0.0,
    final_uniform_scale: float = 1.0,
    sar_imaging_scale_match: bool = False,
    sar_params_for_scale: Optional[Dict[str, Any]] = None,
    sar_scale_ref_azimuth_deg: float = 90.0,
    sar_scale_ref_depression_deg: Optional[float] = None,
    sar_scale_ref_azimuths: Optional[Sequence[float]] = None,
) -> MeshPriorResult:
    """
    主入口：网格路径 + sparse 目录（或内存中的 sparse_xyz）→ 世界系点云 + 4x4 变换。

    sparse_xyz 为 (N,3) 时优先使用，供 SfM 内在不写盘的情况下对齐。
    scale_override>0 时覆盖粗对齐尺度（仍用中心对齐），用于已知 CAD 米制与场景比。
    triangle_mesh 若提供则忽略 mesh_path 读盘（mesh_path 仍可用于诊断 JSON 路径展示）。
    alignment_extra_xyz：与本 mesh 对齐时额外参与包围盒/ICP 的点（如相机光心），与 sparse 垂直拼接。
    coarse_nominal_semi_axes：若给定 (rx,ry,rz)，阴影比例盒路径有两种粗放置方式（见 nominal_coarse_mode）。
    nominal_coarse_mode：与 coarse_nominal_semi_axes 同时生效。`translate_centroid`（默认）不缩放网格，仅用汇总名义尺寸，
        盒心平移到 sparse（及 alignment_extra）AABB 中心后采样；`sparse_diagonal` 按稀疏包络对角线对盒做各向同性缩放（旧行为）。
    mesh_vertex_axis_sign：对齐采样前对每个顶点乘以 (sx,sy,sz)，默认 (1,-1,1)，用于 OBJ/CAD Y 轴与 SAR/COLMAP
    「Y≈竖直」相反时校正上下颠倒。
    extra_world_yaw_deg：粗对齐+ICP 完成后、最终表面采样写入世界坐标前，对变换左乘绕 **世界 +Y** 的旋转（度，右手法则，
    与 ``rotation_world_y`` 一致）。用于 CAD 车头/侧向与 SAR 方位 0° 约定相差固定偏航角（常见 ±90°）或「由 -Y 俯视」语义下整目标绕竖直轴纠偏。
    final_uniform_scale：在上述步骤之后（最终稠密采样前）对整条 mesh→world **相似缩放**：以 coarse 对齐所用点（稀疏±辅助）的 **质心**
    为中心做各向 s 倍缩放（s≠1）。用于粗对齐后因 CAD 偏大/偏小再在场景里整体缩小一半等，而不覆盖 ``scale_override`` 的语义（后者在粗对齐阶段生效）。
    sar_imaging_scale_match：在 ``final_uniform_scale`` 之后再做一步可选对齐——用与 sar/rasterizer 一致的 SAR 斜距近似投影，
    在参考俯仰/方位下比较 **SfM 稀疏点**与 **变换后网格顶点包络** 在图像平面上的延展，按比例在 **同一 coarse 质心** 上做各向均匀缩放
    （**相似变换**，不截断网格三角面）。
    使 CAD/盒模型在 SAR 视图中的成像尺寸更接近稀疏重构（默认关闭；常与参考方位 ~90° 联用以统一「侧视」标尺）。
    需传入 ``sar_params_for_scale``（含 Na/Nr、camera_height 及可选 sar_scale_params 合并字段）；俯角可由 ``sar_scale_ref_depression_deg`` 给定，
    留空则由调用方传入中位数或由本函数兜底常数俯角并在 diagnostics 标明。

    默认 **use_normal_rgb=False**：所有输出点为 **uniform_rgb**（默认中性灰），与 SAR 散射强度无关，
    也与「用多视图像给 COLMAP 点上色」不同；3DGS 训练时由球谐从图像学习辐射。
    use_normal_rgb=True 时用法向伪彩（仅供可视化/调试）。
    """
    mp = (mesh_path or "").strip()
    if triangle_mesh is not None:
        mesh = triangle_mesh
        if not mp:
            mp = "<triangle_mesh_in_memory>"
    else:
        if not mp:
            raise ValueError("build_mesh_prior_pointcloud: 需要 mesh_path 或 triangle_mesh")
        mesh = load_triangle_mesh(mesh_path)

    apply_vertex_axis_sign_to_triangle_mesh(mesh, np.asarray(mesh_vertex_axis_sign, dtype=np.float64))

    ncm_raw = (nominal_coarse_mode or "ground_contact").strip().lower()
    use_sar_ground = ncm_raw in (
        "ground_contact",
        "sparse_diagonal",
        "ground",
        "origin_ground_contact",
    )
    if coarse_nominal_semi_axes is not None and use_sar_ground:
        reanchor_triangle_mesh_bottom_center_to_local_origin(mesh)

    if sparse_xyz is not None:
        sparse = np.asarray(sparse_xyz, dtype=np.float64)
        if sparse.ndim != 2 or sparse.shape[1] != 3:
            raise ValueError("sparse_xyz 必须为形状 (N, 3) 的数组")
        if sparse.shape[0] > max_sparse_points:
            rng = np.random.default_rng(int(seed))
            idx = rng.choice(sparse.shape[0], size=max_sparse_points, replace=False)
            sparse = sparse[idx]
    else:
        sparse = load_sparse_xyz_from_colmap_sparse_dir(sparse_dir, max_points=max_sparse_points)

    # 模型坐标采样（用于 ICP 子集 + 最终可分开采样）
    n_icp = min(icp_source_samples, max(5000, sample_count))
    if use_poisson_disk:
        samp_local, nrm_local = sample_mesh_surface_poisson(mesh, n_icp, seed=seed)
    else:
        samp_local, nrm_local = sample_mesh_surface_uniform(mesh, n_icp, seed=seed)

    if sparse.shape[0] == 0:
        raise RuntimeError(
            "sparse/0 无点云；无法与 OBJ 对齐。请先完成 SfM，或提供已有点云的 COLMAP 目录。"
        )

    extra = None
    if alignment_extra_xyz is not None:
        ex = np.asarray(alignment_extra_xyz, dtype=np.float64).reshape(-1, 3)
        if ex.shape[0] > 0:
            if ex.shape[0] > 4000:
                rng = np.random.default_rng(int(seed) + 31)
                ex = ex[rng.choice(ex.shape[0], size=4000, replace=False)]
            extra = ex
    coarse_tgt = np.vstack([sparse, extra]) if extra is not None else sparse

    ncm_eff = ""
    scale_pivot = np.zeros(3, dtype=np.float64)
    verts_local = np.asarray(mesh.vertices, dtype=np.float64)
    if scale_override and scale_override > 0:
        c_s, _ = _bbox_axes_diag(verts_local)
        c_t, _ = _bbox_axes_diag(coarse_tgt)
        s = float(scale_override)
        t = c_t - s * c_s
        T_coarse = np.eye(4, dtype=np.float64)
        T_coarse[0, 0] = T_coarse[1, 1] = T_coarse[2, 2] = s
        T_coarse[:3, 3] = t
        scale_pivot = c_t
    elif coarse_nominal_semi_axes is not None:
        nrx, nry, nrz = coarse_nominal_semi_axes
        if ncm_raw == "sparse_diagonal":
            T_coarse, scale_pivot = coarse_similarity_nominal_box_ground_contact(
                nrx, nry, nrz, sparse
            )
            ncm_eff = "sparse_diagonal_ground"
        elif ncm_raw == "translate_centroid":
            T_coarse = coarse_translate_centroid_identity_scale(coarse_tgt)
            scale_pivot = np.mean(coarse_tgt, axis=0, dtype=np.float64)
            ncm_eff = "translate_centroid"
        elif ncm_raw == "origin_ground_contact":
            T_coarse = np.eye(4, dtype=np.float64)
            scale_pivot = np.zeros(3, dtype=np.float64)
            ncm_eff = "origin_ground_contact"
        else:
            T_coarse, scale_pivot = coarse_translate_ground_contact_to_anchor(sparse)
            ncm_eff = "ground_contact"
    else:
        # 用网格**全部顶点**与稀疏对角线对齐；表面随机子集 AABB 常明显小于 CAD 真实外包络，
        # 分母 d_s 偏小 → s=d_t/d_s 偏大 → 整模在世上显得过大；以前靠 crop 裁掉外伸部分才显得「尺寸对」。
        _, d_sparse_diag = _bbox_axes_diag(coarse_tgt)
        T_coarse = coarse_similarity_translation_scale(verts_local, coarse_tgt)
        _, d_v = _bbox_axes_diag(verts_local)
        _, d_sub = _bbox_axes_diag(samp_local)
        print(
            f"   mesh_prior: 粗对齐尺度 = 稀疏对角线 / 网格顶点包络对角线 "
            f"(d_sparse≈{d_sparse_diag:.4g} m, d_mesh_verts={d_v:.4g}, d_surf_sample={d_sub:.4g})"
        )

    if ncm_eff == "ground_contact":
        print(
            "   mesh_prior: SAR 接地点 — 名义盒底面中心对齐 sparse footprint 底面"
            f" ({scale_pivot[0]:.4g},{scale_pivot[1]:.4g},{scale_pivot[2]:.4g})，尺寸保持汇总 2rx×2ry×2rz。"
        )
    elif ncm_eff == "origin_ground_contact":
        print(
            "   mesh_prior: SAR 接地点 — 名义盒底面中心固定世界原点 (0,0,0)，"
            "不跟随 sparse footprint 平移；尺寸保持汇总 2rx×2ry×2rz。"
        )
    elif ncm_eff == "sparse_diagonal_ground":
        print(
            "   mesh_prior: SAR 接地点 + 稀疏对角线缩放 — 底面中心对齐 footprint，"
            "各向同性缩放匹配稀疏包络。"
        )
    elif ncm_eff == "translate_centroid":
        print(
            "   mesh_prior: 名义盒 — 尺寸保持汇总名义 2rx×2ry×2rz，仅平移至稀疏(+辅助点)几何中心后再采样（无对角缩放）。"
        )
    elif ncm_eff == "sparse_diagonal":
        print("   mesh_prior: 名义盒 — 按稀疏包络对角线做各向同性缩放对齐（旧行为）。")

    samp_coarse = transform_points(T_coarse, samp_local)
    fitness_rmse = None
    T_final = T_coarse.copy()

    # ICP 目标：ground_contact 模式下仅用 sparse，不用相机光心（避免把接地点拉偏）
    icp_tgt = sparse if ncm_eff in (
        "ground_contact",
        "sparse_diagonal_ground",
        "origin_ground_contact",
    ) else coarse_tgt

    if not skip_icp:
        _, d_t = _bbox_axes_diag(icp_tgt)
        if icp_voxel_chain is None:
            icp_voxel_chain = (
                max(d_t * 0.06, 1e-4),
                max(d_t * 0.02, 1e-4),
                max(d_t * 0.008, 1e-5),
            )
        # ICP：刚体修正。在 coarse 已相似变换后的源点上，相对目标点云求刚体增量。
        T_icp, reg = icp_multiscale_refinement(
            samp_coarse,
            icp_tgt,
            np.eye(4, dtype=np.float64),
            icp_voxel_chain,
            max_iters=icp_max_iters,
        )
        # 完整变换：先 coarse 再 icp
        T_final = T_icp @ T_coarse
        if reg is not None:
            fitness_rmse = (float(reg.fitness), float(reg.inlier_rmse))

    yaw_extra = float(extra_world_yaw_deg or 0.0)
    if abs(yaw_extra) > 1e-12:
        Ry = rotation_world_y(np.deg2rad(yaw_extra))
        T_yaw = np.eye(4, dtype=np.float64)
        T_yaw[:3, :3] = Ry
        if use_sar_ground and ncm_eff in (
            "ground_contact",
            "sparse_diagonal_ground",
            "origin_ground_contact",
        ):
            p = scale_pivot.reshape(3)
            T_yaw[:3, 3] = p - Ry @ p
        T_final = T_yaw @ T_final

    _fs_in = float(final_uniform_scale)
    if (not np.isfinite(_fs_in)) or _fs_in <= 0:
        fs = 1.0
    else:
        fs = _fs_in
    if abs(fs - 1.0) > 1e-12:
        T_final = _similarity_uniform_scale_about_point(T_final, fs, scale_pivot)

    sar_px_gamma = 1.0
    sar_im_extra: Dict[str, Any] = {"requested": bool(sar_imaging_scale_match)}
    if sar_imaging_scale_match:
        if sar_params_for_scale is None or not isinstance(sar_params_for_scale, dict):
            sar_im_extra["skipped"] = True
            sar_im_extra["reason"] = "no_sar_params_for_scale"
            print("   ⚠️ mesh_prior SAR成像尺度对齐: 跳过（未提供 sar_params_for_scale）")
        else:
            d_in = sar_scale_ref_depression_deg
            if d_in is None or (not np.isfinite(float(d_in))):
                dref = float(30.0)
                sar_im_extra["depression_fallback_constant_deg"] = dref
            else:
                dref = float(d_in)
            if sar_scale_ref_azimuths:
                az_list = [float(a) for a in sar_scale_ref_azimuths]
            else:
                az_list = [float(sar_scale_ref_azimuth_deg), 270.0]
                az_list = list(dict.fromkeys(round(a % 360.0, 6) for a in az_list))
            c_cent = np.asarray(scale_pivot, dtype=np.float64).reshape(3)
            verts_local = _mesh_vertices_local_maybe_subsample(mesh, 65_536, seed + 3)
            gammas: list = []
            per_az: list = []
            for az_i in az_list:
                g_i, det_i = _estimate_sar_imaging_uniform_scale(
                    sparse_world=np.asarray(sparse, dtype=np.float64),
                    mesh_local_vertices=verts_local,
                    T_final=T_final,
                    coarse_centroid_for_scale=c_cent,
                    sar_params=dict(sar_params_for_scale),
                    depression_deg=dref,
                    azimuth_deg=float(az_i),
                    seed=seed + int(round(float(az_i))) % 997,
                )
                per_az.append({"azimuth_deg": float(az_i), **det_i})
                if not det_i.get("skipped"):
                    gammas.append(float(g_i))
            sar_im_extra["per_azimuth"] = per_az
            if gammas:
                sar_px_gamma = float(np.exp(np.mean(np.log(np.clip(gammas, 1e-9, None)))))
            else:
                sar_px_gamma = 1.0
                sar_im_extra["skipped"] = True
                sar_im_extra["reason"] = "all_azimuths_skipped"
            sar_im_extra["gamma_uniform"] = float(sar_px_gamma)
            sar_im_extra["reference_depression_deg"] = float(dref)
            sar_im_extra["reference_azimuths_deg"] = [float(a) for a in az_list]
            if abs(float(sar_px_gamma) - 1.0) > 1e-9 and gammas:
                T_final = _similarity_uniform_scale_about_centroid(
                    np.asarray(T_final, dtype=np.float64), float(sar_px_gamma), c_cent
                )
                print(
                    f"   mesh_prior SAR成像尺度对齐: 参考俯角={dref:.4g}°, "
                    f"方位={', '.join(f'{a:.0g}°' for a in az_list)}, "
                    f"均匀比例 γ={float(sar_px_gamma):.6f}"
                )
            elif not gammas:
                print(
                    f"   ℹ️  mesh_prior SAR成像尺度对齐: 未缩放（原因: {sar_im_extra.get('reason', 'unknown')}）"
                )

    # 最终稠密采样（可多于 ICP 子集）
    n_final = int(max(1, sample_count))
    if use_poisson_disk:
        final_local, final_nrm = sample_mesh_surface_poisson(mesh, n_final, seed=seed + 7)
    else:
        final_local, final_nrm = sample_mesh_surface_uniform(mesh, n_final, seed=seed + 7)
    xyz_w = transform_points(T_final, final_local)
    n_out = int(xyz_w.shape[0])
    if use_normal_rgb:
        Rlin = T_final[:3, :3].astype(np.float64)
        n_world = final_nrm.astype(np.float64) @ Rlin.T
        rgb = normals_to_rgb(n_world)
    else:
        r = int(np.clip(uniform_rgb[0], 0, 255))
        g = int(np.clip(uniform_rgb[1], 0, 255))
        b = int(np.clip(uniform_rgb[2], 0, 255))
        rgb = np.full((n_out, 3), (r, g, b), dtype=np.uint8)

    # 注意：以下 AABB 过滤只删除「落在框外」的表面采样点，不是修改三角网格的几何等比尺度；
    # 等比缩小整模请用 scale_override / final_uniform_scale / sar_imaging_scale_match。
    crop_mode = "off"
    if crop_margin_factor and crop_margin_factor > 0:
        if coarse_nominal_semi_axes is not None:
            mask = filter_points_in_sparse_aabb_union_nominal_box(
                xyz_w, sparse, crop_margin_factor, T_final, coarse_nominal_semi_axes
            )
            crop_mode = "sparse_union_nominal_box"
        else:
            mask = filter_points_in_sparse_aabb(xyz_w, sparse, crop_margin_factor)
            crop_mode = "sparse_only"
        if mask.sum() < max(50, 0.001 * n_final):
            print(
                f"   ⚠️ AABB 裁剪后点过少 ({int(mask.sum())}/{n_final})，保留全部采样点（可检查 margin / 对齐）"
            )
        else:
            xyz_w = xyz_w[mask]
            rgb = rgb[mask]

    diag: Dict[str, Any] = {
        "mesh_path": os.path.abspath(mp) if not mp.startswith("<") else mp,
        "sparse_count": int(sparse.shape[0]),
        "alignment_extra_count": int(extra.shape[0]) if extra is not None else 0,
        "coarse_target_count": int(coarse_tgt.shape[0]),
        "coarse_mode": (
            "nominal_semi_axes" if (coarse_nominal_semi_axes is not None and not (scale_override and scale_override > 0)) else (
                "scale_override" if (scale_override and scale_override > 0) else "sample_bbox"
            )
        ),
        "sample_count_requested": n_final,
        "sample_count_output": int(xyz_w.shape[0]),
        "skip_icp": skip_icp,
        "use_poisson_disk": use_poisson_disk,
        "point_rgb_mode": "normal_pseudocolor" if use_normal_rgb else "uniform_neutral",
        "mesh_vertex_axis_sign": np.asarray(mesh_vertex_axis_sign, dtype=np.float64).tolist(),
        "extra_world_yaw_deg": float(yaw_extra),
        "final_uniform_scale": float(fs),
        "sar_imaging_scale_match": sar_im_extra,
        "sar_imaging_scale_gamma": float(sar_px_gamma),
        "composed_uniform_scale_after_sar_px": float(fs * sar_px_gamma),
        "crop_mode": crop_mode,
        "nominal_coarse_mode": ncm_eff,
    }
    if fitness_rmse is not None:
        diag["icp_fitness"] = fitness_rmse[0]
        diag["icp_inlier_rmse"] = fitness_rmse[1]
    if save_transform_json:
        out_json = os.path.abspath(save_transform_json)
        parent = os.path.dirname(out_json)
        if parent:
            os.makedirs(parent, exist_ok=True)
        payload = {
            "transform_4x4_row_major": T_final.tolist(),
            "mesh_path": os.path.abspath(mp) if mp and not mp.startswith("<") else mp,
            "sparse_dir": os.path.abspath(sparse_dir),
            "diagnostics": diag,
        }
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)

    return MeshPriorResult(
        transform_4x4=T_final,
        xyz_world=xyz_w,
        rgb=rgb,
        fitness_rmse=fitness_rmse,
        diagnostics=diag,
    )


def append_prior_xyz_to_records(
    records: list,
    xyz: np.ndarray,
    rgb: np.ndarray,
    merge_min_dist: float,
) -> Tuple[list, int]:
    """在已有 Point3DRecord 列表上追加点（新 ID），可选与现有点 min-dist 过滤。"""
    from post_sfm.colmap_points import Point3DRecord

    max_id = max((p.point_id for p in records), default=0)
    next_id = max_id + 1
    ref = np.stack([p.xyz for p in records], axis=0) if records else None

    added = 0
    if merge_min_dist > 0 and ref is not None and ref.shape[0] > 0:
        use_tree = True
        try:
            from scipy.spatial import cKDTree
        except ImportError:
            use_tree = False
        if use_tree:
            tree = cKDTree(ref.astype(np.float64, copy=False))
            pending: list[np.ndarray] = []
            rebuild_every = 256
            thr = float(merge_min_dist)
            for i in range(xyz.shape[0]):
                p = xyz[i].astype(np.float64)
                d, _ = tree.query(p, k=1, distance_upper_bound=thr)
                if np.isfinite(d) and float(d) < thr:
                    continue
                records.append(
                    Point3DRecord(
                        point_id=next_id,
                        xyz=p,
                        rgb=rgb[i].astype(np.uint8),
                        error=0.0,
                        track=[],
                    )
                )
                next_id += 1
                added += 1
                pending.append(p)
                if len(pending) >= rebuild_every:
                    ref = np.vstack([ref, np.stack(pending, axis=0)])
                    tree = cKDTree(ref.astype(np.float64, copy=False))
                    pending.clear()
            if pending:
                ref = np.vstack([ref, np.stack(pending, axis=0)])
        else:
            for i in range(xyz.shape[0]):
                p = xyz[i]
                if float(np.linalg.norm(ref - p, axis=1).min()) < merge_min_dist:
                    continue
                records.append(
                    Point3DRecord(
                        point_id=next_id,
                        xyz=p.astype(np.float64),
                        rgb=rgb[i].astype(np.uint8),
                        error=0.0,
                        track=[],
                    )
                )
                next_id += 1
                added += 1
                ref = np.vstack([ref, p.reshape(1, 3)])
    else:
        for i in range(xyz.shape[0]):
            records.append(
                Point3DRecord(
                    point_id=next_id,
                    xyz=xyz[i].astype(np.float64),
                    rgb=rgb[i].astype(np.uint8),
                    error=0.0,
                    track=[],
                )
            )
            next_id += 1
            added += 1
    return records, added
