from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class PostSfmContext:
    source_path: str
    sparse_dir: str
    args: Any
