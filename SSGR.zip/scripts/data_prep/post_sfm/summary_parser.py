"""解析 adaptive_threshold_visualization/target_dimension_constraints_summary.txt 中的统计量。"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import numpy as np


@dataclass
class ShadowSummaryStats:
    height_median_px: Optional[float]
    length_median_px: Optional[float]
    width_median_px: Optional[float]
    hl_ratio: Optional[float]
    hw_ratio: Optional[float]


@dataclass
class PerViewShadowTarget:
    """单张训练图 shadow_diagnostic 中的目标包络（图像 u/v 轴像素）。"""

    width_px: float
    height_px: float
    center_u: float
    center_v: float


_DIAG_CENTER_RE = re.compile(r"目标中心位置:\s*\(([\d.]+),\s*([\d.]+)\)")
_DIAG_BOUNDS_RE = re.compile(
    r"目标边界:\s*X=\[([\d.]+),\s*([\d.]+)\],\s*Y=\[([\d.]+),\s*([\d.]+)\]"
)
_DIAG_WIDTH_RE = re.compile(r"目标宽度:\s*([\d.]+)\s*像素")
_DIAG_HEIGHT_RE = re.compile(r"目标高度:\s*([\d.]+)\s*像素")


def parse_shadow_diagnostic_target(path: str) -> Optional[PerViewShadowTarget]:
    """解析 shadow_diagnostic_<stem>.txt 中的目标宽高与中心。"""
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
    except OSError:
        return None
    mw = _DIAG_WIDTH_RE.search(text)
    mh = _DIAG_HEIGHT_RE.search(text)
    if not mw or not mh:
        return None
    w_px = float(mw.group(1))
    h_px = float(mh.group(1))
    cx, cy = w_px / 2.0 + 64.0, h_px / 2.0 + 64.0
    u0, u1, v0, v1 = 0.0, w_px, 0.0, h_px
    mc = _DIAG_CENTER_RE.search(text)
    if mc:
        cx = float(mc.group(1))
        cy = float(mc.group(2))
    mb = _DIAG_BOUNDS_RE.search(text)
    if mb:
        u0, u1 = float(mb.group(1)), float(mb.group(2))
        v0, v1 = float(mb.group(3)), float(mb.group(4))
        w_px = max(u1 - u0, 1.0)
        h_px = max(v1 - v0, 1.0)
    return PerViewShadowTarget(
        width_px=w_px,
        height_px=h_px,
        center_u=cx,
        center_v=cy,
    )


def load_per_view_shadow_targets(source_path: str) -> Dict[str, PerViewShadowTarget]:
    """读取 adaptive_threshold_visualization/shadow_diagnostic_*.txt，键为图像 stem。"""
    viz = os.path.join(source_path, "adaptive_threshold_visualization")
    if not os.path.isdir(viz):
        return {}
    out: Dict[str, PerViewShadowTarget] = {}
    for fn in os.listdir(viz):
        if not fn.startswith("shadow_diagnostic_") or not fn.endswith(".txt"):
            continue
        stem = fn[len("shadow_diagnostic_") : -4]
        tgt = parse_shadow_diagnostic_target(os.path.join(viz, fn))
        if tgt is not None:
            out[stem] = tgt
    return out


def _line_median(pattern: str, text: str) -> Optional[float]:
    m = re.search(pattern, text)
    if not m:
        return None
    return float(m.group(1))


def _line_last_number_with_token(text: str, token: str, *, exclude: tuple[str, ...] = ()) -> Optional[float]:
    for line in text.splitlines():
        if token not in line:
            continue
        if any(x in line for x in exclude):
            continue
        if "中位" not in line and "涓" not in line:
            continue
        nums = re.findall(r"[-+]?\d+(?:\.\d+)?", line)
        if nums:
            return float(nums[-1])
    return None


_ORIENT_RE = re.compile(r"朝向角:\s*([\d.]+)\s*°")


def orientations_deg_from_summary_file(path: str) -> list[float]:
    """从 summary 每张有效图像旁的「朝向角」行读取列表（度）。"""
    if not os.path.isfile(path):
        return []
    vals: list[float] = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                m = _ORIENT_RE.search(line)
                if m:
                    vals.append(float(m.group(1)))
    except Exception:
        return []
    return vals


def median_orientation_deg_from_summary_file(path: str) -> Optional[float]:
    """从 target_dimension_constraints_summary.txt 每张有效图像旁的「朝向角」行取中位数（度）。"""
    vals = orientations_deg_from_summary_file(path)
    if len(vals) < 1:
        return None
    return float(np.median(np.asarray(vals, dtype=np.float64)))


def _snap_azimuth_to_side_view_deg(azimuth_deg: float) -> float:
    """将任意方位角吸附到 MSTAR 侧视轴 90° 或 270°。"""
    o = float(azimuth_deg) % 360.0
    d90 = min(abs(o - 90.0), abs(o - 450.0), abs(o + 270.0))
    d270 = min(abs(o - 270.0), abs(o - 630.0), abs(o + 90.0))
    return 90.0 if d90 <= d270 else 270.0


def resolve_mstar_side_view_azimuth_deg(summary_path: str, args: Any) -> float:
    """
    与 ``mstar_axis_split`` 汇总 L/W 口径一致的 SAR 成像参考方位。
    不得使用全圆环图像方位角中位数（≈180° 为端视，L 投影仅 ~19 px）。
    """
    explicit = getattr(args, "sfm_mstar_fill_ref_azimuth_deg", None)
    if explicit is not None:
        try:
            e = float(explicit)
            if np.isfinite(e):
                return float(e)
        except (TypeError, ValueError):
            pass

    orients = orientations_deg_from_summary_file(summary_path)
    if orients:
        snapped = [_snap_azimuth_to_side_view_deg(o) for o in orients]
        if any(abs(s - 90.0) < 1.0 for s in snapped):
            return 90.0
        if any(abs(s - 270.0) < 1.0 for s in snapped):
            return 270.0
        return float(snapped[0])

    mode = str(
        getattr(args, "target_dimension_summary_azimuth_mode", "") or ""
    ).strip().lower()
    if mode == "mstar_axis_split":
        return 90.0
    return 90.0


def mstar_side_view_pixel_targets(
    l_med_px: float,
    w_med_px: float,
    *,
    side_view: bool = True,
) -> Tuple[float, float]:
    """
    MSTAR ``mstar_axis_split`` 侧视：L=Tr（距离向/图像 v），W=Taz（方位向/图像 u）。
    返回 (target_u, target_v) 供 SAR 投影 ``x_image, y_image`` 对比。
    """
    if side_view:
        return float(w_med_px), float(l_med_px)
    return float(l_med_px), float(w_med_px)


def parse_target_dimension_summary(path: str) -> Optional[ShadowSummaryStats]:
    if not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()

    h_med = _line_median(r"高度 \(H\):[^\n]*中位数=([\d.]+)", text)
    l_med = _line_median(r"长度 \(L\):[^\n]*中位数=([\d.]+)", text)
    w_med = _line_median(r"宽度 \(W\):[^\n]*中位数=([\d.]+)", text)

    hl = _line_median(r"高度/长度比例 \(H/L\):[^\n]*中位数=([\d.]+)", text)
    hw = _line_median(r"高度/宽度比例 \(H/W\):[^\n]*中位数=([\d.]+)", text)

    h_med = h_med if h_med is not None else _line_last_number_with_token(text, "(H)", exclude=("(H/L)", "(H/W)"))
    l_med = l_med if l_med is not None else _line_last_number_with_token(text, "(L)", exclude=("(H/L)", "(L/W)"))
    w_med = w_med if w_med is not None else _line_last_number_with_token(text, "(W)", exclude=("(H/W)", "(L/W)"))
    hl = hl if hl is not None else _line_last_number_with_token(text, "(H/L)")
    hw = hw if hw is not None else _line_last_number_with_token(text, "(H/W)")

    if all(x is None for x in (h_med, l_med, w_med, hl, hw)):
        return None
    return ShadowSummaryStats(
        height_median_px=h_med,
        length_median_px=l_med,
        width_median_px=w_med,
        hl_ratio=hl,
        hw_ratio=hw,
    )


def shadow_summary_semiaxes_xyz(
    stats: ShadowSummaryStats,
    depth_scale: float,
    pf_scale: float,
    h_world: Optional[float],
    upper_h: float,
    lower_h: float,
) -> Optional[Tuple[float, float, float]]:
    """
    由阴影汇总 L/W（像素 × depth_scale × planform_scale）与 H_world 推导世界系半轴距 (rx, ry, rz)。
    X≈长度、Y≈竖直、Z≈宽度，与 COLMAP/scheme_a、「merge_summary_box_mesh_prior」长方体网格一致。

    竖直尺度优先使用汇总文件中的 **H/W、H/L 比例**（与 standalone / feature_extraction 打印的「推荐」一致），
    避免旧逻辑 ``max(L×0.28, W×0.28, …)`` 在长目标上过大致使盒高度失真。
    """
    if stats.length_median_px is None or stats.width_median_px is None:
        return None
    lx_full = float(stats.length_median_px) * depth_scale * pf_scale
    lz_full = float(stats.width_median_px) * depth_scale * pf_scale
    if lx_full <= 1e-9 or lz_full <= 1e-9:
        return None

    ly_full: Optional[float] = None

    try:
        if stats.hw_ratio is not None and float(stats.hw_ratio) > 1e-12:
            ly_full = lz_full * float(stats.hw_ratio)
    except (TypeError, ValueError):
        pass

    if ly_full is None or ly_full <= 1e-12:
        try:
            if stats.hl_ratio is not None and float(stats.hl_ratio) > 1e-12:
                ly_full = lx_full * float(stats.hl_ratio)
        except (TypeError, ValueError):
            pass

    # 比例行解析失败时，仍可用 H、W 像素中位数直接复原 H/W（与 standalone 写入段落一致）
    if ly_full is None or ly_full <= 1e-12:
        try:
            hp = stats.height_median_px
            wp = stats.width_median_px
            if hp is not None and wp is not None:
                _hp = float(hp)
                _wp = float(wp)
                if _wp > 1e-12 and _hp > 1e-12:
                    ly_full = lz_full * (_hp / _wp)
        except (TypeError, ValueError):
            pass

    if ly_full is None or ly_full <= 1e-12:
        if h_world is not None and float(h_world) > 1e-9:
            slab = max(float(upper_h) + float(lower_h), 0.55)
            ly_full = float(h_world) * slab
        else:
            ly_full = max(lx_full * 0.28, lz_full * 0.28)

    return (lx_full * 0.5, ly_full * 0.5, lz_full * 0.5)
