"""COLMAP sparse 与 SAR 近似针孔投影一致的工具（与训练读取约定对齐）。"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, List, Mapping, Optional, Sequence, Tuple

import importlib.util

import numpy as np

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))


def _load_colmap_loader():
    path = os.path.join(_REPO_ROOT, "scene", "colmap_loader.py")
    spec = importlib.util.spec_from_file_location("post_sfm_colmap_loader", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"无法加载 COLMAP 读取模块: {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


_cl = None


def _colmap():
    global _cl
    if _cl is None:
        _cl = _load_colmap_loader()
    return _cl


@dataclass
class ColmapCameraView:
    """单张已配准图像的外参 + 内参（OpenCV: X_cam = R @ X_world + t）。"""

    name: str
    R_w2c: np.ndarray  # (3,3)
    t_w2c: np.ndarray  # (3,)
    K: np.ndarray  # (3,3)
    width: int
    height: int


def _pinhole_K(cam) -> Tuple[np.ndarray, int, int]:
    w, h = int(cam.width), int(cam.height)
    if cam.model == "SIMPLE_PINHOLE":
        f, cx, cy = cam.params[0], cam.params[1], cam.params[2]
        K = np.array([[f, 0, cx], [0, f, cy], [0, 0, 1.0]], dtype=np.float64)
    elif cam.model == "PINHOLE":
        fx, fy, cx, cy = cam.params[0], cam.params[1], cam.params[2], cam.params[3]
        K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.0]], dtype=np.float64)
    else:
        raise ValueError(f"不支持的相机模型（仅 PINHOLE / SIMPLE_PINHOLE）: {cam.model}")
    return K, w, h


def sparse_colmap_views_exist(sparse_dir: str) -> bool:
    """sparse/0 是否已写出 COLMAP cameras + images（文本或二进制任一组合）。"""
    cam_bin = os.path.join(sparse_dir, "cameras.bin")
    img_bin = os.path.join(sparse_dir, "images.bin")
    cam_txt = os.path.join(sparse_dir, "cameras.txt")
    img_txt = os.path.join(sparse_dir, "images.txt")
    return bool(
        (os.path.isfile(cam_bin) and os.path.isfile(img_bin))
        or (os.path.isfile(cam_txt) and os.path.isfile(img_txt))
    )


def views_from_world_to_cam_bundle(
    image_data: Mapping[str, Any],
    image_K: Mapping[str, Any],
    image_sizes: Mapping[str, Tuple[int, int]],
    *,
    default_width_height: Tuple[int, int],
) -> List[ColmapCameraView]:
    """
    从 SfM pipeline 内存中的位姿构造 ``ColmapCameraView``（与 ``_SaveColmapFormat`` 写入 COLMAP 的约定一致：
    ``R_cam, t_cam`` 为世界系→相机系的旋转与平移）。
    用于 ``before_filter`` 比例盒/OBJ 路径在尚未写出 sparse cameras/images 时估计 depth_scale。
    """
    views: List[ColmapCameraView] = []
    dw, dh = int(default_width_height[0]), int(default_width_height[1])
    fallback_K = None
    if image_K:
        fallback_K = np.asarray(next(iter(image_K.values())), dtype=np.float64).reshape(3, 3)

    for img_name in sorted(image_data.keys()):
        bundle = image_data[img_name]
        if not isinstance(bundle, (list, tuple)) or len(bundle) < 2:
            continue
        R_cam = np.asarray(bundle[0], dtype=np.float64).reshape(3, 3)
        t_cam = np.asarray(bundle[1], dtype=np.float64).reshape(3)

        U, _, Vt = np.linalg.svd(R_cam)
        R = U @ Vt
        if np.linalg.det(R) < 0:
            R[:, 2] = -R[:, 2]

        K = image_K.get(img_name)
        if K is None:
            K = fallback_K
        if K is None:
            fx = float(dw) * 1.5
            fy = float(dh) * 1.5
            K = np.array([[fx, 0, dw * 0.5], [0, fy, dh * 0.5], [0, 0, 1.0]], dtype=np.float64)
        else:
            K = np.asarray(K, dtype=np.float64).reshape(3, 3)

        try:
            wh = image_sizes[img_name]  # type: ignore[index]
            w, h = int(wh[0]), int(wh[1])
        except Exception:
            w, h = dw, dh

        views.append(
            ColmapCameraView(
                name=str(img_name),
                R_w2c=R.astype(np.float64),
                t_w2c=t_cam.astype(np.float64),
                K=K,
                width=w,
                height=h,
            )
        )
    return views


def load_colmap_views(sparse_dir: str) -> List[ColmapCameraView]:
    """读取 images.* + cameras.*（OpenCV/COLMAP：``X_cam = R @ X_world + t``）。

    注意：``dataset_readers`` 中的 ``np.transpose(qvec2rotmat(q))`` 是为
    ``getWorld2View2`` 再转置一次而准备的 ``R_cam_to_world``；此处针孔投影须直接用
    ``qvec2rotmat(q)`` 作为 ``R_w2c``，不可再转置。
    """
    cl = _colmap()
    cam_bin = os.path.join(sparse_dir, "cameras.bin")
    img_bin = os.path.join(sparse_dir, "images.bin")
    if os.path.isfile(cam_bin) and os.path.isfile(img_bin):
        cams = cl.read_intrinsics_binary(cam_bin)
        images = cl.read_extrinsics_binary(img_bin)
    else:
        cam_txt = os.path.join(sparse_dir, "cameras.txt")
        img_txt = os.path.join(sparse_dir, "images.txt")
        if not (os.path.isfile(cam_txt) and os.path.isfile(img_txt)):
            raise FileNotFoundError(f"sparse 目录缺少 cameras/images 二进制或文本: {sparse_dir}")
        cams = cl.read_intrinsics_text(cam_txt)
        images = cl.read_extrinsics_text(img_txt)

    views: List[ColmapCameraView] = []
    for im in images.values():
        cam = cams[im.camera_id]
        K, w, h = _pinhole_K(cam)
        R_w2c = np.asarray(cl.qvec2rotmat(im.qvec), dtype=np.float64)
        t_w2c = np.array(im.tvec, dtype=np.float64).reshape(3)
        views.append(
            ColmapCameraView(
                name=im.name,
                R_w2c=R_w2c.astype(np.float64),
                t_w2c=t_w2c,
                K=K,
                width=w,
                height=h,
            )
        )
    views.sort(key=lambda v: v.name)
    return views


def camera_center_world(view: ColmapCameraView) -> np.ndarray:
    """光心在世界系下的坐标。"""
    return (-view.R_w2c.T @ view.t_w2c.reshape(3, 1)).reshape(3)


def world_to_pixel(
    X: np.ndarray, view: ColmapCameraView
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    批量世界点 -> 像素坐标。
    X: (N,3)
    返回 u, v, valid（前向、在有限深度内）
    """
    R = view.R_w2c
    t = view.t_w2c.reshape(3, 1)
    Xc = (R @ X.T) + t  # (3,N)
    z = Xc[2, :]
    eps = 1e-8
    valid = z > eps
    u = np.zeros_like(z)
    v = np.zeros_like(z)
    inv_z = np.zeros_like(z)
    inv_z[valid] = 1.0 / z[valid]
    u[valid] = view.K[0, 0] * Xc[0, valid] * inv_z[valid] + view.K[0, 2]
    v[valid] = view.K[1, 1] * Xc[1, valid] * inv_z[valid] + view.K[1, 2]
    return u, v, valid


def estimate_depth_scale_from_sparse(
    sparse_xyz: np.ndarray,
    views: List[ColmapCameraView],
    *,
    side_view_azimuths_deg: Optional[Sequence[float]] = None,
    side_view_tolerance_deg: float = 5.0,
) -> float:
    """
    用「稀疏点在若干视图下的中位斜距 / 焦距」估计场景长度与像素量级比，
    用于将汇总报告中的 H（像素）拉到世界坐标尺度（近似）。

    side_view_azimuths_deg 非空时仅用该方位±容差内的相机（默认侧视 90°/270°）。
    """
    if sparse_xyz.size == 0 or not views:
        return 1.0
    use_views = list(views)
    if side_view_azimuths_deg:
        use_views = filter_colmap_views_near_azimuths(
            use_views,
            ref_azimuths_deg=side_view_azimuths_deg,
            tolerance_deg=side_view_tolerance_deg,
        )
    depths: List[float] = []
    f_list: List[float] = []
    sample = sparse_xyz
    if sample.shape[0] > 2000:
        rng = np.random.default_rng(0)
        idx = rng.choice(sample.shape[0], size=2000, replace=False)
        sample = sample[idx]
    for view in use_views[: min(len(use_views), 32)]:
        Xc = (view.R_w2c @ sample.T) + view.t_w2c.reshape(3, 1)
        z = Xc[2, :]
        m = z > 1e-6
        if m.any():
            depths.append(float(np.median(z[m])))
        f_list.append(0.5 * (view.K[0, 0] + view.K[1, 1]))
    if not depths or not f_list:
        return 1.0
    d_med = float(np.median(depths))
    f_med = float(np.median(f_list))
    if f_med < 1e-9:
        return 1.0
    return d_med / f_med


def filter_colmap_views_near_azimuths(
    views: List[ColmapCameraView],
    ref_azimuths_deg: Sequence[float] = (90.0, 270.0),
    tolerance_deg: float = 5.0,
) -> List[ColmapCameraView]:
    """保留文件名方位角落在 ref±容差 内的视图（MSTAR 侧视 90°/270°）。"""
    if not views:
        return views
    try:
        from sar_utils import parse_mstar_filename
    except ImportError:
        return views

    tol = float(tolerance_deg)
    refs = [float(a) % 360.0 for a in ref_azimuths_deg]
    kept: List[ColmapCameraView] = []
    for v in views:
        stem = os.path.splitext(os.path.basename(str(v.name)))[0]
        try:
            _, az = parse_mstar_filename(stem)
            az = float(az) % 360.0
        except Exception:
            continue
        for ref in refs:
            diff = abs((az - ref + 180.0) % 360.0 - 180.0)
            if diff <= tol:
                kept.append(v)
                break
    return kept if kept else list(views)


def ray_sample_points(
    view: ColmapCameraView,
    u: float,
    v: float,
    depths: np.ndarray,
) -> np.ndarray:
    """给定像素与一组沿射线的相机 Z 深度，返回世界坐标点 (K,3)。x_cam = R X + t。"""
    Kinv = np.linalg.inv(view.K)
    homo = np.array([u, v, 1.0], dtype=np.float64)
    dir_cam = Kinv @ homo
    if abs(dir_cam[2]) < 1e-12:
        return np.zeros((0, 3), dtype=np.float64)
    t = view.t_w2c.reshape(3)
    Rt = view.R_w2c.T
    out = []
    for z in depths:
        xcam = dir_cam * (z / dir_cam[2])
        xw = Rt @ (xcam - t)
        out.append(xw)
    return np.stack(out, axis=0)
