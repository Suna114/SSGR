"""convert + sfm.py 路径：当配置了 --sfm_summary_box_mesh_prior_mode 但未走 sfm/pipeline 时执行比例盒。"""

from __future__ import annotations

import json
import os
from typing import Any, List

import numpy as np


def _parse_module_names(raw: str) -> List[str]:
    if not raw:
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]


def _write_target_plane_ratio_record(
    *,
    mesh_path: str,
    source_path: str,
    sparse_dir: str,
    rx: float,
    ry: float,
    rz: float,
    result: Any,
    mode: str,
    replace_sparse: bool,
) -> None:
    length = 2.0 * float(rx)
    width = 2.0 * float(rz)
    height = 2.0 * float(ry)
    payload = {
        "target_plane_length_m": length,
        "target_plane_width_m": width,
        "target_plane_height_m": height,
        "target_plane_length_width_ratio": length / width if abs(width) > 1e-12 else None,
        "target_plane_width_length_ratio": width / length if abs(length) > 1e-12 else None,
        "semi_axes_rx_ry_rz": [float(rx), float(ry), float(rz)],
        "surface_mode": "plane",
        "mode": mode,
        "replace_sparse": bool(replace_sparse),
        "sample_count_output": int(getattr(result, "xyz_world").shape[0]),
        "mesh_path": os.path.abspath(mesh_path),
        "sparse_dir": os.path.abspath(sparse_dir),
    }
    out_dir = os.path.dirname(os.path.abspath(mesh_path)) or os.path.abspath(source_path)
    out_path = os.path.join(out_dir, "target_plane_ratio.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    print(
        "   target_plane_ratio: "
        f"L/W={payload['target_plane_length_width_ratio']:.6f} "
        f"(L={length:.6f}, W={width:.6f}) → {out_path}"
    )


def run_sfm_configured_summary_box_mesh_prior(source_path: str, args: Any) -> bool:
    """
    若 --sfm_summary_box_mesh_prior_mode 非 off，且 post_sfm_modules 未含 merge_summary_box_mesh_prior，
    则在此直接调用 summary_box_mesh_prior_core（与 SfM pipeline 内逻辑一致，写回 sparse/0）。
    """
    mode = (getattr(args, "sfm_summary_box_mesh_prior_mode", "off") or "off").strip().lower()
    if mode == "off":
        return False

    post_names = _parse_module_names(getattr(args, "post_sfm_modules", "") or "")
    if "merge_summary_box_mesh_prior" in post_names:
        return False

    sparse_dir = os.path.join(source_path, "sparse", "0")
    bin_path = os.path.join(sparse_dir, "points3D.bin")
    if not os.path.isdir(sparse_dir) or not os.path.isfile(bin_path):
        print("⚠️ sfm_summary_box: 无 sparse/0/points3D.bin，跳过比例盒")
        return False

    from post_sfm.colmap_points import (
        point3d_records_from_mesh_samples,
        read_points3d_binary_full,
        sync_colmap_point_outputs,
    )
    from post_sfm.summary_box_mesh_prior_core import run_summary_box_mesh_prior_core

    records0 = read_points3d_binary_full(bin_path)
    pts = np.stack([p.xyz for p in records0], axis=0) if records0 else np.zeros((0, 3))

    replace_sparse = mode == "replace"
    no_crop = bool(getattr(args, "post_sfm_summary_box_no_crop_on_replace", False))
    try:
        crop_margin = float(getattr(args, "sfm_mesh_prior_crop_margin", 0.0) or 0.0)
    except (TypeError, ValueError):
        crop_margin = 0.0
    crop_eff = float(0.0 if (replace_sparse and no_crop) else crop_margin)

    print("\n" + "=" * 60)
    print(f"【sfm_summary_box_mesh_prior】mode={mode}（convert/sfm.py 路径）")
    print("=" * 60)

    result, mesh_path, _mesh, rx, ry, rz = run_summary_box_mesh_prior_core(
        source_path=source_path,
        sparse_dir=sparse_dir,
        sparse_xyz_for_align=pts,
        args=args,
        mesh_param_source="sfm_mesh_prior",
        crop_margin_factor=crop_eff,
    )

    print(
        f"   名义半轴(rx,ry,rz)=({rx:.6f},{ry:.6f},{rz:.6f})\n"
        f"   网格: {mesh_path}\n"
        f"   replace_sparse={replace_sparse}, crop_margin={crop_eff}"
    )
    _write_target_plane_ratio_record(
        mesh_path=mesh_path,
        source_path=source_path,
        sparse_dir=sparse_dir,
        rx=rx,
        ry=ry,
        rz=rz,
        result=result,
        mode=mode,
        replace_sparse=replace_sparse,
    )

    if replace_sparse:
        rec_only = point3d_records_from_mesh_samples(result.xyz_world, result.rgb, start_id=1)
        sync_colmap_point_outputs(sparse_dir, rec_only)
        print(f"   replace_sparse: points3D 已替换为表面采样（{len(rec_only)} 点）")
        try:
            from sar.scene_scale_closure import sync_target_envelope_from_sparse_points3d

            sync_target_envelope_from_sparse_points3d(
                source_path,
                args,
                sparse_dir=sparse_dir,
                box_obj_path=mesh_path,
            )
        except Exception as e:
            print(f"   ⚠️ 由点云回写比例盒 / sar_scale_params 失败（继续）: {e}")
        try:
            from sar.gs_satellite_poses import gs_satellite_poses_enabled

            if not gs_satellite_poses_enabled(args):
                from sar.scene_anchor import maybe_center_colmap_scene_at_sar_anchor

                maybe_center_colmap_scene_at_sar_anchor(
                    source_path, args, tag="sfm_summary_box_mesh_prior"
                )
            else:
                print(
                    "   ℹ️ gs_satellite_poses 已启用：接地点居中延后至 mesh→ring 外参 之后"
                )
        except Exception as e:
            print(f"   ⚠️ SAR 场景接地点居中失败（继续）: {e}")
    else:
        from post_sfm.colmap_points import append_prior_xyz_to_records

        merge_min = float(getattr(args, "post_sfm_merge_min_dist", 0.0) or 0.0)
        before = len(records0)
        records, added = append_prior_xyz_to_records(
            records0, result.xyz_world, result.rgb, merge_min
        )
        sync_colmap_point_outputs(sparse_dir, records)
        print(f"   merge: {len(records)} 点（新增 {added}，合并前 {before}）")

    print("=" * 60 + "\n")
    return True
