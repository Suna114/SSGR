"""按配置顺序执行 post_sfm 模块。"""

from __future__ import annotations

import os
import traceback
from typing import Any, Callable, List

from post_sfm.context import PostSfmContext


def _parse_module_names(raw: str) -> List[str]:
    if not raw:
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]


_SCHEME_A_MODULE_NAMES = frozenset({"scheme_a_geometry_prior", "scheme_a_height_band"})


def _mesh_geometry_prior_configured(args: Any) -> bool:
    """是否配置了网格几何先验（SfM 内或 post_sfm 合并 OBJ）。"""
    mode = (getattr(args, "sfm_mesh_prior_mode", "off") or "off").strip().lower()
    sfm_obj = (getattr(args, "sfm_mesh_prior_obj", "") or "").strip()
    if mode != "off" and sfm_obj:
        return True
    sb = (getattr(args, "sfm_summary_box_mesh_prior_mode", "off") or "off").strip().lower()
    if sb != "off":
        return True
    if (getattr(args, "post_sfm_mesh_obj", "") or "").strip():
        return True
    if "merge_summary_box_mesh_prior" in _parse_module_names(getattr(args, "post_sfm_modules", "") or ""):
        return True
    return False


def _strip_scheme_a_if_mesh_prior(names: List[str], args: Any) -> List[str]:
    if getattr(args, "post_sfm_force_scheme_a", False):
        return names
    if not _mesh_geometry_prior_configured(args):
        return names
    removed = [n for n in names if n in _SCHEME_A_MODULE_NAMES]
    if not removed:
        return names
    kept = [n for n in names if n not in _SCHEME_A_MODULE_NAMES]
    print(
        "\nℹ️ post_sfm: 已启用网格几何先验，自动跳过体积先验模块: "
        + ", ".join(removed)
        + "\n   （避免与模型表面校正重复；若仍需方案 A 请加 --post_sfm_force_scheme_a）"
    )
    return kept


def run_post_sfm_modules(source_path: str, args: Any) -> bool:
    """
    在 sparse/0 已生成后调用。strict 模式下任一模块失败会抛出异常。
    """
    names = _parse_module_names(getattr(args, "post_sfm_modules", "") or "")
    if not names:
        return True

    sm = (getattr(args, "sfm_summary_box_mesh_prior_mode", "off") or "off").strip().lower()
    if sm != "off" and "merge_summary_box_mesh_prior" in names:
        names = [n for n in names if n != "merge_summary_box_mesh_prior"]
        print(
            f"\nℹ️ post_sfm: 已启用 --sfm_summary_box_mesh_prior_mode {sm}（SfM 内与 OBJ 同阶段），"
            "已跳过 post_sfm 中的 merge_summary_box_mesh_prior，避免二次替换/合并。"
        )

    names = _strip_scheme_a_if_mesh_prior(names, args)
    if not names:
        print("ℹ️ post_sfm: 过滤后无待执行模块，跳过。")
        return True

    sparse_dir = os.path.join(source_path, "sparse", "0")
    if not os.path.isdir(sparse_dir):
        print("⚠️ post_sfm: 未找到 sparse/0，跳过后处理模块")
        return True

    bin_path = os.path.join(sparse_dir, "points3D.bin")
    if not os.path.isfile(bin_path):
        print("⚠️ post_sfm: 无 points3D.bin，跳过后处理模块")
        return True

    from post_sfm.modules import REGISTRY

    ctx = PostSfmContext(source_path=source_path, sparse_dir=sparse_dir, args=args)
    strict = getattr(args, "post_sfm_strict", False)

    print("\n" + "=" * 60)
    print("【post_sfm 可插拔模块】顺序执行:", ", ".join(names))
    print("=" * 60)

    for name in names:
        fn: Callable[[PostSfmContext], None] | None = REGISTRY.get(name)
        if fn is None:
            known = ", ".join(sorted(REGISTRY.keys()))
            msg = f"未知 post_sfm 模块 '{name}'。已注册: {known}"
            print(f"❌ {msg}")
            if strict:
                raise ValueError(msg)
            continue
        print(f"▶ post_sfm 模块: {name}")
        try:
            fn(ctx)
            print(f"✅ post_sfm 模块完成: {name}")
        except Exception as e:
            print(f"❌ post_sfm 模块失败 [{name}]: {e}")
            traceback.print_exc()
            if strict:
                raise
    return True


def registered_module_names() -> List[str]:
    from post_sfm.modules import REGISTRY

    return sorted(REGISTRY.keys())
