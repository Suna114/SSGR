"""散射/语义掩码查找与加载（与 convert / train 缓存约定兼容）。"""

from __future__ import annotations

import glob
import os
from typing import Dict, Optional

import numpy as np


def _stem_key(name: str) -> str:
    return os.path.splitext(os.path.basename(name))[0]


def discover_mask_arrays(source_path: str, extra_dirs: Optional[list] = None) -> Dict[str, np.ndarray]:
    """
    在常见目录中查找 *_mask.npy，键为「带扩展名文件名」（与 images.bin 中 name 对齐优先）。
    """
    masks: Dict[str, np.ndarray] = {}
    candidates: list = []

    def add_dir(d: str):
        if d and os.path.isdir(d):
            candidates.append(d)

    add_dir(os.path.join(source_path, "scattering_masks"))
    add_dir(os.path.join(source_path, "adaptive_threshold_visualization"))
    add_dir(os.path.join(source_path, "feature_visualization"))
    add_dir(os.path.join(source_path, "input"))
    add_dir(os.path.join(source_path, "images"))
    add_dir(os.path.join(source_path, "masks"))
    if extra_dirs:
        for d in extra_dirs:
            ds = str(d).strip() if d else ""
            if ds:
                add_dir(ds)

    def _register_mask_path(p: str) -> None:
        if p in seen_paths or not os.path.isfile(p):
            return
        seen_paths.add(p)
        try:
            arr = np.load(p, mmap_mode="r")
            arr = np.asarray(arr)
        except Exception:
            return
        base = os.path.basename(p)
        stem = base.replace("_mask.npy", "").replace(".npy", "")
        for key in (stem + ".jpg", stem + ".png", stem + ".tif", stem + ".tiff", stem + ".jpeg"):
            if key not in masks:
                masks[key] = arr
        masks.setdefault(stem, arr)

    seen_paths = set()
    for d in candidates:
        for pat in ("*_mask.npy", "**/*_mask.npy"):
            for p in glob.glob(os.path.join(d, pat), recursive=True):
                _register_mask_path(p)

    # 最后一遍：数据集根下任意深度的 *_mask.npy（常用于 run_* 子目录）
    try:
        for p in glob.glob(os.path.join(source_path, "**", "*_mask.npy"), recursive=True):
            _register_mask_path(os.path.normpath(p))
    except Exception:
        pass

    return masks


def match_mask_for_image(
    image_name: str, cache: Dict[str, np.ndarray]
) -> Optional[np.ndarray]:
    if image_name in cache:
        return np.asarray(cache[image_name])
    stem = _stem_key(image_name)
    if stem in cache:
        return np.asarray(cache[stem])
    for k, v in cache.items():
        if _stem_key(k) == stem:
            return np.asarray(v)
    return None
