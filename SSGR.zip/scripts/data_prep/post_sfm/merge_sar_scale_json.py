"""
Merge ``sar_scale_params.json`` into a SAR parameter dict（与 Scene 加载 COLMAP/SfM 及
``render_novel_sar_views.merge_sfm_scale_params`` 对齐），避免在依赖 matplotlib 的大型脚本中重复导入逻辑。
"""

from __future__ import annotations

import json
import os
from typing import Any


def merge_scale_json_into_sar_params(
    sar_params: dict[str, Any],
    source_path: str | None = None,
    scale_json_path: str | None = None,
    mstar_nosfm: bool = False,
) -> dict[str, Any]:
    """
    从 SFM 输出的 sar_scale_params.json 合并尺度（与 scene/__init__.py 读取 COLMAP+SfM 数据时一致）。

    **mstar_nosfm**：无 SfM、无 scaled_camera_height 场景单位时不应用 JSON，避免与外参脱节。
    """
    if mstar_nosfm:
        print(
            "   ℹ️  mesh_prior SAR 尺度合并：训练为 mstar_nosfm，跳过 sar_scale_params.json "
            "（保持物理 camera_height 与渲染外参一致）"
        )
        return dict(sar_params)
    out = dict(sar_params)
    path = scale_json_path
    if path is None and source_path:
        path = os.path.join(source_path, "sar_scale_params.json")
    if not path or not os.path.isfile(path):
        print(
            "   ⚠️  mesh_prior SAR：未找到 sar_scale_params.json（可放在 source_path）；"
            "将仅用当前 sar_params 中的 camera_height / radius_scale。"
        )
        return out
    try:
        with open(path, "r", encoding="utf-8") as f:
            sp = json.load(f)
    except Exception as e:
        print(f"   ⚠️ mesh_prior SAR：读取尺度文件失败 {path}: {e}")
        return out

    if "unified_radius_scale" in sp:
        rs = float(sp["unified_radius_scale"])
        tag = "unified_radius_scale"
    elif "estimated_radius_scale" in sp:
        rs = float(sp["estimated_radius_scale"])
        tag = "estimated_radius_scale"
    else:
        rs = None
        tag = None
    if rs is not None:
        out["radius_scale"] = rs
        out["default_radius_scale"] = rs
        print(f"   ✅ mesh_prior SAR [{path}]：{tag} = {rs:.6g}")

    if "scene_scale" in sp:
        out["scene_scale"] = float(sp["scene_scale"])
        print(f"   ✅ mesh_prior SAR：已合并 scene_scale = {out['scene_scale']:.6g}")

    if "scaled_camera_height" in sp:
        out["camera_height"] = float(sp["scaled_camera_height"])
        print(f"   ✅ mesh_prior SAR：scaled_camera_height = {out['camera_height']:.4g}")
    elif "camera_height" in sp:
        print("   ℹ️  mesh_prior SAR：尺度文件仅有 camera_height，未覆盖（避免混淆物理/SfM 单位）")

    for k in ("unified_focal_azimuth", "unified_focal_range", "unified_cx", "unified_cy"):
        if k in sp:
            out[k] = sp[k]
    return out
