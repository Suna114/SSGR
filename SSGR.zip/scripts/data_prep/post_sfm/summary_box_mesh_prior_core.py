"""
阴影汇总比例盒：解析目标维度 txt → 名义半轴 → 轴对齐盒网格 → build_mesh_prior_pointcloud。

供 merge_summary_box_mesh_prior（post_sfm，写 COLMAP）与 SfM pipeline（内存点云，时机与 OBJ 先验一致）共用。
"""

from __future__ import annotations

import datetime
import os
from typing import Any, Literal, Optional, Sequence, Tuple

import numpy as np

from post_sfm.mesh_obj_prior_core import (
    MeshPriorResult,
    build_mesh_prior_pointcloud,
    make_axis_aligned_box_mesh,
    make_axis_aligned_ground_plane_mesh,
)
from post_sfm.sar_colmap_geom import (
    ColmapCameraView,
    camera_center_world,
    estimate_depth_scale_from_sparse,
    filter_colmap_views_near_azimuths,
    load_colmap_views,
)
from post_sfm.summary_parser import parse_target_dimension_summary, shadow_summary_semiaxes_xyz

try:
    from sar.imaging_mode import dataset_convention_debug_summary, resolve_dataset_world_yaw_deg
except ImportError:
    dataset_convention_debug_summary = None  # type: ignore
    resolve_dataset_world_yaw_deg = None  # type: ignore

try:
    from sar.scene_scale_closure import (
        MSTAR_DEFAULT_AZIMUTH_RES_M,
        MSTAR_DEFAULT_RANGE_RES_M,
        mstar_physical_semiaxes_xyz,
    )
except ImportError:
    mstar_physical_semiaxes_xyz = None  # type: ignore
    MSTAR_DEFAULT_AZIMUTH_RES_M = 0.3
    MSTAR_DEFAULT_RANGE_RES_M = 0.3


def resolve_mesh_prior_sar_imaging_scale_from_disk(
    source_path: str,
    sparse_dir: str,
    args: Any,
) -> Tuple[Optional[dict[str, Any]], Optional[float], Optional[Tuple[float, float]]]:
    """
    convert/sfm.py 路径下为 mesh_prior SAR 成像尺度对齐组装 sar_params（与 sfm/pipeline._MergedSarParams… 等价）。
    若未开启 --sfm_mesh_prior_sar_imaging_scale_match 则返回 (None, None, None)。
    """
    if not bool(getattr(args, "sfm_mesh_prior_sar_imaging_scale_match", False)):
        return None, None, None

    try:
        from sar.geometry import DEFAULT_SAR_PARAMS
    except ImportError:
        print("   ⚠️ mesh_prior SAR成像尺度对齐: 跳过（无法导入 sar.geometry）")
        return None, None, None

    from post_sfm.merge_sar_scale_json import merge_scale_json_into_sar_params

    sp: dict[str, Any] = dict(DEFAULT_SAR_PARAMS)
    views: list[ColmapCameraView] = []
    try:
        views = load_colmap_views(sparse_dir)
        if views:
            sp["Na"] = int(views[0].width)
            sp["Nr"] = int(views[0].height)
    except Exception as e:
        print(f"   ⚠️ mesh_prior SAR：读取 COLMAP 内参失败（继续）: {e}")

    mode = getattr(args, "sar_camera_distribution_mode", None)
    if mode:
        sp["camera_distribution_mode"] = str(mode).strip().lower()

    if getattr(args, "sar_camera_height", None) is not None:
        sp["camera_height"] = float(args.sar_camera_height)
    if getattr(args, "sar_scene_scale", None) is not None:
        sp["scene_scale"] = float(args.sar_scene_scale)

    sp = merge_scale_json_into_sar_params(
        sp,
        source_path,
        scale_json_path=None,
        mstar_nosfm=bool(getattr(args, "mstar_nosfm", False)),
    )

    dep: Optional[float] = None
    raw_dep = getattr(args, "sfm_mesh_prior_sar_imaging_ref_depression_deg", None)
    if raw_dep is not None:
        try:
            dep = float(raw_dep)
        except (TypeError, ValueError):
            dep = None

    if dep is None:
        deps: list[float] = []
        try:
            from sar_utils import parse_mstar_filename
        except ImportError:
            parse_mstar_filename = None  # type: ignore
        if parse_mstar_filename and views:
            for v in views:
                try:
                    d, _ = parse_mstar_filename(v.name)
                    deps.append(float(d))
                except Exception:
                    continue
        if deps:
            dep = float(np.median(np.asarray(deps, dtype=np.float64)))
        else:
            dep = 15.0

    side_az = (90.0, 270.0)
    theta_nadir = 90.0 - float(dep)
    print(
        f"   SAR 成像尺度匹配（convert 路径）: MSTAR horizon 俯角 φ≈{dep:.4g}° "
        f"(天底入射 θ≈{theta_nadir:.4g}°)，参考方位 90°/270°；"
        f"Na={sp.get('Na')}, Nr={sp.get('Nr')}, camera_height={sp.get('camera_height')}"
    )
    return sp, dep, side_az


def prepare_geometry_prior_versioned_outputs(source_path: str, args: Any) -> None:
    """
    每次运行 shadows 比例盒流程时在 geometry_prior/run_<时间戳>/ 下写出 OBJ 与相对路径的变换 JSON，
    避免覆盖历史模型；可通过 --no-geometry_prior_versioned_run_dir 关闭。
    若 ``post_sfm_summary_box_mesh_out`` 为绝对路径则不改写（保持用户完全自定义）。
    """
    if not bool(getattr(args, "geometry_prior_versioned_run_dir", True)):
        return
    if getattr(args, "_geometry_prior_versioned_prepared", False):
        return

    rel_mesh = (getattr(args, "post_sfm_summary_box_mesh_out", "") or "").strip()
    if rel_mesh and os.path.isabs(rel_mesh):
        setattr(args, "_geometry_prior_versioned_prepared", True)
        return

    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run_rel = os.path.join("geometry_prior", f"run_{stamp}")
    abs_run = os.path.abspath(os.path.join(source_path, run_rel))
    os.makedirs(abs_run, exist_ok=True)

    base_m = os.path.basename(rel_mesh.replace("\\", "/")) if rel_mesh else ""
    if not base_m.endswith(".obj"):
        base_m = "shadow_proportional_box.obj"
    args.post_sfm_summary_box_mesh_out = os.path.join(run_rel, base_m)

    sj = (getattr(args, "sfm_mesh_prior_save_transform_json", "") or "").strip()
    if sj and not os.path.isabs(sj):
        sj_norm = sj.replace("\\", "/")
        args.sfm_mesh_prior_save_transform_json = os.path.join(run_rel, os.path.basename(sj_norm))

    setattr(args, "_geometry_prior_versioned_prepared", True)
    setattr(args, "_geometry_prior_run_abs", abs_run)
    print(f"📁 geometry_prior 版本化输出目录: {run_rel}")


def resolve_target_dimension_summary_path(source_path: str, args: Any) -> Tuple[str, list]:
    """
    COLMAP/SfM 的 data_dir 可能与 convert 写入汇总的 source_path 不一致（例如设置了 --sfm_data_dir）。
    在若干候选根目录下查找 adaptive_threshold_visualization/target_dimension_constraints_summary.txt，
    返回首个存在的路径；否则返回首选路径（便于报错列出全部候选）。
    """
    viz = getattr(args, "visualization_dir", "adaptive_threshold_visualization")
    fname = "target_dimension_constraints_summary.txt"
    roots: list[str] = []
    for base in (
        source_path,
        getattr(args, "source_path", None),
        getattr(args, "sfm_data_dir", None),
    ):
        b = (base or "").strip()
        if not b:
            continue
        ab = os.path.normpath(os.path.abspath(b))
        if ab not in roots:
            roots.append(ab)
    if not roots:
        roots.append(os.path.normpath(os.path.abspath(os.curdir)))
    candidates = [os.path.join(r, viz, fname) for r in roots]
    for p in candidates:
        if os.path.isfile(p):
            return p, candidates
    return candidates[0], candidates


def _resolve_user_path(base_dir: str, p: str) -> str:
    p = (p or "").strip()
    if not p:
        return ""
    if os.path.isfile(p):
        return os.path.abspath(p)
    cand = os.path.join(base_dir, p)
    if os.path.isfile(cand):
        return os.path.abspath(cand)
    return os.path.abspath(os.path.normpath(os.path.join(base_dir, p)))


def _align_kwargs_from_args(args: Any, mesh_param_source: Literal["post_sfm_mesh", "sfm_mesh_prior"]) -> dict:
    """与 merge_summary_box_mesh_prior / _MaybeApplySfmMeshGeometryPrior 的字段命名一致。"""
    if resolve_dataset_world_yaw_deg is not None:
        auto_world_yaw = float(resolve_dataset_world_yaw_deg(args, default_yaw_deg=-90.0))
    else:
        auto_world_yaw = float(getattr(args, "sfm_mesh_prior_extra_world_yaw_deg", -90.0))
    if mesh_param_source == "sfm_mesh_prior":
        save_json = (getattr(args, "sfm_mesh_prior_save_transform_json", "") or "").strip()
        if save_json and not os.path.isabs(save_json):
            base = getattr(args, "source_path", "") or getattr(args, "data_dir", "") or ""
            save_json = os.path.abspath(os.path.join(base, save_json)) if base else os.path.abspath(save_json)
        elif save_json:
            save_json = os.path.abspath(save_json)
        else:
            save_json = None
        return {
            "sample_count": int(getattr(args, "sfm_mesh_prior_sample_count", 120_000)),
            "icp_source_samples": int(getattr(args, "sfm_mesh_prior_icp_source_samples", 50_000)),
            "skip_icp": bool(getattr(args, "sfm_mesh_prior_skip_icp", True)),
            "use_poisson_disk": bool(getattr(args, "sfm_mesh_prior_poisson_disk", True)),
            "scale_override": float(getattr(args, "sfm_mesh_prior_scale_override", 0.0) or 0.0),
            "icp_max_iters": int(getattr(args, "sfm_mesh_prior_icp_max_iters", 40) or 40),
            "seed": int(getattr(args, "sfm_mesh_prior_seed", 0) or 0),
            "max_sparse_points": int(getattr(args, "sfm_mesh_prior_max_sparse_read", 500_000) or 500_000),
            "save_transform_json": save_json,
            "use_normal_rgb": bool(getattr(args, "sfm_mesh_prior_pseudocolor_normals", False)),
            "extra_world_yaw_deg": auto_world_yaw,
            "final_uniform_scale": float(getattr(args, "sfm_mesh_prior_final_uniform_scale", 0.5)),
            "sar_imaging_scale_match": bool(getattr(args, "sfm_mesh_prior_sar_imaging_scale_match", False)),
            "sar_params_for_scale": None,
            "sar_scale_ref_azimuth_deg": float(
                getattr(args, "sfm_mesh_prior_sar_imaging_ref_azimuth_deg", 90.0)
            ),
            "sar_scale_ref_depression_deg": getattr(
                args, "sfm_mesh_prior_sar_imaging_ref_depression_deg", None
            ),
            "nominal_coarse_mode": (
                "sparse_diagonal"
                if bool(getattr(args, "sfm_mesh_prior_nominal_match_sparse_diagonal", False))
                else str(
                    getattr(args, "sfm_mesh_prior_nominal_coarse_mode", "ground_contact")
                    or "ground_contact"
                ).strip().lower()
            ),
        }
    save_json = (getattr(args, "post_sfm_mesh_save_transform_json", "") or "").strip()
    base = getattr(args, "source_path", "") or ""
    if save_json:
        save_json = _resolve_user_path(base, save_json)
    return {
        "sample_count": int(getattr(args, "post_sfm_mesh_sample_count", 200_000) or 200_000),
        "icp_source_samples": int(getattr(args, "post_sfm_mesh_icp_source_samples", 80_000) or 80_000),
        "skip_icp": bool(getattr(args, "post_sfm_mesh_skip_icp", False)),
        "use_poisson_disk": bool(getattr(args, "post_sfm_mesh_poisson_disk", False)),
        "scale_override": float(getattr(args, "post_sfm_mesh_scale_override", 0.0) or 0.0),
        "icp_max_iters": int(getattr(args, "post_sfm_mesh_icp_max_iters", 40) or 40),
        "seed": int(getattr(args, "post_sfm_mesh_seed", 0) or 0),
        "max_sparse_points": int(getattr(args, "post_sfm_mesh_max_sparse_read", 500_000) or 500_000),
        "save_transform_json": save_json or None,
        "use_normal_rgb": bool(getattr(args, "post_sfm_mesh_pseudocolor_normals", False)),
        "extra_world_yaw_deg": auto_world_yaw,
        "sar_imaging_scale_match": False,
        "sar_params_for_scale": None,
        "sar_scale_ref_azimuth_deg": float(90.0),
        "sar_scale_ref_depression_deg": None,
        "nominal_coarse_mode": (
            "sparse_diagonal"
            if bool(getattr(args, "post_sfm_mesh_nominal_match_sparse_diagonal", False))
            else str(
                getattr(args, "sfm_mesh_prior_nominal_coarse_mode", "ground_contact")
                or "ground_contact"
            ).strip().lower()
        ),
    }


def build_axis_aligned_summary_box_mesh(
    *,
    source_path: str,
    sparse_dir: str,
    sparse_xyz: np.ndarray,
    args: Any,
    views_override: Optional[list[ColmapCameraView]] = None,
) -> Tuple[float, float, float, Any, str]:
    """
    解析 summary，估计 depth_scale 与名义半轴，生成轴对齐盒并写出 OBJ。

    ``views_override``：在未写出 ``sparse/0/cameras*`` ``images*`` 时（如 ``before_filter`` 阶段）
    传入与 COLMAP 一致的内存相机列表；为 ``None`` 时从磁盘读取。

    返回 (rx, ry, rz, triangle_mesh, mesh_path)。
    """
    summary_path, tried_paths = resolve_target_dimension_summary_path(source_path, args)
    stats = parse_target_dimension_summary(summary_path)
    if stats is None:
        cand_txt = "\n".join(f"    - {p}" for p in tried_paths)
        raise RuntimeError(
            "比例盒先验需要目标尺度汇总（文件缺失或缺少 L/W/H 中位数行）：\n"
            f"  解析路径: {summary_path}\n"
            "请先完成带有维度汇总的 convert 流程；若已转换，检查 --source_path / --sfm_data_dir 是否与写出汇总的路径一致。\n"
            "已尝试路径:\n"
            f"{cand_txt}"
        )

    if views_override is not None:
        views = list(views_override)
    else:
        views = load_colmap_views(sparse_dir)
    if not views:
        raise RuntimeError(
            "比例盒先验: 无可用相机视图（sparse_dir 缺少 COLMAP cameras/images，且未提供内存 views_override），"
            "无法估计深度尺度"
        )

    pts = np.asarray(sparse_xyz, dtype=np.float64)
    pick_mode = str(getattr(args, "target_dimension_summary_azimuth_mode", "oblique") or "oblique").strip().lower()
    side_az = (90.0, 270.0) if pick_mode == "mstar_axis_split" else None
    tol = float(getattr(args, "target_dimension_summary_azimuth_tolerance_deg", 5.0) or 5.0)
    use_mstar_phys = bool(getattr(args, "sfm_mesh_prior_use_mstar_pixel_resolution", False))
    shadow_h_scale = float(getattr(args, "post_sfm_scheme_a_shadow_height_scale", 1.0) or 1.0)
    upper_h = float(getattr(args, "post_sfm_scheme_a_height_slab_upper_scale", 1.25) or 1.25)
    lower_h = float(getattr(args, "post_sfm_scheme_a_height_slab_lower_scale", 0.35) or 0.35)
    pf_scale = float(getattr(args, "post_sfm_scheme_a_planform_scale", 1.0) or 1.0)

    rho_a = float(
        getattr(args, "sfm_mstar_azimuth_resolution_m", MSTAR_DEFAULT_AZIMUTH_RES_M)
        or MSTAR_DEFAULT_AZIMUTH_RES_M
    )
    rho_r = float(
        getattr(args, "sfm_mstar_range_resolution_m", MSTAR_DEFAULT_RANGE_RES_M)
        or MSTAR_DEFAULT_RANGE_RES_M
    )

    if use_mstar_phys and mstar_physical_semiaxes_xyz is not None:
        from sar.scene_scale_closure import (
            mstar_fixed_physical_target_dims_enabled,
            resolve_mstar_target_semiaxes_xyz,
        )

        sem = resolve_mstar_target_semiaxes_xyz(
            stats,
            args,
            rho_azimuth_m=rho_a,
            rho_range_m=rho_r,
            planform_scale=pf_scale,
            shadow_h_scale=shadow_h_scale,
            upper_h=upper_h,
            lower_h=lower_h,
        )
        if mstar_fixed_physical_target_dims_enabled(args):
            from sar.scene_scale_closure import resolve_mstar_fixed_physical_meters

            lm, wm, hm = resolve_mstar_fixed_physical_meters(args, stats)
            print(
                f"   比例盒 MSTAR 固定米制: L={lm:.2f} m, W={wm:.2f} m, H={hm:.2f} m"
                f"（ρ={rho_a:g}/{rho_r:g} m/px 作相机尺度，不放大 L×planform）"
            )
        else:
            print(
                f"   比例盒 MSTAR 像素分辨率尺度: ρ_a={rho_a:g} m/px, ρ_r={rho_r:g} m/px"
                f"（L/W 直接换米制，不用稀疏 depth_scale）"
            )
    else:
        depth_scale = estimate_depth_scale_from_sparse(
            pts, views, side_view_azimuths_deg=side_az, side_view_tolerance_deg=tol
        )
        if side_az is not None:
            n_side = len(filter_colmap_views_near_azimuths(views, side_az, tol))
            print(
                f"   比例盒 depth_scale={depth_scale:.6g}（侧视 90°/270°±{tol:g}° 相机 {n_side}/{len(views)} 张）"
            )

        h_world = None
        if stats.height_median_px is not None:
            h_world = float(stats.height_median_px) * depth_scale * shadow_h_scale

        sem = shadow_summary_semiaxes_xyz(stats, depth_scale, pf_scale, h_world, upper_h, lower_h)
    if sem is None:
        raise RuntimeError("比例盒先验: 汇总缺少 L/W 像素中位数")

    rx, ry, rz = sem
    surface_mode = str(getattr(args, "sfm_summary_box_surface_mode", "box") or "box").strip().lower()
    if surface_mode in ("plane", "flat", "ground_plane", "imaging_plane"):
        mesh = make_axis_aligned_ground_plane_mesh(rx, rz)
        print(
            "   比例盒表面模式: plane（仅 XZ 接地/成像平面采样；"
            f"保留 L/W=2rx/2rz，忽略盒体厚度 H=2ry={2.0 * float(ry):.4g}）"
        )
    else:
        surface_mode = "box"
        mesh = make_axis_aligned_box_mesh(rx, ry, rz)
        print("   比例盒表面模式: box（六面体表面采样）")

    rel_out = (getattr(args, "post_sfm_summary_box_mesh_out", "") or "").strip()
    if not rel_out:
        rel_out = os.path.join("geometry_prior", "shadow_proportional_box.obj")
    mesh_path = _resolve_user_path(source_path, rel_out)
    parent = os.path.dirname(mesh_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    try:
        import open3d as o3d
    except ImportError as e:
        raise ImportError("长方体导出需 open3d：pip install open3d") from e

    if not o3d.io.write_triangle_mesh(mesh_path, mesh, write_triangle_uvs=False, print_progress=False):
        raise RuntimeError(f"无法写出网格: {mesh_path}")

    return rx, ry, rz, mesh, mesh_path


def align_summary_box_mesh_to_sparse(
    *,
    sparse_dir: str,
    sparse_xyz_align: Optional[np.ndarray],
    mesh_path: str,
    triangle_mesh: Any,
    rx: float,
    ry: float,
    rz: float,
    args: Any,
    mesh_param_source: Literal["post_sfm_mesh", "sfm_mesh_prior"],
    crop_margin_factor: float,
    alignment_extra_xyz: Optional[np.ndarray] = None,
    sar_params_for_scale: Optional[dict[str, Any]] = None,
    sar_scale_ref_depression_deg: Optional[float] = None,
    sar_scale_ref_azimuth_deg: float = 90.0,
    sar_scale_ref_azimuths: Optional[Sequence[float]] = None,
) -> MeshPriorResult:
    """对已建成 triangle_mesh 做多尺度对齐 + 表面采样（与 OBJ 先验同一套 build_mesh_prior_pointcloud）。"""
    kw = _align_kwargs_from_args(args, mesh_param_source)
    source_path = getattr(args, "source_path", "") or getattr(args, "data_dir", "") or ""
    if dataset_convention_debug_summary is not None and source_path:
        print(
            "   mesh_prior convention -> "
            f"{dataset_convention_debug_summary(source_path)}; "
            f"world_yaw={float(kw.get('extra_world_yaw_deg', 0.0)):.1f} deg"
        )
    if sar_params_for_scale is not None:
        kw["sar_params_for_scale"] = sar_params_for_scale
    if sar_scale_ref_depression_deg is not None:
        kw["sar_scale_ref_depression_deg"] = sar_scale_ref_depression_deg
    kw["sar_scale_ref_azimuth_deg"] = float(sar_scale_ref_azimuth_deg)
    if sar_scale_ref_azimuths is not None:
        kw["sar_scale_ref_azimuths"] = tuple(float(a) for a in sar_scale_ref_azimuths)
    return build_mesh_prior_pointcloud(
        mesh_path,
        sparse_dir,
        sparse_xyz=sparse_xyz_align,
        crop_margin_factor=float(crop_margin_factor),
        triangle_mesh=triangle_mesh,
        alignment_extra_xyz=alignment_extra_xyz,
        coarse_nominal_semi_axes=(rx, ry, rz),
        **kw,
    )


def run_summary_box_mesh_prior_core(
    *,
    source_path: str,
    sparse_dir: str,
    sparse_xyz_for_align: np.ndarray,
    args: Any,
    mesh_param_source: Literal["post_sfm_mesh", "sfm_mesh_prior"],
    crop_margin_factor: float,
    views_override: Optional[list[ColmapCameraView]] = None,
    sar_params_for_scale: Optional[dict[str, Any]] = None,
    sar_scale_ref_depression_deg: Optional[float] = None,
    sar_scale_ref_azimuth_deg: float = 90.0,
    sar_scale_ref_azimuths: Optional[Sequence[float]] = None,
) -> Tuple[MeshPriorResult, str, Any, float, float, float]:
    """
    完整流程：summary → 盒网格 OBJ → 对齐采样。

    sparse_xyz_for_align：与 COLMAP/内存一致的稀疏点（N×3），可作空数组时由调用方传入 align 子集。
    views_override：见 ``build_axis_aligned_summary_box_mesh``（SfM before_filter 尚未写 sparse 时使用）。
    """
    prepare_geometry_prior_versioned_outputs(source_path, args)

    if (
        sar_params_for_scale is None
        and bool(getattr(args, "sfm_mesh_prior_sar_imaging_scale_match", False))
    ):
        try:
            from sar.imaging_mode import gs_optical_perspective_only_enabled

            if gs_optical_perspective_only_enabled(args):
                print("   mesh_prior：gs 光学透视模式，跳过 SAR 成像尺度匹配")
            else:
                sp_res, dep_res, az_res = resolve_mesh_prior_sar_imaging_scale_from_disk(
                    source_path, sparse_dir, args
                )
                if sp_res is not None:
                    sar_params_for_scale = sp_res
                if sar_scale_ref_depression_deg is None and dep_res is not None:
                    sar_scale_ref_depression_deg = dep_res
                if sar_scale_ref_azimuths is None and az_res is not None:
                    sar_scale_ref_azimuths = az_res
        except ImportError:
            sp_res, dep_res, az_res = resolve_mesh_prior_sar_imaging_scale_from_disk(
                source_path, sparse_dir, args
            )
            if sp_res is not None:
                sar_params_for_scale = sp_res
            if sar_scale_ref_depression_deg is None and dep_res is not None:
                sar_scale_ref_depression_deg = dep_res
            if sar_scale_ref_azimuths is None and az_res is not None:
                sar_scale_ref_azimuths = az_res

    pts = np.asarray(sparse_xyz_for_align, dtype=np.float64)
    sparse_xyz_align = pts if pts.shape[0] else None

    rx, ry, rz, mesh, mesh_path = build_axis_aligned_summary_box_mesh(
        source_path=source_path,
        sparse_dir=sparse_dir,
        sparse_xyz=pts,
        args=args,
        views_override=views_override,
    )

    views = list(views_override) if views_override is not None else load_colmap_views(sparse_dir)
    use_cam = bool(getattr(args, "post_sfm_summary_box_align_camera_centers", False))
    align_extra = None
    if use_cam and views:
        pick_mode = str(getattr(args, "target_dimension_summary_azimuth_mode", "oblique") or "oblique").strip().lower()
        tol = float(getattr(args, "target_dimension_summary_azimuth_tolerance_deg", 5.0) or 5.0)
        cam_views = (
            filter_colmap_views_near_azimuths(views, (90.0, 270.0), tol)
            if pick_mode == "mstar_axis_split"
            else views
        )
        cams = np.stack([camera_center_world(v) for v in cam_views], axis=0)
        if cams.shape[0] > 0:
            align_extra = cams

    result = align_summary_box_mesh_to_sparse(
        sparse_dir=sparse_dir,
        sparse_xyz_align=sparse_xyz_align,
        mesh_path=mesh_path,
        triangle_mesh=mesh,
        rx=rx,
        ry=ry,
        rz=rz,
        args=args,
        mesh_param_source=mesh_param_source,
        crop_margin_factor=crop_margin_factor,
        alignment_extra_xyz=align_extra,
        sar_params_for_scale=sar_params_for_scale,
        sar_scale_ref_depression_deg=sar_scale_ref_depression_deg,
        sar_scale_ref_azimuth_deg=float(sar_scale_ref_azimuth_deg),
        sar_scale_ref_azimuths=sar_scale_ref_azimuths,
    )
    return result, mesh_path, mesh, rx, ry, rz
