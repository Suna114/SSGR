# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# sfm_pure_visual.py
"""
纯视觉SAR SfM实现 - 基于论文方法
"Keypoint-Based SAR Structure From Motion via Riemannian Optimization"

核心特点：
1. 不依赖文件名中的角度信息
2. 使用关键点匹配和极线几何
3. 从基础矩阵恢复初始姿态
4. 增量式重建（类似COLMAP）
5. SO-RCG全局优化

使用方法：
在config.py中设置 --sfm_use_pure_visual True
"""

import numpy as np
import cv2
from scipy.spatial.transform import Rotation as Rot
import pickle
import os

try:
    from sar_geometry import compute_sar_camera_pose, DEFAULT_SAR_PARAMS
    SAR_GEOMETRY_AVAILABLE = True
except ImportError:
    SAR_GEOMETRY_AVAILABLE = False


class PureVisualSARSfM:
    """
    纯视觉SAR SfM求解器 - 完全遵循论文方法
    """
    
    def __init__(self, opts, sar_params=None):
        """
        初始化纯视觉SAR SfM求解器
        
        Args:
            opts: 配置参数
            sar_params: SAR系统参数（用于计算K矩阵）
        """
        self.opts = opts
        self.sar_params = sar_params or DEFAULT_SAR_PARAMS
        
        # 从opts读取阈值参数
        self.min_initial_matches = getattr(opts, 'sfm_pure_visual_min_initial_matches', 100)
        self.min_inliers = getattr(opts, 'sfm_pure_visual_min_inliers', 15)
        self.min_pnp_points = getattr(opts, 'sfm_pure_visual_min_pnp_points', 10)
        self.reproj_threshold = getattr(opts, 'sfm_pure_visual_reproj_threshold', 4.0)
        
        # 重建状态
        self.camera_poses = {}  # {img_name: {'R': R, 't': t, 'K': K}}
        self.point_cloud = np.zeros((0, 3))  # 3D点云
        self.point_colors = np.zeros((0, 3))  # 点云颜色
        self.point_tracks = {}  # {point_idx: [(img_name, kp_idx), ...]}
        
        # 重建过程中的图像状态
        self.registered_images = set()  # 已注册的图像
        self.unregistered_images = set()  # 未注册的图像
        
        # 统计信息
        self.num_initial_points = 0
        self.num_registered_images = 0
        
        print("\n" + "="*70)
        print("🎯 纯视觉SAR SfM初始化")
        print("   模式: 基于极线几何的增量式重建（论文方法）")
        print("   不依赖文件名角度信息")
        print(f"\n   📊 阈值参数:")
        print(f"      - 最小初始匹配数: {self.min_initial_matches}")
        print(f"      - 最小内点数: {self.min_inliers}")
        print(f"      - 最小PnP点数: {self.min_pnp_points}")
        print(f"      - 重投影误差阈值: {self.reproj_threshold}像素")
        print("="*70 + "\n")
    
    def estimate_initial_pair_pose(self, img1_pts, img2_pts, K1, K2):
        """
        从基础矩阵估计初始图像对的相对位姿（论文方法）
        
        Args:
            img1_pts: 图像1中的匹配点 (N, 2)
            img2_pts: 图像2中的匹配点 (N, 2)
            K1, K2: 相机内参矩阵
        
        Returns:
            R_rel: 相对旋转矩阵 (3, 3)
            t_rel: 相对平移向量 (3, 1)
            inlier_mask: RANSAC内点掩码
            success: 是否成功估计
        """
        if len(img1_pts) < 8:
            print(f"   ⚠️ 匹配点数不足: {len(img1_pts)} < 8")
            return None, None, None, False
        
        print(f"   🔍 从 {len(img1_pts)} 个匹配点估计基础矩阵...")
        
        try:
            # 1. 使用RANSAC估计基础矩阵（论文核心方法）
            F, mask = cv2.findFundamentalMat(
                img1_pts, img2_pts,
                method=cv2.FM_RANSAC,
                ransacReprojThreshold=2.0,  # 像素
                confidence=0.999,
                maxIters=10000
            )
            
            if F is None or mask is None:
                print("   ❌ 基础矩阵估计失败")
                return None, None, None, False
            
            inlier_mask = mask.ravel().astype(bool)
            num_inliers = np.sum(inlier_mask)
            inlier_ratio = num_inliers / len(img1_pts)
            
            print(f"   ✅ 基础矩阵估计成功: {num_inliers}/{len(img1_pts)} 内点 ({inlier_ratio*100:.1f}%)")
            
            # 检查内点数是否足够
            if num_inliers < self.min_inliers:
                print(f"   ⚠️ 内点数不足: {num_inliers} < {self.min_inliers}")
                return None, None, None, False
            
            # 2. 计算本质矩阵 E = K2^T F K1
            E = K2.T @ F @ K1
            
            # 3. 从本质矩阵恢复相对位姿（论文方法）
            _, R_rel, t_rel, pose_mask = cv2.recoverPose(
                E, 
                img1_pts[inlier_mask], 
                img2_pts[inlier_mask], 
                K1
            )
            
            # 更新内点掩码（结合pose恢复的掩码）
            temp_inlier_mask = inlier_mask.copy()
            inlier_indices = np.where(inlier_mask)[0]
            pose_inlier_indices = inlier_indices[pose_mask.ravel().astype(bool)]
            temp_inlier_mask[:] = False
            temp_inlier_mask[pose_inlier_indices] = True
            inlier_mask = temp_inlier_mask
            
            num_final_inliers = np.sum(inlier_mask)
            print(f"   ✅ 相对位姿恢复成功: {num_final_inliers} 个有效内点")
            
            return R_rel, t_rel, inlier_mask, True
            
        except Exception as e:
            print(f"   ❌ 位姿估计失败: {e}")
            import traceback
            traceback.print_exc()
            return None, None, None, False
    
    def triangulate_initial_points(self, img1_pts, img2_pts, R1, t1, R2, t2, K1, K2, inlier_mask):
        """
        三角化初始点云
        
        Args:
            img1_pts, img2_pts: 图像匹配点
            R1, t1, R2, t2: 相机位姿
            K1, K2: 相机内参
            inlier_mask: 内点掩码
        
        Returns:
            points_3d: 三角化的3D点 (N, 3)
            valid_mask: 有效点掩码
        """
        print(f"   🔺 三角化初始点云...")
        
        # 只使用内点
        pts1 = img1_pts[inlier_mask]
        pts2 = img2_pts[inlier_mask]
        
        # 构建投影矩阵 P = K[R|t]
        P1 = K1 @ np.hstack([R1, t1])
        P2 = K2 @ np.hstack([R2, t2])
        
        # 三角化
        points_4d_hom = cv2.triangulatePoints(P1, P2, pts1.T, pts2.T)
        points_3d = points_4d_hom[:3] / points_4d_hom[3]
        points_3d = points_3d.T  # (N, 3)
        
        # 过滤无效点
        valid_mask = np.ones(len(points_3d), dtype=bool)
        
        # 1. 深度检查：点应该在两个相机前方
        points_cam1 = (R1 @ points_3d.T + t1).T
        points_cam2 = (R2 @ points_3d.T + t2).T
        valid_mask &= (points_cam1[:, 2] > 0) & (points_cam2[:, 2] > 0)
        
        # 2. 重投影误差检查
        pts1_reproj = (P1 @ np.hstack([points_3d, np.ones((len(points_3d), 1))]).T).T
        pts1_reproj = pts1_reproj[:, :2] / pts1_reproj[:, 2:3]
        reproj_error1 = np.linalg.norm(pts1 - pts1_reproj, axis=1)
        
        pts2_reproj = (P2 @ np.hstack([points_3d, np.ones((len(points_3d), 1))]).T).T
        pts2_reproj = pts2_reproj[:, :2] / pts2_reproj[:, 2:3]
        reproj_error2 = np.linalg.norm(pts2 - pts2_reproj, axis=1)
        
        max_reproj_error = 4.0  # 像素
        valid_mask &= (reproj_error1 < max_reproj_error) & (reproj_error2 < max_reproj_error)
        
        # 3. 距离合理性检查
        mean_dist = np.mean(np.linalg.norm(points_3d[valid_mask], axis=1))
        std_dist = np.std(np.linalg.norm(points_3d[valid_mask], axis=1))
        max_dist = mean_dist + 3 * std_dist
        point_dists = np.linalg.norm(points_3d, axis=1)
        valid_mask &= (point_dists < max_dist)
        
        num_valid = np.sum(valid_mask)
        print(f"   ✅ 三角化完成: {num_valid}/{len(points_3d)} 有效点")
        
        return points_3d, valid_mask
    
    def select_initial_pair(self, image_names, matches_dict, keypoints_dict):
        """
        选择初始图像对（增量式SfM的第一步）
        
        选择标准：
        1. 匹配点数量多
        2. 匹配点分布均匀
        3. 基线足够大但不过大
        
        Args:
            image_names: 图像名称列表
            matches_dict: 匹配字典
            keypoints_dict: 关键点字典
        
        Returns:
            best_pair: (img1_name, img2_name) 或 None
        """
        print("\n" + "="*70)
        print("🔍 选择初始图像对...")
        print("="*70)
        
        # 🔍 添加诊断信息
        print(f"   📊 输入数据统计:")
        print(f"      - 图像数量: {len(image_names)}")
        print(f"      - 关键点字典大小: {len(keypoints_dict)}")
        print(f"      - 匹配字典大小: {len(matches_dict)}")
        
        if len(matches_dict) > 0:
            first_match_key = list(matches_dict.keys())[0]
            first_matches = matches_dict[first_match_key]
            print(f"      - 第一个匹配对: {first_match_key}")
            print(f"      - 第一个匹配数量: {len(first_matches)}")
            if len(first_matches) > 0:
                print(f"      - 匹配数据类型: {type(first_matches[0])}")
        
        candidate_pairs = []
        
        # 🔍 添加统计信息
        total_pairs = len(matches_dict)
        filtered_by_count = 0
        filtered_by_kp = 0
        filtered_by_extraction = 0
        
        for (img1, img2), matches in matches_dict.items():
            if len(matches) < self.min_initial_matches:  # 最小匹配点数（从opts读取）
                filtered_by_count += 1
                continue
            
            # 提取匹配点
            kp1 = keypoints_dict.get(img1, [])
            kp2 = keypoints_dict.get(img2, [])
            
            if len(kp1) == 0 or len(kp2) == 0:
                filtered_by_kp += 1
                continue
            
            # 提取匹配点坐标
            img1_pts = []
            img2_pts = []
            for m in matches:
                if hasattr(m, 'queryIdx'):
                    idx1, idx2 = m.queryIdx, m.trainIdx
                elif isinstance(m, (list, tuple)) and len(m) >= 2:
                    idx1, idx2 = m[0], m[1]
                else:
                    continue
                
                if idx1 < len(kp1) and idx2 < len(kp2):
                    pt1 = kp1[idx1].pt if hasattr(kp1[idx1], 'pt') else kp1[idx1]
                    pt2 = kp2[idx2].pt if hasattr(kp2[idx2], 'pt') else kp2[idx2]
                    img1_pts.append(pt1)
                    img2_pts.append(pt2)
            
            if len(img1_pts) < self.min_initial_matches:
                filtered_by_extraction += 1
                continue
            
            img1_pts = np.array(img1_pts)
            img2_pts = np.array(img2_pts)
            
            # 计算分布均匀性（使用标准差）
            spread1 = np.std(img1_pts, axis=0).mean()
            spread2 = np.std(img2_pts, axis=0).mean()
            spread_score = (spread1 + spread2) / 2
            
            # 综合评分：匹配数 + 分布均匀性
            score = len(img1_pts) + spread_score * 10
            
            candidate_pairs.append((img1, img2, score, len(img1_pts)))
        
        # 🔍 输出过滤统计
        print(f"\n   📊 过滤统计:")
        print(f"      - 总匹配对数: {total_pairs}")
        print(f"      - 匹配数<100过滤: {filtered_by_count}")
        print(f"      - 关键点为空过滤: {filtered_by_kp}")
        print(f"      - 提取后<100过滤: {filtered_by_extraction}")
        print(f"      - 候选对数量: {len(candidate_pairs)}")
        
        if not candidate_pairs:
            print("\n   ❌ 没有找到合适的初始图像对")
            print("   💡 建议:")
            print("      1. 降低最小匹配数阈值: --sfm_pure_visual_min_initial_matches 50")
            print("      2. 检查匹配质量和数量")
            print("      3. 尝试使用SO-RCG方法: --sfm_use_sorc")
            return None
        
        # 按评分排序
        candidate_pairs.sort(key=lambda x: x[2], reverse=True)
        
        # 显示前5个候选
        print("\n   📊 候选图像对（前5名）:")
        for i, (img1, img2, score, num_matches) in enumerate(candidate_pairs[:5], 1):
            print(f"      {i}. {img1} ↔ {img2}: {num_matches}个匹配, 评分={score:.1f}")
        
        best_pair = (candidate_pairs[0][0], candidate_pairs[0][1])
        print(f"\n   ✅ 选择初始对: {best_pair[0]} ↔ {best_pair[1]}")
        print("="*70 + "\n")
        
        return best_pair
    
    def register_initial_pair(self, img1_name, img2_name, keypoints_dict, matches_dict):
        """
        注册初始图像对（增量式SfM的第一步）
        
        Args:
            img1_name, img2_name: 图像名称
            keypoints_dict: 关键点字典
            matches_dict: 匹配字典
        
        Returns:
            success: 是否成功注册
        """
        print("\n" + "="*70)
        print(f"📸 注册初始图像对: {img1_name} ↔ {img2_name}")
        print("="*70)
        
        # 1. 提取匹配点
        matches_key = (img1_name, img2_name) if (img1_name, img2_name) in matches_dict else (img2_name, img1_name)
        if matches_key not in matches_dict:
            print(f"   ❌ 未找到匹配: {matches_key}")
            return False
        
        matches = matches_dict[matches_key]
        kp1 = keypoints_dict[img1_name]
        kp2 = keypoints_dict[img2_name]
        
        img1_pts = []
        img2_pts = []
        match_indices = []
        
        for i, m in enumerate(matches):
            if hasattr(m, 'queryIdx'):
                idx1, idx2 = m.queryIdx, m.trainIdx
            elif isinstance(m, (list, tuple)) and len(m) >= 2:
                idx1, idx2 = m[0], m[1]
            else:
                continue
            
            if idx1 < len(kp1) and idx2 < len(kp2):
                pt1 = kp1[idx1].pt if hasattr(kp1[idx1], 'pt') else kp1[idx1]
                pt2 = kp2[idx2].pt if hasattr(kp2[idx2], 'pt') else kp2[idx2]
                img1_pts.append(pt1)
                img2_pts.append(pt2)
                match_indices.append((idx1, idx2))
        
        img1_pts = np.array(img1_pts, dtype=np.float32)
        img2_pts = np.array(img2_pts, dtype=np.float32)
        
        print(f"   📊 匹配点数: {len(img1_pts)}")
        
        # 2. 估计相机内参（使用SAR几何模型的简化版本）
        # 注意：纯视觉方法仍需要K矩阵，这里使用默认参数
        # 在实际应用中，K矩阵可以通过标定获得
        height, width = 512, 512  # 默认图像尺寸，实际应从图像读取
        
        # 简化的K矩阵：假设焦距为图像宽度
        focal_length = width  # 简化假设
        K1 = np.array([
            [focal_length, 0, width / 2.0],
            [0, focal_length, height / 2.0],
            [0, 0, 1]
        ])
        K2 = K1.copy()
        
        # 3. 从基础矩阵估计相对位姿（论文方法）
        R_rel, t_rel, inlier_mask, success = self.estimate_initial_pair_pose(
            img1_pts, img2_pts, K1, K2
        )
        
        if not success:
            print("   ❌ 初始位姿估计失败")
            return False
        
        # 4. 设置第一个相机为世界坐标系原点（论文方法）
        R1 = np.eye(3)
        t1 = np.zeros((3, 1))
        
        # 5. 计算第二个相机的绝对姿态
        R2 = R_rel
        t2 = t_rel
        
        # 6. 三角化初始点云
        points_3d, valid_mask = self.triangulate_initial_points(
            img1_pts, img2_pts, R1, t1, R2, t2, K1, K2, inlier_mask
        )
        
        # 7. 保存相机位姿
        self.camera_poses[img1_name] = {
            'R': R1,
            't': t1,
            'K': K1
        }
        self.camera_poses[img2_name] = {
            'R': R2,
            't': t2,
            'K': K2
        }
        
        self.registered_images.add(img1_name)
        self.registered_images.add(img2_name)
        
        # 8. 保存点云
        valid_points = points_3d[valid_mask]
        self.point_cloud = valid_points
        self.num_initial_points = len(valid_points)
        
        # 9. 构建点跟踪
        global_point_idx = 0
        inlier_indices = np.where(inlier_mask)[0]
        valid_inlier_indices = inlier_indices[valid_mask]
        
        for i, match_idx in enumerate(valid_inlier_indices):
            idx1, idx2 = match_indices[match_idx]
            self.point_tracks[global_point_idx] = [
                (img1_name, idx1),
                (img2_name, idx2)
            ]
            global_point_idx += 1
        
        print(f"\n   ✅ 初始图像对注册成功:")
        print(f"      - 注册图像: {img1_name}, {img2_name}")
        print(f"      - 初始点云: {len(valid_points)} 个3D点")
        print("="*70 + "\n")
        
        return True
    
    def find_next_image_to_register(self, image_names, matches_dict, keypoints_dict):
        """
        找到下一个要注册的图像（增量式SfM）
        
        选择标准：
        1. 与已注册图像有足够多的匹配
        2. 能观测到足够多的已有3D点
        
        Args:
            image_names: 所有图像名称
            matches_dict: 匹配字典
            keypoints_dict: 关键点字典
        
        Returns:
            next_image: 下一个要注册的图像名称，或None
        """
        candidates = []
        
        for img_name in image_names:
            if img_name in self.registered_images:
                continue
            
            # 统计与已注册图像的匹配数
            total_matches = 0
            total_observed_points = 0
            
            for registered_img in self.registered_images:
                # 检查匹配
                match_key1 = (img_name, registered_img)
                match_key2 = (registered_img, img_name)
                
                if match_key1 in matches_dict:
                    total_matches += len(matches_dict[match_key1])
                elif match_key2 in matches_dict:
                    total_matches += len(matches_dict[match_key2])
            
            if total_matches < 50:  # 至少50个匹配
                continue
            
            # 评分：匹配数越多越好
            score = total_matches
            candidates.append((img_name, score, total_matches))
        
        if not candidates:
            return None
        
        # 按评分排序
        candidates.sort(key=lambda x: x[1], reverse=True)
        
        return candidates[0][0]
    
    def register_new_image_pnp(self, img_name, keypoints_dict, matches_dict):
        """
        使用PnP算法注册新图像（增量式SfM）
        
        Args:
            img_name: 要注册的图像名称
            keypoints_dict: 关键点字典
            matches_dict: 匹配字典
        
        Returns:
            success: 是否成功注册
        """
        print(f"\n   🔄 使用PnP注册新图像: {img_name}")
        
        # 1. 收集2D-3D对应关系
        points_2d = []
        points_3d = []
        
        kp_new = keypoints_dict.get(img_name, [])
        if len(kp_new) == 0:
            return False
        
        # 遍历已有3D点
        for point_idx, track in self.point_tracks.items():
            if point_idx >= len(self.point_cloud):
                continue
            
            # 检查这个3D点是否在新图像中被观测到
            for registered_img in self.registered_images:
                # 找到新图像与已注册图像的匹配
                match_key1 = (img_name, registered_img)
                match_key2 = (registered_img, img_name)
                
                matches = None
                swap_indices = False
                if match_key1 in matches_dict:
                    matches = matches_dict[match_key1]
                elif match_key2 in matches_dict:
                    matches = matches_dict[match_key2]
                    swap_indices = True
                
                if matches is None:
                    continue
                
                # 检查track中是否有来自registered_img的观测
                registered_kp_idx = None
                for track_img, track_kp_idx in track:
                    if track_img == registered_img:
                        registered_kp_idx = track_kp_idx
                        break
                
                if registered_kp_idx is None:
                    continue
                
                # 查找匹配
                for m in matches:
                    if hasattr(m, 'queryIdx'):
                        idx_new = m.queryIdx if not swap_indices else m.trainIdx
                        idx_reg = m.trainIdx if not swap_indices else m.queryIdx
                    elif isinstance(m, (list, tuple)) and len(m) >= 2:
                        idx_new = m[0] if not swap_indices else m[1]
                        idx_reg = m[1] if not swap_indices else m[0]
                    else:
                        continue
                    
                    if idx_reg == registered_kp_idx and idx_new < len(kp_new):
                        # 找到对应关系
                        pt_2d = kp_new[idx_new].pt if hasattr(kp_new[idx_new], 'pt') else kp_new[idx_new]
                        pt_3d = self.point_cloud[point_idx]
                        points_2d.append(pt_2d)
                        points_3d.append(pt_3d)
                        break
        
        if len(points_2d) < self.min_pnp_points:  # 最小2D-3D对应数（从opts读取）
            print(f"      ❌ 2D-3D对应不足: {len(points_2d)} < {self.min_pnp_points}")
            return False
        
        points_2d = np.array(points_2d, dtype=np.float32)
        points_3d = np.array(points_3d, dtype=np.float32)
        
        print(f"      📊 2D-3D对应数: {len(points_2d)}")
        
        # 2. 使用简化的K矩阵（与初始对一致）
        height, width = 512, 512
        focal_length = width
        K = np.array([
            [focal_length, 0, width / 2.0],
            [0, focal_length, height / 2.0],
            [0, 0, 1]
        ])
        dist_coeffs = np.zeros(4)
        
        # 3. PnP求解（论文方法）
        try:
            success, rvec, tvec, inliers = cv2.solvePnPRansac(
                points_3d, points_2d, K, dist_coeffs,
                reprojectionError=4.0,
                confidence=0.99,
                iterationsCount=1000
            )
            
            if not success or inliers is None or len(inliers) < self.min_pnp_points:
                print(f"      ❌ PnP失败")
                return False
            
            # 转换旋转向量为旋转矩阵
            R, _ = cv2.Rodrigues(rvec)
            t = tvec
            
            num_inliers = len(inliers)
            inlier_ratio = num_inliers / len(points_2d)
            print(f"      ✅ PnP成功: {num_inliers}/{len(points_2d)} 内点 ({inlier_ratio*100:.1f}%)")
            
            # 4. 保存相机位姿
            self.camera_poses[img_name] = {
                'R': R,
                't': t,
                'K': K
            }
            self.registered_images.add(img_name)
            
            return True
            
        except Exception as e:
            print(f"      ❌ PnP失败: {e}")
            return False
    
    def run_incremental_sfm(self, image_names, keypoints_dict, matches_dict):
        """
        运行增量式SfM重建（论文方法）
        
        Args:
            image_names: 图像名称列表
            keypoints_dict: 关键点字典
            matches_dict: 匹配字典
        
        Returns:
            success: 是否成功重建
        """
        print("\n" + "="*70)
        print("🚀 开始增量式SAR SfM重建（纯视觉方法）")
        print("="*70 + "\n")
        
        # 1. 选择并注册初始图像对
        initial_pair = self.select_initial_pair(image_names, matches_dict, keypoints_dict)
        if initial_pair is None:
            print("❌ 无法选择初始图像对")
            return False
        
        success = self.register_initial_pair(
            initial_pair[0], initial_pair[1],
            keypoints_dict, matches_dict
        )
        
        if not success:
            print("❌ 初始图像对注册失败")
            return False
        
        # 2. 增量式添加新图像
        max_images_to_register = len(image_names) - 2
        registered_count = 0
        
        print("\n" + "="*70)
        print("🔄 增量式添加新图像...")
        print("="*70)
        
        while registered_count < max_images_to_register:
            # 找到下一个要注册的图像
            next_img = self.find_next_image_to_register(
                image_names, matches_dict, keypoints_dict
            )
            
            if next_img is None:
                print("\n   ⚠️ 没有更多可注册的图像")
                break
            
            # 使用PnP注册
            success = self.register_new_image_pnp(next_img, keypoints_dict, matches_dict)
            
            if success:
                registered_count += 1
                print(f"   ✅ 已注册: {registered_count}/{max_images_to_register}")
            else:
                print(f"   ⚠️ 注册失败: {next_img}")
        
        # 3. 总结
        print("\n" + "="*70)
        print("📊 增量式SfM重建完成")
        print("="*70)
        print(f"   注册图像数: {len(self.registered_images)}/{len(image_names)}")
        print(f"   初始点云数: {self.num_initial_points}")
        print("="*70 + "\n")
        
        return len(self.registered_images) >= 2
    
    def get_results(self):
        """
        获取重建结果
        
        Returns:
            camera_poses: 相机位姿字典
            point_cloud: 3D点云
            point_colors: 点云颜色
        """
        return self.camera_poses, self.point_cloud, self.point_colors

