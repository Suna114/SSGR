# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

import os
import numpy as np
import cv2
import random
import math
import pickle
from sar_utils import parse_mstar_filename
from sfm_utils import SerializeMatches
import logging
import traceback

# 添加 PyTorch 导入保护
import torch
import torch.nn.functional as F
TORCH_AVAILABLE = True

# ==================== SAR-SIFT匹配函数 ====================
def deep_match(kp1_location, kp2_location, deep_des1, deep_des2, ratio):
    """深度匹配方法 - 修复一对多匹配问题，确保每个目标点只被一个源点匹配"""
    # 第一阶段：收集所有候选匹配
    candidates = []  # [(i, j, distance), ...]
    
    for i in range(deep_des1.shape[0]):
        # 计算所有描述符的距离
        distances = np.sqrt(np.sum((deep_des2 - deep_des1[i]) ** 2, axis=1))

        # 找到最近的两个距离
        sorted_indices = np.argsort(distances)
        min_dist = distances[sorted_indices[0]]
        second_min_dist = distances[sorted_indices[1]]

        # 改进匹配条件：进一步放宽阈值以增加匹配点数量
        if (min_dist < second_min_dist * ratio and
            min_dist < 1.5 and  # 进一步放宽最大距离阈值：从1.2增加到1.5
            min_dist > 0.02):   # 进一步放宽最小距离阈值：从0.03降到0.02
            candidates.append((i, sorted_indices[0], min_dist))
    
    # 第二阶段：解决一对多匹配问题 - 确保每个目标点j只被一个源点i匹配
    # 如果有多个源点匹配到同一个目标点，选择距离最小的那个
    target_to_source = {}  # {j: (i, distance)} - 记录每个目标点对应的最佳源点和距离
    
    for i, j, dist in candidates:
        if j not in target_to_source:
            # 目标点j还没有被匹配，直接添加
            target_to_source[j] = (i, dist)
        else:
            # 目标点j已经被匹配，比较距离，保留距离更小的
            existing_i, existing_dist = target_to_source[j]
            if dist < existing_dist:
                target_to_source[j] = (i, dist)
    
    # 构建最终的匹配结果
    deep_kp1 = []
    deep_kp2 = []
    for j, (i, dist) in target_to_source.items():
        deep_kp1.append((kp1_location[i][0], kp1_location[i][1]))
        deep_kp2.append((kp2_location[j][0], kp2_location[j][1]))

    print(f"    深度匹配结果: {len(deep_kp1)} 个匹配点 (已确保一对一匹配)")
    return deep_kp1, deep_kp2

def ransac_matching(kp1, kp2, error_threshold=12.0, iterations=15000):
    """RANSAC匹配算法 - 增强稳定性版本，使用自适应阈值
    
    针对SAR图像优化：使用更宽松的阈值以保留更多匹配点
    默认参数与 config.py 中的 ransac_error_threshold 和 ransac_iterations 一致
    """
    n = 3  # affine transform
    kp_num = len(kp1)

    # 如果匹配点太少，直接返回
    if kp_num < 3:
        print(f"    匹配点过少 ({kp_num})，跳过RANSAC")
        return kp1, kp2

    # 自适应误差阈值：根据图像尺寸和匹配点分布调整
    # 计算匹配点的空间分布范围
    kp1_array = np.array(kp1)
    kp2_array = np.array(kp2)
    
    # 计算图像尺寸的估计（使用匹配点的范围）
    img_width = max(np.max(kp1_array[:, 0]), np.max(kp2_array[:, 0])) - min(np.min(kp1_array[:, 0]), np.min(kp2_array[:, 0]))
    img_height = max(np.max(kp1_array[:, 1]), np.max(kp2_array[:, 1])) - min(np.min(kp1_array[:, 1]), np.min(kp2_array[:, 1]))
    img_size = max(img_width, img_height)
    
    # SAR图像优化：使用更宽松的自适应阈值
    # 基于图像尺寸的3%作为基准（SAR图像特征定位不如光学图像精确）
    adaptive_threshold = max(error_threshold, img_size * 0.03, 5.0)
    # 上限为图像尺寸的5%
    adaptive_threshold = min(adaptive_threshold, img_size * 0.05, 10.0)
    
    # list to matrix
    kp1_matrix = np.zeros((3, kp_num), dtype="f")
    kp2_matrix = np.zeros((3, kp_num), dtype="f")
    for m in range(kp_num):
        kp1_matrix[0][m] = kp1[m][0]
        kp1_matrix[1][m] = kp1[m][1]
        kp1_matrix[2][m] = 1
        kp2_matrix[0][m] = kp2[m][0]
        kp2_matrix[1][m] = kp2[m][1]
        kp2_matrix[2][m] = 1

    most_consensus_number = 0
    better_kp1 = []
    better_kp2 = []
    best_transform = None

    # 如果匹配点较少，减少迭代次数
    if kp_num < 20:
        iterations = min(iterations, 2000)
    elif kp_num < 50:
        iterations = min(iterations, 4000)

    for i in range(iterations):
        kp1_rand = np.zeros((n, 2), dtype="f")
        kp2_rand = np.zeros((n, 2), dtype="f")

        # 随机选择不重复的点
        selected_indices = set()
        while len(selected_indices) < n:
            rand = random.randint(0, kp_num - 1)
            selected_indices.add(rand)

        selected_indices = list(selected_indices)
        for j, idx in enumerate(selected_indices):
            kp1_rand[j, 0] = kp1[idx][0]
            kp1_rand[j, 1] = kp1[idx][1]
            kp2_rand[j, 0] = kp2[idx][0]
            kp2_rand[j, 1] = kp2[idx][1]

        # 使用3个关键点计算变换矩阵
        try:
            M = cv2.getAffineTransform(kp1_rand, kp2_rand)
            if M is None:
                continue

            M_stack = np.vstack((M, [0, 0, 1]))  # 变换矩阵[a,b,c;d,e,f;0,0,1]

            # 用矩阵变换所有kp1
            kp1_transform = np.dot(M_stack, kp1_matrix)
            error = kp2_matrix - kp1_transform
            error = error[0:2].transpose()

            # 计算均方根误差
            mean_square = np.sqrt(np.sum(np.square(error), axis=1) / 2.)
            # 使用自适应阈值
            index = np.where(mean_square < adaptive_threshold)
            consensus_num = index[0].shape[0]

            # 更新参数和最小均方误差
            if consensus_num > most_consensus_number:
                better_kp1 = []
                better_kp2 = []
                most_consensus_number = consensus_num
                best_transform = M_stack

                for order in range(consensus_num):
                    idx = index[0][order]
                    better_kp1.append(kp1[idx])
                    better_kp2.append(kp2[idx])

                # 如果找到足够多的内点，可以提前结束
                if consensus_num > kp_num * 0.8:
                    break

        except Exception as e:
            # 忽略单次迭代的错误，继续下一次
            continue

    # 后处理，检查匹配质量（放宽条件，保留更多匹配点）
    # SAR图像优化：降低最小内点比例要求（从30%降到15%）
    min_inlier_ratio = 0.15
    if len(better_kp1) > 0:
        inlier_ratio = len(better_kp1) / kp_num if kp_num > 0 else 0
        if inlier_ratio < min_inlier_ratio:
            print(f"    RANSAC内点比例过低 ({inlier_ratio:.2%} < {min_inlier_ratio:.2%})，使用原始匹配点（{kp_num}个）")
            better_kp1, better_kp2 = kp1, kp2
        else:
            # 使用更宽松的后处理，保留更多匹配点
            better_kp1, better_kp2 = post_process_matches(better_kp1, better_kp2, best_transform)
    else:
        # 如果RANSAC没有找到任何内点，使用原始匹配点
        if kp_num >= 2:  # 降低最小匹配点数要求
            print(f"    RANSAC未找到内点，使用原始匹配点（{kp_num}个）")
            better_kp1, better_kp2 = kp1, kp2
        else:
            better_kp1, better_kp2 = [], []

    print(f"    RANSAC结果: {len(better_kp1)}/{kp_num} 个内点 (自适应阈值: {adaptive_threshold:.2f})")
    return better_kp1, better_kp2


def post_process_matches(kp1, kp2, transform):
    """后处理匹配点，提高几何一致性 - 优化版本，保留更多匹配点"""
    if len(kp1) < 2:  # 进一步降低最小匹配点数要求：从3降到2
        return kp1, kp2

    # 计算匹配点的空间分布
    kp1_array = np.array(kp1)
    kp2_array = np.array(kp2)

    # 计算中心点
    center1 = np.mean(kp1_array, axis=0)
    center2 = np.mean(kp2_array, axis=0)

    # 计算到中心的距离
    distances1 = np.linalg.norm(kp1_array - center1, axis=1)
    distances2 = np.linalg.norm(kp2_array - center2, axis=1)

    # 进一步放宽过滤条件：使用更大的标准差倍数（从3倍增加到4倍），保留更多匹配点
    max_distance = np.mean(distances1) + 4 * np.std(distances1)

    filtered_kp1 = []
    filtered_kp2 = []

    for i in range(len(kp1)):
        # 进一步放宽条件：只要有一个方向满足条件就保留
        if distances1[i] <= max_distance or distances2[i] <= max_distance:
            filtered_kp1.append(kp1[i])
            filtered_kp2.append(kp2[i])

    # 如果过滤后匹配点太少，返回原始匹配点（阈值从50%降到40%）
    if len(filtered_kp1) < len(kp1) * 0.4:  # 如果过滤掉了超过60%的点，保留原始匹配
        print(f"    空间过滤过于严格，保留原始匹配点（{len(kp1)}个）")
        return kp1, kp2

    print(f"    空间过滤: {len(kp1)} -> {len(filtered_kp1)} 个匹配点")
    return filtered_kp1, filtered_kp2

# ==================== 主匹配函数 ====================
def select_promising_pairs(image_paths, max_pairs_per_image=None, max_azimuth_diff=None, args=None):
    """
    改为全局匹配 - 返回所有可能的图像对
    """
    print(f"🔍 使用全局匹配策略...")

    # 如果max_pairs_per_image为0或None，则进行全局匹配
    if max_pairs_per_image == 0 or max_pairs_per_image is None:
        print("   全局匹配模式: 匹配所有可能的图像对")

        # 生成所有可能的图像对
        image_names = [os.path.basename(img_path) for img_path in image_paths]
        promising_pairs = set()

        for i in range(len(image_names)):
            for j in range(i + 1, len(image_names)):
                pair = tuple(sorted([image_names[i], image_names[j]]))
                promising_pairs.add(pair)

        promising_pairs = list(promising_pairs)
        total_possible_pairs = len(promising_pairs)

        print(f"✅ 全局匹配选择完成:")
        print(f"   总图像数: {len(image_names)}")
        print(f"   总匹配对数: {total_possible_pairs}")

        return promising_pairs

    # 否则使用原来的基于方位角的选择逻辑（保持原有代码不变）
    print(f"   基于方位角选择: 每张图像最多匹配 {max_pairs_per_image} 个相邻图像")
    print(f"   最大方位角差异: {max_azimuth_diff}°")

    # 解析所有图像的方位角
    image_angles = {}
    for img_path in image_paths:
        img_name = os.path.basename(img_path)
        _, azimuth_angle = parse_mstar_filename(img_name)
        image_angles[img_name] = azimuth_angle

    # 获取所有角度并排序
    all_angles = sorted(image_angles.values())
    print(f"   图像方位角范围: {min(all_angles)}° - {max(all_angles)}°")

    promising_pairs = set()

    # 为每张图像选择角度相近的图像进行匹配
    for img_name, current_angle in image_angles.items():
        candidate_images = []
        for candidate_name, candidate_angle in image_angles.items():
            if candidate_name == img_name:
                continue

            # 改进的角度差计算，正确处理循环角度
            raw_diff = abs(candidate_angle - current_angle)
            angle_diff = min(raw_diff, 360 - raw_diff)

            # 特别处理跨越360°边界的情况
            # 例如：340°与10°的差应该是30°，而不是330°
            if raw_diff > 180:
                angle_diff = 360 - raw_diff

            if angle_diff <= max_azimuth_diff:
                # 给更小的角度差异更高的优先级
                priority_score = 1.0 / (angle_diff + 1.0)  # 避免除零
                candidate_images.append((candidate_name, angle_diff, priority_score))

        # 按优先级排序
        candidate_images.sort(key=lambda x: x[2], reverse=True)
        selected_candidates = candidate_images[:max_pairs_per_image]

        for candidate_img, angle_diff, priority_score in selected_candidates:
            pair = tuple(sorted([img_name, candidate_img]))
            promising_pairs.add(pair)

            # 输出调试信息，显示特殊角度对的匹配
            if angle_diff <= max_azimuth_diff and (raw_diff > 180 or angle_diff < raw_diff):
                print(f"     特殊角度对: {img_name}({current_angle}°) - {candidate_img}({candidate_angle}°) "
                      f"-> 角度差: {angle_diff}° (原始差: {raw_diff}°)")

    promising_pairs = list(promising_pairs)
    total_possible_pairs = len(image_paths) * (len(image_paths) - 1) // 2
    reduction_ratio = (total_possible_pairs - len(promising_pairs)) / total_possible_pairs * 100

    print(f"✅ 图像对选择完成:")
    print(f"   总图像数: {len(image_paths)}")
    print(f"   可能的总匹配对数: {total_possible_pairs}")
    print(f"   选定的匹配对数: {len(promising_pairs)}")
    print(f"   匹配对数减少: {reduction_ratio:.1f}%")

    # 输出一些特殊角度对的例子
    special_pairs = []
    for img1, img2 in promising_pairs:
        angle1 = image_angles[img1]
        angle2 = image_angles[img2]
        raw_diff = abs(angle1 - angle2)
        if raw_diff > 180:
            angle_diff = 360 - raw_diff
            if angle_diff <= max_azimuth_diff:
                special_pairs.append((img1, img2, angle1, angle2, angle_diff))

    if special_pairs:
        print(f"   找到 {len(special_pairs)} 个跨越360°边界的特殊角度对")
        for i, (img1, img2, a1, a2, diff) in enumerate(special_pairs[:5]):  # 只显示前5个
            print(f"     示例 {i + 1}: {img1}({a1}°) - {img2}({a2}°) -> 角度差: {diff}°")

    return promising_pairs


def apply_sar_geometric_constraints(matches_dict, image_angles, max_azimuth_diff, min_depression_diff=0):
    """
    应用SAR几何约束过滤匹配对 - 在全局匹配模式下放宽约束
    """
    print("应用SAR几何约束过滤匹配对...")

    # 检查是否为全局匹配模式（max_azimuth_diff为0或很大）
    if max_azimuth_diff == 0 or max_azimuth_diff >= 180:
        print("   全局匹配模式: 禁用几何约束")
        return matches_dict  # 直接返回所有匹配，不进行过滤

    filtered_matches = {}
    for (img1, img2), matches in matches_dict.items():
        if img1 not in image_angles or img2 not in image_angles:
            continue

        dep1, azi1 = image_angles[img1]
        dep2, azi2 = image_angles[img2]

        # 改进的角度差计算，正确处理循环角度
        raw_diff = abs(azi1 - azi2)
        azimuth_diff = min(raw_diff, 360 - raw_diff)
        if raw_diff > 180:
            azimuth_diff = 360 - raw_diff

        depression_diff = abs(dep1 - dep2)

        # 放宽的几何约束条件
        if (azimuth_diff <= max_azimuth_diff and
                min_depression_diff <= depression_diff <= 45):  # 保持原有的俯角约束

            if len(matches) >= 3:  # 保持最小匹配点数要求
                filtered_matches[(img1, img2)] = matches
                special_note = " (跨越边界)" if raw_diff > 180 else ""
                print(
                    f"  保留 {img1}-{img2}: 方位角差{azimuth_diff}°{special_note}, 俯角差{depression_diff}°, 匹配点{len(matches)}")
            else:
                print(f"  丢弃 {img1}-{img2}: 匹配点不足 ({len(matches)})")
        else:
            print(f"  丢弃 {img1}-{img2}: 几何约束不满足 (方位角差{azimuth_diff}°, 俯角差{depression_diff}°)")

    print(f"几何约束过滤: {len(matches_dict)} -> {len(filtered_matches)} 对匹配")
    return filtered_matches


def match_selected_pairs_sar_sift(keypoints, descriptors, original_keypoints, image_paths, selected_pairs, args=None):
    """
    使用完整SAR-SIFT算法对选定的图像对进行匹配 - 修复匹配图保存问题，保存正向、反向和双向匹配图
    """
    print(f"🎯 对选定的 {len(selected_pairs)} 个图像对进行SAR-SIFT特征匹配...")

    # 创建匹配图保存目录
    matches_dir = os.path.join(args.source_path, "feature_matches")
    if args.save_match_images:
        os.makedirs(matches_dir, exist_ok=True)
        print(f"📸 特征匹配图将保存到: {matches_dir}")

    img_path_map = {}
    for img_path in image_paths:
        img_name = os.path.basename(img_path)
        img_path_map[img_name] = img_path

    matches_dict = {}
    saved_pairs = 0

    # GPU设置
    force_cpu = getattr(args, 'force_cpu', getattr(args, 'use_cpu', False))
    use_gpu = torch.cuda.is_available() and not force_cpu
    gpu_device = torch.device('cuda') if use_gpu else torch.device('cpu')

    if use_gpu:
        print(f"🎮 使用GPU加速: {torch.cuda.get_device_name(0)}")
    else:
        print("🔧 使用CPU进行匹配")

    # 预处理所有描述符到GPU
    gpu_descriptors = {}
    if use_gpu:
        print("🚀 预处理描述符到GPU...")
        for img_name, desc in descriptors.items():
            if desc is not None and len(desc) > 0:
                try:
                    gpu_descriptors[img_name] = torch.from_numpy(desc).to(gpu_device)
                except Exception as e:
                    print(f"⚠️ 加载 {img_name} 描述符到GPU失败: {e}")
        print(f"   ✅ 已将 {len(gpu_descriptors)} 个描述符加载到GPU")

    # ========== 修复：为每个图像对独立处理 ==========
    for pair_idx, (img1_name, img2_name) in enumerate(selected_pairs):
        current_matching_method = "unknown"  # 为当前图像对初始化匹配方法

        print(f"\n🔍 处理图像对 {pair_idx + 1}/{len(selected_pairs)}: {img1_name} - {img2_name}")

        try:
            if img1_name not in descriptors or img2_name not in descriptors:
                print(f"   ❌ 跳过: 缺少描述符")
                continue

            # 获取描述符
            if use_gpu and img1_name in gpu_descriptors and img2_name in gpu_descriptors:
                desc1 = gpu_descriptors[img1_name]
                desc2 = gpu_descriptors[img2_name]
                desc1_np = desc1.cpu().numpy()
                desc2_np = desc2.cpu().numpy()
            else:
                desc1_np = descriptors[img1_name]
                desc2_np = descriptors[img2_name]

            # 获取关键点位置
            kp1_locations = np.array([[kp.pt[0], kp.pt[1]] for kp in original_keypoints[img1_name]])
            kp2_locations = np.array([[kp.pt[0], kp.pt[1]] for kp in original_keypoints[img2_name]])

            # ========== 修复：确保使用正确的匹配方法 ==========
            use_bidirectional = getattr(args, 'use_bidirectional_matching', True)
            matching_method = getattr(args, 'matching_method', 'bidirectional')

            if use_bidirectional:
                if matching_method == 'symmetry':
                    good_kp1, good_kp2 = symmetry_test_matching(
                        kp1_locations, kp2_locations, desc1_np, desc2_np,
                        args.max_ratio, use_gpu, gpu_device
                    )
                    current_matching_method = 'symmetry'
                    forward_kp1, forward_kp2, reverse_kp1, reverse_kp2 = [], [], [], []
                else:  # 默认使用双向匹配
                    good_kp1, good_kp2, forward_kp1, forward_kp2, reverse_kp1, reverse_kp2 = bidirectional_match(
                        kp1_locations, kp2_locations, desc1_np, desc2_np,
                        args.max_ratio, use_gpu, gpu_device
                    )
                    current_matching_method = 'bidirectional'
            else:
                # 传统单向匹配
                good_kp1, good_kp2 = deep_match_gpu_optimized(
                    kp1_locations, kp2_locations, desc1_np, desc2_np,
                    args.max_ratio, use_gpu, gpu_device
                )
                current_matching_method = 'unidirectional'
                forward_kp1, forward_kp2, reverse_kp1, reverse_kp2 = good_kp1, good_kp2, [], []

            print(f"  初始匹配: {len(good_kp1)} 个点 (方法: {current_matching_method})")

            # 匹配质量预评估 - 放宽最小匹配点数要求
            min_matches_required = getattr(args, 'min_matches_required', 2)
            if len(good_kp1) < min_matches_required:
                print(f"  跳过: 初始匹配点过少 ({len(good_kp1)} < {min_matches_required})")
                continue

            # 使用RANSAC进一步优化匹配
            print(f"  应用RANSAC过滤...")
            better_kp1, better_kp2 = ransac_matching(good_kp1, good_kp2,
                                                     args.ransac_error_threshold,
                                                     args.ransac_iterations)

            print(f"  RANSAC后: {len(better_kp1)} 个点")

            # 宽松匹配模式：如果RANSAC失败或结果太少，使用原始匹配
            use_relaxed = getattr(args, 'use_relaxed_matching', True)
            if use_relaxed and len(better_kp1) < min_matches_required:
                # RANSAC过滤掉了太多点，使用原始匹配
                if len(good_kp1) >= min_matches_required:
                    print(f"  ⚠️ RANSAC过滤后匹配点过少，使用原始匹配点 ({len(good_kp1)} 个)")
                    better_kp1, better_kp2 = good_kp1, good_kp2

            # 匹配质量后评估
            if len(better_kp1) > 0:
                match_quality = evaluate_match_quality(better_kp1, better_kp2)

                # 宽松模式：即使质量评估不通过，如果匹配点数量足够，也保留
                if not match_quality['is_valid']:
                    if use_relaxed and len(better_kp1) >= min_matches_required:
                        print(f"  ⚠️ 匹配质量评估未通过，但匹配点数量足够 ({len(better_kp1)} >= {min_matches_required})，保留匹配")
                    else:
                        print(f"  跳过: 匹配质量差 - {match_quality['reason']}")
                        continue

                # 转换为COLMAP格式: [idx1, idx2] 对
                match_pairs = find_match_indices(kp1_locations, kp2_locations, better_kp1, better_kp2)

                if len(match_pairs) > 0:
                    pair_key = (img1_name, img2_name)
                    matches_dict[pair_key] = np.array(match_pairs, dtype=np.uint32)

                    print(f"  ✅ 最终匹配: {len(match_pairs)} 个点 (质量分数: {match_quality['score']:.3f})")

                    # ========== 修复：保存匹配可视化图像 ==========
                    if args.save_match_images and saved_pairs < args.max_match_pairs:
                        img1_path = img_path_map[img1_name]
                        img2_path = img_path_map[img2_name]
                        kp1 = original_keypoints[img1_name]
                        kp2 = original_keypoints[img2_name]

                        # 创建OpenCV格式的匹配对象
                        opencv_matches = []
                        for match_pair in match_pairs[:100]:  # 限制显示前100个匹配
                            match_obj = cv2.DMatch()
                            match_obj.queryIdx = int(match_pair[0])
                            match_obj.trainIdx = int(match_pair[1])
                            match_obj.distance = 0.0  # 设置默认距离
                            opencv_matches.append(match_obj)

                        # 调用可视化函数 - 使用正确的匹配方法
                        output_path = visualize_and_save_matches(
                            img1_path, img2_path, kp1, kp2, opencv_matches,
                            matches_dir, saved_pairs, current_matching_method
                        )

                        if output_path and os.path.exists(output_path):
                            print(f"  📸 保存双向匹配图: {os.path.basename(output_path)}")

                            # 保存正向匹配图
                            if len(forward_kp1) > 0:
                                forward_match_pairs = find_match_indices(kp1_locations, kp2_locations, forward_kp1,
                                                                         forward_kp2)
                                forward_opencv_matches = []
                                for match_pair in forward_match_pairs[:100]:
                                    match_obj = cv2.DMatch()
                                    match_obj.queryIdx = int(match_pair[0])
                                    match_obj.trainIdx = int(match_pair[1])
                                    match_obj.distance = 0.0
                                    forward_opencv_matches.append(match_obj)

                                forward_output_path = visualize_and_save_matches(
                                    img1_path, img2_path, kp1, kp2, forward_opencv_matches,
                                    matches_dir, saved_pairs, "forward"
                                )
                                if forward_output_path:
                                    print(f"  📸 保存正向匹配图: {os.path.basename(forward_output_path)}")

                            # 保存反向匹配图
                            if len(reverse_kp1) > 0:
                                reverse_match_pairs = find_match_indices(kp1_locations, kp2_locations, reverse_kp1,
                                                                         reverse_kp2)
                                reverse_opencv_matches = []
                                for match_pair in reverse_match_pairs[:100]:
                                    match_obj = cv2.DMatch()
                                    match_obj.queryIdx = int(match_pair[0])
                                    match_obj.trainIdx = int(match_pair[1])
                                    match_obj.distance = 0.0
                                    reverse_opencv_matches.append(match_obj)

                                reverse_output_path = visualize_and_save_matches(
                                    img1_path, img2_path, kp1, kp2, reverse_opencv_matches,
                                    matches_dir, saved_pairs, "reverse"
                                )
                                if reverse_output_path:
                                    print(f"  📸 保存反向匹配图: {os.path.basename(reverse_output_path)}")

                            saved_pairs += 1
                        else:
                            print(f"  ❌ 保存匹配图失败")
                else:
                    print(f"  ⚠️ RANSAC后无有效匹配索引")
            else:
                print(f"  ❌ RANSAC后无匹配点")

        except Exception as e:
            error_msg = f"匹配 {img1_name} - {img2_name} 时出错: {e}"
            logging.error(error_msg)
            logging.error(traceback.format_exc())
            print(f"  💥 {error_msg}")
            continue

    print(f"\n🎯 匹配完成: 总共找到 {len(matches_dict)} 对有效图像匹配")
    print(f"📸 匹配图保存: 共保存 {saved_pairs} 组匹配图像（每组包含双向、正向、反向匹配图）")

    # ========== 新增：保存匹配为pickle格式（用于sfm.py） ==========
    if args and hasattr(args, 'save_matches_for_sfm') and args.save_matches_for_sfm:
        try:
            save_matches_to_pickle_format(matches_dict, original_keypoints, args)
        except Exception as e:
            print(f"⚠️ 保存匹配为pickle格式时出错: {e}")

    # 清理GPU内存
    if use_gpu:
        del gpu_descriptors
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            print("🧹 已清理GPU内存")

    return matches_dict

def evaluate_match_quality(kp1_list, kp2_list):
    """评估匹配质量 - 优化版本，放宽阈值以保留更多匹配点"""
    if len(kp1_list) < 3:  # 最小匹配点数为3
        return {'is_valid': False, 'score': 0.0, 'reason': '匹配点过少'}

    kp1_array = np.array(kp1_list)
    kp2_array = np.array(kp2_list)

    # 计算空间分布一致性
    kp1_center = np.mean(kp1_array, axis=0)
    kp2_center = np.mean(kp2_array, axis=0)

    kp1_std = np.std(kp1_array, axis=0)
    kp2_std = np.std(kp2_array, axis=0)

    # 计算图像尺寸估计（用于归一化）
    img_width = max(np.max(kp1_array[:, 0]), np.max(kp2_array[:, 0])) - min(np.min(kp1_array[:, 0]), np.min(kp2_array[:, 0]))
    img_height = max(np.max(kp1_array[:, 1]), np.max(kp2_array[:, 1])) - min(np.min(kp1_array[:, 1]), np.min(kp2_array[:, 1]))
    img_size = max(img_width, img_height, 1.0)  # 避免除零

    # 空间分布分数（基于归一化的标准差，放宽条件）
    normalized_std = np.mean(kp1_std + kp2_std) / img_size
    spatial_score = 1.0 / (1.0 + normalized_std * 5.0)  # 放宽系数从10.0降到5.0

    # 匹配数量分数（更宽松的评分）
    count_score = min(1.0, len(kp1_list) / 10.0)  # 分母从15降到10，更容易达到高分

    # 几何一致性检查（计算匹配点之间的相对位置一致性）
    # 计算匹配点对的相对位移
    displacements = kp2_array - kp1_array
    displacement_std = np.std(displacements, axis=0)
    displacement_mean = np.mean(np.abs(displacements), axis=0)
    
    # 如果位移标准差相对于平均位移较小，说明几何一致性较好
    if np.sum(displacement_mean) > 0:
        geometric_consistency = 1.0 / (1.0 + np.mean(displacement_std) / (np.mean(displacement_mean) + 1.0))
    else:
        geometric_consistency = 0.5  # 默认中等分数

    # 综合分数（更注重数量和几何一致性，放宽空间分布要求）
    total_score = 0.15 * spatial_score + 0.6 * count_score + 0.25 * geometric_consistency

    # 进一步放宽验证条件：降低阈值，允许更多匹配通过
    # 如果匹配点数量足够多，即使分数较低也认为有效
    min_score_threshold = 0.1 if len(kp1_list) >= 5 else 0.12
    is_valid = (total_score > min_score_threshold and len(kp1_list) >= 2) or len(kp1_list) >= 10  # 至少2个点，或10个以上自动通过

    return {
        'is_valid': is_valid,
        'score': total_score,
        'reason': f'空间分布: {spatial_score:.3f}, 数量: {count_score:.3f}, 几何一致性: {geometric_consistency:.3f}'
    }

def match_features_sar_sift(keypoints, descriptors, original_keypoints, image_paths, args=None):
    """
    完整SAR-SIFT特征匹配流程 - 修复匹配图保存问题
    """
    print("使用完整SAR-SIFT算法进行特征匹配...")

    # 收集图像角度信息
    image_angles = {}
    for img_path in image_paths:
        img_name = os.path.basename(img_path)
        depression_angle, azimuth_angle = parse_mstar_filename(img_name)
        image_angles[img_name] = (depression_angle, azimuth_angle)

    # 选择有希望的图像对
    selected_pairs = select_promising_pairs(image_paths, args=args)

    # 根据GPU可用性选择匹配方法
    force_cpu = getattr(args, 'force_cpu', getattr(args, 'use_cpu', False))
    use_gpu = torch.cuda.is_available() and not force_cpu

    if use_gpu and len(selected_pairs) > 10:
        print("🎮 使用批量GPU加速匹配...")
        device = torch.device('cuda')
        matches_dict = batch_match_pairs_gpu(
            selected_pairs, descriptors, original_keypoints,
            args.max_ratio, device, batch_size=20, args=args  # 添加args参数
        )
    else:
        print("🔧 使用标准匹配流程...")
        matches_dict = match_selected_pairs_sar_sift(
            keypoints, descriptors, original_keypoints, image_paths, selected_pairs, args
        )

    # 应用SAR几何约束
    matches_dict = apply_sar_geometric_constraints(
        matches_dict, image_angles, args.max_azimuth_diff
    )

    # 分析匹配统计
    if matches_dict:
        print(f"✅ GPU加速匹配完成: 找到 {len(matches_dict)} 对有效匹配")
    else:
        print("❌ 没有找到任何匹配对")

    # ========== 新增：保存匹配为pickle格式（用于sfm.py） ==========
    if args and hasattr(args, 'save_matches_for_sfm') and args.save_matches_for_sfm:
        try:
            save_matches_to_pickle_format(matches_dict, original_keypoints, args)
        except Exception as e:
            print(f"⚠️ 保存匹配为pickle格式时出错: {e}")

    return matches_dict
def visualize_and_save_matches(img1_path, img2_path, keypoints1, keypoints2, matches, output_dir, pair_id,
                               matching_method=None):
    """
    可视化并保存特征点匹配图 - 修复版本
    （无双图叠字；左右影像之间保留窄条间隔便于查看）
    """
    # 匹配拼图左右间隔（像素），纯色竖条
    match_visual_gap_px = 24
    try:
        # 读取图像
        img1 = cv2.imread(img1_path)
        img2 = cv2.imread(img2_path)

        if img1 is None:
            print(f"⚠️ 无法读取图像1: {img1_path}")
            return ""
        if img2 is None:
            print(f"⚠️ 无法读取图像2: {img2_path}")
            return ""

        # 确保图像是彩色图像
        if len(img1.shape) == 2:
            img1 = cv2.cvtColor(img1, cv2.COLOR_GRAY2BGR)
        if len(img2.shape) == 2:
            img2 = cv2.cvtColor(img2, cv2.COLOR_GRAY2BGR)

        # 设置最大显示尺寸
        max_display_size = 800

        # 计算缩放比例
        height1, width1 = img1.shape[:2]
        height2, width2 = img2.shape[:2]

        # 确定缩放比例，使较大的边不超过max_display_size
        scale1 = min(1.0, max_display_size / max(height1, width1))
        scale2 = min(1.0, max_display_size / max(height2, width2))

        # 缩放图像
        if scale1 < 1.0:
            new_width1 = int(width1 * scale1)
            new_height1 = int(height1 * scale1)
            img1_resized = cv2.resize(img1, (new_width1, new_height1), interpolation=cv2.INTER_AREA)
        else:
            img1_resized = img1.copy()
            scale1 = 1.0

        if scale2 < 1.0:
            new_width2 = int(width2 * scale2)
            new_height2 = int(height2 * scale2)
            img2_resized = cv2.resize(img2, (new_width2, new_height2), interpolation=cv2.INTER_AREA)
        else:
            img2_resized = img2.copy()
            scale2 = 1.0

        # 调整关键点坐标到缩放后的图像
        kp1_resized = []
        for kp in keypoints1:
            x = kp.pt[0] * scale1
            y = kp.pt[1] * scale1
            # 创建新的关键点
            new_kp = cv2.KeyPoint()
            new_kp.pt = (x, y)
            new_kp.size = kp.size * scale1
            new_kp.angle = kp.angle
            new_kp.response = kp.response
            new_kp.octave = kp.octave
            new_kp.class_id = kp.class_id
            kp1_resized.append(new_kp)

        kp2_resized = []
        for kp in keypoints2:
            x = kp.pt[0] * scale2
            y = kp.pt[1] * scale2
            new_kp = cv2.KeyPoint()
            new_kp.pt = (x, y)
            new_kp.size = kp.size * scale2
            new_kp.angle = kp.angle
            new_kp.response = kp.response
            new_kp.octave = kp.octave
            new_kp.class_id = kp.class_id
            kp2_resized.append(new_kp)

        # 统一高度后在左侧图右缘加入竖条间隔（drawMatches 会把右侧图紧挨第一张图画布拼接）
        rh1, _ = img1_resized.shape[:2]
        rh2, _ = img2_resized.shape[:2]
        match_canvas_h = max(rh1, rh2)
        gap_w = max(0, int(match_visual_gap_px))

        def _pad_bottom_to(img, target_h, val=255):
            h, w = img.shape[:2]
            if h >= target_h:
                return img
            pad = np.full((target_h - h, w, 3), val, dtype=np.uint8)
            return np.vstack([img, pad])

        img1_canvas = _pad_bottom_to(img1_resized, match_canvas_h)
        img2_canvas = _pad_bottom_to(img2_resized, match_canvas_h)
        if gap_w > 0:
            sep = np.full((match_canvas_h, gap_w, 3), 255, dtype=np.uint8)
            img1_canvas = np.hstack([img1_canvas, sep])

        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)

        # 限制匹配数量，避免图像过于拥挤
        max_display_matches = min(50, len(matches))
        if max_display_matches == 0:
            print("⚠️ 没有匹配点可以绘制")
            return ""

        display_matches = matches[:max_display_matches]

        # 绘制匹配结果
        try:
            # 使用NOT_DRAW_SINGLE_POINTS标志，只绘制匹配线
            match_img = cv2.drawMatches(
                img1_canvas, kp1_resized,
                img2_canvas, kp2_resized,
                display_matches,
                None,
                matchColor=(0, 255, 0),  # 绿色匹配线
                singlePointColor=(255, 0, 0),  # 蓝色特征点
                flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
            )
        except Exception as draw_error:
            print(f"⚠️ 绘制匹配图失败: {draw_error}")
            # 尝试使用更简单的绘制方式
            try:
                match_img = cv2.drawMatches(
                    img1_canvas, kp1_resized,
                    img2_canvas, kp2_resized,
                    display_matches,
                    None,
                    flags=2  # 使用默认标志
                )
            except Exception as simple_draw_error:
                print(f"⚠️ 简单绘制也失败: {simple_draw_error}")
                return ""

        # 生成安全的输出文件名
        img1_safe_name = "".join(c for c in os.path.basename(img1_path) if c.isalnum() or c in ('_', '.')).split('.')[0]
        img2_safe_name = "".join(c for c in os.path.basename(img2_path) if c.isalnum() or c in ('_', '.')).split('.')[0]

        # 截断过长的文件名
        img1_safe_name = img1_safe_name[:15]
        img2_safe_name = img2_safe_name[:15]

        if matching_method:
            output_filename = f"matches_{pair_id:04d}_{matching_method}_{img1_safe_name}_vs_{img2_safe_name}.jpg"
        else:
            output_filename = f"matches_{pair_id:04d}_{img1_safe_name}_vs_{img2_safe_name}.jpg"

        output_path = os.path.join(output_dir, output_filename)

        # 保存图像
        try:
            # 使用JPEG格式保存，文件更小
            success = cv2.imwrite(output_path, match_img, [cv2.IMWRITE_JPEG_QUALITY, 90])
            if success:
                print(f"  ✅ 成功保存匹配图: {os.path.basename(output_path)}")
                return output_path
            else:
                print(f"❌ OpenCV保存失败: {output_path}")
                return ""
        except Exception as save_error:
            print(f"❌ 保存图像时出错: {save_error}")
            return ""

    except Exception as e:
        print(f"❌ 可视化匹配时出错: {e}")
        import traceback
        traceback.print_exc()
        return ""
def deep_match_gpu_optimized(kp1_location, kp2_location, deep_des1, deep_des2, ratio, use_gpu=False, device=None):
    """
    GPU加速的深度匹配方法 - 优化版本
    """
    if use_gpu and device and TORCH_AVAILABLE:
        return deep_match_gpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio, device)
    else:
        return deep_match(kp1_location, kp2_location, deep_des1, deep_des2, ratio)


def deep_match_gpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio, device):
    """
    PyTorch GPU加速的深度匹配 - 修复一对多匹配问题
    """
    if len(deep_des1) == 0 or len(deep_des2) == 0:
        return [], []

    # 转换为PyTorch张量并移动到GPU
    des1_tensor = torch.from_numpy(deep_des1).float().to(device)
    des2_tensor = torch.from_numpy(deep_des2).float().to(device)

    # 计算所有描述符之间的距离矩阵
    # 使用矩阵运算优化距离计算
    des1_norm = torch.sum(des1_tensor ** 2, dim=1, keepdim=True)
    des2_norm = torch.sum(des2_tensor ** 2, dim=1, keepdim=True)
    distances = torch.sqrt(des1_norm + des2_norm.T - 2 * torch.mm(des1_tensor, des2_tensor.T))

    # 找到最近的两个距离
    min_distances, min_indices = torch.topk(distances, k=2, dim=1, largest=False)

    # 转换为numpy进行处理（更简单）
    min_dist = min_distances[:, 0].cpu().numpy()
    second_min_dist = min_distances[:, 1].cpu().numpy()
    min_indices = min_indices[:, 0].cpu().numpy()

    # 第一阶段：收集所有候选匹配
    candidates = []  # [(i, j, distance), ...]
    
    for i in range(len(min_dist)):
        if (min_dist[i] < second_min_dist[i] * ratio and
                min_dist[i] < 0.9 and  # 添加最大距离阈值
                min_dist[i] > 0.1):  # 添加最小距离阈值，避免太近的匹配
            candidates.append((i, min_indices[i], min_dist[i]))
    
    # 第二阶段：解决一对多匹配问题 - 确保每个目标点j只被一个源点i匹配
    target_to_source = {}  # {j: (i, distance)}
    
    for i, j, dist in candidates:
        if j not in target_to_source:
            target_to_source[j] = (i, dist)
        else:
            existing_i, existing_dist = target_to_source[j]
            if dist < existing_dist:
                target_to_source[j] = (i, dist)
    
    # 构建最终的匹配结果
    deep_kp1 = []
    deep_kp2 = []
    for j, (i, dist) in target_to_source.items():
        deep_kp1.append((kp1_location[i][0], kp1_location[i][1]))
        deep_kp2.append((kp2_location[j][0], kp2_location[j][1]))

    print(f"    GPU匹配结果: {len(deep_kp1)} 个匹配点 (已确保一对一匹配)")
    return deep_kp1, deep_kp2


def find_match_indices(kp1_locations, kp2_locations, better_kp1, better_kp2):
    """
    优化的匹配索引查找函数 - 修复版本
    """
    if len(better_kp1) == 0:
        return []

    match_pairs = []

    # 创建位置到索引的映射（使用更宽松的容差）
    kp1_dict = {}
    for idx, loc in enumerate(kp1_locations):
        # 使用整数坐标作为键，避免浮点精度问题
        key = (int(round(loc[0])), int(round(loc[1])))
        # 允许一个位置对应多个索引（虽然不常见，但安全起见）
        if key not in kp1_dict:
            kp1_dict[key] = []
        kp1_dict[key].append(idx)

    kp2_dict = {}
    for idx, loc in enumerate(kp2_locations):
        key = (int(round(loc[0])), int(round(loc[1])))
        if key not in kp2_dict:
            kp2_dict[key] = []
        kp2_dict[key].append(idx)

    # 用于检测重复匹配的集合
    used_kp1_indices = set()
    used_kp2_indices = set()

    # 直接匹配：遍历better_kp1和better_kp2
    matched_count = 0
    for kp1, kp2 in zip(better_kp1, better_kp2):
        kp1_key = (int(round(kp1[0])), int(round(kp1[1])))
        kp2_key = (int(round(kp2[0])), int(round(kp2[1])))

        if kp1_key in kp1_dict and kp2_key in kp2_dict:
            # 选择第一个可用的索引
            idx1_candidates = [idx for idx in kp1_dict[kp1_key] if idx not in used_kp1_indices]
            idx2_candidates = [idx for idx in kp2_dict[kp2_key] if idx not in used_kp2_indices]

            if idx1_candidates and idx2_candidates:
                idx1 = idx1_candidates[0]
                idx2 = idx2_candidates[0]

                match_pairs.append([idx1, idx2])
                used_kp1_indices.add(idx1)
                used_kp2_indices.add(idx2)
                matched_count += 1

    print(f"    匹配索引查找: 找到 {matched_count} 个有效匹配对")
    return match_pairs


def batch_match_pairs_gpu(selected_pairs, descriptors, original_keypoints, ratio, device, batch_size=10, args=None):
    """
    批量GPU匹配 - 修复匹配图保存问题
    """
    print(f"🚀 使用批量GPU匹配，批量大小: {batch_size}")

    all_matches = {}

    # 创建匹配图保存目录
    matches_dir = os.path.join(args.source_path, "feature_matches")
    if args.save_match_images:
        os.makedirs(matches_dir, exist_ok=True)
        print(f"📸 特征匹配图将保存到: {matches_dir}")

    # 预处理所有描述符到GPU - 分批处理避免内存溢出
    gpu_descriptors = {}
    processed_count = 0

    print("🚀 分批加载描述符到GPU...")
    for img_name, desc in descriptors.items():
        if desc is not None and len(desc) > 0:
            try:
                # 分批加载，避免一次性占用太多GPU内存
                if processed_count % 50 == 0 and processed_count > 0:
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()

                gpu_descriptors[img_name] = torch.from_numpy(desc).float().to(device)
                processed_count += 1

            except RuntimeError as e:
                if "out of memory" in str(e):
                    print(f"⚠️  GPU内存不足，跳过图像 {img_name} 的描述符")
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                    continue
                else:
                    raise e

    print(f"   ✅ 已将 {len(gpu_descriptors)} 个描述符加载到GPU")

    # 创建图像路径映射
    img_path_map = {}
    for img_path in [os.path.join(args.source_path, "input", img_name) for img_name in descriptors.keys()]:
        img_name = os.path.basename(img_path)
        img_path_map[img_name] = img_path

    saved_pairs = 0

    # 批量处理
    for i in range(0, len(selected_pairs), batch_size):
        batch_pairs = selected_pairs[i:i + batch_size]
        print(f"   处理批次 {i // batch_size + 1}/{(len(selected_pairs) - 1) // batch_size + 1}")

        for img1_name, img2_name in batch_pairs:
            if img1_name not in gpu_descriptors or img2_name not in gpu_descriptors:
                continue

            try:
                desc1 = gpu_descriptors[img1_name]
                desc2 = gpu_descriptors[img2_name]

                kp1_locations = np.array([[kp.pt[0], kp.pt[1]] for kp in original_keypoints[img1_name]])
                kp2_locations = np.array([[kp.pt[0], kp.pt[1]] for kp in original_keypoints[img2_name]])

                # ========== 修复：根据双向匹配设置选择匹配方法 ==========
                use_bidirectional = getattr(args, 'use_bidirectional_matching', False)

                if use_bidirectional:
                    # 使用GPU双向匹配
                    bidirectional_kp1, bidirectional_kp2, forward_kp1, forward_kp2, reverse_kp1, reverse_kp2 = bidirectional_match_gpu(
                        kp1_locations, kp2_locations,
                        descriptors[img1_name], descriptors[img2_name],
                        ratio, device
                    )
                    good_kp1, good_kp2 = bidirectional_kp1, bidirectional_kp2
                else:
                    # 使用单向匹配
                    good_kp1, good_kp2 = deep_match_gpu(
                        kp1_locations, kp2_locations,
                        descriptors[img1_name], descriptors[img2_name],
                        ratio, device
                    )

                if len(good_kp1) > 0:
                    better_kp1, better_kp2 = ransac_matching(
                        good_kp1, good_kp2  # 使用函数默认参数（12.0, 15000）
                    )

                    if len(better_kp1) > 0:
                        match_pairs = find_match_indices(
                            kp1_locations, kp2_locations, better_kp1, better_kp2
                        )

                        if len(match_pairs) > 0:
                            pair_key = (img1_name, img2_name)
                            all_matches[pair_key] = np.array(match_pairs, dtype=np.uint32)

                            print(f"  ✅ {img1_name} - {img2_name}: 最终匹配 {len(match_pairs)} 个点")

                            # ========== 修复：在批量匹配中保存匹配图 ==========
                            if args.save_match_images and saved_pairs < args.max_match_pairs:
                                img1_path = img_path_map[img1_name]
                                img2_path = img_path_map[img2_name]
                                kp1 = original_keypoints[img1_name]
                                kp2 = original_keypoints[img2_name]

                                # 创建OpenCV格式的匹配对象
                                opencv_matches = []
                                for match_pair in match_pairs[:100]:  # 限制显示前100个匹配
                                    match_obj = cv2.DMatch()
                                    match_obj.queryIdx = int(match_pair[0])
                                    match_obj.trainIdx = int(match_pair[1])
                                    match_obj.distance = 0.0  # 设置默认距离
                                    opencv_matches.append(match_obj)

                                # 调用可视化函数
                                matching_method = "bidirectional_gpu" if use_bidirectional else "unidirectional_gpu"
                                output_path = visualize_and_save_matches(
                                    img1_path, img2_path, kp1, kp2, opencv_matches,
                                    matches_dir, saved_pairs, matching_method
                                )

                                if output_path and os.path.exists(output_path):
                                    print(f"  📸 保存匹配图: {os.path.basename(output_path)}")
                                    saved_pairs += 1
                                else:
                                    print(f"  ❌ 保存匹配图失败: {img1_name} vs {img2_name}")

            except Exception as e:
                print(f"   批量匹配 {img1_name}-{img2_name} 时出错: {e}")
                # 清理GPU内存
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                continue

        # 每个批次后清理GPU内存
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    # 最终清理GPU内存
    del gpu_descriptors
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        print("🧹 已清理GPU内存")

    print(f"📸 批量匹配图保存: 共保存 {saved_pairs} 张匹配图像")
    return all_matches

def bidirectional_match(kp1_location, kp2_location, deep_des1, deep_des2, ratio, use_gpu=False, device=None):
    """
    双向匹配（交叉验证） - 返回正向、反向和双向匹配结果
    """
    print("   使用双向匹配...")

    if use_gpu and device and TORCH_AVAILABLE:
        return bidirectional_match_gpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio, device)
    else:
        return bidirectional_match_cpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio)

def bidirectional_match_cpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio):
    """
    CPU版本的双向匹配 - 修复一对多匹配问题，确保每个目标点只被一个源点匹配
    """
    if len(deep_des1) == 0 or len(deep_des2) == 0:
        return [], [], [], []

    # 正向匹配 - 第一阶段：收集所有候选匹配
    forward_candidates = []  # [(i, j, distance), ...]
    
    for i in range(deep_des1.shape[0]):
        distances = np.sqrt(np.sum((deep_des2 - deep_des1[i]) ** 2, axis=1))
        sorted_indices = np.argsort(distances)
        min_dist = distances[sorted_indices[0]]
        second_min_dist = distances[sorted_indices[1]]

        # 放宽距离阈值
        if (min_dist < second_min_dist * ratio and
                min_dist < 0.8 and  # 放宽最大距离阈值
                min_dist > 0.05):  # 放宽最小距离阈值
            forward_candidates.append((i, sorted_indices[0], min_dist, sorted_indices[1]))

    # 第二阶段：解决一对多匹配问题 - 确保每个目标点j只被一个源点i匹配
    # 如果有多个源点匹配到同一个目标点，选择距离最小的那个
    target_to_source = {}  # {j: (i, distance)} - 记录每个目标点对应的最佳源点和距离
    
    for i, j, dist, second_best_idx in forward_candidates:
        if j not in target_to_source:
            # 目标点j还没有被匹配，直接添加
            target_to_source[j] = (i, dist)
        else:
            # 目标点j已经被匹配，比较距离，保留距离更小的
            existing_i, existing_dist = target_to_source[j]
            if dist < existing_dist:
                target_to_source[j] = (i, dist)
    
    # 构建最终的正向匹配字典
    forward_matches = {}
    forward_distances = {}
    for j, (i, dist) in target_to_source.items():
        forward_matches[i] = j
        forward_distances[i] = dist

    # 反向匹配 - 同样处理一对多问题
    reverse_candidates = []
    
    for j in range(deep_des2.shape[0]):
        distances = np.sqrt(np.sum((deep_des1 - deep_des2[j]) ** 2, axis=1))
        sorted_indices = np.argsort(distances)
        min_dist = distances[sorted_indices[0]]
        second_min_dist = distances[sorted_indices[1]]

        if (min_dist < second_min_dist * ratio and
                min_dist < 0.8 and
                min_dist > 0.05):
            reverse_candidates.append((sorted_indices[0], j, min_dist))
    
    # 解决反向匹配的一对多问题
    source_to_target = {}  # {i: (j, distance)}
    
    for i, j, dist in reverse_candidates:
        if i not in source_to_target:
            source_to_target[i] = (j, dist)
        else:
            existing_j, existing_dist = source_to_target[i]
            if dist < existing_dist:
                source_to_target[i] = (j, dist)
    
    # 构建最终的反向匹配字典
    reverse_matches = {}
    reverse_distances = {}
    for i, (j, dist) in source_to_target.items():
        reverse_matches[i] = j
        reverse_distances[i] = dist

    # 生成正向匹配的关键点对
    forward_kp1 = []
    forward_kp2 = []
    for i, j in forward_matches.items():
        forward_kp1.append((kp1_location[i][0], kp1_location[i][1]))
        forward_kp2.append((kp2_location[j][0], kp2_location[j][1]))

    # 生成反向匹配的关键点对
    reverse_kp1 = []
    reverse_kp2 = []
    for i, j in reverse_matches.items():
        reverse_kp1.append((kp1_location[i][0], kp1_location[i][1]))
        reverse_kp2.append((kp2_location[j][0], kp2_location[j][1]))

    # === 严格的双向验证 - 只保留严格对称的匹配 ===
    bidirectional_kp1 = []
    bidirectional_kp2 = []
    match_qualities = []

    for i, j in forward_matches.items():
        # 严格双向验证：源点i匹配到目标点j，且目标点j反向匹配也指向源点i
        if i in reverse_matches and reverse_matches[i] == j:
            quality = 1.0 / (1.0 + (forward_distances[i] + reverse_distances[i]) / 2.0)
            bidirectional_kp1.append((kp1_location[i][0], kp1_location[i][1]))
            bidirectional_kp2.append((kp2_location[j][0], kp2_location[j][1]))
            match_qualities.append(quality)

    print(f"   双向匹配结果: 正向={len(forward_kp1)}, 反向={len(reverse_kp1)}, 双向={len(bidirectional_kp1)} (已确保一对一匹配)")

    return bidirectional_kp1, bidirectional_kp2, forward_kp1, forward_kp2, reverse_kp1, reverse_kp2

def bidirectional_match_gpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio, device):
    """
    GPU版本的双向匹配 - 优化版本，返回正向、反向和双向匹配结果
    """
    if len(deep_des1) == 0 or len(deep_des2) == 0:
        return [], [], [], [], [], []

    # 转换为PyTorch张量
    des1_tensor = torch.from_numpy(deep_des1).float().to(device)
    des2_tensor = torch.from_numpy(deep_des2).float().to(device)

    # 计算距离矩阵 - 使用更高效的矩阵运算
    des1_norm = torch.sum(des1_tensor ** 2, dim=1, keepdim=True)
    des2_norm = torch.sum(des2_tensor ** 2, dim=1, keepdim=True)

    # 使用矩阵乘法计算距离，避免内存溢出
    distances = torch.cdist(des1_tensor, des2_tensor, p=2)  # 更高效的距离计算

    # 正向匹配: 图像1 -> 图像2
    min_distances_forward, min_indices_forward = torch.topk(distances, k=2, dim=1, largest=False)

    # 反向匹配: 图像2 -> 图像1
    min_distances_reverse, min_indices_reverse = torch.topk(distances, k=2, dim=0, largest=False)
    min_distances_reverse = min_distances_reverse.transpose(0, 1)
    min_indices_reverse = min_indices_reverse.transpose(0, 1)

    # 转换为numpy进行处理
    min_dist_forward = min_distances_forward[:, 0].cpu().numpy()
    second_min_dist_forward = min_distances_forward[:, 1].cpu().numpy()
    min_indices_forward = min_indices_forward[:, 0].cpu().numpy()

    min_dist_reverse = min_distances_reverse[:, 0].cpu().numpy()
    second_min_dist_reverse = min_distances_reverse[:, 1].cpu().numpy()
    min_indices_reverse = min_indices_reverse[:, 0].cpu().numpy()

    # 正向匹配筛选 - 第一阶段：收集所有候选匹配
    forward_candidates = []  # [(i, j, distance), ...]
    
    for i in range(len(min_dist_forward)):
        if (min_dist_forward[i] < second_min_dist_forward[i] * ratio and
                min_dist_forward[i] < 1.0 and  # 进一步放宽距离阈值：从0.8增加到1.0
                min_dist_forward[i] > 0.08 and    # 进一步放宽最小距离阈值：从0.1降到0.08
                min_dist_forward[i] / second_min_dist_forward[i] < 0.95):  # 进一步放宽比率：从0.9增加到0.95
            forward_candidates.append((i, min_indices_forward[i], min_dist_forward[i]))
    
    # 第二阶段：解决一对多匹配问题 - 确保每个目标点j只被一个源点i匹配
    target_to_source = {}  # {j: (i, distance)}
    
    for i, j, dist in forward_candidates:
        if j not in target_to_source:
            target_to_source[j] = (i, dist)
        else:
            existing_i, existing_dist = target_to_source[j]
            if dist < existing_dist:
                target_to_source[j] = (i, dist)
    
    # 构建最终的正向匹配字典
    forward_matches = {}
    forward_qualities = {}
    for j, (i, dist) in target_to_source.items():
        forward_matches[i] = j
        forward_qualities[i] = 1.0 / (1.0 + dist)

    # 反向匹配筛选 - 第一阶段：收集所有候选匹配
    reverse_candidates = []  # [(i, j, distance), ...]
    
    for j in range(len(min_dist_reverse)):
        if (min_dist_reverse[j] < second_min_dist_reverse[j] * ratio and
                min_dist_reverse[j] < 1.0 and  # 进一步放宽距离阈值：从0.8增加到1.0
                min_dist_reverse[j] > 0.08 and  # 进一步放宽最小距离阈值：从0.1降到0.08
                min_dist_reverse[j] / second_min_dist_reverse[j] < 0.95):  # 进一步放宽比率：从0.9增加到0.95
            reverse_candidates.append((min_indices_reverse[j], j, min_dist_reverse[j]))
    
    # 第二阶段：解决反向匹配的一对多问题
    source_to_target = {}  # {i: (j, distance)}
    
    for i, j, dist in reverse_candidates:
        if i not in source_to_target:
            source_to_target[i] = (j, dist)
        else:
            existing_j, existing_dist = source_to_target[i]
            if dist < existing_dist:
                source_to_target[i] = (j, dist)
    
    # 构建最终的反向匹配字典
    reverse_matches = {}
    reverse_qualities = {}
    for i, (j, dist) in source_to_target.items():
        reverse_matches[i] = j
        reverse_qualities[i] = 1.0 / (1.0 + dist)

    # 生成正向匹配的关键点对
    forward_kp1 = []
    forward_kp2 = []
    for i, j in forward_matches.items():
        forward_kp1.append((kp1_location[i][0], kp1_location[i][1]))
        forward_kp2.append((kp2_location[j][0], kp2_location[j][1]))

    # 生成反向匹配的关键点对
    reverse_kp1 = []
    reverse_kp2 = []
    for i, j in reverse_matches.items():
        reverse_kp1.append((kp1_location[i][0], kp1_location[i][1]))
        reverse_kp2.append((kp2_location[j][0], kp2_location[j][1]))

    # 双向验证和质量评估
    bidirectional_matches = []
    match_qualities = []

    for i, j in forward_matches.items():
        if i in reverse_matches and reverse_matches[i] == j:
            # 综合匹配质量
            quality = (forward_qualities[i] + reverse_qualities[i]) / 2.0
            bidirectional_matches.append((i, j, quality))

    # 按匹配质量排序
    bidirectional_matches.sort(key=lambda x: x[2], reverse=True)

    # 移除硬编码限制，保留所有高质量的双向匹配
    # 只过滤掉质量过低的匹配（质量分数 < 0.1）
    quality_threshold = 0.1
    filtered_matches = [m for m in bidirectional_matches if m[2] >= quality_threshold]

    bidirectional_kp1 = []
    bidirectional_kp2 = []

    for i, j, quality in filtered_matches:
        bidirectional_kp1.append((kp1_location[i][0], kp1_location[i][1]))
        bidirectional_kp2.append((kp2_location[j][0], kp2_location[j][1]))

    print(f"   GPU双向匹配结果: 正向={len(forward_kp1)}, 反向={len(reverse_kp1)}, 双向={len(bidirectional_kp1)}")

    return bidirectional_kp1, bidirectional_kp2, forward_kp1, forward_kp2, reverse_kp1, reverse_kp2


def symmetry_test_matching(kp1_location, kp2_location, deep_des1, deep_des2, ratio, use_gpu=False, device=None):
    """
    对称性测试匹配 - 另一种双向匹配方法
    """
    print("   使用对称性测试匹配...")

    if use_gpu and device and TORCH_AVAILABLE:
        return symmetry_test_matching_gpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio, device)
    else:
        return symmetry_test_matching_cpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio)


def symmetry_test_matching_cpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio):
    """
    CPU版本的对称性测试匹配 - 放宽条件版本
    """
    if len(deep_des1) == 0 or len(deep_des2) == 0:
        return [], []

    # 计算两个方向的最近邻
    matches_1_to_2 = []
    matches_2_to_1 = []

    # 图像1 -> 图像2
    for i in range(deep_des1.shape[0]):
        distances = np.sqrt(np.sum((deep_des2 - deep_des1[i]) ** 2, axis=1))
        sorted_indices = np.argsort(distances)
        min_dist = distances[sorted_indices[0]]
        second_min_dist = distances[sorted_indices[1]]

        # 进一步放宽条件以增加匹配点数量
        if (min_dist < second_min_dist * ratio and
                min_dist < 1.2 and min_dist > 0.02):  # 进一步放宽最大距离：1.0->1.2，放宽最小距离：0.03->0.02
            matches_1_to_2.append((i, sorted_indices[0], min_dist))

    # 图像2 -> 图像1
    for j in range(deep_des2.shape[0]):
        distances = np.sqrt(np.sum((deep_des1 - deep_des2[j]) ** 2, axis=1))
        sorted_indices = np.argsort(distances)
        min_dist = distances[sorted_indices[0]]
        second_min_dist = distances[sorted_indices[1]]

        if (min_dist < second_min_dist * ratio and
                min_dist < 1.2 and min_dist > 0.02):  # 进一步放宽最大距离：1.0->1.2，放宽最小距离：0.03->0.02
            matches_2_to_1.append((sorted_indices[0], j, min_dist))

    # === 放宽的对称性测试 ===
    symmetry_matches = []

    # 严格对称性测试
    for match_1 in matches_1_to_2:
        i1, j1, dist1 = match_1
        for match_2 in matches_2_to_1:
            i2, j2, dist2 = match_2
            if i1 == i2 and j1 == j2:
                avg_dist = (dist1 + dist2) / 2.0
                symmetry_matches.append((i1, j1, avg_dist))
                break

    # === 新增：宽松对称性测试 ===
    # 对于没有严格对称的匹配，检查空间邻近性
    spatial_tolerance = 3.0  # 像素容忍度

    for match_1 in matches_1_to_2:
        i1, j1, dist1 = match_1
        found_strict = False

        # 检查是否已经在严格匹配中
        for strict_match in symmetry_matches:
            if strict_match[0] == i1 and strict_match[1] == j1:
                found_strict = True
                break

        if not found_strict:
            # 在反向匹配中寻找空间邻近的匹配
            for match_2 in matches_2_to_1:
                i2, j2, dist2 = match_2
                if i1 == i2:  # 同一个源点
                    # 检查目标点是否空间接近
                    dist_j1_j2 = abs(j1 - j2)
                    if dist_j1_j2 <= spatial_tolerance:
                        avg_dist = (dist1 + dist2) / 2.0
                        # 使用平均位置
                        avg_j = (j1 + j2) / 2
                        symmetry_matches.append((i1, avg_j, avg_dist))
                        break

    # 按平均距离排序
    symmetry_matches.sort(key=lambda x: x[2])

    symmetry_kp1 = []
    symmetry_kp2 = []

    for i, j, dist in symmetry_matches:
        symmetry_kp1.append((kp1_location[i][0], kp1_location[i][1]))
        symmetry_kp2.append((kp2_location[int(j)][0], kp2_location[int(j)][1]))

    print(f"   对称性测试结果: {len(symmetry_kp1)} 个匹配点 "
          f"(1->2: {len(matches_1_to_2)}, 2->1: {len(matches_2_to_1)})")

    return symmetry_kp1, symmetry_kp2
def symmetry_test_matching_gpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio, device):
    """
    GPU版本的对称性测试匹配
    """
    if len(deep_des1) == 0 or len(deep_des2) == 0:
        return [], []

    # 转换为PyTorch张量
    des1_tensor = torch.from_numpy(deep_des1).float().to(device)
    des2_tensor = torch.from_numpy(deep_des2).float().to(device)

    # 计算距离矩阵
    des1_norm = torch.sum(des1_tensor ** 2, dim=1, keepdim=True)
    des2_norm = torch.sum(des2_tensor ** 2, dim=1, keepdim=True)
    distances = torch.sqrt(des1_norm + des2_norm.T - 2 * torch.mm(des1_tensor, des2_tensor.T))

    # 正向匹配
    min_distances_forward, min_indices_forward = torch.topk(distances, k=2, dim=1, largest=False)
    # 反向匹配
    min_distances_reverse, min_indices_reverse = torch.topk(distances.T, k=2, dim=1, largest=False)

    # 转换为numpy
    min_dist_forward = min_distances_forward[:, 0].cpu().numpy()
    second_min_dist_forward = min_distances_forward[:, 1].cpu().numpy()
    min_indices_forward = min_indices_forward[:, 0].cpu().numpy()

    min_dist_reverse = min_distances_reverse[:, 0].cpu().numpy()
    second_min_dist_reverse = min_distances_reverse[:, 1].cpu().numpy()
    min_indices_reverse = min_indices_reverse[:, 0].cpu().numpy()

    # 收集匹配
    matches_1_to_2 = []
    matches_2_to_1 = []

    # 正向匹配筛选
    for i in range(len(min_dist_forward)):
        if (min_dist_forward[i] < second_min_dist_forward[i] * ratio and
                min_dist_forward[i] < 0.7 and min_dist_forward[i] > 0.1):
            matches_1_to_2.append((i, min_indices_forward[i], min_dist_forward[i]))

    # 反向匹配筛选
    for j in range(len(min_dist_reverse)):
        if (min_dist_reverse[j] < second_min_dist_reverse[j] * ratio and
                min_dist_reverse[j] < 0.7 and min_dist_reverse[j] > 0.1):
            matches_2_to_1.append((min_indices_reverse[j], j, min_dist_reverse[j]))

    # 对称性测试
    symmetry_matches = []
    for match_1 in matches_1_to_2:
        i1, j1, dist1 = match_1
        for match_2 in matches_2_to_1:
            i2, j2, dist2 = match_2
            if i1 == i2 and j1 == j2:
                avg_dist = (dist1 + dist2) / 2.0
                symmetry_matches.append((i1, j1, avg_dist))
                break

    # 按平均距离排序
    symmetry_matches.sort(key=lambda x: x[2])

    symmetry_kp1 = []
    symmetry_kp2 = []

    for i, j, dist in symmetry_matches:
        symmetry_kp1.append((kp1_location[i][0], kp1_location[i][1]))
        symmetry_kp2.append((kp2_location[j][0], kp2_location[j][1]))

    print(f"   GPU对称性测试结果: {len(symmetry_kp1)} 个匹配点 "
          f"(1->2: {len(matches_1_to_2)}, 2->1: {len(matches_2_to_1)})")

    return symmetry_kp1, symmetry_kp2


# ==================== 保存匹配为pickle格式（用于sfm.py） ====================
def save_matches_to_pickle_format(matches_dict, original_keypoints, args):
    """
    保存匹配为pickle格式，适配sfm.py的数据格式要求
    
    Args:
        matches_dict: dict, {(img1_name, img2_name): np.ndarray([idx1, idx2], ...)}
        original_keypoints: dict, {img_name: [cv2.KeyPoint, ...]}
        args: 参数对象，包含source_path等信息
    """
    print("💾 保存匹配为pickle格式（用于sfm.py）...")
    
    # 确定保存目录（适配sfm.py的目录结构）
    # sfm.py期望: {data_dir}/{dataset}/matches/{matcher}/
    if hasattr(args, 'sfm_data_dir') and args.sfm_data_dir:
        data_dir = args.sfm_data_dir
    else:
        data_dir = args.source_path
    
    if hasattr(args, 'sfm_dataset') and args.sfm_dataset:
        dataset = args.sfm_dataset
    else:
        dataset = os.path.basename(os.path.normpath(args.source_path))
    
    if hasattr(args, 'sfm_matcher') and args.sfm_matcher:
        matcher = args.sfm_matcher
    else:
        matcher = "SAR_SIFT"
    
    matches_dir = os.path.join(data_dir, dataset, 'matches', matcher)
    os.makedirs(matches_dir, exist_ok=True)
    
    print(f"   匹配保存目录: {matches_dir}")
    
    saved_count = 0
    for (img1_name, img2_name), match_indices in matches_dict.items():
        try:
            # 获取图像名称（不含扩展名）
            img1_name_base = os.path.splitext(img1_name)[0]
            img2_name_base = os.path.splitext(img2_name)[0]
            
            # 确保图像名称在original_keypoints中存在
            if img1_name not in original_keypoints or img2_name not in original_keypoints:
                print(f"   ⚠️ 跳过匹配对 {img1_name}-{img2_name}: 缺少关键点数据")
                continue
            
            # 将匹配索引转换为cv2.DMatch对象
            matches = []
            for match_pair in match_indices:
                query_idx = int(match_pair[0])
                train_idx = int(match_pair[1])
                
                # 验证索引有效性
                if query_idx >= len(original_keypoints[img1_name]) or train_idx >= len(original_keypoints[img2_name]):
                    continue
                
                match = cv2.DMatch()
                match.queryIdx = query_idx
                match.trainIdx = train_idx
                match.imgIdx = 0  # sfm.py中不使用imgIdx，设为0
                match.distance = 0.0  # 距离信息在匹配时已使用，这里设为0
                matches.append(match)
            
            if len(matches) == 0:
                print(f"   ⚠️ 跳过匹配对 {img1_name}-{img2_name}: 无有效匹配")
                continue
            
            # 序列化匹配
            matches_serialized = SerializeMatches(matches)
            
            # 保存匹配（使用sfm.py期望的文件名格式）
            match_path = os.path.join(matches_dir, f'match_{img1_name_base}_{img2_name_base}.pkl')
            with open(match_path, 'wb') as f:
                pickle.dump(matches_serialized, f)
            
            saved_count += 1
            if saved_count % 10 == 0:
                print(f"   已保存 {saved_count} 对匹配...")
        
        except Exception as e:
            print(f"   ❌ 保存匹配对 {img1_name}-{img2_name} 时出错: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"✅ 匹配保存完成: 共保存 {saved_count} 对匹配到 {matches_dir}")
    return matches_dir

