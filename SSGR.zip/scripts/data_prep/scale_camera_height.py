#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
缩放相机高度到10-30米范围
"""

import json
import sys
import os

def scale_camera_height(input_file, output_file=None, target_height=20.0):
    """
    缩放相机高度到目标高度
    
    Args:
        input_file: 输入的cameras.json文件路径
        output_file: 输出的cameras.json文件路径（如果为None，则覆盖原文件）
        target_height: 目标平均高度（米）
    """
    # 读取原始文件
    with open(input_file, 'r', encoding='utf-8') as f:
        cameras = json.load(f)
    
    print(f"读取了 {len(cameras)} 个相机")
    
    # 计算当前Z坐标（高度）的统计信息
    z_coords = [cam['position'][2] for cam in cameras]
    current_avg_height = sum(z_coords) / len(z_coords)
    min_height = min(z_coords)
    max_height = max(z_coords)
    
    print(f"\n当前高度统计:")
    print(f"  最小高度: {min_height:.2f} 米")
    print(f"  最大高度: {max_height:.2f} 米")
    print(f"  平均高度: {current_avg_height:.2f} 米")
    
    # 计算缩放因子（基于平均高度）
    scale_factor = target_height / current_avg_height
    print(f"\n缩放因子: {scale_factor:.6f} (目标平均高度: {target_height} 米)")
    
    # 计算场景中心（用于缩放）
    positions = [[cam['position'][0], cam['position'][1], cam['position'][2]] for cam in cameras]
    center_x = sum(p[0] for p in positions) / len(positions)
    center_y = sum(p[1] for p in positions) / len(positions)
    center_z = sum(p[2] for p in positions) / len(positions)
    center = [center_x, center_y, center_z]
    
    print(f"场景中心: [{center[0]:.2f}, {center[1]:.2f}, {center[2]:.2f}]")
    
    # 缩放相机位置（相对于场景中心）
    # 注意：Z坐标（高度）需要单独处理，因为我们要将高度缩放到目标值
    for cam in cameras:
        pos = cam['position']
        # X和Y坐标相对于中心缩放
        scaled_x = center[0] + (pos[0] - center[0]) * scale_factor
        scaled_y = center[1] + (pos[1] - center[1]) * scale_factor
        # Z坐标（高度）直接按比例缩放
        scaled_z = pos[2] * scale_factor
        cam['position'] = [scaled_x, scaled_y, scaled_z]
    
    # 计算缩放后的统计信息
    scaled_z_coords = [cam['position'][2] for cam in cameras]
    scaled_avg_height = sum(scaled_z_coords) / len(scaled_z_coords)
    scaled_min_height = min(scaled_z_coords)
    scaled_max_height = max(scaled_z_coords)
    
    print(f"\n缩放后高度统计:")
    print(f"  最小高度: {scaled_min_height:.2f} 米")
    print(f"  最大高度: {scaled_max_height:.2f} 米")
    print(f"  平均高度: {scaled_avg_height:.2f} 米")
    
    # 保存文件
    if output_file is None:
        output_file = input_file
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(cameras, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ 已保存到: {output_file}")
    print(f"   缩放因子: {scale_factor:.6f}")
    print(f"   目标高度: {target_height} 米")
    print(f"   实际平均高度: {scaled_avg_height:.2f} 米")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法: python scale_camera_height.py <cameras.json> [output_file] [target_height]")
        print("示例: python scale_camera_height.py output/sar_reconstruction/cameras.json")
        print("示例: python scale_camera_height.py output/sar_reconstruction/cameras.json cameras_scaled.json 20.0")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    target_height = float(sys.argv[3]) if len(sys.argv) > 3 else 20.0
    
    if not os.path.exists(input_file):
        print(f"❌ 错误: 文件不存在: {input_file}")
        sys.exit(1)
    
    scale_camera_height(input_file, output_file, target_height)

