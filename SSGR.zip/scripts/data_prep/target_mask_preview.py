#!/usr/bin/env python3
"""Generate target-only semantic mask previews for SAR/MSTAR images.

This script intentionally does not run shadow/background classification. It is
for isolating and tuning target recognition before feeding target masks into the
shadow/background stages.
"""

from __future__ import annotations

import argparse
import csv
import html
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy import ndimage


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
DATA_PREP_DIR = REPO_ROOT / "scripts" / "data_prep"
if str(DATA_PREP_DIR) not in sys.path:
    sys.path.insert(0, str(DATA_PREP_DIR))

from sar.scattering_filter import load_sar_grayscale_like_convert
from sar.semantic_mask_config import compute_scattering_threshold, mask_default
from feature_extraction import (
    _apply_center_roi_to_target_mask,
    _target_mask_keep_centered_main_component_with_nearby,
    _target_mask_remove_small_connected_components,
)


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def _normalize_u8(image: np.ndarray) -> np.ndarray:
    arr = np.asarray(image, dtype=np.float32)
    lo = float(np.percentile(arr, 0.5))
    hi = float(np.percentile(arr, 99.5))
    if hi <= lo:
        hi = float(np.max(arr))
        lo = float(np.min(arr))
    if hi <= lo:
        return np.zeros(arr.shape, dtype=np.uint8)
    out = np.clip((arr - lo) / (hi - lo), 0.0, 1.0)
    return (out * 255.0 + 0.5).astype(np.uint8)


def _target_boundary(mask: np.ndarray) -> np.ndarray:
    m = np.asarray(mask, dtype=bool)
    if not np.any(m):
        return m
    eroded = ndimage.binary_erosion(m, structure=np.ones((3, 3), dtype=bool), iterations=1)
    return m & ~eroded


def build_target_mask(
    image: np.ndarray,
    *,
    target_percentile: float,
    background_percentile: float,
    target_mask_dilate_px: int,
    target_center_roi_fraction: float,
    target_center_roi_min_keep_fraction: float,
    target_mask_min_component_area_px: int,
    target_semantic_largest_component_only: bool,
    target_semantic_keep_dilate_px: int,
) -> tuple[np.ndarray, dict]:
    target_threshold, background_threshold = compute_scattering_threshold(
        image,
        target_percentile=target_percentile,
        background_percentile=background_percentile,
        verbose=False,
    )
    target_mask = np.asarray(image >= target_threshold, dtype=bool)
    stats: dict = {
        "target_threshold": float(target_threshold),
        "background_threshold": float(background_threshold),
        "initial_pixels": int(np.sum(target_mask)),
    }

    target_mask, roi_stats = _apply_center_roi_to_target_mask(
        target_mask,
        roi_fraction=float(target_center_roi_fraction or 0.0),
        min_keep_fraction=float(target_center_roi_min_keep_fraction or 0.0),
    )
    stats.update(
        {
            "roi_enabled": bool(roi_stats.get("enabled")),
            "roi_pixels": int(np.sum(target_mask)),
            "roi_keep_fraction": float(roi_stats.get("keep_fraction", 1.0)),
        }
    )

    dilate_n = max(0, int(target_mask_dilate_px or 0))
    if dilate_n > 0 and np.any(target_mask):
        before = int(np.sum(target_mask))
        target_mask = ndimage.binary_dilation(
            target_mask, structure=np.ones((3, 3), dtype=bool), iterations=dilate_n
        )
        stats["dilate_before_pixels"] = before
        stats["dilate_after_pixels"] = int(np.sum(target_mask))
    else:
        stats["dilate_before_pixels"] = int(np.sum(target_mask))
        stats["dilate_after_pixels"] = int(np.sum(target_mask))

    min_area = max(0, int(target_mask_min_component_area_px or 0))
    if min_area > 0 and np.any(target_mask):
        target_mask, min_stats = _target_mask_remove_small_connected_components(
            target_mask, min_component_area_px=min_area
        )
        stats["min_area_components"] = int(min_stats.get("n_components", 0))
        stats["min_area_kept_components"] = int(min_stats.get("kept_components", 0))
    else:
        stats["min_area_components"] = 0
        stats["min_area_kept_components"] = 0

    if bool(target_semantic_largest_component_only) and np.any(target_mask):
        target_mask, main_stats = _target_mask_keep_centered_main_component_with_nearby(
            target_mask,
            keep_dilate_px=max(0, int(target_semantic_keep_dilate_px or 0)),
        )
        stats["main_component_enabled"] = bool(main_stats.get("enabled"))
        stats["main_component_count"] = int(main_stats.get("n_components", 0))
        stats["main_component_dropped_pixels"] = int(main_stats.get("dropped_pixels", 0))
    else:
        stats["main_component_enabled"] = False
        stats["main_component_count"] = 0
        stats["main_component_dropped_pixels"] = 0

    stats["final_pixels"] = int(np.sum(target_mask))
    stats["final_percent"] = float(stats["final_pixels"] / max(1, image.size) * 100.0)
    return target_mask, stats


def save_preview(image: np.ndarray, target_mask: np.ndarray, out_dir: Path, stem: str, stats: dict) -> dict:
    base = _normalize_u8(image)
    rgb = cv2.cvtColor(base, cv2.COLOR_GRAY2BGR)
    overlay = rgb.copy()
    overlay[target_mask] = (30, 30, 255)
    blended = cv2.addWeighted(rgb, 0.58, overlay, 0.42, 0.0)
    boundary = _target_boundary(target_mask)
    blended[boundary] = (0, 255, 255)

    mask_u8 = (np.asarray(target_mask, dtype=np.uint8) * 255)
    mask_bgr = cv2.cvtColor(mask_u8, cv2.COLOR_GRAY2BGR)
    original_bgr = rgb.copy()

    label = f"target={stats['final_pixels']} ({stats['final_percent']:.2f}%)"
    cv2.putText(blended, label, (8, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.putText(mask_bgr, label, (8, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)

    compare = np.concatenate([original_bgr, blended, mask_bgr], axis=1)
    overlay_name = f"target_overlay_{stem}.png"
    mask_name = f"target_mask_{stem}.png"
    compare_name = f"target_compare_{stem}.png"
    cv2.imwrite(str(out_dir / overlay_name), blended)
    cv2.imwrite(str(out_dir / mask_name), mask_u8)
    cv2.imwrite(str(out_dir / compare_name), compare)
    return {"overlay": overlay_name, "mask": mask_name, "compare": compare_name}


def write_index(out_dir: Path, rows: list[dict]) -> None:
    cards = []
    for row in rows:
        cards.append(
            "<figure>"
            f"<a href=\"{html.escape(row['compare'])}\" target=\"_blank\">"
            f"<img src=\"{html.escape(row['compare'])}\" loading=\"lazy\"></a>"
            f"<figcaption>{html.escape(row['image'])}<br>"
            f"target {row['final_pixels']} px ({row['final_percent']:.2f}%)</figcaption>"
            "</figure>"
        )
    body = f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Target Mask Preview</title>
  <style>
    body {{ margin: 0; font: 14px/1.45 Arial, sans-serif; background: #f8fafc; color: #111827; }}
    header {{ position: sticky; top: 0; padding: 14px 18px; background: #fff; border-bottom: 1px solid #d9e2ec; }}
    h1 {{ margin: 0 0 4px; font-size: 18px; }}
    main {{ padding: 18px; }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(430px, 1fr)); gap: 14px; }}
    figure {{ margin: 0; border: 1px solid #d9e2ec; border-radius: 8px; background: #fff; overflow: hidden; }}
    img {{ display: block; width: 100%; height: auto; background: #111827; }}
    figcaption {{ padding: 8px 10px; font-size: 12px; color: #374151; }}
    .meta {{ color: #6b7280; font-size: 12px; }}
  </style>
</head>
<body>
  <header>
    <h1>Target Mask Preview</h1>
    <div class="meta">Left: original | Middle: target overlay | Right: binary target mask</div>
  </header>
  <main><section class="grid">{''.join(cards)}</section></main>
</body>
</html>
"""
    (out_dir / "index.html").write_text(body, encoding="utf-8")


def image_files_from_args(args: argparse.Namespace) -> list[Path]:
    if args.image:
        return [Path(args.image)]
    data_dir = Path(args.data_dir)
    if not data_dir.is_absolute():
        data_dir = REPO_ROOT / data_dir
    img_dir = data_dir / args.image_subdir
    if not img_dir.is_dir():
        img_dir = data_dir
    files = sorted(p for p in img_dir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS)
    if args.max_images and args.max_images > 0:
        files = files[: args.max_images]
    return files


def default_output_dir(args: argparse.Namespace) -> Path:
    if args.output_dir:
        out = Path(args.output_dir)
        return out if out.is_absolute() else REPO_ROOT / out
    if args.image:
        return REPO_ROOT / "output" / "target_mask_preview"
    data_dir = Path(args.data_dir)
    if not data_dir.is_absolute():
        data_dir = REPO_ROOT / data_dir
    return data_dir / "target_mask_preview"


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Target-only SAR mask preview")
    parser.add_argument("--data_dir", default="data/2S1", help="Dataset folder, for example data/2S1.")
    parser.add_argument("--image_subdir", default="input", help="Image subfolder under data_dir.")
    parser.add_argument("--image", default="", help="Single image path. Overrides data_dir.")
    parser.add_argument("--output_dir", default="", help="Output folder. Defaults to <data_dir>/target_mask_preview.")
    parser.add_argument("--max_images", type=int, default=0, help="Limit number of images, 0 means all.")
    parser.add_argument("--target_percentile", type=float, default=mask_default("target_percentile"))
    parser.add_argument("--background_percentile", type=float, default=mask_default("background_percentile"))
    parser.add_argument("--target_mask_dilate_px", type=int, default=mask_default("target_mask_dilate_px"))
    parser.add_argument("--target_center_roi_fraction", type=float, default=mask_default("target_center_roi_fraction"))
    parser.add_argument(
        "--target_center_roi_min_keep_fraction",
        type=float,
        default=mask_default("target_center_roi_min_keep_fraction"),
    )
    parser.add_argument(
        "--target_mask_min_component_area_px",
        type=int,
        default=mask_default("target_mask_min_component_area_px"),
    )
    parser.add_argument(
        "--target_semantic_largest_component_only",
        action=argparse.BooleanOptionalAction,
        default=mask_default("target_semantic_largest_component_only"),
    )
    parser.add_argument(
        "--target_semantic_keep_dilate_px",
        type=int,
        default=mask_default("target_semantic_keep_dilate_px"),
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    out_dir = default_output_dir(args)
    out_dir.mkdir(parents=True, exist_ok=True)
    files = image_files_from_args(args)
    if not files:
        raise SystemExit("No images found.")

    rows: list[dict] = []
    for idx, img_path in enumerate(files, 1):
        image = load_sar_grayscale_like_convert(str(img_path))
        target_mask, stats = build_target_mask(
            image,
            target_percentile=float(args.target_percentile),
            background_percentile=float(args.background_percentile),
            target_mask_dilate_px=int(args.target_mask_dilate_px),
            target_center_roi_fraction=float(args.target_center_roi_fraction),
            target_center_roi_min_keep_fraction=float(args.target_center_roi_min_keep_fraction),
            target_mask_min_component_area_px=int(args.target_mask_min_component_area_px),
            target_semantic_largest_component_only=bool(args.target_semantic_largest_component_only),
            target_semantic_keep_dilate_px=int(args.target_semantic_keep_dilate_px),
        )
        names = save_preview(image, target_mask, out_dir, img_path.stem, stats)
        row = {
            "image": img_path.name,
            **stats,
            **names,
        }
        rows.append(row)
        print(
            f"[{idx}/{len(files)}] {img_path.name}: "
            f"target={stats['final_pixels']} ({stats['final_percent']:.2f}%), "
            f"initial={stats['initial_pixels']}, roi={stats['roi_pixels']}, "
            f"main_drop={stats['main_component_dropped_pixels']}"
        )

    csv_path = out_dir / "target_mask_summary.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    write_index(out_dir, rows)
    print(f"Saved target-only preview: {out_dir}")
    print(f"Open: {out_dir / 'index.html'}")
    print(f"Summary: {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
