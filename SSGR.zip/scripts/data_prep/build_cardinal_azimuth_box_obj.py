#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从 target_dimension_constraints_summary.txt 读取「优选方位角」视图上的 L/W，
并用同批视图中由阴影几何得到的 H，生成轴对齐长方体 OBJ（单独脚本，便于测试）。

逻辑与 post_sfm 模块 build_cardinal_box_obj（--post_sfm_modules）相同，见 post_sfm.cardinal_box_from_summary。

用法（须单独一行执行）:
  python scripts/data_prep/build_cardinal_azimuth_box_obj.py ^
    --summary ...\\target_dimension_constraints_summary.txt ^
    --out ...\\box_from_cardinal.obj ^
    --depth-scale 0.002

或在 convert 末尾: --post_sfm_modules build_cardinal_box_obj --post_sfm_cardinal_box_depth_scale 0.002
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _root = str(_repo)
        if _root not in sys.path:
            sys.path.insert(0, _root)
        break
else:
    raise RuntimeError("无法定位仓库根目录（需存在 train.py）")
_dp = str(Path(__file__).resolve().parent)
if _dp not in sys.path:
    sys.path.insert(0, _dp)

from post_sfm.cardinal_box_from_summary import run_cardinal_box_pipeline


def main() -> None:
    p = argparse.ArgumentParser(description="优选方位角 L/W + 阴影高度 H → 长方体 OBJ（与 convert post_sfm 同源）")
    p.add_argument("--summary", required=True, help="target_dimension_constraints_summary.txt 路径")
    p.add_argument("--out", required=True, help="输出 .obj 路径")
    p.add_argument("--azimuth-tolerance", type=float, default=10.0)
    p.add_argument(
        "--azimuth-lane",
        choices=("cardinal", "diagonal"),
        default="cardinal",
        help="cardinal=筛 0/90/180/270°±容差；diagonal=筛 45/135/225/315°±容差（减轻叠掩—阴影误判时可试）",
    )
    p.add_argument(
        "--aggregate",
        choices=("median", "mean", "weighted_mean"),
        default="weighted_mean",
        help="weighted_mean：越接近 lane 参考角权重越高",
    )
    p.add_argument(
        "--azimuth-weight-floor",
        type=float,
        default=0.05,
        help="加权时角距≥容差对应的最小权重",
    )
    p.add_argument("--height-mode", choices=("cardinal", "all_images"), default="cardinal")
    p.add_argument("--include-all-for-lw", action="store_true", default=False)
    p.add_argument("--depth-scale", type=float, default=1.0)
    p.add_argument("--json-sidecar", default="")
    p.add_argument("--ascii-obj-only", action="store_true", default=False)
    args = p.parse_args()

    try:
        run_cardinal_box_pipeline(
            os.path.abspath(args.summary),
            os.path.abspath(args.out),
            azimuth_tolerance=float(args.azimuth_tolerance),
            aggregate=args.aggregate,
            height_mode=args.height_mode,
            include_all_for_lw=bool(args.include_all_for_lw),
            depth_scale=float(args.depth_scale),
            json_sidecar=(args.json_sidecar or "").strip(),
            ascii_obj_only=bool(args.ascii_obj_only),
            print_report=True,
            azimuth_weight_floor=float(args.azimuth_weight_floor),
            azimuth_lane=str(args.azimuth_lane),
        )
    except (FileNotFoundError, RuntimeError, ValueError) as e:
        raise SystemExit(str(e)) from e


if __name__ == "__main__":
    main()
