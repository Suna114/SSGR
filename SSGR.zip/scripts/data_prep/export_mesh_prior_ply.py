#!/usr/bin/env python3
"""调试：从 OBJ 网格与 COLMAP sparse/0 生成对齐后的点云 PLY，不写回 points3D.bin。"""

from __future__ import annotations

import argparse
import os
import sys

_REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_DATA_PREP = os.path.join(_REPO, "scripts", "data_prep")
if _DATA_PREP not in sys.path:
    sys.path.insert(0, _DATA_PREP)

from post_sfm.colmap_points import store_ply_ascii  # noqa: E402
from post_sfm.mesh_obj_prior_core import build_mesh_prior_pointcloud, parse_vertex_axis_sign  # noqa: E402


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--mesh", required=True, help="网格 .obj / .ply / .stl / .off")
    p.add_argument(
        "--sparse_dir",
        required=True,
        help="含 points3D.bin 或 points3D.txt 的目录（通常为 .../sparse/0）",
    )
    p.add_argument("--out_ply", required=True, help="输出 ASCII PLY 路径")
    p.add_argument("--sample_count", type=int, default=200_000)
    p.add_argument("--icp_source_samples", type=int, default=80_000)
    p.add_argument("--skip_icp", action="store_true")
    p.add_argument("--poisson_disk", action="store_true")
    p.add_argument("--scale_override", type=float, default=0.0)
    p.add_argument("--crop_margin", type=float, default=0.0, help="相对 sparse AABB 外扩后裁点；0=不裁（与 convert 默认一致）")
    p.add_argument("--icp_max_iters", type=int, default=40)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--max_sparse_points", type=int, default=500_000)
    p.add_argument("--save_transform_json", type=str, default="", help="可选：写出 4x4 JSON")
    p.add_argument(
        "--pseudocolor_normals",
        action="store_true",
        help="用法向伪彩作为 RGB（默认：中性灰）",
    )
    p.add_argument(
        "--vertex_axis_sign",
        type=str,
        default="1,-1,1",
        help="对齐前 OBJ 顶点三轴符号（±1），如 1,-1,-1；与 convert --sfm_mesh_prior_vertex_axis_sign 相同语义",
    )
    args = p.parse_args()

    mesh = args.mesh
    if not os.path.isfile(mesh):
        raise SystemExit(f"网格不存在: {mesh}")
    if not os.path.isdir(args.sparse_dir):
        raise SystemExit(f"目录不存在: {args.sparse_dir}")

    result = build_mesh_prior_pointcloud(
        mesh,
        args.sparse_dir,
        sample_count=args.sample_count,
        icp_source_samples=args.icp_source_samples,
        use_poisson_disk=args.poisson_disk,
        skip_icp=args.skip_icp,
        icp_max_iters=args.icp_max_iters,
        scale_override=args.scale_override,
        crop_margin_factor=args.crop_margin,
        seed=args.seed,
        save_transform_json=args.save_transform_json or None,
        max_sparse_points=args.max_sparse_points,
        use_normal_rgb=bool(args.pseudocolor_normals),
        mesh_vertex_axis_sign=parse_vertex_axis_sign(args.vertex_axis_sign),
    )

    out = os.path.abspath(args.out_ply)
    parent = os.path.dirname(out)
    if parent:
        os.makedirs(parent, exist_ok=True)
    store_ply_ascii(out, result.xyz_world, result.rgb)
    print(f"写出 {out}，点数 {result.xyz_world.shape[0]}")
    if result.fitness_rmse:
        print(f"ICP fitness={result.fitness_rmse[0]:.6f}, rmse={result.fitness_rmse[1]:.6f}")


if __name__ == "__main__":
    main()
