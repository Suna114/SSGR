#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
将 GT 图与对应训练渲染图横向（或纵向）拼成一张图，便于肉眼看差异。
默认无顶部文字标签；需要标签时加 --with-label。

按「文件名主干」配对：默认同名；若渲染图多后缀（如 *_nobg），可用 --render-stem-suffix 去掉后再与 GT 主干比对。

示例:
  python stitch_gt_train.py ^
    --gt_dir output/51/rendered_images/train/gt ^
    --render_dir output/51/rendered_images/train/renders ^
    --out_dir output/51/rendered_images/train/paired

  # GT 为 T72-15-001.png，渲染为 T72-15-001_nobg.jpg 时:
  python stitch_gt_train.py --gt_dir .../gt --render_dir .../renders --out_dir .../paired ^
    --render-stem-suffix _nobg
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, List, Optional

from PIL import Image, ImageDraw, ImageFont

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}


def _list_images(folder: Path) -> List[Path]:
    if not folder.is_dir():
        raise FileNotFoundError(f"目录不存在: {folder}")
    files = sorted(
        p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS
    )
    return files


def _norm_stem(stem: str, strip_suffix: Optional[str]) -> str:
    if strip_suffix and stem.endswith(strip_suffix):
        return stem[: -len(strip_suffix)]
    return stem


def _build_render_index(
    render_paths: List[Path], strip_suffix: Optional[str]
) -> Dict[str, Path]:
    """主干(规范化后) -> 渲染图路径；冲突时保留字典序前者。"""
    index: Dict[str, Path] = {}
    for p in sorted(render_paths):
        key = _norm_stem(p.stem, strip_suffix)
        if key not in index:
            index[key] = p
    return index


def _resize_to(ref: Image.Image, img: Image.Image) -> Image.Image:
    if img.size == ref.size:
        return img
    return img.resize(ref.size, Image.Resampling.BICUBIC)


def _to_rgb(img: Image.Image) -> Image.Image:
    if img.mode == "RGBA":
        bg = Image.new("RGB", img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    return img.convert("RGB")


def _caption_bar(width: int, height: int, text: str, bg=(40, 40, 40), fg=(255, 255, 255)) -> Image.Image:
    bar = Image.new("RGB", (width, height), bg)
    draw = ImageDraw.Draw(bar)
    try:
        font = ImageFont.truetype("arial.ttf", 14)
    except OSError:
        font = ImageFont.load_default()
    draw.text((6, 2), text, fill=fg, font=font)
    return bar


def stitch_pair(
    gt_path: Path,
    render_path: Path,
    layout: str,
    bar_h: int,
    label_gt: str,
    label_render: str,
) -> Image.Image:
    gt = _to_rgb(Image.open(gt_path))
    ren = _to_rgb(Image.open(render_path))
    ren = _resize_to(gt, ren)

    if layout == "horizontal":
        cap_w = gt.width + ren.width
        if bar_h <= 0:
            canvas = Image.new("RGB", (cap_w, gt.height), (0, 0, 0))
            canvas.paste(gt, (0, 0))
            canvas.paste(ren, (gt.width, 0))
            return canvas
        bar = _caption_bar(cap_w, bar_h, f"{label_gt}  |  {label_render}")
        canvas = Image.new("RGB", (cap_w, bar_h + gt.height), (0, 0, 0))
        canvas.paste(bar, (0, 0))
        canvas.paste(gt, (0, bar_h))
        canvas.paste(ren, (gt.width, bar_h))
        return canvas

    # vertical
    cap_w = max(gt.width, ren.width)
    if bar_h <= 0:
        total_h = gt.height + ren.height
        canvas = Image.new("RGB", (cap_w, total_h), (0, 0, 0))
        canvas.paste(gt, ((cap_w - gt.width) // 2, 0))
        canvas.paste(ren, ((cap_w - ren.width) // 2, gt.height))
        return canvas
    bar = _caption_bar(cap_w, bar_h, f"{label_gt} / {label_render}")
    total_h = bar_h + gt.height + ren.height
    canvas = Image.new("RGB", (cap_w, total_h), (0, 0, 0))
    canvas.paste(bar, (0, 0))
    canvas.paste(gt, ((cap_w - gt.width) // 2, bar_h))
    canvas.paste(ren, ((cap_w - ren.width) // 2, bar_h + gt.height))
    return canvas


def main() -> int:
    p = argparse.ArgumentParser(description="GT 与训练渲染图按文件名配对并拼接保存")
    p.add_argument("--gt_dir", type=Path, required=True, help="GT 图像目录")
    p.add_argument("--render_dir", type=Path, required=True, help="训练渲染图目录（与 GT 同主干配对）")
    p.add_argument("--out_dir", type=Path, required=True, help="拼接结果输出目录")
    p.add_argument(
        "--layout",
        choices=("horizontal", "vertical"),
        default="horizontal",
        help="horizontal: 左 GT 右渲染；vertical: 上 GT 下渲染",
    )
    p.add_argument(
        "--render-stem-suffix",
        type=str,
        default="",
        help="从渲染图文件名主干末尾去掉该后缀再与 GT 主干匹配，例如 _nobg",
    )
    p.add_argument(
        "--anchor",
        choices=("gt", "render"),
        default="gt",
        help="以哪边为基准遍历：gt=每张 GT 找渲染；render=每张渲染找 GT",
    )
    p.add_argument(
        "--with-label",
        action="store_true",
        help="在顶部绘制 GT / Train 说明条（默认不绘制）",
    )
    p.add_argument("--label-gt", type=str, default="GT")
    p.add_argument("--label-render", type=str, default="Train render")
    args = p.parse_args()

    strip = args.render_stem_suffix or None
    gt_dir = args.gt_dir.expanduser().resolve()
    render_dir = args.render_dir.expanduser().resolve()
    out_dir = args.out_dir.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    gt_files = _list_images(gt_dir)
    render_files = _list_images(render_dir)
    r_index = _build_render_index(render_files, strip)

    g_index: Dict[str, Path] = {}
    for pth in gt_files:
        g_index[pth.stem] = pth

    bar_h = 22 if args.with_label else 0
    ok, skip = 0, 0

    if args.anchor == "gt":
        for gt_path in gt_files:
            key = gt_path.stem
            rp = r_index.get(key)
            if rp is None:
                print(f"[跳过] 无匹配渲染: GT={gt_path.name} (key={key})")
                skip += 1
                continue
            out_name = f"{key}_paired.png"
            img = stitch_pair(
                gt_path,
                rp,
                args.layout,
                bar_h,
                args.label_gt,
                args.label_render,
            )
            img.save(out_dir / out_name)
            ok += 1
    else:
        for render_path in render_files:
            key = _norm_stem(render_path.stem, strip)
            gp = g_index.get(key)
            if gp is None:
                print(f"[跳过] 无匹配 GT: render={render_path.name} (key={key})")
                skip += 1
                continue
            out_name = f"{key}_paired.png"
            img = stitch_pair(
                gp,
                render_path,
                args.layout,
                bar_h,
                args.label_gt,
                args.label_render,
            )
            img.save(out_dir / out_name)
            ok += 1

    print(f"完成: 写出 {ok} 张 -> {out_dir}；跳过 {skip} 张")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
