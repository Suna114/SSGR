#!/usr/bin/env python3
"""Standalone preview for SAR semantic regions: background / target / edge / shadow.

This script isolates the region classification part of the pipeline. It does
not run SfM, 3DGS, refiner, training, or generation. It only:

1. reads SAR/MSTAR grayscale images with the same preprocessing as convert;
2. computes semantic masks through feature_extraction.create_scattering_mask;
3. writes region_classification_*.png, shadow_diagnostic_*.txt, masks, CSV,
   and an index.html gallery for quick inspection.
"""

from __future__ import annotations

import argparse
import csv
import html
import re
import sys
from pathlib import Path

import cv2
import numpy as np


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
DATA_PREP_DIR = REPO_ROOT / "scripts" / "data_prep"
if str(DATA_PREP_DIR) not in sys.path:
    sys.path.insert(0, str(DATA_PREP_DIR))

from sar.scattering_filter import load_sar_grayscale_like_convert
from sar.semantic_mask_config import (
    compute_scattering_threshold,
    register_semantic_mask_cli_args,
    semantic_mask_kwargs_from_args,
)
from feature_extraction import (
    create_scattering_mask,
    enhance_target_contrast_adaptive,
    visualize_adaptive_threshold_effect,
    visualize_scattering_regions,
)
from feature_extraction import apply_dataset_shadow_consistency_refinement


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def _resolve_path(raw: str | Path) -> Path:
    path = Path(raw)
    return path if path.is_absolute() else REPO_ROOT / path


def _image_files(args: argparse.Namespace) -> list[Path]:
    if args.image:
        image = _resolve_path(args.image)
        if not image.is_file():
            raise FileNotFoundError(f"Image not found: {image}")
        return [image]

    data_dir = _resolve_path(args.data_dir)
    img_dir = data_dir / args.image_subdir
    if not img_dir.is_dir():
        img_dir = data_dir
    if not img_dir.is_dir():
        raise FileNotFoundError(f"Image folder not found: {img_dir}")

    files = sorted(p for p in img_dir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS)
    if args.azimuth:
        wanted = {int(x.strip()) % 360 for x in str(args.azimuth).split(",") if x.strip()}
        files = [p for p in files if _azimuth_from_stem(p.stem) in wanted]
    if args.max_images and args.max_images > 0:
        files = files[: int(args.max_images)]
    return files


def _azimuth_from_stem(stem: str) -> int | None:
    match = re.search(r"-(\d{1,3})$", str(stem))
    if not match:
        return None
    return int(match.group(1)) % 360


def _default_output_dir(args: argparse.Namespace) -> Path:
    if args.output_dir:
        return _resolve_path(args.output_dir)
    if args.image:
        return REPO_ROOT / "output" / "semantic_region_preview"
    return _resolve_path(args.data_dir) / "semantic_region_preview"


def _mask_label_png(mask: np.ndarray) -> np.ndarray:
    """BGR label image: bg black, target red, edge green, shadow blue."""
    out = np.zeros((*mask.shape, 3), dtype=np.uint8)
    out[mask == 1] = (0, 0, 255)
    out[mask == 2] = (0, 255, 0)
    out[mask == 3] = (255, 0, 0)
    return out


def _mask_stats(mask: np.ndarray) -> dict:
    total = max(1, int(mask.size))
    bg = int(np.sum(mask == 0))
    interior = int(np.sum(mask == 1))
    edge = int(np.sum(mask == 2))
    shadow = int(np.sum(mask == 3))
    target_total = interior + edge
    return {
        "background_pixels": bg,
        "background_percent": bg / total * 100.0,
        "target_interior_pixels": interior,
        "target_edge_pixels": edge,
        "target_total_pixels": target_total,
        "target_total_percent": target_total / total * 100.0,
        "shadow_pixels": shadow,
        "shadow_percent": shadow / total * 100.0,
    }


def _write_index(out_dir: Path, rows: list[dict]) -> None:
    cards = []
    for row in rows:
        region = html.escape(str(row["region_preview"]))
        label = html.escape(str(row["label_png"]))
        cards.append(
            "<figure>"
            f"<a href=\"{region}\" target=\"_blank\"><img src=\"{region}\" loading=\"lazy\"></a>"
            f"<figcaption>{html.escape(row['image'])}<br>"
            f"target {row['target_total_percent']:.2f}% | "
            f"shadow {row['shadow_percent']:.2f}% | "
            f"background {row['background_percent']:.2f}%<br>"
            f"<a href=\"{label}\" target=\"_blank\">label mask</a></figcaption>"
            "</figure>"
        )
    body = f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>SAR Semantic Region Preview</title>
  <style>
    body {{ margin: 0; font: 14px/1.45 Arial, sans-serif; background: #f8fafc; color: #111827; }}
    header {{ position: sticky; top: 0; z-index: 1; padding: 14px 18px; background: #fff; border-bottom: 1px solid #d9e2ec; }}
    h1 {{ margin: 0 0 4px; font-size: 18px; }}
    main {{ padding: 18px; }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 14px; }}
    figure {{ margin: 0; border: 1px solid #d9e2ec; border-radius: 8px; background: #fff; overflow: hidden; }}
    img {{ display: block; width: 100%; height: auto; background: #111827; }}
    figcaption {{ padding: 8px 10px; font-size: 12px; color: #374151; word-break: break-word; }}
    a {{ color: #0f766e; }}
    .meta {{ color: #6b7280; font-size: 12px; }}
  </style>
</head>
<body>
  <header>
    <h1>SAR Semantic Region Preview</h1>
    <div class="meta">Red: target interior | Green: target edge | Blue: shadow | Black: background</div>
  </header>
  <main><section class="grid">{''.join(cards)}</section></main>
</body>
</html>
"""
    (out_dir / "index.html").write_text(body, encoding="utf-8")


def _run_one(img_path: Path, out_dir: Path, mask_kwargs: dict, *, save_npy: bool) -> tuple[dict, np.ndarray]:
    image = load_sar_grayscale_like_convert(str(img_path))
    if image.ndim != 2:
        image = np.mean(image, axis=2)

    target_threshold, background_threshold = compute_scattering_threshold(
        image,
        target_percentile=mask_kwargs["target_percentile"],
        background_percentile=mask_kwargs["background_percentile"],
        verbose=False,
    )
    mask = create_scattering_mask(
        image,
        target_threshold,
        background_threshold,
        shadow_threshold_factor=mask_kwargs["shadow_threshold_factor"],
        output_dir=str(out_dir),
        img_name=img_path.name,
        target_mask_dilate_px=mask_kwargs["target_mask_dilate_px"],
        target_edge_band_px=mask_kwargs["target_edge_band_px"],
        target_edge_inner_px=mask_kwargs["target_edge_inner_px"],
        target_edge_outer_px=mask_kwargs["target_edge_outer_px"],
        merge_target_edge_into_interior=mask_kwargs["merge_scattering_target_edge"],
        target_mask_largest_component_only=mask_kwargs["target_mask_largest_component_only"],
        target_mask_min_component_area_px=mask_kwargs["target_mask_min_component_area_px"],
        target_semantic_largest_component_only=mask_kwargs["target_semantic_largest_component_only"],
        target_semantic_keep_dilate_px=mask_kwargs["target_semantic_keep_dilate_px"],
        target_selection_mode=mask_kwargs["target_selection_mode"],
        target_percentile=mask_kwargs["target_percentile"],
        target_filter_blur_sigma=mask_kwargs["target_filter_blur_sigma"],
        target_filter_open_iter=mask_kwargs["target_filter_open_iter"],
        target_filter_close_iter=mask_kwargs["target_filter_close_iter"],
        target_filter_morph_kernel=mask_kwargs["target_filter_morph_kernel"],
        target_filter_largest_cc=mask_kwargs["target_filter_largest_cc"],
        target_filter_min_target_ratio=mask_kwargs["target_filter_min_target_ratio"],
        target_filter_min_cc_area=mask_kwargs["target_filter_min_cc_area"],
        target_filter_erode_px=mask_kwargs["target_filter_erode_px"],
        shadow_percentile=mask_kwargs["shadow_percentile"],
        shadow_target_geometry_filter=mask_kwargs["shadow_target_geometry_filter"],
        shadow_min_area_fraction=mask_kwargs["shadow_min_area_fraction"],
        shadow_min_target_area_fraction=mask_kwargs["shadow_min_target_area_fraction"],
        shadow_y_margin_fraction=mask_kwargs["shadow_y_margin_fraction"],
        shadow_require_background_mask=mask_kwargs["shadow_require_background_mask"],
        shadow_target_dilate_px=mask_kwargs["shadow_target_dilate_px"],
        shadow_bridge_along_azimuth=mask_kwargs["shadow_bridge_along_azimuth"],
        shadow_bridge_length_px=mask_kwargs["shadow_bridge_length_px"],
        shadow_bridge_width_px=mask_kwargs["shadow_bridge_width_px"],
        target_center_roi_fraction=mask_kwargs["target_center_roi_fraction"],
        target_center_roi_min_keep_fraction=mask_kwargs["target_center_roi_min_keep_fraction"],
        shadow_use_azimuth_prior=mask_kwargs["shadow_use_azimuth_prior"],
        shadow_direction_offset_deg=mask_kwargs["shadow_direction_offset_deg"],
        shadow_azimuth_tolerance_deg=mask_kwargs["shadow_azimuth_tolerance_deg"],
        shadow_azimuth_direction_weight=mask_kwargs["shadow_azimuth_direction_weight"],
    )

    region_path = Path(visualize_scattering_regions(image, mask, str(out_dir), img_path.name, verbose=False))
    label_name = f"semantic_label_{img_path.stem}.png"
    cv2.imwrite(str(out_dir / label_name), _mask_label_png(mask))
    if save_npy:
        np.save(out_dir / f"semantic_mask_{img_path.stem}.npy", np.asarray(mask, dtype=np.int8))

    row = {
        "image": img_path.name,
        "path": str(img_path),
        "target_threshold": float(target_threshold),
        "background_threshold": float(background_threshold),
        "region_preview": region_path.name,
        "label_png": label_name,
        **_mask_stats(mask),
    }
    return row, np.asarray(mask, dtype=np.int8)


def _refresh_outputs_from_masks(
    rows: list[dict],
    masks_by_name: dict[str, np.ndarray],
    out_dir: Path,
    *,
    save_npy: bool,
) -> list[dict]:
    refreshed = []
    by_name = {row["image"]: row for row in rows}
    for image_name, row in by_name.items():
        mask = masks_by_name.get(image_name)
        if mask is None:
            refreshed.append(row)
            continue
        img_path = Path(row["path"])
        image = load_sar_grayscale_like_convert(str(img_path))
        region_path = Path(visualize_scattering_regions(image, mask, str(out_dir), image_name, verbose=False))
        enhanced = enhance_target_contrast_adaptive(image, mask)
        visualize_adaptive_threshold_effect(image, enhanced, mask, str(out_dir), image_name)
        label_name = f"semantic_label_{img_path.stem}.png"
        cv2.imwrite(str(out_dir / label_name), _mask_label_png(mask))
        if save_npy:
            np.save(out_dir / f"semantic_mask_{img_path.stem}.npy", np.asarray(mask, dtype=np.int8))
        refreshed.append(
            {
                **row,
                "region_preview": region_path.name,
                "label_png": label_name,
                **_mask_stats(mask),
            }
        )
    return refreshed


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Standalone target/shadow/background semantic region preview."
    )
    parser.add_argument("--data_dir", default="data/2S1", help="Dataset folder, for example data/2S1.")
    parser.add_argument("--image_subdir", default="input", help="Image subfolder under data_dir.")
    parser.add_argument("--image", default="", help="Single image path. Overrides data_dir.")
    parser.add_argument("--output_dir", default="", help="Output folder. Defaults to <data_dir>/semantic_region_preview.")
    parser.add_argument("--max_images", type=int, default=0, help="Limit number of images, 0 means all.")
    parser.add_argument("--azimuth", default="", help="Optional comma list, e.g. 021,041,358.")
    parser.add_argument("--save_npy", action=argparse.BooleanOptionalAction, default=True)
    register_semantic_mask_cli_args(parser)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    files = _image_files(args)
    if not files:
        raise SystemExit("No images found.")

    out_dir = _default_output_dir(args)
    out_dir.mkdir(parents=True, exist_ok=True)
    mask_kwargs = semantic_mask_kwargs_from_args(args)

    rows: list[dict] = []
    visualization_results: dict[str, dict] = {}
    for idx, img_path in enumerate(files, 1):
        row, mask = _run_one(img_path, out_dir, mask_kwargs, save_npy=bool(args.save_npy))
        rows.append(row)
        visualization_results[img_path.name] = {"scattering_mask": mask}
        print(
            f"[{idx}/{len(files)}] {img_path.name}: "
            f"target={row['target_total_pixels']} ({row['target_total_percent']:.2f}%), "
            f"shadow={row['shadow_pixels']} ({row['shadow_percent']:.2f}%), "
            f"background={row['background_pixels']} ({row['background_percent']:.2f}%)"
        )

    if mask_kwargs.get("shadow_dataset_consistency", True):
        visualization_results = apply_dataset_shadow_consistency_refinement(
            [str(p) for p in files],
            visualization_results,
            output_dir=str(out_dir),
            params=mask_kwargs,
        )
        masks_by_name = {
            name: np.asarray(vr["scattering_mask"], dtype=np.int8)
            for name, vr in visualization_results.items()
            if isinstance(vr, dict) and vr.get("scattering_mask") is not None
        }
        rows = _refresh_outputs_from_masks(rows, masks_by_name, out_dir, save_npy=bool(args.save_npy))

    csv_path = out_dir / "semantic_region_summary.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    _write_index(out_dir, rows)

    print(f"Saved semantic region preview: {out_dir}")
    print(f"Open: {out_dir / 'index.html'}")
    print(f"Summary: {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
