#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
点云缩放脚本 - 用于将高斯泼溅生成的点云缩放到合适尺寸进行对比
支持PLY格式点云文件的读取、缩放和保存
"""

import os
import sys
import numpy as np
import argparse
from pathlib import Path

def read_pointcloud_ply(ply_file):
    """读取PLY点云文件（支持ASCII和二进制格式）"""
    try:
        # 尝试使用plyfile库
        try:
            from plyfile import PlyData
            plydata = PlyData.read(ply_file)
            vertices = plydata['vertex']

            # 提取位置
            x = vertices['x']
            y = vertices['y']
            z = vertices['z']
            points = np.vstack([x, y, z]).T

            # 提取颜色（如果存在）
            try:
                r = vertices['red']
                g = vertices['green']
                b = vertices['blue']
                # 如果颜色是0-1范围，转换为0-255
                if r.max() <= 1.0:
                    colors = np.vstack([r, g, b]).T * 255.0
                    colors = colors.astype(np.uint8)
                else:
                    colors = np.vstack([r, g, b]).T.astype(np.uint8)
            except (KeyError, ValueError):
                # 如果没有颜色信息，使用默认颜色
                colors = np.ones((len(points), 3), dtype=np.uint8) * 128

            return points, colors
        except ImportError:
            # 如果plyfile不可用，尝试手动解析ASCII格式
            print("  警告: plyfile库不可用，尝试手动解析ASCII格式...")
            return read_pointcloud_ply_ascii(ply_file)
    except Exception as e:
        print(f"读取PLY文件失败: {e}")
        print("  尝试使用ASCII格式解析...")
        try:
            return read_pointcloud_ply_ascii(ply_file)
        except Exception as e2:
            print(f"ASCII格式解析也失败: {e2}")
            print("  请确保安装了plyfile库: pip install plyfile")
            return None, None

def read_pointcloud_ply_ascii(ply_file):
    """手动解析ASCII格式的PLY文件"""
    points = []
    colors = []

    with open(ply_file, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()

    # 查找vertex数量和格式
    vertex_count = 0
    header_end = 0
    is_ascii = False

    for i, line in enumerate(lines):
        line_lower = line.lower().strip()
        if 'format ascii' in line_lower:
            is_ascii = True
        if 'element vertex' in line_lower:
            vertex_count = int(line.split()[-1])
        if 'end_header' in line_lower:
            header_end = i + 1
            break

    if not is_ascii:
        raise ValueError("PLY文件不是ASCII格式，需要plyfile库来读取二进制格式")

    # 读取顶点数据
    for i in range(header_end, header_end + vertex_count):
        if i >= len(lines):
            break
        parts = lines[i].strip().split()
        if len(parts) >= 3:
            try:
                x, y, z = float(parts[0]), float(parts[1]), float(parts[2])
                points.append([x, y, z])

                # 尝试读取颜色
                if len(parts) >= 6:
                    r, g, b = int(float(parts[3])), int(float(parts[4])), int(float(parts[5]))
                    colors.append([r, g, b])
                else:
                    colors.append([128, 128, 128])  # 默认灰色
            except (ValueError, IndexError):
                continue

    if len(points) == 0:
        raise ValueError("未能读取任何点")

    return np.array(points), np.array(colors)

def calculate_bbox(points):
    """计算点云的边界框"""
    if points is None or len(points) == 0:
        return None

    min_coords = np.min(points, axis=0)
    max_coords = np.max(points, axis=0)

    # 计算尺寸（长宽高）
    dimensions = max_coords - min_coords

    # 计算对角线长度（作为整体尺寸参考）
    diagonal = np.linalg.norm(dimensions)

    return {
        'min': min_coords,
        'max': max_coords,
        'dimensions': dimensions,
        'diagonal': diagonal,
        'center': (min_coords + max_coords) / 2
    }

def scale_pointcloud(points, scale_factor, center=None):
    """缩放点云"""
    if points is None or len(points) == 0:
        return None

    # 如果没有指定中心点，使用点云中心
    if center is None:
        center = np.mean(points, axis=0)

    # 将点云平移到原点，缩放，然后平移回去
    scaled_points = (points - center) * scale_factor + center

    return scaled_points

def save_pointcloud_ply(points, colors, output_file, original_header=None):
    """保存点云到PLY文件"""
    try:
        from plyfile import PlyData, PlyElement
    except ImportError:
        print("警告: plyfile库不可用，将保存为ASCII格式的PLY文件")
        return save_pointcloud_ply_ascii(points, colors, output_file)

    if points is None or len(points) == 0:
        print("错误: 没有点云数据可保存")
        return False

    # 创建顶点数据结构
    vertex_data = np.empty(len(points), dtype=[
        ('x', 'f4'), ('y', 'f4'), ('z', 'f4'),
        ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')
    ])

    vertex_data['x'] = points[:, 0].astype('f4')
    vertex_data['y'] = points[:, 1].astype('f4')
    vertex_data['z'] = points[:, 2].astype('f4')

    if colors is not None and len(colors) == len(points):
        vertex_data['red'] = colors[:, 0].astype('u1')
        vertex_data['green'] = colors[:, 1].astype('u1')
        vertex_data['blue'] = colors[:, 2].astype('u1')
    else:
        # 使用默认颜色
        vertex_data['red'] = np.full(len(points), 128, dtype='u1')
        vertex_data['green'] = np.full(len(points), 128, dtype='u1')
        vertex_data['blue'] = np.full(len(points), 128, dtype='u1')

    # 创建PLY元素
    vertex_element = PlyElement.describe(vertex_data, 'vertex')

    # 保存PLY文件
    PlyData([vertex_element]).write(output_file)
    return True

def save_pointcloud_ply_ascii(points, colors, output_file):
    """保存点云为ASCII格式的PLY文件"""
    if points is None or len(points) == 0:
        print("错误: 没有点云数据可保存")
        return False

    with open(output_file, 'w') as f:
        # 写入PLY头部
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"element vertex {len(points)}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        f.write("property uchar red\n")
        f.write("property uchar green\n")
        f.write("property uchar blue\n")
        f.write("end_header\n")

        # 写入顶点数据
        for i, point in enumerate(points):
            x, y, z = point
            if colors is not None and len(colors) > i:
                r, g, b = colors[i]
            else:
                r, g, b = 128, 128, 128

            f.write(".6f")

    return True

def analyze_t72_tank_dimensions():
    """T72坦克的典型尺寸（米）"""
    # T72坦克的典型尺寸
    t72_specs = {
        'length': 9.53,      # 全长（米）
        'width': 3.59,       # 全宽（米）
        'height': 2.23,      # 全高（米）
        'turret_length': 2.0, # 炮塔长度（近似）
        'turret_width': 3.0,  # 炮塔宽度（近似）
        'turret_height': 0.8  # 炮塔高度（近似）
    }

    print("\n" + "="*60)
    print("T72坦克典型尺寸参考:")
    print("="*60)
    print(".2f")
    print(".2f")
    print(".2f")
    print("炮塔尺寸（近似）:")
    print(".2f")
    print(".2f")
    print(".2f")
    # 计算对角线长度作为参考
    diagonal = np.sqrt(t72_specs['length']**2 + t72_specs['width']**2 + t72_specs['height']**2)
    print(".2f")
    return t72_specs

def main():
    parser = argparse.ArgumentParser(description='点云缩放工具 - 用于对比高斯泼溅结果与真实模型')
    parser.add_argument('--input', '-i', type=str, required=True,
                       help='输入PLY点云文件路径')
    parser.add_argument('--output', '-o', type=str,
                       help='输出缩放后PLY文件路径（可选，默认在输入文件同目录生成）')
    parser.add_argument('--target_size', '-s', type=float,
                       help='目标尺寸（米），将点云缩放到此对角线长度')
    parser.add_argument('--scale_factor', '-f', type=float,
                       help='直接指定缩放倍数')
    parser.add_argument('--analyze_only', '-a', action='store_true',
                       help='仅分析点云尺寸，不进行缩放')
    parser.add_argument('--t72_compare', '-t', action='store_true',
                       help='与T72坦克尺寸进行对比分析')

    args = parser.parse_args()

    input_file = args.input

    if not os.path.exists(input_file):
        print(f"错误: 输入文件不存在: {input_file}")
        return

    print("="*70)
    print("点云缩放工具 - 高斯泼溅结果对比分析")
    print("="*70)
    print(f"输入文件: {input_file}")

    # 读取点云
    print("\n📂 读取点云文件...")
    points, colors = read_pointcloud_ply(input_file)

    if points is None:
        print("❌ 无法读取点云文件")
        return

    print(f"   点数: {len(points)}")

    # 计算边界框
    bbox = calculate_bbox(points)

    if bbox is None:
        print("❌ 无法计算点云边界框")
        return

    print("\n📊 点云尺寸分析:")
    print("-"*40)
    print(".2f")
    print(".2f")
    print(".2f")
    print(".2f")
    print(".2f")
    print(".2f")
    print(".2f")
    # 如果要与T72对比，显示T72尺寸
    if args.t72_compare:
        t72_specs = analyze_t72_tank_dimensions()

        print("\n🔍 尺寸对比分析:")
        print("-"*40)

        # 计算缩放因子以匹配T72坦克尺寸
        current_diagonal = bbox['diagonal']
        t72_diagonal = np.sqrt(t72_specs['length']**2 + t72_specs['width']**2 + t72_specs['height']**2)

        scale_to_t72 = t72_diagonal / current_diagonal

        print(".2f")
        print(".2f")
        print(".2f")
        print(".2f")
        # 显示缩放后的尺寸
        scaled_dimensions = bbox['dimensions'] * scale_to_t72
        print(".2f")
        # 如果没有指定缩放参数，建议使用T72缩放因子
        if not args.scale_factor and not args.target_size:
            args.scale_factor = scale_to_t72
            print(".4f")
    # 如果仅分析，不进行缩放
    if args.analyze_only:
        print("\n✅ 分析完成（未进行缩放）")
        return

    # 确定缩放因子
    scale_factor = 1.0

    if args.scale_factor:
        scale_factor = args.scale_factor
        print(f"\n🔧 使用指定缩放倍数: {scale_factor}")
    elif args.target_size:
        current_diagonal = bbox['diagonal']
        scale_factor = args.target_size / current_diagonal
        print(".2f")
        print(".4f")
    else:
        print("\n⚠️  未指定缩放参数，使用默认缩放倍数1.0（不缩放）")
        print("   使用 --scale_factor 或 --target_size 指定缩放参数")

    # 应用缩放
    print(f"\n🔄 应用缩放倍数 {scale_factor}...")
    scaled_points = scale_pointcloud(points, scale_factor, bbox['center'])

    if scaled_points is None:
        print("❌ 缩放失败")
        return

    # 计算缩放后的边界框
    scaled_bbox = calculate_bbox(scaled_points)

    print("✅ 缩放完成")
    print("\n📊 缩放后尺寸:")
    print("-"*40)
    print(".2f")
    print(".2f")
    print(".2f")
    print(".2f")
    # 确定输出文件路径
    if args.output:
        output_file = args.output
    else:
        input_path = Path(input_file)
        output_file = input_path.parent / f"{input_path.stem}_scaled{input_path.suffix}"

    print(f"\n💾 保存缩放后点云到: {output_file}")

    # 保存点云
    success = save_pointcloud_ply(scaled_points, colors, str(output_file))

    if success:
        print("✅ 点云保存成功")
    else:
        print("❌ 点云保存失败")

    print("\n" + "="*70)
    print("处理完成")
    print("="*70)

if __name__ == '__main__':
    main()
