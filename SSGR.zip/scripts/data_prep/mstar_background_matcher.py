#!/usr/bin/env python3
"""Build and sample real MSTAR background patches.

The generated SAR target should not rely on a purely synthetic 3D background.
This utility extracts background-only patches from real images using semantic
masks (0=background, 1=target, 2=edge, 3=shadow), groups them by azimuth, and
can sample a statistically matched background canvas for novel-view renders.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
from pathlib import Path
from typing import Any


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
np = None
Image = None


def _require_numpy():
    global np
    if np is None:
        import numpy as _np

        np = _np
    return np


def _require_pillow():
    global Image
    if Image is None:
        from PIL import Image as _Image

        Image = _Image
    return Image


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _load_gray(path: Path) -> np.ndarray:
    _require_numpy()
    _require_pillow()
    img = Image.open(path).convert("L")
    arr = np.asarray(img, dtype=np.float32) / 255.0
    return arr


def _save_gray(path: Path, arr: np.ndarray) -> None:
    _require_numpy()
    _require_pillow()
    path.parent.mkdir(parents=True, exist_ok=True)
    out = np.clip(arr, 0.0, 1.0)
    Image.fromarray((out * 255.0 + 0.5).astype(np.uint8), mode="L").save(path)


def _parse_angles(name: str) -> tuple[str | None, float | None, float | None]:
    try:
        import sys

        root = str(_repo_root())
        if root not in sys.path:
            sys.path.insert(0, root)
        from sar_utils import parse_mstar_filename_quiet

        target, dep, az = parse_mstar_filename_quiet(name)
        if target is None:
            return None, None, None
        return str(target), float(dep), float(az) % 360.0
    except Exception:
        return None, None, None


def _angle_dist(a: float, b: float) -> float:
    return abs(((float(a) - float(b) + 180.0) % 360.0) - 180.0)


def _azimuth_bin(azimuth: float | None, bin_deg: float) -> str:
    if azimuth is None:
        return "unknown"
    b = int(round((float(azimuth) % 360.0) / max(bin_deg, 1e-6))) % int(round(360.0 / bin_deg))
    center = (b * bin_deg) % 360.0
    return f"az_{int(round(center)):03d}"


def _resolve_latest_masks(source: Path, images_dir: Path, masks_dir: Path | None) -> Path:
    if masks_dir is not None:
        return masks_dir
    import sys

    root = str(_repo_root())
    if root not in sys.path:
        sys.path.insert(0, root)
    from sar.semantic_mask_config import resolve_convert_masks_run_dir

    resolved = resolve_convert_masks_run_dir(str(source), run_id="latest")
    if resolved:
        return Path(resolved)
    fallback = source / "scattering_masks"
    if fallback.is_dir():
        return fallback
    raise FileNotFoundError(
        "No masks directory found. Run convert/train mask generation first or pass --masks-dir."
    )


def _find_images(images_dir: Path) -> list[Path]:
    return sorted(p for p in images_dir.iterdir() if p.suffix.lower() in IMAGE_EXTS)


def _load_mask(masks_dir: Path, image_path: Path) -> np.ndarray | None:
    stem = image_path.stem
    candidates = [
        masks_dir / f"{stem}_mask.npy",
        masks_dir / f"{stem}.npy",
        masks_dir / f"{stem}_scattering_mask.npy",
    ]
    for p in candidates:
        if p.is_file():
            return np.asarray(np.load(p), dtype=np.int8)
    return None


def _patch_is_good(mask_patch: np.ndarray, min_bg_fraction: float) -> bool:
    return float(np.mean(mask_patch == 0)) >= float(min_bg_fraction)


def _patch_stats(patch: np.ndarray) -> dict[str, float]:
    return {
        "mean": float(np.mean(patch)),
        "std": float(np.std(patch)),
        "p05": float(np.percentile(patch, 5)),
        "p50": float(np.percentile(patch, 50)),
        "p95": float(np.percentile(patch, 95)),
    }


def build_library(args: argparse.Namespace) -> None:
    _require_numpy()
    source = Path(args.source).resolve()
    images_dir = (source / args.images).resolve() if not Path(args.images).is_absolute() else Path(args.images)
    masks_dir = _resolve_latest_masks(source, images_dir, Path(args.masks_dir).resolve() if args.masks_dir else None)
    out_dir = Path(args.output).resolve()
    patch_dir = out_dir / "patches"
    patch_dir.mkdir(parents=True, exist_ok=True)

    rng = random.Random(int(args.seed))
    images = _find_images(images_dir)
    records: list[dict[str, Any]] = []

    for image_path in images:
        mask = _load_mask(masks_dir, image_path)
        if mask is None:
            print(f"[skip] no mask for {image_path.name}")
            continue
        img = _load_gray(image_path)
        if mask.shape != img.shape:
            mask_img = Image.fromarray(mask.astype(np.uint8), mode="L").resize(
                (img.shape[1], img.shape[0]), resample=Image.NEAREST
            )
            mask = np.asarray(mask_img, dtype=np.int8)

        target, dep, az = _parse_angles(image_path.name)
        bin_name = _azimuth_bin(az, float(args.azimuth_bin_deg))
        h, w = img.shape
        ps = min(int(args.patch_size), h, w)
        if ps <= 4:
            continue

        accepted = 0
        attempts = max(int(args.max_attempts_per_image), int(args.patches_per_image) * 10)
        for _ in range(attempts):
            if accepted >= int(args.patches_per_image):
                break
            y = rng.randint(0, h - ps)
            x = rng.randint(0, w - ps)
            mp = mask[y : y + ps, x : x + ps]
            if not _patch_is_good(mp, float(args.min_background_fraction)):
                continue
            patch = img[y : y + ps, x : x + ps].copy()
            rec_id = f"{image_path.stem}_{accepted:03d}_{y:03d}_{x:03d}"
            rel = Path("patches") / bin_name / f"{rec_id}.png"
            _save_gray(out_dir / rel, patch)
            rec = {
                "path": str(rel).replace("\\", "/"),
                "source_image": image_path.name,
                "target": target,
                "depression": dep,
                "azimuth": az,
                "azimuth_bin": bin_name,
                "x": x,
                "y": y,
                "size": ps,
                **_patch_stats(patch),
            }
            records.append(rec)
            accepted += 1

        print(f"[build] {image_path.name}: accepted {accepted}")

    meta = {
        "source": str(source),
        "images_dir": str(images_dir),
        "masks_dir": str(masks_dir),
        "azimuth_bin_deg": float(args.azimuth_bin_deg),
        "patch_size": int(args.patch_size),
        "count": len(records),
        "records": records,
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "background_library.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    print(f"[done] saved {len(records)} patches to {out_dir}")


def _load_library(path: Path) -> dict[str, Any]:
    meta_path = path / "background_library.json" if path.is_dir() else path
    with open(meta_path, encoding="utf-8") as f:
        meta = json.load(f)
    meta["_root"] = str(meta_path.parent)
    return meta


def _choose_records(meta: dict[str, Any], azimuth: float | None, k: int) -> list[dict[str, Any]]:
    records = list(meta.get("records", []))
    if not records:
        raise RuntimeError("Background library is empty.")
    if azimuth is None:
        return random.sample(records, k=min(k, len(records)))
    ranked = sorted(
        records,
        key=lambda r: _angle_dist(float(r["azimuth"]), azimuth) if r.get("azimuth") is not None else 999.0,
    )
    pool = ranked[: max(k * 4, 12)]
    return random.sample(pool, k=min(k, len(pool)))


def _tile_canvas(patches: list[np.ndarray], height: int, width: int, rng: random.Random) -> np.ndarray:
    canvas = np.zeros((height, width), dtype=np.float32)
    weight = np.zeros((height, width), dtype=np.float32)
    for patch in patches:
        ph, pw = patch.shape
        if ph > height or pw > width:
            patch_img = Image.fromarray((patch * 255.0).astype(np.uint8), mode="L").resize((width, height))
            patch = np.asarray(patch_img, dtype=np.float32) / 255.0
            ph, pw = patch.shape
        y = rng.randint(0, max(0, height - ph))
        x = rng.randint(0, max(0, width - pw))
        canvas[y : y + ph, x : x + pw] += patch
        weight[y : y + ph, x : x + pw] += 1.0
    missing = weight <= 0
    if np.any(missing):
        fill = float(np.mean(canvas[weight > 0] / np.maximum(weight[weight > 0], 1e-6))) if np.any(~missing) else 0.0
        canvas[missing] = fill
        weight[missing] = 1.0
    return canvas / np.maximum(weight, 1e-6)


def sample_background(args: argparse.Namespace) -> None:
    _require_numpy()
    meta = _load_library(Path(args.library).resolve())
    rng = random.Random(int(args.seed))
    records = _choose_records(meta, float(args.azimuth) % 360.0 if args.azimuth is not None else None, int(args.tiles))
    patches = [_load_gray(Path(meta["_root"]) / rec["path"]) for rec in records]
    canvas = _tile_canvas(patches, int(args.height), int(args.width), rng)
    if float(args.speckle_sigma) > 0.0:
        noise = np.random.default_rng(int(args.seed)).lognormal(
            mean=-0.5 * float(args.speckle_sigma) ** 2,
            sigma=float(args.speckle_sigma),
            size=canvas.shape,
        )
        canvas = np.clip(canvas * noise.astype(np.float32), 0.0, 1.0)
    _save_gray(Path(args.output).resolve(), canvas)
    print(f"[done] sampled background: {args.output}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build", help="extract background-only patches from real MSTAR images")
    b.add_argument("--source", required=True, help="dataset root, e.g. data/T72")
    b.add_argument("--images", default="images", help="image folder or folder name under source")
    b.add_argument("--masks-dir", default=None, help="directory containing *_mask.npy; default latest from_convert")
    b.add_argument("--output", required=True, help="output background library directory")
    b.add_argument("--patch-size", type=int, default=64)
    b.add_argument("--patches-per-image", type=int, default=8)
    b.add_argument("--max-attempts-per-image", type=int, default=160)
    b.add_argument("--min-background-fraction", type=float, default=0.96)
    b.add_argument("--azimuth-bin-deg", type=float, default=15.0)
    b.add_argument("--seed", type=int, default=1234)
    b.set_defaults(func=build_library)

    s = sub.add_parser("sample", help="sample a background canvas near a requested azimuth")
    s.add_argument("--library", required=True, help="background library directory or json")
    s.add_argument("--output", required=True)
    s.add_argument("--width", type=int, default=128)
    s.add_argument("--height", type=int, default=128)
    s.add_argument("--azimuth", type=float, default=None)
    s.add_argument("--tiles", type=int, default=12)
    s.add_argument("--speckle-sigma", type=float, default=0.18)
    s.add_argument("--seed", type=int, default=1234)
    s.set_defaults(func=sample_background)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
