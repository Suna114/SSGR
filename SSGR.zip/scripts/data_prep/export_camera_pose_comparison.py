# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
导出并对比三类相机位姿，便于在 COLMAP / 数值上排查「渲染位姿 vs 原始稀疏」差异：

1) COLMAP 稀疏模型（sparse/0/images.bin 或 .txt）中的 qvec/tvec → 相机中心 C_raw
2) 3DGS 加载后的训练相机（Scene）→ camera_center（应与 1 一致，除非有额外变换）
3) render_novel_sar_views 在 colmap_ring 模式下使用的中位数环参数 + 若干示例方位角上的合成位姿

输出目录（默认 model_path/camera_pose_comparison）：
  - per_image_comparison.csv / .json
  - summary.txt
  - novel_ring_params.json（median r_xz、median Y、与渲染脚本一致）
  - sample_novel_poses.json（示例新视角：相机中心 + 说明）
  - optional: synthetic_views_for_colmap.txt（COLMAP images.txt 片段，可拷贝到独立模型做可视化）

用法:
    python export_camera_pose_comparison.py -m ./output/125 --iteration 45000
    python export_camera_pose_comparison.py -m ./output/125 --iteration 45000 -o ./pose_cmp
"""

from __future__ import annotations

import csv
import json
import os
import sys
from argparse import ArgumentParser
from pathlib import Path

import numpy as np

from scene import Scene, GaussianModel
from scene.colmap_loader import (
    qvec2rotmat,
    read_extrinsics_binary,
    read_extrinsics_text,
    rotmat2qvec,
)
from utils.general_utils import safe_state
from arguments import ModelParams, PipelineParams, get_combined_args

try:
    from sar_geometry import pradar_to_world_to_camera_rt
except ImportError:
    pradar_to_world_to_camera_rt = None

try:
    from sar_utils import parse_mstar_filename as _parse_mstar_filename
except ImportError:
    _parse_mstar_filename = None

# 与 render_novel_sar_views 一致
from render_novel_sar_views import (
    estimate_median_ring_from_colmap_train_cameras,
    ring_world_position_from_colmap_median_ring,
)


def camera_center_from_colmap_qvec_tvec(qvec, tvec) -> np.ndarray:
    """COLMAP: x_cam = R_w2c * X_world + t，相机中心 C = -R_w2c^T * t"""
    R_w2c = qvec2rotmat(qvec)
    t = np.asarray(tvec).reshape(3, 1)
    C = -R_w2c.T @ t
    return C.flatten()


def camera_R_w2c_from_scene_camera(cam) -> np.ndarray:
    """Scene.Camera: R 存为 cam-to-world，故 world-to-camera 旋转为 R^T"""
    R_c2w = np.asarray(cam.R, dtype=np.float64)
    return R_c2w.T


def load_colmap_images_dict(source_path: str) -> dict:
    sparse = os.path.join(source_path, "sparse", "0")
    bin_path = os.path.join(sparse, "images.bin")
    txt_path = os.path.join(sparse, "images.txt")
    if os.path.isfile(bin_path):
        return read_extrinsics_binary(bin_path)
    if os.path.isfile(txt_path):
        return read_extrinsics_text(txt_path)
    raise FileNotFoundError(f"未找到 {bin_path} 或 {txt_path}")


def frobenius_angle_deg(R_a: np.ndarray, R_b: np.ndarray) -> float:
    """粗略用 F 范数换算旋转差异（度）。"""
    d = np.linalg.norm(R_a - R_b, "fro")
    # 粗略：小角度近似
    return float(np.rad2deg(d / np.sqrt(2)))


def main():
    parser = ArgumentParser(description="COLMAP vs Scene vs 新视角环 位姿对比导出")
    model = ModelParams(parser, sentinel=True)
    pipeline = PipelineParams(parser)
    parser.add_argument("--iteration", type=int, default=-1, help="加载迭代（-1=最新）")
    parser.add_argument(
        "-o",
        "--output_dir",
        type=str,
        default=None,
        help="输出目录（默认: model_path/camera_pose_comparison）",
    )
    parser.add_argument("--quiet", action="store_true")
    args = get_combined_args(parser)
    safe_state(args.quiet)

    model_params = model.extract(args)
    source_path = getattr(model_params, "source_path", None) or ""
    if not source_path or not os.path.isdir(source_path):
        print("❌ cfg 中 source_path 无效或目录不存在")
        sys.exit(1)

    out = args.output_dir
    if out is None:
        out = os.path.join(model_params.model_path, "camera_pose_comparison")
    output_dir = Path(out)
    output_dir.mkdir(parents=True, exist_ok=True)

    print("加载 COLMAP 稀疏 images …")
    colmap_images = load_colmap_images_dict(source_path)
    # name -> extrinsic Image
    by_name = {img.name: img for img in colmap_images.values()}

    print("加载 Scene / 训练相机 …")
    gaussians = GaussianModel(model_params.sh_degree)
    scene = Scene(model_params, gaussians, load_iteration=args.iteration, shuffle=False)
    train_cams = list(scene.getTrainCameras(1.0) or [])

    rows = []
    per_image = []

    for cam in train_cams:
        name = cam.image_name
        center_scene = cam.camera_center.detach().cpu().numpy().reshape(3)
        R_w2c_scene = camera_R_w2c_from_scene_camera(cam)
        t_scene = np.asarray(cam.T, dtype=np.float64).reshape(3)

        rec = {
            "image_name": name,
            "colmap_id": int(cam.colmap_id),
            "center_scene_x": float(center_scene[0]),
            "center_scene_y": float(center_scene[1]),
            "center_scene_z": float(center_scene[2]),
            "tvec_scene_tx": float(t_scene[0]),
            "tvec_scene_ty": float(t_scene[1]),
            "tvec_scene_tz": float(t_scene[2]),
        }

        if name not in by_name:
            rec["match_colmap"] = False
            rec["note"] = "sparse/0 中无同名图像"
            rows.append(rec)
            per_image.append({**rec})
            continue

        im = by_name[name]
        center_raw = camera_center_from_colmap_qvec_tvec(im.qvec, im.tvec)
        R_w2c_raw = qvec2rotmat(im.qvec)
        t_raw = np.asarray(im.tvec, dtype=np.float64).reshape(3)

        diff_c = center_raw - center_scene
        diff_norm = float(np.linalg.norm(diff_c))
        azi_geom = float(
            np.rad2deg(np.arctan2(center_raw[2], center_raw[0]))
        )
        rec["azimuth_from_center_xz_deg"] = azi_geom
        if _parse_mstar_filename is not None:
            try:
                _d, azi_fn = _parse_mstar_filename(name)
                rec["depression_from_filename"] = float(_d)
                rec["azimuth_from_filename_deg"] = float(azi_fn)
                rec["azimuth_filename_minus_geom_deg"] = float(azi_fn) - azi_geom
            except Exception:
                pass

        rec.update(
            {
                "match_colmap": True,
                "center_raw_x": float(center_raw[0]),
                "center_raw_y": float(center_raw[1]),
                "center_raw_z": float(center_raw[2]),
                "tvec_raw_tx": float(t_raw[0]),
                "tvec_raw_ty": float(t_raw[1]),
                "tvec_raw_tz": float(t_raw[2]),
                "diff_center_x": float(diff_c[0]),
                "diff_center_y": float(diff_c[1]),
                "diff_center_z": float(diff_c[2]),
                "diff_center_norm": diff_norm,
                "fro_R_w2c_deg_approx": frobenius_angle_deg(R_w2c_raw, R_w2c_scene),
            }
        )
        rows.append(rec)
        per_image.append(
            {
                **rec,
                "qvec_raw": im.qvec.tolist(),
                "R_w2c_raw": R_w2c_raw.tolist(),
                "R_w2c_scene": R_w2c_scene.tolist(),
            }
        )

    # 与 render_novel_sar_views colmap_ring 一致的中位数环
    r_xz, y_med, C_all = estimate_median_ring_from_colmap_train_cameras(train_cams)
    novel_ring = {
        "median_r_xz": r_xz,
        "median_Y_world": y_med,
        "num_train_cameras": len(train_cams),
        "mean_camera_distance": float(np.mean(np.linalg.norm(C_all, axis=1))),
    }
    with open(output_dir / "novel_ring_params.json", "w", encoding="utf-8") as f:
        json.dump(novel_ring, f, indent=2, ensure_ascii=False)

    # 示例新视角（与渲染脚本相同公式）
    sample_novel = []
    if pradar_to_world_to_camera_rt is not None:
        for dep in (15.0, 17.0):
            for azi in (0.0, 90.0, 180.0, 270.0):
                P = ring_world_position_from_colmap_median_ring(r_xz, y_med, azi)
                azi_rad = np.deg2rad(azi)
                R_w2r, t = pradar_to_world_to_camera_rt(P, azi_rad)
                # 与 Camera 一致：光学相机中心 = -R_w2c^T t，此处 R_w2c 对应 R_world_to_radar
                C_est = (-np.asarray(R_w2r).T @ np.asarray(t).reshape(3, 1)).flatten()
                sample_novel.append(
                    {
                        "label": f"median_ring_dep{dep}_azi{azi:.0f}",
                        "depression_deg_for_metadata": dep,
                        "azimuth_deg_pose": azi,
                        "P_world_radar": P.flatten().tolist(),
                        "camera_center_estimated": C_est.tolist(),
                        "center_minus_P_norm": float(np.linalg.norm(C_est - P.flatten())),
                    }
                )
        with open(output_dir / "sample_novel_poses.json", "w", encoding="utf-8") as f:
            json.dump(sample_novel, f, indent=2, ensure_ascii=False)

    # CSV（合并所有列名，避免首行缺列）
    csv_path = output_dir / "per_image_comparison.csv"
    if rows:
        keys = sorted(set().union(*(r.keys() for r in rows)))
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            for row in rows:
                w.writerow({k: row.get(k, "") for k in keys})

    with open(output_dir / "per_image_comparison_full.json", "w", encoding="utf-8") as f:
        json.dump(per_image, f, indent=2, ensure_ascii=False)

    # Summary
    matched = [r for r in rows if r.get("match_colmap")]
    if matched:
        norms = [r["diff_center_norm"] for r in matched]
        summary_lines = [
            "相机位姿对比摘要（训练视角）",
            "=" * 60,
            f"source_path (COLMAP): {source_path}",
            f"model_path: {model_params.model_path}",
            f"训练相机数: {len(train_cams)}",
            f"与 sparse 按文件名匹配: {len(matched)} / {len(train_cams)}",
            f"相机中心差 ||C_raw - C_scene||: max={max(norms):.6g}, mean={np.mean(norms):.6g}",
            "",
            "若 max/mean 接近 0：说明 3DGS 加载的 R|T 与 COLMAP 一致。",
            "若明显非 0：检查是否改过 sparse、或数据集读取与磁盘不一致。",
            "",
            "median 环（与 render_novel_sar_views colmap_ring 一致）:",
            f"  median(r_xz)={r_xz:.8g}",
            f"  median(Y)={y_med:.8g}",
            "",
            "在 COLMAP GUI 中对比：可打开原始 sparse/0；合成视角见 synthetic_views_for_colmap.txt 说明。",
        ]
    else:
        summary_lines = ["无匹配项，请检查 image 文件名是否与 sparse 一致。"]

    with open(output_dir / "summary.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(summary_lines) + "\n")

    # COLMAP 片段：从 Scene 相机写回 qvec/tvec（应与磁盘一致），便于单独导入查看
    lines_out = [
        "# 由 export_camera_pose_comparison 从 Scene 相机导出（应与原 COLMAP 一致）",
        "# 格式: IMAGE_ID QW QX QY QZ TX TY TZ CAMERA_ID NAME",
        "# 第二行 POINTS2D 省略（仅位姿可视化时可尝试导入；完整模型请用原 images.txt）",
    ]
    # 取前 3 个示例
    for cam in train_cams[: min(3, len(train_cams))]:
        if cam.image_name not in by_name:
            continue
        im0 = by_name[cam.image_name]
        R_w2c = camera_R_w2c_from_scene_camera(cam)
        tvec = np.asarray(cam.T, dtype=np.float64).reshape(3)
        qvec = rotmat2qvec(R_w2c)
        nm = cam.image_name.replace(" ", "_")
        lines_out.append(
            f"# {nm}: IMAGE_ID={im0.id}, CAMERA_ID={im0.camera_id}（应与 sparse/images 中该行一致）"
        )
        lines_out.append(
            f"{int(im0.id)} {qvec[0]} {qvec[1]} {qvec[2]} {qvec[3]} "
            f"{tvec[0]} {tvec[1]} {tvec[2]} {int(im0.camera_id)} {cam.image_name}"
        )
        lines_out.append("")  # POINTS2D 行省略；完整模型请用原 images.txt

    with open(output_dir / "synthetic_views_for_colmap.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lines_out) + "\n")
        f.write(
            "\n# 使用说明：\n"
            "# - 主要对比请用 per_image_comparison.csv 中的 diff_center_norm\n"
            "# - 若要在 COLMAP 看「中位数环」上的虚拟相机，可复制 sample_novel_poses.json 中的 P_world，\n"
            "#   用脚本或手动构造 qvec/tvec；完整自动写入需额外 CAMERA_ID 与 cameras.txt 一致。\n"
        )

    print("\n".join(summary_lines))
    print(f"\n✅ 已写入: {output_dir.absolute()}")


if __name__ == "__main__":
    main()
