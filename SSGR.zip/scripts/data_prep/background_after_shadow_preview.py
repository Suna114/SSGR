#!/usr/bin/env python3
"""Standalone preview for MSTAR-like background composition.

This script tests the background-after-shadow step without rerunning the full
novel-view pipeline.  It samples real background patches from semantic
background pixels (mask == 0), matches simple image statistics, and composites
the sampled background behind an existing target/shadow render.
"""

from __future__ import annotations

import argparse
import html
import json
import math
import random
import re
import sys
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def _repo_root() -> Path:
    for parent in Path(__file__).resolve().parents:
        if (parent / "train.py").is_file():
            return parent
    return Path(__file__).resolve().parents[2]


ROOT = _repo_root()
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _image_files(path: Path) -> list[Path]:
    if not path.is_dir():
        return []
    return sorted(p for p in path.iterdir() if p.suffix.lower() in IMAGE_EXTS)


def _load_gray(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("L"), dtype=np.float32) / 255.0


def _save_gray(path: Path, arr: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    out = np.clip(arr, 0.0, 1.0)
    Image.fromarray((out * 255.0 + 0.5).astype(np.uint8), mode="L").save(path)


def _resize_float(arr: np.ndarray, shape_hw: tuple[int, int], *, nearest: bool = False) -> np.ndarray:
    h, w = shape_hw
    if tuple(arr.shape[:2]) == (h, w):
        return arr
    mode = Image.NEAREST if nearest else Image.BILINEAR
    img = Image.fromarray(np.asarray(arr, dtype=np.float32))
    return np.asarray(img.resize((w, h), resample=mode), dtype=np.float32)


def _parse_azimuth(path_or_name: Path | str) -> float:
    name = Path(path_or_name).name
    stem = Path(name).stem
    m = re.search(r"(?:^|[_-])azimuth[_-]?(\d+(?:\.\d+)?)", stem, flags=re.IGNORECASE)
    if m:
        return float(m.group(1)) % 360.0
    m = re.search(r"^azimuth[_-]?(\d+(?:\.\d+)?)$", stem, flags=re.IGNORECASE)
    if m:
        return float(m.group(1)) % 360.0
    try:
        from sar_utils import parse_mstar_filename_quiet

        _target, _dep, az = parse_mstar_filename_quiet(name)
        if az is not None:
            return float(az) % 360.0
    except Exception:
        pass
    nums = re.findall(r"(?<!\d)(\d{1,3})(?!\d)", stem)
    if nums:
        return float(nums[-1]) % 360.0
    return 0.0


def _parse_label_set(text: str) -> set[int]:
    labels: set[int] = set()
    for part in str(text or "").split(","):
        part = part.strip()
        if not part:
            continue
        labels.add(int(part))
    return labels


def _angle_dist(a: float, b: float) -> float:
    return abs(((float(a) - float(b) + 180.0) % 360.0) - 180.0)


def _dilate(mask: np.ndarray, px: int) -> np.ndarray:
    px = int(px)
    if px <= 0:
        return mask.astype(np.float32)
    try:
        import cv2

        kernel = np.ones((px * 2 + 1, px * 2 + 1), dtype=np.uint8)
        return cv2.dilate((mask > 0.5).astype(np.uint8), kernel, iterations=1).astype(np.float32)
    except Exception:
        out = mask > 0.5
        for _ in range(px):
            padded = np.pad(out, 1, mode="edge")
            acc = np.zeros_like(out)
            for dy in range(3):
                for dx in range(3):
                    acc |= padded[dy : dy + out.shape[0], dx : dx + out.shape[1]]
            out = acc
        return out.astype(np.float32)


def _shift_mask(mask: np.ndarray, dy: int, dx: int) -> np.ndarray:
    h, w = mask.shape
    out = np.zeros_like(mask, dtype=np.float32)
    src_y0 = max(0, -dy)
    src_y1 = min(h, h - dy)
    src_x0 = max(0, -dx)
    src_x1 = min(w, w - dx)
    dst_y0 = max(0, dy)
    dst_y1 = min(h, h + dy)
    dst_x0 = max(0, dx)
    dst_x1 = min(w, w + dx)
    if src_y1 > src_y0 and src_x1 > src_x0:
        out[dst_y0:dst_y1, dst_x0:dst_x1] = mask[src_y0:src_y1, src_x0:src_x1]
    return out


def _directional_grow(mask: np.ndarray, angle_deg: float, px: int) -> np.ndarray:
    px = int(px)
    if px <= 0:
        return mask.astype(np.float32)
    rad = math.radians(float(angle_deg))
    dx = int(round(math.cos(rad)))
    dy = int(round(math.sin(rad)))
    if dx == 0 and dy == 0:
        return mask.astype(np.float32)
    out = mask.astype(np.float32)
    cur = mask.astype(np.float32)
    for _ in range(px):
        cur = _shift_mask(cur, dy, dx)
        out = np.maximum(out, cur)
    return out.astype(np.float32)


def _blur(mask: np.ndarray, radius: int) -> np.ndarray:
    radius = int(radius)
    if radius <= 0:
        return np.clip(mask.astype(np.float32), 0.0, 1.0)
    try:
        import cv2

        k = radius * 2 + 1
        return np.clip(cv2.GaussianBlur(mask.astype(np.float32), (k, k), 0), 0.0, 1.0)
    except Exception:
        pad = radius
        padded = np.pad(mask.astype(np.float32), pad, mode="edge")
        out = np.zeros_like(mask, dtype=np.float32)
        n = 0
        for dy in range(2 * radius + 1):
            for dx in range(2 * radius + 1):
                out += padded[dy : dy + mask.shape[0], dx : dx + mask.shape[1]]
                n += 1
        return np.clip(out / max(n, 1), 0.0, 1.0)


def _resolve_masks_dir(data_dir: Path | None, masks_dir: Path | None) -> Path | None:
    if masks_dir is not None:
        return masks_dir
    if data_dir is None:
        return None
    try:
        from sar.semantic_mask_config import resolve_convert_masks_run_dir

        resolved = resolve_convert_masks_run_dir(str(data_dir), run_id="latest")
        if resolved:
            return Path(resolved)
    except Exception:
        pass
    fallback = data_dir / "scattering_masks"
    return fallback if fallback.is_dir() else None


def _load_semantic_mask(masks_dir: Path | None, image_path: Path, shape_hw: tuple[int, int]) -> np.ndarray | None:
    if masks_dir is None:
        return None
    stem = image_path.stem
    for cand in (masks_dir / f"{stem}_mask.npy", masks_dir / f"{stem}.npy", masks_dir / f"{stem}_scattering_mask.npy"):
        if cand.is_file():
            arr = np.asarray(np.load(cand), dtype=np.int16)
            return _resize_float(arr.astype(np.float32), shape_hw, nearest=True).astype(np.int16)
    return None


def _nearest_by_azimuth(items: list[dict[str, Any]], az: float, k: int) -> list[dict[str, Any]]:
    ranked = sorted(items, key=lambda x: (_angle_dist(float(x["azimuth"]), az), str(x["path"].name)))
    return ranked[: max(1, min(int(k), len(ranked)))]


def _find_named_or_nearest(files: list[Path], stem: str, az: float) -> Path | None:
    by_stem = {p.stem: p for p in files}
    if stem in by_stem:
        return by_stem[stem]
    if not files:
        return None
    return min(files, key=lambda p: (_angle_dist(_parse_azimuth(p), az), p.name))


def _load_map_alpha(
    map_dir: Path | None,
    stem: str,
    az: float,
    shape_hw: tuple[int, int],
    suffixes: tuple[str, ...],
) -> np.ndarray | None:
    if map_dir is None or not map_dir.is_dir():
        return None
    for suffix in suffixes:
        p = map_dir / f"{stem}_{suffix}.png"
        if p.is_file():
            return _resize_float(_load_gray(p), shape_hw)
    candidates: list[Path] = []
    for suffix in suffixes:
        candidates.extend(map_dir.glob(f"*_{suffix}.png"))
    pick = _find_named_or_nearest(candidates, stem, az)
    if pick is None:
        return None
    return _resize_float(_load_gray(pick), shape_hw)


def _load_shadow_alpha(
    map_dir: Path | None,
    stem: str,
    az: float,
    shape_hw: tuple[int, int],
    source: str = "apply_alpha",
) -> np.ndarray:
    source_suffixes = {
        "apply_alpha": ("shadow_apply_alpha",),
        "opacity": ("azimuth_shadow_opacity", "final_shadow_alpha", "shadow_alpha", "opacity", "final_shadow_mask"),
        "compose_alpha": ("compose_alpha",),
    }
    if source == "max":
        parts = [
            _load_map_alpha(map_dir, stem, az, shape_hw, suffixes)
            for suffixes in source_suffixes.values()
        ]
        parts = [p for p in parts if p is not None]
        if parts:
            return np.maximum.reduce(parts).astype(np.float32)
        arr = None
    else:
        suffixes = source_suffixes.get(
            source,
            ("shadow_apply_alpha", "final_shadow_mask", "compose_alpha", "azimuth_shadow_opacity"),
        )
        arr = _load_map_alpha(map_dir, stem, az, shape_hw, suffixes)
    if arr is None:
        return np.zeros(shape_hw, dtype=np.float32)
    return arr


def _load_target_alpha(map_dir: Path | None, stem: str, az: float, shape_hw: tuple[int, int]) -> np.ndarray | None:
    return _load_map_alpha(map_dir, stem, az, shape_hw, ("target_mask", "target_core_mask", "target_visible_mask"))


def _make_keep_mask(
    render: np.ndarray,
    target: np.ndarray | None,
    shadow_alpha: np.ndarray,
    args,
    target_mask: np.ndarray | None = None,
) -> np.ndarray:
    if target_mask is not None:
        target_mask = np.clip(target_mask.astype(np.float32), 0.0, 1.0)
    elif target is None:
        target_mask = (render > float(args.target_threshold)).astype(np.float32)
        target_mask = _dilate(target_mask, int(args.target_dilate))
    else:
        target_mask = (target > float(args.target_threshold)).astype(np.float32)
        target_mask = _dilate(target_mask, int(args.target_dilate))
    shadow = np.clip(shadow_alpha.astype(np.float32), 0.0, 1.0)
    keep = np.maximum(target_mask, shadow)
    keep = _dilate(keep, int(args.keep_dilate))
    keep = np.maximum(keep, _blur(keep, int(args.keep_blur)))
    gamma = max(float(args.keep_gamma), 0.05)
    return np.clip(keep, 0.0, 1.0) ** gamma


def _make_blend_alpha(render: np.ndarray, target: np.ndarray | None, shadow_alpha: np.ndarray, args) -> np.ndarray:
    """Tighter alpha for final foreground/background compositing.

    The preview keep mask is intentionally conservative and dilated so the
    background sampler avoids target/shadow pixels.  Reusing that same mask for
    final compositing preserves a dark halo around target-only renders, so this
    alpha is kept closer to the true target support and then softly feathered.
    """
    target_alpha, shadow_keep, layover_alpha = _make_composite_alphas(render, target, shadow_alpha, 0.0, args)
    return np.maximum(np.maximum(target_alpha, layover_alpha), shadow_keep).clip(0.0, 1.0)


def _hard_support(alpha: np.ndarray, threshold: float) -> np.ndarray:
    return (np.clip(alpha.astype(np.float32), 0.0, 1.0) >= float(threshold)).astype(np.float32)


def _final_copy_mask(alpha: np.ndarray, threshold: float, hard: bool) -> np.ndarray:
    alpha = np.clip(alpha.astype(np.float32), 0.0, 1.0)
    if hard:
        return _hard_support(alpha, threshold)
    return alpha


def _target_map_is_complete(map_alpha: np.ndarray | None, target: np.ndarray | None, args) -> bool:
    if map_alpha is None or target is None:
        return False
    map_area = int((map_alpha > 0.5).sum())
    target_area = int((target > float(args.target_threshold)).sum())
    if target_area <= 0:
        return map_area > 0
    min_ratio = float(getattr(args, "map_target_min_area_ratio", 0.35) or 0.0)
    return (map_area / max(target_area, 1)) >= min_ratio


def _make_composite_alphas(
    render: np.ndarray,
    target: np.ndarray | None,
    shadow_alpha: np.ndarray,
    azimuth: float,
    args,
    target_mask: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    using_map_target = target_mask is not None
    if using_map_target:
        target_base = np.clip(target_mask.astype(np.float32), 0.0, 1.0)
    elif target is None:
        target_base = (render > float(args.target_threshold)).astype(np.float32)
    else:
        target_base = (target > float(args.target_threshold)).astype(np.float32)
    erode = int(getattr(args, "blend_erode", 0) or 0)
    if erode > 0:
        target_base = 1.0 - _dilate(1.0 - target_base, erode)
    dilate = int(getattr(args, "blend_dilate", 0) or 0)
    if dilate > 0:
        target_base = _dilate(target_base, dilate)

    # Target-only foregrounds can contain a near-black padding ring, but dark
    # pixels inside the target and the SAR shadow are valid signal.  Restrict
    # gap removal to a thin target-boundary band and protect shadow alpha.
    gap_threshold = float(getattr(args, "target_gap_dark_threshold", 0.0) or 0.0)
    edge_px = int(getattr(args, "target_gap_edge_px", 0) or 0)
    if gap_threshold > 0.0 and edge_px > 0:
        gray = np.clip(render.astype(np.float32), 0.0, 1.0)
        support = (target_base > 0.5).astype(np.float32)
        eroded = 1.0 - _dilate(1.0 - support, edge_px)
        boundary = np.clip(support - eroded, 0.0, 1.0)
        shadow_protect = float(getattr(args, "target_gap_shadow_protect_threshold", 0.02) or 0.02)
        gap = boundary * (gray <= gap_threshold).astype(np.float32)
        gap *= (np.clip(shadow_alpha.astype(np.float32), 0.0, 1.0) <= shadow_protect).astype(np.float32)
        target_base = target_base * (1.0 - gap)

    target_blur = int(getattr(args, "blend_blur", 0) or 0)
    if target_blur > 0:
        target_base = _blur(target_base, target_blur)
    target_gamma = max(float(getattr(args, "blend_gamma", 1.0) or 1.0), 0.05)
    target_alpha = np.clip(target_base, 0.0, 1.0) ** target_gamma

    # Preserve the shadow mask from the refiner maps as-is except for an
    # optional scalar weight; no threshold, target-mask dilation, blur, or dark
    # suppression is applied here.
    shadow_keep = np.clip(shadow_alpha.astype(np.float32), 0.0, 1.0)
    shadow_weight = max(float(getattr(args, "blend_shadow_weight", 1.0) or 0.0), 0.0)
    shadow_keep = np.clip(shadow_keep * shadow_weight, 0.0, 1.0)

    grow_px = int(getattr(args, "target_shadow_directional_grow", 0) or 0)
    layover_alpha = np.zeros_like(target_alpha, dtype=np.float32)
    if grow_px > 0:
        angle = (
            float(getattr(args, "target_shadow_direction_deg"))
            if getattr(args, "target_shadow_direction_deg", None) is not None
            else float(azimuth)
        )
        grown = _directional_grow((target_base > 0.25).astype(np.float32), angle, grow_px)
        ring = np.clip(grown - (target_base > 0.25).astype(np.float32), 0.0, 1.0)
        if bool(getattr(args, "target_shadow_directional_intersect_shadow", True)):
            ring *= (shadow_keep > 0.0).astype(np.float32)
        if bool(getattr(args, "target_shadow_directional_use_render_intensity", True)):
            # Do not invent a blurred dark bridge.  Only keep the directional
            # extension where the shadow-refined render already has energy.
            ring *= np.clip(render / max(float(getattr(args, "blend_dark_threshold", 0.04) or 0.04), 1e-6), 0.0, 1.0)
        layover_alpha = ring * min(max(float(getattr(args, "target_shadow_directional_strength", 0.6) or 0.0), 0.0), 1.0)
        layover_blur = int(getattr(args, "target_shadow_directional_blur", 1) or 0)
        if layover_blur > 0:
            layover_alpha = _blur(layover_alpha, layover_blur)
    return target_alpha.clip(0.0, 1.0), shadow_keep.clip(0.0, 1.0), layover_alpha.clip(0.0, 1.0)


def _infer_shadow_from_render(render: np.ndarray, target_mask: np.ndarray, percentile: float) -> np.ndarray:
    if percentile < 0.0:
        return np.zeros_like(render, dtype=np.float32)
    bg_vals = render[target_mask < 0.5]
    if bg_vals.size < 16:
        bg_vals = render.reshape(-1)
    threshold = float(np.percentile(bg_vals, min(max(percentile, 0.0), 100.0)))
    if threshold <= 1e-6:
        return np.zeros_like(render, dtype=np.float32)
    dark = np.clip((threshold - render) / threshold, 0.0, 1.0)
    return dark.astype(np.float32)


def _masked_blur_fill(ref: np.ndarray, valid: np.ndarray, radius: int) -> np.ndarray:
    valid = (valid > 0.5).astype(np.float32)
    denom = _blur(valid, radius)
    num = _blur(ref * valid, radius)
    vals = ref[valid > 0.5]
    mean = float(vals.mean()) if vals.size else float(ref.mean())
    return np.where(denom > 1e-4, num / np.maximum(denom, 1e-4), mean).astype(np.float32)


def _candidate_positions(bg_mask: np.ndarray, ph: int, pw: int, min_bg_fraction: float) -> list[tuple[int, int]]:
    h, w = bg_mask.shape
    step_y = max(1, ph // 3)
    step_x = max(1, pw // 3)
    out: list[tuple[int, int]] = []
    for y in range(0, h - ph + 1, step_y):
        for x in range(0, w - pw + 1, step_x):
            if float(bg_mask[y : y + ph, x : x + pw].mean()) >= min_bg_fraction:
                out.append((y, x))
    return out


def _sample_background(
    refs: list[dict[str, Any]],
    shape_hw: tuple[int, int],
    rng: random.Random,
    args,
) -> tuple[np.ndarray, np.ndarray]:
    h, w = shape_hw
    tile = max(4, int(args.patch_size))
    overlap = min(max(0, int(args.patch_overlap)), tile - 1)
    stride = max(1, tile - overlap)
    canvas = np.zeros((h, w), dtype=np.float32)
    weight = np.zeros((h, w), dtype=np.float32)
    fallback = np.zeros((h, w), dtype=np.float32)
    fallback_weight = 0.0
    cache: dict[tuple[int, int, int], list[tuple[int, int]]] = {}

    for ref_idx, ref in enumerate(refs):
        valid = ref["bg_mask"].astype(np.float32)
        fallback += _masked_blur_fill(ref["image"], valid, int(args.fallback_blur))
        fallback_weight += 1.0
    fallback = fallback / max(fallback_weight, 1.0)

    for y in range(0, h, stride):
        ph = min(tile, h - y)
        for x in range(0, w, stride):
            pw = min(tile, w - x)
            order = list(range(len(refs)))
            rng.shuffle(order)
            chosen = None
            for ref_idx in order:
                ref = refs[ref_idx]
                key = (ref_idx, ph, pw)
                if key not in cache:
                    cache[key] = _candidate_positions(
                        ref["bg_mask"],
                        ph,
                        pw,
                        float(args.min_background_fraction),
                    )
                cand = cache[key]
                if cand:
                    sy, sx = rng.choice(cand)
                    chosen = ref["image"][sy : sy + ph, sx : sx + pw]
                    break
            if chosen is None:
                chosen = fallback[y : y + ph, x : x + pw]
            canvas[y : y + ph, x : x + pw] += chosen
            weight[y : y + ph, x : x + pw] += 1.0

    bg = np.where(weight > 0, canvas / np.maximum(weight, 1e-6), fallback)
    smooth = int(args.patch_smooth)
    if smooth > 0:
        low = _blur(bg, smooth)
        mix = min(max(float(args.patch_smooth_mix), 0.0), 1.0)
        bg = bg * (1.0 - mix) + low * mix
    return np.clip(bg, 0.0, 1.0), fallback


def _reference_background_values(refs: list[dict[str, Any]]) -> np.ndarray:
    vals = []
    for ref in refs:
        cur = ref["image"][ref["bg_mask"] > 0.5]
        if cur.size:
            vals.append(cur)
    if not vals:
        return np.array([], dtype=np.float32)
    return np.concatenate(vals).astype(np.float32)


def _clean_reference_background(ref: dict[str, Any], fill: np.ndarray | None, args) -> np.ndarray:
    """Use a real reference image as background, filling its target/shadow hole.

    This keeps the spatial statistics of the real MSTAR background instead of
    building a synthetic mosaic from patches.  Non-background regions in the
    reference are replaced by sampled real-background texture when available;
    masked blur is only a fallback.  This avoids the equal-width dark fill halo
    that appears around both target and shadow boundaries.
    """
    image = ref["image"].astype(np.float32)
    bg_mask = (ref["bg_mask"] > 0.5).astype(np.float32)
    if fill is None:
        fill = _masked_blur_fill(image, bg_mask, int(args.fallback_blur))
    else:
        fill = np.clip(fill.astype(np.float32), 0.0, 1.0)
    clean = image * bg_mask + fill * (1.0 - bg_mask)
    smooth = int(getattr(args, "reference_clean_smooth", 0) or 0)
    if smooth > 0:
        low = _blur(clean, smooth)
        mix = min(max(float(getattr(args, "reference_clean_smooth_mix", 0.0) or 0.0), 0.0), 1.0)
        clean = clean * (1.0 - mix) + low * mix
    return np.clip(clean, 0.0, 1.0).astype(np.float32)


def _angle_weights(refs: list[dict[str, Any]], az: float, sigma_deg: float) -> np.ndarray:
    sigma = max(float(sigma_deg), 1e-3)
    dists = np.array([_angle_dist(float(ref["azimuth"]), az) for ref in refs], dtype=np.float32)
    weights = np.exp(-0.5 * (dists / sigma) ** 2)
    total = float(weights.sum())
    if total <= 1e-8:
        return np.full(len(refs), 1.0 / max(len(refs), 1), dtype=np.float32)
    return (weights / total).astype(np.float32)


def _reference_clean_background(refs: list[dict[str, Any]], fill: np.ndarray | None, az: float, args) -> np.ndarray:
    base = _clean_reference_background(refs[0], fill, args)
    blend_refs = max(1, int(getattr(args, "reference_clean_blend_refs", 1) or 1))
    blend_mix = min(max(float(getattr(args, "reference_clean_blend_mix", 0.0) or 0.0), 0.0), 1.0)
    patch_mix = min(max(float(getattr(args, "reference_clean_patch_mix", 0.0) or 0.0), 0.0), 1.0)

    out = base
    refs_for_blend = refs[: min(blend_refs, len(refs))]
    if blend_mix > 0.0 and len(refs_for_blend) > 1:
        weights = _angle_weights(
            refs_for_blend,
            az,
            float(getattr(args, "reference_clean_angle_sigma", 12.0) or 12.0),
        )
        blended = np.zeros_like(base, dtype=np.float32)
        for ref, weight in zip(refs_for_blend, weights):
            blended += _clean_reference_background(ref, fill, args) * float(weight)
        out = out * (1.0 - blend_mix) + blended * blend_mix

    if fill is not None and patch_mix > 0.0:
        out = out * (1.0 - patch_mix) + np.clip(fill.astype(np.float32), 0.0, 1.0) * patch_mix
    return np.clip(out, 0.0, 1.0).astype(np.float32)


def _match_stats(bg: np.ndarray, ref_vals: np.ndarray, mode: str) -> np.ndarray:
    if ref_vals.size < 16 or mode == "none":
        return bg
    valid = bg.reshape(-1)
    if mode == "mean_std":
        src_mean, src_std = float(valid.mean()), float(valid.std())
        ref_mean, ref_std = float(ref_vals.mean()), float(ref_vals.std())
        return np.clip((bg - src_mean) / max(src_std, 1e-6) * max(ref_std, 1e-6) + ref_mean, 0.0, 1.0)
    qs = np.array([0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99], dtype=np.float32)
    src_q = np.quantile(valid, qs)
    ref_q = np.quantile(ref_vals, qs)
    return np.clip(np.interp(bg, src_q, ref_q).astype(np.float32), 0.0, 1.0)


def _relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _write_index(output_dir: Path, rows: list[dict[str, Any]], args) -> None:
    cards = []
    for row in rows:
        cells = []
        for label, key in [
            ("training image", "input"),
            ("foreground input", "foreground_input"),
            ("keep", "keep"),
            ("blend alpha", "blend_alpha"),
            ("target alpha", "target_alpha"),
            ("maps target mask", "map_target_alpha"),
            ("shadow alpha", "shadow_alpha"),
            ("layover alpha", "layover_alpha"),
            ("generated background", "background"),
            ("composite", "composite"),
            ("reference", "reference"),
            ("reference bg mask", "reference_background_mask"),
            ("reference bg only", "reference_background_only"),
        ]:
            rel = html.escape(row.get(key, ""))
            cells.append(f"<figure><figcaption>{label}</figcaption><img src='{rel}'></figure>")
        cards.append(
            "<section class='card'>"
            f"<h2>{html.escape(row['name'])} az={row['azimuth']:.1f}</h2>"
            f"<p>{html.escape(row.get('refs', ''))}</p>"
            "<div class='grid'>" + "".join(cells) + "</div>"
            "</section>"
        )
    params = html.escape(json.dumps(vars(args), ensure_ascii=False, indent=2, default=str))
    page = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>MSTAR background preview</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:20px;background:#f5f7fa;color:#1f2937}}
.card{{background:white;border:1px solid #d8dee6;border-radius:8px;padding:14px;margin:0 0 18px}}
h1{{font-size:22px}} h2{{font-size:16px;margin:0 0 6px}} p{{color:#6b7280;font-size:12px}}
.grid{{display:grid;grid-template-columns:repeat(4,minmax(120px,1fr));gap:12px}}
figure{{margin:0}} figcaption{{font-size:12px;font-weight:700;margin-bottom:5px}}
img{{width:100%;image-rendering:pixelated;border:1px solid #d1d5db;background:#111}}
pre{{white-space:pre-wrap;background:#111827;color:#d1d5db;padding:12px;border-radius:6px;font-size:12px}}
</style></head><body>
<h1>MSTAR background preview</h1>
<pre>{params}</pre>
{''.join(cards)}
</body></html>"""
    (output_dir / "index.html").write_text(page, encoding="utf-8")


def run_preview(args: argparse.Namespace) -> None:
    render_dir = Path(args.render_dir).resolve()
    reference_dir = Path(args.reference_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    input_dir = output_dir / "inputs"
    foreground_dir = output_dir / "foreground_inputs"
    bg_dir = output_dir / "backgrounds"
    keep_dir = output_dir / "keep_masks"
    blend_dir = output_dir / "blend_alpha"
    target_alpha_dir = output_dir / "target_alpha"
    map_target_alpha_dir = output_dir / "map_target_alpha"
    shadow_alpha_dir = output_dir / "shadow_alpha_preserved"
    layover_alpha_dir = output_dir / "layover_alpha"
    render_out_dir = output_dir / "renders"
    ref_out_dir = output_dir / "references"
    ref_bg_mask_dir = output_dir / "reference_background_masks"
    ref_bg_only_dir = output_dir / "reference_background_only"
    for d in (
        input_dir,
        foreground_dir,
        bg_dir,
        keep_dir,
        blend_dir,
        target_alpha_dir,
        map_target_alpha_dir,
        shadow_alpha_dir,
        layover_alpha_dir,
        render_out_dir,
        ref_out_dir,
        ref_bg_mask_dir,
        ref_bg_only_dir,
    ):
        d.mkdir(parents=True, exist_ok=True)

    data_dir = Path(args.data_dir).resolve() if args.data_dir else None
    masks_dir = _resolve_masks_dir(data_dir, Path(args.semantic_mask_dir).resolve() if args.semantic_mask_dir else None)
    target_files = _image_files(Path(args.target_mask_dir).resolve()) if args.target_mask_dir else []
    shadow_map_dir = Path(args.shadow_map_dir).resolve() if args.shadow_map_dir else None

    semantic_target_labels = _parse_label_set(getattr(args, "semantic_target_labels", "1,2"))
    ref_items = []
    for p in _image_files(reference_dir):
        img = _load_gray(p)
        mask = _load_semantic_mask(masks_dir, p, img.shape)
        if mask is None:
            bg_mask = np.ones_like(img, dtype=np.float32)
        else:
            bg_mask = (mask == 0).astype(np.float32)
            bg_mask = 1.0 - _dilate(1.0 - bg_mask, int(args.reference_exclude_dilate))
        ref_items.append({"path": p, "image": img, "bg_mask": bg_mask, "semantic_mask": mask, "azimuth": _parse_azimuth(p)})
    if not ref_items:
        raise RuntimeError(f"No reference images found: {reference_dir}")

    rows: list[dict[str, Any]] = []
    renders = _image_files(render_dir)
    if int(args.limit) > 0:
        renders = renders[: int(args.limit)]
    for idx, render_path in enumerate(renders):
        az = _parse_azimuth(render_path)
        render = _load_gray(render_path)
        h, w = render.shape
        target_path = _find_named_or_nearest(target_files, render_path.stem, az) if target_files else None
        target = _resize_float(_load_gray(target_path), (h, w)) if target_path else None
        shadow_alpha = _load_shadow_alpha(
            shadow_map_dir,
            render_path.stem,
            az,
            (h, w),
            str(getattr(args, "shadow_alpha_source", "apply_alpha")),
        )
        target_map_alpha = _load_target_alpha(shadow_map_dir, render_path.stem, az, (h, w))
        semantic_target_alpha = None
        if bool(getattr(args, "semantic_hard_target_copy", True)) and semantic_target_labels:
            nearest_sem = next((r.get("semantic_mask") for r in _nearest_by_azimuth(ref_items, az, 1) if r.get("semantic_mask") is not None), None)
            if nearest_sem is not None:
                sem = _resize_float(np.asarray(nearest_sem, dtype=np.float32), (h, w), nearest=True).astype(np.int16)
                semantic_target_alpha = np.isin(sem, list(semantic_target_labels)).astype(np.float32)
        target_mask_for_composite = (
            target_map_alpha
            if _target_map_is_complete(target_map_alpha, target, args)
            else None
        )
        if semantic_target_alpha is not None:
            target_mask_for_composite = (
                semantic_target_alpha
                if target_mask_for_composite is None
                else np.maximum(target_mask_for_composite, semantic_target_alpha).astype(np.float32)
            )
        if float(shadow_alpha.max()) <= 1e-6 and float(args.shadow_from_render_percentile) >= 0.0:
            if target is not None:
                target_for_shadow = (target > float(args.target_threshold)).astype(np.float32)
            elif target_mask_for_composite is not None:
                target_for_shadow = (target_mask_for_composite > 0.5).astype(np.float32)
            else:
                target_for_shadow = (render > float(args.target_threshold)).astype(np.float32)
            target_for_shadow = _dilate(target_for_shadow, int(args.target_dilate))
            shadow_alpha = _infer_shadow_from_render(
                render,
                target_for_shadow,
                float(args.shadow_from_render_percentile),
            )
        keep = _make_keep_mask(render, target, shadow_alpha, args, target_mask=target_mask_for_composite)
        target_alpha, shadow_keep, layover_alpha = _make_composite_alphas(
            render,
            target,
            shadow_alpha,
            az,
            args,
            target_mask=target_mask_for_composite,
        )
        # Target/layover alpha controls only the generated target layer.
        # Shadow texture is already baked into `render` by the shadow refiner
        # and is copied back later with the preserved shadow mask.
        blend_alpha = np.maximum(target_alpha, layover_alpha).clip(0.0, 1.0)

        refs = _nearest_by_azimuth(ref_items, az, int(args.nearest_refs))
        refs_hw = []
        for ref in refs:
            img = _resize_float(ref["image"], (h, w))
            bg_mask = _resize_float(ref["bg_mask"], (h, w), nearest=True)
            refs_hw.append({**ref, "image": img, "bg_mask": bg_mask})

        rng = random.Random(int(args.seed) + idx * 1009 + int(round(az * 10.0)))
        fallback = refs_hw[0]["image"] if refs_hw else np.zeros((h, w), dtype=np.float32)
        if str(getattr(args, "background_mode", "patch")) == "reference_clean" and refs_hw:
            patch_fill, fallback = _sample_background(refs_hw, (h, w), rng, args)
            bg = _reference_clean_background(refs_hw, patch_fill, az, args)
        else:
            bg, fallback = _sample_background(refs_hw, (h, w), rng, args)
            bg = _match_stats(bg, _reference_background_values(refs_hw), str(args.stat_match))
        if float(args.speckle_sigma) > 0.0:
            noise = np.random.default_rng(int(args.seed) + idx).lognormal(
                mean=-0.5 * float(args.speckle_sigma) ** 2,
                sigma=float(args.speckle_sigma),
                size=bg.shape,
            )
            bg = np.clip(bg * noise.astype(np.float32), 0.0, 1.0)

        # Outside the copied target/shadow support, the final image should come
        # from the generated/real background only.  Mixing the original render
        # into this layer reintroduces the same low-intensity fringe around
        # both target and shadow boundaries.
        strength = min(max(float(args.strength), 0.0), 1.0)
        bg_layer = render * (1.0 - strength) + bg * strength
        target_copy = _final_copy_mask(
            blend_alpha,
            float(getattr(args, "target_copy_threshold", 0.5) or 0.5),
            bool(getattr(args, "hard_target_copy", True)),
        )
        composite = np.clip(render * target_copy + bg_layer * (1.0 - target_copy), 0.0, 1.0)
        shadow_copy_strength = min(max(float(getattr(args, "shadow_copy_strength", 1.0) or 0.0), 0.0), 1.0)
        if shadow_copy_strength > 0.0:
            # Preserve shadow-refiner output directly.  Do not regenerate the
            # shadow as averaged dark scatter and do not alter its mask source.
            # By default this is a soft copy with shadow_apply_alpha so the
            # grown/feathered apply mask keeps the same spatial support.
            shadow_only = _final_copy_mask(
                shadow_keep,
                float(getattr(args, "shadow_copy_threshold", 0.5) or 0.5),
                bool(getattr(args, "hard_shadow_copy", True)),
            ) * shadow_copy_strength
            composite = np.clip(render * shadow_only + composite * (1.0 - shadow_only), 0.0, 1.0)

        ref_source_path = Path(refs_hw[0]["path"]) if refs_hw else None
        ref_source_stem = ref_source_path.stem if ref_source_path is not None else "fallback"
        input_name = f"{render_path.stem}__ref_{ref_source_stem}.png"
        input_path = input_dir / input_name
        foreground_path = foreground_dir / render_path.name
        bg_path = bg_dir / render_path.name
        keep_path = keep_dir / render_path.name
        blend_path = blend_dir / render_path.name
        target_alpha_path = target_alpha_dir / render_path.name
        map_target_alpha_path = map_target_alpha_dir / render_path.name
        shadow_alpha_path = shadow_alpha_dir / render_path.name
        layover_alpha_path = layover_alpha_dir / render_path.name
        out_path = render_out_dir / render_path.name
        ref_path = ref_out_dir / render_path.name
        ref_image = refs_hw[0]["image"] if refs_hw else fallback
        ref_bg_mask = refs_hw[0]["bg_mask"] if refs_hw else np.ones_like(ref_image, dtype=np.float32)
        _save_gray(input_path, ref_image)
        _save_gray(foreground_path, render)
        _save_gray(bg_path, bg)
        _save_gray(keep_path, keep)
        _save_gray(blend_path, blend_alpha)
        _save_gray(target_alpha_path, target_alpha)
        _save_gray(map_target_alpha_path, target_map_alpha if target_map_alpha is not None else target_alpha)
        _save_gray(shadow_alpha_path, shadow_keep)
        _save_gray(layover_alpha_path, layover_alpha)
        _save_gray(out_path, composite)
        _save_gray(ref_path, ref_image)
        _save_gray(ref_bg_mask_dir / render_path.name, ref_bg_mask)
        _save_gray(ref_bg_only_dir / render_path.name, ref_image * ref_bg_mask)
        rows.append(
            {
                "name": render_path.name,
                "azimuth": az,
                "input": _relative(input_path, output_dir),
                "input_source": str(ref_source_path) if ref_source_path is not None else None,
                "foreground_input": _relative(foreground_path, output_dir),
                "keep": _relative(keep_path, output_dir),
                "blend_alpha": _relative(blend_path, output_dir),
                "target_alpha": _relative(target_alpha_path, output_dir),
                "map_target_alpha": _relative(map_target_alpha_path, output_dir),
                "shadow_alpha": _relative(shadow_alpha_path, output_dir),
                "layover_alpha": _relative(layover_alpha_path, output_dir),
                "background": _relative(bg_path, output_dir),
                "composite": _relative(out_path, output_dir),
                "reference": _relative(ref_path, output_dir),
                "reference_background_mask": _relative(ref_bg_mask_dir / render_path.name, output_dir),
                "reference_background_only": _relative(ref_bg_only_dir / render_path.name, output_dir),
                "refs": ", ".join(f"{r['path'].name}({float(r['azimuth']):.0f})" for r in refs_hw),
            }
        )
        print(f"[preview] {render_path.name}: az={az:.1f}, refs={rows[-1]['refs']}")

    _write_index(output_dir, rows, args)
    meta = {
        "count": len(rows),
        "args": vars(args),
        "masks_dir": str(masks_dir) if masks_dir else None,
        "rows": rows,
    }
    (output_dir / "summary.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[done] wrote {len(rows)} previews: {output_dir}")
    print(f"[open] {output_dir / 'index.html'}")


def main() -> int:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--render_dir", required=True, help="target+shadow render directory to receive real backgrounds")
    parser.add_argument("--reference_dir", required=True, help="real MSTAR images used as background source")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--data_dir", default=None, help="dataset root used to resolve latest semantic masks")
    parser.add_argument("--semantic_mask_dir", default=None, help="directory containing *_mask.npy for reference images")
    parser.add_argument("--semantic_target_labels", default="1,2")
    parser.add_argument("--semantic_hard_target_copy", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--target_mask_dir", default=None, help="target-only render directory; used to preserve target")
    parser.add_argument("--shadow_map_dir", default=None, help="azimuth/refiner maps containing shadow alpha")
    parser.add_argument("--shadow_alpha_source", choices=["apply_alpha", "opacity", "compose_alpha", "max"], default="apply_alpha")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--nearest_refs", type=int, default=6)
    parser.add_argument("--background_mode", choices=["patch", "reference_clean"], default="patch")
    parser.add_argument("--strength", type=float, default=1.0)
    parser.add_argument("--target_threshold", type=float, default=0.02)
    parser.add_argument("--target_dilate", type=int, default=1)
    parser.add_argument("--shadow_alpha_threshold", type=float, default=0.20)
    parser.add_argument(
        "--shadow_from_render_percentile",
        type=float,
        default=-1.0,
        help="fallback shadow alpha from dark render pixels when no shadow map is available; -1 disables",
    )
    parser.add_argument("--keep_dilate", type=int, default=1)
    parser.add_argument("--keep_blur", type=int, default=6)
    parser.add_argument("--keep_gamma", type=float, default=1.0)
    parser.add_argument("--blend_dilate", type=int, default=0)
    parser.add_argument("--blend_erode", type=int, default=0)
    parser.add_argument("--blend_blur", type=int, default=0)
    parser.add_argument("--blend_gamma", type=float, default=1.0)
    parser.add_argument("--blend_dark_threshold", type=float, default=0.04)
    parser.add_argument("--blend_shadow_weight", type=float, default=1.0)
    parser.add_argument("--target_gap_dark_threshold", type=float, default=0.0)
    parser.add_argument("--target_gap_edge_px", type=int, default=0)
    parser.add_argument("--target_gap_shadow_protect_threshold", type=float, default=0.02)
    parser.add_argument("--map_target_min_area_ratio", type=float, default=0.35)
    parser.add_argument("--target_shadow_directional_grow", type=int, default=0)
    parser.add_argument("--target_shadow_direction_deg", type=float, default=None)
    parser.add_argument("--target_shadow_directional_strength", type=float, default=0.6)
    parser.add_argument("--target_shadow_directional_blur", type=int, default=1)
    parser.add_argument("--target_shadow_directional_intersect_shadow", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--target_shadow_directional_use_render_intensity", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--reference_exclude_dilate", type=int, default=2)
    parser.add_argument("--patch_size", type=int, default=24)
    parser.add_argument("--patch_overlap", type=int, default=6)
    parser.add_argument("--patch_smooth", type=int, default=1)
    parser.add_argument("--patch_smooth_mix", type=float, default=0.30)
    parser.add_argument("--fallback_blur", type=int, default=9)
    parser.add_argument("--reference_clean_smooth", type=int, default=1)
    parser.add_argument("--reference_clean_smooth_mix", type=float, default=0.15)
    parser.add_argument("--reference_clean_blend_refs", type=int, default=4)
    parser.add_argument("--reference_clean_blend_mix", type=float, default=0.35)
    parser.add_argument("--reference_clean_angle_sigma", type=float, default=12.0)
    parser.add_argument("--reference_clean_patch_mix", type=float, default=0.15)
    parser.add_argument("--min_background_fraction", type=float, default=0.96)
    parser.add_argument("--stat_match", choices=["none", "mean_std", "quantile"], default="mean_std")
    parser.add_argument("--speckle_sigma", type=float, default=0.0)
    parser.add_argument("--shadow_overlay_strength", type=float, default=0.0)
    parser.add_argument("--shadow_copy_strength", type=float, default=1.0)
    parser.add_argument("--hard_target_copy", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--target_copy_threshold", type=float, default=0.5)
    parser.add_argument("--hard_shadow_copy", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_copy_threshold", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=1234)
    args = parser.parse_args()
    run_preview(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
