#!/usr/bin/env python3
"""Make a class-by-azimuth contact sheet for picture/extra renders."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def _font(size: int) -> ImageFont.ImageFont:
    try:
        return ImageFont.truetype("arial.ttf", size)
    except Exception:
        return ImageFont.load_default()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(r"F:\3dgs\SSGR\output\final\picture\extra"))
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--start", type=int, default=5)
    parser.add_argument("--stop", type=int, default=355)
    parser.add_argument("--step", type=int, default=10)
    parser.add_argument("--classes", nargs="*", default=["2S1", "BMP2", "BRDM_2", "BTR70", "D7", "SLICY", "T62", "T72", "ZIL131", "ZSU_23_4"])
    parser.add_argument("--gap", type=int, default=4)
    parser.add_argument("--label_width", type=int, default=92)
    parser.add_argument("--header_height", type=int, default=28)
    parser.add_argument("--background", type=int, default=20)
    args = parser.parse_args()

    angles = list(range(int(args.start), int(args.stop) + 1, int(args.step)))
    if not angles:
        raise SystemExit("No angles selected.")
    output = args.output or (args.root / f"angle_grid_{args.start:03d}_{args.stop:03d}_step{args.step}.png")

    sample_path = args.root / args.classes[0] / f"azimuth_{angles[0]:03d}.png"
    if not sample_path.is_file():
        raise FileNotFoundError(sample_path)
    sample = Image.open(sample_path).convert("L")
    tile_w, tile_h = sample.size

    gap = max(int(args.gap), 0)
    label_w = max(int(args.label_width), 0)
    header_h = max(int(args.header_height), 0)
    width = label_w + len(angles) * tile_w + max(len(angles) - 1, 0) * gap
    height = header_h + len(args.classes) * tile_h + max(len(args.classes) - 1, 0) * gap
    canvas = Image.new("RGB", (width, height), (args.background, args.background, args.background))
    draw = ImageDraw.Draw(canvas)
    font = _font(14)
    small_font = _font(10)

    for col, angle in enumerate(angles):
        x = label_w + col * (tile_w + gap)
        draw.text((x + 4, 6), f"{angle:03d}", fill=(235, 235, 235), font=small_font)

    missing: list[str] = []
    for row, cls in enumerate(args.classes):
        y = header_h + row * (tile_h + gap)
        draw.text((8, y + max((tile_h - 14) // 2, 0)), cls, fill=(245, 245, 245), font=font)
        for col, angle in enumerate(angles):
            x = label_w + col * (tile_w + gap)
            path = args.root / cls / f"azimuth_{angle:03d}.png"
            if not path.is_file():
                missing.append(str(path))
                tile = Image.new("RGB", (tile_w, tile_h), (60, 20, 20))
            else:
                tile = Image.open(path).convert("RGB")
                if tile.size != (tile_w, tile_h):
                    tile = tile.resize((tile_w, tile_h), Image.BILINEAR)
            canvas.paste(tile, (x, y))

    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)
    print(f"[angle grid] wrote {output}")
    print(f"[angle grid] classes={len(args.classes)} angles={len(angles)} size={canvas.size}")
    if missing:
        print(f"[angle grid] missing={len(missing)}")
        for item in missing[:20]:
            print("  " + item)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
