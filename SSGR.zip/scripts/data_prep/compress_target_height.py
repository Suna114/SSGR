#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
SAR目标点云高度压缩后处理工具

对训练完成的Gaussian Splatting模型进行后处理，直接压缩目标点云的高度
以符合SFM约束的目标高度/长度比例。

使用方法:
python compress_target_height.py --model_path output/V5 --target_h_l_ratio 0.3460
"""

import os
import sys

# 设置编码环境
os.environ['PYTHONIOENCODING'] = 'utf-8'

def check_environment():
    """检查运行环境和必需的模块"""
    print("[INFO] 检查运行环境...")

    # 检查Python版本
    print(f"   Python版本: {sys.version}")

    # 检查必需的模块
    required_modules = {
        'torch': 'PyTorch',
        'numpy': 'NumPy',
        'plyfile': 'PLY file library',
        'scipy.spatial': 'SciPy spatial module'
    }

    missing_modules = []
    for module_name, description in required_modules.items():
        try:
            if '.' in module_name:
                # 处理子模块导入，如 scipy.spatial
                module_parts = module_name.split('.')
                __import__(module_parts[0])
                module = __import__(module_parts[0])
                for part in module_parts[1:]:
                    module = getattr(module, part)
            else:
                __import__(module_name)
            print(f"   [OK] {description} ({module_name}): installed")
        except ImportError:
            missing_modules.append((module_name, description))
            print(f"   [ERROR] {description} ({module_name}): missing")

    if missing_modules:
        print("\n[WARNING] Missing required modules:")
        for module_name, description in missing_modules:
            print(f"   - {description} ({module_name})")
        print("\nPlease install missing modules:")
        print("   pip install torch numpy plyfile scipy")
        return False

    print("   [OK] All required modules are installed")
    return True

# 检查环境
try:
    if not check_environment():
        sys.exit(1)
except Exception as e:
    print(f"[FATAL] 环境检查失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 导入必需的模块（在环境检查通过后）
import torch
import numpy as np
import argparse
from plyfile import PlyData, PlyElement
import json
from scipy.spatial import cKDTree

def load_target_constraints(model_path):
    """从模型路径加载目标尺寸约束"""
    possible_paths = [
        os.path.join(model_path, 'target_dimension_constraints_summary.txt'),
        os.path.join(model_path, '..', 'target_dimension_constraints_summary.txt'),
        'target_dimension_constraints_summary.txt'
    ]

    for path in possible_paths:
        if os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # 解析高度/长度比例和长度/宽度比例
                import re
                h_l_pattern = r'推荐高度/长度比例.*?:\s*([\d.]+)'
                l_w_pattern = r'推荐长度/宽度比例.*?:\s*([\d.]+)'

                h_l_match = re.search(h_l_pattern, content)
                l_w_match = re.search(l_w_pattern, content)

                constraints = {}
                if h_l_match:
                    constraints['height_length_ratio'] = float(h_l_match.group(1))
                if l_w_match:
                    # 将长度/宽度比例转换为宽度/长度比例
                    constraints['length_width_ratio'] = float(l_w_match.group(1))

                if constraints:
                    return constraints
            except Exception as e:
                print(f"[WARN] 解析约束文件失败 {path}: {e}")
                continue

    return None

def filter_target_points_from_ply(ply_path, target_constraints=None, brightness_percentile=95.0, use_spatial_clustering=True):
    """
    从PLY文件中过滤出目标点云
    
    改进的过滤策略：
    1. 降低亮度阈值（从99%改为95%），避免过滤过度
    2. 添加空间聚类过滤，确保目标点云是连续的
    3. 检测并排除混合点（同时包含目标点和背景点特征的点）
    
    Args:
        ply_path: PLY文件路径
        target_constraints: 目标约束（可选）
        brightness_percentile: 亮度分位数阈值（默认95.0，即95%分位数）
        use_spatial_clustering: 是否使用空间聚类过滤（默认True）
    """
    try:
        print(f"[INFO] 读取PLY文件: {ply_path}")
        plydata = PlyData.read(ply_path)

        # 获取顶点数据
        vertices = plydata['vertex']

        # 检查vertices的类型和结构
        print(f"   PLY文件结构: {type(vertices)}")
        print(f"   顶点数量: {len(vertices)}")

        # 获取顶点数据 - 处理不同的plyfile版本
        try:
            if hasattr(vertices, 'data'):
                # 新版本plyfile
                vertex_data = vertices.data
                x = vertex_data['x']
                y = vertex_data['y']
                z = vertex_data['z']

                # 检查颜色字段
                has_color = ('red' in vertex_data.dtype.names and
                           'green' in vertex_data.dtype.names and
                           'blue' in vertex_data.dtype.names)
            else:
                # 旧版本plyfile或不同结构
                x = vertices['x']
                y = vertices['y']
                z = vertices['z']
                has_color = ('red' in vertices.dtype.names and
                           'green' in vertices.dtype.names and
                           'blue' in vertices.dtype.names)
        except Exception as e:
            print(f"   [ERROR] 无法解析PLY顶点数据: {e}")
            print(f"   vertices类型: {type(vertices)}")
            print(f"   vertices属性: {dir(vertices)}")
            return None, None

        points = np.column_stack([x, y, z])
        
        # 如果有颜色信息，用于亮度过滤
        if has_color:
            r = vertices['red'] / 255.0
            g = vertices['green'] / 255.0
            b = vertices['blue'] / 255.0

            # 计算亮度
            brightness = 0.299 * r + 0.587 * g + 0.114 * b
            
            # 计算亮度的统计信息
            brightness_mean = np.mean(brightness)
            brightness_std = np.std(brightness)
            brightness_median = np.median(brightness)
            
            print(f"   亮度统计: 均值={brightness_mean:.3f}, 标准差={brightness_std:.3f}, 中位数={brightness_median:.3f}")
            print(f"   亮度范围: [{brightness.min():.3f}, {brightness.max():.3f}]")

            # 改进的亮度阈值：使用更低的分位数，避免过滤过度
            brightness_threshold = np.percentile(brightness, brightness_percentile)
            
            # 同时考虑绝对阈值：目标点应该明显亮于背景
            # 背景点通常是灰色的（亮度约0.1-0.3），目标点是白色的（亮度约0.8-1.0）
            absolute_brightness_threshold = brightness_median + 2.0 * brightness_std  # 均值+2倍标准差
            absolute_brightness_threshold = max(absolute_brightness_threshold, 0.5)  # 至少0.5
            
            # 使用两个阈值的较大值，确保过滤出足够的目标点
            final_brightness_threshold = max(brightness_threshold, absolute_brightness_threshold)
            
            print(f"   {brightness_percentile}%分位数阈值: {brightness_threshold:.3f}")
            print(f"   绝对阈值（均值+2σ）: {absolute_brightness_threshold:.3f}")
            print(f"   最终亮度阈值: {final_brightness_threshold:.3f}")
            
            # 初始亮度过滤
            brightness_mask = brightness >= final_brightness_threshold
            print(f"   初始亮度过滤: {np.sum(brightness_mask)}/{len(brightness)} 点")
            
            # 检测混合点：亮度中等但颜色方差大的点可能是混合点
            # 混合点通常有较高的颜色方差（RGB值差异大）
            color_variance = np.var(np.column_stack([r, g, b]), axis=1)
            color_variance_threshold = np.percentile(color_variance, 90.0)  # 90%分位数
            
            # 混合点特征：亮度中等（0.3-0.7）但颜色方差大
            mixed_point_mask = (brightness >= 0.3) & (brightness <= 0.7) & (color_variance >= color_variance_threshold)
            print(f"   检测到可能的混合点: {np.sum(mixed_point_mask)} 点")
            
            # 排除混合点
            brightness_mask = brightness_mask & ~mixed_point_mask
            print(f"   排除混合点后: {np.sum(brightness_mask)} 点")
            
            target_mask = brightness_mask
            
        else:
            # 如果没有颜色信息，使用简单的几何过滤
            print("   [WARN] PLY文件无颜色信息，使用几何中心过滤")
            centroid = np.mean(points, axis=0)
            distances = np.linalg.norm(points - centroid, axis=1)
            distance_threshold = np.percentile(distances, 10.0)  # 10%分位数作为阈值
            target_mask = distances <= distance_threshold
            print(f"   基于距离过滤: {np.sum(target_mask)}/{len(points)} 点 (阈值: {distance_threshold:.3f})")

        # 空间聚类过滤：确保目标点云是连续的
        if use_spatial_clustering and np.sum(target_mask) > 0:
            print(f"\n   [INFO] 应用空间聚类过滤...")
            target_points_initial = points[target_mask]
            
            # 使用KD树进行空间聚类
            from scipy.spatial import cKDTree
            from scipy.cluster.hierarchy import linkage, fcluster
            
            # 计算点之间的距离矩阵（只对目标点）
            if len(target_points_initial) > 1:
                # 使用KD树找到每个点的最近邻
                tree = cKDTree(target_points_initial)
                
                # 计算每个点到最近邻的距离
                distances_to_nearest, _ = tree.query(target_points_initial, k=2)  # k=2因为第一个是自己
                if len(distances_to_nearest.shape) > 1:
                    nearest_distances = distances_to_nearest[:, 1]  # 第二个是最近邻
                else:
                    nearest_distances = distances_to_nearest
                
                # 计算平均最近邻距离
                mean_nearest_distance = np.mean(nearest_distances)
                std_nearest_distance = np.std(nearest_distances)
                
                # 距离阈值：超过均值+3倍标准差的距离被认为是异常点
                distance_threshold = mean_nearest_distance + 3.0 * std_nearest_distance
                
                print(f"   平均最近邻距离: {mean_nearest_distance:.4f} ± {std_nearest_distance:.4f}")
                print(f"   距离阈值: {distance_threshold:.4f}")
                
                # 过滤掉距离过远的孤立点
                isolated_mask = nearest_distances <= distance_threshold
                target_points_filtered = target_points_initial[isolated_mask]
                
                # 更新target_mask
                target_indices = np.where(target_mask)[0]
                target_mask_new = np.zeros_like(target_mask)
                target_mask_new[target_indices[isolated_mask]] = True
                
                print(f"   空间聚类过滤: {len(target_points_filtered)}/{len(target_points_initial)} 点保留")
                target_mask = target_mask_new
            else:
                print(f"   目标点数量太少，跳过空间聚类过滤")

        # 应用过滤
        filtered_x = x[target_mask]
        filtered_y = y[target_mask]
        filtered_z = z[target_mask]

        target_points = np.column_stack([filtered_x, filtered_y, filtered_z])

        print(f"\n   [SUCCESS] 目标点云过滤完成: {len(target_points)} 点")
        print(f"   过滤率: {len(target_points)/len(points)*100:.2f}%")

        return target_points, target_mask

    except Exception as e:
        print(f"[WARN] PLY文件读取失败: {e}")
        import traceback
        traceback.print_exc()
        return None, None

def compress_target_height(ply_path, target_h_l_ratio, output_path=None, target_only=False, brightness_percentile=95.0, use_spatial_clustering=True):
    """压缩目标点云的高度和宽度以符合几何约束"""
    if output_path is None:
        base, ext = os.path.splitext(ply_path)
        output_path = f"{base}_compressed{ext}"

    print("[INFO] Starting geometric compression...")
    print(f"   Input file: {ply_path}")
    print(f"   Output file: {output_path}")
    print(f"   Target H/L ratio: {target_h_l_ratio}")
    print(f"   Mode: {'target cloud only' if target_only else 'full point cloud'}")
    print("   [INFO] Only height compression (width compression disabled)")

    if target_only:
        # 对于已经过滤的目标点云，直接读取所有点作为目标点
        print("   [INFO] Processing pre-filtered target point cloud...")
        try:
            plydata = PlyData.read(ply_path)
            vertices = plydata['vertex']

            # 获取顶点数据结构
            try:
                if hasattr(vertices, 'data'):
                    vertex_data = vertices.data
                    x = vertex_data['x']
                    y = vertex_data['y']
                    z = vertex_data['z']
                else:
                    x = vertices['x']
                    y = vertices['y']
                    z = vertices['z']
            except Exception as e:
                print(f"   [ERROR] 无法解析PLY顶点数据: {e}")
                return False

            # 所有点都是目标点
            target_points = np.column_stack([x, y, z])
            target_mask = np.ones(len(target_points), dtype=bool)

            print(f"   [SUCCESS] Loaded target point cloud: {len(target_points)} points")

        except Exception as e:
            print(f"[ERROR] 读取目标点云文件失败: {e}")
            return False
    else:
        # 原有的完整点云处理逻辑
        # 1. 过滤目标点云（使用改进的过滤函数）
        target_points, target_mask = filter_target_points_from_ply(ply_path, brightness_percentile=brightness_percentile, use_spatial_clustering=use_spatial_clustering)
    if target_points is None or len(target_points) == 0:
        print("[ERROR] 无法获取目标点云，退出")
        return False

    # 2. 计算当前几何尺寸
    min_coords = target_points.min(axis=0)
    max_coords = target_points.max(axis=0)
    bbox_size = max_coords - min_coords

    # 确定长度和宽度（XOZ平面，取较大的作为长度）
    x_size = bbox_size[0]
    z_size = bbox_size[2]

    print(f"   [DEBUG] XOZ平面尺寸: X={x_size:.3f}, Z={z_size:.3f}")

    if x_size >= z_size:
        current_length = x_size
        current_width = z_size
        length_axis = 0  # X轴
        width_axis = 2   # Z轴
        print("   几何方向: X-长度，Z-宽度")
    else:
        current_length = z_size
        current_width = x_size
        length_axis = 2  # Z轴
        width_axis = 0   # X轴
        print("   几何方向: Z-长度，X-宽度")

    current_height = bbox_size[1]  # Y轴高度
    current_h_l_ratio = abs(current_height) / current_length if current_length > 0 else 0

    print(f"\n[INFO] Current geometry:")
    print(f"   Height: {abs(current_height):.3f}")
    print(f"   Length: {current_length:.3f} ({'X' if length_axis == 0 else 'Z'}轴)")
    print(f"   Width: {current_width:.3f} ({'Z' if width_axis == 2 else 'X'}轴)")
    print(f"   Current H/L ratio: {current_h_l_ratio:.4f}")
    print(f"   Target H/L ratio: {target_h_l_ratio:.4f}")

    # 3. 计算压缩参数
    needs_height_compression = current_h_l_ratio > target_h_l_ratio
    needs_width_compression = False  # 宽度压缩功能已禁用

    print(f"   [DEBUG] 压缩判断:")
    print(f"     高度: 当前 {current_h_l_ratio:.4f} > 目标 {target_h_l_ratio:.4f} = {needs_height_compression}")

    if not needs_height_compression:
        print("   [INFO] 当前尺寸已符合高度约束要求，无需压缩")
        return True

    print(f"\n[INFO] Compression analysis:")
    print(f"   Height compression: {'needed' if needs_height_compression else 'not needed'}")
    print("   Width compression: disabled")

    # 计算目标尺寸（基于当前几何关系）
    target_height = target_h_l_ratio * current_length

    print(f"   [DEBUG] 目标尺寸计算:")
    print(f"     目标高度 = {target_h_l_ratio:.4f} × {current_length:.3f} = {target_height:.3f}")

    print(f"\n[INFO] Target dimensions:")
    print(f"   Target height: {target_height:.3f}")
    print(f"   Width unchanged: {current_width:.3f}")
    print(f"   Length unchanged: {current_length:.3f}")

    # 计算压缩比例（相对于质心）
    height_compression_ratio = target_height / abs(current_height) if needs_height_compression else 1.0

    print(f"   [DEBUG] 压缩比例计算:")
    print(f"     高度压缩: {abs(current_height):.3f} → {target_height:.3f} (比例: {height_compression_ratio:.4f})")
    print(f"     宽度保持: {current_width:.3f} (不变)")
    print(f"     长度保持: {current_length:.3f} (不变)")

    print(f"\n[INFO] Compression ratios:")
    print(f"   Height compression ratio: {height_compression_ratio:.4f}")
    print("   Width compression ratio: disabled")

    # 4. 执行几何压缩
    print(f"\n[INFO] Executing geometric compression...")

    # 计算质心
    y_centroid = np.mean(target_points[:, 1])  # 高度方向质心

    # 对目标点云进行几何压缩
    compressed_target_points = target_points.copy()

    print(f"   [DEBUG] 执行几何压缩...")

    # 高度压缩（Y轴）
    if needs_height_compression:
        print(f"     [DEBUG] 开始高度压缩...")

        # 获取当前Y轴的值
        current_y_values = target_points[:, 1]

        # 计算当前Y轴的范围
        current_y_min = current_y_values.min()
        current_y_max = current_y_values.max()
        current_y_range = abs(current_y_max - current_y_min)  # 使用绝对值

        # 目标高度范围应该等于target_height
        target_y_range = target_height

        # 计算缩放因子
        y_scale = target_y_range / current_y_range if current_y_range > 0 else 1.0

        print(f"       当前高度范围: {current_y_range:.3f} (min: {current_y_min:.3f}, max: {current_y_max:.3f})")
        print(f"       目标高度范围: {target_y_range:.3f}")
        print(f"       高度质心: {y_centroid:.3f}")
        print(f"       缩放因子: {y_scale:.4f}")

        # 验证缩放因子的合理性
        if y_scale > 2.0 or y_scale < 0.1:
            print(f"       [WARNING] 高度缩放因子异常: {y_scale:.4f} (正常范围: 0.1-2.0)")

        # 相对于质心缩放
        y_relative = current_y_values - y_centroid
        compressed_target_points[:, 1] = y_centroid + y_relative * y_scale

        # 验证压缩结果
        compressed_y_values = compressed_target_points[:, 1]
        compressed_y_min = compressed_y_values.min()
        compressed_y_max = compressed_y_values.max()
        actual_compressed_height = abs(compressed_y_max - compressed_y_min)

        print(f"       压缩结果: 范围 {current_y_range:.3f} → {actual_compressed_height:.3f} (目标: {target_y_range:.3f})")
        print(f"       实际缩放: {actual_compressed_height/current_y_range:.4f}")

        # 检查压缩是否成功
        compression_error = abs(actual_compressed_height - target_y_range)
        if compression_error > 0.01:  # 允许1cm的误差
            print(f"       [WARNING] 高度压缩误差: {compression_error:.3f} (> 0.01)")
        else:
            print(f"       [OK] 高度压缩成功，误差: {compression_error:.3f}")

    # 验证压缩效果
    compressed_min = compressed_target_points.min(axis=0)
    compressed_max = compressed_target_points.max(axis=0)
    compressed_bbox_size = compressed_max - compressed_min

    compressed_height = compressed_bbox_size[1]

    # 重新计算压缩后的长度和宽度（因为压缩可能改变大小关系）
    compressed_x_size = compressed_bbox_size[0]
    compressed_z_size = compressed_bbox_size[2]

    if compressed_x_size >= compressed_z_size:
        compressed_length = compressed_x_size
        compressed_width = compressed_z_size
        compressed_length_axis = 0
        compressed_width_axis = 2
    else:
        compressed_length = compressed_z_size
        compressed_width = compressed_x_size
        compressed_length_axis = 2
        compressed_width_axis = 0

    compressed_h_l_ratio = abs(compressed_height) / compressed_length if compressed_length > 0 else 0

    print(f"   [DEBUG] 压缩后尺寸验证:")
    print(f"     压缩后X轴尺寸: {compressed_x_size:.3f}")
    print(f"     压缩后Z轴尺寸: {compressed_z_size:.3f}")
    print(f"     压缩后高度: {abs(compressed_height):.3f}")
    print(f"     确定长度轴: {'X' if compressed_length_axis == 0 else 'Z'}")
    print(f"     确定宽度轴: {'Z' if compressed_width_axis == 2 else 'X'}")
    print(f"     压缩后长度: {compressed_length:.3f}")
    print(f"     压缩后宽度: {compressed_width:.3f}")
    print(f"     压缩后H/L: {compressed_h_l_ratio:.4f}")

    print(f"   [SUCCESS] Height compression completed")
    print(f"   Compressed height: {abs(compressed_height):.3f}")
    print(f"   Compressed length: {compressed_length:.3f}")
    print(f"   Compressed width: {compressed_width:.3f} (unchanged)")
    print(f"   Compressed H/L ratio: {compressed_h_l_ratio:.4f}")

    # 计算约束匹配度
    h_l_match = 1.0 - min(abs(compressed_h_l_ratio - target_h_l_ratio) / target_h_l_ratio, 1.0)
    print(f"   约束匹配度: {100 * h_l_match:.1f}%")

    # 5. 保存压缩后的PLY文件
    try:
        print(f"\n[INFO] Saving compressed PLY file...")

        # 读取原始PLY文件
        plydata = PlyData.read(ply_path)
        vertices = plydata['vertex']

        # 获取顶点数据结构 - 处理不同的plyfile版本
        try:
            if hasattr(vertices, 'data'):
                # 新版本plyfile
                vertex_data_array = vertices.data
                dtype_names = vertex_data_array.dtype.names
                dtype_info = vertex_data_array.dtype
            else:
                # 旧版本plyfile
                dtype_names = vertices.dtype.names
                dtype_info = vertices.dtype
                vertex_data_array = vertices
        except Exception as e:
            print(f"   [ERROR] 无法解析PLY顶点结构: {e}")
            return False

        # 创建新的顶点数组
        new_vertices = []
        vertex_idx = 0

        for i in range(len(vertex_data_array)):
            if target_mask[i]:  # 这是目标点
                vertex_data = []
                for name in dtype_names:
                    if name == 'x':
                        vertex_data.append(compressed_target_points[vertex_idx, 0])
                    elif name == 'y':
                        vertex_data.append(compressed_target_points[vertex_idx, 1])
                    elif name == 'z':
                        vertex_data.append(compressed_target_points[vertex_idx, 2])
                    else:
                        vertex_data.append(vertex_data_array[name][i])
                vertex_idx += 1
            else:  # 这是背景点，保持不变
                vertex_data = [vertex_data_array[name][i] for name in dtype_names]

            new_vertices.append(tuple(vertex_data))

        # 创建新的PLY数据
        new_dtype = [(name, dtype_info[name]) for name in dtype_names]
        new_elements = np.array(new_vertices, dtype=new_dtype)
        el = PlyElement.describe(new_elements, 'vertex')

        # 保存文件
        PlyData([el]).write(output_path)

        print(f"   [SUCCESS] 文件保存成功: {output_path}")
        print(f"   文件大小: {os.path.getsize(output_path)} bytes")

        # 6. 生成统计报告
        print(f"\n[INFO] Geometric compression statistics:")
        print(f"   总点数: {len(vertices)}")
        print(f"   目标点数: {len(target_points)}")
        print(f"   背景点数: {len(vertices) - len(target_points)}")
        if needs_height_compression:
            print(f"   高度压缩比例: {height_compression_ratio:.1%}")
        # 宽度压缩已禁用，不显示宽度压缩比例
        print(f"   H/L比例改进: {current_h_l_ratio:.4f} → {compressed_h_l_ratio:.4f}")

        # 显示约束匹配度
        h_l_match = 1.0 - min(abs(compressed_h_l_ratio - target_h_l_ratio) / target_h_l_ratio, 1.0)
        print(f"   约束匹配度: {100 * h_l_match:.1f}%")

        return True

    except Exception as e:
        print(f"[ERROR] 保存文件失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    parser = argparse.ArgumentParser(description='SAR目标点云高度压缩后处理工具')
    parser.add_argument('--model_path', type=str, required=True,
                       help='模型路径，包含point_cloud目录')
    parser.add_argument('--target_h_l_ratio', type=float, default=None,
                       help='目标高度/长度比例，如果不指定则尝试从约束文件中读取')
    parser.add_argument('--target_w_l_ratio', type=float, default=None,
                       help='目标宽度/长度比例（可选），如果不指定则尝试从约束文件中读取')
    parser.add_argument('--iteration', type=int, default=30000,
                       help='使用的迭代次数，默认30000')
    parser.add_argument('--target_only', action='store_true',
                       help='只压缩point_cloud_target_only.ply文件，而不是整个point_cloud.ply')
    parser.add_argument('--brightness_percentile', type=float, default=95.0,
                       help='亮度分位数阈值（默认95.0，即95%%分位数）。降低此值可以保留更多目标点，但可能包含更多背景点')
    parser.add_argument('--disable_spatial_clustering', action='store_true',
                       help='禁用空间聚类过滤（默认启用）')

    args = parser.parse_args()

    # 检查模型路径是否存在
    if not os.path.exists(args.model_path):
        print(f"[ERROR] 模型路径不存在: {args.model_path}")
        return 1

    # 构建并检查PLY文件路径
    print("[INFO] Looking for PLY files...")

    if args.target_only:
        # 只处理目标点云文件
        print("   [MODE] Compressing target point cloud only")
        possible_ply_paths = [
            os.path.join(args.model_path, 'point_cloud', f'iteration_{args.iteration}', 'point_cloud_target_only.ply'),
        ]
    else:
        # 处理整个点云文件（原有逻辑）
        print("   [MODE] Compressing full point cloud")
        possible_ply_paths = [
            # 标准路径
            os.path.join(args.model_path, 'point_cloud', f'iteration_{args.iteration}', 'point_cloud.ply'),
            # 相对路径（如果model_path是相对路径）
            os.path.join('output', args.model_path, 'point_cloud', f'iteration_{args.iteration}', 'point_cloud.ply'),
            # 绝对路径尝试
            os.path.abspath(os.path.join(args.model_path, 'point_cloud', f'iteration_{args.iteration}', 'point_cloud.ply')),
        ]

    ply_path = None
    for path in possible_ply_paths:
        print(f"   检查: {path}")
        if os.path.exists(path):
            ply_path = path
            print(f"   [OK] 找到PLY文件: {path}")
            break
        else:
            print(f"   [NOT_FOUND] 不存在: {path}")

    if ply_path is None:
        print(f"\n[ERROR] 无法找到PLY文件!")
        print("请检查以下可能的问题:")
        print("1. 模型路径是否正确")
        print(f"2. 迭代次数是否正确 (当前: {args.iteration})")
        print("3. 训练是否已完成并保存了点云文件")
        print("\n可能的PLY文件位置:")
        print(f"   - {args.model_path}/point_cloud/iteration_{args.iteration}/point_cloud.ply")
        print(f"   - output/{args.model_path}/point_cloud/iteration_{args.iteration}/point_cloud.ply")

        # 列出模型目录下的内容以帮助调试
        print(f"\n📂 模型目录内容 ({args.model_path}):")
        if os.path.exists(args.model_path):
            try:
                items = os.listdir(args.model_path)
                for item in items[:10]:  # 只显示前10个
                    print(f"   - {item}")
                if len(items) > 10:
                    print(f"   ... 还有 {len(items) - 10} 个项目")
            except Exception as e:
                print(f"   无法读取目录: {e}")
        else:
            print("   目录不存在")

        return 1

    # 获取目标比例参数
    target_h_l_ratio = args.target_h_l_ratio
    target_w_l_ratio = args.target_w_l_ratio

    # 如果没有手动指定参数，尝试从约束文件中读取
    if target_h_l_ratio is None or target_w_l_ratio is None:
        constraints = load_target_constraints(args.model_path)
        if constraints is not None:
            if target_h_l_ratio is None and 'height_length_ratio' in constraints:
                target_h_l_ratio = constraints['height_length_ratio']
            if target_w_l_ratio is None and 'length_width_ratio' in constraints:
                # 注意：length_width_ratio需要转换为width_length_ratio
                target_w_l_ratio = 1.0 / constraints['length_width_ratio']

    # 检查是否获取到了必要的参数
        if target_h_l_ratio is None:
            print("[ERROR] 无法获取目标H/L比例，请手动指定 --target_h_l_ratio 参数")
            return 1

    if target_w_l_ratio is None:
        print("[WARNING] 无法获取目标W/L比例，将只约束高度")
        target_w_l_ratio = None

    print("[INFO] SAR Target Point Cloud Geometric Compression Tool")
    print(f"   Model path: {args.model_path}")
    print(f"   Target H/L ratio: {target_h_l_ratio}")
    print(f"   Iteration: {args.iteration}")
    print(f"   Mode: {'target cloud only' if args.target_only else 'full point cloud'}")
    print("   [INFO] Only height compression (width compression disabled)")
    print()

    # 执行压缩
    success = compress_target_height(ply_path, target_h_l_ratio, target_only=args.target_only, 
                                     brightness_percentile=args.brightness_percentile,
                                     use_spatial_clustering=not args.disable_spatial_clustering)

    if success:
        print("\n[SUCCESS] Geometric compression completed!")
        return 0
    else:
        print("\n[FAILED] Geometric compression failed!")
        return 1

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(f"[FATAL] 脚本执行失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
