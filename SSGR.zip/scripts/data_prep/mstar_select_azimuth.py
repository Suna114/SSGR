#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""在指定俯视角与方位角范围内，按等间隔目标方位角从图像中选取若干张；
若某目标角度无精确匹配，则选取该文件夹中方位角最接近且尚未被选中的一张（贪心，保证张数且不重复）。

文件名格式:
  - MSTAR: 目标名-俯视角-方位角.扩展名  例如 T72-15-009.jpg
  - novel 渲染默认 legacy: azimuth_XXX.png（俯视角需与 --depression 一致，或路径中含 depression_N 子目录）
"""
from __future__ import annotations

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

import argparse
import os
import re
import shutil
from pathlib import Path
from typing import List, Optional, Tuple

# 与 sar_utils.parse_mstar_filename 一致，但不打印日志
_MSTAR_RE = re.compile(r"^([A-Za-z0-9]+)-(\d+)-(\d+)$")
# render_novel_sar_views.py 默认 legacy：azimuth_XXX.png
_NOVEL_AZ_RE = re.compile(r"^azimuth_(\d+)$", re.IGNORECASE)


def parse_name(basename: str) -> Optional[Tuple[str, int, int]]:
    stem = os.path.splitext(basename)[0]
    m = _MSTAR_RE.match(stem)
    if not m:
        return None
    return m.group(1), int(m.group(2)), int(m.group(3))


def infer_depression_from_path(folder: str) -> Optional[int]:
    """从路径段 .../depression_15/... 解析俯视角；无则返回 None。"""
    for part in Path(folder).resolve().parts:
        m = re.match(r"(?i)^depression_(\d+)$", part)
        if m:
            return int(m.group(1))
    return None


def parse_depression_azimuth(
    basename: str, folder_abs: str, cli_depression: int
) -> Optional[Tuple[int, int]]:
    """
    返回 (俯视角, 方位角)。支持：
    - MSTAR：目标名-俯视角-方位角
    - novel 渲染默认名：azimuth_XXX（俯视角优先从路径 depression_N 推断，否则视为与 --depression 一致）
    """
    meta = parse_name(basename)
    if meta is not None:
        _, dep, az = meta
        return dep, az
    stem = os.path.splitext(basename)[0]
    m = _NOVEL_AZ_RE.match(stem)
    if not m:
        return None
    az = int(m.group(1))
    infer = infer_depression_from_path(folder_abs)
    dep = infer if infer is not None else cli_depression
    return dep, az


def collect_images(
    folder: str,
    depression: int,
    az_min: float,
    az_max: float,
) -> List[Tuple[str, int]]:
    """返回 [(完整路径, 方位角), ...]，仅俯视角匹配且方位角落在 [az_min, az_max]。"""
    folder_abs = os.path.abspath(folder)
    out: List[Tuple[str, int]] = []
    for name in os.listdir(folder):
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            continue
        da = parse_depression_azimuth(name, folder_abs, depression)
        if da is None:
            continue
        dep, az = da
        if dep != depression:
            continue
        if az < az_min or az > az_max:
            continue
        out.append((path, az))
    return out


def target_azimuths(az_min: float, az_max: float, num: int) -> List[float]:
    if num < 1:
        raise ValueError("num 必须 >= 1")
    if az_max < az_min:
        raise ValueError("az_max 必须 >= az_min")
    if num == 1:
        return [(az_min + az_max) / 2.0]
    # 端点均分：含 az_min 与 az_max
    step = (az_max - az_min) / (num - 1)
    return [az_min + i * step for i in range(num)]


def select_greedy_nearest_unique(
    pool: List[Tuple[str, int]], targets: List[float]
) -> List[Tuple[str, int, float]]:
    """
    对每个目标角度依次选「尚未使用」的路径中方位角最近的一张。
    返回 [(路径, 实际方位角, 目标方位角), ...]
    """
    used_paths = set()
    result: List[Tuple[str, int, float]] = []
    for t in targets:
        best_path: Optional[str] = None
        best_az: Optional[int] = None
        best_dist = float("inf")
        for path, az in pool:
            if path in used_paths:
                continue
            d = abs(float(az) - t)
            if d < best_dist or (d == best_dist and path < (best_path or "")):
                best_dist = d
                best_path = path
                best_az = az
        if best_path is None or best_az is None:
            break
        used_paths.add(best_path)
        result.append((best_path, best_az, t))
    return result


def main() -> None:
    p = argparse.ArgumentParser(description="MSTAR 等间隔方位角选图（最近邻 + 不重复）")
    p.add_argument(
        "--source",
        "-s",
        required=True,
        help="图像所在文件夹（MSTAR 命名 或 render_novel_sar_views 的 azimuth_XXX.png）",
    )
    p.add_argument("--depression", "-d", type=int, required=True, help="俯视角（度），如 15")
    p.add_argument("--az-min", type=float, default=0.0, help="方位角下限（度）")
    p.add_argument("--az-max", type=float, default=360.0, help="方位角上限（度）")
    p.add_argument("--num", "-n", type=int, required=True, help="选取张数")
    p.add_argument(
        "--output",
        "-o",
        default="",
        help="输出目录；若指定则复制选中文件到该目录（不存在会创建）",
    )
    p.add_argument(
        "--list-file",
        default="",
        help="将选中文件的绝对路径逐行写入该文本文件",
    )
    args = p.parse_args()

    src = os.path.abspath(args.source)
    if not os.path.isdir(src):
        raise SystemExit(f"源目录不存在: {src}")

    pool = collect_images(src, args.depression, args.az_min, args.az_max)
    if len(pool) < args.num:
        hint = ""
        try:
            entries = [x for x in os.listdir(src) if os.path.isfile(os.path.join(src, x))]
            if entries and infer_depression_from_path(src) is None:
                sample = entries[:3]
                hint = (
                    "\n提示: 若来自 render_novel_sar_views 的 **legacy** 输出，文件名应为 azimuth_XXX.png；"
                    "常见目录为 .../novel_views/depression_<俯角>/renders/。"
                    "\n      若把这些图放在无 depression_N 的文件夹里，仍会按 --depression 过滤（与路径无矛盾即可）。"
                    f"\n      当前目录下示例文件: {sample}"
                )
        except OSError:
            pass
        raise SystemExit(
            f"符合条件的图像仅 {len(pool)} 张（俯视角={args.depression}°, "
            f"方位角∈[{args.az_min}, {args.az_max}]），不足 {args.num} 张。" + hint
        )

    targets = target_azimuths(args.az_min, args.az_max, args.num)
    picked = select_greedy_nearest_unique(pool, targets)

    if len(picked) < args.num:
        raise SystemExit(
            f"贪心选取只得到 {len(picked)} 张（可能候选不足以不重复填满），请扩大方位角范围或减小 --num。"
        )

    print(f"俯视角 {args.depression}°, 方位角 [{args.az_min}, {args.az_max}], 等间隔 {args.num} 个目标角:")
    for path, az, t in picked:
        print(f"  目标 {t:7.3f}° -> {os.path.basename(path)} (实际方位 {az}°, 误差 {abs(az - t):.3f}°)")

    if args.list_file:
        out_list = os.path.abspath(args.list_file)
        os.makedirs(os.path.dirname(out_list) or ".", exist_ok=True)
        with open(out_list, "w", encoding="utf-8") as f:
            for path, _, _ in picked:
                f.write(path + "\n")
        print(f"已写入列表: {out_list}")

    if args.output:
        out_dir = os.path.abspath(args.output)
        os.makedirs(out_dir, exist_ok=True)
        for path, _, _ in picked:
            shutil.copy2(path, os.path.join(out_dir, os.path.basename(path)))
        print(f"已复制 {len(picked)} 个文件到: {out_dir}")


if __name__ == "__main__":
    main()
