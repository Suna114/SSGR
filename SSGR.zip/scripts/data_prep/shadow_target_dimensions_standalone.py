#!/usr/bin/env python3
"""
批量 / 单张：散射掩码 + 阴影几何 target_dimensions（与 convert 特征阶段同源逻辑）。

convert 集成：加 ``--convert_use_standalone_shadow_target_dimensions`` 时，特征阶段不逐张算
target_dimensions，结束后由本模块 ``run_standalone_target_dimension_summary_for_convert`` 批处理写
``<visualization_dir>/target_dimension_constraints_summary.txt``（与 SfM / 比例盒 OBJ 读取格式一致）。

目录扫描与 convert 一致：
  1) 优先 ``<数据目录>/input/*.{jpg,jpeg,png,tif,tiff}``
  2) 若为空则 ``<数据目录>/*.{同上}``（不递归）

示例:
  python scripts/data_prep/shadow_target_dimensions_standalone.py path/to/dataset
  # 与某次 convert 逐比特一致需相同掩码参数：--target-percentile / --background-percentile /
  # --shadow-threshold-factor / --merge-target-edge / --target-mask-dilate-px 等与当时命令行一致。
  # 默认：mstar_axis_split 仅 **90°/270°**：**L=Tr、W=Taz**；H 来自阴影（若有）。
  #   --shadow-geometry-azimuth-mode oblique --pick-azimuth-mode oblique
  python scripts/data_prep/shadow_target_dimensions_standalone.py path/to/dataset \\
      --pick-azimuth-mode cardinal --vis-dir out/vis --json out/report.json
  python scripts/data_prep/shadow_target_dimensions_standalone.py path/to/one.png
"""
from __future__ import annotations

import argparse
import contextlib
import datetime
import io
import json
import math
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import cv2
import numpy as np

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# 与 feature_extraction / convert 一致：仓库根 + data_prep
_repo_root: Optional[Path] = None
for _p in Path(__file__).resolve().parents:
    if (_p / "train.py").is_file():
        _repo_root = _p
        break
if _repo_root is None:
    raise RuntimeError(f"无法定位仓库根（train.py），脚本路径: {__file__}")
if str(_repo_root) not in sys.path:
    sys.path.insert(0, str(_repo_root))
_data_prep = _repo_root / "scripts" / "data_prep"
if str(_data_prep) not in sys.path:
    sys.path.insert(0, str(_data_prep))

from feature_extraction import (
    azimuth_allowed_for_shadow_dimension_gate,
    calculate_scattering_threshold,
    calculate_target_dimensions_from_shadow,
    create_scattering_mask,
    parse_azimuth_angle_list,
    visualize_scattering_regions,
)
from sar_utils import parse_mstar_filename_quiet, preprocess_sar_image
from utils.filter_background import build_target_mask as build_background_target_mask
from utils.filter_background import load_rgb_float, rgb_to_gray_float

_IMAGE_GLOBS = ("*.jpg", "*.jpeg", "*.png", "*.tif", "*.tiff", "*.bmp")
_CONVENTION_JSON_NAME = "dataset_convention_probe.json"


def collect_image_files_like_convert(data_dir: Path) -> List[Path]:
    """与 convert.create_custom_features_and_matches 相同的收集顺序（仅顶层，不递归复制）。"""
    data_dir = data_dir.resolve()
    found: List[Path] = []
    input_dir = data_dir / "input"
    if input_dir.is_dir():
        for pat in _IMAGE_GLOBS:
            found.extend(input_dir.glob(pat))
    if not found:
        for pat in _IMAGE_GLOBS:
            found.extend(data_dir.glob(pat))
    unique = sorted({p.resolve() for p in found}, key=lambda x: x.name.lower())
    return unique


def _to_jsonable(obj: Any) -> Any:
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, np.generic):
        return float(obj) if isinstance(obj, np.floating) else int(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, dict):
        return {str(k): _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(x) for x in obj]
    return str(obj)


def snapshot_3d_ratios(td: Dict[str, Any]) -> Dict[str, Any]:
    """
    从 calculate_target_dimensions_from_shadow 的返回中提取像素域 L/W/H 与比例，
    与汇总文件中的 H/L、H/W、L/W 含义一致。mstar_axis_split 在 90°/270° 下同图可得 L=Tr、W=Taz。
    """
    def _fpos(x: Any) -> Optional[float]:
        if x is None:
            return None
        try:
            v = float(x)
        except (TypeError, ValueError):
            return None
        if not np.isfinite(v) or v <= 0:
            return None
        return v

    H = _fpos(td.get("height"))
    L = _fpos(td.get("length"))
    W = _fpos(td.get("width"))

    hl = td.get("height_length_ratio")
    if hl is not None and np.isfinite(float(hl)) and float(hl) > 0:
        hl_f = float(hl)
    elif H is not None and L is not None and L > 0:
        hl_f = float(H / L)
    else:
        hl_f = None

    hw = td.get("height_width_ratio")
    if hw is not None and np.isfinite(float(hw)) and float(hw) > 0:
        hw_f = float(hw)
    elif H is not None and W is not None and W > 0:
        hw_f = float(H / W)
    else:
        hw_f = None

    lw = td.get("length_width_ratio")
    if lw is not None and np.isfinite(float(lw)) and float(lw) > 0:
        lw_f = float(lw)
    elif L is not None and W is not None and W > 0:
        lw_f = L / W
    else:
        lw_f = None

    out: Dict[str, Any] = {
        "L_px": L,
        "W_px": W,
        "H_px": H,
        "H_over_L": hl_f,
        "H_over_W": hw_f,
        "L_over_W": lw_f,
        "layover_px": float(td.get("layover_length") or 0.0),
        "gamma_deg": float(td.get("orientation_angle") or 0.0),
    }
    ci = td.get("calculation_info") or {}
    if ci.get("mstar_axis_bucket"):
        out["mstar_axis_bucket"] = str(ci.get("mstar_axis_bucket"))
    return out


def format_px_optional_2(x: Any) -> str:
    """像素长度；None / 非有限 为 N/A。"""
    if x is None:
        return "N/A"
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "N/A"
    if not np.isfinite(v):
        return "N/A"
    return f"{v:.2f}"


def format_ratio_optional_4(x: Any) -> str:
    """比例打印为四位小数；None / 非有限 为 N/A。"""
    if x is None:
        return "N/A"
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "N/A"
    if not np.isfinite(v):
        return "N/A"
    return f"{v:.4f}"


def agg_median_mean_str(agg: Dict[str, Any], stem: str, *, fmt: str = ".4f") -> str:
    """汇总字典中 {stem}_median / {stem}_mean；缺一则 N/A / N/A。"""
    mk, ak = f"{stem}_median", f"{stem}_mean"
    if mk not in agg or ak not in agg:
        return "N/A / N/A"
    return f"{float(agg[mk]):{fmt}} / {float(agg[ak]):{fmt}}"


def broadcast_ratios_line(name: str, snap: Dict[str, Any]) -> str:
    """一行播报：L/W/H、比率，以及 clean-axis 取到的 filtered/core/all 像素。"""
    H = format_px_optional_2(snap.get("H_px"))
    L = format_px_optional_2(snap.get("L_px"))
    W = format_px_optional_2(snap.get("W_px"))
    hl = format_ratio_optional_4(snap.get("H_over_L"))
    hw = format_ratio_optional_4(snap.get("H_over_W"))
    lw = format_ratio_optional_4(snap.get("L_over_W"))
    M = float(snap.get("layover_px") or 0.0)
    gf = float(snap.get("gamma_deg") or 0.0)
    ratio_part = f"H/L={hl} H/W={hw} L/W={lw}"
    mstar = snap.get("mstar_axis_bucket")
    clean_axis_dim = snap.get("dataset_clean_axis_dimension")
    clean_axis_val = snap.get("dataset_clean_axis_applied_px")
    if clean_axis_val is None:
        clean_axis_val = snap.get("clean_px")
    filtered_px = snap.get("clean_filtered_px")
    core_px = snap.get("clean_core_px")
    all_px = snap.get("clean_all_px")
    dim_detail = ""
    if clean_axis_dim in ("L", "W"):
        dim_detail = (
            f" | clean={clean_axis_dim}={format_px_optional_2(clean_axis_val)}px"
            f" (filtered={format_px_optional_2(filtered_px)},"
            f" core={format_px_optional_2(core_px)},"
            f" all={format_px_optional_2(all_px)})"
        )

    if mstar == "end_on":
        return (
            f"{name}: 提取W={W}px 估高H={H}px | {ratio_part} | "
            f"叠掩M={M:.2f}px γ={gf:.1f}° (MSTAR端视·仅估宽)"
            f"{dim_detail}"
        )
    if mstar == "broadside":
        return (
            f"{name}: 提取L={L}px 提取W={W}px 估高H={H}px | {ratio_part} | "
            f"叠掩M={M:.2f}px γ={gf:.1f}° (MSTAR侧视·L=Tr W=Taz)"
            f"{dim_detail}"
        )
    return (
        f"{name}: 提取L={L}px 提取W={W}px 估高H={H}px | {ratio_part} | "
        f"叠掩M={M:.2f}px γ={gf:.1f}°"
        f"{dim_detail}"
    )


def compact_progress_ratios_suffix(s3: Dict[str, Any]) -> str:
    """批量一行末尾：与 broadcast 语义一致的简短比例段。"""
    if not s3:
        return ""
    mstar = s3.get("mstar_axis_bucket")
    H = format_px_optional_2(s3.get("H_px"))
    if mstar == "end_on":
        return (
            f" | 提取W={format_px_optional_2(s3.get('W_px'))}px 估高H={H}px "
            f"H/W={format_ratio_optional_4(s3.get('H_over_W'))}"
        )
    if mstar == "broadside":
        return (
            f" | 提取L={format_px_optional_2(s3.get('L_px'))}px "
            f"提取W={format_px_optional_2(s3.get('W_px'))}px 估高H={H}px "
            f"L/W={format_ratio_optional_4(s3.get('L_over_W'))}"
        )
    return (
        f" | H/L={format_ratio_optional_4(s3.get('H_over_L'))} "
        f"H/W={format_ratio_optional_4(s3.get('H_over_W'))} "
        f"L/W={format_ratio_optional_4(s3.get('L_over_W'))}"
    )


def median_mean_ratios(snaps: List[Dict[str, Any]]) -> Dict[str, Any]:
    """多张「合适」图像时，对 L/W/H 与 H/L、H/W、L/W 做中位数/均值汇总。"""
    if not snaps:
        return {}
    keys = ("L_px", "W_px", "H_px", "H_over_L", "H_over_W", "L_over_W", "layover_px")
    out: Dict[str, Any] = {"n": len(snaps)}
    for k in keys:
        vals: List[float] = []
        for s in snaps:
            if k not in s:
                continue
            v = s[k]
            if v is None:
                continue
            try:
                fv = float(v)
            except (TypeError, ValueError):
                continue
            if np.isfinite(fv):
                vals.append(fv)
        if vals:
            arr = np.array(vals, dtype=np.float64)
            out[f"{k}_median"] = float(np.median(arr))
            out[f"{k}_mean"] = float(np.mean(arr))
    return out


def _angle180(angle_deg: float) -> float:
    return float(angle_deg) % 180.0


def _angle180_delta(a_deg: float, b_deg: float) -> float:
    """Smallest signed delta on an undirected 180-degree axis."""
    return ((float(a_deg) - float(b_deg) + 90.0) % 180.0) - 90.0


def _circ_mean_deg(angles: List[float], period: float = 180.0) -> Optional[float]:
    if not angles:
        return None
    scale = 2.0 * math.pi / float(period)
    z = [complex(math.cos(float(a) * scale), math.sin(float(a) * scale)) for a in angles]
    m = sum(z) / max(len(z), 1)
    if abs(m) < 1e-9:
        return None
    return (math.atan2(m.imag, m.real) / scale) % float(period)


def _dominant_label(labels: List[str]) -> Tuple[Optional[str], float, Dict[str, int]]:
    counts: Dict[str, int] = {}
    for label in labels:
        if not label:
            continue
        counts[label] = counts.get(label, 0) + 1
    if not counts:
        return None, 0.0, counts
    label, count = max(counts.items(), key=lambda kv: kv[1])
    return label, float(count) / max(sum(counts.values()), 1), counts


def _axis_from_dims(width_px: float, height_px: float, rel_tol: float = 0.08) -> str:
    w = float(width_px)
    h = float(height_px)
    denom = max(abs(w), abs(h), 1.0)
    if abs(w - h) / denom <= float(rel_tol):
        return "ambiguous"
    return "x" if w > h else "y"


def _side_from_vector(dx: float, dy: float, *, min_norm: float = 1.0) -> str:
    if math.hypot(float(dx), float(dy)) < float(min_norm):
        return "unknown"
    if abs(dx) >= abs(dy):
        return "right" if dx > 0 else "left"
    return "bottom" if dy > 0 else "top"


def _side_to_shadow_direction_deg(side: Optional[str]) -> Optional[float]:
    # Image coordinates: +x right, +y down. These degrees match the refiner's
    # cos/sin shift convention.
    return {
        "right": 0.0,
        "bottom": 90.0,
        "left": 180.0,
        "top": 270.0,
    }.get(str(side or "").lower())


def _extract_mask_probe(mask: np.ndarray, azimuth: float) -> Optional[Dict[str, Any]]:
    target_core = mask == 1
    target = (mask == 1) | (mask == 2)
    shadow = mask == 3
    if not np.any(target):
        return None
    ty, tx = np.where(target)
    tx0, tx1 = float(tx.min()), float(tx.max())
    ty0, ty1 = float(ty.min()), float(ty.max())
    tw = tx1 - tx0 + 1.0
    th = ty1 - ty0 + 1.0
    tcx = float(np.mean(tx))
    tcy = float(np.mean(ty))

    coords = np.stack([tx.astype(np.float64) - tcx, ty.astype(np.float64) - tcy], axis=1)
    major_angle = None
    elongation = None
    if coords.shape[0] >= 3:
        cov = np.cov(coords, rowvar=False)
        try:
            vals, vecs = np.linalg.eigh(cov)
            order = np.argsort(vals)[::-1]
            vals = vals[order]
            vec = vecs[:, order[0]]
            major_angle = _angle180(math.degrees(math.atan2(float(vec[1]), float(vec[0]))))
            elongation = float(vals[0] / max(vals[-1], 1e-9))
        except Exception:
            major_angle = None
            elongation = None

    out: Dict[str, Any] = {
        "azimuth_deg": float(azimuth) % 360.0,
        "target_center_xy": [tcx, tcy],
        "target_bbox_xyxy": [tx0, ty0, tx1, ty1],
        "target_bbox_width_px": float(tw),
        "target_bbox_height_px": float(th),
        "bbox_long_axis": _axis_from_dims(tw, th),
        "pca_major_axis_deg": major_angle,
        "pca_elongation": elongation,
        "shadow_pixels": int(np.sum(shadow)),
    }
    if np.any(target_core):
        cy, cx = np.where(target_core)
        cx0, cx1 = float(cx.min()), float(cx.max())
        cy0, cy1 = float(cy.min()), float(cy.max())
        cw = cx1 - cx0 + 1.0
        ch = cy1 - cy0 + 1.0
        out.update(
            {
                "target_core_bbox_xyxy": [cx0, cy0, cx1, cy1],
                "target_core_bbox_width_px": float(cw),
                "target_core_bbox_height_px": float(ch),
                "target_core_bbox_long_axis": _axis_from_dims(cw, ch),
                "target_core_pixels": int(np.sum(target_core)),
            }
        )
    else:
        out.update(
            {
                "target_core_bbox_xyxy": None,
                "target_core_bbox_width_px": None,
                "target_core_bbox_height_px": None,
                "target_core_bbox_long_axis": "unknown",
                "target_core_pixels": 0,
            }
        )
    if np.any(shadow):
        sy, sx = np.where(shadow)
        scx = float(np.mean(sx))
        scy = float(np.mean(sy))
        dx = scx - tcx
        dy = scy - tcy
        side = _side_from_vector(dx, dy, min_norm=max(1.0, 0.04 * max(tw, th)))
        out.update(
            {
                "shadow_center_xy": [scx, scy],
                "shadow_offset_xy": [float(dx), float(dy)],
                "shadow_side": side,
                "shadow_direction_deg": _side_to_shadow_direction_deg(side),
            }
        )
    else:
        out.update(
            {
                "shadow_center_xy": None,
                "shadow_offset_xy": None,
                "shadow_side": "unknown",
                "shadow_direction_deg": None,
            }
        )
    return out


def _infer_rotation_from_angles(samples: List[Dict[str, Any]]) -> Dict[str, Any]:
    usable: List[Tuple[float, float]] = []
    for s in samples:
        az = s.get("azimuth_deg")
        ang = s.get("filtered_pca_major_axis_deg")
        elong = s.get("filtered_pca_elongation")
        if ang is None:
            ang = s.get("pca_major_axis_deg")
            elong = s.get("pca_elongation")
        if az is None or ang is None:
            continue
        try:
            if elong is not None and float(elong) < 1.15:
                continue
            usable.append((float(az) % 180.0, float(ang) % 180.0))
        except (TypeError, ValueError):
            continue
    if len(usable) < 4:
        return {
            "rotation_direction": "unknown",
            "rotation_sign": None,
            "confidence": 0.0,
            "n": len(usable),
        }

    candidates: List[Tuple[int, float, float]] = []
    for sign in (-1, 1):
        offsets: List[float] = []
        residuals: List[float] = []
        for az, ang in usable:
            offsets.append(_angle180_delta(ang, sign * az))
        off = _circ_mean_deg(offsets, period=180.0)
        if off is None:
            off = float(np.median(np.asarray(offsets, dtype=np.float64))) % 180.0
        for az, ang in usable:
            pred = _angle180(sign * az + off)
            residuals.append(abs(_angle180_delta(ang, pred)))
        med = float(np.median(np.asarray(residuals, dtype=np.float64)))
        candidates.append((sign, med, float(off)))

    sign, med_err, offset = min(candidates, key=lambda x: x[1])
    confidence = max(0.0, min(1.0, 1.0 - med_err / 45.0))
    return {
        # Image coordinates have +Y downward, so increasing atan2 angle appears
        # clockwise on screen.
        "rotation_direction": "clockwise" if sign > 0 else "counterclockwise",
        "rotation_sign": int(sign),
        "confidence": float(confidence),
        "median_abs_error_deg": float(med_err),
        "image_axis_offset_deg": float(offset),
        "n": len(usable),
    }


def infer_dataset_convention(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    probes = [r.get("dataset_probe") for r in rows if isinstance(r.get("dataset_probe"), dict)]
    probes = [p for p in probes if p]
    shadow_label, shadow_conf, shadow_counts = _dominant_label(
        [str(p.get("shadow_side", "")) for p in probes if p.get("shadow_side") not in (None, "unknown")]
    )
    near_zero = []
    side_views = []
    for p in probes:
        try:
            az = float(p.get("azimuth_deg", 999.0)) % 360.0
        except (TypeError, ValueError):
            continue
        if min(abs(az - 0.0), abs(az - 360.0)) <= 15.0:
            near_zero.append(p)
        if min(abs(az - 90.0), abs(az - 270.0)) <= 15.0:
            side_views.append(p)

    zero_axis, zero_axis_conf, zero_axis_counts = _dominant_label(
        [
            str(p.get("filtered_bbox_long_axis", p.get("bbox_long_axis", "")))
            for p in near_zero
            if p.get("filtered_bbox_long_axis", p.get("bbox_long_axis")) not in (None, "ambiguous")
        ]
    )
    side_axis, side_axis_conf, side_axis_counts = _dominant_label(
        [
            str(p.get("filtered_bbox_long_axis", p.get("bbox_long_axis", "")))
            for p in side_views
            if p.get("filtered_bbox_long_axis", p.get("bbox_long_axis")) not in (None, "ambiguous")
        ]
    )
    rot = _infer_rotation_from_angles(probes)

    side_lw_mapping = "L=image_y,W=image_x"
    if side_axis == "x":
        side_lw_mapping = "L=image_x,W=image_y"
    elif side_axis == "y":
        side_lw_mapping = "L=image_y,W=image_x"

    zero_axis_mapping = None
    if zero_axis == "x":
        zero_axis_mapping = "az0: X=length, Y=width"
    elif zero_axis == "y":
        zero_axis_mapping = "az0: Y=length, X=width"

    clean_axis = _clean_image_axis_from_shadow_side(shadow_label)
    if clean_axis in ("x", "y") and shadow_conf >= 0.35:
        # Global shadow-side statistics are more stable than near-0 high
        # percentile bbox voting.  At 0/360 deg the clean axis gives width; at
        # 90/270 deg the same clean axis gives length.
        if clean_axis == "x":
            zero_axis = "y"
            zero_axis_mapping = "az0: Y=length, X=width"
            side_axis = "x"
            side_lw_mapping = "L=image_x,W=image_y"
        else:
            zero_axis = "x"
            zero_axis_mapping = "az0: X=length, Y=width"
            side_axis = "y"
            side_lw_mapping = "L=image_y,W=image_x"
        zero_axis_conf = max(float(zero_axis_conf), float(shadow_conf))
        side_axis_conf = max(float(side_axis_conf), float(shadow_conf))

    shadow_dir = _side_to_shadow_direction_deg(shadow_label)
    image_rotation_sign = rot.get("rotation_sign")
    gs_sign = int(image_rotation_sign) if image_rotation_sign in (-1, 1) else None
    if gs_sign not in (-1, 1):
        gs_sign = None

    return {
        "version": 1,
        "source": "shadow_target_dimensions_standalone",
        "generated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "n_images": len(rows),
        "n_probe_samples": len(probes),
        "shadow_side": shadow_label or "unknown",
        "shadow_side_confidence": float(shadow_conf),
        "shadow_side_counts": shadow_counts,
        "shadow_direction_deg": shadow_dir,
        "zero_azimuth_long_axis": zero_axis or "unknown",
        "zero_azimuth_axis_mapping": zero_axis_mapping,
        "zero_azimuth_axis_confidence": float(zero_axis_conf),
        "zero_azimuth_axis_counts": zero_axis_counts,
        "side_view_long_axis": side_axis or "unknown",
        "side_view_lw_mapping": side_lw_mapping,
        "side_view_axis_confidence": float(side_axis_conf),
        "side_view_axis_counts": side_axis_counts,
        "rotation_direction": rot.get("rotation_direction", "unknown"),
        "rotation_sign": rot.get("rotation_sign"),
        "rotation_confidence": float(rot.get("confidence", 0.0) or 0.0),
        "rotation_fit": rot,
        "gs_optical_ring_azimuth_sign": int(gs_sign) if gs_sign in (-1, 1) else None,
        "refiner_shadow_direction_offset_deg": float(shadow_dir) if shadow_dir is not None else None,
        "refiner_shadow_direction_sign": 1.0,
        "samples": probes,
    }


def _apply_dataset_convention_to_row(row: Dict[str, Any], convention: Dict[str, Any]) -> None:
    """Adjust row ratios after probing when side-view image axes differ from the old MSTAR assumption."""
    if not row.get("ratios_3d"):
        return
    mapping = str(convention.get("side_view_lw_mapping") or "")
    # In calculate_target_dimensions_from_shadow, target_range_size is image Y
    # and target_azimuth_size is image X. The legacy mstar_axis_split already
    # maps L=image_y, W=image_x; only X-long datasets need a swap.
    if mapping != "L=image_x,W=image_y":
        return
    try:
        if float(convention.get("side_view_axis_confidence", 0.0) or 0.0) < 0.6:
            return
    except (TypeError, ValueError):
        return
    snap = row.get("ratios_3d") or {}
    td = row.get("target_dimensions")
    if not isinstance(td, dict):
        return
    try:
        tr = float(td.get("target_range_size"))
        taz = float(td.get("target_azimuth_size"))
    except (TypeError, ValueError):
        return
    if not np.isfinite(tr) or not np.isfinite(taz) or tr <= 0 or taz <= 0:
        return
    H = snap.get("H_px")
    snap["L_px"] = float(taz)
    snap["W_px"] = float(tr)
    if H is not None:
        try:
            hf = float(H)
            snap["H_over_L"] = hf / float(taz) if taz > 0 else None
            snap["H_over_W"] = hf / float(tr) if tr > 0 else None
        except (TypeError, ValueError):
            pass
    snap["L_over_W"] = float(taz) / float(tr) if tr > 0 else None
    snap["dataset_axis_mapping_applied"] = mapping
    row["ratios_3d"] = snap
    td["length"] = float(taz)
    td["width"] = float(tr)
    td["height_length_ratio"] = snap.get("H_over_L")
    td["height_width_ratio"] = snap.get("H_over_W")
    td["length_width_ratio"] = snap.get("L_over_W")
    ci = td.get("calculation_info")
    if not isinstance(ci, dict):
        ci = {}
        td["calculation_info"] = ci
    ci["dataset_axis_mapping_applied"] = mapping
    ci["dataset_axis_mapping_note"] = "auto probe: side-view target long axis follows image X; swapped legacy L=image_y/W=image_x"
    row["target_dimensions"] = td


def _clean_image_axis_from_shadow_side(shadow_side: Any) -> Optional[str]:
    """Return the image axis least contaminated by the dataset-level shadow side."""
    side = str(shadow_side or "").strip().lower()
    if side in ("left", "right"):
        return "y"
    if side in ("top", "bottom"):
        return "x"
    return None


def _azimuth_role_for_clean_axis_sample(azimuth: Any, tol: float) -> Optional[str]:
    try:
        a = float(azimuth) % 360.0
    except (TypeError, ValueError):
        return None
    tol = max(0.0, float(tol))
    if min(abs(a - 0.0), abs(a - 360.0)) <= tol:
        return "zero"
    if min(abs(a - 90.0), abs(a - 270.0)) <= tol:
        return "side"
    return None


def _axis_dimension_from_zero_mapping(convention: Dict[str, Any], axis: str) -> Optional[str]:
    axis = str(axis or "").strip().lower()
    mapping = str(convention.get("zero_azimuth_axis_mapping") or "").lower().replace(" ", "")
    if f"{axis}=length" in mapping:
        return "L"
    if f"{axis}=width" in mapping:
        return "W"

    long_axis = str(convention.get("zero_azimuth_long_axis") or "").strip().lower()
    if long_axis in ("x", "y"):
        return "L" if axis == long_axis else "W"
    return None


def _axis_dimension_from_side_mapping(convention: Dict[str, Any], axis: str) -> Optional[str]:
    axis = str(axis or "").strip().lower()
    mapping = str(convention.get("side_view_lw_mapping") or "").lower().replace(" ", "")
    if f"l=image_{axis}" in mapping:
        return "L"
    if f"w=image_{axis}" in mapping:
        return "W"

    long_axis = str(convention.get("side_view_long_axis") or "").strip().lower()
    if long_axis in ("x", "y"):
        return "L" if axis == long_axis else "W"
    return None


def _clean_axis_dimension_for_role(
    convention: Dict[str, Any],
    *,
    clean_axis: str,
    role: str,
) -> Optional[str]:
    # Clean-axis extraction is role-based:
    # 0/360 views give the width sample; 90/270 views give the length sample.
    if role == "zero":
        return "W"
    if role == "side":
        return "L"
    return None


def _clean_axis_span_px(probe: Dict[str, Any], axis: str, *, core: bool = True) -> Optional[float]:
    if core:
        key = "target_core_bbox_width_px" if axis == "x" else "target_core_bbox_height_px"
    else:
        key = "target_bbox_width_px" if axis == "x" else "target_bbox_height_px"
    try:
        v = float(probe.get(key))
    except (TypeError, ValueError):
        return None
    if not np.isfinite(v) or v <= 0:
        return None
    return v


def _filtered_axis_span_px(probe: Dict[str, Any], axis: str) -> Optional[float]:
    key = "filtered_bbox_width_px" if str(axis).lower() == "x" else "filtered_bbox_height_px"
    try:
        v = float(probe.get(key))
    except (TypeError, ValueError):
        return None
    if not np.isfinite(v) or v <= 0:
        return None
    return v


def _choose_clean_axis_span_px(
    filtered_span: Optional[float],
    core_span: Optional[float],
    all_span: Optional[float],
) -> Tuple[Optional[float], str]:
    """Choose a clean-axis L/W span without letting a bright-core filter shrink vehicles.

    The filtered bbox is useful for rejecting speckle, but for some MSTAR targets
    (notably T72) the brightest connected component covers only the turret/strong
    scatterers.  In that case using it as the physical L/W span makes the nominal
    verify box and geometry prior much too small.
    """
    if filtered_span is None:
        if all_span is not None:
            return all_span, "all_no_filtered"
        return core_span, "core_no_filtered"

    # If the filtered target is much smaller than the semantic target extent, it
    # is measuring a bright sub-part rather than the target footprint.
    if all_span is not None and filtered_span < 0.65 * all_span:
        return all_span, "all_filtered_too_small"
    if core_span is not None and filtered_span < 0.75 * core_span:
        return core_span, "core_filtered_too_small"
    return filtered_span, "filtered"


def _bbox_is_full_frame(probe: Dict[str, Any], *, min_fill: float = 0.9) -> bool:
    try:
        w = float(probe.get("target_bbox_width_px"))
        h = float(probe.get("target_bbox_height_px"))
    except (TypeError, ValueError):
        return False
    if w <= 0 or h <= 0:
        return False
    return w >= 127.0 * float(min_fill) or h >= 127.0 * float(min_fill)


def _extract_filtered_target_probe(
    path: Path,
    *,
    percentile: float = 99.0,
    min_target_ratio: float = 0.002,
) -> Optional[Dict[str, Any]]:
    """
    Build a filtered target bbox using the same background filtering logic as
    utils/filter_background.py, so width/length measurement is less polluted by
    speckle and outer ring clutter.
    """
    try:
        rgb, _ = load_rgb_float(path)
        gray = rgb_to_gray_float(rgb)
        filt = build_background_target_mask(
            gray,
            percentile,
            min_target_ratio,
            method="percentile",
            blur_sigma=1.0,
            open_iter=1,
            close_iter=2,
            morph_kernel=5,
            largest_cc=True,
            min_cc_area=0,
            erode_px=0,
        )
    except Exception:
        return None
    m = np.asarray(filt, dtype=np.float32) > 0.5
    if not np.any(m):
        return None
    ys, xs = np.where(m)
    x0, x1 = float(xs.min()), float(xs.max())
    y0, y1 = float(ys.min()), float(ys.max())
    cx = float(np.mean(xs))
    cy = float(np.mean(ys))
    coords = np.stack(
        [xs.astype(np.float64) - cx, ys.astype(np.float64) - cy],
        axis=1,
    )
    major_angle = None
    elongation = None
    if coords.shape[0] >= 3:
        try:
            cov = np.cov(coords, rowvar=False)
            vals, vecs = np.linalg.eigh(cov)
            order = np.argsort(vals)[::-1]
            vals = vals[order]
            vec = vecs[:, order[0]]
            major_angle = _angle180(math.degrees(math.atan2(float(vec[1]), float(vec[0]))))
            elongation = float(vals[0] / max(vals[-1], 1e-9))
        except Exception:
            major_angle = None
            elongation = None
    return {
        "filtered_bbox_xyxy": [x0, y0, x1, y1],
        "filtered_bbox_width_px": float(x1 - x0 + 1.0),
        "filtered_bbox_height_px": float(y1 - y0 + 1.0),
        "filtered_bbox_long_axis": _axis_from_dims(x1 - x0 + 1.0, y1 - y0 + 1.0),
        "filtered_center_xy": [cx, cy],
        "filtered_pca_major_axis_deg": major_angle,
        "filtered_pca_elongation": elongation,
        "filtered_pixels": int(m.sum()),
        "filtered_percentile": float(percentile),
        "filtered_min_target_ratio": float(min_target_ratio),
    }


def _update_shadow_side_from_filtered_target(probe: Dict[str, Any]) -> None:
    """Use the filtered target center when deciding the shadow side."""
    try:
        sc = probe.get("shadow_center_xy")
        tc = probe.get("filtered_center_xy")
        if not isinstance(sc, (list, tuple)) or not isinstance(tc, (list, tuple)):
            return
        scx, scy = float(sc[0]), float(sc[1])
        tcx, tcy = float(tc[0]), float(tc[1])
        fw = float(probe.get("filtered_bbox_width_px", 0.0) or 0.0)
        fh = float(probe.get("filtered_bbox_height_px", 0.0) or 0.0)
    except (TypeError, ValueError, IndexError):
        return
    side = _side_from_vector(
        scx - tcx,
        scy - tcy,
        min_norm=max(1.0, 0.04 * max(fw, fh, 1.0)),
    )
    if side != "unknown":
        probe["shadow_offset_xy_filtered_target"] = [float(scx - tcx), float(scy - tcy)]
        probe["shadow_side"] = side
        probe["shadow_direction_deg"] = _side_to_shadow_direction_deg(side)


def _axis_clean_rows_from_dataset_convention(
    rows: List[Dict[str, Any]],
    convention: Dict[str, Any],
    *,
    tol: float,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Build L/W samples from the unshadowed image axis:
    left/right shadow -> use image Y; top/bottom shadow -> use image X.

    This uses the dataset-level convention probe, not folder names. 0-degree
    views provide the zero-azimuth mapped dimension, while 90/270-degree views
    provide the side-view mapped dimension.
    """
    clean_axis = _clean_image_axis_from_shadow_side(convention.get("shadow_side"))
    meta: Dict[str, Any] = {
        "enabled": False,
        "clean_axis": clean_axis,
        "shadow_side": convention.get("shadow_side", "unknown"),
        "azimuth_tolerance_deg": float(tol),
        "n_samples": 0,
        "n_L_samples": 0,
        "n_W_samples": 0,
        "samples": [],
    }
    if clean_axis not in ("x", "y"):
        meta["reason"] = "unknown_shadow_side"
        return [], meta

    out: List[Dict[str, Any]] = []
    for r in rows:
        probe = r.get("dataset_probe")
        if not isinstance(probe, dict):
            continue
        az = probe.get("azimuth_deg", r.get("azimuth"))
        role = _azimuth_role_for_clean_axis_sample(az, tol)
        if role not in ("zero", "side"):
            continue
        dim = _clean_axis_dimension_for_role(convention, clean_axis=clean_axis, role=role)
        core_span = _clean_axis_span_px(probe, clean_axis, core=True)
        all_span = _clean_axis_span_px(probe, clean_axis, core=False)
        filtered_span = _filtered_axis_span_px(probe, clean_axis)
        span, span_source = _choose_clean_axis_span_px(filtered_span, core_span, all_span)
        skipped_reason = None
        if dim not in ("L", "W"):
            skipped_reason = "no_axis_mapping"
        elif span is None:
            skipped_reason = "invalid_span"
        elif _bbox_is_full_frame(probe):
            skipped_reason = "full_frame_bbox"
        try:
            azf = float(az) % 360.0
        except (TypeError, ValueError):
            azf = None
        meta["samples"].append(
            {
                "name": r.get("name"),
                "azimuth_deg": azf,
                "role": role,
                "dimension": dim,
                "clean_axis": clean_axis,
                "clean_px": span,
                "clean_px_source": span_source,
                "clean_filtered_px": filtered_span,
                "clean_core_px": core_span,
                "clean_all_px": all_span,
                "filtered_bbox_width_px": probe.get("filtered_bbox_width_px"),
                "filtered_bbox_height_px": probe.get("filtered_bbox_height_px"),
                "filtered_bbox_xyxy": probe.get("filtered_bbox_xyxy"),
                "filtered_percentile": probe.get("filtered_percentile"),
                "target_core_bbox_width_px": probe.get("target_core_bbox_width_px"),
                "target_core_bbox_height_px": probe.get("target_core_bbox_height_px"),
                "target_bbox_width_px": probe.get("target_bbox_width_px"),
                "target_bbox_height_px": probe.get("target_bbox_height_px"),
                "target_bbox_xyxy": probe.get("target_bbox_xyxy"),
                "used": skipped_reason is None,
                "skip_reason": skipped_reason,
            }
        )
        if skipped_reason is not None:
            continue

        snap: Dict[str, Any] = {
            f"{dim}_px": float(span),
            "dataset_clean_axis_applied_px": float(span),
            "clean_px": float(span),
            "clean_px_source": span_source,
            "clean_filtered_px": float(filtered_span) if filtered_span is not None else None,
            "clean_core_px": float(core_span) if core_span is not None else None,
            "clean_all_px": float(all_span) if all_span is not None else None,
            "dataset_clean_axis": f"image_{clean_axis}",
            "dataset_clean_axis_role": role,
            "dataset_clean_axis_dimension": dim,
        }
        old_snap = r.get("ratios_3d")
        if isinstance(old_snap, dict):
            H = _finite_positive_px(old_snap, "H_px")
            if H is not None:
                snap["H_px"] = float(H)
                if dim == "L":
                    snap["H_over_L"] = float(H) / float(span)
                else:
                    snap["H_over_W"] = float(H) / float(span)
                if old_snap.get("mstar_axis_bucket"):
                    snap["mstar_axis_bucket"] = str(old_snap.get("mstar_axis_bucket"))

        td = r.get("target_dimensions")
        if isinstance(td, dict):
            td_out = dict(td)
        else:
            td_out = {}
        try:
            td_out["orientation_angle"] = float(az)
        except (TypeError, ValueError):
            pass
        td_out["dataset_clean_axis_applied"] = True
        td_out["dataset_clean_axis"] = f"image_{clean_axis}"
        td_out["dataset_clean_axis_role"] = role
        td_out["dataset_clean_axis_dimension"] = dim

        rr = dict(r)
        rr["success"] = True
        rr["selected"] = True
        rr["target_dimensions"] = td_out
        rr["ratios_3d"] = snap
        rr["dataset_clean_axis_sample"] = True
        out.append(rr)

    l_vals = [
        _finite_positive_px((r.get("ratios_3d") or {}), "L_px")
        for r in out
        if isinstance(r.get("ratios_3d"), dict)
    ]
    w_vals = [
        _finite_positive_px((r.get("ratios_3d") or {}), "W_px")
        for r in out
        if isinstance(r.get("ratios_3d"), dict)
    ]
    l_vals = [v for v in l_vals if v is not None]
    w_vals = [v for v in w_vals if v is not None]
    meta.update(
        {
            "enabled": bool(l_vals and w_vals),
            "n_samples": len(out),
            "n_L_samples": len(l_vals),
            "n_W_samples": len(w_vals),
            "L_px_median": float(np.median(np.asarray(l_vals, dtype=np.float64))) if l_vals else None,
            "W_px_median": float(np.median(np.asarray(w_vals, dtype=np.float64))) if w_vals else None,
        }
    )
    if l_vals and w_vals:
        meta["L_over_W_composite"] = float(meta["L_px_median"]) / float(meta["W_px_median"])
    return out, meta


def _merge_clean_axis_lw_into_summary_inputs(
    base_rows: List[Dict[str, Any]],
    base_agg: Dict[str, Any],
    clean_axis_rows: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    if not clean_axis_rows:
        return base_rows, base_agg
    h_only_rows: List[Dict[str, Any]] = []
    for r in base_rows:
        rr = dict(r)
        snap = rr.get("ratios_3d")
        if isinstance(snap, dict):
            ss = dict(snap)
            for key in ("L_px", "W_px", "H_over_L", "H_over_W", "L_over_W"):
                ss.pop(key, None)
            rr["ratios_3d"] = ss
        h_only_rows.append(rr)
    clean_lw_rows: List[Dict[str, Any]] = []
    for r in clean_axis_rows:
        rr = dict(r)
        snap = rr.get("ratios_3d")
        if isinstance(snap, dict):
            ss = dict(snap)
            for key in ("H_px", "H_over_L", "H_over_W", "L_over_W"):
                ss.pop(key, None)
            rr["ratios_3d"] = ss
        clean_lw_rows.append(rr)
    merged_rows = h_only_rows + clean_lw_rows
    agg = dict(base_agg)

    snaps = [r.get("ratios_3d") for r in clean_axis_rows if isinstance(r.get("ratios_3d"), dict)]
    l_vals = [_finite_positive_px(s, "L_px") for s in snaps]
    w_vals = [_finite_positive_px(s, "W_px") for s in snaps]
    l_vals = [v for v in l_vals if v is not None]
    w_vals = [v for v in w_vals if v is not None]
    if l_vals:
        la = np.asarray(l_vals, dtype=np.float64)
        agg["L_px_median"] = float(np.median(la))
        agg["L_px_mean"] = float(np.mean(la))
    if w_vals:
        wa = np.asarray(w_vals, dtype=np.float64)
        agg["W_px_median"] = float(np.median(wa))
        agg["W_px_mean"] = float(np.mean(wa))
    if l_vals and w_vals:
        lw = float(agg["L_px_median"]) / float(agg["W_px_median"])
        agg["L_over_W_median"] = lw
        agg["L_over_W_mean"] = lw
    h_med = agg.get("H_px_median")
    try:
        hf = float(h_med)
        if np.isfinite(hf) and hf > 0:
            if agg.get("L_px_median") is not None and float(agg["L_px_median"]) > 0:
                hl = hf / float(agg["L_px_median"])
                agg["H_over_L_median"] = hl
                agg["H_over_L_mean"] = hl
            if agg.get("W_px_median") is not None and float(agg["W_px_median"]) > 0:
                hw = hf / float(agg["W_px_median"])
                agg["H_over_W_median"] = hw
                agg["H_over_W_mean"] = hw
    except (TypeError, ValueError):
        pass
    return merged_rows, agg


def ref_ratios_from_meters(length_m: float, width_m: float, height_m: float) -> Dict[str, float]:
    """真值长宽高（米）→ H/L、H/W、L/W（与像素比例同名键）。"""
    L, W, H = float(length_m), float(width_m), float(height_m)
    if min(L, W, H) <= 0:
        raise ValueError("参考尺寸须为正")
    return {
        "H_over_L": H / L,
        "H_over_W": H / W,
        "L_over_W": L / W,
    }


def _mad_outlier_indices(indexed_vals: List[Tuple[int, float]], mad_k: float) -> Set[int]:
    """
    对 (位置索引, 数值) 列表做 MAD 离群检测；返回在「同列表下标」意义下的离群位置索引。
    至少 3 个有效数值才参与；mad_k≤0 则永不标记离群。
    """
    if mad_k <= 0 or len(indexed_vals) < 3:
        return set()
    positions = [t[0] for t in indexed_vals]
    vals = np.array([t[1] for t in indexed_vals], dtype=np.float64)
    med = float(np.median(vals))
    dev = np.abs(vals - med)
    mad = float(np.median(dev))
    if mad < 1e-12:
        return set()
    thresh = float(mad_k) * 1.4826 * mad
    out: Set[int] = set()
    for i in range(len(vals)):
        if float(dev[i]) > thresh:
            out.add(positions[i])
    return out


def _finite_positive_px(snap: Dict[str, Any], key: str) -> Optional[float]:
    v = snap.get(key)
    if v is None:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if not np.isfinite(f) or f <= 0:
        return None
    return f


def robust_prune_selected(
    selected: List[Dict[str, Any]],
    *,
    min_width_px: float,
    lw_min: float,
    lw_max: float,
    max_matrix_condition: float,
    mad_k: float,
    ref_ratios: Optional[Dict[str, float]],
    max_ratio_rel_dev: float,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    从已通过方位筛选的条目中去掉明显病态/离谱的样本。
    硬门控：有效像素尺度、矩阵条件数、可选真值比例。
    软门控（默认）：在同一几何批次内对 **L_px/W_px/H_px 像素值** 做 MAD 离群剔除（与同视轴分组的其它图比，而非强行要求 H/L、H/W）。
    返回 (保留列表, 排除列表)；排除项为 {\"name\", \"reason\"}。
    """
    exclusions: List[Dict[str, Any]] = []
    candidates: List[Dict[str, Any]] = []

    for r in selected:
        name = r.get("name", "?")
        snap = r.get("ratios_3d")
        if not snap:
            exclusions.append({"name": name, "reason": "无 ratios_3d"})
            continue
        mstar = snap.get("mstar_axis_bucket")
        Lpx = snap.get("L_px")
        Wpx = snap.get("W_px")
        L = float(Lpx) if Lpx is not None else None
        W = float(Wpx) if Wpx is not None else None
        lw = snap.get("L_over_W")
        hl = snap.get("H_over_L")
        hw = snap.get("H_over_W")
        reasons: List[str] = []

        if mstar == "end_on":
            if W is None or W < float(min_width_px):
                reasons.append(f"端视 W_px 无效或 < min_width_px= {min_width_px}")
        elif mstar == "broadside":
            if L is None or L < float(min_width_px):
                reasons.append(f"侧视 L_px(Tr) 无效或 < min_width_px= {min_width_px}")
            if W is None or W < float(min_width_px):
                reasons.append(f"侧视 W_px(Taz) 无效或 < min_width_px= {min_width_px}")
        else:
            Wf = float(W) if W is not None else 0.0
            if Wf < float(min_width_px):
                reasons.append(f"W_px={Wf:.3f} < min_width_px({min_width_px})")
            Lf = float(L) if L is not None else 0.0
            if Lf <= 0 or not np.isfinite(Lf):
                reasons.append(f"L_px 非正或非有限 ({Lpx})")
            lwf = float(lw) if lw is not None and np.isfinite(float(lw)) else 0.0
            if not np.isfinite(lwf) or lwf <= 0:
                reasons.append(f"L/W 非正或非有限 ({lw})")
            elif lwf < float(lw_min) or lwf > float(lw_max):
                reasons.append(f"L/W={lwf:.4f} 超出 [{lw_min},{lw_max}]")

        mc = r.get("matrix_condition")
        if mc is not None and float(max_matrix_condition) > 0:
            try:
                if float(mc) > float(max_matrix_condition):
                    reasons.append(f"矩阵条件数 {float(mc):.1f} > {max_matrix_condition}")
            except (TypeError, ValueError):
                pass

        if ref_ratios and float(max_ratio_rel_dev) >= 0:
            for key, refv in ref_ratios.items():
                if refv <= 0:
                    continue
                v_raw = snap.get(key)
                if v_raw is None:
                    continue
                v = float(v_raw)
                if v <= 0 or not np.isfinite(v):
                    continue
                dev = abs(v / refv - 1.0)
                if dev > float(max_ratio_rel_dev):
                    vn = "H/L" if key == "H_over_L" else ("H/W" if key == "H_over_W" else "L/W")
                    reasons.append(
                        f"{vn}: 像素={v:.4f} 真值={refv:.4f} 相对偏差 {dev:.2f} > {max_ratio_rel_dev}"
                    )

        if reasons:
            exclusions.append({"name": name, "reason": "; ".join(reasons)})
        else:
            candidates.append(r)

    # —— 像素域 MAD：按 mstar 分桶，与同批同视轴样本比 L/W/H，而非比例硬阈值 ——
    bucket_to_ci: Dict[str, List[int]] = defaultdict(list)
    for ci, c in enumerate(candidates):
        snap = c.get("ratios_3d") or {}
        mb = snap.get("mstar_axis_bucket") if isinstance(snap, dict) else None
        key = mb if mb in ("end_on", "broadside") else "__general__"
        bucket_to_ci[key].append(ci)

    mad_reasons: Dict[int, List[str]] = defaultdict(list)
    mk = float(mad_k)

    for bucket, ci_list in bucket_to_ci.items():
        if mk <= 0 or len(ci_list) < 3:
            continue
        snaps = [candidates[i]["ratios_3d"] for i in ci_list]

        def collect_pairs(dim: str) -> List[Tuple[int, float]]:
            pairs: List[Tuple[int, float]] = []
            key_px = f"{dim}_px"
            for j, s in enumerate(snaps):
                fv = _finite_positive_px(s, key_px)
                if fv is not None:
                    pairs.append((j, fv))
            return pairs

        if bucket == "end_on":
            for j in _mad_outlier_indices(collect_pairs("W"), mk):
                mad_reasons[ci_list[j]].append(f"端视 W_px MAD 离群 (k={mad_k})")
            for j in _mad_outlier_indices(collect_pairs("H"), mk):
                mad_reasons[ci_list[j]].append(f"H_px MAD 离群·端视子集 (k={mad_k})")
        elif bucket == "broadside":
            for j in _mad_outlier_indices(collect_pairs("L"), mk):
                mad_reasons[ci_list[j]].append(f"侧视 L_px MAD 离群 (k={mad_k})")
            for j in _mad_outlier_indices(collect_pairs("H"), mk):
                mad_reasons[ci_list[j]].append(f"H_px MAD 离群·侧视子集 (k={mad_k})")
        else:
            for label, dim in (("L_px", "L"), ("W_px", "W"), ("H_px", "H")):
                for j in _mad_outlier_indices(collect_pairs(dim), mk):
                    mad_reasons[ci_list[j]].append(f"{label} MAD 离群 (k={mad_k})")

    kept: List[Dict[str, Any]] = []
    for ci, c in enumerate(candidates):
        if ci in mad_reasons:
            exclusions.append(
                {
                    "name": c.get("name"),
                    "reason": "; ".join(mad_reasons[ci]),
                }
            )
        else:
            kept.append(c)

    return kept, exclusions


def load_image_like_convert(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"无法读取图像: {path}")
    img = preprocess_sar_image(img)
    if img.dtype != np.float32:
        img = img.astype(np.float32)
    if img.max() > 1.0:
        img = img / 255.0
    return img


def run_shadow_geometry(
    image: np.ndarray,
    img_name: str,
    depression: float,
    azimuth: float,
    *,
    target_percentile: float,
    background_percentile: float,
    shadow_threshold_factor: float,
    target_mask_dilate_px: int,
    merge_target_edge: bool,
    target_mask_largest_component_only: bool,
    target_mask_min_component_area_px: int,
    diagnostic_dir: Optional[Path],
    shadow_geometry_azimuth_mode: str = "mstar_axis_split",
) -> Tuple[np.ndarray, Optional[Dict[str, Any]]]:
    tt, bt = calculate_scattering_threshold(
        image,
        target_percentile=target_percentile,
        background_percentile=background_percentile,
    )
    out_dir = str(diagnostic_dir) if diagnostic_dir else None
    mask = create_scattering_mask(
        image,
        tt,
        bt,
        shadow_threshold_factor=shadow_threshold_factor,
        output_dir=out_dir,
        img_name=img_name,
        target_mask_dilate_px=target_mask_dilate_px,
        merge_target_edge_into_interior=merge_target_edge,
        target_mask_largest_component_only=target_mask_largest_component_only,
        target_mask_min_component_area_px=target_mask_min_component_area_px,
    )
    td = calculate_target_dimensions_from_shadow(
        image,
        mask,
        float(depression),
        float(azimuth),
        shadow_geometry_azimuth_mode=shadow_geometry_azimuth_mode,
    )
    return mask, td


def _parse_angles_for_file(
    img_name: str,
    global_depression: Optional[float],
    global_azimuth: Optional[float],
) -> Tuple[float, float, Optional[str]]:
    dep, azi = global_depression, global_azimuth
    mstar_name: Optional[str] = None
    if dep is None or azi is None:
        mstar_name, fd, fa = parse_mstar_filename_quiet(img_name)
        if dep is None:
            dep = float(fd)
        if azi is None:
            azi = float(fa)
    if dep is None:
        dep = 15.0
    if azi is None:
        azi = 0.0
    return dep, azi, mstar_name


def process_one(
    path: Path,
    *,
    global_depression: Optional[float],
    global_azimuth: Optional[float],
    target_percentile: float,
    target_dimension_filter_percentile: float,
    background_percentile: float,
    shadow_threshold_factor: float,
    target_mask_dilate_px: int,
    merge_target_edge: bool,
    target_mask_largest_component_only: bool,
    target_mask_min_component_area_px: int,
    diagnostic_dir: Optional[Path],
    vis_dir: Optional[Path],
    pick_azimuth_mode: str,
    azimuth_tolerance_deg: float,
    shadow_geometry_azimuth_mode: str,
    suppress_submodule_prints: bool,
    custom_azimuth_angles_deg=None,
) -> Dict[str, Any]:
    img_name = path.name
    dep, azi, mstar_token = _parse_angles_for_file(
        img_name, global_depression, global_azimuth
    )

    try:
        ctx = contextlib.redirect_stdout(io.StringIO()) if suppress_submodule_prints else contextlib.nullcontext()
        with ctx:
            image = load_image_like_convert(path)
            mask, td = run_shadow_geometry(
                image,
                img_name,
                dep,
                azi,
                target_percentile=target_percentile,
                background_percentile=background_percentile,
                shadow_threshold_factor=shadow_threshold_factor,
                target_mask_dilate_px=target_mask_dilate_px,
                merge_target_edge=merge_target_edge,
                target_mask_largest_component_only=target_mask_largest_component_only,
                target_mask_min_component_area_px=target_mask_min_component_area_px,
                diagnostic_dir=diagnostic_dir,
                shadow_geometry_azimuth_mode=shadow_geometry_azimuth_mode,
            )
    except Exception as ex:
        return {
            "file": str(path),
            "name": img_name,
            "success": False,
            "error": str(ex),
            "selected": False,
            "depression": dep,
            "azimuth": azi,
            "target_dimensions": None,
        }

    region_vis_path: Optional[str] = None
    if vis_dir:
        vis_dir.mkdir(parents=True, exist_ok=True)
        vctx = contextlib.redirect_stdout(io.StringIO()) if suppress_submodule_prints else contextlib.nullcontext()
        with vctx:
            region_vis_path = visualize_scattering_regions(
                image,
                mask,
                str(vis_dir),
                img_name,
                verbose=not suppress_submodule_prints,
            )

    geometry_ok = td is not None
    allowed, _ = azimuth_allowed_for_shadow_dimension_gate(
        azi,
        mode=pick_azimuth_mode,
        tolerance_deg=azimuth_tolerance_deg,
        custom_angles_deg=custom_azimuth_angles_deg,
    )
    selected = geometry_ok and allowed

    row: Dict[str, Any] = {
        "file": str(path),
        "name": img_name,
        "success": geometry_ok,
        "mstar_target": mstar_token,
        "depression": dep,
        "azimuth": azi,
        "pick_azimuth_ok": allowed,
        "selected": selected,
        "target_dimensions": _to_jsonable(td) if td else None,
    }
    if region_vis_path:
        row["region_vis_path"] = region_vis_path
    try:
        row["dataset_probe"] = _extract_mask_probe(np.asarray(mask), azi)
        filtered_probe = _extract_filtered_target_probe(
            path,
            percentile=float(target_dimension_filter_percentile),
        )
        if isinstance(row["dataset_probe"], dict) and isinstance(filtered_probe, dict):
            row["dataset_probe"].update(filtered_probe)
            _update_shadow_side_from_filtered_target(row["dataset_probe"])
    except Exception:
        row["dataset_probe"] = None
    if geometry_ok and td:
        hval = td.get("height")
        row["height"] = float(hval) if hval is not None else None
        row["shadow_length"] = float(td.get("shadow_length", 0))
        row["ratios_3d"] = snapshot_3d_ratios(td)
        ci = td.get("calculation_info")
        if isinstance(ci, dict) and ci.get("matrix_condition") is not None:
            try:
                row["matrix_condition"] = float(ci["matrix_condition"])
            except (TypeError, ValueError):
                pass
    return row


def main() -> int:
    ap = argparse.ArgumentParser(
        description="阴影几何批量工具：扫描目录（同 convert）+ 筛选合适图像"
    )
    ap.add_argument(
        "path",
        type=Path,
        help="SAR 图像文件，或与 convert 相同的数据目录（含 input/ 或根目录放图）",
    )
    ap.add_argument("--depression", type=float, default=None, help="俯视角（度），指定则所有图共用")
    ap.add_argument("--azimuth", type=float, default=None, help="方位角（度），指定则所有图共用")
    ap.add_argument(
        "--target-percentile",
        type=float,
        default=99.5,
        help="与 convert --target_percentile 一致（默认对齐 config.py，勿再用旧版 70）",
    )
    ap.add_argument(
        "--background-percentile",
        type=float,
        default=1.0,
        help="与 convert --background_percentile 一致（默认对齐 config.py）",
    )
    ap.add_argument(
        "--shadow-threshold-factor",
        type=float,
        default=0.0001,
        help="与 convert --shadow_threshold_factor 一致（默认对齐 config.py）",
    )
    ap.add_argument("--target-mask-dilate-px", type=int, default=3)
    ap.add_argument(
        "--target-dimension-filter-percentile",
        type=float,
        default=99.0,
        help=(
            "目标长宽提取前的背景过滤分位数；使用 utils/filter_background.py "
            "同源 percentile+largest_cc 逻辑，默认 99。"
        ),
    )
    ap.add_argument(
        "--merge-target-edge",
        action="store_true",
        help="散射边缘并入内部（掩码 0/1/3）",
    )
    ap.add_argument(
        "--no-largest-component-only",
        action="store_true",
        help="关闭「仅最大高亮连通域」",
    )
    ap.add_argument("--target-mask-min-component-area-px", type=int, default=0)
    ap.add_argument(
        "--diagnostic-dir",
        type=Path,
        default=None,
        help="阴影诊断 txt 输出目录（每张 shadow_diagnostic_<stem>.txt）",
    )
    ap.add_argument(
        "--vis-dir",
        type=Path,
        default=None,
        help="区域划分可视化输出目录",
    )
    ap.add_argument(
        "--json",
        type=Path,
        default=None,
        help="结果 JSON（批量为数组 + manifest）",
    )
    ap.add_argument(
        "--shadow-geometry-azimuth-mode",
        type=str,
        default="mstar_axis_split",
        choices=("oblique", "cardinal", "mstar_axis_split", "any"),
        help=(
            "传入 calculate_target_dimensions_from_shadow。默认 mstar_axis_split（仅 90°/270°，L=Tr、W=Taz）；"
            "与 convert 一致跑 oblique 时请显式传 oblique。"
        ),
    )
    ap.add_argument(
        "--pick-azimuth-mode",
        type=str,
        default="mstar_axis_split",
        choices=("near_zero", "cardinal", "mstar_axis_split", "diagonal", "custom_oblique", "oblique", "any"),
        help="几何成功后再按方位筛选。默认 mstar_axis_split（**仅 90°/270°±容差**，L=Tr、W=Taz）；"
        "需斜视样本汇总时请显式 oblique。",
    )
    ap.add_argument(
        "--pick-azimuth-angles",
        type=str,
        default="45,125,225,315",
        help="custom_oblique reference azimuths in degrees, comma-separated.",
    )
    ap.add_argument(
        "--pick-azimuth-tolerance-deg",
        type=float,
        default=5.0,
        help="与 --pick-azimuth-mode 配套的容差（度）",
    )
    ap.add_argument(
        "--quiet",
        action="store_true",
        help="批量时屏蔽 feature_extraction 内部 print，仅保留本脚本摘要",
    )
    ap.add_argument(
        "--robust-filter",
        dest="robust_filter",
        action="store_true",
        default=True,
        help="对「合适」样本做鲁棒剔除后再汇总（默认开启）",
    )
    ap.add_argument(
        "--no-robust-filter",
        dest="robust_filter",
        action="store_false",
        help="关闭鲁棒剔除，仅用全部合适样本算中位数",
    )
    ap.add_argument(
        "--min-width-px",
        type=float,
        default=1.0,
        help="剔除 W 像素低于此值的解（近零宽 = 线性方程病态）",
    )
    ap.add_argument("--lw-min", type=float, default=0.25, help="可接受 L/W 下限（车辆通常 >~1.5，放宽容错）")
    ap.add_argument("--lw-max", type=float, default=8.0, help="可接受 L/W 上限")
    ap.add_argument(
        "--max-matrix-condition",
        type=float,
        default=120.0,
        help="线性方程组条件数上限；≤0 表示不检查",
    )
    ap.add_argument(
        "--mad-k",
        type=float,
        default=4.0,
        help="同批同几何分组内，对像素 L_px/W_px/H_px 做 MAD 离群剔除的倍数；≤0 关闭（每组至少 3 张才参与）",
    )
    ap.add_argument("--ref-length-m", type=float, default=None, help="真值长 L（米），用于打印对照；配合 --filter-by-ref 才参与剔除")
    ap.add_argument("--ref-width-m", type=float, default=None, help="真值宽 W（米）")
    ap.add_argument("--ref-height-m", type=float, default=None, help="真值高 H（米）")
    ap.add_argument(
        "--filter-by-ref",
        action="store_true",
        help="若同时给出 ref-length/width/height-m，按 --max-ratio-rel-dev 相对真值比例剔除",
    )
    ap.add_argument(
        "--max-ratio-rel-dev",
        type=float,
        default=0.85,
        help="与 --filter-by-ref 配合：|r/r_gt-1| 超此值则剔除（像素模型系统偏差大时慎开）",
    )
    args = ap.parse_args()

    root = args.path.resolve()
    if root.is_file():
        paths = [root]
        data_dir = root.parent
    elif root.is_dir():
        data_dir = root
        paths = collect_image_files_like_convert(root)
    else:
        print(f"路径不存在: {root}")
        return 1

    if not paths:
        print(f"未找到图像: {root}（已按 convert 规则搜索 input/ 与数据根目录）")
        return 1

    batch = len(paths) > 1
    quiet = bool(args.quiet) or batch

    print(f"待处理 {len(paths)} 张图像，数据目录: {data_dir}")
    if batch:
        print(
            f"模式: --shadow-geometry-azimuth-mode={args.shadow_geometry_azimuth_mode!r}；"
            f"筛选: target_dimensions 成功 且 --pick-azimuth-mode={args.pick_azimuth_mode!r} "
            f"(±{args.pick_azimuth_tolerance_deg:g}°)"
        )

    rows: List[Dict[str, Any]] = []
    for i, p in enumerate(paths, 1):
        if batch and quiet:
            print(f"[{i}/{len(paths)}] {p.name} ... ", end="", flush=True)
        row = process_one(
            p,
            global_depression=args.depression,
            global_azimuth=args.azimuth,
            target_percentile=args.target_percentile,
            target_dimension_filter_percentile=args.target_dimension_filter_percentile,
            background_percentile=args.background_percentile,
            shadow_threshold_factor=args.shadow_threshold_factor,
            target_mask_dilate_px=args.target_mask_dilate_px,
            merge_target_edge=args.merge_target_edge,
            target_mask_largest_component_only=not args.no_largest_component_only,
            target_mask_min_component_area_px=args.target_mask_min_component_area_px,
            diagnostic_dir=args.diagnostic_dir,
            vis_dir=args.vis_dir,
            pick_azimuth_mode=args.pick_azimuth_mode,
            azimuth_tolerance_deg=args.pick_azimuth_tolerance_deg,
            shadow_geometry_azimuth_mode=args.shadow_geometry_azimuth_mode,
            suppress_submodule_prints=quiet,
            custom_azimuth_angles_deg=parse_azimuth_angle_list(args.pick_azimuth_angles),
        )
        rows.append(row)
        if batch and quiet:
            if row.get("error"):
                print(f"ERROR {row['error'][:50]}")
            elif row["selected"]:
                s3 = row.get("ratios_3d") or {}
                print(f"OK (合适) az={row['azimuth']:.1f}°{compact_progress_ratios_suffix(s3)}")
            elif row["success"]:
                print(f"几何OK 但未入选方位 az={row['azimuth']:.1f}°")
            else:
                print("几何失败 (无 target_dimensions)")

        if not batch and not quiet:
            print(
                f"文件: {p.name}  dep={row['depression']}° az={row['azimuth']:.1f}° "
                f"mstar={row.get('mstar_target')!r}"
            )
            if row.get("error"):
                print(f"错误: {row['error']}")
            td = row.get("target_dimensions")
            if td is None:
                print("target_dimensions: None")
            else:
                print("target_dimensions 摘要:")
                for k in (
                    "height",
                    "length",
                    "width",
                    "shadow_length",
                    "height_length_ratio",
                    "height_width_ratio",
                    "length_width_ratio",
                    "orientation_angle",
                ):
                    if k in td:
                        print(f"  {k}: {td[k]}")
                rx = row.get("ratios_3d")
                if rx:
                    print("提取长宽(像素)、阴影估高(像素) 与 比例:")
                    print(f"  {broadcast_ratios_line(p.name, rx)}")
            print(f"selected (几何OK 且 方位筛选): {row['selected']}")

    selected = [r for r in rows if r.get("selected")]
    dataset_convention = infer_dataset_convention(rows)
    for r in selected:
        _apply_dataset_convention_to_row(r, dataset_convention)
    clean_axis_selected, clean_axis_meta = _axis_clean_rows_from_dataset_convention(
        rows,
        dataset_convention,
        tol=args.pick_azimuth_tolerance_deg,
    )
    if clean_axis_meta.get("clean_axis"):
        print(
            "clean-axis L/W: "
            f"shadow={clean_axis_meta.get('shadow_side')} "
            f"clean_axis=image_{clean_axis_meta.get('clean_axis')} "
            f"L_samples={clean_axis_meta.get('n_L_samples')} "
            f"W_samples={clean_axis_meta.get('n_W_samples')}"
        )
        for s in clean_axis_meta.get("samples", []) or []:
            try:
                az_s = f"{float(s.get('azimuth_deg')):.1f}"
            except (TypeError, ValueError):
                az_s = "?"
            used = "used" if s.get("used") else f"skip:{s.get('skip_reason') or 'unknown'}"
            print(
                "  "
                f"{s.get('name', '?')} az={az_s} role={s.get('role')} "
                f"shadow={clean_axis_meta.get('shadow_side')} "
                f"dim={s.get('dimension')} axis=image_{s.get('clean_axis')} "
                f"used_px={format_px_optional_2(s.get('clean_px'))} "
                f"filtered_px={format_px_optional_2(s.get('clean_filtered_px'))} "
                f"core_px={format_px_optional_2(s.get('clean_core_px'))} "
                f"all_px={format_px_optional_2(s.get('clean_all_px'))} "
                f"filtered_x={format_px_optional_2(s.get('filtered_bbox_width_px'))} "
                f"filtered_y={format_px_optional_2(s.get('filtered_bbox_height_px'))} "
                f"{used}"
            )
    sel_snaps = [r["ratios_3d"] for r in selected if r.get("ratios_3d")]
    agg = median_mean_ratios(sel_snaps)

    ref_ratios: Optional[Dict[str, float]] = None
    if (
        args.ref_length_m is not None
        and args.ref_width_m is not None
        and args.ref_height_m is not None
    ):
        try:
            ref_ratios = ref_ratios_from_meters(
                args.ref_length_m, args.ref_width_m, args.ref_height_m
            )
        except ValueError as e:
            print(f"警告: 参考尺寸无效: {e}")

    ref_for_filter = ref_ratios if (ref_ratios and args.filter_by_ref) else None

    robust_selected = list(selected)
    robust_excl: List[Dict[str, Any]] = []
    agg_robust: Dict[str, Any] = {}
    if args.robust_filter and selected:
        robust_selected, robust_excl = robust_prune_selected(
            selected,
            min_width_px=args.min_width_px,
            lw_min=args.lw_min,
            lw_max=args.lw_max,
            max_matrix_condition=args.max_matrix_condition,
            mad_k=args.mad_k,
            ref_ratios=ref_for_filter,
            max_ratio_rel_dev=args.max_ratio_rel_dev,
        )
        rsnap = [r["ratios_3d"] for r in robust_selected if r.get("ratios_3d")]
        agg_robust = median_mean_ratios(rsnap)
    elif selected:
        rsnap = [r["ratios_3d"] for r in selected if r.get("ratios_3d")]
        agg_robust = median_mean_ratios(rsnap)
    summary_selected, summary_agg = _merge_clean_axis_lw_into_summary_inputs(
        robust_selected,
        agg_robust,
        clean_axis_selected,
    )
    if clean_axis_selected:
        robust_selected = summary_selected
        agg_robust = summary_agg

    print("\n--- 汇总 ---")
    if ref_ratios:
        print(
            f"参考真值(米): L={args.ref_length_m:g} W={args.ref_width_m:g} H={args.ref_height_m:g} → "
            f"H/L={ref_ratios['H_over_L']:.4f} H/W={ref_ratios['H_over_W']:.4f} L/W={ref_ratios['L_over_W']:.4f}"
        )
        if args.filter_by_ref:
            print(f"  已启用 --filter-by-ref，相对偏差上限 |r/r_gt-1|={args.max_ratio_rel_dev}")
    print(f"成功 target_dimensions: {sum(1 for r in rows if r['success'])}/{len(rows)}")
    print(f"合适图像 (--pick-azimuth-mode): {len(selected)}/{len(rows)}")
    for r in selected:
        snap = r.get("ratios_3d")
        mc = r.get("matrix_condition")
        mc_s = f" cond={mc:.1f}" if mc is not None else ""
        base = (
            f"  - {r['name']}  估高H={format_px_optional_2(r.get('height'))}px  "
            f"S={r.get('shadow_length', 0):.2f}px  "
            f"az={r['azimuth']:.1f}°{mc_s}"
        )
        if snap:
            ms = snap.get("mstar_axis_bucket")
            if ms == "end_on":
                suff = (
                    f" | 提取W={format_px_optional_2(snap.get('W_px'))}px "
                    f"H/W={format_ratio_optional_4(snap.get('H_over_W'))}"
                )
            elif ms == "broadside":
                suff = (
                    f" | 提取L={format_px_optional_2(snap.get('L_px'))}px "
                    f"提取W={format_px_optional_2(snap.get('W_px'))}px "
                    f"L/W={format_ratio_optional_4(snap.get('L_over_W'))} "
                    f"H/L={format_ratio_optional_4(snap.get('H_over_L'))}"
                )
            else:
                suff = (
                    f" | H/L={format_ratio_optional_4(snap.get('H_over_L'))} "
                    f"H/W={format_ratio_optional_4(snap.get('H_over_W'))} "
                    f"L/W={format_ratio_optional_4(snap.get('L_over_W'))}"
                )
            print(base + suff)
        else:
            print(base)

    if sel_snaps:
        print("\n--- 提取长宽(像素)、阴影估高(像素) 与 比例（合适图像）---")
        for r in selected:
            snap = r.get("ratios_3d")
            if snap:
                print(f"  {broadcast_ratios_line(r['name'], snap)}")
        if agg.get("n", 0) >= 1:
            print("\n合适样本 比例汇总（中位数 / 均值；分项仅统计该量在本批中有效的图）:")
            print(
                f"  n={agg['n']}  H/L: {agg_median_mean_str(agg, 'H_over_L')}  "
                f"H/W: {agg_median_mean_str(agg, 'H_over_W')}  "
                f"L/W: {agg_median_mean_str(agg, 'L_over_W')}"
            )
            print(
                f"  像素 中位数/均值 — 提取L: {agg_median_mean_str(agg, 'L_px', fmt='.2f')} ; "
                f"提取W: {agg_median_mean_str(agg, 'W_px', fmt='.2f')} ; "
                f"估高H: {agg_median_mean_str(agg, 'H_px', fmt='.2f')}"
            )

    if args.robust_filter and selected:
        print(
            f"\n--- 鲁棒子集（硬门控：min_W、c非MSTAR时 L/W 区间、cond；"
            f"软门控：同批同视轴内 L/W/H 像素 MAD_k={args.mad_k}，每组≥3 才判离群）---"
        )
        print(f"保留 {len(robust_selected)}/{len(selected)}")
        for ex in robust_excl:
            print(f"  剔除 {ex.get('name')}: {ex.get('reason')}")
        if agg_robust.get("n", 0) >= 1:
            print("\n鲁棒子集 比例汇总（中位数 / 均值；分项有效样本同上）:")
            print(
                f"  n={agg_robust['n']}  H/L: {agg_median_mean_str(agg_robust, 'H_over_L')}  "
                f"H/W: {agg_median_mean_str(agg_robust, 'H_over_W')}  "
                f"L/W: {agg_median_mean_str(agg_robust, 'L_over_W')}"
            )
            print(
                f"  像素 中位数/均值 — 提取L: {agg_median_mean_str(agg_robust, 'L_px', fmt='.2f')} ; "
                f"提取W: {agg_median_mean_str(agg_robust, 'W_px', fmt='.2f')} ; "
                f"估高H: {agg_median_mean_str(agg_robust, 'H_px', fmt='.2f')}"
            )

    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "data_dir": str(data_dir),
            "n_images": len(paths),
            "pick_azimuth_mode": args.pick_azimuth_mode,
            "pick_azimuth_tolerance_deg": args.pick_azimuth_tolerance_deg,
            "ref_ratios_gt": ref_ratios,
            "filter_by_ref": bool(args.filter_by_ref),
            "robust_filter": bool(args.robust_filter),
            "robust_params": {
                "min_width_px": args.min_width_px,
                "lw_min": args.lw_min,
                "lw_max": args.lw_max,
                "max_matrix_condition": args.max_matrix_condition,
                "mad_k": args.mad_k,
                "max_ratio_rel_dev": args.max_ratio_rel_dev,
            },
            "selected_names": [r["name"] for r in selected],
            "robust_selected_names": [r["name"] for r in robust_selected],
            "robust_exclusions": robust_excl,
            "dataset_convention": dataset_convention,
            "selected_3d_ratios_summary": agg,
            "robust_selected_3d_ratios_summary": agg_robust,
            "results": rows,
        }
        args.json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"已写 JSON: {args.json}")

    return 0


def _filter_desc_for_pick(mode: str, tol: float) -> str:
    m = (mode or "oblique").strip().lower()
    if m == "cardinal":
        return f"0°、90°、180°、270°、360°±{tol:g}°（cardinal）"
    if m == "mstar_axis_split":
        return (
            f"MSTAR 侧视汇总：仅 90°/270°±{tol:g}°（L=Tr、W=Taz）；"
            f"与 shadow_geometry_azimuth_mode=mstar_axis_split 一致"
        )
    if m == "diagonal":
        return f"45°、135°、225°、315°±{tol:g}°（diagonal）"
    if m == "custom_oblique":
        return f"45°、125°、225°、315°±{tol:g}°（custom_oblique）"
    if m == "oblique":
        return f"15° 步进斜视、且偏离 0/90/180/270±{tol:g}°（oblique）"
    if m == "any":
        return "任意方位（any）"
    return f"0° 左右（含 360° 等价），±{tol:g}°（near_zero）"


def _finite_series_from_snaps(
    robust_selected: List[Dict[str, Any]],
) -> Tuple[List[float], List[float], List[float], List[float], List[float], List[float]]:
    """鲁棒子集上的像素 H/L/W 与同图 H/L、H/W 比例列表（供写「均值/中位数=」行文）。"""
    heights: List[float] = []
    lengths: List[float] = []
    widths: List[float] = []
    lw_ratios: List[float] = []
    hl_ratios: List[float] = []
    hw_ratios: List[float] = []
    for r in robust_selected:
        snap = r.get("ratios_3d")
        if not isinstance(snap, dict):
            continue
        for key, bucket in (
            ("H_px", heights),
            ("L_px", lengths),
            ("W_px", widths),
        ):
            v = snap.get(key)
            if v is None:
                continue
            try:
                fv = float(v)
            except (TypeError, ValueError):
                continue
            if np.isfinite(fv) and fv > 0:
                bucket.append(fv)
        for key, bucket in (
            ("L_over_W", lw_ratios),
            ("H_over_L", hl_ratios),
            ("H_over_W", hw_ratios),
        ):
            v = snap.get(key)
            if v is None:
                continue
            try:
                fv = float(v)
            except (TypeError, ValueError):
                continue
            if np.isfinite(fv) and fv > 0:
                bucket.append(fv)
    return heights, lengths, widths, lw_ratios, hl_ratios, hw_ratios


def _write_pixel_stat_block(
    label: str, vals: List[float], lines: List[str], *, none_msg: str
) -> None:
    """与 feature_extraction 落盘格式一致，供 post_sfm.summary_parser 解析「中位数=」。"""
    if not vals:
        lines.append(none_msg + "\n")
        return
    a = np.asarray(vals, dtype=np.float64)
    lines.append(
        f"{label}: 均值={float(a.mean()):.2f}, 标准差={float(a.std()):.2f}, "
        f"范围=[{float(a.min()):.2f}, {float(a.max()):.2f}], 中位数={float(np.median(a)):.2f}\n"
    )


def _write_ratio_stat_block(
    label: str, vals: List[float], lines: List[str], *, none_msg: str
) -> None:
    if not vals:
        lines.append(none_msg + "\n")
        return
    a = np.asarray(vals, dtype=np.float64)
    lines.append(
        f"{label}: 均值={float(a.mean()):.4f}, 标准差={float(a.std()):.4f}, "
        f"范围=[{float(a.min()):.4f}, {float(a.max()):.4f}], 中位数={float(np.median(a)):.4f}\n"
    )


def write_target_dimension_constraints_summary_txt_for_sfm(
    path: Path,
    *,
    agg: Dict[str, Any],
    robust_selected: List[Dict[str, Any]],
    n_images: int,
    n_geom_ok: int,
    n_selected: int,
    n_robust: int,
    pick_mode: str,
    pick_tol: float,
    geom_mode: str,
    robust_filter: bool,
    robust_excl: List[Dict[str, Any]],
    dataset_convention: Optional[Dict[str, Any]] = None,
    clean_axis_meta: Optional[Dict[str, Any]] = None,
) -> None:
    """
    供比例盒 ``parse_target_dimension_summary`` 解析：须含「高度 (H): … 中位数=」「长度 (L): …」等行
    （与 feature_extraction 写 txt 的句式一致）；并保留 ``推荐…比例`` 行以兼容 ``load_target_dimension_constraints_from_summary``。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    heights, lengths, widths, lw_ratios, hl_ratios, hw_ratios = _finite_series_from_snaps(robust_selected)

    h_l = agg.get("H_over_L_median")
    h_w = agg.get("H_over_W_median")
    l_w = agg.get("L_over_W_median")
    med_l = agg.get("L_px_median")
    med_w = agg.get("W_px_median")
    l_w_composite = None
    if (
        med_l is not None
        and med_w is not None
        and float(med_w) > 0
        and np.isfinite(float(med_l))
        and np.isfinite(float(med_w))
    ):
        l_w_composite = float(med_l) / float(med_w)
    if l_w is None or not (isinstance(l_w, (int, float)) and np.isfinite(float(l_w)) and float(l_w) > 0):
        l_w = l_w_composite

    h_l_composite = None
    h_w_composite = None
    try:
        med_h = agg.get("H_px_median")
        if med_h is not None and np.isfinite(float(med_h)) and float(med_h) > 0:
            if med_l is not None and np.isfinite(float(med_l)) and float(med_l) > 0:
                h_l_composite = float(med_h) / float(med_l)
            if med_w is not None and np.isfinite(float(med_w)) and float(med_w) > 0:
                h_w_composite = float(med_h) / float(med_w)
    except (TypeError, ValueError):
        h_l_composite = None
        h_w_composite = None
    if not hl_ratios and h_l_composite is not None and h_l_composite > 0:
        hl_ratios = [float(h_l_composite)]
    if not hw_ratios and h_w_composite is not None and h_w_composite > 0:
        hw_ratios = [float(h_w_composite)]

    recommended_h_l = float(np.median(hl_ratios)) if hl_ratios else 0.0
    if recommended_h_l <= 0 and h_l is not None:
        try:
            fv = float(h_l)
            if np.isfinite(fv) and fv > 0:
                recommended_h_l = fv
        except (TypeError, ValueError):
            pass
    recommended_h_w = float(np.median(hw_ratios)) if hw_ratios else 0.0
    if recommended_h_w <= 0 and h_w is not None:
        try:
            fv = float(h_w)
            if np.isfinite(fv) and fv > 0:
                recommended_h_w = fv
        except (TypeError, ValueError):
            pass
    valid_lw = [r for r in lw_ratios if r > 0]
    recommended_l_w = float(np.median(valid_lw)) if valid_lw else (float(l_w) if l_w is not None else 0.0)
    if recommended_l_w <= 0 and l_w_composite is not None and l_w_composite > 0:
        recommended_l_w = float(l_w_composite)
    l_w_for_file = recommended_l_w if recommended_l_w > 0 else (
        float(l_w_composite) if l_w_composite and l_w_composite > 0 else 0.0
    )

    lines: List[str] = [
        "=" * 70 + "\n",
        "SAR阴影几何模型比例约束数据汇总报告\n",
        "=" * 70 + "\n",
        f"生成时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n",
        f"来源: shadow_target_dimensions_standalone（convert --convert_use_standalone_shadow_target_dimensions）\n",
        f"方位角筛选: {_filter_desc_for_pick(pick_mode, pick_tol)} (mode={pick_mode})\n",
        f"单张几何模式 shadow_geometry_azimuth_mode: {geom_mode}\n",
        f"鲁棒剔除: {'开' if robust_filter else '关'}；汇总样本数（方位入选 {n_selected} → 鲁棒保留 {n_robust}）\n",
        f"成功算出 target_dimensions: {n_geom_ok}/{n_images}\n",
        f"有效图像数量: {n_robust}/{n_images}\n",
        "\n",
        "【目标尺寸统计（像素单位）】\n",
    ]
    if dataset_convention:
        dc = dataset_convention
        lines.extend(
            [
                "【数据集约定自动探测】\n",
                f"阴影主要位置: {dc.get('shadow_side', 'unknown')} "
                f"(confidence={float(dc.get('shadow_side_confidence', 0.0)):.2f}, "
                f"counts={dc.get('shadow_side_counts', {})})\n",
                f"0°长轴映射: {dc.get('zero_azimuth_axis_mapping') or 'unknown'} "
                f"(confidence={float(dc.get('zero_azimuth_axis_confidence', 0.0)):.2f})\n",
                f"侧视 L/W 映射: {dc.get('side_view_lw_mapping', 'unknown')} "
                f"(confidence={float(dc.get('side_view_axis_confidence', 0.0)):.2f})\n",
                f"方位角增加时图像旋转方向: {dc.get('rotation_direction', 'unknown')} "
                f"(sign={dc.get('rotation_sign')}, confidence={float(dc.get('rotation_confidence', 0.0)):.2f})\n",
                f"refiner 阴影方向偏置: {dc.get('refiner_shadow_direction_offset_deg')}\n",
                f"gs 光学圆环方位 sign: {dc.get('gs_optical_ring_azimuth_sign')}\n",
                f"机器可读文件: {_CONVENTION_JSON_NAME}\n",
            ]
        )
    if clean_axis_meta and clean_axis_meta.get("clean_axis"):
        cam = clean_axis_meta
        lines.extend(
            [
                "clean-axis L/W extraction: "
                f"shadow={cam.get('shadow_side', 'unknown')} -> "
                f"clean_axis=image_{cam.get('clean_axis')}; "
                f"azimuths=0/90/270±{float(cam.get('azimuth_tolerance_deg', pick_tol)):.1f}deg; "
                f"L_samples={int(cam.get('n_L_samples', 0) or 0)}, "
                f"W_samples={int(cam.get('n_W_samples', 0) or 0)}\n",
            ]
        )
        if cam.get("L_px_median") is not None:
            lines.append(f"clean-axis L_median_px: {float(cam['L_px_median']):.2f}\n")
        if cam.get("W_px_median") is not None:
            lines.append(f"clean-axis W_median_px: {float(cam['W_px_median']):.2f}\n")
        if cam.get("L_over_W_composite") is not None:
            lines.append(f"clean-axis L_med/W_med: {float(cam['L_over_W_composite']):.4f}\n")
        samples = cam.get("samples")
        if isinstance(samples, list) and samples:
            lines.append("clean-axis samples (0/90/270):\n")
            for s in samples:
                try:
                    azs = f"{float(s.get('azimuth_deg')):.1f}"
                except (TypeError, ValueError):
                    azs = "?"
                used = "used" if s.get("used") else f"skip:{s.get('skip_reason') or 'unknown'}"
                lines.append(
                    "  "
                    f"{s.get('name', '?')} az={azs} role={s.get('role')} "
                    f"shadow={cam.get('shadow_side', 'unknown')} "
                    f"dim={s.get('dimension')} clean_axis=image_{s.get('clean_axis')} "
                    f"used_clean_px={format_px_optional_2(s.get('clean_px'))} "
                    f"source={s.get('clean_px_source', 'unknown')} "
                    f"filtered_clean_px={format_px_optional_2(s.get('clean_filtered_px'))} "
                    f"core_clean_px={format_px_optional_2(s.get('clean_core_px'))} "
                    f"all_clean_px={format_px_optional_2(s.get('clean_all_px'))} "
                    f"filtered_x={format_px_optional_2(s.get('filtered_bbox_width_px'))} "
                    f"filtered_y={format_px_optional_2(s.get('filtered_bbox_height_px'))} "
                    f"core_x={format_px_optional_2(s.get('target_core_bbox_width_px'))} "
                    f"core_y={format_px_optional_2(s.get('target_core_bbox_height_px'))} "
                    f"all_x={format_px_optional_2(s.get('target_bbox_width_px'))} "
                    f"all_y={format_px_optional_2(s.get('target_bbox_height_px'))} "
                    f"{used}\n"
                )
    lines.append("\n")
    _write_pixel_stat_block("高度 (H)", heights, lines, none_msg="高度 (H): 无有效样本")
    _write_pixel_stat_block("长度 (L)", lengths, lines, none_msg="长度 (L): 无有效样本")
    _write_pixel_stat_block("宽度 (W)", widths, lines, none_msg="宽度 (W): 无有效样本")
    lines.append("\n")
    lines.append("【关键比例约束】\n")
    _write_ratio_stat_block(
        "高度/长度比例 (H/L)",
        hl_ratios,
        lines,
        none_msg="高度/长度比例 (H/L): 无有效样本",
    )
    _write_ratio_stat_block(
        "高度/宽度比例 (H/W)",
        hw_ratios,
        lines,
        none_msg="高度/宽度比例 (H/W): 无有效样本",
    )
    if valid_lw:
        _write_ratio_stat_block(
            "长度/宽度比例 (L/W)",
            valid_lw,
            lines,
            none_msg="长度/宽度比例 (L/W): 无有效样本",
        )
    elif l_w_composite is not None and l_w_composite > 0:
        lines.append(
            f"长度/宽度比例 (L/W): 无单张同图样本；合成 L_med/W_med={l_w_composite:.4f}\n"
        )
    else:
        lines.append("长度/宽度比例 (L/W): 无有效样本\n")

    lines.append("\n")
    lines.append("【推荐的点云约束参数】\n")
    if recommended_h_l > 0:
        lines.append(f"推荐高度/长度比例: {recommended_h_l:.4f}\n")
        lines.append(f"推荐高度/长度比例 (H/L): {recommended_h_l:.4f}\n")
    else:
        lines.append("推荐高度/长度比例: N/A（无有效 H/L 样本）\n")
    if recommended_h_w > 0:
        lines.append(f"推荐高度/宽度比例: {recommended_h_w:.4f}\n")
        lines.append(f"推荐高度/宽度比例 (H/W): {recommended_h_w:.4f}\n")
    else:
        lines.append("推荐高度/宽度比例: N/A（无有效 H/W 样本）\n")
    if l_w_for_file > 0:
        lines.append(f"推荐长度/宽度比例: {l_w_for_file:.4f}\n")
        lines.append(f"推荐长度/宽度比例 (L/W，单张同图 L+W): {l_w_for_file:.4f}\n")
    lines.append("\n")

    if robust_excl:
        lines.append("【鲁棒剔除】\n")
        for ex in robust_excl:
            lines.append(f"  - {ex.get('name')}: {ex.get('reason')}\n")
        lines.append("\n")

    # 【详细数据（每张图像）】朝向角 — 供 median_orientation_deg_from_summary_file 可选使用
    lines.append("【详细数据（每张图像）】\n")
    for r in robust_selected:
        name = str(r.get("name", "?"))
        td = r.get("target_dimensions")
        gamma = None
        if isinstance(td, dict) and td.get("orientation_angle") is not None:
            try:
                gamma = float(td["orientation_angle"])
            except (TypeError, ValueError):
                gamma = None
        if gamma is not None:
            lines.append(f"图像 {name}\n")
            lines.append(f"  朝向角: {gamma:.1f}°\n")

    path.write_text("".join(lines), encoding="utf-8")


def run_standalone_target_dimension_summary_for_convert(args: Any) -> Optional[str]:
    """
    供 convert / ``extract_features_multiprocess`` 调用：与 CLI 批量逻辑一致，写入
    ``<source_path>/<visualization_dir>/target_dimension_constraints_summary.txt``。
    """
    source = Path(str(getattr(args, "source_path", "") or "")).resolve()
    if not source.is_dir():
        print(f"⚠️ standalone 阴影汇总: source_path 非目录: {source}")
        return None

    viz_rel = getattr(args, "visualization_dir", "adaptive_threshold_visualization") or "adaptive_threshold_visualization"
    out_dir = source / Path(viz_rel)
    summary_path = out_dir / "target_dimension_constraints_summary.txt"

    paths = collect_image_files_like_convert(source)
    if not paths:
        print(f"⚠️ standalone 阴影汇总: 未在 {source} 找到图像（input/ 或根目录）")
        return None

    geom_mode = str(getattr(args, "shadow_geometry_azimuth_mode", "oblique") or "oblique").strip().lower()
    pick_mode = str(
        getattr(args, "target_dimension_summary_azimuth_mode", "oblique") or "oblique"
    ).strip().lower()
    pick_tol = float(getattr(args, "target_dimension_summary_azimuth_tolerance_deg", 5.0) or 5.0)

    robust_filter = not bool(getattr(args, "no_standalone_shadow_robust_filter", False))
    mad_k = float(getattr(args, "standalone_shadow_mad_k", 4.0) or 0.0)

    tp = float(getattr(args, "target_percentile", 95.0))
    tdfp = float(getattr(args, "target_dimension_filter_percentile", 99.0))
    bp = float(getattr(args, "background_percentile", 1.0))
    stf = float(getattr(args, "shadow_threshold_factor", 0.0001))
    tdpx = int(getattr(args, "target_mask_dilate_px", 0))
    merge_edge = bool(getattr(args, "merge_scattering_target_edge", False))
    largest_only = bool(getattr(args, "target_mask_largest_component_only", True))
    min_ca = int(getattr(args, "target_mask_min_component_area_px", 0) or 0)
    custom_angles = parse_azimuth_angle_list(
        getattr(args, "target_dimension_summary_azimuth_angles", None)
    )

    print(
        f"\n📐 standalone 阴影几何批处理: {len(paths)} 张 → {summary_path}\n"
        f"   shadow_geometry_azimuth_mode={geom_mode!r}；"
        f"汇总筛选 target_dimension_summary_azimuth_mode={pick_mode!r} (±{pick_tol:g}°)；"
        f"鲁棒剔除={'开' if robust_filter else '关'}"
    )

    rows: List[Dict[str, Any]] = []
    quiet = True
    for i, p in enumerate(paths, 1):
        print(f"   [{i}/{len(paths)}] {p.name}", flush=True)
        row = process_one(
            p,
            global_depression=None,
            global_azimuth=None,
            target_percentile=tp,
            target_dimension_filter_percentile=tdfp,
            background_percentile=bp,
            shadow_threshold_factor=stf,
            target_mask_dilate_px=tdpx,
            merge_target_edge=merge_edge,
            target_mask_largest_component_only=largest_only,
            target_mask_min_component_area_px=min_ca,
            diagnostic_dir=None,
            vis_dir=None,
            pick_azimuth_mode=pick_mode,
            azimuth_tolerance_deg=pick_tol,
            shadow_geometry_azimuth_mode=geom_mode,
            suppress_submodule_prints=quiet,
            custom_azimuth_angles_deg=custom_angles,
        )
        rows.append(row)

    selected = [r for r in rows if r.get("selected")]
    n_geom_ok = sum(1 for r in rows if r.get("success"))
    dataset_convention = infer_dataset_convention(rows)
    for r in selected:
        _apply_dataset_convention_to_row(r, dataset_convention)
    clean_axis_selected, clean_axis_meta = _axis_clean_rows_from_dataset_convention(
        rows,
        dataset_convention,
        tol=pick_tol,
    )
    if clean_axis_meta.get("clean_axis"):
        print(
            "   clean-axis L/W: "
            f"shadow={clean_axis_meta.get('shadow_side')} "
            f"clean_axis=image_{clean_axis_meta.get('clean_axis')} "
            f"L_samples={clean_axis_meta.get('n_L_samples')} "
            f"W_samples={clean_axis_meta.get('n_W_samples')}"
        )
        for s in clean_axis_meta.get("samples", []) or []:
            try:
                az_s = f"{float(s.get('azimuth_deg')):.1f}"
            except (TypeError, ValueError):
                az_s = "?"
            used = "used" if s.get("used") else f"skip:{s.get('skip_reason') or 'unknown'}"
            print(
                "      "
                f"{s.get('name', '?')} az={az_s} role={s.get('role')} "
                f"dim={s.get('dimension')} axis=image_{s.get('clean_axis')} "
                f"used_px={format_px_optional_2(s.get('clean_px'))} "
                f"filtered_px={format_px_optional_2(s.get('clean_filtered_px'))} "
                f"core_px={format_px_optional_2(s.get('clean_core_px'))} "
                f"all_px={format_px_optional_2(s.get('clean_all_px'))} "
                f"{used}"
            )

    convention_path = out_dir / _CONVENTION_JSON_NAME
    try:
        convention_path.parent.mkdir(parents=True, exist_ok=True)
        convention_path.write_text(
            json.dumps(_to_jsonable(dataset_convention), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception as exc:
        print(f"⚠️ 数据集约定探测 JSON 写入失败（继续汇总）: {exc}")

    robust_selected = list(selected)
    robust_excl: List[Dict[str, Any]] = []
    agg_robust: Dict[str, Any] = {}
    if robust_filter and selected:
        robust_selected, robust_excl = robust_prune_selected(
            selected,
            min_width_px=float(getattr(args, "standalone_shadow_min_width_px", 1.0) or 1.0),
            lw_min=float(getattr(args, "standalone_shadow_lw_min", 0.25) or 0.25),
            lw_max=float(getattr(args, "standalone_shadow_lw_max", 8.0) or 8.0),
            max_matrix_condition=float(getattr(args, "standalone_shadow_max_matrix_condition", 120.0) or 120.0),
            mad_k=mad_k,
            ref_ratios=None,
            max_ratio_rel_dev=float(getattr(args, "standalone_shadow_max_ratio_rel_dev", 0.85) or 0.85),
        )
        rsnap = [r["ratios_3d"] for r in robust_selected if r.get("ratios_3d")]
        agg_robust = median_mean_ratios(rsnap)
    elif selected:
        rsnap = [r["ratios_3d"] for r in selected if r.get("ratios_3d")]
        agg_robust = median_mean_ratios(rsnap)

    summary_selected, summary_agg = _merge_clean_axis_lw_into_summary_inputs(
        robust_selected,
        agg_robust,
        clean_axis_selected,
    )

    write_target_dimension_constraints_summary_txt_for_sfm(
        summary_path,
        agg=summary_agg,
        robust_selected=summary_selected,
        n_images=len(paths),
        n_geom_ok=n_geom_ok,
        n_selected=len(selected),
        n_robust=len(robust_selected),
        pick_mode=pick_mode,
        pick_tol=pick_tol,
        geom_mode=geom_mode,
        robust_filter=robust_filter,
        robust_excl=robust_excl,
        dataset_convention=dataset_convention,
        clean_axis_meta=clean_axis_meta,
    )
    hl = summary_agg.get("H_over_L_median")
    print(f"✅ standalone 阴影汇总已写入: {summary_path}")
    print(
        "   数据集约定探测: "
        f"shadow={dataset_convention.get('shadow_side')} "
        f"axis0={dataset_convention.get('zero_azimuth_axis_mapping')} "
        f"side_LW={dataset_convention.get('side_view_lw_mapping')} "
        f"rot={dataset_convention.get('rotation_direction')} "
        f"sign={dataset_convention.get('gs_optical_ring_azimuth_sign')}"
    )
    if hl is not None and np.isfinite(float(hl)) and float(hl) > 0:
        print(f"   推荐 H/L（鲁棒子集中位数）: {float(hl):.4f}")
    else:
        print("   ⚠️ 未得到有效 H/L：请检查方位/掩码或与 --shadow_geometry_azimuth_mode 是否匹配")
    return str(summary_path.resolve())


if __name__ == "__main__":
    raise SystemExit(main())
