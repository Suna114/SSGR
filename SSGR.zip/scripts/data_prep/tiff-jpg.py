# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

import os
import glob
from PIL import Image
import argparse


def convert_tiff_to_jpg(input_folder, output_folder, quality=95, overwrite=False):
    """
    批量将文件夹内的 TIFF 图像转换为 JPG 格式

    参数:
        input_folder (str): 输入文件夹路径
        output_folder (str): 输出文件夹路径
        quality (int): JPG 质量，1-100（默认95）
        overwrite (bool): 是否覆盖已存在的文件（默认False）
    """
    # 创建输出文件夹（如果不存在）
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"创建输出文件夹: {output_folder}")

    # 查找所有 TIFF 文件（支持 .tiff 和 .tif 扩展名）
    tiff_patterns = [
        os.path.join(input_folder, "*.tiff"),
        os.path.join(input_folder, "*.tif")
    ]

    tiff_files = []
    for pattern in tiff_patterns:
        tiff_files.extend(glob.glob(pattern))

    if not tiff_files:
        print(f"在文件夹 {input_folder} 中未找到 TIFF 文件")
        return

    print(f"找到 {len(tiff_files)} 个 TIFF 文件")

    # 统计变量
    success_count = 0
    skip_count = 0
    error_count = 0

    # 处理每个 TIFF 文件
    for tiff_path in tiff_files:
        # 获取文件名（不含扩展名）
        filename = os.path.splitext(os.path.basename(tiff_path))[0]
        # 构建输出路径
        jpg_path = os.path.join(output_folder, f"{filename}.jpg")

        # 检查文件是否已存在
        if not overwrite and os.path.exists(jpg_path):
            print(f"跳过已存在的文件: {jpg_path}")
            skip_count += 1
            continue

        try:
            # 打开 TIFF 图像
            with Image.open(tiff_path) as img:
                # 转换为 RGB 模式（处理透明通道）
                if img.mode in ('RGBA', 'LA', 'P'):
                    # 创建白色背景
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    # 如果图像有透明度，将其合并到白色背景上
                    if img.mode == 'P':
                        img = img.convert('RGBA')
                    background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
                    img = background
                elif img.mode != 'RGB':
                    img = img.convert('RGB')

                # 保存为 JPG
                img.save(jpg_path, 'JPEG', quality=quality, optimize=True)

                print(f"✓ 转换成功: {os.path.basename(tiff_path)} -> {os.path.basename(jpg_path)}")
                success_count += 1

        except Exception as e:
            print(f"✗ 转换失败 {os.path.basename(tiff_path)}: {str(e)}")
            error_count += 1

    # 输出统计信息
    print("\n" + "=" * 50)
    print(f"转换完成!")
    print(f"成功: {success_count} 个文件")
    print(f"跳过: {skip_count} 个文件")
    print(f"失败: {error_count} 个文件")
    print(f"输出文件夹: {output_folder}")


def main():
    """主函数，处理命令行参数"""
    parser = argparse.ArgumentParser(description='批量 TIFF 转 JPG 转换器')
    parser.add_argument('input_folder', help='输入文件夹路径')
    parser.add_argument('output_folder', help='输出文件夹路径')
    parser.add_argument('-q', '--quality', type=int, default=95,
                        help='JPG 质量 (1-100，默认: 95)')
    parser.add_argument('-o', '--overwrite', action='store_true',
                        help='覆盖已存在的文件')

    args = parser.parse_args()

    # 验证输入文件夹是否存在
    if not os.path.exists(args.input_folder):
        print(f"错误: 输入文件夹 '{args.input_folder}' 不存在")
        return

    # 验证质量参数
    if not 1 <= args.quality <= 100:
        print("错误: 质量参数必须在 1-100 范围内")
        return

    # 执行转换
    convert_tiff_to_jpg(
        input_folder=args.input_folder,
        output_folder=args.output_folder,
        quality=args.quality,
        overwrite=args.overwrite
    )


# 直接使用的函数（无需命令行参数）
def process_folder_simple(input_folder, output_folder, quality=95):
    """
    简化版本的文件夹处理函数

    参数:
        input_folder (str): 输入文件夹路径
        output_folder (str): 输出文件夹路径
        quality (int): JPG 质量，1-100
    """
    convert_tiff_to_jpg(input_folder, output_folder, quality)


if __name__ == "__main__":
    # 使用方法1: 直接调用（取消注释并修改路径）
    process_folder_simple(r"F:\gaosi\1\target_image", r"F:\3dgs\gaussian-splatting\data\21\input2", quality=95)

    # # 使用方法2: 命令行参数
    # main()