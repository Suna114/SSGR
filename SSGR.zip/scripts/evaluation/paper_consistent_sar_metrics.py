#!/usr/bin/env python3
"""Paper-consistent SAR image metrics for rendered-vs-GT novel views.

This evaluator follows the image-quality definitions used by the referenced
SAR-3DGS/SAR-GS papers:

* SAR images are evaluated as a single normalized intensity channel in [0, 1].
* PSNR = 10 * log10(MAX^2 / MSE), with MAX = 1 after normalization.
* SSIM uses the standard luminance/contrast/structure formula with
  C1 = 0.01^2 and C2 = 0.03^2. The local statistics use the same 11x11,
  sigma=1.5 Gaussian window used by the original 3DGS SSIM implementation.

Input folders are usually organized by class:

    render_root/<class>/azimuth_010.png
    gt_root/<class>/<class>-15-010.jpg

Matching is done by class directory name and azimuth angle. For a flat
single-class render directory, pass --class_name:

    render_root/azimuth_010.png
    gt_root/<class>/<class>-15-010.jpg
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from lpipsPyTorch import LPIPS


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


@dataclass(frozen=True)
class Pair:
    cls: str
    azimuth: int
    render_path: Path
    gt_path: Path


def image_files(root: Path) -> list[Path]:
    if not root.is_dir():
        return []
    return sorted(p for p in root.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS)


def azimuth_from_name(path: Path) -> int | None:
    text = path.stem.lower()
    match = re.search(r"azimuth[_-]?(\d{1,3})", text)
    if match:
        return int(match.group(1)) % 360
    nums = re.findall(r"\d+", text)
    if not nums:
        return None
    return int(nums[-1]) % 360


def class_dirs(root: Path) -> dict[str, Path]:
    if not root.is_dir():
        raise FileNotFoundError(f"Directory does not exist: {root}")
    return {p.name: p for p in sorted(root.iterdir()) if p.is_dir()}


def index_gt_by_azimuth(gt_dir: Path) -> dict[int, Path]:
    gt_by_az: dict[int, Path] = {}
    for gt_path in image_files(gt_dir):
        az = azimuth_from_name(gt_path)
        if az is not None:
            gt_by_az.setdefault(az, gt_path)
    return gt_by_az


def build_pairs(render_root: Path, gt_root: Path, class_name: str | None = None) -> tuple[list[Pair], list[dict[str, str]]]:
    flat_render_files = image_files(render_root)
    if flat_render_files:
        cls = class_name or render_root.name
        if class_name and (gt_root / class_name).is_dir():
            gt_dir = gt_root / class_name
        elif image_files(gt_root):
            gt_dir = gt_root
        elif (gt_root / cls).is_dir():
            gt_dir = gt_root / cls
        else:
            raise ValueError(
                "render_root contains images directly, but no matching GT images were found. "
                "Pass --gt_root as the GT image directory or pass --class_name for a class-structured GT root."
            )
        gt_by_az = index_gt_by_azimuth(gt_dir)
        pairs: list[Pair] = []
        skipped: list[dict[str, str]] = []
        for render_path in flat_render_files:
            az = azimuth_from_name(render_path)
            if az is None:
                skipped.append({"class": cls, "render": str(render_path), "reason": "no_render_azimuth"})
                continue
            gt_path = gt_by_az.get(az)
            if gt_path is None:
                skipped.append(
                    {
                        "class": cls,
                        "render": str(render_path),
                        "reason": f"missing_gt_azimuth_{az:03d}",
                    }
                )
                continue
            pairs.append(Pair(cls=cls, azimuth=az, render_path=render_path, gt_path=gt_path))
        return pairs, skipped

    gt_classes = class_dirs(gt_root)
    flat_gt_files = image_files(gt_root)
    render_classes = class_dirs(render_root)
    pairs: list[Pair] = []
    skipped: list[dict[str, str]] = []
    for cls, render_dir in render_classes.items():
        if class_name and cls != class_name:
            continue
        gt_dir = gt_root if flat_gt_files and (class_name or len(render_classes) == 1) else gt_classes.get(cls)
        if gt_dir is None:
            for render_path in image_files(render_dir):
                skipped.append({"class": cls, "render": str(render_path), "reason": "missing_gt_class"})
            continue
        gt_by_az = index_gt_by_azimuth(gt_dir)
        for render_path in image_files(render_dir):
            az = azimuth_from_name(render_path)
            if az is None:
                skipped.append({"class": cls, "render": str(render_path), "reason": "no_render_azimuth"})
                continue
            gt_path = gt_by_az.get(az)
            if gt_path is None:
                skipped.append(
                    {
                        "class": cls,
                        "render": str(render_path),
                        "reason": f"missing_gt_azimuth_{az:03d}",
                    }
                )
                continue
            pairs.append(Pair(cls=cls, azimuth=az, render_path=render_path, gt_path=gt_path))
    return pairs, skipped


def read_gray01(path: Path) -> np.ndarray:
    img = Image.open(path).convert("RGB")
    arr = np.asarray(img, dtype=np.float32) / 255.0
    return arr.mean(axis=2).astype(np.float32)


def to_lpips_tensor(gray01: np.ndarray, device: torch.device) -> torch.Tensor:
    rgb = np.repeat(gray01[..., None], 3, axis=2)
    tensor = torch.from_numpy(rgb).to(device=device, dtype=torch.float32)
    tensor = tensor.permute(2, 0, 1).unsqueeze(0)
    return tensor.mul(2.0).sub(1.0).contiguous()


def resize_like(img: np.ndarray, ref: np.ndarray) -> np.ndarray:
    pil = Image.fromarray(np.clip(img * 255.0 + 0.5, 0, 255).astype(np.uint8), mode="L")
    pil = pil.resize((ref.shape[1], ref.shape[0]), Image.BILINEAR)
    return (np.asarray(pil, dtype=np.float32) / 255.0).astype(np.float32)


def gaussian_window(window_size: int, sigma: float, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    coords = torch.arange(window_size, device=device, dtype=dtype) - window_size // 2
    g = torch.exp(-(coords**2) / (2.0 * sigma * sigma))
    g = g / g.sum()
    window = torch.outer(g, g)
    return window.view(1, 1, window_size, window_size)


def ssim_3dgs_gray(a: np.ndarray, b: np.ndarray, window_size: int = 11, sigma: float = 1.5) -> float:
    if a.shape != b.shape:
        raise ValueError(f"SSIM requires equal shapes, got {a.shape} and {b.shape}")
    x = torch.from_numpy(a).to(dtype=torch.float32).view(1, 1, a.shape[0], a.shape[1])
    y = torch.from_numpy(b).to(dtype=torch.float32).view(1, 1, b.shape[0], b.shape[1])
    window = gaussian_window(window_size, sigma, x.device, x.dtype)
    padding = window_size // 2
    mu_x = F.conv2d(x, window, padding=padding)
    mu_y = F.conv2d(y, window, padding=padding)
    mu_x_sq = mu_x.pow(2)
    mu_y_sq = mu_y.pow(2)
    mu_xy = mu_x * mu_y
    sig_x_sq = F.conv2d(x * x, window, padding=padding) - mu_x_sq
    sig_y_sq = F.conv2d(y * y, window, padding=padding) - mu_y_sq
    sig_xy = F.conv2d(x * y, window, padding=padding) - mu_xy
    c1 = 0.01**2
    c2 = 0.03**2
    ssim_map = ((2.0 * mu_xy + c1) * (2.0 * sig_xy + c2)) / (
        (mu_x_sq + mu_y_sq + c1) * (sig_x_sq + sig_y_sq + c2)
    ).clamp_min(1e-12)
    return float(ssim_map.mean().item())


def compute_metrics(render: np.ndarray, gt: np.ndarray) -> dict[str, float]:
    diff = render - gt
    mse = float(np.mean(diff * diff))
    mae = float(np.mean(np.abs(diff)))
    psnr = 99.0 if mse <= 1e-12 else float(10.0 * math.log10(1.0 / mse))
    ssim = ssim_3dgs_gray(render, gt)
    return {"MSE": mse, "MAE": mae, "PSNR": psnr, "SSIM": ssim}


def summarize(rows: list[dict[str, object]]) -> dict[str, dict[str, float]]:
    metrics = ["MSE", "MAE", "PSNR", "SSIM", "LPIPS"]
    out: dict[str, dict[str, float]] = {}
    for key in metrics:
        values = np.asarray([float(row[key]) for row in rows], dtype=np.float64)
        out[key] = {
            "mean": float(values.mean()) if values.size else math.nan,
            "std": float(values.std(ddof=0)) if values.size else math.nan,
            "min": float(values.min()) if values.size else math.nan,
            "max": float(values.max()) if values.size else math.nan,
        }
    out["count"] = {"value": float(len(rows))}
    return out


def write_summary_csv(path: Path, grouped_rows: dict[str, list[dict[str, object]]]) -> None:
    fieldnames = ["group", "count"]
    for metric in ["MSE", "MAE", "PSNR", "SSIM", "LPIPS"]:
        fieldnames += [f"{metric}_mean", f"{metric}_std", f"{metric}_min", f"{metric}_max"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for group, rows in grouped_rows.items():
            stats = summarize(rows)
            row: dict[str, object] = {"group": group, "count": len(rows)}
            for metric in ["MSE", "MAE", "PSNR", "SSIM", "LPIPS"]:
                for name in ["mean", "std", "min", "max"]:
                    row[f"{metric}_{name}"] = stats[metric][name]
            writer.writerow(row)


def main() -> int:
    parser = argparse.ArgumentParser(description="Evaluate SAR render/GT metrics with paper-consistent PSNR/SSIM.")
    parser.add_argument("--render_root", required=True, type=Path)
    parser.add_argument("--gt_root", required=True, type=Path)
    parser.add_argument("--output_dir", required=True, type=Path)
    parser.add_argument(
        "--class_name",
        default=None,
        help="Class name for a flat single-class render directory, e.g. T72, 2S1, ZIL131.",
    )
    parser.add_argument(
        "--resize",
        choices=["none", "render_to_gt"],
        default="none",
        help="Paper metrics assume matching image grids. Use render_to_gt only when necessary.",
    )
    args = parser.parse_args()

    pairs, skipped = build_pairs(args.render_root, args.gt_root, args.class_name)
    if not pairs:
        raise SystemExit("No render/GT pairs were found.")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    lpips_model = LPIPS("alex").to(device).eval()
    for pair in pairs:
        render = read_gray01(pair.render_path)
        gt = read_gray01(pair.gt_path)
        if render.shape != gt.shape:
            if args.resize == "render_to_gt":
                render = resize_like(render, gt)
            else:
                raise SystemExit(
                    "Image shapes differ. Re-run with --resize render_to_gt if this is intended: "
                    f"{pair.render_path} {render.shape} vs {pair.gt_path} {gt.shape}"
                )
        metrics = compute_metrics(render, gt)
        with torch.no_grad():
            lp = float(lpips_model(to_lpips_tensor(render, device), to_lpips_tensor(gt, device)).item())
        rows.append(
            {
                "class": pair.cls,
                "azimuth": pair.azimuth,
                "render_path": str(pair.render_path),
                "gt_path": str(pair.gt_path),
                "height": int(gt.shape[0]),
                "width": int(gt.shape[1]),
                "LPIPS": lp,
                **metrics,
            }
        )

    per_image_csv = args.output_dir / "paper_metrics_per_image.csv"
    with per_image_csv.open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["class", "azimuth", "render_path", "gt_path", "height", "width", "MSE", "MAE", "PSNR", "SSIM", "LPIPS"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    per_image_json = args.output_dir / "paper_metrics_per_image.json"
    with per_image_json.open("w", encoding="utf-8") as f:
        json.dump({"rows": rows}, f, indent=2, ensure_ascii=False)

    grouped: dict[str, list[dict[str, object]]] = {"ALL": rows}
    for row in rows:
        grouped.setdefault(str(row["class"]), []).append(row)

    summary_json = args.output_dir / "paper_metrics_summary.json"
    payload = {
        "render_root": str(args.render_root),
        "gt_root": str(args.gt_root),
        "pair_count": len(rows),
        "skipped_count": len(skipped),
        "metric_definition": {
            "domain": "single-channel SAR intensity normalized to [0, 1]",
            "PSNR": "10*log10(1/MSE)",
            "SSIM": "3DGS-style standard SSIM, 11x11 Gaussian window sigma=1.5, C1=0.01^2, C2=0.03^2",
            "LPIPS": "AlexNet-based LPIPS on grayscale replicated to 3 channels and mapped to [-1, 1]",
        },
        "summary": {group: summarize(group_rows) for group, group_rows in grouped.items()},
        "skipped": skipped,
    }
    with summary_json.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)

    summary_csv = args.output_dir / "paper_metrics_summary.csv"
    write_summary_csv(summary_csv, grouped)

    all_stats = payload["summary"]["ALL"]
    print(f"[paper metrics] pairs: {len(rows)} skipped: {len(skipped)}")
    print(f"[paper metrics] SSIM mean={all_stats['SSIM']['mean']:.6f} std={all_stats['SSIM']['std']:.6f}")
    print(f"[paper metrics] PSNR mean={all_stats['PSNR']['mean']:.4f} dB")
    print(f"[paper metrics] LPIPS mean={all_stats['LPIPS']['mean']:.6f}")
    print(f"[paper metrics] per-image: {per_image_csv}")
    print(f"[paper metrics] per-image: {per_image_json}")
    print(f"[paper metrics] summary  : {summary_json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
