#!/usr/bin/env python3
"""Compare render/GT pairs after shared background filtering.

This script mirrors each image pair through ``utils/filter_background.py``-style
background suppression and then computes full-image PSNR/SSIM on the filtered
results. It can also archive the filtered images into:

  <output_dir>/picture/<dataset>/
  <output_dir>/label/<dataset>/

The dataset name is inferred from the rendered image path parent when possible.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import numpy as np
from PIL import Image
import torch
import torchvision.transforms.functional as tf

from utils.loss_utils import ssim
from utils.image_utils import psnr
from utils.filter_background import build_target_mask, load_rgb_float, rgb_to_gray_float


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def image_files(path: Path) -> list[Path]:
    if not path.is_dir():
        raise FileNotFoundError(f"directory not found: {path}")
    return sorted((p for p in path.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS), key=lambda p: p.name.lower())


def extract_render_azimuth(stem: str) -> int | None:
    match = re.search(r"(?i)azimuth[_-](\d+)", stem)
    if match:
        return int(match.group(1)) % 360
    return extract_gt_azimuth(stem)


def extract_gt_azimuth(stem: str) -> int | None:
    for part in reversed(stem.split("-")):
        match = re.match(r"^(\d+)", part.strip())
        if match:
            return int(match.group(1)) % 360
    return None


def angular_distance(a: int, b: int) -> int:
    delta = abs((int(a) % 360) - (int(b) % 360))
    return min(delta, 360 - delta)


def gt_index(gt_dir: Path) -> dict[int, Path]:
    out: dict[int, Path] = {}
    buckets: dict[int, list[Path]] = {}
    for path in image_files(gt_dir):
        az = extract_gt_azimuth(path.stem)
        if az is not None:
            buckets.setdefault(az, []).append(path)
    for az, paths in buckets.items():
        out[az] = sorted(paths, key=lambda p: p.name.lower())[0]
    return out


def find_gt(index: dict[int, Path], azimuth: int | None, tolerance: int) -> tuple[Path | None, int | None]:
    if azimuth is None or not index:
        return None, None
    if azimuth in index:
        return index[azimuth], azimuth
    if tolerance <= 0:
        return None, None
    best = min(index.keys(), key=lambda candidate: angular_distance(azimuth, candidate))
    if angular_distance(azimuth, best) <= tolerance:
        return index[best], best
    return None, None


def filter_to_black(src: Path, dst: Path, args: argparse.Namespace) -> None:
    rgb, _mode = load_rgb_float(src)
    gray = rgb_to_gray_float(rgb)
    mask = build_target_mask(
        gray,
        percentile=float(args.percentile),
        min_target_ratio=float(args.min_target_ratio),
        method="percentile",
        blur_sigma=float(args.blur_sigma),
        open_iter=int(args.open_iter),
        close_iter=int(args.close_iter),
        morph_kernel=int(args.morph_kernel),
        largest_cc=bool(args.largest_cc),
        min_cc_area=int(args.min_cc_area),
        erode_px=int(args.erode_px),
    )
    masked = (np.clip(rgb, 0.0, 1.0) * mask[:, :, None] * 255.0).round().astype(np.uint8)
    dst.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(masked, mode="RGB").save(dst)


def load_tensor(path: Path, device: str) -> torch.Tensor:
    img = Image.open(path).convert("RGB")
    tensor = tf.to_tensor(img).unsqueeze(0)
    if device == "cuda" and torch.cuda.is_available():
        return tensor.cuda()
    return tensor.cpu()


def compare_pair(render_filtered: Path, gt_filtered: Path, device: str) -> dict:
    render = load_tensor(render_filtered, device)
    gt = load_tensor(gt_filtered, device)
    if render.shape[-2:] != gt.shape[-2:]:
        render = tf.resize(render, size=(gt.shape[2], gt.shape[3]))
    mse = float(((render - gt) ** 2).mean().item())
    mae = float(torch.abs(render - gt).mean().item())
    psnr_value = float(psnr(render, gt).item())
    ssim_value = float(ssim(render, gt).item())
    return {
        "MSE": mse,
        "MAE": mae,
        "PSNR": psnr_value,
        "SSIM": ssim_value,
    }


def summarize(rows: list[dict]) -> dict:
    out: dict[str, dict[str, float]] = {}
    for key in ("MSE", "MAE", "PSNR", "SSIM"):
        vals = [float(row[key]) for row in rows if row.get(key) is not None and math.isfinite(float(row[key]))]
        if not vals:
            continue
        arr = np.asarray(vals, dtype=np.float64)
        out[key] = {
            "mean": float(arr.mean()),
            "std": float(arr.std()),
            "min": float(arr.min()),
            "max": float(arr.max()),
            "count": int(arr.size),
        }
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--render_dir", type=Path, required=True)
    parser.add_argument("--gt_dir", type=Path, required=True)
    parser.add_argument("--output_dir", type=Path, required=True)
    parser.add_argument("--dataset", type=str, required=True)
    parser.add_argument("--picture_root", type=Path, default=None)
    parser.add_argument("--label_root", type=Path, default=None)
    parser.add_argument("--azimuth_match_tolerance", type=int, default=0)
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--percentile", type=float, default=90.0)
    parser.add_argument("--min_target_ratio", type=float, default=0.002)
    parser.add_argument("--blur_sigma", type=float, default=1.0)
    parser.add_argument("--open_iter", type=int, default=1)
    parser.add_argument("--close_iter", type=int, default=2)
    parser.add_argument("--morph_kernel", type=int, default=5)
    parser.add_argument("--largest_cc", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--min_cc_area", type=int, default=0)
    parser.add_argument("--erode_px", type=int, default=0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    render_dir = args.render_dir.resolve()
    gt_dir = args.gt_dir.resolve()
    output_dir = args.output_dir.resolve()
    dataset = str(args.dataset)
    filtered_render_dir = output_dir / "filtered_render"
    filtered_gt_dir = output_dir / "filtered_gt"
    picture_dir = (args.picture_root.resolve() if args.picture_root else output_dir / "picture") / dataset
    label_dir = (args.label_root.resolve() if args.label_root else output_dir / "label") / dataset
    output_dir.mkdir(parents=True, exist_ok=True)

    index = gt_index(gt_dir)
    rows: list[dict] = []
    skipped: list[dict] = []
    for render_path in image_files(render_dir):
        azimuth = extract_render_azimuth(render_path.stem)
        gt_path, matched_azimuth = find_gt(index, azimuth, int(args.azimuth_match_tolerance))
        if gt_path is None:
            skipped.append({"image": render_path.name, "reason": "missing GT azimuth match"})
            continue

        render_filtered = filtered_render_dir / render_path.with_suffix(".png").name
        gt_filtered = filtered_gt_dir / gt_path.with_suffix(".png").name
        filter_to_black(render_path, render_filtered, args)
        filter_to_black(gt_path, gt_filtered, args)
        metrics = compare_pair(render_filtered, gt_filtered, args.device)

        picture_path = picture_dir / render_filtered.name
        label_path = label_dir / gt_filtered.name
        picture_path.parent.mkdir(parents=True, exist_ok=True)
        label_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(render_filtered, picture_path)
        shutil.copy2(gt_filtered, label_path)

        rows.append({
            "image_name": render_path.name,
            "azimuth": azimuth,
            "matched_gt_azimuth": matched_azimuth,
            "render_path": str(render_path),
            "gt_path": str(gt_path),
            "filtered_render_path": str(render_filtered),
            "filtered_gt_path": str(gt_filtered),
            "picture_path": str(picture_path),
            "label_path": str(label_path),
            **metrics,
        })

    payload = {
        "dataset": dataset,
        "render_dir": str(render_dir),
        "gt_dir": str(gt_dir),
        "output_dir": str(output_dir),
        "picture_dir": str(picture_dir),
        "label_dir": str(label_dir),
        "count": len(rows),
        "skipped": skipped,
        "summary": summarize(rows),
        "per_image": rows,
    }
    (output_dir / "background_filtered_metrics.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"[background filtered eval] compared {len(rows)} images; output: {output_dir}")
    if skipped:
        print(f"[background filtered eval] skipped {len(skipped)} images")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
