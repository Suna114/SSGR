# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
风格迁移结果量化：相对内容图/风格图的 LPIPS、SSIM、PSNR，
并补充强散射点分布、RCS 与目标-背景对比度等指标，汇总写入 txt。
依赖: pip install piq

星载 SAR 与风格迁移后的机载 SAR 做 SSIM 时，斑点相干斑易拉高局部差异；
可用 ``--sar-lee-window`` + ``--sar-lee-mode content_and_output`` 在评估前做 Lee 滤波
（见 ``sar/sar_speckle_reduce.py``）。建议对称滤波内容与输出，避免只滤波一侧造成 SSIM 偏差。
Lee 需要 scipy（推荐）或 OpenCV（cv2）。
"""

from __future__ import annotations

import argparse
import unicodedata
from pathlib import Path
from statistics import mean, pstdev
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torchvision.transforms.functional import to_tensor

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff"}


def _resolve_metrics_device(device: str) -> torch.device:
    req = torch.device(device)
    if req.type == "cuda" and not torch.cuda.is_available():
        return torch.device("cpu")
    if req.type == "cuda" and req.index is not None and req.index >= torch.cuda.device_count():
        return torch.device("cuda:0")
    return req


def is_image_file(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() in SUPPORTED_EXTS


def norm_stem(s: str) -> str:
    """与迁移时 Path.stem 在磁盘上可能因大小写/Unicode 形式不同，对齐后再比较。"""
    return unicodedata.normalize("NFC", s).casefold()


def find_matching_style_path(content_file: Path, sty_root: Path) -> Optional[Path]:
    if sty_root.is_file():
        return sty_root if is_image_file(sty_root) else None
    direct = sty_root / content_file.name
    if direct.is_file():
        return direct
    stem = norm_stem(content_file.stem)
    candidates = [p for p in sty_root.rglob("*") if is_image_file(p) and norm_stem(p.stem) == stem]
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    same_ext = [p for p in candidates if p.suffix.lower() == content_file.suffix.lower()]
    if len(same_ext) == 1:
        return same_ext[0]
    return sorted(candidates)[0]


def parse_output_stems(filename_stem: str) -> Optional[Tuple[str, str]]:
    """解析输出文件名 `{content_stem}_styliedby_{style_stem}`。"""
    if "_styliedby_" not in filename_stem:
        return None
    left, right = filename_stem.split("_styliedby_", 1)
    if not left or not right:
        return None
    return left, right


def find_content_image(cnt_root: Path, rel_under_cnt: Path, content_stem: str) -> Optional[Path]:
    """在 cnt 下按 stem 找内容图：先精确路径，再在整棵树按规范化 stem 匹配，优先 rel 子目录。"""
    key = norm_stem(content_stem)
    if cnt_root.is_file():
        return cnt_root if norm_stem(cnt_root.stem) == key else None

    folder = cnt_root / rel_under_cnt
    if folder.is_dir():
        for ext in SUPPORTED_EXTS:
            p = folder / f"{content_stem}{ext}"
            if p.is_file():
                return p

    matches = [p for p in cnt_root.rglob("*") if is_image_file(p) and norm_stem(p.stem) == key]
    if not matches:
        return None
    if folder.is_dir():
        under = []
        for p in matches:
            try:
                p.relative_to(folder)
                under.append(p)
            except ValueError:
                continue
        if under:
            return sorted(under)[0]
    return sorted(matches)[0]


def find_style_image(sty_root: Path, style_stem: str) -> Optional[Path]:
    key = norm_stem(style_stem)
    if sty_root.is_file():
        return sty_root if norm_stem(sty_root.stem) == key else None
    candidates = [p for p in sty_root.rglob("*") if is_image_file(p) and norm_stem(p.stem) == key]
    if not candidates:
        return None
    return sorted(candidates)[0]


def load_rgb_tensor(
    path: Path,
    size: int,
    *,
    sar_lee_window: int = 0,
    sar_lee_looks: float = 4.0,
) -> torch.Tensor:
    """
    读取 RGB 图并Resize；可选对 SAR 显示图做 Lee 相干斑抑制后再送入张量。
    ``sar_lee_window>=3`` 且为奇数时启用（与 ``sar/sar_speckle_reduce.py`` 一致）。
    """
    img = Image.open(path).convert("RGB")
    if img.size != (size, size):
        img = img.resize((size, size), Image.BICUBIC)
    arr = np.asarray(img)
    if sar_lee_window >= 3:
        from sar.sar_speckle_reduce import lee_filter_image_u8

        arr = lee_filter_image_u8(arr, window=int(sar_lee_window), looks=float(sar_lee_looks))
    return to_tensor(arr).unsqueeze(0)


def _to_gray01(t: torch.Tensor) -> torch.Tensor:
    """RGB 张量转灰度 [0,1]，输入形状 (1,3,H,W)。"""
    return (0.299 * t[:, 0:1] + 0.587 * t[:, 1:2] + 0.114 * t[:, 2:3]).clamp(0.0, 1.0)


def _estimate_target_mask(gray: torch.Tensor, target_percentile: float = 90.0) -> torch.Tensor:
    """
    依据亮度分位数估计目标区域（强散射主体）:
    gray: (1,1,H,W), 返回 bool mask 同形状。
    """
    p = float(min(max(target_percentile, 50.0), 99.9))
    thr = torch.quantile(gray.flatten(), p / 100.0)
    mask = gray >= thr
    if mask.sum() == 0:
        # 极端情况下至少保留最亮点
        idx = torch.argmax(gray.flatten())
        mask = torch.zeros_like(gray, dtype=torch.bool)
        mask.view(-1)[idx] = True
    return mask


def _strong_scatter_distribution(
    gray: torch.Tensor,
    topk_ratio: float = 0.01,
    grid_size: int = 8,
) -> torch.Tensor:
    """
    计算强散射点空间分布（概率直方图）。
    - 取灰度最亮 top-k 像素为强散射点；
    - 按 grid_size x grid_size 网格统计并归一化。
    """
    _, _, h, w = gray.shape
    flat = gray.flatten()
    n = flat.numel()
    k = int(max(1, round(n * float(min(max(topk_ratio, 1e-4), 0.2)))))
    topk_idx = torch.topk(flat, k=k, largest=True).indices

    ys = topk_idx // w
    xs = topk_idx % w

    gy = torch.clamp((ys * grid_size) // h, 0, grid_size - 1)
    gx = torch.clamp((xs * grid_size) // w, 0, grid_size - 1)
    bins = gy * grid_size + gx

    hist = torch.bincount(bins, minlength=grid_size * grid_size).float()
    hist = hist / hist.sum().clamp_min(1e-10)
    return hist


def _js_divergence(p: torch.Tensor, q: torch.Tensor, eps: float = 1e-10) -> torch.Tensor:
    """Jensen-Shannon divergence, 数值越小分布越相似。"""
    p = p.clamp_min(eps)
    q = q.clamp_min(eps)
    m = 0.5 * (p + q)
    kl_pm = torch.sum(p * torch.log(p / m))
    kl_qm = torch.sum(q * torch.log(q / m))
    return 0.5 * (kl_pm + kl_qm)


def _cosine_sim(p: torch.Tensor, q: torch.Tensor) -> torch.Tensor:
    """余弦相似度，越大越相似。"""
    num = torch.sum(p * q)
    den = torch.sqrt(torch.sum(p * p) * torch.sum(q * q)).clamp_min(1e-10)
    return num / den


def _rcs_proxy(gray: torch.Tensor, target_mask: torch.Tensor) -> torch.Tensor:
    """
    目标 RCS 代理量（相对值）：
    以灰度平方近似散射功率，取目标区域平均功率。
    """
    power = gray * gray
    target_power = power[target_mask]
    return target_power.mean()


def _contrast_target_background(gray: torch.Tensor, target_mask: torch.Tensor) -> torch.Tensor:
    """
    目标-背景对比度（Weber 形式）:
    C = (mu_t - mu_b) / (mu_b + eps)
    """
    eps = 1e-10
    mu_t = gray[target_mask].mean()
    bg_mask = ~target_mask
    if bg_mask.sum() == 0:
        mu_b = torch.tensor(0.0, device=gray.device, dtype=gray.dtype)
    else:
        mu_b = gray[bg_mask].mean()
    return (mu_t - mu_b) / (mu_b + eps)


def _resolve_paths_for_output(
    out_path: Path,
    out_root: Path,
    cnt_root: Path,
    sty_root: Path,
) -> Tuple[Optional[Path], Optional[Path]]:
    """根据输出图路径解析对应内容图、风格图路径。"""
    rel = out_path.parent.relative_to(out_root) if out_root.is_dir() else Path(".")
    stems = parse_output_stems(out_path.stem)
    if stems is None:
        return None, None
    content_stem, style_stem = stems
    content_path = find_content_image(cnt_root, rel, content_stem)
    style_path = find_style_image(sty_root, style_stem)
    if style_path is None and content_path is not None:
        style_path = find_matching_style_path(content_path, sty_root)
    return content_path, style_path


def _normalize_metrics_path(metrics_path: Path, output_dir: Path) -> Path:
    """
    兼容用户把 --metrics-out 传成目录的情况：
    - 若是目录，自动追加默认文件名 metrics_eval.txt
    - 若无后缀，也按目录处理并追加默认文件名
    """
    if metrics_path.exists() and metrics_path.is_dir():
        return metrics_path / "metrics_eval.txt"
    if metrics_path.suffix == "":
        return metrics_path / "metrics_eval.txt"
    return metrics_path


def compute_metrics_for_triplet(
    out_t: torch.Tensor,
    cnt_t: torch.Tensor,
    sty_t: torch.Tensor,
    lpips_fn: Any,
    device: torch.device,
) -> Dict[str, float]:
    out_t = out_t.to(device)
    cnt_t = cnt_t.to(device)
    sty_t = sty_t.to(device)

    from piq import ssim as ssim_metric

    lpips_oc = lpips_fn(out_t, cnt_t).detach()
    lpips_os = lpips_fn(out_t, sty_t).detach()
    if lpips_oc.dim() > 0:
        lpips_oc = lpips_oc.mean()
    if lpips_os.dim() > 0:
        lpips_os = lpips_os.mean()

    ssim_oc = ssim_metric(out_t, cnt_t, data_range=1.0, reduction="mean").detach()
    if ssim_oc.dim() > 0:
        ssim_oc = ssim_oc.mean()

    mse = F.mse_loss(out_t, cnt_t)
    psnr_oc = (10 * torch.log10(1.0 / (mse.clamp_min(1e-10)))).detach()

    # ---- 新增指标：强散射点分布 / RCS / 对比度 ----
    out_g = _to_gray01(out_t)
    cnt_g = _to_gray01(cnt_t)
    sty_g = _to_gray01(sty_t)

    out_mask = _estimate_target_mask(out_g, target_percentile=90.0)
    cnt_mask = _estimate_target_mask(cnt_g, target_percentile=90.0)
    sty_mask = _estimate_target_mask(sty_g, target_percentile=90.0)

    out_dist = _strong_scatter_distribution(out_g, topk_ratio=0.01, grid_size=8)
    cnt_dist = _strong_scatter_distribution(cnt_g, topk_ratio=0.01, grid_size=8)
    sty_dist = _strong_scatter_distribution(sty_g, topk_ratio=0.01, grid_size=8)

    ss_jsd_oc = _js_divergence(out_dist, cnt_dist)
    ss_jsd_os = _js_divergence(out_dist, sty_dist)
    ss_cos_oc = _cosine_sim(out_dist, cnt_dist)
    ss_cos_os = _cosine_sim(out_dist, sty_dist)

    rcs_out = _rcs_proxy(out_g, out_mask)
    rcs_cnt = _rcs_proxy(cnt_g, cnt_mask)
    rcs_sty = _rcs_proxy(sty_g, sty_mask)
    rcs_out_db = 10.0 * torch.log10(rcs_out.clamp_min(1e-10))
    rcs_cnt_db = 10.0 * torch.log10(rcs_cnt.clamp_min(1e-10))
    rcs_sty_db = 10.0 * torch.log10(rcs_sty.clamp_min(1e-10))

    contrast_out = _contrast_target_background(out_g, out_mask)
    contrast_cnt = _contrast_target_background(cnt_g, cnt_mask)
    contrast_sty = _contrast_target_background(sty_g, sty_mask)
    contrast_change_vs_content = (contrast_out - contrast_cnt) / contrast_cnt.abs().clamp_min(1e-10)
    contrast_change_vs_style = (contrast_out - contrast_sty) / contrast_sty.abs().clamp_min(1e-10)

    return {
        "lpips_vs_content": float(lpips_oc.item()),
        "lpips_vs_style": float(lpips_os.item()),
        "ssim_vs_content": float(ssim_oc.item()),
        "psnr_vs_content_db": float(psnr_oc.item()),
        "strong_scatter_jsd_vs_content": float(ss_jsd_oc.item()),
        "strong_scatter_jsd_vs_style": float(ss_jsd_os.item()),
        "strong_scatter_cos_vs_content": float(ss_cos_oc.item()),
        "strong_scatter_cos_vs_style": float(ss_cos_os.item()),
        "rcs_out_db": float(rcs_out_db.item()),
        "rcs_content_db": float(rcs_cnt_db.item()),
        "rcs_style_db": float(rcs_sty_db.item()),
        "rcs_delta_vs_content_db": float((rcs_out_db - rcs_cnt_db).item()),
        "rcs_delta_vs_style_db": float((rcs_out_db - rcs_sty_db).item()),
        "contrast_out": float(contrast_out.item()),
        "contrast_content": float(contrast_cnt.item()),
        "contrast_style": float(contrast_sty.item()),
        "contrast_change_rate_vs_content": float(contrast_change_vs_content.item()),
        "contrast_change_rate_vs_style": float(contrast_change_vs_style.item()),
    }


def run_evaluation_and_save(
    cnt_root: Path,
    sty_root: Path,
    output_dir: Path,
    metrics_path: Path,
    eval_size: int = 512,
    device: str = "cuda:0",
    sar_lee_window: int = 0,
    sar_lee_looks: float = 4.0,
    sar_lee_mode: str = "content_and_output",
) -> List[Dict[str, Any]]:
    try:
        from piq import LPIPS
    except ImportError as exc:
        raise ImportError("请先安装: pip install piq") from exc

    cnt_root = cnt_root.expanduser().resolve()
    sty_root = sty_root.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    metrics_path = metrics_path.expanduser().resolve()
    metrics_path = _normalize_metrics_path(metrics_path, output_dir)

    dev = _resolve_metrics_device(device)
    lpips_fn = LPIPS(reduction="mean").to(dev)
    lpips_fn.eval()

    mode_eff = (sar_lee_mode or "off").strip().lower()
    if sar_lee_window >= 3 and sar_lee_window % 2 == 0:
        raise ValueError("sar_lee_window 必须为奇数（例如 5、7、9）")
    if sar_lee_window < 3:
        mode_eff = "off"

    def _lee_win(role: str) -> int:
        if mode_eff == "off":
            return 0
        if mode_eff == "content_only":
            return sar_lee_window if role == "content" else 0
        if mode_eff == "content_and_output":
            return sar_lee_window if role in ("content", "output") else 0
        if mode_eff == "all":
            return sar_lee_window
        raise ValueError(f"未知 sar_lee_mode: {sar_lee_mode}")

    rows: List[Dict[str, Any]] = []
    out_files = sorted(
        p for p in output_dir.rglob("*") if p.is_file() and p.suffix.lower() == ".png" and "_styliedby_" in p.stem
    )

    for out_path in out_files:
        content_path, style_path = _resolve_paths_for_output(out_path, output_dir, cnt_root, sty_root)
        if content_path is None or style_path is None:
            rows.append(
                {
                    "output": str(out_path),
                    "error": f"未找到内容或风格图 (cnt={content_path}, sty={style_path})",
                }
            )
            continue
        try:
            lw_o = _lee_win("output")
            lw_c = _lee_win("content")
            lw_s = _lee_win("style")
            out_t = load_rgb_tensor(
                out_path, eval_size, sar_lee_window=lw_o, sar_lee_looks=sar_lee_looks
            )
            cnt_t = load_rgb_tensor(
                content_path, eval_size, sar_lee_window=lw_c, sar_lee_looks=sar_lee_looks
            )
            sty_t = load_rgb_tensor(
                style_path, eval_size, sar_lee_window=lw_s, sar_lee_looks=sar_lee_looks
            )
            m = compute_metrics_for_triplet(out_t, cnt_t, sty_t, lpips_fn, dev)
            rows.append(
                {
                    "output": str(out_path),
                    "content": str(content_path),
                    "style": str(style_path),
                    **m,
                }
            )
        except Exception as e:
            rows.append({"output": str(out_path), "error": str(e)})

    ok_rows = [r for r in rows if "error" not in r]
    metrics_path.parent.mkdir(parents=True, exist_ok=True)
    with open(metrics_path, "w", encoding="utf-8") as f:
        f.write("风格迁移量化指标\n")
        f.write(f"评估分辨率: {eval_size}x{eval_size}\n")
        if sar_lee_window >= 3:
            f.write(
                f"SAR Lee 预处理: window={sar_lee_window}, looks={sar_lee_looks}, mode={mode_eff}\n"
            )
        else:
            f.write("SAR Lee 预处理: 关闭\n")
        f.write(f"内容目录: {cnt_root}\n")
        f.write(f"风格目录: {sty_root}\n")
        f.write(f"输出目录: {output_dir}\n")
        f.write("\n说明:\n")
        f.write("  LPIPS_vs_content / LPIPS_vs_style: 越小表示与参考图在感知上越接近\n")
        f.write("  SSIM_vs_content: 越大(最大1)表示与内容图结构越相似\n")
        f.write("  PSNR_vs_content: 越大表示与内容图像素越接近(dB)\n")
        f.write("  StrongScatter_*: 强散射点空间分布相似性（JSD 越小越好, COS 越大越好）\n")
        f.write("  RCS_*_db: 目标区域散射强度代理值（dB）\n")
        f.write("  Contrast_*: 目标-背景 Weber 对比度\n")
        f.write("  Contrast_change_rate_*: 对比度相对变化率\n")
        f.write("\n")

        for r in rows:
            if "error" in r:
                f.write(f"[跳过] {r['output']}\n  原因: {r['error']}\n")
            else:
                f.write(f"输出: {r['output']}\n")
                f.write(f"  LPIPS_vs_content: {r['lpips_vs_content']:.6f}\n")
                f.write(f"  LPIPS_vs_style:   {r['lpips_vs_style']:.6f}\n")
                f.write(f"  SSIM_vs_content:  {r['ssim_vs_content']:.6f}\n")
                f.write(f"  PSNR_vs_content:  {r['psnr_vs_content_db']:.4f} dB\n")
                f.write(f"  StrongScatter_JSD_vs_content: {r['strong_scatter_jsd_vs_content']:.6f}\n")
                f.write(f"  StrongScatter_JSD_vs_style:   {r['strong_scatter_jsd_vs_style']:.6f}\n")
                f.write(f"  StrongScatter_COS_vs_content: {r['strong_scatter_cos_vs_content']:.6f}\n")
                f.write(f"  StrongScatter_COS_vs_style:   {r['strong_scatter_cos_vs_style']:.6f}\n")
                f.write(f"  RCS_out:            {r['rcs_out_db']:.4f} dB\n")
                f.write(f"  RCS_content:        {r['rcs_content_db']:.4f} dB\n")
                f.write(f"  RCS_style:          {r['rcs_style_db']:.4f} dB\n")
                f.write(f"  RCS_delta_content:  {r['rcs_delta_vs_content_db']:.4f} dB\n")
                f.write(f"  RCS_delta_style:    {r['rcs_delta_vs_style_db']:.4f} dB\n")
                f.write(f"  Contrast_out:       {r['contrast_out']:.6f}\n")
                f.write(f"  Contrast_content:   {r['contrast_content']:.6f}\n")
                f.write(f"  Contrast_style:     {r['contrast_style']:.6f}\n")
                f.write(f"  Contrast_rate_vs_content: {r['contrast_change_rate_vs_content']:.6f}\n")
                f.write(f"  Contrast_rate_vs_style:   {r['contrast_change_rate_vs_style']:.6f}\n")

        f.write("\n--- 汇总(有效样本) ---\n")
        if ok_rows:
            keys = [
                "lpips_vs_content",
                "lpips_vs_style",
                "ssim_vs_content",
                "psnr_vs_content_db",
                "strong_scatter_jsd_vs_content",
                "strong_scatter_jsd_vs_style",
                "strong_scatter_cos_vs_content",
                "strong_scatter_cos_vs_style",
                "rcs_out_db",
                "rcs_content_db",
                "rcs_style_db",
                "rcs_delta_vs_content_db",
                "rcs_delta_vs_style_db",
                "contrast_out",
                "contrast_content",
                "contrast_style",
                "contrast_change_rate_vs_content",
                "contrast_change_rate_vs_style",
            ]
            f.write(f"样本数: {len(ok_rows)}\n")
            for k in keys:
                vals = [r[k] for r in ok_rows]
                f.write(f"  {k}: 均值={mean(vals):.6f}, 标准差={pstdev(vals) if len(vals) > 1 else 0.0:.6f}\n")
        else:
            f.write("无有效样本。\n")

    print(f"指标已写入: {metrics_path}")
    return rows


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="对已生成的风格迁移结果做量化并写入 txt")
    p.add_argument("--cnt", required=True, help="与迁移时相同的内容图根路径")
    p.add_argument("--sty", required=True, help="与迁移时相同的风格图路径")
    p.add_argument("--out", required=True, help="迁移输出目录（含 *_styliedby_*.png）")
    p.add_argument("--metrics-out", required=True, help="指标输出 txt 路径（也可传目录，默认生成 metrics_eval.txt）")
    p.add_argument("--eval-size", type=int, default=512, help="评估时统一缩放边长")
    p.add_argument("--device", default="cuda:0", help="LPIPS 计算设备")
    p.add_argument(
        "--sar-lee-window",
        type=int,
        default=0,
        help="Lee 相干斑抑制窗口边长（奇数，>=3 启用；0 关闭）。减轻星载 SAR 斑点对 SSIM 的干扰",
    )
    p.add_argument(
        "--sar-lee-looks",
        type=float,
        default=4.0,
        help="Lee 等效视数 ENL（越大越保留细节、抑斑越弱）",
    )
    p.add_argument(
        "--sar-lee-mode",
        choices=["off", "content_only", "content_and_output", "all"],
        default="content_and_output",
        help="content_only: 仅滤波内容图(星载)；content_and_output: 内容与迁移输出均滤波(推荐)；all: 含机载风格参考图",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    run_evaluation_and_save(
        cnt_root=Path(args.cnt),
        sty_root=Path(args.sty),
        output_dir=Path(args.out),
        metrics_path=Path(args.metrics_out),
        eval_size=args.eval_size,
        device=args.device,
        sar_lee_window=args.sar_lee_window,
        sar_lee_looks=args.sar_lee_looks,
        sar_lee_mode=args.sar_lee_mode,
    )


if __name__ == "__main__":
    main()
