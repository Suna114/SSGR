"""Batch compare MSTAR final renders against per-class GT folders.

This is a thin wrapper around scripts/evaluation/compare_render_gt.py.
It expects render images at:
  <render_root>/<class>/refiner/03.apply_postprocess/apply/final_renders
and GT images at:
  <gt_root>/<class>
"""

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path


DEFAULT_GT_ROOT = Path(r"F:\3dgs\新建文件夹\15")
DEFAULT_RENDER_ROOT = Path(r"F:\3dgs\SSGR\output\final")
DEFAULT_RENDER_REL = Path(r"refiner\03.apply_postprocess\apply\final_renders")
DEFAULT_OUTPUT_ROOT = Path(r"F:\3dgs\SSGR\output\final\_compare_render_gt_15")
SKIP_NAMES = {"label", "label_azimuth", "mask_label", "picture", "picture2", "figure"}
FALLBACK_RENDER_RELS = [
    Path(r"refiner\03.apply_postprocess\apply\renders"),
    Path(r"refiner\03.apply_postprocess\apply_background_then_shadow\renders"),
    Path(r"refiner\03.apply_postprocess\azimuth_shadow_refiner\apply_after_background\renders"),
    Path(r"refiner\03.apply_postprocess\azimuth_shadow_refiner\apply\renders"),
]


def find_repo_root() -> Path:
    for parent in Path(__file__).resolve().parents:
        if (parent / "train.py").is_file():
            return parent
    raise RuntimeError("Could not locate repo root from script path")


def image_count(path: Path) -> int:
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
    if not path.is_dir():
        return 0
    return sum(1 for p in path.iterdir() if p.is_file() and p.suffix.lower() in exts)


def resolve_render_dir(class_root: Path, render_rel: Path, auto_find: bool = True) -> tuple[Path, list[Path]]:
    preferred = class_root / render_rel
    if preferred.is_dir():
        return preferred, []
    if not auto_find or not class_root.is_dir():
        return preferred, []

    candidates = [p for p in class_root.rglob("final_renders") if p.is_dir()]
    candidates += [class_root / rel for rel in FALLBACK_RENDER_RELS if (class_root / rel).is_dir()]
    if not candidates:
        return preferred, []

    def sort_key(path: Path):
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0
        return (mtime, str(path))

    candidates = sorted(candidates, key=sort_key, reverse=True)
    return candidates[0], candidates[1:]


def load_summary(result_path: Path) -> dict:
    if not result_path.is_file():
        return {}
    with result_path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    summary = data.get("summary", {})
    out = {}
    for key, stats in summary.items():
        if isinstance(stats, dict) and "mean" in stats:
            out[f"{key}_mean"] = stats.get("mean")
            out[f"{key}_std"] = stats.get("std")
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare all MSTAR class render folders with matching GT folders.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--gt_root", type=Path, default=DEFAULT_GT_ROOT)
    parser.add_argument("--render_root", type=Path, default=DEFAULT_RENDER_ROOT)
    parser.add_argument("--render_rel", type=Path, default=DEFAULT_RENDER_REL)
    parser.add_argument("--output_root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument(
        "--classes",
        nargs="*",
        default=None,
        help="Classes to compare. Default: common directories in gt_root and render_root.",
    )
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--azimuth_match_tolerance", type=int, default=0)
    parser.add_argument("--target_only", action="store_true")
    parser.add_argument("--target_shadow", action="store_true")
    parser.add_argument("--no_visual_diagnosis", action="store_true")
    parser.add_argument("--no_agent_diagnosis", action="store_true")
    parser.add_argument(
        "--reuse_existing",
        action="store_true",
        help="Reuse an existing class comparison_results.json instead of recomputing it.",
    )
    parser.add_argument(
        "--no_auto_find_render_dir",
        action="store_true",
        help="Do not search for final_renders when the fixed render_rel path is missing.",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Disable SAR SSIM/intensity/local tolerance knobs for stricter metrics.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo_root = find_repo_root()
    compare_script = repo_root / "scripts" / "evaluation" / "compare_render_gt.py"

    gt_root = args.gt_root.resolve()
    render_root = args.render_root.resolve()
    output_root = args.output_root.resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    if args.classes:
        classes = args.classes
    else:
        gt_classes = {
            p.name
            for p in gt_root.iterdir()
            if p.is_dir() and p.name not in SKIP_NAMES and not p.name.lower().startswith("label")
        }
        render_classes = {
            p.name
            for p in render_root.iterdir()
            if p.is_dir() and p.name not in SKIP_NAMES and not p.name.lower().startswith("label")
        }
        classes = sorted(gt_classes & render_classes)

    rows = []
    failures = []
    for class_name in classes:
        gt_dir = gt_root / class_name
        render_dir, extra_render_dirs = resolve_render_dir(
            render_root / class_name,
            args.render_rel,
            auto_find=not args.no_auto_find_render_dir,
        )
        class_output = output_root / class_name

        row = {
            "class": class_name,
            "gt_dir": str(gt_dir),
            "render_dir": str(render_dir),
            "output_dir": str(class_output),
            "gt_images": image_count(gt_dir),
            "render_images": image_count(render_dir),
        }
        if extra_render_dirs:
            row["extra_render_candidates"] = " | ".join(str(p) for p in extra_render_dirs)

        if not gt_dir.is_dir():
            row["status"] = "missing_gt_dir"
            failures.append(row)
            rows.append(row)
            continue
        if not render_dir.is_dir():
            row["status"] = "missing_render_dir"
            failures.append(row)
            rows.append(row)
            continue

        summary_path = class_output / "comparison_results.json"
        if args.reuse_existing and summary_path.is_file():
            row["status"] = "reused"
            row.update(load_summary(summary_path))
            rows.append(row)
            continue

        cmd = [
            sys.executable,
            str(compare_script),
            "--render_dir",
            str(render_dir),
            "--gt_dir",
            str(gt_dir),
            "--output_dir",
            str(class_output),
            "--device",
            args.device,
            "--azimuth_match_tolerance",
            str(args.azimuth_match_tolerance),
        ]
        if args.target_only:
            cmd.append("--target_only")
        if args.target_shadow:
            cmd.append("--target_shadow")
        if args.no_visual_diagnosis:
            cmd.append("--no_visual_diagnosis")
        if args.no_agent_diagnosis:
            cmd.append("--no_agent_diagnosis")
        if args.strict:
            cmd += [
                "--ssim_mode",
                "pixel",
                "--sar_ssim_tolerant_radius",
                "0",
                "--sar_ssim_intensity_tolerance",
                "0",
                "--sar_tolerant_radius",
                "0",
                "--sar_ssim_smooth_radius",
                "0",
            ]

        print(f"\n[{class_name}] comparing {render_dir} -> {gt_dir}")
        result = subprocess.run(cmd, cwd=str(repo_root))
        row["status"] = "ok" if result.returncode == 0 else f"failed:{result.returncode}"
        if result.returncode != 0:
            failures.append(row)

        row.update(load_summary(summary_path))
        rows.append(row)

    csv_path = output_root / "all_classes_summary.csv"
    json_path = output_root / "all_classes_summary.json"
    fieldnames = sorted({key for row in rows for key in row.keys()})
    preferred = ["class", "status", "gt_images", "render_images", "PSNR_mean", "SSIM_mean", "SAR_SSIM_mean", "SAR_TOL_PSNR_mean"]
    fieldnames = [x for x in preferred if x in fieldnames] + [x for x in fieldnames if x not in preferred]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2, ensure_ascii=False)

    print(f"\nsummary csv: {csv_path}")
    print(f"summary json: {json_path}")
    if failures:
        print(f"failures/skips: {len(failures)}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
