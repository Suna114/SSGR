#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
SAR-GS 重建结果完成度量化与显示

根据 compare_render_gt.py 生成的 comparison_results.json，
计算并打印「完成度」等级与主要指标汇总，便于论文/报告使用。

使用前请先运行对比：
    python compare_render_gt.py --render_dir my_renders/1/train/renders --gt_dir my_renders/1/train/gt --output_dir my_renders/1/train/comparison --sar_metrics

然后运行本脚本：
    python evaluate_reconstruction_quality.py --comparison_json my_renders/1/train/comparison/comparison_results.json

或直接指定渲染/真值目录（会自动调用对比并生成完成度）：
    python evaluate_reconstruction_quality.py --render_dir my_renders/1/train/renders --gt_dir my_renders/1/train/gt --output_dir my_renders/1/train/comparison --sar_metrics
"""

import json
import argparse
from pathlib import Path


# =============================================================================
# SAR 专用完成度等级阈值
# 说明：针对 SAR 成像特点（斑点噪声、灰度分布与光学不同），采用较宽松阈值；
# LPIPS 基于自然图像训练，对 SAR 参考价值有限，仅作参考不参与综合等级。
# =============================================================================

# PSNR(dB) - SAR: >26 优秀, 22-26 良好, 18-22 一般, <18 较差
def grade_psnr_sar(psnr):
    if psnr >= 26: return "优秀"
    if psnr >= 22: return "良好"
    if psnr >= 18: return "一般"
    return "较差"


# SSIM - SAR: >0.80 优秀, 0.70-0.80 良好, 0.60-0.70 一般, <0.60 较差
def grade_ssim_sar(ssim):
    if ssim >= 0.80: return "优秀"
    if ssim >= 0.70: return "良好"
    if ssim >= 0.60: return "一般"
    return "较差"


# LPIPS - SAR 仅作参考（基于自然图像，不参与综合）: <0.20 优秀, 0.20-0.35 良好, 0.35-0.50 一般, >0.50 较差
def grade_lpips_sar(lpips_val):
    if lpips_val <= 0.20: return "优秀"
    if lpips_val <= 0.35: return "良好"
    if lpips_val <= 0.50: return "一般"
    return "较差"


# SAR 指标：对比度/边缘/直方图相似度，>0.8 优秀, 0.6-0.8 良好, 0.5-0.6 一般, <0.5 较差
def grade_sar_metric(value):
    if value >= 0.80: return "优秀"
    if value >= 0.60: return "良好"
    if value >= 0.50: return "一般"
    return "较差"


def overall_grade_sar(summary):
    """
    综合等级（SAR 专用）：
    - 以 PSNR、SSIM 为主（使用 SAR 专用阈值）
    - 若有 SAR 指标则纳入（contrast_similarity, histogram_correlation, edge_similarity）
    - LPIPS 不参与综合等级（仅作参考显示）
    """
    psnr = summary.get("PSNR", {}).get("mean")
    ssim = summary.get("SSIM", {}).get("mean")
    if psnr is None and ssim is None:
        return "未知", "缺少 PSNR/SSIM 数据"
    grades = []
    if psnr is not None:
        grades.append((grade_psnr_sar(psnr), "PSNR"))
    if ssim is not None:
        grades.append((grade_ssim_sar(ssim), "SSIM"))
    # 纳入 SAR 指标（若存在）
    for key in ["contrast_similarity", "histogram_correlation", "edge_similarity"]:
        val = summary.get(key, {}).get("mean")
        if val is not None:
            grades.append((grade_sar_metric(val), key))
    if not grades:
        return "未知", "无可用指标"
    rank_order = {"优秀": 4, "良好": 3, "一般": 2, "较差": 1}
    if any(g[0] == "较差" for g in grades):
        return "较差", "至少有一项指标为较差"
    if all(g[0] == "优秀" for g in grades):
        return "优秀", "各项指标均优秀"
    min_rank = min(rank_order[g[0]] for g in grades)
    inv_order = {v: k for k, v in rank_order.items()}
    return inv_order[min_rank], "综合 PSNR/SSIM/SAR 指标（LPIPS 未参与）"


def print_completion_report(comparison_json_path, verbose=True):
    path = Path(comparison_json_path)
    if not path.exists():
        raise FileNotFoundError(f"找不到对比结果文件: {path}")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    summary = data.get("summary", {})
    per_image = data.get("per_image", [])
    n_images = len(per_image)

    overall, reason = overall_grade_sar(summary)
    psnr_s = summary.get("PSNR", {})
    ssim_s = summary.get("SSIM", {})
    lpips_s = summary.get("LPIPS", {})
    mse_s = summary.get("MSE", {})

    # 控制台输出：完成度量化报告（SAR 专用阈值）
    print()
    print("=" * 70)
    print("  SAR-GS 重建结果完成度量化报告（SAR 专用等级）")
    print("=" * 70)
    print(f"  对比结果文件: {path.name}")
    print(f"  有效图像数量: {n_images}")
    print()
    print("  【综合完成度】")
    print(f"    等级: {overall}  （{reason}）")
    print()
    print("  【主要指标汇总】（渲染图与真值对比，SAR 专用阈值）")
    print("  " + "-" * 66)
    if psnr_s:
        print(f"    PSNR (峰值信噪比)   : 平均 {psnr_s['mean']:.2f} dB    范围 [{psnr_s['min']:.2f}, {psnr_s['max']:.2f}]  →  {grade_psnr_sar(psnr_s['mean'])}")
    if ssim_s:
        print(f"    SSIM (结构相似性)   : 平均 {ssim_s['mean']:.4f}     范围 [{ssim_s['min']:.4f}, {ssim_s['max']:.4f}]  →  {grade_ssim_sar(ssim_s['mean'])}")
    if lpips_s:
        print(f"    LPIPS (感知相似度)  : 平均 {lpips_s['mean']:.4f}     范围 [{lpips_s['min']:.4f}, {lpips_s['max']:.4f}]  →  {grade_lpips_sar(lpips_s['mean'])} (仅参考)")
    if mse_s:
        print(f"    MSE (均方误差)      : 平均 {mse_s['mean']:.6f}")
    # SAR 相关（参与综合等级）
    for key in ["contrast_similarity", "histogram_correlation", "edge_similarity"]:
        if key in summary and summary[key]:
            s = summary[key]
            print(f"    {key:22s}: 平均 {s['mean']:.4f}  →  {grade_sar_metric(s['mean'])}")
    print("  " + "-" * 66)
    print()
    print("  说明: 采用 SAR 专用阈值；PSNR/SSIM/SAR 指标参与综合等级，LPIPS 仅参考。")
    print("=" * 70)
    print()

    if verbose and per_image:
        print("  【各视角简要】前 5 张与后 5 张")
        print("  " + "-" * 66)
        show = per_image[:5] if len(per_image) <= 10 else per_image[:5] + per_image[-5:]
        for m in show:
            name = m.get("image_name", "?")
            psnr = m.get("PSNR")
            ssim = m.get("SSIM")
            psnr_str = f"{psnr:.2f}" if psnr is not None else "N/A"
            ssim_str = f"{ssim:.4f}" if ssim is not None else "N/A"
            print(f"    {name:30s}  PSNR={psnr_str:>8s}  SSIM={ssim_str}")
        print("  " + "-" * 66)
        print()

    return {
        "overall_grade": overall,
        "n_images": n_images,
        "PSNR_mean": psnr_s.get("mean") if psnr_s else None,
        "SSIM_mean": ssim_s.get("mean") if ssim_s else None,
        "LPIPS_mean": lpips_s.get("mean") if lpips_s else None,
        "summary": summary,
    }


def main():
    parser = argparse.ArgumentParser(description="SAR-GS 重建结果完成度量化显示")
    parser.add_argument("--comparison_json", type=str, default=None,
                        help="compare_render_gt.py 生成的 comparison_results.json 路径")
    parser.add_argument("--render_dir", type=str, default=None,
                        help="渲染图目录（若与 --gt_dir 同时指定，将先运行对比再生成完成度）")
    parser.add_argument("--gt_dir", type=str, default=None,
                        help="真值图目录")
    parser.add_argument("--output_dir", type=str, default=None,
                        help="对比结果输出目录（与 --render_dir/--gt_dir 配合使用）")
    parser.add_argument("--sar_metrics", action="store_true", help="计算 SAR 指标")
    parser.add_argument("--quiet", action="store_true", help="不打印逐张简要")
    args = parser.parse_args()

    json_path = args.comparison_json
    if args.render_dir and args.gt_dir:
        # 先运行对比
        try:
            from compare_render_gt import compare_directories
            out_dir = args.output_dir or (Path(args.render_dir).parent / "comparison")
            out_dir = str(out_dir)
            print("正在运行渲染与真值对比...")
            all_metrics, summary = compare_directories(
                args.render_dir, args.gt_dir, out_dir,
                device="cuda", calculate_sar=args.sar_metrics, debug=False,
                align_images=False, diagnose=False
            )
            json_path = str(Path(out_dir) / "comparison_results.json")
        except Exception as e:
            print(f"对比失败: {e}")
            return 1
    if not json_path:
        print("请指定 --comparison_json 或同时指定 --render_dir 与 --gt_dir")
        return 1
    print_completion_report(json_path, verbose=not args.quiet)
    return 0


if __name__ == "__main__":
    exit(main())
