#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from pathlib import Path

import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from utils.loss_utils import ssim  # noqa: E402

IMG_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}


def _image_files(path: Path) -> list[Path]:
    return sorted([p for p in path.iterdir() if p.suffix.lower() in IMG_EXTS])


def _parse_azimuth(path: Path) -> float:
    stem = path.stem
    m = re.search(r"(?i)azimuth[_-]?(\d+(?:\.\d+)?)", stem)
    if m:
        return float(m.group(1)) % 360.0
    m = re.search(r"(\d+(?:\.\d+)?)$", stem)
    if m:
        return float(m.group(1)) % 360.0
    return float("nan")


def _angle_gap(a: float, b: float) -> float:
    return (float(b) - float(a)) % 360.0


def _load_rgb(path: Path) -> torch.Tensor:
    im = Image.open(path).convert("RGB")
    arr = np.asarray(im, dtype=np.float32) / 255.0
    return torch.from_numpy(arr).permute(2, 0, 1).unsqueeze(0).contiguous()


def _sar_log(img: torch.Tensor, log_scale: float) -> torch.Tensor:
    gray = img.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    return (torch.log1p(gray * float(log_scale)) / math.log1p(float(log_scale))).clamp(0.0, 1.0)


def _dilate(mask: torch.Tensor, radius: int) -> torch.Tensor:
    radius = int(radius)
    if radius <= 0:
        return mask
    k = 2 * radius + 1
    return F.max_pool2d(mask, kernel_size=k, stride=1, padding=radius).clamp(0.0, 1.0)


def _target_mask(a: torch.Tensor, b: torch.Tensor, threshold: float, quantile: float, dilate: int) -> torch.Tensor:
    ga = a.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    gb = b.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    vals = torch.cat([ga.flatten(), gb.flatten()])
    q = torch.quantile(vals, min(max(float(quantile), 0.0), 1.0)) if vals.numel() else vals.new_tensor(0.0)
    th = max(float(threshold), float(q.item()))
    mask = ((ga >= th) | (gb >= th)).float()
    return _dilate(mask, int(dilate))


def _bbox_from_mask(mask: torch.Tensor, margin: int) -> tuple[int, int, int, int] | None:
    m = mask[0, 0] > 0.5
    ys, xs = torch.where(m)
    if ys.numel() == 0:
        return None
    h, w = m.shape
    y0 = max(0, int(ys.min().item()) - int(margin))
    y1 = min(h, int(ys.max().item()) + 1 + int(margin))
    x0 = max(0, int(xs.min().item()) - int(margin))
    x1 = min(w, int(xs.max().item()) + 1 + int(margin))
    if y1 <= y0 or x1 <= x0:
        return None
    return y0, y1, x0, x1


def _crop(img: torch.Tensor, bbox: tuple[int, int, int, int] | None) -> torch.Tensor:
    if bbox is None:
        return img
    y0, y1, x0, x1 = bbox
    return img[..., y0:y1, x0:x1]


def _ssim(a: torch.Tensor, b: torch.Tensor) -> float:
    if a.shape[-2:] != b.shape[-2:]:
        b = F.interpolate(b, size=a.shape[-2:], mode="bilinear", align_corners=False)
    if min(a.shape[-2:]) < 11:
        return float("nan")
    return float(ssim(a, b).item())


def _pair_metrics(a_path: Path, b_path: Path, args: argparse.Namespace) -> dict:
    a = _load_rgb(a_path)
    b = _load_rgb(b_path)
    if a.shape[-2:] != b.shape[-2:]:
        b = F.interpolate(b, size=a.shape[-2:], mode="bilinear", align_corners=False)
    a_log = _sar_log(a, args.log_scale)
    b_log = _sar_log(b, args.log_scale)
    mask = _target_mask(a, b, args.target_threshold, args.target_quantile, args.target_dilate)
    bbox = _bbox_from_mask(mask, args.bbox_margin)
    return {
        "a": a_path.name,
        "b": b_path.name,
        "azimuth_a": _parse_azimuth(a_path),
        "azimuth_b": _parse_azimuth(b_path),
        "angle_gap": _angle_gap(_parse_azimuth(a_path), _parse_azimuth(b_path)),
        "sar_ssim_full": _ssim(a_log, b_log),
        "pixel_ssim_full": _ssim(a, b),
        "sar_ssim_target_crop": _ssim(_crop(a_log, bbox), _crop(b_log, bbox)),
        "pixel_ssim_target_crop": _ssim(_crop(a, bbox), _crop(b, bbox)),
        "target_mask_ratio": float(mask.mean().item()),
    }


def _summarize(rows: list[dict], threshold: float, severe_threshold: float) -> dict:
    vals = np.array([r["sar_ssim_target_crop"] for r in rows if math.isfinite(float(r["sar_ssim_target_crop"]))], dtype=np.float64)
    flagged = [r for r in rows if math.isfinite(float(r["sar_ssim_target_crop"])) and float(r["sar_ssim_target_crop"]) >= threshold]
    severe = [r for r in rows if math.isfinite(float(r["sar_ssim_target_crop"])) and float(r["sar_ssim_target_crop"]) >= severe_threshold]
    if vals.size == 0:
        stats = {"count": 0}
    else:
        stats = {
            "count": int(vals.size),
            "mean": float(vals.mean()),
            "std": float(vals.std()),
            "min": float(vals.min()),
            "max": float(vals.max()),
            "median": float(np.median(vals)),
            "p90": float(np.quantile(vals, 0.90)),
            "p95": float(np.quantile(vals, 0.95)),
        }
    return {
        "metric": "sar_ssim_target_crop",
        "threshold": float(threshold),
        "severe_threshold": float(severe_threshold),
        "stats": stats,
        "flagged_count": len(flagged),
        "severe_count": len(severe),
        "flagged_pairs": flagged,
        "interpretation": (
            "suspiciously smooth / possible overfit or angle collapse"
            if flagged
            else "no adjacent pair exceeded the high-similarity threshold"
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Check adjacent azimuth render similarity for possible overfit/angle collapse.")
    parser.add_argument("--render_dir", type=Path, required=True)
    parser.add_argument("--output_dir", type=Path, default=None)
    parser.add_argument("--threshold", type=float, default=0.985)
    parser.add_argument("--severe_threshold", type=float, default=0.995)
    parser.add_argument("--log_scale", type=float, default=20.0)
    parser.add_argument("--target_threshold", type=float, default=0.012)
    parser.add_argument("--target_quantile", type=float, default=0.85)
    parser.add_argument("--target_dilate", type=int, default=2)
    parser.add_argument("--bbox_margin", type=int, default=12)
    parser.add_argument("--include_wrap", action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args()

    files = _image_files(args.render_dir)
    items = [(p, _parse_azimuth(p)) for p in files]
    items = [(p, az) for p, az in items if math.isfinite(float(az))]
    items.sort(key=lambda x: (x[1], x[0].name))
    if len(items) < 2:
        raise RuntimeError(f"Need at least two azimuth-named images in {args.render_dir}")

    pairs = [(items[i][0], items[i + 1][0]) for i in range(len(items) - 1)]
    if bool(args.include_wrap) and len(items) > 2:
        pairs.append((items[-1][0], items[0][0]))
    rows = [_pair_metrics(a, b, args) for a, b in pairs]
    summary = _summarize(rows, args.threshold, args.severe_threshold)

    out_dir = args.output_dir or (args.render_dir.parent / "adjacent_similarity")
    out_dir.mkdir(parents=True, exist_ok=True)
    with (out_dir / "adjacent_similarity.json").open("w", encoding="utf-8") as f:
        json.dump({"render_dir": str(args.render_dir), "summary": summary, "pairs": rows}, f, indent=2, ensure_ascii=False)
    with (out_dir / "adjacent_similarity.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with (out_dir / "adjacent_similarity_report.txt").open("w", encoding="utf-8") as f:
        f.write("Adjacent azimuth similarity report\n")
        f.write("=" * 80 + "\n")
        f.write(f"render_dir: {args.render_dir}\n")
        f.write(f"metric: {summary['metric']}\n")
        f.write(f"threshold: {args.threshold:.4f}, severe: {args.severe_threshold:.4f}\n")
        f.write(f"stats: {summary['stats']}\n")
        f.write(f"flagged: {summary['flagged_count']}, severe: {summary['severe_count']}\n\n")
        f.write("top pairs:\n")
        for r in sorted(rows, key=lambda x: float(x["sar_ssim_target_crop"]), reverse=True)[:12]:
            f.write(
                f"- {r['a']} -> {r['b']} gap={r['angle_gap']:.3f} "
                f"SAR_SSIM_target={r['sar_ssim_target_crop']:.6f} "
                f"pixel_target={r['pixel_ssim_target_crop']:.6f}\n"
            )
    print(f"[adjacent similarity] wrote: {out_dir}")
    print(f"[adjacent similarity] {summary['interpretation']}; flagged={summary['flagged_count']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
