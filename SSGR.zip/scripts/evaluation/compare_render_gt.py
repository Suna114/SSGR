# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
高斯泼溅渲染结果与原始图像相似度对比工具

功能：
1. 支持批量对比渲染结果和原始图像
2. 计算多种相似度指标：PSNR, SSIM, LPIPS, MSE等
3. 支持SAR图像特定指标
4. 生成详细的对比报告和可视化
5. 支持单张图像对比和批量对比

使用方法：
    # 批量对比两个文件夹
    python compare_render_gt.py --render_dir ./output/model/test/ours_30000/renders --gt_dir ./output/model/test/ours_30000/gt
    
    # 单张图像对比
    python compare_render_gt.py --render_path render.png --gt_path gt.png
    
    # 指定输出目录
    python compare_render_gt.py --render_dir renders --gt_dir gt --output_dir ./comparison_results

    # 仅目标区域（排除背景，GT 分位数掩码）
    python compare_render_gt.py --render_dir renders --gt_dir gt --output_dir ./results --target_only --target_percentile 85

    # 批量对比且渲染名为 azimuth_331.png、GT 为 T72-15-331.jpg 等（按方位数字匹配）时无须改名；仅用 stem 则用 --no_azimuth_match
"""

import os
import re
import argparse
import csv
import json
import math
from collections import defaultdict
import numpy as np
from pathlib import Path
from PIL import Image, ImageDraw
import torch
import torchvision.transforms.functional as tf
from tqdm import tqdm
import matplotlib.pyplot as plt
import cv2
from utils.filter_background import build_target_mask as build_filter_background_target_mask

# 导入项目中的评估工具
from utils.image_utils import psnr
from utils.loss_utils import ssim
from utils.target_region_compare import (
    build_target_mask_from_gt,
    masked_mse,
    masked_mae,
    masked_psnr_from_mse,
    mask_bbox_with_margin,
    crop_tensor_11hw,
    ensure_min_size,
)
try:
    from lpipsPyTorch import lpips
    LPIPS_AVAILABLE = True
except ImportError:
    LPIPS_AVAILABLE = False
    print("⚠️ 警告: LPIPS未安装，将跳过LPIPS指标计算")


def normalize_cli_path(p):
    """
    去掉路径两端空格及中英文弯引号（Word/微信等粘贴时常带入），
    避免出现 cwd + 「'F:\\...'」这类非法拼接。
    """
    if p is None:
        return p
    s = os.fspath(p).strip().strip("\ufeff")
    _pairs = (
        ('"', '"'),
        ("'", "'"),
        ("\u2018", "\u2019"),  # ‘ ’
        ("\u201c", "\u201d"),  # “ ”
    )
    while len(s) >= 2:
        changed = False
        for a, b in _pairs:
            if s.startswith(a) and s.endswith(b):
                s = s[len(a) : len(s) - len(b)].strip()
                changed = True
                break
        if not changed:
            break
    return s


def extract_azimuth_from_render_stem(stem: str):
    """
    从渲染图 stem 中取方位角，例如 azimuth_331、Azimuth-331、prefix_azimuth_12。
    返回 int，若不匹配则为 None。
    """
    if not stem:
        return None
    m = re.search(r"(?i)azimuth[_-](\d+)", stem)
    if not m:
        return None
    return int(m.group(1))


def extract_azimuth_from_gt_stem(stem: str):
    """
    从 GT 文件名 stem 取「最后一个由连字符分隔的纯数字段」作为方位角编号，
    例如 T72-15-331 -> 331，T72-15-001 -> 1（前导零忽略）。
    若无此类段则为 None。
    """
    if not stem or "-" not in stem:
        return None
    for part in reversed(stem.split("-")):
        part = part.strip()
        if part.isdigit():
            return int(part)
        # 形如 001_extra 的常见变体（仍取第一段数字）
        m = re.match(r"^(\d+)", part)
        if m:
            return int(m.group(1))
    return None


def build_gt_azimuth_index(gt_files: dict):
    """
    将 gt_files (name -> Path) 按 extract_azimuth_from_gt_stem 建索引。
    若同一方位角对应多个文件，取按名称排序后的第一个，并记录歧义列表。
    返回 (azimuth -> Path, list of (az, [names]))
    """
    buckets = defaultdict(list)
    for name in sorted(gt_files.keys()):
        p = gt_files[name]
        az = extract_azimuth_from_gt_stem(Path(name).stem)
        if az is not None:
            buckets[az].append(p)

    index = {}
    ambiguous = []
    for az in sorted(buckets.keys()):
        paths = sorted(buckets[az], key=lambda x: x.name)
        index[az] = paths[0]
        if len(paths) > 1:
            ambiguous.append((az, [x.name for x in paths]))

    return index, ambiguous


def angular_distance_deg(a, b):
    """Smallest circular distance between two azimuths in degrees."""
    d = abs((int(a) % 360) - (int(b) % 360))
    return min(d, 360 - d)


def find_nearest_azimuth_match(azimuth_index, azimuth, max_error=0):
    """Find the nearest GT azimuth when exact integer matching is unavailable."""
    if azimuth is None or not azimuth_index:
        return None, None
    max_error = int(max_error)
    if max_error <= 0:
        return None, None
    best_az = None
    best_dist = None
    for gt_az in azimuth_index.keys():
        dist = angular_distance_deg(azimuth, gt_az)
        if best_dist is None or dist < best_dist:
            best_az = gt_az
            best_dist = dist
    if best_dist is not None and best_dist <= int(max_error):
        return best_az, azimuth_index[best_az]
    return None, None


def extract_azimuth_from_any_stem(stem: str):
    """Extract an azimuth from either render-style or GT-style file names."""
    az = extract_azimuth_from_render_stem(stem)
    if az is not None:
        return az
    return extract_azimuth_from_gt_stem(stem)


def parse_angle_list(text):
    """Parse comma/space separated integer azimuths."""
    if text is None:
        return None
    angles = set()
    for part in re.split(r"[\s,;]+", str(text).strip()):
        if not part:
            continue
        angles.add(int(float(part)) % 360)
    return angles


def build_train_angle_set(train_angle_list=None, train_angle_step=None, train_angle_dir=None):
    """Build a train-view azimuth set from an explicit list, step, and/or image directory."""
    angles = set()
    listed = parse_angle_list(train_angle_list)
    if listed:
        angles.update(listed)

    if train_angle_step is not None and int(train_angle_step) > 0:
        step = int(train_angle_step)
        angles.update(range(0, 360, step))

    if train_angle_dir:
        p = Path(normalize_cli_path(train_angle_dir))
        if p.exists():
            image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'}
            for f in p.iterdir():
                if f.suffix.lower() not in image_extensions:
                    continue
                az = extract_azimuth_from_any_stem(f.stem)
                if az is not None:
                    angles.add(int(az) % 360)
        else:
            print(f"⚠️ warning: train angle directory does not exist, ignored: {p}")

    return angles


def load_image(image_path, device='cuda', normalize=True):
    """
    加载图像并转换为tensor格式
    
    Args:
        image_path: 图像路径
        device: 设备（'cuda'或'cpu'）
        normalize: 是否归一化到[0, 1]（默认True）
    
    Returns:
        image_tensor: (1, C, H, W)格式的tensor，值范围[0, 1]
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"图像文件不存在: {image_path}")
    
    # 使用PIL加载图像
    image = Image.open(image_path)
    
    # 转换为RGB格式（如果是灰度图，复制3次）
    if image.mode == 'L':
        image = image.convert('RGB')
    elif image.mode != 'RGB':
        image = image.convert('RGB')
    
    # 转换为tensor: (C, H, W)，值范围[0, 1]
    image_tensor = tf.to_tensor(image)
    
    # 🔧 新增：检查是否需要归一化
    # 如果图像已经是[0, 1]范围，tf.to_tensor会自动处理
    # 但如果图像是16位或其他格式，可能需要特殊处理
    if normalize:
        # 确保值范围在[0, 1]
        if image_tensor.max() > 1.0:
            image_tensor = image_tensor / 255.0
    
    # 添加batch维度: (1, C, H, W)
    image_tensor = image_tensor.unsqueeze(0)
    
    # 移动到指定设备
    if device == 'cuda' and torch.cuda.is_available():
        image_tensor = image_tensor.cuda()
    else:
        image_tensor = image_tensor.cpu()
        device = 'cpu'
    
    return image_tensor, device


def calculate_mse(img1, img2):
    """
    计算均方误差（MSE）
    
    Args:
        img1, img2: (1, C, H, W)格式的tensor
    
    Returns:
        mse: 标量值
    """
    mse = ((img1 - img2) ** 2).view(img1.shape[0], -1).mean(1).mean()
    return mse.item()


def calculate_mae(img1, img2):
    """
    计算平均绝对误差（MAE / L1 Loss）
    
    Args:
        img1, img2: (1, C, H, W)格式的tensor
    
    Returns:
        mae: 标量值
    """
    mae = torch.abs(img1 - img2).view(img1.shape[0], -1).mean(1).mean()
    return mae.item()


def calculate_psnr(img1, img2):
    """
    计算峰值信噪比（PSNR）
    
    Args:
        img1, img2: (1, C, H, W)格式的tensor
    
    Returns:
        psnr_value: 标量值（dB）
    """
    psnr_value = psnr(img1, img2)
    return psnr_value.item()


def psnr_from_mse(mse, max_val=1.0):
    """PSNR from an MSE value in a normalized metric domain."""
    mse = float(mse)
    if mse <= 1e-12:
        return 99.0
    return float(10.0 * math.log10((float(max_val) ** 2) / mse))


def calculate_ssim(img1, img2):
    """
    计算结构相似性指数（SSIM）
    
    Args:
        img1, img2: (1, C, H, W)格式的tensor
    
    Returns:
        ssim_value: 标量值（范围[0, 1]）
    """
    ssim_value = ssim(img1, img2)
    return ssim_value.item()


def sar_intensity_image(img, log_scale=20.0, smooth_radius=0):
    """Convert an image tensor to a SAR scattering-intensity image for SSIM."""
    if img.shape[1] > 1:
        intensity = img.mean(dim=1, keepdim=True)
    else:
        intensity = img
    intensity = intensity.clamp_min(0.0)
    log_scale = max(float(log_scale), 1e-6)
    intensity = torch.log1p(log_scale * intensity) / math.log1p(log_scale)

    smooth_radius = int(smooth_radius)
    if smooth_radius > 0:
        k = 2 * smooth_radius + 1
        if min(intensity.shape[-2:]) > smooth_radius:
            intensity = torch.nn.functional.avg_pool2d(
                torch.nn.functional.pad(
                    intensity,
                    (smooth_radius, smooth_radius, smooth_radius, smooth_radius),
                    mode="reflect",
                ),
                kernel_size=k,
                stride=1,
                padding=0,
            )
        else:
            intensity = torch.nn.functional.avg_pool2d(intensity, kernel_size=k, stride=1, padding=smooth_radius)
    return intensity.clamp(0.0, 1.0)


def _shift_tensor_reflect(img, dy, dx):
    """Shift an image tensor by a few pixels using reflect padding."""
    dy = int(dy)
    dx = int(dx)
    if dy == 0 and dx == 0:
        return img
    pad = (abs(dx), abs(dx), abs(dy), abs(dy))
    padded = torch.nn.functional.pad(img, pad, mode="reflect")
    y0 = abs(dy) - dy
    x0 = abs(dx) - dx
    h, w = img.shape[-2:]
    return padded[..., y0 : y0 + h, x0 : x0 + w]


def _apply_intensity_tolerance(src, ref, tolerance):
    """Ignore small SAR intensity differences by pulling src toward ref."""
    tolerance = max(float(tolerance), 0.0)
    if tolerance <= 0.0:
        return src
    diff = src - ref
    return ref + diff.sign() * (diff.abs() - tolerance).clamp_min(0.0)


def calculate_sar_intensity_ssim(
    img1,
    img2,
    log_scale=20.0,
    smooth_radius=1,
    tolerant_radius=0,
    intensity_tolerance=0.0,
):
    """SSIM on log-compressed SAR scattering intensity instead of RGB pixels."""
    i1 = sar_intensity_image(img1, log_scale=log_scale, smooth_radius=smooth_radius)
    i2 = sar_intensity_image(img2, log_scale=log_scale, smooth_radius=smooth_radius)
    tolerant_radius = int(tolerant_radius)
    if tolerant_radius <= 0:
        return ssim(_apply_intensity_tolerance(i1, i2, intensity_tolerance), i2).item()

    best = None
    for dy in range(-tolerant_radius, tolerant_radius + 1):
        for dx in range(-tolerant_radius, tolerant_radius + 1):
            shifted = _shift_tensor_reflect(i2, dy, dx)
            score_map = _ssim_map_simple(_apply_intensity_tolerance(i1, shifted, intensity_tolerance), shifted)
            best = score_map if best is None else torch.maximum(best, score_map)
    return best.mean().item()


def _prepare_metric_mask(mask, ref):
    if mask is None:
        return None
    if mask.dim() == 3:
        mask = mask.unsqueeze(1)
    mask = mask.to(device=ref.device, dtype=ref.dtype).clamp(0.0, 1.0)
    if mask.shape[-2:] != ref.shape[-2:]:
        mask = torch.nn.functional.interpolate(mask, size=ref.shape[-2:], mode="nearest")
    return mask


def _masked_mean(value, mask=None):
    if mask is None:
        return value.mean()
    if mask.shape[1] != value.shape[1]:
        mask = mask.expand_as(value)
    return (value * mask).sum() / mask.sum().clamp_min(1e-8)


def _local_range_error(src, ref, radius):
    """Zero error when src falls inside the local min/max range of ref."""
    radius = int(radius)
    if radius <= 0:
        return torch.abs(src - ref)
    k = 2 * radius + 1
    pad = (radius, radius, radius, radius)
    ref_pad = torch.nn.functional.pad(ref, pad, mode="reflect")
    local_max = torch.nn.functional.max_pool2d(ref_pad, kernel_size=k, stride=1)
    local_min = -torch.nn.functional.max_pool2d(-ref_pad, kernel_size=k, stride=1)
    above = (src - local_max).clamp_min(0.0)
    below = (local_min - src).clamp_min(0.0)
    return above + below


def calculate_sar_error_metrics(img1, img2, mask=None, log_scale=20.0, smooth_radius=0, tolerant_radius=1):
    """
    SAR-aware error metrics on log-compressed scattering intensity.

    SAR_MSE/SAR_PSNR are still pixel-aligned, but computed in a log intensity
    domain. SAR_TOL_* additionally allows a small local displacement of sparse
    scatterers by comparing each pixel against the other image's local range.
    """
    i1 = sar_intensity_image(img1, log_scale=log_scale, smooth_radius=smooth_radius)
    i2 = sar_intensity_image(img2, log_scale=log_scale, smooth_radius=smooth_radius)
    mask = _prepare_metric_mask(mask, i1)

    diff = i1 - i2
    mse = float(_masked_mean(diff * diff, mask).item())
    mae = float(_masked_mean(torch.abs(diff), mask).item())
    gt_mean = _masked_mean(i2, mask)
    gt_var = _masked_mean((i2 - gt_mean) ** 2, mask)
    nrmse = float(math.sqrt(max(mse, 0.0)) / math.sqrt(max(float(gt_var.item()), 1e-12)))

    e12 = _local_range_error(i1, i2, tolerant_radius)
    e21 = _local_range_error(i2, i1, tolerant_radius)
    tol_abs = 0.5 * (e12 + e21)
    tol_mse = float(_masked_mean(tol_abs * tol_abs, mask).item())
    tol_mae = float(_masked_mean(tol_abs, mask).item())

    return {
        "SAR_MSE": mse,
        "SAR_MAE": mae,
        "SAR_PSNR": psnr_from_mse(mse),
        "SAR_NRMSE": nrmse,
        "SAR_TOL_MSE": tol_mse,
        "SAR_TOL_MAE": tol_mae,
        "SAR_TOL_PSNR": psnr_from_mse(tol_mse),
    }


def add_prefixed_metrics(metrics, values, suffix=""):
    """Add metric values with an optional suffix, preserving insertion order."""
    for key, value in values.items():
        metrics[f"{key}{suffix}"] = value


def _ssim_map_simple(img1, img2, window_size=11):
    """Local SSIM map for masked evaluation."""
    if img1.shape[1] != img2.shape[1]:
        raise ValueError("SSIM inputs must have the same channel count")
    radius = max(1, int(window_size) // 2)
    k = 2 * radius + 1
    channel = img1.shape[1]
    weight = torch.ones((channel, 1, k, k), dtype=img1.dtype, device=img1.device) / float(k * k)
    mu1 = torch.nn.functional.conv2d(img1, weight, padding=radius, groups=channel)
    mu2 = torch.nn.functional.conv2d(img2, weight, padding=radius, groups=channel)
    mu1_sq = mu1 * mu1
    mu2_sq = mu2 * mu2
    mu12 = mu1 * mu2
    sigma1_sq = torch.nn.functional.conv2d(img1 * img1, weight, padding=radius, groups=channel) - mu1_sq
    sigma2_sq = torch.nn.functional.conv2d(img2 * img2, weight, padding=radius, groups=channel) - mu2_sq
    sigma12 = torch.nn.functional.conv2d(img1 * img2, weight, padding=radius, groups=channel) - mu12
    c1 = 0.01 ** 2
    c2 = 0.03 ** 2
    return ((2 * mu12 + c1) * (2 * sigma12 + c2)) / ((mu1_sq + mu2_sq + c1) * (sigma1_sq + sigma2_sq + c2)).clamp_min(1e-8)


def calculate_masked_ssim(
    img1,
    img2,
    mask,
    sar_intensity=False,
    log_scale=20.0,
    smooth_radius=1,
    tolerant_radius=0,
    intensity_tolerance=0.0,
):
    """SSIM weighted by a 1x1xHxW target mask."""
    if sar_intensity:
        x = sar_intensity_image(img1, log_scale=log_scale, smooth_radius=smooth_radius)
        y = sar_intensity_image(img2, log_scale=log_scale, smooth_radius=smooth_radius)
    else:
        x = img1.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
        y = img2.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    if mask.dim() == 3:
        mask = mask.unsqueeze(1)
    mask = mask.to(device=x.device, dtype=x.dtype).clamp(0.0, 1.0)
    if mask.shape[-2:] != x.shape[-2:]:
        mask = torch.nn.functional.interpolate(mask, size=x.shape[-2:], mode="nearest")
    tolerant_radius = int(tolerant_radius)
    if tolerant_radius > 0:
        ssim_map = None
        for dy in range(-tolerant_radius, tolerant_radius + 1):
            for dx in range(-tolerant_radius, tolerant_radius + 1):
                shifted = _shift_tensor_reflect(y, dy, dx)
                score_map = _ssim_map_simple(_apply_intensity_tolerance(x, shifted, intensity_tolerance), shifted)
                ssim_map = score_map if ssim_map is None else torch.maximum(ssim_map, score_map)
    else:
        ssim_map = _ssim_map_simple(_apply_intensity_tolerance(x, y, intensity_tolerance), y)
    while mask.dim() < ssim_map.dim():
        mask = mask.unsqueeze(1)
    return ((ssim_map * mask).sum() / mask.sum().clamp_min(1.0)).item()


def build_target_mask_from_reference(mask_img, threshold=0.08, quantile=0.35, dilate=0):
    """Build a compact target mask from a target-render/reference image."""
    gray = mask_img.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    q = torch.quantile(gray.flatten(), float(quantile)).item()
    th = max(float(threshold), float(q))
    mask = (gray >= th).float()
    if int(dilate) > 0:
        for _ in range(int(dilate)):
            mask = torch.nn.functional.max_pool2d(mask, kernel_size=3, stride=1, padding=1)
    return mask.clamp(0.0, 1.0)


def build_target_mask_filter_background(
    img,
    *,
    percentile=95.0,
    min_target_ratio=0.002,
    blur_sigma=1.0,
    open_iter=0,
    close_iter=0,
    morph_kernel=5,
    largest_cc=True,
    min_cc_area=0,
    erode_px=0,
):
    """Target mask aligned with utils/filter_background.py percentile+largest_cc selection."""
    gray = img.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    gray_np = gray[0, 0].detach().cpu().numpy().astype(np.float32)
    mask_np = build_filter_background_target_mask(
        gray_np,
        percentile=float(percentile),
        min_target_ratio=float(min_target_ratio),
        method="percentile",
        blur_sigma=float(blur_sigma),
        open_iter=int(open_iter),
        close_iter=int(close_iter),
        morph_kernel=int(morph_kernel),
        largest_cc=bool(largest_cc),
        min_cc_area=int(min_cc_area),
        erode_px=int(erode_px),
    )
    mask = torch.from_numpy((mask_np > 0.5).astype(np.float32)).to(img.device)
    return mask[None, None].clamp(0.0, 1.0)


def dilate_mask(mask, pixels=0):
    """Binary 3x3 dilation repeated by pixel count."""
    pixels = int(pixels)
    out = mask.float().clamp(0.0, 1.0)
    for _ in range(max(0, pixels)):
        out = torch.nn.functional.max_pool2d(out, kernel_size=3, stride=1, padding=1)
    return out.clamp(0.0, 1.0)


def build_shadow_mask_near_target(
    render_img,
    gt_img,
    target_mask,
    source="union",
    search_dilate=45,
    target_exclude_dilate=1,
    dark_threshold=0.18,
    dark_quantile=0.15,
    dilate=0,
):
    """Build a dark-shadow mask around the target, optionally using render/GT union."""
    target_mask = target_mask.float().clamp(0.0, 1.0)
    search = dilate_mask(target_mask, search_dilate)
    exclude = dilate_mask(target_mask, target_exclude_dilate)
    search = (search * (1.0 - exclude)).clamp(0.0, 1.0)

    def _dark_mask(img):
        gray = img.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
        valid = search > 0.5
        if valid.sum().item() <= 0:
            return torch.zeros_like(search)
        q = torch.quantile(gray[valid], float(dark_quantile)).item()
        threshold = min(float(dark_threshold), float(q))
        return ((gray <= threshold).float() * search).clamp(0.0, 1.0)

    gt_shadow = _dark_mask(gt_img)
    render_shadow = _dark_mask(render_img)
    if source == "gt":
        shadow = gt_shadow
    elif source == "render":
        shadow = render_shadow
    elif source == "intersection":
        shadow = gt_shadow * render_shadow
    else:
        shadow = torch.maximum(gt_shadow, render_shadow)

    shadow = dilate_mask(shadow, dilate)
    return shadow.clamp(0.0, 1.0), gt_shadow.clamp(0.0, 1.0), render_shadow.clamp(0.0, 1.0)


def calculate_lpips(img1, img2, net_type='vgg'):
    """
    计算学习感知图像块相似度（LPIPS）
    
    Args:
        img1, img2: (1, C, H, W)格式的tensor，值范围[0, 1]
        net_type: 网络类型（'vgg'、'alex'或'squeeze'）
    
    Returns:
        lpips_value: 标量值（值越小越好）
    """
    if not LPIPS_AVAILABLE:
        return None
    
    # LPIPS需要值范围在[-1, 1]，所以需要转换
    img1_lpips = img1 * 2.0 - 1.0
    img2_lpips = img2 * 2.0 - 1.0
    
    # 调用LPIPS函数
    from lpipsPyTorch import lpips as lpips_fn
    lpips_value = lpips_fn(img1_lpips, img2_lpips, net_type=net_type)
    
    # LPIPS返回的是tensor，需要提取标量值
    if isinstance(lpips_value, torch.Tensor):
        return lpips_value.item()
    else:
        return float(lpips_value)


def calculate_sar_metrics(img1, img2):
    """
    计算SAR图像特定指标
    
    Args:
        img1, img2: (1, C, H, W)格式的tensor
    
    Returns:
        metrics_dict: 包含SAR特定指标的字典
    """
    metrics = {}
    
    # 转换为灰度图
    img1_gray = torch.mean(img1, dim=1, keepdim=True)  # (1, 1, H, W)
    img2_gray = torch.mean(img2, dim=1, keepdim=True)
    
    # 1. 对比度相似度
    def local_contrast(img):
        """计算局部对比度"""
        kernel = torch.tensor([[[[-1, -1, -1], 
                                  [-1, 8, -1], 
                                  [-1, -1, -1]]]], 
                              dtype=torch.float32, device=img.device)
        return torch.nn.functional.conv2d(img, kernel, padding=1).abs().mean()
    
    contrast1 = local_contrast(img1_gray)
    contrast2 = local_contrast(img2_gray)
    contrast_similarity = 1.0 - torch.abs(contrast1 - contrast2) / (contrast2 + 1e-8)
    metrics['contrast_similarity'] = contrast_similarity.item()
    
    # 2. 强度分布相似度（直方图相关性）
    img1_np = img1_gray.squeeze().cpu().numpy()
    img2_np = img2_gray.squeeze().cpu().numpy()
    
    # 计算直方图
    hist1, _ = np.histogram(img1_np.flatten(), bins=256, range=(0, 1))
    hist2, _ = np.histogram(img2_np.flatten(), bins=256, range=(0, 1))
    
    # 归一化
    hist1 = hist1 / (hist1.sum() + 1e-8)
    hist2 = hist2 / (hist2.sum() + 1e-8)
    
    # 计算相关性
    hist_correlation = np.corrcoef(hist1, hist2)[0, 1]
    metrics['histogram_correlation'] = hist_correlation if not np.isnan(hist_correlation) else 0.0
    
    # 3. 边缘保持度（使用Sobel算子）
    def sobel_edge(img):
        """使用Sobel算子检测边缘"""
        sobel_x = torch.tensor([[[[-1, 0, 1], 
                                   [-2, 0, 2], 
                                   [-1, 0, 1]]]], 
                              dtype=torch.float32, device=img.device)
        sobel_y = torch.tensor([[[[-1, -2, -1], 
                                   [0, 0, 0], 
                                   [1, 2, 1]]]], 
                              dtype=torch.float32, device=img.device)
        edge_x = torch.nn.functional.conv2d(img, sobel_x, padding=1)
        edge_y = torch.nn.functional.conv2d(img, sobel_y, padding=1)
        edge_magnitude = torch.sqrt(edge_x**2 + edge_y**2)
        return edge_magnitude
    
    edge1 = sobel_edge(img1_gray)
    edge2 = sobel_edge(img2_gray)
    edge_similarity = 1.0 - torch.abs(edge1 - edge2).mean() / (edge2.mean() + 1e-8)
    metrics['edge_similarity'] = edge_similarity.item()
    
    return metrics


def compare_images(
    render_path,
    gt_path,
    device="cuda",
    calculate_sar=False,
    align_images=False,
    diagnose=False,
    output_dir=None,
    target_only=False,
    target_shadow=False,
    target_percentile=85.0,
    ssim_mode="sar_intensity",
    sar_ssim_log_scale=20.0,
    sar_ssim_smooth_radius=1,
    sar_ssim_tolerant_radius=1,
    sar_ssim_intensity_tolerance=0.03,
    sar_metric_log_scale=20.0,
    sar_metric_smooth_radius=0,
    sar_tolerant_radius=1,
    target_mask_path=None,
    target_mask_mode="filter_background",
    target_mask_threshold=0.08,
    target_mask_quantile=0.35,
    target_mask_dilate=0,
    target_mask_filter_percentile=95.0,
    target_mask_filter_min_target_ratio=0.002,
    target_mask_filter_blur_sigma=1.0,
    target_mask_filter_open_iter=0,
    target_mask_filter_close_iter=0,
    target_mask_filter_morph_kernel=5,
    target_mask_filter_largest_cc=True,
    target_mask_filter_min_cc_area=0,
    target_mask_filter_erode_px=0,
    azimuth_match_tolerance=0,
    shadow_mask_source="union",
    shadow_search_dilate=45,
    shadow_target_exclude_dilate=1,
    shadow_dark_threshold=0.18,
    shadow_dark_quantile=0.15,
    shadow_mask_dilate=0,
    visual_diagnosis=True,
    visual_diagnosis_max_panels=12,
    visual_diagnosis_angles="225,220,230,325,330,345,355",
    diagnosis_extra_threshold=0.18,
    diagnosis_dark_threshold=0.26,
    agent_diagnosis=True,
):
    """
    对比两张图像
    
    Args:
        render_path: 渲染结果图像路径
        gt_path: 原始图像路径
        device: 设备
        calculate_sar: 是否计算SAR特定指标
        align_images: 是否对齐图像（归一化亮度和对比度）
        diagnose: 是否进行诊断分析
        output_dir: 输出目录（用于保存诊断结果）
    
    Returns:
        metrics_dict: 包含所有指标的字典
    """
    render_path = normalize_cli_path(render_path)
    gt_path = normalize_cli_path(gt_path)
    if output_dir is not None:
        output_dir = normalize_cli_path(output_dir)
    # 加载图像
    render_img, device = load_image(render_path, device)
    gt_img, _ = load_image(gt_path, device)
    
    # 确保图像尺寸一致
    if render_img.shape != gt_img.shape:
        print(f"⚠️ 警告: 图像尺寸不一致，调整渲染图像尺寸")
        render_img = tf.resize(render_img, size=(gt_img.shape[2], gt_img.shape[3]))
    
    # 🔧 新增：诊断模式
    if diagnose:
        print("\n" + "=" * 80)
        print("【图像差异诊断】")
        print("=" * 80)
        
        # 转换为numpy进行诊断
        render_np = render_img[0].cpu().numpy().transpose(1, 2, 0)  # (H, W, C)
        gt_np = gt_img[0].cpu().numpy().transpose(1, 2, 0)
        
        # 转换为灰度
        render_gray = np.mean(render_np, axis=2) if render_np.shape[2] == 3 else render_np[:, :, 0]
        gt_gray = np.mean(gt_np, axis=2) if gt_np.shape[2] == 3 else gt_np[:, :, 0]
        
        # 统计分析
        render_mean = render_gray.mean()
        gt_mean = gt_gray.mean()
        render_std = render_gray.std()
        gt_std = gt_gray.std()
        mean_diff = render_mean - gt_mean
        contrast_diff = render_std - gt_std
        
        print(f"渲染图像统计:")
        print(f"  均值: {render_mean:.6f}, 标准差: {render_std:.6f}")
        print(f"  值范围: [{render_gray.min():.6f}, {render_gray.max():.6f}]")
        print(f"\n原始图像统计:")
        print(f"  均值: {gt_mean:.6f}, 标准差: {gt_std:.6f}")
        print(f"  值范围: [{gt_gray.min():.6f}, {gt_gray.max():.6f}]")
        print(f"\n差异分析:")
        print(f"  均值差异: {mean_diff:.6f} ({mean_diff*100:.2f}%)")
        print(f"  对比度差异: {contrast_diff:.6f} ({contrast_diff*100:.2f}%)")
        
        if abs(mean_diff) > 0.05:
            print(f"  ⚠️ 发现系统性亮度偏移！这可能是导致指标差的主要原因")
        if abs(contrast_diff) > 0.05:
            print(f"  ⚠️ 发现对比度差异！这可能导致SSIM较低")
        
        # 计算直方图相关性
        hist_render, _ = np.histogram(render_gray.flatten(), bins=256, range=(0, 1))
        hist_gt, _ = np.histogram(gt_gray.flatten(), bins=256, range=(0, 1))
        hist_render = hist_render / (hist_render.sum() + 1e-8)
        hist_gt = hist_gt / (hist_gt.sum() + 1e-8)
        hist_corr = np.corrcoef(hist_render, hist_gt)[0, 1]
        print(f"  直方图相关性: {hist_corr:.4f}")
        
        print("=" * 80 + "\n")
    
    # 🔧 新增：图像对齐（如果启用）
    if align_images:
        print("ℹ️  对齐图像（归一化亮度和对比度）...")
        # 转换为numpy进行对齐
        render_np = render_img[0].cpu().numpy()  # (C, H, W)
        gt_np = gt_img[0].cpu().numpy()
        
        # 对每个通道进行均值-标准差对齐
        aligned_channels = []
        for c in range(render_np.shape[0]):
            render_ch = render_np[c]
            gt_ch = gt_np[c]
            
            render_mean = render_ch.mean()
            render_std = render_ch.std()
            gt_mean = gt_ch.mean()
            gt_std = gt_ch.std()
            
            # 对齐：保持结构，调整亮度和对比度
            aligned_ch = (render_ch - render_mean) / (render_std + 1e-8) * gt_std + gt_mean
            aligned_ch = np.clip(aligned_ch, 0, 1)
            aligned_channels.append(aligned_ch)
        
        aligned_render = np.stack(aligned_channels, axis=0)
        render_img = torch.from_numpy(aligned_render).unsqueeze(0).to(device)
        
        print(f"  对齐前: 均值={render_np.mean():.4f}, 标准差={render_np.std():.4f}")
        print(f"  对齐后: 均值={aligned_render.mean():.4f}, 标准差={aligned_render.std():.4f}")
        print(f"  目标值: 均值={gt_np.mean():.4f}, 标准差={gt_np.std():.4f}\n")
    
    # 计算基础指标
    metrics = {
        'image_name': os.path.basename(render_path),
        'render_path': render_path,
        'gt_path': gt_path,
        'image_size': f"{gt_img.shape[2]}x{gt_img.shape[3]}",
        'ssim_mode': ssim_mode,
        'sar_ssim_log_scale': float(sar_ssim_log_scale),
        'sar_ssim_smooth_radius': int(sar_ssim_smooth_radius),
        'sar_ssim_tolerant_radius': int(sar_ssim_tolerant_radius),
        'sar_ssim_intensity_tolerance': float(sar_ssim_intensity_tolerance),
        'sar_metric_log_scale': float(sar_metric_log_scale),
        'sar_metric_smooth_radius': int(sar_metric_smooth_radius),
        'sar_tolerant_radius': int(sar_tolerant_radius),
    }

    if target_only or target_shadow:
        metrics['eval_mode'] = 'target_shadow' if target_shadow else 'target_only'
        metrics['target_percentile'] = float(target_percentile)
        if target_mask_path:
            mask_img, _ = load_image(target_mask_path, device)
            if mask_img.shape[-2:] != gt_img.shape[-2:]:
                mask_img = tf.resize(mask_img, size=(gt_img.shape[2], gt_img.shape[3]))
            target_mask = build_target_mask_from_reference(
                mask_img,
                threshold=target_mask_threshold,
                quantile=target_mask_quantile,
                dilate=target_mask_dilate,
            )
            metrics['target_mask_source'] = str(target_mask_path)
            metrics['target_mask_threshold'] = float(target_mask_threshold)
            metrics['target_mask_quantile'] = float(target_mask_quantile)
            metrics['target_mask_dilate'] = int(target_mask_dilate)
        elif str(target_mask_mode).lower().strip() == "filter_background":
            target_mask = build_target_mask_filter_background(
                gt_img,
                percentile=target_mask_filter_percentile,
                min_target_ratio=target_mask_filter_min_target_ratio,
                blur_sigma=target_mask_filter_blur_sigma,
                open_iter=target_mask_filter_open_iter,
                close_iter=target_mask_filter_close_iter,
                morph_kernel=target_mask_filter_morph_kernel,
                largest_cc=target_mask_filter_largest_cc,
                min_cc_area=target_mask_filter_min_cc_area,
                erode_px=target_mask_filter_erode_px,
            )
            metrics['target_mask_source'] = 'filter_background_gt'
            metrics['target_mask_mode'] = 'filter_background'
            metrics['target_mask_filter_percentile'] = float(target_mask_filter_percentile)
            metrics['target_mask_filter_min_target_ratio'] = float(target_mask_filter_min_target_ratio)
            metrics['target_mask_filter_blur_sigma'] = float(target_mask_filter_blur_sigma)
            metrics['target_mask_filter_open_iter'] = int(target_mask_filter_open_iter)
            metrics['target_mask_filter_close_iter'] = int(target_mask_filter_close_iter)
            metrics['target_mask_filter_morph_kernel'] = int(target_mask_filter_morph_kernel)
            metrics['target_mask_filter_largest_cc'] = bool(target_mask_filter_largest_cc)
            metrics['target_mask_filter_min_cc_area'] = int(target_mask_filter_min_cc_area)
            metrics['target_mask_filter_erode_px'] = int(target_mask_filter_erode_px)
        else:
            target_mask = build_target_mask_from_gt(gt_img, target_percentile=target_percentile)
            metrics['target_mask_source'] = 'gt_percentile'
            metrics['target_mask_mode'] = 'gt_percentile'
        metrics['target_mask_ratio'] = float(target_mask.mean().item())

        if target_shadow:
            shadow_mask, gt_shadow_mask, render_shadow_mask = build_shadow_mask_near_target(
                render_img,
                gt_img,
                target_mask,
                source=shadow_mask_source,
                search_dilate=shadow_search_dilate,
                target_exclude_dilate=shadow_target_exclude_dilate,
                dark_threshold=shadow_dark_threshold,
                dark_quantile=shadow_dark_quantile,
                dilate=shadow_mask_dilate,
            )
            mask = torch.maximum(target_mask, shadow_mask).clamp(0.0, 1.0)
            metrics['shadow_mask_source'] = str(shadow_mask_source)
            metrics['shadow_search_dilate'] = int(shadow_search_dilate)
            metrics['shadow_target_exclude_dilate'] = int(shadow_target_exclude_dilate)
            metrics['shadow_dark_threshold'] = float(shadow_dark_threshold)
            metrics['shadow_dark_quantile'] = float(shadow_dark_quantile)
            metrics['shadow_mask_dilate'] = int(shadow_mask_dilate)
            metrics['shadow_mask_ratio'] = float(shadow_mask.mean().item())
            metrics['shadow_mask_ratio_gt'] = float(gt_shadow_mask.mean().item())
            metrics['shadow_mask_ratio_render'] = float(render_shadow_mask.mean().item())
            metrics['target_shadow_mask_ratio'] = float(mask.mean().item())
        else:
            mask = target_mask

        metrics['MSE_full'] = calculate_mse(render_img, gt_img)
        metrics['MAE_full'] = calculate_mae(render_img, gt_img)
        metrics['PSNR_full'] = calculate_psnr(render_img, gt_img)
        add_prefixed_metrics(
            metrics,
            calculate_sar_error_metrics(
                render_img,
                gt_img,
                mask=None,
                log_scale=sar_metric_log_scale,
                smooth_radius=sar_metric_smooth_radius,
                tolerant_radius=sar_tolerant_radius,
            ),
            suffix="_full",
        )
        metrics['SSIM_pixel_full_strict'] = calculate_ssim(render_img, gt_img)
        metrics['SSIM_pixel_full'] = calculate_sar_intensity_ssim(
            render_img,
            gt_img,
            log_scale=1.0,
            smooth_radius=0,
            tolerant_radius=sar_ssim_tolerant_radius,
            intensity_tolerance=sar_ssim_intensity_tolerance,
        )
        metrics['SAR_SSIM_full_strict'] = calculate_sar_intensity_ssim(
            render_img,
            gt_img,
            log_scale=sar_ssim_log_scale,
            smooth_radius=sar_ssim_smooth_radius,
        )
        metrics['SAR_SSIM_full'] = calculate_sar_intensity_ssim(
            render_img,
            gt_img,
            log_scale=sar_ssim_log_scale,
            smooth_radius=sar_ssim_smooth_radius,
            tolerant_radius=sar_ssim_tolerant_radius,
            intensity_tolerance=sar_ssim_intensity_tolerance,
        )
        metrics['SSIM_full'] = metrics['SAR_SSIM_full'] if ssim_mode == "sar_intensity" else metrics['SSIM_pixel_full']
        if LPIPS_AVAILABLE:
            metrics['LPIPS_full'] = calculate_lpips(render_img, gt_img)
        else:
            metrics['LPIPS_full'] = None

        metrics['MSE_pixel'] = masked_mse(render_img, gt_img, mask)
        metrics['MAE_pixel'] = masked_mae(render_img, gt_img, mask)
        metrics['PSNR_pixel'] = masked_psnr_from_mse(metrics['MSE_pixel'])
        add_prefixed_metrics(
            metrics,
            calculate_sar_error_metrics(
                render_img,
                gt_img,
                mask=mask,
                log_scale=sar_metric_log_scale,
                smooth_radius=sar_metric_smooth_radius,
                tolerant_radius=sar_tolerant_radius,
            ),
        )
        metrics['MSE'] = metrics['SAR_MSE']
        metrics['MAE'] = metrics['SAR_MAE']
        metrics['PSNR'] = metrics['SAR_PSNR']
        metrics['SSIM_pixel_strict'] = calculate_masked_ssim(render_img, gt_img, mask, sar_intensity=False)
        metrics['SSIM_pixel'] = calculate_masked_ssim(
            render_img,
            gt_img,
            mask,
            sar_intensity=False,
            tolerant_radius=sar_ssim_tolerant_radius,
            intensity_tolerance=sar_ssim_intensity_tolerance,
        )
        metrics['SAR_SSIM_strict'] = calculate_masked_ssim(
            render_img,
            gt_img,
            mask,
            sar_intensity=True,
            log_scale=sar_ssim_log_scale,
            smooth_radius=sar_ssim_smooth_radius,
        )
        metrics['SAR_SSIM'] = calculate_masked_ssim(
            render_img,
            gt_img,
            mask,
            sar_intensity=True,
            log_scale=sar_ssim_log_scale,
            smooth_radius=sar_ssim_smooth_radius,
            tolerant_radius=sar_ssim_tolerant_radius,
            intensity_tolerance=sar_ssim_intensity_tolerance,
        )
        metrics['SSIM'] = metrics['SAR_SSIM'] if ssim_mode == "sar_intensity" else metrics['SSIM_pixel']

        bbox = mask_bbox_with_margin(mask)
        if bbox is not None:
            cr = ensure_min_size(crop_tensor_11hw(render_img, bbox))
            cg = ensure_min_size(crop_tensor_11hw(gt_img, bbox))
            metrics['SSIM_pixel_crop_strict'] = calculate_ssim(cr, cg)
            metrics['SSIM_pixel_crop'] = calculate_sar_intensity_ssim(
                cr,
                cg,
                log_scale=1.0,
                smooth_radius=0,
                tolerant_radius=sar_ssim_tolerant_radius,
                intensity_tolerance=sar_ssim_intensity_tolerance,
            )
            metrics['SAR_SSIM_crop_strict'] = calculate_sar_intensity_ssim(
                cr,
                cg,
                log_scale=sar_ssim_log_scale,
                smooth_radius=sar_ssim_smooth_radius,
            )
            metrics['SAR_SSIM_crop'] = calculate_sar_intensity_ssim(
                cr,
                cg,
                log_scale=sar_ssim_log_scale,
                smooth_radius=sar_ssim_smooth_radius,
                tolerant_radius=sar_ssim_tolerant_radius,
                intensity_tolerance=sar_ssim_intensity_tolerance,
            )
            if LPIPS_AVAILABLE:
                metrics['LPIPS'] = calculate_lpips(cr, cg)
            else:
                metrics['LPIPS'] = None
            if calculate_sar:
                sar_metrics = calculate_sar_metrics(cr, cg)
                for sk, sv in sar_metrics.items():
                    metrics[f'{sk}_target'] = sv
        else:
            metrics['SSIM'] = float('nan')
            metrics['SSIM_pixel'] = float('nan')
            metrics['SSIM_pixel_strict'] = float('nan')
            metrics['SAR_SSIM'] = float('nan')
            metrics['SAR_SSIM_strict'] = float('nan')
            metrics['SSIM_pixel_crop'] = float('nan')
            metrics['SSIM_pixel_crop_strict'] = float('nan')
            metrics['SAR_SSIM_crop'] = float('nan')
            metrics['SAR_SSIM_crop_strict'] = float('nan')
            metrics['LPIPS'] = None if not LPIPS_AVAILABLE else float('nan')
            if calculate_sar:
                sar_metrics = calculate_sar_metrics(render_img, gt_img)
                for sk, sv in sar_metrics.items():
                    metrics[f'{sk}_target'] = sv
    else:
        metrics['eval_mode'] = 'full_image'
        metrics['MSE'] = calculate_mse(render_img, gt_img)
        metrics['MAE'] = calculate_mae(render_img, gt_img)
        metrics['PSNR'] = calculate_psnr(render_img, gt_img)
        add_prefixed_metrics(
            metrics,
            calculate_sar_error_metrics(
                render_img,
                gt_img,
                mask=None,
                log_scale=sar_metric_log_scale,
                smooth_radius=sar_metric_smooth_radius,
                tolerant_radius=sar_tolerant_radius,
            ),
        )
        metrics['SSIM_pixel_strict'] = calculate_ssim(render_img, gt_img)
        metrics['SSIM_pixel'] = calculate_sar_intensity_ssim(
            render_img,
            gt_img,
            log_scale=1.0,
            smooth_radius=0,
            tolerant_radius=sar_ssim_tolerant_radius,
            intensity_tolerance=sar_ssim_intensity_tolerance,
        )
        metrics['SAR_SSIM_strict'] = calculate_sar_intensity_ssim(
            render_img,
            gt_img,
            log_scale=sar_ssim_log_scale,
            smooth_radius=sar_ssim_smooth_radius,
        )
        metrics['SAR_SSIM'] = calculate_sar_intensity_ssim(
            render_img,
            gt_img,
            log_scale=sar_ssim_log_scale,
            smooth_radius=sar_ssim_smooth_radius,
            tolerant_radius=sar_ssim_tolerant_radius,
            intensity_tolerance=sar_ssim_intensity_tolerance,
        )
        metrics['SSIM'] = metrics['SAR_SSIM'] if ssim_mode == "sar_intensity" else metrics['SSIM_pixel']
        if LPIPS_AVAILABLE:
            metrics['LPIPS'] = calculate_lpips(render_img, gt_img)
        else:
            metrics['LPIPS'] = None
        if calculate_sar:
            sar_metrics = calculate_sar_metrics(render_img, gt_img)
            metrics.update(sar_metrics)

    return metrics


def _load_gray_np_for_visual(path, size_hw=None):
    """Load an image as a float32 grayscale array in [0, 1]."""
    img = Image.open(path).convert("RGB")
    if size_hw is not None:
        h, w = size_hw
        if img.size != (w, h):
            img = img.resize((w, h), Image.BILINEAR)
    arr = np.asarray(img, dtype=np.float32) / 255.0
    return arr.mean(axis=2).clip(0.0, 1.0)


def _log_sar_np(gray, log_scale=20.0):
    log_scale = max(float(log_scale), 1e-6)
    gray = np.asarray(gray, dtype=np.float32).clip(0.0, 1.0)
    return (np.log1p(log_scale * gray) / math.log1p(log_scale)).clip(0.0, 1.0)


def _normalize01_np(arr, robust=True):
    arr = np.asarray(arr, dtype=np.float32)
    if robust:
        lo, hi = np.percentile(arr, [1.0, 99.0])
    else:
        lo, hi = float(np.nanmin(arr)), float(np.nanmax(arr))
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        return np.zeros_like(arr, dtype=np.float32)
    return ((arr - lo) / (hi - lo)).clip(0.0, 1.0)


def _np_dilate_bool(mask, pixels=1):
    pixels = int(pixels)
    mask_u8 = np.asarray(mask, dtype=np.uint8)
    if pixels <= 0:
        return mask_u8.astype(bool)
    kernel = np.ones((3, 3), dtype=np.uint8)
    return cv2.dilate(mask_u8, kernel, iterations=pixels).astype(bool)


def _np_erode_bool(mask, pixels=1):
    pixels = int(pixels)
    mask_u8 = np.asarray(mask, dtype=np.uint8)
    if pixels <= 0:
        return mask_u8.astype(bool)
    kernel = np.ones((3, 3), dtype=np.uint8)
    return cv2.erode(mask_u8, kernel, iterations=pixels).astype(bool)


def _mask_bbox_np(mask, margin=18, shape_hw=None):
    ys, xs = np.where(np.asarray(mask, dtype=bool))
    if len(xs) == 0:
        return None
    if shape_hw is None:
        shape_hw = mask.shape[:2]
    h, w = shape_hw
    y0 = max(0, int(ys.min()) - int(margin))
    y1 = min(h, int(ys.max()) + int(margin) + 1)
    x0 = max(0, int(xs.min()) - int(margin))
    x1 = min(w, int(xs.max()) + int(margin) + 1)
    return y0, y1, x0, x1


def _global_ssim_np(a, b, mask=None, window_size=11):
    """Small dependency-free SSIM for grayscale numpy arrays."""
    a = np.asarray(a, dtype=np.float32)
    b = np.asarray(b, dtype=np.float32)
    k = max(3, int(window_size))
    if k % 2 == 0:
        k += 1
    mu_a = cv2.blur(a, (k, k), borderType=cv2.BORDER_REFLECT)
    mu_b = cv2.blur(b, (k, k), borderType=cv2.BORDER_REFLECT)
    mu_a2 = mu_a * mu_a
    mu_b2 = mu_b * mu_b
    mu_ab = mu_a * mu_b
    var_a = cv2.blur(a * a, (k, k), borderType=cv2.BORDER_REFLECT) - mu_a2
    var_b = cv2.blur(b * b, (k, k), borderType=cv2.BORDER_REFLECT) - mu_b2
    cov = cv2.blur(a * b, (k, k), borderType=cv2.BORDER_REFLECT) - mu_ab
    c1 = 0.01 ** 2
    c2 = 0.03 ** 2
    ssim_map = ((2.0 * mu_ab + c1) * (2.0 * cov + c2)) / (
        ((mu_a2 + mu_b2 + c1) * (var_a + var_b + c2)).clip(min=1e-8)
    )
    if mask is None:
        return float(np.nanmean(ssim_map))
    m = np.asarray(mask, dtype=np.float32)
    denom = float(m.sum())
    if denom <= 0.0:
        return float("nan")
    return float((ssim_map * m).sum() / denom)


def _gray_rgb_u8(gray):
    g = (_normalize01_np(gray, robust=False) * 255.0).astype(np.uint8)
    return np.repeat(g[:, :, None], 3, axis=2)


def _abs_heatmap_rgb(abs_diff):
    v = (_normalize01_np(abs_diff, robust=True) * 255.0).astype(np.uint8)
    return cv2.applyColorMap(v, cv2.COLORMAP_INFERNO)[:, :, ::-1]


def _signed_diff_rgb(diff, scale=0.35):
    diff = np.asarray(diff, dtype=np.float32)
    mag = np.clip(np.abs(diff) / max(float(scale), 1e-6), 0.0, 1.0)
    rgb = np.zeros((*diff.shape, 3), dtype=np.float32)
    pos = diff > 0
    neg = diff < 0
    rgb[pos, 0] = mag[pos]
    rgb[pos, 1] = 0.15 * mag[pos]
    rgb[neg, 1] = 0.65 * mag[neg]
    rgb[neg, 2] = mag[neg]
    return (rgb * 255.0).astype(np.uint8)


def _overlay_diagnosis_rgb(gt_log, extra_bright, missing_bright, gt_dark, dark_leak, target_mask):
    rgb = _gray_rgb_u8(gt_log).astype(np.float32)
    rgb[target_mask] = 0.55 * rgb[target_mask] + np.array([40.0, 80.0, 40.0], dtype=np.float32)
    rgb[gt_dark] = 0.35 * rgb[gt_dark] + np.array([255.0, 235.0, 0.0], dtype=np.float32)
    rgb[extra_bright] = 0.25 * rgb[extra_bright] + np.array([255.0, 30.0, 30.0], dtype=np.float32)
    rgb[missing_bright] = 0.25 * rgb[missing_bright] + np.array([0.0, 220.0, 255.0], dtype=np.float32)
    rgb[dark_leak] = 0.20 * rgb[dark_leak] + np.array([255.0, 0.0, 255.0], dtype=np.float32)
    return rgb.clip(0, 255).astype(np.uint8)


def _target_mask_np_for_visual(metrics, gt_log, render_log, target_mask_threshold=0.08, target_mask_quantile=0.35, target_mask_dilate=0):
    """Prefer the clean target reference mask saved in per-image metrics."""
    h, w = gt_log.shape
    if str(metrics.get("target_mask_mode", "")).lower().strip() == "filter_background":
        mask = build_filter_background_target_mask(
            np.asarray(gt_log, dtype=np.float32),
            percentile=float(metrics.get("target_mask_filter_percentile", 95.0)),
            min_target_ratio=float(metrics.get("target_mask_filter_min_target_ratio", 0.002)),
            method="percentile",
            blur_sigma=float(metrics.get("target_mask_filter_blur_sigma", 1.0)),
            open_iter=int(metrics.get("target_mask_filter_open_iter", 0)),
            close_iter=int(metrics.get("target_mask_filter_close_iter", 0)),
            morph_kernel=int(metrics.get("target_mask_filter_morph_kernel", 5)),
            largest_cc=bool(metrics.get("target_mask_filter_largest_cc", True)),
            min_cc_area=int(metrics.get("target_mask_filter_min_cc_area", 0)),
            erode_px=int(metrics.get("target_mask_filter_erode_px", 0)),
        )
        return _np_dilate_bool(mask > 0.5, target_mask_dilate), "filter_background_gt"
    source = metrics.get("target_mask_source")
    if source and source != "gt_percentile":
        p = Path(normalize_cli_path(source))
        if p.is_file():
            ref = _load_gray_np_for_visual(p, size_hw=(h, w))
            q = float(np.quantile(ref, float(target_mask_quantile)))
            th = max(float(target_mask_threshold), q)
            mask = ref >= th
            return _np_dilate_bool(mask, target_mask_dilate), str(p)

    # Fallback: use the bright support union so the diagnostic remains useful
    # even when target-only masks were not supplied.
    gt_th = float(np.percentile(gt_log, 85.0))
    render_th = float(np.percentile(render_log, 85.0))
    mask = (gt_log >= gt_th) | (render_log >= render_th)
    mask = _np_dilate_bool(mask, 3)
    return mask, "fallback_gt_render_percentile"


def _make_visual_diagnosis_panel(title, render_log, gt_log, mask, metrics, extra, missing, gt_dark, dark_leak, out_path):
    bbox = _mask_bbox_np(mask, margin=24, shape_hw=gt_log.shape)
    if bbox is not None:
        y0, y1, x0, x1 = bbox
        render_log = render_log[y0:y1, x0:x1]
        gt_log = gt_log[y0:y1, x0:x1]
        mask = mask[y0:y1, x0:x1]
        extra = extra[y0:y1, x0:x1]
        missing = missing[y0:y1, x0:x1]
        gt_dark = gt_dark[y0:y1, x0:x1]
        dark_leak = dark_leak[y0:y1, x0:x1]

    diff = render_log - gt_log
    panels = [
        ("render log", _gray_rgb_u8(render_log)),
        ("GT log", _gray_rgb_u8(gt_log)),
        ("abs error", _abs_heatmap_rgb(np.abs(diff))),
        ("signed: red bright, cyan dark", _signed_diff_rgb(diff)),
        ("mask / GT dark / errors", _overlay_diagnosis_rgb(gt_log, extra, missing, gt_dark, dark_leak, mask)),
        (
            "legend",
            _legend_panel(
                render_log.shape,
                [
                    ("red", "render too bright"),
                    ("cyan", "missing GT bright"),
                    ("yellow", "GT dark target"),
                    ("magenta", "dark leak"),
                ],
                metrics,
            ),
        ),
    ]

    cell_h, cell_w = render_log.shape
    title_h = 24
    scale = max(1, int(math.ceil(220.0 / max(cell_h, cell_w))))
    scaled_w = cell_w * scale
    scaled_h = cell_h * scale
    canvas = Image.new("RGB", (scaled_w * 3, (scaled_h + title_h) * 2 + 34), (18, 18, 18))
    draw = ImageDraw.Draw(canvas)
    draw.text((8, 6), title, fill=(245, 245, 245))
    y_base = 34
    for idx, (label, arr) in enumerate(panels):
        r = idx // 3
        c = idx % 3
        x = c * scaled_w
        y = y_base + r * (scaled_h + title_h)
        draw.text((x + 6, y), label, fill=(235, 235, 235))
        im = Image.fromarray(arr).resize((scaled_w, scaled_h), Image.NEAREST)
        canvas.paste(im, (x, y + title_h))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(out_path)


def _legend_panel(shape_hw, labels, metrics):
    h, w = shape_hw
    img = Image.new("RGB", (w, h), (28, 28, 28))
    draw = ImageDraw.Draw(img)
    colors = {
        "red": (255, 30, 30),
        "cyan": (0, 220, 255),
        "yellow": (255, 235, 0),
        "magenta": (255, 0, 255),
    }
    y = 8
    for color_name, text in labels:
        draw.rectangle((8, y, 24, y + 12), fill=colors[color_name])
        draw.text((32, y - 1), text, fill=(235, 235, 235))
        y += 20
    y += 4
    summary_lines = [
        f"SSIM_target {metrics.get('diagnosis_ssim_target_global', float('nan')):.3f}",
        f"edge MAE {metrics.get('diagnosis_mae_edge_log', float('nan')):.3f}",
        f"missing bright {metrics.get('diagnosis_missing_bright_ratio', float('nan')):.3f}",
        f"dark leak {metrics.get('diagnosis_dark_region_leak_ratio', float('nan')):.3f}",
    ]
    for line in summary_lines:
        draw.text((8, y), line, fill=(235, 235, 235))
        y += 18
    return np.asarray(img, dtype=np.uint8)


def _select_visual_diagnosis_items(items, max_panels=12, angles_text="225,220,230,325,330,345,355"):
    by_name = {m.get("image_name"): m for m in items}
    selected = []
    seen = set()

    def add(m):
        name = m.get("image_name")
        if name and name not in seen:
            selected.append(m)
            seen.add(name)

    for m in sorted(items, key=lambda x: float(x.get("diagnosis_ssim_target_global", 1e9))):
        add(m)
        if len(selected) >= max(1, int(max_panels)) // 2:
            break

    requested = parse_angle_list(angles_text) or set()
    for angle in sorted(requested):
        candidates = [
            m for m in items
            if m.get("azimuth") is not None and int(m.get("azimuth")) % 360 == int(angle) % 360
        ]
        if candidates:
            add(candidates[0])

    for m in sorted(items, key=lambda x: float(x.get("diagnosis_ssim_target_global", -1.0)), reverse=True):
        add(m)
        if len(selected) >= int(max_panels):
            break
    return selected[: int(max_panels)]


def generate_visual_diagnosis(
    all_metrics,
    output_dir,
    max_panels=12,
    angles="225,220,230,325,330,345,355",
    log_scale=20.0,
    target_mask_threshold=0.08,
    target_mask_quantile=0.35,
    target_mask_dilate=0,
    extra_threshold=0.18,
    dark_threshold=0.26,
):
    """Create SAR-focused visual comparison panels and per-image diagnosis metrics."""
    if not all_metrics or not output_dir:
        return None
    out_dir = Path(output_dir) / "visual_diagnosis"
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for metrics in tqdm(all_metrics, desc="visual diagnosis"):
        try:
            render_path = Path(normalize_cli_path(metrics["render_path"]))
            gt_path = Path(normalize_cli_path(metrics["gt_path"]))
            render_gray = _load_gray_np_for_visual(render_path)
            gt_gray = _load_gray_np_for_visual(gt_path, size_hw=render_gray.shape)
            render_log = _log_sar_np(render_gray, log_scale=log_scale)
            gt_log = _log_sar_np(gt_gray, log_scale=log_scale)
            target_mask, mask_source = _target_mask_np_for_visual(
                metrics,
                gt_log,
                render_log,
                target_mask_threshold=target_mask_threshold,
                target_mask_quantile=target_mask_quantile,
                target_mask_dilate=target_mask_dilate,
            )

            edge = _np_dilate_bool(target_mask, 4) & ~_np_erode_bool(target_mask, 4)
            inner = target_mask & ~edge
            bg = ~_np_dilate_bool(target_mask, 24)
            diff = render_log - gt_log
            gt_bright = gt_log >= np.percentile(gt_log[target_mask], 78.0) if target_mask.any() else gt_log > 0.7
            render_bright = render_log >= np.percentile(render_log[target_mask], 78.0) if target_mask.any() else render_log > 0.7
            extra_bright = target_mask & render_bright & (diff > float(extra_threshold))
            missing_bright = target_mask & gt_bright & (diff < -float(extra_threshold))
            gt_dark = target_mask & (
                (gt_log <= float(dark_threshold))
                | ((gt_log / np.maximum(render_log, 1e-4)) <= 0.45)
            )
            dark_leak = gt_dark & (render_log > np.maximum(float(dark_threshold), gt_log + 0.08))

            bbox = _mask_bbox_np(target_mask, margin=24, shape_hw=gt_log.shape)
            if bbox is not None:
                y0, y1, x0, x1 = bbox
                crop_ssim = _global_ssim_np(render_log[y0:y1, x0:x1], gt_log[y0:y1, x0:x1])
            else:
                crop_ssim = float("nan")

            row = {
                "image_name": metrics.get("image_name"),
                "azimuth": metrics.get("azimuth"),
                "render_path": str(render_path),
                "gt_path": str(gt_path),
                "mask_source": mask_source,
                "diagnosis_ssim_target_global": _global_ssim_np(render_log, gt_log, target_mask),
                "diagnosis_ssim_crop_global": crop_ssim,
                "diagnosis_mae_target_log": float(np.abs(diff[target_mask]).mean()) if target_mask.any() else float("nan"),
                "diagnosis_mae_edge_log": float(np.abs(diff[edge]).mean()) if edge.any() else float("nan"),
                "diagnosis_mae_inner_log": float(np.abs(diff[inner]).mean()) if inner.any() else float("nan"),
                "diagnosis_mae_bg_log": float(np.abs(diff[bg]).mean()) if bg.any() else float("nan"),
                "diagnosis_extra_bright_ratio": float(extra_bright.sum() / max(float(target_mask.sum()), 1.0)),
                "diagnosis_missing_bright_ratio": float(missing_bright.sum() / max(float(target_mask.sum()), 1.0)),
                "diagnosis_gt_dark_target_ratio": float(gt_dark.sum() / max(float(target_mask.sum()), 1.0)),
                "diagnosis_dark_region_leak_ratio": float(dark_leak.sum() / max(float(gt_dark.sum()), 1.0)),
            }
            metrics.update({k: v for k, v in row.items() if k.startswith("diagnosis_")})
            rows.append((row, render_log, gt_log, target_mask, extra_bright, missing_bright, gt_dark, dark_leak))
        except Exception as exc:
            metrics["diagnosis_error"] = str(exc)
            print(f"warning: visual diagnosis failed for {metrics.get('image_name')}: {exc}")

    if not rows:
        return None

    csv_path = out_dir / "diagnosis_metrics.csv"
    csv_keys = [
        "image_name", "azimuth", "render_path", "gt_path", "mask_source",
        "diagnosis_ssim_target_global", "diagnosis_ssim_crop_global",
        "diagnosis_mae_target_log", "diagnosis_mae_edge_log", "diagnosis_mae_inner_log", "diagnosis_mae_bg_log",
        "diagnosis_extra_bright_ratio", "diagnosis_missing_bright_ratio",
        "diagnosis_gt_dark_target_ratio", "diagnosis_dark_region_leak_ratio",
    ]
    with open(csv_path, "w", encoding="utf-8") as f:
        f.write(",".join(csv_keys) + "\n")
        for row, *_ in rows:
            vals = []
            for key in csv_keys:
                val = row.get(key, "")
                vals.append('"' + str(val).replace('"', '""') + '"' if isinstance(val, str) else str(val))
            f.write(",".join(vals) + "\n")

    row_by_name = {row["image_name"]: (row, render_log, gt_log, mask, extra, missing, gt_dark, dark_leak)
                   for row, render_log, gt_log, mask, extra, missing, gt_dark, dark_leak in rows}
    selected_metrics = _select_visual_diagnosis_items([row for row, *_ in rows], max_panels=max_panels, angles_text=angles)
    panel_paths = []
    for row in selected_metrics:
        packed = row_by_name.get(row["image_name"])
        if packed is None:
            continue
        row, render_log, gt_log, mask, extra, missing, gt_dark, dark_leak = packed
        stem = Path(row["image_name"]).stem
        out_path = out_dir / f"diagnosis_{stem}.png"
        title = (
            f"{row['image_name']}  az={row.get('azimuth')}  "
            f"SSIMt={row['diagnosis_ssim_target_global']:.3f}  "
            f"darkLeak={row['diagnosis_dark_region_leak_ratio']:.3f}"
        )
        _make_visual_diagnosis_panel(title, render_log, gt_log, mask, row, extra, missing, gt_dark, dark_leak, out_path)
        panel_paths.append((row["image_name"], out_path))

    summary_path = out_dir / "diagnosis_summary.txt"
    numeric_keys = [k for k in csv_keys if k.startswith("diagnosis_")]
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("SAR visual diagnosis\n")
        f.write(f"total images: {len(rows)}\n")
        f.write(f"log_scale: {float(log_scale)}\n")
        f.write("color legend: red=render too bright, cyan=missing GT bright, yellow=GT dark target, magenta=dark-region leak\n\n")
        for key in numeric_keys:
            vals = np.array([float(row.get(key, np.nan)) for row, *_ in rows], dtype=np.float64)
            vals = vals[np.isfinite(vals)]
            if vals.size:
                f.write(
                    f"{key}: mean={vals.mean():.4f}, median={np.median(vals):.4f}, "
                    f"min={vals.min():.4f}, max={vals.max():.4f}\n"
                )
        f.write("\nmain reading:\n")
        leak_mean = np.nanmean([row["diagnosis_dark_region_leak_ratio"] for row, *_ in rows])
        miss_mean = np.nanmean([row["diagnosis_missing_bright_ratio"] for row, *_ in rows])
        bg_mean = np.nanmean([row["diagnosis_mae_bg_log"] for row, *_ in rows])
        edge_mean = np.nanmean([row["diagnosis_mae_edge_log"] for row, *_ in rows])
        inner_mean = np.nanmean([row["diagnosis_mae_inner_log"] for row, *_ in rows])
        f.write(f"- dark-region leak mean={leak_mean:.4f}: GT-dark target support still has render scattering.\n")
        f.write(f"- missing-bright mean={miss_mean:.4f}: discontinuous bright SAR scatterers are missing or shifted.\n")
        f.write(f"- edge MAE mean={edge_mean:.4f}, inner MAE mean={inner_mean:.4f}: edge/layover shape is a major error if edge is larger.\n")
        f.write(f"- background MAE mean={bg_mean:.4f}: full-image SSIM is strongly affected by background speckle statistics.\n\n")
        f.write("worst target SSIM:\n")
        for row, *_ in sorted(rows, key=lambda x: x[0]["diagnosis_ssim_target_global"])[: min(12, len(rows))]:
            f.write(
                f"{row['image_name']}: ssim={row['diagnosis_ssim_target_global']:.4f}, "
                f"edge={row['diagnosis_mae_edge_log']:.4f}, missing={row['diagnosis_missing_bright_ratio']:.4f}, "
                f"gt_dark={row['diagnosis_gt_dark_target_ratio']:.4f}, leak={row['diagnosis_dark_region_leak_ratio']:.4f}\n"
            )
        f.write("\npanels:\n")
        for name, path in panel_paths:
            f.write(f"{name}: {path}\n")

    print(f"visual diagnosis saved: {out_dir}")
    return {
        "dir": str(out_dir),
        "csv": str(csv_path),
        "summary": str(summary_path),
        "panels": [str(p) for _, p in panel_paths],
    }


def compare_directories(
    render_dir,
    gt_dir,
    output_dir=None,
    device="cuda",
    calculate_sar=False,
    debug=False,
    align_images=False,
    diagnose=False,
    target_only=False,
    target_shadow=False,
    target_percentile=85.0,
    match_by_azimuth=True,
    ssim_mode="sar_intensity",
    sar_ssim_log_scale=20.0,
    sar_ssim_smooth_radius=1,
    sar_ssim_tolerant_radius=1,
    sar_ssim_intensity_tolerance=0.03,
    sar_metric_log_scale=20.0,
    sar_metric_smooth_radius=0,
    sar_tolerant_radius=1,
    view_split_train_angles=None,
    view_split_train_angle_step=None,
    view_split_train_dir=None,
    target_mask_dir=None,
    target_mask_mode="filter_background",
    target_mask_threshold=0.08,
    target_mask_quantile=0.35,
    target_mask_dilate=0,
    target_mask_filter_percentile=95.0,
    target_mask_filter_min_target_ratio=0.002,
    target_mask_filter_blur_sigma=1.0,
    target_mask_filter_open_iter=0,
    target_mask_filter_close_iter=0,
    target_mask_filter_morph_kernel=5,
    target_mask_filter_largest_cc=True,
    target_mask_filter_min_cc_area=0,
    target_mask_filter_erode_px=0,
    azimuth_match_tolerance=0,
    shadow_mask_source="union",
    shadow_search_dilate=45,
    shadow_target_exclude_dilate=1,
    shadow_dark_threshold=0.18,
    shadow_dark_quantile=0.15,
    shadow_mask_dilate=0,
    visual_diagnosis=True,
    visual_diagnosis_max_panels=12,
    visual_diagnosis_angles="225,220,230,325,330,345,355",
    diagnosis_extra_threshold=0.18,
    diagnosis_dark_threshold=0.26,
    agent_diagnosis=True,
):
    """
    批量对比两个文件夹中的图像
    
    Args:
        render_dir: 渲染结果文件夹路径
        gt_dir: 原始图像文件夹路径
        output_dir: 输出目录（用于保存报告）
        device: 设备
        calculate_sar: 是否计算SAR特定指标
        match_by_azimuth: stem 不匹配时是否按方位角对齐（渲染含 azimuth_<数字>，
            GT 取 stem 最后一个「-」分隔的纯整数段）

    Returns:
        all_metrics: 所有图像的指标列表
        summary: 汇总统计信息
    """
    render_dir = Path(normalize_cli_path(render_dir))
    gt_dir = Path(normalize_cli_path(gt_dir))
    target_mask_dir = Path(normalize_cli_path(target_mask_dir)) if target_mask_dir else None
    train_angle_set = build_train_angle_set(
        train_angle_list=view_split_train_angles,
        train_angle_step=view_split_train_angle_step,
        train_angle_dir=view_split_train_dir,
    )
    
    def _missing_dir_hint(which: str, p: Path) -> str:
        cwd = Path.cwd()
        resolved = (cwd / p).resolve() if not p.is_absolute() else p.resolve()
        return (
            f"{which}不存在: {p}\n"
            f"  当前工作目录: {cwd}\n"
            f"  解析为绝对路径: {resolved}\n"
            f"  请确认：① 路径使用英文直引号 \"...\" 或不用引号，勿用 Word 弯引号 ‘...’；"
            f"② 已先执行 render_and_save.py 生成渲染图；③ 路径与输出目录一致。"
        )

    if not render_dir.exists():
        raise FileNotFoundError(_missing_dir_hint("渲染结果文件夹", render_dir))
    if not gt_dir.exists():
        raise FileNotFoundError(_missing_dir_hint("原始图像文件夹", gt_dir))
    
    # 获取所有图像文件
    image_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff']
    render_files = sorted([f for f in render_dir.iterdir() 
                          if f.suffix.lower() in image_extensions])
    
    if len(render_files) == 0:
        raise ValueError(f"渲染结果文件夹中没有找到图像文件: {render_dir}")
    
    print(f"找到 {len(render_files)} 张渲染图像")
    
    # 获取GT文件夹中的所有图像文件（用于智能匹配）
    gt_files = {f.name: f for f in gt_dir.iterdir() 
                if f.suffix.lower() in image_extensions}
    
    if len(gt_files) == 0:
        print(f"⚠️ 警告: 原始图像文件夹中没有找到图像文件: {gt_dir}")
        print(f"   请检查文件夹路径是否正确")

    gt_azimuth_index = {}
    gt_azimuth_ambiguous = []
    azimuth_banner_printed = False
    if match_by_azimuth:
        gt_azimuth_index, gt_azimuth_ambiguous = build_gt_azimuth_index(gt_files)
        if debug and gt_azimuth_index:
            print(
                "\n【调试】方位角索引（GT stem 最后一段为整数）已建立，"
                f"共 {len(gt_azimuth_index)} 个方位角键"
            )
        if gt_azimuth_ambiguous:
            for az, names in gt_azimuth_ambiguous[:10]:
                print(
                    f"⚠️ 警告: GT 中方位角 {az} 对应多个文件，将使用 '{names[0]}' "
                    f"（同级: {', '.join(names)}）"
                )
            if len(gt_azimuth_ambiguous) > 10:
                print(
                    f"   ... 另有 {len(gt_azimuth_ambiguous) - 10} 组重复方位角"
                )
    
    # 调试模式：显示文件列表
    if debug:
        print(f"\n【调试信息】")
        print(f"渲染结果文件夹 ({len(render_files)} 个文件):")
        for f in render_files[:10]:  # 只显示前10个
            print(f"  - {f.name}")
        if len(render_files) > 10:
            print(f"  ... 还有 {len(render_files) - 10} 个文件")
        
        print(f"\n原始图像文件夹 ({len(gt_files)} 个文件):")
        for name in list(gt_files.keys())[:10]:  # 只显示前10个
            print(f"  - {name}")
        if len(gt_files) > 10:
            print(f"  ... 还有 {len(gt_files) - 10} 个文件")
        print()
    
    all_metrics = []
    skipped_files = []
    if train_angle_set:
        print(
            f"[view split] train angles: {len(train_angle_set)}; "
            "matched renders outside this set are reported as novel_view."
        )
    
    if target_only:
        if str(target_mask_mode).lower().strip() == "filter_background":
            mask_desc = (
                f"utils/filter_background percentile={target_mask_filter_percentile:g}, "
                f"largest_cc={bool(target_mask_filter_largest_cc)}"
            )
        else:
            mask_desc = f"GT gray >= {target_percentile:g}% percentile"
        print(
            f"【目标区域评估】{mask_desc} → 目标掩码；"
            f"主指标 MSE/PSNR 使用 SAR log 域掩码误差，SSIM 使用 SAR log 域掩码 SSIM；"
            f"普通像素域指标另存为 *_pixel；"
            f"* _full 为全图参考。\n"
        )
    if target_shadow:
        print(
            f"【目标+阴影评估】目标掩码 + 目标邻域暗散射阴影掩码；"
            f"shadow_source={shadow_mask_source}, search_dilate={shadow_search_dilate}, "
            f"dark_threshold={shadow_dark_threshold}, dark_quantile={shadow_dark_quantile}。\n"
        )

    # 逐张对比
    for idx, render_file in enumerate(tqdm(render_files, desc="对比图像")):
        gt_file = gt_dir / render_file.name
        render_azimuth = extract_azimuth_from_any_stem(render_file.stem)
        
        # 如果精确匹配的文件不存在，尝试智能匹配
        if not gt_file.exists():
            render_stem = render_file.stem
            matched_gt = None

            for gt_name, gt_path in gt_files.items():
                if Path(gt_name).stem == render_stem:
                    matched_gt = gt_path
                    break

            if matched_gt:
                gt_file = matched_gt
                print(
                    f"ℹ️  找到匹配文件（扩展名不同）: {render_file.name} <-> {matched_gt.name}"
                )
            elif match_by_azimuth and gt_azimuth_index:
                az_r = extract_azimuth_from_render_stem(render_stem)
                if az_r is not None and az_r not in gt_azimuth_index and int(azimuth_match_tolerance) > 0:
                    nearest_az, nearest_gt = find_nearest_azimuth_match(
                        gt_azimuth_index,
                        az_r,
                        max_error=azimuth_match_tolerance,
                    )
                    if nearest_gt is not None:
                        gt_azimuth_index[az_r] = nearest_gt
                if az_r is not None and az_r in gt_azimuth_index:
                    render_azimuth = az_r
                    gt_file = gt_azimuth_index[az_r]
                    if not azimuth_banner_printed:
                        print(
                            "ℹ️  按方位角匹配渲染图与 GT（渲染: azimuth_<角>；"
                            "GT: stem 最后一个「-」分隔的整数段）"
                        )
                        azimuth_banner_printed = True
                    print(
                        f"ℹ️  方位角 {az_r}: {render_file.name} <-> {gt_file.name}"
                    )
                else:
                    skipped_files.append({
                        "render": render_file.name,
                        "reason": "not_found",
                        "suggestions": list(gt_files.keys())[:5],
                    })
                    print(f"⚠️ 警告: 原始图像不存在，跳过: {render_file.name}")
                    if len(gt_files) > 0:
                        print(
                            f"   GT文件夹中的文件示例: {', '.join(list(gt_files.keys())[:3])}"
                        )
                    continue
            else:
                skipped_files.append({
                    "render": render_file.name,
                    "reason": "not_found",
                    "suggestions": list(gt_files.keys())[:5],
                })
                print(f"⚠️ 警告: 原始图像不存在，跳过: {render_file.name}")
                if len(gt_files) > 0:
                    print(
                        f"   GT文件夹中的文件示例: {', '.join(list(gt_files.keys())[:3])}"
                    )
                continue
        
        try:
            target_mask_path = None
            if target_mask_dir is not None:
                cand = target_mask_dir / render_file.name
                if cand.is_file():
                    target_mask_path = str(cand)
                elif debug:
                    print(f"⚠️ target mask not found for {render_file.name}: {cand}")
            metrics = compare_images(
                str(render_file),
                str(gt_file),
                device,
                calculate_sar,
                align_images,
                diagnose and idx == 0,
                output_dir,
                target_only=target_only,
                target_shadow=target_shadow,
                target_percentile=target_percentile,
                ssim_mode=ssim_mode,
                sar_ssim_log_scale=sar_ssim_log_scale,
                sar_ssim_smooth_radius=sar_ssim_smooth_radius,
                sar_ssim_tolerant_radius=sar_ssim_tolerant_radius,
                sar_ssim_intensity_tolerance=sar_ssim_intensity_tolerance,
                sar_metric_log_scale=sar_metric_log_scale,
                sar_metric_smooth_radius=sar_metric_smooth_radius,
                sar_tolerant_radius=sar_tolerant_radius,
                target_mask_path=target_mask_path,
                target_mask_mode=target_mask_mode,
                target_mask_threshold=target_mask_threshold,
                target_mask_quantile=target_mask_quantile,
                target_mask_dilate=target_mask_dilate,
                target_mask_filter_percentile=target_mask_filter_percentile,
                target_mask_filter_min_target_ratio=target_mask_filter_min_target_ratio,
                target_mask_filter_blur_sigma=target_mask_filter_blur_sigma,
                target_mask_filter_open_iter=target_mask_filter_open_iter,
                target_mask_filter_close_iter=target_mask_filter_close_iter,
                target_mask_filter_morph_kernel=target_mask_filter_morph_kernel,
                target_mask_filter_largest_cc=target_mask_filter_largest_cc,
                target_mask_filter_min_cc_area=target_mask_filter_min_cc_area,
                target_mask_filter_erode_px=target_mask_filter_erode_px,
                shadow_mask_source=shadow_mask_source,
                shadow_search_dilate=shadow_search_dilate,
                shadow_target_exclude_dilate=shadow_target_exclude_dilate,
                shadow_dark_threshold=shadow_dark_threshold,
                shadow_dark_quantile=shadow_dark_quantile,
                shadow_mask_dilate=shadow_mask_dilate,
            )
            if render_azimuth is not None:
                metrics['azimuth'] = int(render_azimuth) % 360
            if train_angle_set and render_azimuth is not None:
                metrics['view_split'] = 'train_view' if (int(render_azimuth) % 360) in train_angle_set else 'novel_view'
            all_metrics.append(metrics)
        except Exception as e:
            print(f"⚠️ 错误: 对比图像失败 {render_file.name}: {e}")
            continue
    
    if len(all_metrics) == 0:
        error_msg = "没有成功对比任何图像\n\n"
        error_msg += "可能的原因：\n"
        error_msg += "1. 渲染结果与原始图像的文件名 / 方位角无法对应（默认同 stem 后用 azimuth_<角> ↔ GT 末尾连字段）\n"
        error_msg += "2. 文件扩展名不一致且 stem 也不一致、方位角也不在 GT 索引中\n"
        error_msg += "3. 原始图像文件夹路径不正确\n\n"
        
        if skipped_files:
            error_msg += f"跳过的文件详情：\n"
            for skip_info in skipped_files[:5]:  # 只显示前5个
                error_msg += f"  - {skip_info['render']}\n"
                if skip_info.get('suggestions'):
                    error_msg += f"    GT文件夹中的文件: {', '.join(skip_info['suggestions'][:3])}\n"
        
        error_msg += f"\n提示：\n"
        error_msg += f"- 渲染结果文件夹: {render_dir}\n"
        error_msg += f"  找到的文件: {[f.name for f in render_files[:5]]}\n"
        error_msg += f"- 原始图像文件夹: {gt_dir}\n"
        if gt_files:
            error_msg += f"  找到的文件: {list(gt_files.keys())[:5]}\n"
        else:
            error_msg += f"  未找到任何图像文件\n"
        
        raise ValueError(error_msg)
    
    # 计算汇总统计
    summary = calculate_summary(all_metrics)
    
    # 保存结果
    if output_dir:
        output_dir = Path(normalize_cli_path(output_dir))
        output_dir.mkdir(parents=True, exist_ok=True)
        if visual_diagnosis:
            generate_visual_diagnosis(
                all_metrics,
                output_dir,
                max_panels=visual_diagnosis_max_panels,
                angles=visual_diagnosis_angles,
                log_scale=sar_metric_log_scale,
                target_mask_threshold=target_mask_threshold,
                target_mask_quantile=target_mask_quantile,
                target_mask_dilate=target_mask_dilate,
                extra_threshold=diagnosis_extra_threshold,
                dark_threshold=diagnosis_dark_threshold,
            )
            summary = calculate_summary(all_metrics)
        save_results(
            all_metrics,
            summary,
            output_dir,
            calculate_sar,
            target_only or target_shadow,
            agent_diagnosis=agent_diagnosis,
        )
    else:
        # 即使没有指定输出目录，也在控制台显示汇总结果
        print("\n" + "=" * 80)
        print("对比结果汇总")
        print("=" * 80)
        for metric_name, stats in summary.items():
            print(f"{metric_name:20s}: 平均值={stats['mean']:8.4f}, "
                  f"标准差={stats['std']:8.4f}, "
                  f"范围=[{stats['min']:.4f}, {stats['max']:.4f}]")
        print("=" * 80)
        
        # 显示逐图像结果
        print("\n【逐图像详细结果】")
        print("=" * 80)
        for metrics in all_metrics:
            print(f"\n图像: {metrics['image_name']}")
            print("-" * 80)
            for key, value in metrics.items():
                if key not in ['render_path', 'gt_path']:
                    if value is not None:
                        if isinstance(value, float):
                            print(f"  {key:20s}: {value:.6f}")
                        else:
                            print(f"  {key:20s}: {value}")
        print("=" * 80)
        print("\n💡 提示: 使用 --output_dir 参数可以保存详细报告到文件")
    
    # 如果有跳过的文件，给出提示
    if len(all_metrics) < len(render_files):
        skipped_count = len(render_files) - len(all_metrics)
        print(f"\nℹ️  跳过了 {skipped_count} 张图像（无对应 GT）")
        if debug and skipped_files:
            print(f"跳过的文件列表:")
            for skip_info in skipped_files[:10]:
                print(f"  - {skip_info['render']}")
    
    return all_metrics, summary


def calculate_summary(all_metrics):
    """
    计算汇总统计信息
    
    Args:
        all_metrics: 所有图像的指标列表
    
    Returns:
        summary: 汇总统计字典
    """
    summary = {}
    
    # 提取所有指标名称（排除非数值字段）
    exclude_keys = [
        'image_name',
        'render_path',
        'gt_path',
        'image_size',
        'azimuth',
        'view_split',
        'eval_mode',
        'ssim_mode',
        'sar_ssim_log_scale',
        'sar_ssim_smooth_radius',
        'target_mask_source',
        'target_mask_threshold',
        'target_mask_quantile',
        'target_mask_dilate',
        'shadow_mask_source',
    ]
    metric_keys = [k for k in all_metrics[0].keys() if k not in exclude_keys]

    for key in metric_keys:
        values = []
        for m in all_metrics:
            v = m.get(key)
            if v is None or isinstance(v, str):
                continue
            if isinstance(v, float) and (np.isnan(v) or np.isinf(v)):
                continue
            values.append(float(v))
        if len(values) > 0:
            arr = np.array(values, dtype=np.float64)
            summary[key] = {
                'mean': float(np.nanmean(arr)),
                'std': float(np.nanstd(arr)),
                'min': float(np.nanmin(arr)),
                'max': float(np.nanmax(arr)),
                'median': float(np.nanmedian(arr)),
            }
    
    return summary


def calculate_group_summaries(all_metrics, group_key):
    """Calculate summary statistics for each value of a grouping field."""
    groups = {}
    for metrics in all_metrics:
        group = metrics.get(group_key)
        if not group:
            continue
        groups.setdefault(str(group), []).append(metrics)
    return {name: calculate_summary(items) for name, items in sorted(groups.items()) if items}


def _json_safe_replace_nan(obj):
    """将 float nan/inf 转为 None，便于 JSON 序列化。"""
    if isinstance(obj, dict):
        return {k: _json_safe_replace_nan(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_safe_replace_nan(v) for v in obj]
    if isinstance(obj, float):
        if np.isnan(obj) or np.isinf(obj):
            return None
    return obj


def _safe_float(value, default=float("nan")):
    try:
        if value is None or value == "":
            return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


def _finite_values(values):
    out = []
    for value in values:
        value = _safe_float(value)
        if math.isfinite(value):
            out.append(value)
    return out


def _mean_metric(rows, key, default=float("nan")):
    values = _finite_values(row.get(key) for row in rows)
    return float(np.mean(values)) if values else default


def _summary_mean(summary, key, default=float("nan")):
    stats = summary.get(key, {}) if isinstance(summary, dict) else {}
    return _safe_float(stats.get("mean"), default)


def _load_agent_inputs(output_dir, all_metrics=None, summary=None):
    output_dir = Path(output_dir)
    summary_by_view_split = {}
    if all_metrics is None or summary is None:
        json_path = output_dir / "comparison_results.json"
        if not json_path.exists():
            raise FileNotFoundError(f"missing comparison_results.json: {json_path}")
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if all_metrics is None:
            all_metrics = data.get("per_image", [])
        if summary is None:
            summary = data.get("summary", {})
        summary_by_view_split = data.get("summary_by_view_split", {})
    else:
        summary_by_view_split = calculate_group_summaries(all_metrics, "view_split")

    diag_rows = []
    diag_path = output_dir / "visual_diagnosis" / "diagnosis_metrics.csv"
    if diag_path.exists():
        with open(diag_path, "r", encoding="utf-8-sig", newline="") as f:
            diag_rows = list(csv.DictReader(f))

    by_name = {str(row.get("image_name")): dict(row) for row in (all_metrics or [])}
    for drow in diag_rows:
        name = str(drow.get("image_name"))
        by_name.setdefault(name, {}).update(drow)
    return list(by_name.values()), summary or {}, summary_by_view_split or {}, diag_path if diag_path.exists() else None


def _grade_from_score(score):
    if score >= 80:
        return "good"
    if score >= 60:
        return "usable"
    if score >= 40:
        return "weak"
    return "failed"


def generate_agent_diagnosis_report(output_dir, all_metrics=None, summary=None):
    """Rule-based SAR result analyst for compare_render_gt outputs."""
    output_dir = Path(output_dir)
    rows, summary, summary_by_view_split, diag_csv = _load_agent_inputs(output_dir, all_metrics, summary)
    if not rows:
        return None

    sar_ssim = _summary_mean(summary, "SAR_SSIM", _summary_mean(summary, "SSIM"))
    sar_tol_psnr = _summary_mean(summary, "SAR_TOL_PSNR")
    psnr = _summary_mean(summary, "PSNR")
    ssim_full = _summary_mean(summary, "SAR_SSIM_full", _summary_mean(summary, "SSIM_full"))
    psnr_full = _summary_mean(summary, "PSNR_full")

    leak = _mean_metric(rows, "diagnosis_dark_region_leak_ratio")
    gt_dark = _mean_metric(rows, "diagnosis_gt_dark_target_ratio")
    missing = _mean_metric(rows, "diagnosis_missing_bright_ratio")
    extra = _mean_metric(rows, "diagnosis_extra_bright_ratio")
    edge_mae = _mean_metric(rows, "diagnosis_mae_edge_log")
    inner_mae = _mean_metric(rows, "diagnosis_mae_inner_log")
    bg_mae = _mean_metric(rows, "diagnosis_mae_bg_log")
    target_mae = _mean_metric(rows, "diagnosis_mae_target_log")
    diag_target_ssim = _mean_metric(rows, "diagnosis_ssim_target_global")

    score = 100.0
    findings = []
    recommendations = []
    next_params = []

    if math.isfinite(leak):
        if leak >= 0.80:
            score -= 35
            findings.append(("severe", f"dark-region leak is extremely high: mean={leak:.4f}; GT-dark target regions still contain scattering."))
            recommendations.append("First fix extinction/layover gating. Do not keep increasing speckle losses or pure L1/SSIM while the dark regions still leak.")
            next_params += [
                "--target_extinction_apply_gamma 0.55",
                "--target_extinction_apply_mode power_sigmoid",
                "--target_extinction_apply_threshold 0.50",
                "--target_extinction_apply_softness 0.08",
                "--target_extinction_apply_sigmoid_mix 0.35",
                "--target_extinction_render_gate_floor 0.25",
                "--target_extinction_residual_loss_weight 0.50",
                "--target_extinction_ceiling_loss_weight 0.55",
                "--target_extinction_ceiling_max_intensity 0.06",
                "--target_extinction_ceiling_margin 0.008",
                "--target_extinction_ceiling_context_ratio 0.35",
                "--target_extinction_sparsity_weight 0.001",
            ]
        elif leak >= 0.50:
            score -= 22
            findings.append(("major", f"dark-region leak is high: mean={leak:.4f}."))
            recommendations.append("Moderately strengthen extinction apply/gate while keeping enough pixel supervision.")
            next_params += [
                "--target_extinction_apply_gamma 0.55",
                "--target_extinction_apply_mode power_sigmoid",
                "--target_extinction_apply_threshold 0.50",
                "--target_extinction_apply_softness 0.08",
                "--target_extinction_apply_sigmoid_mix 0.35",
                "--target_extinction_residual_loss_weight 0.45",
                "--target_extinction_ceiling_loss_weight 0.40",
            ]
        elif leak >= 0.25:
            score -= 10
            findings.append(("moderate", f"dark-region leak is visible: mean={leak:.4f}."))
    else:
        findings.append(("info", "No visual-diagnosis dark leak metric found; run with --visual_diagnosis."))

    if math.isfinite(edge_mae) and math.isfinite(inner_mae):
        edge_ratio = edge_mae / max(inner_mae, 1e-6)
        if edge_ratio >= 1.35:
            score -= 18
            findings.append(("major", f"edge/layover shape error is high: edge MAE={edge_mae:.4f}, inner MAE={inner_mae:.4f}, ratio={edge_ratio:.2f}."))
            recommendations.append("The target still looks like a smooth template instead of a non-rectangular SAR extinction shape. Inspect extinction maps on the worst angles.")
        elif edge_ratio >= 1.15:
            score -= 8
            findings.append(("moderate", f"edge error is higher than inner error: edge/inner={edge_ratio:.2f}."))

    if math.isfinite(missing):
        if missing >= 0.13:
            score -= 16
            findings.append(("major", f"many GT bright scatterers are missing or shifted: mean={missing:.4f}."))
            recommendations.append("Bright speckle/statistics are underfit, but fix dark leakage first if leak is still high.")
        elif missing >= 0.08:
            score -= 8
            findings.append(("moderate", f"GT bright scatterer miss ratio is moderate: mean={missing:.4f}."))

    if math.isfinite(extra) and extra >= 0.08:
        score -= 8
        findings.append(("moderate", f"extra bright scattering is somewhat high: mean={extra:.4f}."))

    if math.isfinite(bg_mae) and math.isfinite(target_mae) and bg_mae > target_mae * 1.45:
        findings.append(("info", f"background strongly affects full-image metrics: bg MAE={bg_mae:.4f}, target MAE={target_mae:.4f}."))
        recommendations.append("Use target metrics and visual panels to judge target quality; full SSIM is dominated by background SAR statistics.")

    if math.isfinite(sar_ssim):
        if sar_ssim < 0.55:
            score -= 18
            findings.append(("major", f"target-region SAR_SSIM is low: mean={sar_ssim:.4f}."))
        elif sar_ssim < 0.62:
            score -= 9
            findings.append(("moderate", f"target-region SAR_SSIM is still weak: mean={sar_ssim:.4f}."))

    if math.isfinite(ssim_full) and ssim_full < 0.05:
        findings.append(("info", f"full-image SSIM is extremely low: mean={ssim_full:.4f}; this is usually background/speckle dominated."))

    train_summary = summary_by_view_split.get("train_view", {})
    novel_summary = summary_by_view_split.get("novel_view", {})
    train_ssim = _summary_mean(train_summary, "SAR_SSIM", _summary_mean(train_summary, "SSIM"))
    novel_ssim = _summary_mean(novel_summary, "SAR_SSIM", _summary_mean(novel_summary, "SSIM"))
    if math.isfinite(train_ssim) and math.isfinite(novel_ssim):
        gap = train_ssim - novel_ssim
        if gap > 0.08:
            findings.append(("moderate", f"train/novel gap is large: train={train_ssim:.4f}, novel={novel_ssim:.4f}, gap={gap:.4f}."))
            recommendations.append("Avoid GT overwrite or per-view memorization; prefer structure/statistical losses and azimuth consistency.")
        else:
            findings.append(("info", f"train/novel gap is small: train={train_ssim:.4f}, novel={novel_ssim:.4f}; the failure is systematic, not only generalization."))

    worst_keys = [
        "diagnosis_ssim_target_global",
        "diagnosis_dark_region_leak_ratio",
        "diagnosis_mae_edge_log",
        "diagnosis_missing_bright_ratio",
        "SAR_SSIM",
        "SSIM",
    ]

    def _row_badness(row):
        ssim_v = _safe_float(row.get("diagnosis_ssim_target_global"), _safe_float(row.get("SAR_SSIM"), _safe_float(row.get("SSIM"), 1.0)))
        leak_v = _safe_float(row.get("diagnosis_dark_region_leak_ratio"), 0.0)
        edge_v = _safe_float(row.get("diagnosis_mae_edge_log"), 0.0)
        miss_v = _safe_float(row.get("diagnosis_missing_bright_ratio"), 0.0)
        return (1.0 - ssim_v) + 0.45 * leak_v + edge_v + 0.7 * miss_v

    worst_rows = sorted(rows, key=_row_badness, reverse=True)[:12]
    panel_dir = output_dir / "visual_diagnosis"
    panel_paths = []
    for row in worst_rows:
        name = str(row.get("image_name", ""))
        panel = panel_dir / f"diagnosis_{Path(name).stem}.png"
        if panel.exists():
            panel_paths.append(str(panel))

    if not recommendations:
        recommendations.append("No single diagnostic item dominates; compare the visual panels for speckle, edge, and background failures.")
    if not next_params and math.isfinite(leak) and leak >= 0.25:
        next_params += [
            "--target_extinction_apply_gamma 0.55",
            "--target_extinction_apply_mode power_sigmoid",
            "--target_extinction_apply_threshold 0.50",
            "--target_extinction_apply_softness 0.08",
            "--target_extinction_apply_sigmoid_mix 0.35",
            "--target_extinction_residual_loss_weight 0.40",
            "--target_extinction_ceiling_loss_weight 0.30",
        ]
    if math.isfinite(missing) and missing >= 0.08 and (not math.isfinite(leak) or leak < 0.50):
        next_params += [
            "--target_speckle_loss_weight 0.24",
            "--target_speckle_intensity_quantile_weight 0.60",
        ]

    score = max(0.0, min(100.0, score))
    grade = _grade_from_score(score)
    primary = findings[0][1] if findings else "No dominant failure found."

    report = {
        "output_dir": str(output_dir),
        "num_images": len(rows),
        "grade": grade,
        "score": round(score, 2),
        "primary_failure": primary,
        "metrics": {
            "SAR_SSIM_mean": sar_ssim,
            "SAR_TOL_PSNR_mean": sar_tol_psnr,
            "PSNR_mean": psnr,
            "SAR_SSIM_full_mean": ssim_full,
            "PSNR_full_mean": psnr_full,
            "diagnosis_ssim_target_global_mean": diag_target_ssim,
            "diagnosis_dark_region_leak_ratio_mean": leak,
            "diagnosis_gt_dark_target_ratio_mean": gt_dark,
            "diagnosis_missing_bright_ratio_mean": missing,
            "diagnosis_extra_bright_ratio_mean": extra,
            "diagnosis_mae_edge_log_mean": edge_mae,
            "diagnosis_mae_inner_log_mean": inner_mae,
            "diagnosis_mae_bg_log_mean": bg_mae,
        },
        "findings": [{"severity": sev, "text": text} for sev, text in findings],
        "recommendations": recommendations,
        "suggested_next_params": list(dict.fromkeys(next_params)),
        "worst_images": [
            {key: row.get(key) for key in ["image_name", "azimuth", *worst_keys] if key in row}
            for row in worst_rows
        ],
        "panel_paths": panel_paths,
        "diagnosis_csv": str(diag_csv) if diag_csv else None,
    }

    json_path = output_dir / "agent_diagnosis_report.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(_json_safe_replace_nan(report), f, indent=2, ensure_ascii=False, allow_nan=False)

    text_path = output_dir / "agent_diagnosis_report.txt"
    with open(text_path, "w", encoding="utf-8") as f:
        f.write("SAR result diagnosis agent\n")
        f.write("=" * 80 + "\n")
        f.write(f"output_dir: {output_dir}\n")
        f.write(f"images: {len(rows)}\n")
        f.write(f"grade: {grade}  score: {score:.1f}/100\n")
        f.write(f"primary_failure: {primary}\n\n")
        f.write("[key metrics]\n")
        for key, value in report["metrics"].items():
            if isinstance(value, float) and math.isfinite(value):
                f.write(f"{key}: {value:.4f}\n")
        f.write("\n[findings]\n")
        for item in report["findings"]:
            f.write(f"- {item['severity']}: {item['text']}\n")
        f.write("\n[recommendations]\n")
        for item in recommendations:
            f.write(f"- {item}\n")
        if report["suggested_next_params"]:
            f.write("\n[suggested next-run params]\n")
            for item in report["suggested_next_params"]:
                f.write(f"  {item}\n")
        f.write("\n[worst images to inspect]\n")
        for row in report["worst_images"]:
            parts = [str(row.get("image_name", ""))]
            for key in worst_keys:
                if key in row:
                    val = _safe_float(row.get(key))
                    if math.isfinite(val):
                        parts.append(f"{key}={val:.4f}")
            f.write("- " + ", ".join(parts) + "\n")
        if panel_paths:
            f.write("\n[diagnosis panels]\n")
            for path in panel_paths:
                f.write(f"{path}\n")

    print(f"agent diagnosis saved: {text_path}")
    return report


def save_results(all_metrics, summary, output_dir, calculate_sar=False, target_only=False, agent_diagnosis=True):
    """
    保存对比结果
    
    Args:
        all_metrics: 所有图像的指标列表
        summary: 汇总统计信息
        output_dir: 输出目录
        calculate_sar: 是否包含SAR指标
        target_only: 是否为「仅目标区域」评估（报告标题说明）
    """
    output_dir = Path(output_dir)
    summary_by_view_split = calculate_group_summaries(all_metrics, 'view_split')
    
    # 1. 保存JSON格式的详细结果
    results_json = {
        'summary': summary,
        'summary_by_view_split': summary_by_view_split,
        'per_image': all_metrics
    }
    results_json = _json_safe_replace_nan(results_json)
    
    json_path = output_dir / 'comparison_results.json'
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(results_json, f, indent=2, ensure_ascii=False, allow_nan=False)
    print(f"✅ 详细结果已保存: {json_path}")
    
    # 2. 保存文本格式的报告
    report_path = output_dir / 'comparison_report.txt'
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("=" * 80 + "\n")
        if target_only:
            f.write("高斯泼溅渲染结果与原始图像相似度对比报告（仅目标区域：背景已排除）\n")
        else:
            f.write("高斯泼溅渲染结果与原始图像相似度对比报告\n")
        f.write("=" * 80 + "\n\n")
        
        f.write("【汇总统计】\n")
        f.write("-" * 80 + "\n")
        for metric_name, stats in summary.items():
            f.write(f"{metric_name}:\n")
            f.write(f"  平均值: {stats['mean']:.6f}\n")
            f.write(f"  标准差: {stats['std']:.6f}\n")
            f.write(f"  最小值: {stats['min']:.6f}\n")
            f.write(f"  最大值: {stats['max']:.6f}\n")
            f.write(f"  中位数: {stats['median']:.6f}\n")
            f.write("\n")
        
        if summary_by_view_split:
            f.write("\n" + "=" * 80 + "\n")
            f.write("[view split summary]\n")
            f.write("=" * 80 + "\n\n")
            for group_name, group_summary in summary_by_view_split.items():
                f.write(f"{group_name}:\n")
                f.write("-" * 80 + "\n")
                for metric_name, stats in group_summary.items():
                    f.write(f"{metric_name}:\n")
                    f.write(f"  mean: {stats['mean']:.6f}\n")
                    f.write(f"  std: {stats['std']:.6f}\n")
                    f.write(f"  min: {stats['min']:.6f}\n")
                    f.write(f"  max: {stats['max']:.6f}\n")
                    f.write(f"  median: {stats['median']:.6f}\n")
                    f.write("\n")

        f.write("\n" + "=" * 80 + "\n")
        f.write("【逐图像详细结果】\n")
        f.write("=" * 80 + "\n\n")
        
        for metrics in all_metrics:
            f.write(f"图像: {metrics['image_name']}\n")
            f.write("-" * 80 + "\n")
            for key, value in metrics.items():
                if key not in ['render_path', 'gt_path']:
                    if value is not None:
                        if isinstance(value, float):
                            f.write(f"  {key}: {value:.6f}\n")
                        else:
                            f.write(f"  {key}: {value}\n")
            f.write("\n")
    
    print(f"✅ 文本报告已保存: {report_path}")
    
    # 3. 打印汇总信息到控制台
    print("\n" + "=" * 80)
    print("对比结果汇总")
    print("=" * 80)
    hidden_summary_suffixes = ("_full",) if target_only else ()
    for metric_name, stats in summary.items():
        if hidden_summary_suffixes and metric_name.endswith(hidden_summary_suffixes):
            continue
        print(f"{metric_name:20s}: 平均值={stats['mean']:8.4f}, "
              f"标准差={stats['std']:8.4f}, "
              f"范围=[{stats['min']:.4f}, {stats['max']:.4f}]")
    if summary_by_view_split:
        important = {"PSNR", "SSIM", "SAR_SSIM", "SAR_TOL_PSNR"}
        if not target_only:
            important |= {"PSNR_full", "SSIM_full", "SAR_SSIM_full", "SAR_TOL_PSNR_full"}
        print("\n" + "=" * 80)
        print("view split summary" + (" (target metrics; full metrics saved as reference)" if target_only else ""))
        print("=" * 80)
        for group_name, group_summary in summary_by_view_split.items():
            print(f"[{group_name}]")
            for metric_name, stats in group_summary.items():
                if metric_name in important:
                    print(f"{metric_name:20s}: mean={stats['mean']:8.4f}, range=[{stats['min']:.4f}, {stats['max']:.4f}]")
    print("=" * 80 + "\n")
    if agent_diagnosis:
        generate_agent_diagnosis_report(output_dir, all_metrics, summary)


def main():
    parser = argparse.ArgumentParser(
        description='对比高斯泼溅渲染结果与原始图像的相似度',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  # 批量对比两个文件夹
  python compare_render_gt.py --render_dir ./output/model/test/ours_30000/renders --gt_dir ./output/model/test/ours_30000/gt
  
  # 单张图像对比
  python compare_render_gt.py --render_path render.png --gt_path gt.png
  
  # 指定输出目录和SAR指标
  python compare_render_gt.py --render_dir renders --gt_dir gt --output_dir ./results --sar_metrics
  
  # 只写 --output_dir 不写路径时，会保存到当前目录下的 comparison_results/
        """
    )
    
    # 输入选项（互斥）
    input_group = parser.add_mutually_exclusive_group(required=False)
    input_group.add_argument('--render_dir', type=str, help='渲染结果文件夹路径')
    input_group.add_argument('--render_path', type=str, help='单张渲染结果图像路径')
    
    input_group2 = parser.add_mutually_exclusive_group(required=False)
    input_group2.add_argument('--gt_dir', type=str, help='原始图像文件夹路径')
    input_group2.add_argument('--gt_path', type=str, help='单张原始图像路径')
    
    # 其他选项：nargs='?' 允许「只写 --output_dir」时用 const 作为默认目录
    parser.add_argument(
        '--output_dir',
        nargs='?',
        const='comparison_results',
        default=None,
        metavar='DIR',
        help='保存报告的目录。省略本参数则不落盘；只写 --output_dir 不写路径时保存到 ./comparison_results',
    )
    parser.add_argument(
        '--analyze_results_dir',
        type=str,
        default=None,
        help='Only run the SAR diagnosis agent on an existing compare_render_gt output directory.',
    )
    parser.add_argument(
        '--agent_diagnosis',
        dest='agent_diagnosis',
        action='store_true',
        default=True,
        help='Generate agent_diagnosis_report.txt/json after saving comparison results.',
    )
    parser.add_argument(
        '--no_agent_diagnosis',
        '--no-agent_diagnosis',
        dest='agent_diagnosis',
        action='store_false',
        help='Disable the automatic SAR diagnosis agent report.',
    )
    parser.add_argument('--device', type=str, default='cuda', choices=['cuda', 'cpu'],
                       help='计算设备（默认: cuda）')
    parser.add_argument('--sar_metrics', action='store_true',
                       help='计算SAR图像特定指标')
    parser.add_argument(
        '--ssim_mode',
        choices=['sar_intensity', 'pixel'],
        default='sar_intensity',
        help='SSIM mode: sar_intensity uses log scattering intensity; pixel uses the old image-pixel SSIM',
    )
    parser.add_argument(
        '--sar_ssim_log_scale',
        type=float,
        default=20.0,
        help='Log compression scale for SAR intensity SSIM',
    )
    parser.add_argument(
        '--sar_ssim_smooth_radius',
        type=int,
        default=1,
        help='Optional symmetric mean-filter radius before SAR intensity SSIM; 1 or 2 reduces speckle pixel mismatch',
    )
    parser.add_argument(
        '--sar_ssim_tolerant_radius',
        type=int,
        default=1,
        help='Local pixel tolerance radius for SSIM/SAR_SSIM; 2-3 is recommended for 1-degree novel SAR views',
    )
    parser.add_argument(
        '--sar_ssim_intensity_tolerance',
        type=float,
        default=0.03,
        help='Small SAR log-intensity difference ignored before SSIM; 0 disables intensity tolerance',
    )
    parser.add_argument(
        '--sar_metric_log_scale',
        type=float,
        default=20.0,
        help='Log compression scale for SAR_MSE/SAR_MAE/SAR_PSNR',
    )
    parser.add_argument(
        '--sar_metric_smooth_radius',
        type=int,
        default=0,
        help='Optional mean-filter radius before SAR error metrics; 0 keeps scatterer detail',
    )
    parser.add_argument(
        '--sar_tolerant_radius',
        type=int,
        default=1,
        help='Local pixel tolerance radius for SAR_TOL_MSE/SAR_TOL_PSNR; 1 allows small scatterer shifts',
    )
    parser.add_argument(
        '--view_split_train_angle_step',
        type=int,
        default=None,
        help='Mark azimuths that are multiples of this step as train_view; others as novel_view, e.g. 10',
    )
    parser.add_argument(
        '--view_split_train_angles',
        type=str,
        default=None,
        help='Comma/space separated train-view azimuth list, e.g. "0,10,20,30"',
    )
    parser.add_argument(
        '--view_split_train_dir',
        type=str,
        default=None,
        help='Directory of training images; azimuths parsed from file names are marked as train_view',
    )
    parser.add_argument('--debug', action='store_true',
                       help='调试模式：显示详细的文件匹配信息')
    parser.add_argument('--diagnose', action='store_true',
                       help='诊断模式：分析图像差异原因，生成诊断报告')
    parser.add_argument(
        '--visual_diagnosis',
        dest='visual_diagnosis',
        action='store_true',
        default=True,
        help='Generate SAR visual diagnosis panels under output_dir/visual_diagnosis',
    )
    parser.add_argument(
        '--no_visual_diagnosis',
        '--no-visual_diagnosis',
        dest='visual_diagnosis',
        action='store_false',
        help='Disable automatic SAR visual diagnosis panels',
    )
    parser.add_argument('--visual_diagnosis_max_panels', type=int, default=12)
    parser.add_argument(
        '--visual_diagnosis_angles',
        type=str,
        default='225,220,230,325,330,345,355',
        help='Comma/space separated azimuths that should always get diagnosis panels when present',
    )
    parser.add_argument('--diagnosis_extra_threshold', type=float, default=0.18)
    parser.add_argument('--diagnosis_dark_threshold', type=float, default=0.26)
    parser.add_argument('--align_images', action='store_true',
                       help='对齐图像：在对比前对齐图像的亮度和对比度（可能提高指标但改变视觉效果）')
    parser.add_argument('--target_only', action='store_true',
                       help='仅评估目标区域：主 MSE/PSNR/SSIM 使用目标 mask 内 SAR log 域；*_pixel 为普通像素域；带 _full 后缀为全图参考')
    parser.add_argument('--target_shadow', action='store_true',
                       help='评估目标+邻近暗阴影区域；推荐同时传 --target_mask_dir 使用干净目标掩码')
    parser.add_argument('--target_percentile', type=float, default=85.0,
                       help='目标掩码：GT 灰度 >= 该分位数(0-100) 视为目标（默认 85，与 utils/target_region_compare 一致）')
    parser.add_argument(
        '--target_mask_dir',
        type=str,
        default=None,
        help='目标掩码参考目录，推荐传 novel_target_only/target_renders；按渲染文件同名查找',
    )
    parser.add_argument(
        '--target_mask_path',
        type=str,
        default=None,
        help='单张图像评估时使用的目标掩码参考图',
    )
    parser.add_argument('--target_mask_threshold', type=float, default=0.08)
    parser.add_argument('--target_mask_quantile', type=float, default=0.35)
    parser.add_argument('--target_mask_dilate', type=int, default=0)
    parser.add_argument(
        '--target_mask_mode',
        choices=['filter_background', 'gt_percentile'],
        default='filter_background',
        help='Target mask used for target_only/target_shadow when no explicit mask path is provided. filter_background matches utils/filter_background.py.',
    )
    parser.add_argument('--target_mask_filter_percentile', type=float, default=95.0)
    parser.add_argument('--target_mask_filter_min_target_ratio', type=float, default=0.002)
    parser.add_argument('--target_mask_filter_blur_sigma', type=float, default=1.0)
    parser.add_argument('--target_mask_filter_open_iter', type=int, default=0)
    parser.add_argument('--target_mask_filter_close_iter', type=int, default=0)
    parser.add_argument('--target_mask_filter_morph_kernel', type=int, default=5)
    parser.add_argument('--target_mask_filter_largest_cc', action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument('--target_mask_filter_min_cc_area', type=int, default=0)
    parser.add_argument('--target_mask_filter_erode_px', type=int, default=0)
    parser.add_argument(
        '--azimuth_match_tolerance',
        type=int,
        default=0,
        help='Maximum circular azimuth difference in degrees when exact render/GT azimuth matching fails. 0 requires exact azimuth and skips missing GT.',
    )
    parser.add_argument(
        '--shadow_mask_source',
        choices=['gt', 'render', 'union', 'intersection'],
        default='union',
        help='--target_shadow 的阴影掩码来源；union 会同时惩罚缺失阴影和多余阴影',
    )
    parser.add_argument('--shadow_search_dilate', type=int, default=45)
    parser.add_argument('--shadow_target_exclude_dilate', type=int, default=1)
    parser.add_argument('--shadow_dark_threshold', type=float, default=0.18)
    parser.add_argument('--shadow_dark_quantile', type=float, default=0.15)
    parser.add_argument('--shadow_mask_dilate', type=int, default=0)
    parser.add_argument(
        '--no_azimuth_match',
        action='store_true',
        help='禁用方位角对齐：仅用「同名完整文件名」或与渲染 stem 相同的 GT stem（不写本参数时在上述失败后尝试方位角匹配）',
    )

    args = parser.parse_args()
    for _name in ("render_dir", "gt_dir", "render_path", "gt_path", "output_dir", "target_mask_dir", "target_mask_path", "view_split_train_dir", "analyze_results_dir"):
        _v = getattr(args, _name, None)
        if isinstance(_v, str) and _v.strip():
            setattr(args, _name, normalize_cli_path(_v))
    if args.target_only and args.target_shadow:
        parser.error("--target_only and --target_shadow are mutually exclusive")

    # 检查设备
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("⚠️ 警告: CUDA不可用，切换到CPU")
        args.device = 'cpu'
    
    try:
        # 单张图像对比
        if args.analyze_results_dir:
            report = generate_agent_diagnosis_report(args.analyze_results_dir)
            if report:
                print(
                    f"\nagent grade: {report['grade']}  score={report['score']:.1f}/100\n"
                    f"primary failure: {report['primary_failure']}"
                )
            return 0

        if args.render_path and args.gt_path:
            print(f"对比单张图像: {args.render_path} vs {args.gt_path}")
            metrics = compare_images(
                args.render_path,
                args.gt_path,
                args.device,
                args.sar_metrics,
                args.align_images,
                args.diagnose,
                args.output_dir,
                target_only=args.target_only,
                target_shadow=args.target_shadow,
                target_percentile=args.target_percentile,
                ssim_mode=args.ssim_mode,
                sar_ssim_log_scale=args.sar_ssim_log_scale,
                sar_ssim_smooth_radius=args.sar_ssim_smooth_radius,
                sar_ssim_tolerant_radius=args.sar_ssim_tolerant_radius,
                sar_ssim_intensity_tolerance=args.sar_ssim_intensity_tolerance,
                sar_metric_log_scale=args.sar_metric_log_scale,
                sar_metric_smooth_radius=args.sar_metric_smooth_radius,
                sar_tolerant_radius=args.sar_tolerant_radius,
                target_mask_path=args.target_mask_path,
                target_mask_mode=args.target_mask_mode,
                target_mask_threshold=args.target_mask_threshold,
                target_mask_quantile=args.target_mask_quantile,
                target_mask_dilate=args.target_mask_dilate,
                target_mask_filter_percentile=args.target_mask_filter_percentile,
                target_mask_filter_min_target_ratio=args.target_mask_filter_min_target_ratio,
                target_mask_filter_blur_sigma=args.target_mask_filter_blur_sigma,
                target_mask_filter_open_iter=args.target_mask_filter_open_iter,
                target_mask_filter_close_iter=args.target_mask_filter_close_iter,
                target_mask_filter_morph_kernel=args.target_mask_filter_morph_kernel,
                target_mask_filter_largest_cc=args.target_mask_filter_largest_cc,
                target_mask_filter_min_cc_area=args.target_mask_filter_min_cc_area,
                target_mask_filter_erode_px=args.target_mask_filter_erode_px,
                shadow_mask_source=args.shadow_mask_source,
                shadow_search_dilate=args.shadow_search_dilate,
                shadow_target_exclude_dilate=args.shadow_target_exclude_dilate,
                shadow_dark_threshold=args.shadow_dark_threshold,
                shadow_dark_quantile=args.shadow_dark_quantile,
                shadow_mask_dilate=args.shadow_mask_dilate,
            )
            
            print("\n" + "=" * 80)
            print("对比结果")
            print("=" * 80)
            for key, value in metrics.items():
                if key not in ['render_path', 'gt_path']:
                    if value is not None:
                        if isinstance(value, float):
                            print(f"{key:20s}: {value:.6f}")
                        else:
                            print(f"{key:20s}: {value}")
            print("=" * 80)
            
            # 如果指定了输出目录，保存结果
            if args.output_dir:
                output_dir = Path(args.output_dir)
                output_dir.mkdir(parents=True, exist_ok=True)
                if args.visual_diagnosis:
                    generate_visual_diagnosis(
                        [metrics],
                        output_dir,
                        max_panels=1,
                        angles=args.visual_diagnosis_angles,
                        log_scale=args.sar_metric_log_scale,
                        target_mask_threshold=args.target_mask_threshold,
                        target_mask_quantile=args.target_mask_quantile,
                        target_mask_dilate=args.target_mask_dilate,
                        extra_threshold=args.diagnosis_extra_threshold,
                        dark_threshold=args.diagnosis_dark_threshold,
                    )
                summary = calculate_summary([metrics])
                save_results(
                    [metrics],
                    summary,
                    output_dir,
                    args.sar_metrics,
                    args.target_only or args.target_shadow,
                    agent_diagnosis=args.agent_diagnosis,
                )
        
        # 批量对比
        elif args.render_dir and args.gt_dir:
            print(f"批量对比文件夹:")
            print(f"  渲染结果: {args.render_dir}")
            print(f"  原始图像: {args.gt_dir}")
            if args.output_dir:
                print(f"  输出目录: {args.output_dir}")
            print()
            
            all_metrics, summary = compare_directories(
                args.render_dir,
                args.gt_dir,
                args.output_dir,
                args.device,
                args.sar_metrics,
                args.debug,
                args.align_images,
                args.diagnose,
                target_only=args.target_only,
                target_shadow=args.target_shadow,
                target_percentile=args.target_percentile,
                match_by_azimuth=not args.no_azimuth_match,
                ssim_mode=args.ssim_mode,
                sar_ssim_log_scale=args.sar_ssim_log_scale,
                sar_ssim_smooth_radius=args.sar_ssim_smooth_radius,
                sar_ssim_tolerant_radius=args.sar_ssim_tolerant_radius,
                sar_ssim_intensity_tolerance=args.sar_ssim_intensity_tolerance,
                sar_metric_log_scale=args.sar_metric_log_scale,
                sar_metric_smooth_radius=args.sar_metric_smooth_radius,
                sar_tolerant_radius=args.sar_tolerant_radius,
                view_split_train_angles=args.view_split_train_angles,
                view_split_train_angle_step=args.view_split_train_angle_step,
                view_split_train_dir=args.view_split_train_dir,
                target_mask_dir=args.target_mask_dir,
                target_mask_mode=args.target_mask_mode,
                target_mask_threshold=args.target_mask_threshold,
                target_mask_quantile=args.target_mask_quantile,
                target_mask_dilate=args.target_mask_dilate,
                target_mask_filter_percentile=args.target_mask_filter_percentile,
                target_mask_filter_min_target_ratio=args.target_mask_filter_min_target_ratio,
                target_mask_filter_blur_sigma=args.target_mask_filter_blur_sigma,
                target_mask_filter_open_iter=args.target_mask_filter_open_iter,
                target_mask_filter_close_iter=args.target_mask_filter_close_iter,
                target_mask_filter_morph_kernel=args.target_mask_filter_morph_kernel,
                target_mask_filter_largest_cc=args.target_mask_filter_largest_cc,
                target_mask_filter_min_cc_area=args.target_mask_filter_min_cc_area,
                target_mask_filter_erode_px=args.target_mask_filter_erode_px,
                azimuth_match_tolerance=args.azimuth_match_tolerance,
                shadow_mask_source=args.shadow_mask_source,
                shadow_search_dilate=args.shadow_search_dilate,
                shadow_target_exclude_dilate=args.shadow_target_exclude_dilate,
                shadow_dark_threshold=args.shadow_dark_threshold,
                shadow_dark_quantile=args.shadow_dark_quantile,
                shadow_mask_dilate=args.shadow_mask_dilate,
                visual_diagnosis=args.visual_diagnosis,
                visual_diagnosis_max_panels=args.visual_diagnosis_max_panels,
                visual_diagnosis_angles=args.visual_diagnosis_angles,
                diagnosis_extra_threshold=args.diagnosis_extra_threshold,
                diagnosis_dark_threshold=args.diagnosis_dark_threshold,
                agent_diagnosis=args.agent_diagnosis,
            )
            
            print(f"\n✅ 成功对比 {len(all_metrics)} 张图像")
        else:
            parser.error(
                "pass either --analyze_results_dir, or a pair of --render_dir/--gt_dir, "
                "or a pair of --render_path/--gt_path"
            )
    
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
