#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
检查SfM代码中radius_scale和焦距的计算逻辑
"""

import json
import math

print("="*70)
print("SfM代码中radius_scale和焦距计算逻辑检查")
print("="*70)

# 读取当前的scale_params.json
scale_params_file = "data/25/sar_scale_params.json"
with open(scale_params_file, 'r') as f:
    scale_params = json.load(f)

print("\n【1. 当前配置文件中的值】")
print("-"*70)
print(f"unified_radius_scale: {scale_params.get('unified_radius_scale', 'N/A')}")
print(f"estimated_radius_scale: {scale_params.get('estimated_radius_scale', 'N/A')}")
print(f"unified_focal_azimuth: {scale_params.get('unified_focal_azimuth', 'N/A')}")
print(f"unified_focal_range: {scale_params.get('unified_focal_range', 'N/A')}")

# 检查计算逻辑
print("\n【2. unified_radius_scale计算逻辑（sfm.py第470-488行）】")
print("-"*70)
if 'radius_scale_calculation' in scale_params:
    calc = scale_params['radius_scale_calculation']
    R0 = calc.get('R0', None)
    image_size = calc.get('image_size', None)
    scene_scale = scale_params.get('scene_scale', None)
    
    if R0 and image_size and scene_scale:
        calculated = (image_size * scene_scale) / R0
        print(f"公式: (image_size × scene_scale) / R0")
        print(f"计算: ({image_size} × {scene_scale}) / {R0} = {calculated:.6f}")
        print(f"实际值: {scale_params.get('unified_radius_scale', 'N/A')}")
        
        if abs(calculated - scale_params.get('unified_radius_scale', 0)) < 1e-6:
            print("✅ 公式计算正确")
        else:
            print("⚠️  公式计算与实际值不一致")
            print(f"   差异: {abs(calculated - scale_params.get('unified_radius_scale', 0)):.6f}")

print("\n【3. estimated_radius_scale计算逻辑（sfm.py第3774行）】")
print("-"*70)
if 'estimated_radius_scale' in scale_params and 'point_cloud_max_extent' in scale_params:
    point_max_extent = scale_params['point_cloud_max_extent']
    estimated = scale_params['estimated_radius_scale']
    avg_dep = scale_params.get('average_depression_angle', 30.0)
    camera_height = scale_params.get('camera_height', 12000.0)
    
    # 计算理论R0
    R0_avg = camera_height / math.sin(math.radians(avg_dep))
    
    # 根据代码中的公式：estimated_radius_scale = (point_max_extent * 100) / R0_avg
    calculated = (point_max_extent * 100) / R0_avg
    
    print(f"公式: (point_cloud_max_extent × 100) / R0_avg")
    print(f"计算: ({point_max_extent:.2f} × 100) / {R0_avg:.2f} = {calculated:.6f}")
    print(f"实际值: {estimated}")
    
    if abs(calculated - estimated) < 1e-6:
        print("✅ 公式计算正确")
    else:
        print("⚠️  公式计算与实际值不一致")
        print(f"   差异: {abs(calculated - estimated):.6f}")
    
    print(f"\n参数说明:")
    print(f"  - point_cloud_max_extent: {point_max_extent:.2f}m (点云最大扩展)")
    print(f"  - average_depression_angle: {avg_dep:.2f}° (平均俯视角)")
    print(f"  - camera_height: {camera_height:.1f}m (相机高度)")
    print(f"  - R0_avg: {R0_avg:.2f}m (理论相机距离)")
    print(f"\n⚠️  问题分析:")
    print(f"  1. 公式中使用了 '× 100'，这个系数可能不合理")
    print(f"  2. estimated_radius_scale应该反映点云尺度与相机距离的关系")
    print(f"  3. 当前公式: estimated = (point_extent × 100) / R0")
    print(f"     如果point_extent=20m, R0=24000m，则estimated = 2000/24000 = 0.083")
    print(f"     这与实际值 {estimated:.6f} 接近")
    print(f"  4. 但'unified_radius_scale'使用公式: (image_size × scene_scale) / R0")
    print(f"     如果image_size=128, scene_scale=0.1, R0=24000，则unified = 12.8/24000 = 0.000533")
    print(f"     两者差异巨大（{estimated / scale_params.get('unified_radius_scale', 1):.1f}倍）")

print("\n【4. 问题总结】")
print("-"*70)
print("1. unified_radius_scale计算:")
print("   - 公式: (image_size × scene_scale) / R0")
print("   - 问题: 这个公式可能不适合SAR几何，导致值过小")
print("   - 结果: 0.000533（太小，导致相机位置过近）")
print("\n2. estimated_radius_scale计算:")
print("   - 公式: (point_cloud_max_extent × 100) / R0_avg")
print("   - 问题: 公式中'× 100'的系数来源不明，可能不合理")
print("   - 结果: 0.084268（更合理，但公式可能有问题）")
print("\n3. 建议:")
print("   - 应该使用estimated_radius_scale（基于实际点云尺度）")
print("   - 但需要检查公式中的'× 100'是否合理")
print("   - 可能需要根据实际SAR几何重新推导公式")

print("\n" + "="*70)
print("检查完成")
print("="*70)

