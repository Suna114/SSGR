#!/usr/bin/env python3
"""Diagnose shadow/anchor direction consistency in refiner training maps.

The script intentionally uses only the Python standard library so it can run in
minimal environments where the training Python stack is not active.
"""

from __future__ import annotations

import argparse
import csv
import math
import struct
import sys
import zlib
from pathlib import Path


def _paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def _read_png_gray(path: Path) -> tuple[int, int, list[int]]:
    data = path.read_bytes()
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError(f"Not a PNG file: {path}")
    pos = 8
    width = height = color_type = bit_depth = None
    payload = bytearray()
    while pos < len(data):
        length = struct.unpack(">I", data[pos : pos + 4])[0]
        kind = data[pos + 4 : pos + 8]
        chunk = data[pos + 8 : pos + 8 + length]
        pos += 12 + length
        if kind == b"IHDR":
            width, height, bit_depth, color_type, _comp, _filter, interlace = struct.unpack(">IIBBBBB", chunk)
            if interlace != 0:
                raise ValueError(f"Interlaced PNG is unsupported: {path}")
            if bit_depth != 8:
                raise ValueError(f"Only 8-bit PNG is supported: {path}")
        elif kind == b"IDAT":
            payload.extend(chunk)
        elif kind == b"IEND":
            break
    if width is None or height is None or color_type is None:
        raise ValueError(f"Missing PNG header: {path}")

    channels_by_type = {0: 1, 2: 3, 4: 2, 6: 4}
    if color_type not in channels_by_type:
        raise ValueError(f"Unsupported PNG color type {color_type}: {path}")
    channels = channels_by_type[color_type]
    raw = zlib.decompress(bytes(payload))
    stride = int(width) * channels
    rows: list[bytes] = []
    prev = bytearray(stride)
    i = 0
    for _y in range(int(height)):
        filt = raw[i]
        i += 1
        cur = bytearray(raw[i : i + stride])
        i += stride
        for x in range(stride):
            left = cur[x - channels] if x >= channels else 0
            up = prev[x]
            up_left = prev[x - channels] if x >= channels else 0
            if filt == 1:
                cur[x] = (cur[x] + left) & 255
            elif filt == 2:
                cur[x] = (cur[x] + up) & 255
            elif filt == 3:
                cur[x] = (cur[x] + ((left + up) // 2)) & 255
            elif filt == 4:
                cur[x] = (cur[x] + _paeth(left, up, up_left)) & 255
            elif filt != 0:
                raise ValueError(f"Unsupported PNG filter {filt}: {path}")
        rows.append(bytes(cur))
        prev = cur

    gray: list[int] = []
    for row in rows:
        for x in range(0, len(row), channels):
            if color_type == 0:
                gray.append(row[x])
            elif color_type == 4:
                gray.append(row[x])
            else:
                gray.append((int(row[x]) + int(row[x + 1]) + int(row[x + 2])) // 3)
    return int(width), int(height), gray


def _mask_stats(path: Path, threshold: int) -> dict[str, float]:
    width, height, gray = _read_png_gray(path)
    n = 0
    sx = 0.0
    sy = 0.0
    total = 0.0
    max_v = 0
    for idx, value in enumerate(gray):
        if value > max_v:
            max_v = value
        if value > threshold:
            y, x = divmod(idx, width)
            n += 1
            sx += x * value
            sy += y * value
            total += value
    if total <= 0.0:
        return {"n": 0, "x": math.nan, "y": math.nan, "max": float(max_v), "width": width, "height": height}
    return {"n": n, "x": sx / total, "y": sy / total, "max": float(max_v), "width": width, "height": height}


def _angle(dx: float, dy: float) -> float:
    return (math.degrees(math.atan2(dy, dx)) + 360.0) % 360.0


def _fmt(value: float, ndigits: int = 3) -> str:
    if isinstance(value, float) and math.isnan(value):
        return "NA"
    return str(round(float(value), ndigits))


def diagnose(map_dir: Path, csv_path: Path | None = None) -> list[dict[str, float | int | str]]:
    rows = []
    stems = sorted({p.name.split("_gt_anchor_mask.png")[0] for p in map_dir.glob("*_gt_anchor_mask.png")})
    for stem in stems:
        anchor_p = map_dir / f"{stem}_gt_anchor_mask.png"
        gt_p = map_dir / f"{stem}_gt_shadow.png"
        pred_p = map_dir / f"{stem}_pred_shadow.png"
        cand_p = map_dir / f"{stem}_candidate.png"
        if not (anchor_p.exists() and gt_p.exists() and pred_p.exists() and cand_p.exists()):
            continue
        anchor = _mask_stats(anchor_p, 128)
        gt = _mask_stats(gt_p, 5)
        pred = _mask_stats(pred_p, 10)
        cand = _mask_stats(cand_p, 10)
        gt_dx = gt["x"] - anchor["x"] if gt["n"] > 0 and anchor["n"] > 0 else math.nan
        gt_dy = gt["y"] - anchor["y"] if gt["n"] > 0 and anchor["n"] > 0 else math.nan
        pred_dx = pred["x"] - anchor["x"] if pred["n"] > 0 and anchor["n"] > 0 else math.nan
        pred_dy = pred["y"] - anchor["y"] if pred["n"] > 0 and anchor["n"] > 0 else math.nan
        rows.append(
            {
                "stem": stem,
                "anchor_pixels": int(anchor["n"]),
                "gt_pixels": int(gt["n"]),
                "gt_max": int(gt["max"]),
                "gt_dx": gt_dx,
                "gt_dy": gt_dy,
                "gt_angle_deg": _angle(gt_dx, gt_dy) if not math.isnan(gt_dx) else math.nan,
                "pred_pixels": int(pred["n"]),
                "pred_max": int(pred["max"]),
                "pred_dx": pred_dx,
                "pred_dy": pred_dy,
                "pred_angle_deg": _angle(pred_dx, pred_dy) if not math.isnan(pred_dx) else math.nan,
                "candidate_pixels": int(cand["n"]),
            }
        )
    if csv_path:
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else [])
            if rows:
                writer.writeheader()
                writer.writerows(rows)
    return rows


def main() -> int:
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("map_dir", type=Path)
    ap.add_argument("--csv", type=Path, default=None)
    args = ap.parse_args()
    rows = diagnose(args.map_dir, args.csv)
    if not rows:
        print(f"No complete training map groups found in {args.map_dir}")
        return 1
    valid = [r for r in rows if int(r["gt_pixels"]) > 0]
    empty = [r for r in rows if int(r["gt_pixels"]) <= 0]
    sx = sy = total = 0.0
    for r in valid:
        angle = float(r["gt_angle_deg"])
        weight = float(r["gt_pixels"])
        rad = math.radians(angle)
        sx += math.cos(rad) * weight
        sy += math.sin(rad) * weight
        total += weight
    mean = (math.degrees(math.atan2(sy, sx)) + 360.0) % 360.0 if total > 0 else math.nan
    concentration = math.hypot(sx, sy) / total if total > 0 else math.nan
    print(f"groups: {len(rows)}")
    print(f"valid_gt_shadows: {len(valid)}")
    print(f"empty_gt_shadows: {len(empty)}")
    print(f"weighted_mean_gt_direction_deg: {_fmt(mean, 2)}")
    print(f"direction_concentration_R: {_fmt(concentration, 4)}")
    if empty:
        print("empty_gt_rows:")
        for r in empty:
            print(
                "  "
                f"{r['stem']} anchor={r['anchor_pixels']} pred={r['pred_pixels']} "
                f"pred_angle={_fmt(float(r['pred_angle_deg']), 1)} candidate={r['candidate_pixels']}"
            )
    if args.csv:
        print(f"csv: {args.csv}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
