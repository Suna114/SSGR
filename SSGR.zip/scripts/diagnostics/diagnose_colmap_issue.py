# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
诊断COLMAP点云问题
分析点云形状和坐标系统问题
"""
import numpy as np
from scipy.spatial.transform import Rotation as R

def read_colmap_images(images_file):
    """读取COLMAP images.txt文件"""
    images = {}
    with open(images_file, 'r') as f:
        lines = f.readlines()
    
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith('#') or not line:
            i += 1
            continue
        
        parts = line.split()
        if len(parts) >= 10:
            image_id = int(parts[0])
            qw, qx, qy, qz = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
            tx, ty, tz = float(parts[5]), float(parts[6]), float(parts[7])
            camera_id = int(parts[8])
            name = parts[9]
            
            # 转换为旋转矩阵
            quat = np.array([qx, qy, qz, qw])  # scipy使用[x,y,z,w]格式
            rotation = R.from_quat(quat)
            R_matrix = rotation.as_matrix()
            
            # 计算相机位置：C = -R^T * t
            t_vec = np.array([[tx], [ty], [tz]])
            camera_position = -R_matrix.T @ t_vec
            
            images[name] = {
                'image_id': image_id,
                'R': R_matrix,
                't': t_vec,
                'camera_position': camera_position.flatten(),
                'quat': quat
            }
        
        i += 2  # 跳过2D点行
    
    return images

def read_colmap_points(points_file):
    """读取COLMAP points3D.txt文件"""
    points = []
    with open(points_file, 'r') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            
            parts = line.split()
            if len(parts) >= 4:
                point_id = int(parts[0])
                x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
                points.append([point_id, x, y, z])
    
    return np.array(points)

def analyze_coordinate_system(images_file, points_file):
    """分析坐标系统问题"""
    print("=" * 60)
    print("COLMAP坐标系统诊断")
    print("=" * 60)
    
    # 读取数据
    images = read_colmap_images(images_file)
    points = read_colmap_points(points_file)
    
    print(f"\n📊 数据统计:")
    print(f"   - 图像数量: {len(images)}")
    print(f"   - 3D点数量: {len(points)}")
    
    # 分析相机位置
    print(f"\n📷 相机位置分析:")
    camera_positions = []
    for name, data in images.items():
        pos = data['camera_position']
        camera_positions.append(pos)
        print(f"   - {name}: 位置=({pos[0]:.2f}, {pos[1]:.2f}, {pos[2]:.2f}), "
              f"平移t=({data['t'][0,0]:.2f}, {data['t'][1,0]:.2f}, {data['t'][2,0]:.2f})")
    
    camera_positions = np.array(camera_positions)
    print(f"\n   相机位置统计:")
    print(f"   - X范围: [{camera_positions[:, 0].min():.2f}, {camera_positions[:, 0].max():.2f}]")
    print(f"   - Y范围: [{camera_positions[:, 1].min():.2f}, {camera_positions[:, 1].max():.2f}]")
    print(f"   - Z范围: [{camera_positions[:, 2].min():.2f}, {camera_positions[:, 2].max():.2f}]")
    print(f"   - 中心: ({camera_positions[:, 0].mean():.2f}, {camera_positions[:, 1].mean():.2f}, {camera_positions[:, 2].mean():.2f})")
    
    # 分析3D点
    if len(points) > 0:
        point_coords = points[:, 1:4]  # 提取x,y,z坐标
        print(f"\n📦 3D点云分析:")
        print(f"   - X范围: [{point_coords[:, 0].min():.2f}, {point_coords[:, 0].max():.2f}]")
        print(f"   - Y范围: [{point_coords[:, 1].min():.2f}, {point_coords[:, 1].max():.2f}]")
        print(f"   - Z范围: [{point_coords[:, 2].min():.2f}, {point_coords[:, 2].max():.2f}]")
        print(f"   - 中心: ({point_coords[:, 0].mean():.2f}, {point_coords[:, 1].mean():.2f}, {point_coords[:, 2].mean():.2f})")
        
        # 检查异常点
        center = point_coords.mean(axis=0)
        distances = np.linalg.norm(point_coords - center, axis=1)
        mean_dist = distances.mean()
        std_dist = distances.std()
        
        print(f"\n   点云分布:")
        print(f"   - 平均距离中心: {mean_dist:.2f}")
        print(f"   - 标准差: {std_dist:.2f}")
        
        # 找出异常点（距离中心超过3倍标准差）
        outlier_mask = distances > mean_dist + 3 * std_dist
        outliers = points[outlier_mask]
        if len(outliers) > 0:
            print(f"\n   ⚠️ 发现 {len(outliers)} 个异常点（距离中心>3σ）:")
            for outlier in outliers[:10]:  # 只显示前10个
                print(f"     点{int(outlier[0])}: ({outlier[1]:.2f}, {outlier[2]:.2f}, {outlier[3]:.2f}), "
                      f"距离={np.linalg.norm(outlier[1:4] - center):.2f}")
        
        # 象限分析
        print(f"\n   象限分布:")
        q1 = np.sum((point_coords[:, 0] > 0) & (point_coords[:, 1] > 0))
        q2 = np.sum((point_coords[:, 0] < 0) & (point_coords[:, 1] > 0))
        q3 = np.sum((point_coords[:, 0] < 0) & (point_coords[:, 1] < 0))
        q4 = np.sum((point_coords[:, 0] > 0) & (point_coords[:, 1] < 0))
        print(f"   - 第一象限 (X>0, Y>0): {q1} 个点 ({q1/len(points)*100:.1f}%)")
        print(f"   - 第二象限 (X<0, Y>0): {q2} 个点 ({q2/len(points)*100:.1f}%)")
        print(f"   - 第三象限 (X<0, Y<0): {q3} 个点 ({q3/len(points)*100:.1f}%)")
        print(f"   - 第四象限 (X>0, Y<0): {q4} 个点 ({q4/len(points)*100:.1f}%)")
    
    # 检查平移向量的一致性
    print(f"\n🔍 平移向量分析:")
    t_values = []
    for name, data in images.items():
        t = data['t'].flatten()
        t_values.append(t)
    
    t_values = np.array(t_values)
    print(f"   - TX范围: [{t_values[:, 0].min():.2f}, {t_values[:, 0].max():.2f}], "
          f"均值={t_values[:, 0].mean():.2f}, 标准差={t_values[:, 0].std():.2f}")
    print(f"   - TY范围: [{t_values[:, 1].min():.2f}, {t_values[:, 1].max():.2f}], "
          f"均值={t_values[:, 1].mean():.2f}, 标准差={t_values[:, 1].std():.2f}")
    print(f"   - TZ范围: [{t_values[:, 2].min():.2f}, {t_values[:, 2].max():.2f}], "
          f"均值={t_values[:, 2].mean():.2f}, 标准差={t_values[:, 2].std():.2f}")
    
    # 如果所有TZ值都相同，可能是问题
    if t_values[:, 2].std() < 1e-6:
        print(f"\n   ⚠️ 警告: 所有图像的TZ值都相同 ({t_values[0, 2]:.2f})，这可能是坐标系统问题！")
        print(f"   在COLMAP中，平移向量t是从世界坐标系到相机坐标系的平移，")
        print(f"   不应该所有相机都有相同的Z分量。")
    
    print("\n" + "=" * 60)

if __name__ == "__main__":
    images_file = "data/20/sparse/0/images.txt"
    points_file = "data/20/sparse/0/points3D.txt"
    
    analyze_coordinate_system(images_file, points_file)







