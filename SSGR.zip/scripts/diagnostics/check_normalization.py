#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
检查相机和点云的归一化情况

验证：
1. 归一化参数是否被计算
2. 归一化参数是否被应用到相机
3. 归一化参数是否被应用到点云
4. 相机和点云是否使用相同的坐标系统
"""

import numpy as np
import os
import sys
from pathlib import Path

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from scene.colmap_loader import read_extrinsics_binary, read_extrinsics_text, qvec2rotmat
from scene.dataset_readers import readColmapSceneInfo, getNerfppNorm
from utils.graphics_utils import getWorld2View2
from plyfile import PlyData

def check_camera_normalization(source_path):
    """检查相机归一化"""
    print("=" * 60)
    print("检查相机归一化")
    print("=" * 60)
    
    # 读取COLMAP数据
    try:
        cameras_extrinsic_file = os.path.join(source_path, "sparse/0", "images.bin")
        cam_extrinsics = read_extrinsics_binary(cameras_extrinsic_file)
    except:
        cameras_extrinsic_file = os.path.join(source_path, "sparse/0", "images.txt")
        cam_extrinsics = read_extrinsics_text(cameras_extrinsic_file)
    
    try:
        cameras_intrinsic_file = os.path.join(source_path, "sparse/0", "cameras.bin")
        from scene.colmap_loader import read_intrinsics_binary
        cam_intrinsics = read_intrinsics_binary(cameras_intrinsic_file)
    except:
        cameras_intrinsic_file = os.path.join(source_path, "sparse/0", "cameras.txt")
        from scene.colmap_loader import read_intrinsics_text
        cam_intrinsics = read_intrinsics_text(cameras_intrinsic_file)
    
    # 创建CameraInfo列表（简化版）
    from scene.dataset_readers import CameraInfo
    from utils.graphics_utils import focal2fov
    
    cam_infos = []
    for key, extr in cam_extrinsics.items():
        R = np.transpose(qvec2rotmat(extr.qvec))
        T = np.array(extr.tvec)
        intr = cam_intrinsics[extr.camera_id]
        
        if intr.model == "SIMPLE_PINHOLE":
            focal_length_x = intr.params[0]
            FovY = focal2fov(focal_length_x, intr.height)
            FovX = focal2fov(focal_length_x, intr.width)
        elif intr.model == "PINHOLE":
            focal_length_x = intr.params[0]
            focal_length_y = intr.params[1]
            FovY = focal2fov(focal_length_y, intr.height)
            FovX = focal2fov(focal_length_x, intr.width)
        else:
            continue
        
        cam_info = CameraInfo(
            uid=intr.id, R=R, T=T, FovY=FovY, FovX=FovX,
            depth_params=None, image_path="", image_name=extr.name,
            depth_path="", width=intr.width, height=intr.height, is_test=False
        )
        cam_infos.append(cam_info)
    
    # 计算归一化参数
    nerf_normalization = getNerfppNorm(cam_infos)
    print(f"\n归一化参数:")
    print(f"  translate: {nerf_normalization['translate']}")
    print(f"  radius: {nerf_normalization['radius']:.2f}")
    
    # 检查相机是否应用了归一化
    print(f"\n检查相机归一化应用情况:")
    
    # 计算归一化前后的相机中心
    cam_centers_before = []
    cam_centers_after = []
    
    translate = nerf_normalization['translate']
    radius = nerf_normalization['radius']
    scale = 1.0 / radius if radius > 0 else 1.0
    
    for cam_info in cam_infos[:3]:  # 只检查前3个相机
        # 归一化前
        W2C_before = getWorld2View2(cam_info.R, cam_info.T)
        C2W_before = np.linalg.inv(W2C_before)
        center_before = C2W_before[:3, 3]
        cam_centers_before.append(center_before)
        
        # 归一化后（如果应用了归一化）
        W2C_after = getWorld2View2(cam_info.R, cam_info.T, translate, scale)
        C2W_after = np.linalg.inv(W2C_after)
        center_after = C2W_after[:3, 3]
        cam_centers_after.append(center_after)
        
        print(f"\n相机 {cam_info.image_name}:")
        print(f"  归一化前中心: ({center_before[0]:.2f}, {center_before[1]:.2f}, {center_before[2]:.2f})")
        print(f"  归一化后中心: ({center_after[0]:.2f}, {center_after[1]:.2f}, {center_after[2]:.2f})")
        print(f"  距离差异: {np.linalg.norm(center_after - center_before):.2f}")
    
    # 检查实际使用的相机（从Camera类）
    print(f"\n检查实际Camera类使用的参数:")
    print(f"  在loadCam函数中，Camera创建时:")
    print(f"    - trans参数: 未传递（使用默认值 [0.0, 0.0, 0.0]）")
    print(f"    - scale参数: 未传递（使用默认值 1.0）")
    print(f"  ⚠️  结论: 相机没有应用归一化！")
    
    return nerf_normalization, cam_centers_before, cam_centers_after

def check_point_cloud_normalization(source_path, nerf_normalization):
    """检查点云归一化"""
    print("\n" + "=" * 60)
    print("检查点云归一化")
    print("=" * 60)
    
    # 读取初始点云
    ply_path = os.path.join(source_path, "sparse/0/points3D.ply")
    if not os.path.exists(ply_path):
        print(f"❌ 点云文件不存在: {ply_path}")
        return None
    
    plydata = PlyData.read(ply_path)
    vertices = plydata['vertex']
    positions = np.vstack([vertices['x'], vertices['y'], vertices['z']]).T
    
    print(f"\n初始点云统计:")
    print(f"  点数: {len(positions)}")
    print(f"  中心: ({positions.mean(axis=0)[0]:.2f}, {positions.mean(axis=0)[1]:.2f}, {positions.mean(axis=0)[2]:.2f})")
    print(f"  范围: X[{positions[:, 0].min():.2f}, {positions[:, 0].max():.2f}], "
          f"Y[{positions[:, 1].min():.2f}, {positions[:, 1].max():.2f}], "
          f"Z[{positions[:, 2].min():.2f}, {positions[:, 2].max():.2f}]")
    
    # 检查是否应用了归一化
    translate = nerf_normalization['translate']
    radius = nerf_normalization['radius']
    scale = 1.0 / radius if radius > 0 else 1.0
    
    # 归一化后的点云
    positions_normalized = (positions + translate) * scale
    
    print(f"\n归一化参数:")
    print(f"  translate: {translate}")
    print(f"  scale: {scale:.6f}")
    
    print(f"\n归一化后点云统计:")
    print(f"  中心: ({positions_normalized.mean(axis=0)[0]:.2f}, {positions_normalized.mean(axis=0)[1]:.2f}, {positions_normalized.mean(axis=0)[2]:.2f})")
    print(f"  范围: X[{positions_normalized[:, 0].min():.2f}, {positions_normalized[:, 0].max():.2f}], "
          f"Y[{positions_normalized[:, 1].min():.2f}, {positions_normalized[:, 1].max():.2f}], "
          f"Z[{positions_normalized[:, 2].min():.2f}, {positions_normalized[:, 2].max():.2f}]")
    
    print(f"\n检查点云归一化应用情况:")
    print(f"  在create_from_pcd函数中，点云创建时:")
    print(f"    - 直接使用原始点云坐标")
    print(f"    - 没有应用translate和scale")
    print(f"  ⚠️  结论: 点云没有应用归一化！")
    
    return positions, positions_normalized

def main():
    if len(sys.argv) < 2:
        print("用法: python check_normalization.py <source_path>")
        print("示例: python check_normalization.py F:\\3dgs\\gaussian-splatting\\data\\24")
        sys.exit(1)
    
    source_path = sys.argv[1]
    
    # 检查相机归一化
    nerf_normalization, cam_centers_before, cam_centers_after = check_camera_normalization(source_path)
    
    # 检查点云归一化
    positions, positions_normalized = check_point_cloud_normalization(source_path, nerf_normalization)
    
    # 总结
    print("\n" + "=" * 60)
    print("总结")
    print("=" * 60)
    print("1. ✅ 归一化参数已被计算")
    print("2. ❌ 归一化参数未被应用到相机（使用默认值trans=[0,0,0], scale=1.0）")
    print("3. ❌ 归一化参数未被应用到点云（使用原始坐标）")
    print("4. ⚠️  相机和点云都没有应用归一化，理论上应该一致")
    print("\n但是，训练后点云位置异常，可能原因：")
    print("  - Densification过程生成了超出范围的点")
    print("  - 优化过程导致点云位置偏移")
    print("  - 其他训练过程中的问题")

if __name__ == "__main__":
    main()

