#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
检查相机位姿中的方位角是否被正确限制在2°偏差范围内
"""

import json
import re
import sys

def parse_azimuth_from_filename(filename):
    """从文件名中解析方位角"""
    # 例如: T72-15-002 -> 2°
    match = re.search(r'-(\d+)$', filename)
    if match:
        azimuth = int(match.group(1))
        # 处理360度的情况
        if azimuth == 360:
            azimuth = 0
        return azimuth
    return None

def normalize_angle(angle):
    """将角度归一化到[-180, 180]范围"""
    while angle > 180:
        angle -= 360
    while angle < -180:
        angle += 360
    return angle

def angle_diff(angle1, angle2):
    """计算两个角度之间的最小差值（考虑周期性）"""
    diff = normalize_angle(angle1 - angle2)
    return abs(diff)

def main():
    json_file = 'data/29/sfm_results/29/point-clouds/camera_poses.json'
    
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            camera_poses = json.load(f)
    except FileNotFoundError:
        print(f"错误: 找不到文件 {json_file}")
        sys.exit(1)
    
    tolerance = 2.0  # 2度容差
    violations = []
    total_cameras = 0
    valid_cameras = 0
    
    print("=" * 80)
    print("方位角约束检查报告")
    print("=" * 80)
    print(f"容差: ±{tolerance}°")
    print()
    
    for img_name, pose_data in camera_poses.items():
        total_cameras += 1
        
        # 从文件名解析原始方位角
        original_azimuth = parse_azimuth_from_filename(img_name)
        if original_azimuth is None:
            print(f"⚠️  警告: 无法从文件名 {img_name} 解析方位角")
            continue
        
        valid_cameras += 1
        
        # 获取优化后的方位角
        optimized_azimuth = pose_data.get('azimuth_angle')
        if optimized_azimuth is None:
            print(f"⚠️  警告: {img_name} 缺少 azimuth_angle 字段")
            continue
        
        # 计算偏差
        diff = angle_diff(optimized_azimuth, original_azimuth)
        
        # 检查是否违反约束
        if diff > tolerance:
            violations.append({
                'name': img_name,
                'original': original_azimuth,
                'optimized': optimized_azimuth,
                'diff': diff
            })
    
    # 统计结果
    violation_count = len(violations)
    success_count = valid_cameras - violation_count
    success_rate = (success_count / valid_cameras * 100) if valid_cameras > 0 else 0
    
    print(f"总相机数: {total_cameras}")
    print(f"有效相机数: {valid_cameras}")
    print(f"符合约束的相机数: {success_count} ({success_rate:.2f}%)")
    print(f"违反约束的相机数: {violation_count} ({100-success_rate:.2f}%)")
    print()
    
    if violations:
        print("=" * 80)
        print("违反约束的相机列表:")
        print("=" * 80)
        print(f"{'相机名称':<20} {'原始方位角':<12} {'优化方位角':<14} {'偏差':<10} {'状态'}")
        print("-" * 80)
        
        # 按偏差大小排序
        violations.sort(key=lambda x: x['diff'], reverse=True)
        
        for v in violations:
            status = "❌ 超出容差"
            print(f"{v['name']:<20} {v['original']:>6.1f}°      {v['optimized']:>8.2f}°      {v['diff']:>6.2f}°    {status}")
        
        print()
        print(f"最大偏差: {violations[0]['diff']:.2f}°")
        print(f"平均偏差: {sum(v['diff'] for v in violations) / len(violations):.2f}°")
    else:
        print("✅ 所有相机的方位角都在容差范围内！")
    
    print()
    print("=" * 80)
    
    # 返回退出码
    return 0 if violation_count == 0 else 1

if __name__ == '__main__':
    sys.exit(main())

