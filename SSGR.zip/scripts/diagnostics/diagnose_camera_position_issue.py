#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
诊断相机位置不一致问题

比较SFM和GS阶段的R、T值，找出Y坐标符号不一致的原因
"""

import json
import numpy as np
import sys
import os

print("="*70)
print("相机位置不一致问题诊断")
print("="*70)

# 1. 读取SFM相机位姿
sfm_poses_file = "data/25/sfm_results/25/point-clouds/camera_poses.json"
if not os.path.exists(sfm_poses_file):
    print(f"\n❌ SFM相机位姿文件不存在: {sfm_poses_file}")
    sys.exit(1)

with open(sfm_poses_file, 'r') as f:
    sfm_poses = json.load(f)

print(f"\n✅ 读取SFM相机位姿: {len(sfm_poses)} 个相机")

# 2. 读取GS相机参数
gs_cameras_file = "output/1/cameras.json"
if not os.path.exists(gs_cameras_file):
    print(f"\n❌ GS相机参数文件不存在: {gs_cameras_file}")
    sys.exit(1)

with open(gs_cameras_file, 'r') as f:
    gs_cameras = json.load(f)

print(f"✅ 读取GS相机参数: {len(gs_cameras)} 个相机")

# 3. 找到共同的相机
# 注意：SFM使用不带扩展名的名称，GS使用带.jpg扩展名的名称
sfm_names = set(sfm_poses.keys())
gs_names = set()
gs_name_mapping = {}  # GS名称到原始名称的映射

for cam in gs_cameras:
    if 'img_name' in cam:
        gs_full_name = cam['img_name']
        # 去掉扩展名，与SFM名称匹配
        gs_base_name = os.path.splitext(gs_full_name)[0]
        gs_names.add(gs_base_name)
        gs_name_mapping[gs_base_name] = gs_full_name

common_names = sfm_names & gs_names
print(f"\n共同相机数量: {len(common_names)}")

if len(common_names) == 0:
    print("\n⚠️  没有找到共同的相机名称")
    print(f"   SFM相机名称示例: {list(sfm_names)[:3]}")
    print(f"   GS相机名称示例: {list(gs_names)[:3]}")
    sys.exit(1)

# 4. 比较前5个共同相机
print("\n" + "="*70)
print("比较SFM和GS的相机位置和旋转")
print("="*70)

for i, common_name in enumerate(list(common_names)[:5]):
    print(f"\n【相机 {i+1}: {common_name}】")
    print("-"*70)
    
    sfm_pose = sfm_poses[common_name]
    # 使用映射找到GS中的完整名称
    gs_full_name = gs_name_mapping.get(common_name, common_name + '.jpg')
    gs_cam = next((c for c in gs_cameras if c.get('img_name') == gs_full_name), None)
    
    if not gs_cam:
        print("   ⚠️  GS中未找到此相机")
        continue
    
    # SFM位置
    sfm_pos = np.array([sfm_pose.get('tx', 0), sfm_pose.get('ty', 0), sfm_pose.get('tz', 0)])
    print(f"   SFM位置: ({sfm_pos[0]:.2f}, {sfm_pos[1]:.2f}, {sfm_pos[2]:.2f})")
    
    # GS位置
    if 'position' in gs_cam:
        gs_pos = np.array(gs_cam['position'])
        print(f"   GS位置:  ({gs_pos[0]:.2f}, {gs_pos[1]:.2f}, {gs_pos[2]:.2f})")
        
        # 位置差异
        diff = np.linalg.norm(sfm_pos - gs_pos)
        print(f"   位置差异: {diff:.2f}")
        
        # Y坐标符号
        if sfm_pos[1] * gs_pos[1] > 0:
            print(f"   ✅ Y坐标符号一致")
        else:
            print(f"   ❌ Y坐标符号不一致！")
            print(f"      SFM Y: {sfm_pos[1]:.2f} (应该为负)")
            print(f"      GS Y:  {gs_pos[1]:.2f} (应该为负)")
    
    # SFM旋转（如果有）
    if 'rotation' in sfm_pose:
        sfm_rot = np.array(sfm_pose['rotation'])
        print(f"\n   SFM旋转矩阵:")
        print(f"   {sfm_rot}")
    
    # GS旋转
    if 'rotation' in gs_cam:
        gs_rot = np.array(gs_cam['rotation'])
        print(f"\n   GS旋转矩阵:")
        print(f"   {gs_rot}")
        
        # 旋转差异
        if 'rotation' in sfm_pose:
            rot_diff = np.linalg.norm(sfm_rot - gs_rot)
            print(f"\n   旋转差异: {rot_diff:.4f}")

# 5. 分析Y坐标分布
print("\n" + "="*70)
print("Y坐标分布分析")
print("="*70)

sfm_y_coords = []
gs_y_coords = []

for common_name in common_names:
    sfm_pose = sfm_poses[common_name]
    # 使用映射找到GS中的完整名称
    gs_full_name = gs_name_mapping.get(common_name, common_name + '.jpg')
    gs_cam = next((c for c in gs_cameras if c.get('img_name') == gs_full_name), None)
    
    if gs_cam:
        sfm_y = sfm_pose.get('ty', 0)
        gs_y = gs_cam.get('position', [0, 0, 0])[1]
        sfm_y_coords.append(sfm_y)
        gs_y_coords.append(gs_y)

if sfm_y_coords and gs_y_coords:
    print(f"\nSFM Y坐标统计:")
    print(f"  均值: {np.mean(sfm_y_coords):.2f}")
    print(f"  范围: [{np.min(sfm_y_coords):.2f}, {np.max(sfm_y_coords):.2f}]")
    print(f"  负值数量: {sum(1 for y in sfm_y_coords if y < 0)} / {len(sfm_y_coords)}")
    
    print(f"\nGS Y坐标统计:")
    print(f"  均值: {np.mean(gs_y_coords):.2f}")
    print(f"  范围: [{np.min(gs_y_coords):.2f}, {np.max(gs_y_coords):.2f}]")
    print(f"  负值数量: {sum(1 for y in gs_y_coords if y < 0)} / {len(gs_y_coords)}")
    
    # 检查相关性
    correlation = np.corrcoef(sfm_y_coords, gs_y_coords)[0, 1]
    print(f"\nY坐标相关性: {correlation:.4f}")
    
    if correlation < -0.9:
        print("   ✅ 高度负相关，可能是Y轴符号相反")
    elif correlation > 0.9:
        print("   ✅ 高度正相关，Y轴方向一致")
    else:
        print("   ⚠️  相关性较低，可能还有其他问题")

# 6. 总结
print("\n" + "="*70)
print("诊断总结")
print("="*70)

if sfm_y_coords and gs_y_coords:
    sfm_mean_y = np.mean(sfm_y_coords)
    gs_mean_y = np.mean(gs_y_coords)
    
    if sfm_mean_y < 0 and gs_mean_y > 0:
        print("\n❌ 问题确认：Y坐标符号相反")
        print("   - SFM阶段：Y坐标为负（符合COLMAP约定）")
        print("   - GS阶段：Y坐标为正（不符合COLMAP约定）")
        print("\n可能原因：")
        print("   1. GS阶段使用了不同的坐标系")
        print("   2. 在保存cameras.json时进行了坐标系转换")
        print("   3. camera.R和camera.T的值不正确")
        print("\n建议：")
        print("   1. 检查readColmapCameras是否正确读取了SFM输出")
        print("   2. 检查是否有坐标系转换代码")
        print("   3. 检查SAR几何计算是否正确")
    elif sfm_mean_y < 0 and gs_mean_y < 0:
        print("\n✅ Y坐标符号一致（都为负值）")
        print("   但位置差异较大，需要进一步检查")
    else:
        print("\n⚠️  其他问题，需要进一步分析")

print("\n" + "="*70)

