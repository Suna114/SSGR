#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
诊断高斯泼溅点云问题脚本
分析点云分布、相机焦距一致性、以及投影问题
"""

import os
import sys
import numpy as np
import json
from pathlib import Path
import argparse

def read_camera_poses_json(json_file):
    """读取相机位姿JSON文件"""
    with open(json_file, 'r') as f:
        cameras = json.load(f)
    return cameras

def read_pointcloud_ply(ply_file):
    """读取PLY点云文件（使用plyfile库，支持ASCII和二进制格式）"""
    try:
        # 尝试使用plyfile库
        try:
            from plyfile import PlyData
            plydata = PlyData.read(ply_file)
            vertices = plydata['vertex']
            
            # 提取位置（使用与代码库中相同的方法）
            x = vertices['x']
            y = vertices['y']
            z = vertices['z']
            points = np.vstack([x, y, z]).T
            
            # 提取颜色（如果存在）
            try:
                r = vertices['red']
                g = vertices['green']
                b = vertices['blue']
                # 如果颜色是0-1范围，转换为0-255
                if r.max() <= 1.0:
                    colors = np.vstack([r, g, b]).T * 255.0
                    colors = colors.astype(np.uint8)
                else:
                    colors = np.vstack([r, g, b]).T.astype(np.uint8)
            except (KeyError, ValueError):
                # 如果没有颜色信息，使用默认颜色
                colors = np.ones((len(points), 3), dtype=np.uint8) * 128
            
            return points, colors
        except ImportError:
            # 如果plyfile不可用，尝试手动解析ASCII格式
            print("  警告: plyfile库不可用，尝试手动解析ASCII格式...")
            return read_pointcloud_ply_ascii(ply_file)
    except Exception as e:
        print(f"读取PLY文件失败: {e}")
        print(f"  尝试使用ASCII格式解析...")
        try:
            return read_pointcloud_ply_ascii(ply_file)
        except Exception as e2:
            print(f"ASCII格式解析也失败: {e2}")
            print(f"  请确保安装了plyfile库: pip install plyfile")
            return None, None

def read_pointcloud_ply_ascii(ply_file):
    """手动解析ASCII格式的PLY文件"""
    points = []
    colors = []
    
    with open(ply_file, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()
    
    # 查找vertex数量和格式
    vertex_count = 0
    header_end = 0
    is_ascii = False
    
    for i, line in enumerate(lines):
        line_lower = line.lower().strip()
        if 'format ascii' in line_lower:
            is_ascii = True
        if 'element vertex' in line_lower:
            vertex_count = int(line.split()[-1])
        if 'end_header' in line_lower:
            header_end = i + 1
            break
    
    if not is_ascii:
        raise ValueError("PLY文件不是ASCII格式，需要plyfile库来读取二进制格式")
    
    # 读取顶点数据
    for i in range(header_end, header_end + vertex_count):
        if i >= len(lines):
            break
        parts = lines[i].strip().split()
        if len(parts) >= 3:
            try:
                x, y, z = float(parts[0]), float(parts[1]), float(parts[2])
                points.append([x, y, z])
                
                # 尝试读取颜色
                if len(parts) >= 6:
                    r, g, b = int(float(parts[3])), int(float(parts[4])), int(float(parts[5]))
                    colors.append([r, g, b])
                else:
                    colors.append([128, 128, 128])  # 默认灰色
            except (ValueError, IndexError):
                continue
    
    if len(points) == 0:
        raise ValueError("未能读取任何点")
    
    return np.array(points), np.array(colors)

def analyze_camera_focal_lengths(cameras):
    """分析相机焦距的一致性"""
    focal_x_list = []
    focal_y_list = []
    camera_positions = []
    
    for cam in cameras:
        if 'fx' in cam:
            focal_x_list.append(cam['fx'])
            focal_y_list.append(cam['fy'])
        # 尝试多种可能的字段名
        if 'tx' in cam and 'ty' in cam and 'tz' in cam:
            camera_positions.append([cam['tx'], cam['ty'], cam['tz']])
        elif 'T' in cam:
            # 如果T是数组
            T = cam['T']
            if isinstance(T, (list, np.ndarray)) and len(T) >= 3:
                camera_positions.append([T[0], T[1], T[2]])
        elif 'position' in cam:
            pos = cam['position']
            if isinstance(pos, (list, np.ndarray)) and len(pos) >= 3:
                camera_positions.append([pos[0], pos[1], pos[2]])
    
    if not focal_x_list:
        return None
    
    focal_x_array = np.array(focal_x_list)
    focal_y_array = np.array(focal_y_list)
    
    # 确保positions_array的形状正确（即使为空数组）
    if len(camera_positions) > 0:
        positions_array = np.array(camera_positions)
    else:
        positions_array = np.empty((0, 3))  # 空数组，形状为(0, 3)
    
    return {
        'focal_x': {
            'mean': np.mean(focal_x_array),
            'std': np.std(focal_x_array),
            'min': np.min(focal_x_array),
            'max': np.max(focal_x_array),
            'range': np.max(focal_x_array) - np.min(focal_x_array),
            'cv': np.std(focal_x_array) / np.mean(focal_x_array) if np.mean(focal_x_array) > 0 else 0  # 变异系数
        },
        'focal_y': {
            'mean': np.mean(focal_y_array),
            'std': np.std(focal_y_array),
            'min': np.min(focal_y_array),
            'max': np.max(focal_y_array),
            'range': np.max(focal_y_array) - np.min(focal_y_array),
            'cv': np.std(focal_y_array) / np.mean(focal_y_array) if np.mean(focal_y_array) > 0 else 0
        },
        'camera_positions': positions_array
    }

def analyze_pointcloud_distribution(points, colors):
    """分析点云分布"""
    if points is None or len(points) == 0:
        return None
    
    # 计算点云中心
    center = np.mean(points, axis=0)
    
    # 计算到中心的距离
    distances = np.linalg.norm(points - center, axis=1)
    
    # 计算亮度（用于区分目标和背景）
    if colors is not None and len(colors) > 0:
        # 转换为0-1范围
        colors_norm = colors.astype(np.float32) / 255.0
        brightness = 0.299 * colors_norm[:, 0] + 0.587 * colors_norm[:, 1] + 0.114 * colors_norm[:, 2]
    else:
        brightness = None
    
    # 分析Y轴分布（高度分布）
    y_coords = points[:, 1]
    
    # 检查是否形成球状分布
    # 方法：计算点到中心的距离分布，如果大部分点距离中心相似，可能是球状分布
    distance_mean = np.mean(distances)
    distance_std = np.std(distances)
    
    # 检查Y轴负方向是否有开口
    y_negative_count = np.sum(y_coords < 0)
    y_positive_count = np.sum(y_coords > 0)
    
    return {
        'center': center,
        'num_points': len(points),
        'distance_stats': {
            'mean': distance_mean,
            'std': distance_std,
            'min': np.min(distances),
            'max': np.max(distances),
            'cv': distance_std / distance_mean if distance_mean > 0 else 0
        },
        'y_distribution': {
            'mean': np.mean(y_coords),
            'std': np.std(y_coords),
            'min': np.min(y_coords),
            'max': np.max(y_coords),
            'negative_count': y_negative_count,
            'positive_count': y_positive_count,
            'negative_ratio': y_negative_count / len(points) if len(points) > 0 else 0
        },
        'brightness': brightness,
        'points': points,
        'colors': colors
    }

def check_sphere_distribution(points, camera_positions):
    """检查点云和相机是否形成球状分布"""
    if points is None or len(points) == 0:
        return None
    
    # 计算点云中心
    pc_center = np.mean(points, axis=0)
    
    # 计算相机中心
    if camera_positions is not None and len(camera_positions) > 0:
        cam_center = np.mean(camera_positions, axis=0)
    else:
        cam_center = pc_center
    
    # 计算点到中心的距离
    pc_distances = np.linalg.norm(points - pc_center, axis=1)
    
    # 计算相机距离（需要检查数组是否为空）
    if camera_positions is not None and len(camera_positions) > 0:
        cam_distances = np.linalg.norm(camera_positions - cam_center, axis=1)
    else:
        cam_distances = None
    
    # 检查是否形成球状分布
    # 如果距离的标准差相对于均值较小，可能是球状分布
    pc_distance_cv = np.std(pc_distances) / np.mean(pc_distances) if np.mean(pc_distances) > 0 else 0
    
    # 检查Y轴负方向是否有开口
    y_coords = points[:, 1]
    y_negative_ratio = np.sum(y_coords < 0) / len(points) if len(points) > 0 else 0
    
    return {
        'is_sphere_like': pc_distance_cv < 0.3,  # 如果变异系数小于0.3，可能是球状分布
        'distance_cv': pc_distance_cv,
        'y_negative_ratio': y_negative_ratio,
        'has_opening': y_negative_ratio < 0.5,  # 如果Y轴负方向点数少于50%，可能有开口
        'pc_center': pc_center,
        'cam_center': cam_center,
        'pc_mean_distance': np.mean(pc_distances),
        'cam_mean_distance': np.mean(cam_distances) if cam_distances is not None else None
    }

def main():
    parser = argparse.ArgumentParser(description='诊断高斯泼溅点云问题')
    parser.add_argument('--model_path', type=str, required=True,
                       help='模型输出路径（包含cameras.json和point_cloud.ply）')
    parser.add_argument('--iteration', type=int, default=None,
                       help='迭代次数（如果指定，读取iteration_N/point_cloud.ply）')
    args = parser.parse_args()
    
    model_path = args.model_path
    
    print("="*70)
    print("高斯泼溅点云问题诊断")
    print("="*70)
    
    # 1. 读取相机参数
    cameras_json = os.path.join(model_path, "cameras.json")
    if not os.path.exists(cameras_json):
        print(f"❌ 未找到cameras.json: {cameras_json}")
        return
    
    print(f"\n📂 读取相机参数: {cameras_json}")
    cameras = read_camera_poses_json(cameras_json)
    print(f"   相机数量: {len(cameras)}")
    
    # 调试：检查第一个相机的字段
    if len(cameras) > 0:
        print(f"   示例相机字段: {list(cameras[0].keys())[:10]}")
    
    # 2. 分析相机焦距
    print("\n" + "="*70)
    print("📊 相机焦距分析")
    print("="*70)
    focal_stats = analyze_camera_focal_lengths(cameras)
    
    if focal_stats:
        fx_stats = focal_stats['focal_x']
        fy_stats = focal_stats['focal_y']
        
        print(f"\n方位向焦距 (fx):")
        print(f"  均值: {fx_stats['mean']:.2f}")
        print(f"  标准差: {fx_stats['std']:.2f}")
        print(f"  范围: [{fx_stats['min']:.2f}, {fx_stats['max']:.2f}]")
        print(f"  跨度: {fx_stats['range']:.2f}")
        print(f"  变异系数: {fx_stats['cv']:.4f}")
        
        print(f"\n距离向焦距 (fy):")
        print(f"  均值: {fy_stats['mean']:.2f}")
        print(f"  标准差: {fy_stats['std']:.2f}")
        print(f"  范围: [{fy_stats['min']:.2f}, {fy_stats['max']:.2f}]")
        print(f"  跨度: {fy_stats['range']:.2f}")
        print(f"  变异系数: {fy_stats['cv']:.4f}")
        
        # 判断焦距一致性
        fx_cv = fx_stats['cv']
        fy_cv = fy_stats['cv']
        
        if fx_cv > 0.1 or fy_cv > 0.1:
            print(f"\n⚠️  警告：焦距不一致！")
            print(f"   fx变异系数: {fx_cv:.4f} {'(>0.1，不一致)' if fx_cv > 0.1 else ''}")
            print(f"   fy变异系数: {fy_cv:.4f} {'(>0.1，不一致)' if fy_cv > 0.1 else ''}")
            print(f"\n   问题：不同相机的焦距不同，会导致投影不一致")
            print(f"   解决：确保SfM重建时使用了统一的焦距参数")
            print(f"         检查sar_sorc_sfm.py中的unified_focal_azimuth和unified_focal_range设置")
        else:
            print(f"\n✅ 焦距一致性良好（变异系数<0.1）")
    else:
        print("⚠️  无法分析焦距（cameras.json中缺少fx/fy字段）")
    
    # 3. 读取点云
    if args.iteration is not None:
        point_cloud_dir = os.path.join(model_path, "point_cloud", f"iteration_{args.iteration}")
        ply_file = os.path.join(point_cloud_dir, "point_cloud.ply")
        target_ply_file = os.path.join(point_cloud_dir, "point_cloud_target_only.ply")
    else:
        # 尝试查找最新的点云文件
        point_cloud_base_dir = os.path.join(model_path, "point_cloud")
        if os.path.exists(point_cloud_base_dir):
            iterations = []
            for item in os.listdir(point_cloud_base_dir):
                if item.startswith("iteration_") and os.path.isdir(os.path.join(point_cloud_base_dir, item)):
                    try:
                        iter_num = int(item.split("_")[1])
                        iterations.append(iter_num)
                    except:
                        pass
            if iterations:
                latest_iter = max(iterations)
                point_cloud_dir = os.path.join(point_cloud_base_dir, f"iteration_{latest_iter}")
                ply_file = os.path.join(point_cloud_dir, "point_cloud.ply")
                target_ply_file = os.path.join(point_cloud_dir, "point_cloud_target_only.ply")
                print(f"\n📂 使用最新迭代的点云: iteration_{latest_iter}")
            else:
                ply_file = None
                target_ply_file = None
        else:
            ply_file = None
            target_ply_file = None
    
    if ply_file is None or not os.path.exists(ply_file):
        print(f"\n⚠️  未找到点云文件")
        print(f"   请指定--iteration参数或确保点云文件存在")
        return
    
    print(f"\n📂 读取完整点云: {ply_file}")
    points, colors = read_pointcloud_ply(ply_file)
    
    if points is None:
        print("❌ 无法读取点云文件")
        return
    
    print(f"   点数: {len(points)}")
    
    # 读取目标点云（如果存在）
    target_points = None
    if target_ply_file and os.path.exists(target_ply_file):
        print(f"\n📂 读取目标点云: {target_ply_file}")
        target_points, _ = read_pointcloud_ply(target_ply_file)
        if target_points is not None:
            print(f"   目标点数: {len(target_points)} ({100*len(target_points)/len(points):.1f}%)")
        else:
            print("   ⚠️  无法读取目标点云文件")
    else:
        print(f"\n⚠️  未找到目标点云文件: {target_ply_file if target_ply_file else 'N/A'}")
        print(f"   将使用亮度阈值方法分析（可能不准确）")
    
    # 4. 分析点云分布
    print("\n" + "="*70)
    print("📊 点云分布分析")
    print("="*70)
    
    pc_stats = analyze_pointcloud_distribution(points, colors)
    
    if pc_stats:
        print(f"\n点云中心: ({pc_stats['center'][0]:.2f}, {pc_stats['center'][1]:.2f}, {pc_stats['center'][2]:.2f})")
        
        print(f"\n到中心的距离统计:")
        dist_stats = pc_stats['distance_stats']
        print(f"  均值: {dist_stats['mean']:.2f}")
        print(f"  标准差: {dist_stats['std']:.2f}")
        print(f"  范围: [{dist_stats['min']:.2f}, {dist_stats['max']:.2f}]")
        print(f"  变异系数: {dist_stats['cv']:.4f}")
        
        print(f"\nY轴分布（高度分布）:")
        y_stats = pc_stats['y_distribution']
        print(f"  均值: {y_stats['mean']:.2f}")
        print(f"  标准差: {y_stats['std']:.2f}")
        print(f"  范围: [{y_stats['min']:.2f}, {y_stats['max']:.2f}]")
        print(f"  Y<0的点数: {y_stats['negative_count']} ({y_stats['negative_ratio']*100:.1f}%)")
        print(f"  Y>0的点数: {y_stats['positive_count']} ({(1-y_stats['negative_ratio'])*100:.1f}%)")
        
        # 检查球状分布
        camera_positions = focal_stats['camera_positions'] if focal_stats else None
        sphere_check = check_sphere_distribution(points, camera_positions)
        
        print("\n" + "="*70)
        print("🔍 球状分布检查")
        print("="*70)
        
        if sphere_check:
            print(f"\n距离变异系数: {sphere_check['distance_cv']:.4f}")
            print(f"Y轴负方向点数比例: {sphere_check['y_negative_ratio']*100:.1f}%")
            
            if sphere_check['is_sphere_like']:
                print(f"\n⚠️  检测到球状分布！")
                print(f"   问题：点云形成球状分布，可能是由于：")
                print(f"   1. 相机位置在球面上分布（camera_distribution_mode='sphere'）")
                print(f"   2. 焦距与相机位置缩放（radius_scale）不匹配")
                print(f"   3. 投影关系错误导致点云被错误地投影到球面上")
            else:
                print(f"\n✅ 点云分布正常（不是球状分布）")
            
            if sphere_check['has_opening']:
                print(f"\n⚠️  检测到Y轴负方向开口！")
                print(f"   问题：点云在Y轴负方向有开口，相机位置也在Y轴负方向")
                print(f"   原因：这符合COLMAP坐标系约定（高度在Y轴负方向）")
                print(f"         但如果开口过大，可能是投影问题")
            
            if camera_positions is not None:
                print(f"\n相机位置统计:")
                print(f"  相机中心: ({sphere_check['cam_center'][0]:.2f}, {sphere_check['cam_center'][1]:.2f}, {sphere_check['cam_center'][2]:.2f})")
                print(f"  相机平均距离: {sphere_check['cam_mean_distance']:.2f}")
                print(f"  点云平均距离: {sphere_check['pc_mean_distance']:.2f}")
                
                if sphere_check['cam_mean_distance'] is not None:
                    distance_ratio = sphere_check['pc_mean_distance'] / sphere_check['cam_mean_distance'] if sphere_check['cam_mean_distance'] > 0 else 0
                    print(f"  距离比（点云/相机）: {distance_ratio:.4f}")
                    
                    if abs(distance_ratio - 1.0) > 0.5:
                        print(f"\n⚠️  警告：点云和相机距离不匹配！")
                        print(f"   问题：点云距离与相机距离差异过大，可能是投影问题")
        
        # 分析目标点vs背景点分布
        print("\n" + "="*70)
        print("📊 目标点vs背景点分布分析")
        print("="*70)
        
        if target_points is not None and len(target_points) > 0:
            # 使用目标点云文件进行分析（更准确）
            print(f"\n✅ 使用目标点云文件进行分析（基于散射强度划分）")
            
            # 计算目标点到中心的距离
            target_distances = np.linalg.norm(target_points - pc_stats['center'], axis=1)
            
            # 计算背景点（完整点云中不在目标点云中的点）
            # 方法：找到完整点云中距离目标点云最近的点，如果距离很小则认为是目标点
            # 简化方法：使用KD树找到最近邻
            try:
                from scipy.spatial import cKDTree
                target_tree = cKDTree(target_points)
                # 对完整点云中的每个点，找到最近的目标点
                distances_to_target, _ = target_tree.query(points, k=1)
                # 如果距离小于阈值，认为是目标点；否则是背景点
                threshold_distance = 0.01  # 1cm阈值
                is_target = distances_to_target < threshold_distance
                background_points = points[~is_target]
            except ImportError:
                # 如果没有scipy，使用简化方法：假设目标点云是完整点云的子集
                print("   ⚠️  scipy不可用，使用简化方法分析背景点")
                # 简单估算：背景点数量 = 总点数 - 目标点数
                background_points = None
            
            print(f"\n目标点统计:")
            print(f"  目标点数: {len(target_points)} ({100*len(target_points)/len(points):.1f}%)")
            print(f"  到中心距离:")
            print(f"    均值: {np.mean(target_distances):.2f}")
            print(f"    标准差: {np.std(target_distances):.2f}")
            print(f"    范围: [{np.min(target_distances):.2f}, {np.max(target_distances):.2f}]")
            
            if background_points is not None and len(background_points) > 0:
                background_distances = np.linalg.norm(background_points - pc_stats['center'], axis=1)
                print(f"\n背景点统计:")
                print(f"  背景点数: {len(background_points)} ({100*len(background_points)/len(points):.1f}%)")
                print(f"  到中心距离:")
                print(f"    均值: {np.mean(background_distances):.2f}")
                print(f"    标准差: {np.std(background_distances):.2f}")
                print(f"    范围: [{np.min(background_distances):.2f}, {np.max(background_distances):.2f}]")
                
                # 检查目标点是否在外围
                target_mean_dist = np.mean(target_distances)
                background_mean_dist = np.mean(background_distances)
                
                if target_mean_dist > background_mean_dist * 1.2:
                    print(f"\n⚠️  警告：目标点在外围！")
                    print(f"   问题：目标点平均距离 ({target_mean_dist:.2f}) 大于背景点平均距离 ({background_mean_dist:.2f})")
                    print(f"   原因：可能是焦距不一致导致强反射点被错误地投影到外围")
                    print(f"   解决：检查焦距统一化设置（unified_focal_azimuth/unified_focal_range）")
                else:
                    print(f"\n✅ 目标点分布正常（目标点平均距离 {target_mean_dist:.2f} <= 背景点平均距离 {background_mean_dist:.2f}）")
            else:
                # 使用完整点云的距离统计作为背景点参考
                all_distances = pc_stats['distance_stats']
                target_mean_dist = np.mean(target_distances)
                background_mean_dist = all_distances['mean']
                
                print(f"\n背景点统计（估算）:")
                print(f"  背景点数: {len(points) - len(target_points)} ({100*(len(points)-len(target_points))/len(points):.1f}%)")
                print(f"  到中心距离（使用完整点云统计）:")
                print(f"    均值: {background_mean_dist:.2f}")
                
                if target_mean_dist > background_mean_dist * 1.2:
                    print(f"\n⚠️  警告：目标点在外围！")
                    print(f"   问题：目标点平均距离 ({target_mean_dist:.2f}) 大于完整点云平均距离 ({background_mean_dist:.2f})")
                    print(f"   原因：可能是焦距不一致导致强反射点被错误地投影到外围")
                    print(f"   解决：检查焦距统一化设置（unified_focal_azimuth/unified_focal_range）")
        elif pc_stats['brightness'] is not None:
            # 回退到亮度阈值方法（不准确，因为点云可能没有保存颜色）
            print(f"\n⚠️  未找到目标点云文件，使用亮度阈值方法（可能不准确）")
            brightness = pc_stats['brightness']
            bright_threshold = 0.59
            bright_points = brightness > bright_threshold
            dim_points = brightness <= bright_threshold
            
            print(f"\n亮度阈值: {bright_threshold}")
            print(f"高亮点数（可能为目标点）: {np.sum(bright_points)} ({np.sum(bright_points)/len(bright_points)*100:.1f}%)")
            print(f"低亮点数（可能为背景点）: {np.sum(dim_points)} ({np.sum(dim_points)/len(dim_points)*100:.1f}%)")
            
            if np.sum(bright_points) > 0:
                bright_positions = points[bright_points]
                bright_distances = np.linalg.norm(bright_positions - pc_stats['center'], axis=1)
                print(f"\n高亮点到中心距离:")
                print(f"  均值: {np.mean(bright_distances):.2f}")
                print(f"  标准差: {np.std(bright_distances):.2f}")
                print(f"  范围: [{np.min(bright_distances):.2f}, {np.max(bright_distances):.2f}]")
            
            if np.sum(dim_points) > 0:
                dim_positions = points[dim_points]
                dim_distances = np.linalg.norm(dim_positions - pc_stats['center'], axis=1)
                print(f"\n低亮点到中心距离:")
                print(f"  均值: {np.mean(dim_distances):.2f}")
                print(f"  标准差: {np.std(dim_distances):.2f}")
                print(f"  范围: [{np.min(dim_distances):.2f}, {np.max(dim_distances):.2f}]")
            
            # 检查高亮点是否在外围
            if np.sum(bright_points) > 0 and np.sum(dim_points) > 0:
                bright_mean_dist = np.mean(bright_distances)
                dim_mean_dist = np.mean(dim_distances)
                
                if bright_mean_dist > dim_mean_dist * 1.2:
                    print(f"\n⚠️  警告：高亮点（目标点）在外围！")
                    print(f"   问题：高亮点平均距离 ({bright_mean_dist:.2f}) 大于低亮点平均距离 ({dim_mean_dist:.2f})")
                    print(f"   原因：可能是焦距不一致导致强反射点被错误地投影到外围")
                    print(f"   解决：检查焦距统一化设置（unified_focal_azimuth/unified_focal_range）")
        else:
            print(f"\n⚠️  无法分析目标点vs背景点分布（缺少目标点云文件和亮度信息）")
    
    # 5. 总结和建议
    print("\n" + "="*70)
    print("💡 诊断总结和建议")
    print("="*70)
    
    issues = []
    suggestions = []
    
    if focal_stats:
        fx_cv = focal_stats['focal_x']['cv']
        fy_cv = focal_stats['focal_y']['cv']
        if fx_cv > 0.1 or fy_cv > 0.1:
            issues.append("焦距不一致")
            suggestions.append("1. 检查SfM重建时是否使用了统一的焦距参数")
            suggestions.append("2. 确保sar_sorc_sfm.py中正确设置了unified_focal_azimuth和unified_focal_range")
            suggestions.append("3. 检查radius_scale是否与焦距匹配")
    
    if sphere_check and sphere_check['is_sphere_like']:
        issues.append("点云形成球状分布")
        suggestions.append("1. 检查camera_distribution_mode设置（如果使用'sphere'，这是正常的）")
        suggestions.append("2. 检查radius_scale是否与焦距匹配")
        suggestions.append("3. 如果不需要球状分布，可以尝试使用'ring'模式")
    
    if sphere_check and sphere_check['has_opening'] and sphere_check['y_negative_ratio'] < 0.3:
        issues.append("Y轴负方向开口过大")
        suggestions.append("1. 检查相机位置是否都在Y轴负方向（符合COLMAP约定）")
        suggestions.append("2. 如果开口过大，可能是投影问题，检查焦距和相机位置缩放")
    
    # 检查目标点是否在外围（优先使用目标点云文件）
    if target_points is not None and len(target_points) > 0:
        target_distances = np.linalg.norm(target_points - pc_stats['center'], axis=1)
        target_mean_dist = np.mean(target_distances)
        background_mean_dist = pc_stats['distance_stats']['mean']
        
        if target_mean_dist > background_mean_dist * 1.2:
            issues.append("目标点在外围")
            suggestions.append("1. 检查焦距一致性（见上述建议）")
            suggestions.append("2. 检查SAR投影是否正确实现")
            suggestions.append("3. 检查radius_scale是否与焦距匹配")
    elif pc_stats and pc_stats['brightness'] is not None:
        brightness = pc_stats['brightness']
        bright_points = brightness > 0.59
        if np.sum(bright_points) > 0:
            bright_positions = points[bright_points]
            bright_distances = np.linalg.norm(bright_positions - pc_stats['center'], axis=1)
            dim_points = brightness <= 0.59
            if np.sum(dim_points) > 0:
                dim_positions = points[dim_points]
                dim_distances = np.linalg.norm(dim_positions - pc_stats['center'], axis=1)
                if np.mean(bright_distances) > np.mean(dim_distances) * 1.2:
                    issues.append("高亮点（目标点）在外围")
                    suggestions.append("1. 检查焦距一致性（见上述建议）")
                    suggestions.append("2. 检查SAR投影是否正确实现")
                    suggestions.append("3. 考虑使用散射强度掩码过滤背景点")
    
    if issues:
        print(f"\n检测到的问题:")
        for i, issue in enumerate(issues, 1):
            print(f"  {i}. {issue}")
        
        print(f"\n建议的解决方案:")
        for suggestion in suggestions:
            print(f"  {suggestion}")
    else:
        print(f"\n✅ 未检测到明显问题")
        print(f"   点云分布正常，焦距一致，投影关系正确")
    
    print("\n" + "="*70)
    print("诊断完成")
    print("="*70)

if __name__ == '__main__':
    main()

