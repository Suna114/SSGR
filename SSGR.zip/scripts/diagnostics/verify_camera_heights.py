#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
验证相机高度范围脚本
检查SfM重建后的相机高度是否在合理范围内
"""

import os
import sys
import numpy as np
from pathlib import Path

def read_colmap_cameras_text(cameras_file):
    """读取COLMAP cameras.txt文件"""
    cameras = {}
    with open(cameras_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            # cameras.txt格式：camera_id model width height params...
            parts = line.split()
            if len(parts) >= 4:
                camera_id = int(parts[0])
                model = parts[1]
                width = int(parts[2])
                height = int(parts[3])
                params = [float(p) for p in parts[4:]]
                cameras[camera_id] = {
                    'model': model,
                    'width': width,
                    'height': height,
                    'params': params
                }
    return cameras

def read_colmap_images_text(images_file):
    """读取COLMAP images.txt文件"""
    images = {}
    with open(images_file, 'r') as f:
        lines = [l.strip() for l in f if l.strip() and not l.startswith('#')]
    
    # images.txt格式：
    # IMAGE_ID QW QX QY QZ TX TY TZ CAMERA_ID NAME
    # POINTS2D[] as (X, Y, POINT3D_ID)
    i = 0
    while i < len(lines):
        line = lines[i]
        parts = line.split()
        if len(parts) >= 10:
            image_id = int(parts[0])
            qw, qx, qy, qz = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
            tx, ty, tz = float(parts[5]), float(parts[6]), float(parts[7])
            camera_id = int(parts[8])
            name = ' '.join(parts[9:])  # 文件名可能包含空格
            
            images[image_id] = {
                'name': name,
                'qvec': (qw, qx, qy, qz),
                'tvec': (tx, ty, tz),
                'camera_id': camera_id
            }
        i += 2  # 跳过POINTS2D行

    return images

def main():
    print("="*70)
    print("相机高度验证脚本")
    print("="*70)
    
    # 查找数据集路径
    if len(sys.argv) > 1:
        dataset_path = sys.argv[1]
    else:
        # 尝试查找默认路径
        possible_paths = [
            'data',
            '../data',
            '../../data'
        ]
        dataset_path = None
        for p in possible_paths:
            if os.path.exists(p):
                dataset_path = p
                break
        
        if dataset_path is None:
            print("❌ 未找到数据集目录")
            print("   使用方法: python verify_camera_heights.py [dataset_path]")
            return
    
    sparse_path = os.path.join(dataset_path, 'sparse', '0')
    if not os.path.exists(sparse_path):
        print(f"❌ 未找到sparse目录: {sparse_path}")
        print("   请先运行SfM重建")
        return
    
    print(f"\n📂 数据集路径: {dataset_path}")
    print(f"📂 Sparse路径: {sparse_path}")
    
    # 读取cameras.txt和images.txt
    cameras_file = os.path.join(sparse_path, 'cameras.txt')
    images_file = os.path.join(sparse_path, 'images.txt')
    
    if not os.path.exists(cameras_file) or not os.path.exists(images_file):
        print(f"❌ 未找到必要文件:")
        print(f"   cameras.txt: {os.path.exists(cameras_file)}")
        print(f"   images.txt: {os.path.exists(images_file)}")
        return
    
    print(f"\n✅ 读取COLMAP文件...")
    cameras = read_colmap_cameras_text(cameras_file)
    images = read_colmap_images_text(images_file)
    
    print(f"   相机数量: {len(cameras)}")
    print(f"   图像数量: {len(images)}")
    
    if not images:
        print("❌ 未找到图像数据")
        return
    
    # 提取所有相机位置（Y坐标 = 高度）
    heights = []
    positions = []
    for img_id, img_data in images.items():
        tx, ty, tz = img_data['tvec']
        heights.append(ty)
        positions.append((tx, ty, tz))
    
    heights = np.array(heights)
    positions = np.array(positions)
    
    # 统计分析
    print("\n" + "="*70)
    print("📊 相机高度统计")
    print("="*70)
    print(f"相机数量: {len(heights)}")
    print(f"\n高度范围:")
    print(f"  最小值: {heights.min():.2f} m")
    print(f"  最大值: {heights.max():.2f} m")
    print(f"  平均值: {heights.mean():.2f} m")
    print(f"  中位数: {np.median(heights):.2f} m")
    print(f"  标准差: {heights.std():.2f} m")
    print(f"  跨度:   {heights.max() - heights.min():.2f} m")
    
    # 高度分布直方图（文本版）
    print(f"\n高度分布:")
    hist, bin_edges = np.histogram(heights, bins=10)
    for i in range(len(hist)):
        bar = '█' * int(hist[i] / hist.max() * 50)
        print(f"  {bin_edges[i]:8.1f} - {bin_edges[i+1]:8.1f} m: {bar} ({hist[i]})")
    
    # 评估结果
    print("\n" + "="*70)
    print("🎯 评估结果")
    print("="*70)
    
    height_range = heights.max() - heights.min()
    height_std = heights.std()
    
    if height_range < 1000:
        print("❌ 相机高度变化过小 (< 1,000m)")
        print("   问题：高度约束过强，所有相机被限制在相似高度")
        print("   原因：BA中的固定高度约束未正确修改")
        print("\n   建议：")
        print("   1. 检查 comple/convert6.py 第1959行的修改")
        print("   2. 确保使用自适应高度约束")
        print("   3. 删除sparse目录，重新运行SfM")
    elif height_range < 5000:
        print("⚠️  相机高度变化较小 (< 5,000m)")
        print("   状态：高度有一定变化，但可能不够充分")
        print("   建议：检查循环俯视角参数（15°-75°）")
    else:
        print("✅ 相机高度变化正常 (≥ 5,000m)")
        print("   状态：高度约束修复成功！")
        print("   说明：不同图像的相机高度显著不同，可以提供垂直几何信息")
    
    if height_std < 1000:
        print("\n⚠️  高度标准差较小，相机位置可能过于集中")
    else:
        print(f"\n✅ 高度标准差合理 ({height_std:.1f}m)")
    
    # 理论高度对比（假设使用循环俯视角15°-75°）
    print("\n" + "="*70)
    print("📐 理论高度对比（假设camera_height=12,000m）")
    print("="*70)
    print("俯视角 | 理论高度 | 是否在实际范围内")
    print("-" * 70)
    
    camera_height = 12000.0
    test_angles = [15, 30, 45, 60, 75]
    for angle in test_angles:
        dep_rad = np.deg2rad(angle)
        R = camera_height / np.sin(dep_rad)
        expected_height = R * np.cos(dep_rad)
        
        in_range = heights.min() <= expected_height <= heights.max()
        status = "✅" if in_range else "❌"
        print(f"{angle:3d}°    | {expected_height:8.1f}m | {status} {in_range}")
    
    # 检查映射文件
    print("\n" + "="*70)
    print("📋 俯视角映射文件检查")
    print("="*70)
    
    mapping_file = os.path.join(dataset_path, 'depression_angle_mapping.json')
    if os.path.exists(mapping_file):
        import json
        with open(mapping_file, 'r') as f:
            mapping = json.load(f)
        print(f"✅ 找到映射文件: {mapping_file}")
        print(f"   映射数量: {len(mapping)}")
        
        # 统计映射中的俯视角分布
        mapped_angles = list(mapping.values())
        unique_angles = sorted(set(mapped_angles))
        print(f"   俯视角种类: {len(unique_angles)}")
        print(f"   俯视角范围: {min(unique_angles)}° - {max(unique_angles)}°")
        print(f"   示例映射:")
        for i, (img, angle) in enumerate(list(mapping.items())[:5]):
            print(f"     {img}: {angle}°")
    else:
        print(f"⚠️  未找到映射文件: {mapping_file}")
        print("   这意味着SfM未保存循环俯视角映射")
        print("   建议：检查 sfm.py 的修改是否正确")
    
    print("\n" + "="*70)
    print("验证完成")
    print("="*70)
    
    # 总结
    if height_range >= 5000 and os.path.exists(mapping_file):
        print("\n🎉 所有检查通过！可以继续GS训练")
        print("\n下一步:")
        print("  python train.py -s", dataset_path, "-m output/test_fixed")
    else:
        print("\n⚠️  发现问题，请按照上述建议修复")

if __name__ == '__main__':
    main()

