#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
诊断SAR高斯泼溅中的坐标系统问题

分析：
1. SFM生成的相机位姿分布
2. 点云坐标分布
3. 检查是否存在坐标系统不一致的问题
"""

import numpy as np
import os
import sys
from pathlib import Path
from plyfile import PlyData
from scene.colmap_loader import read_extrinsics_binary, read_extrinsics_text, qvec2rotmat

def analyze_camera_poses(source_path):
    """分析相机位姿分布"""
    print("=" * 60)
    print("分析相机位姿分布")
    print("=" * 60)
    
    # 尝试多个可能的路径
    possible_paths = []
    
    # 如果路径已经包含 sparse/0，直接使用
    if "sparse" in source_path and "0" in source_path:
        # 提取到 sparse/0 的路径
        sparse_idx = source_path.find("sparse")
        base_path = source_path[:sparse_idx] if sparse_idx > 0 else source_path
        possible_paths.extend([
            os.path.join(base_path, "sparse", "0", "images.bin"),
            os.path.join(base_path, "sparse", "0", "images.txt"),
            os.path.join(base_path, "sparse/0", "images.bin"),
            os.path.join(base_path, "sparse/0", "images.txt"),
        ])
    else:
        # 标准路径：source_path/sparse/0/
        possible_paths.extend([
            os.path.join(source_path, "sparse", "0", "images.bin"),
            os.path.join(source_path, "sparse", "0", "images.txt"),
            os.path.join(source_path, "sparse/0", "images.bin"),
            os.path.join(source_path, "sparse/0", "images.txt"),
        ])
    
    # 尝试读取
    cam_extrinsics = None
    cameras_extrinsic_file = None
    
    # 先尝试二进制文件
    for path in possible_paths:
        if path.endswith('.bin') and os.path.exists(path):
            try:
                cam_extrinsics = read_extrinsics_binary(path)
                cameras_extrinsic_file = path
                print(f"✅ 从二进制文件读取 {len(cam_extrinsics)} 个相机位姿")
                print(f"   路径: {path}")
                break
            except Exception as e:
                continue
    
    # 如果二进制文件读取失败，尝试文本文件
    if cam_extrinsics is None:
        for path in possible_paths:
            if path.endswith('.txt') and os.path.exists(path):
                try:
                    cam_extrinsics = read_extrinsics_text(path)
                    cameras_extrinsic_file = path
                    print(f"✅ 从文本文件读取 {len(cam_extrinsics)} 个相机位姿")
                    print(f"   路径: {path}")
                    break
                except Exception as e:
                    continue
    
    if cam_extrinsics is None:
        print(f"❌ 无法找到相机位姿文件")
        print(f"   尝试的路径:")
        for path in possible_paths:
            exists = "✓" if os.path.exists(path) else "✗"
            print(f"   {exists} {path}")
        return None, None
    
    # 提取相机位置
    camera_positions = []
    camera_orientations = []
    
    for key, extr in cam_extrinsics.items():
        # COLMAP的qvec是四元数 [w, x, y, z]
        # 注意：在scene/dataset_readers.py中，R = np.transpose(qvec2rotmat(extr.qvec))
        # 所以R已经是转置后的，表示从世界坐标系到相机坐标系的旋转
        R = np.transpose(qvec2rotmat(extr.qvec))  # 转置以符合OpenCV约定
        T = np.array(extr.tvec)
        
        # 计算相机中心位置
        # 在COLMAP中，tvec是从世界坐标系到相机坐标系的平移
        # 相机中心在世界坐标系中：C = -R^T @ T
        # 但由于R已经是转置后的，所以应该是：C = -R @ T
        # 但根据getWorld2View2函数，相机中心计算为：C2W[:3, 3] = -R.T @ T
        # 所以正确的计算应该是：C = -R.T @ T
        # 但R已经是转置后的，所以：C = -R @ T
        # 让我们使用与getNerfppNorm相同的计算方法
        W2C = np.zeros((4, 4))
        W2C[:3, :3] = R.T  # R已经是转置后的，所以这里再转置回来
        W2C[:3, 3] = T
        W2C[3, 3] = 1.0
        C2W = np.linalg.inv(W2C)
        C = C2W[:3, 3]  # 相机中心在世界坐标系中
        
        camera_positions.append(C)
        
        # 计算相机朝向（Z轴方向，指向场景）
        # 相机坐标系中Z轴是前方向，在世界坐标系中的表示是C2W的第三列
        forward = C2W[:3, 2]  # Z轴方向（前方向）
        camera_orientations.append(forward)
    
    camera_positions = np.array(camera_positions)
    camera_orientations = np.array(camera_orientations)
    
    print(f"\n相机位置统计:")
    print(f"  X范围: [{camera_positions[:, 0].min():.2f}, {camera_positions[:, 0].max():.2f}]")
    print(f"  Y范围: [{camera_positions[:, 1].min():.2f}, {camera_positions[:, 1].max():.2f}]")
    print(f"  Z范围: [{camera_positions[:, 2].min():.2f}, {camera_positions[:, 2].max():.2f}]")
    
    # 计算相机到原点的距离
    distances = np.linalg.norm(camera_positions, axis=1)
    print(f"  距离范围: [{distances.min():.2f}, {distances.max():.2f}]")
    print(f"  平均距离: {distances.mean():.2f}")
    
    # 分析方位角分布
    azimuths = np.arctan2(camera_positions[:, 1], camera_positions[:, 0]) * 180 / np.pi
    print(f"\n方位角分布:")
    print(f"  范围: [{azimuths.min():.1f}°, {azimuths.max():.1f}°]")
    
    # 统计各象限的相机数量
    quadrants = {
        'X正Y正 (第一象限)': np.sum((camera_positions[:, 0] >= 0) & (camera_positions[:, 1] >= 0)),
        'X负Y正 (第二象限)': np.sum((camera_positions[:, 0] < 0) & (camera_positions[:, 1] >= 0)),
        'X负Y负 (第三象限)': np.sum((camera_positions[:, 0] < 0) & (camera_positions[:, 1] < 0)),
        'X正Y负 (第四象限)': np.sum((camera_positions[:, 0] >= 0) & (camera_positions[:, 1] < 0)),
    }
    
    print(f"\n各象限相机数量:")
    for quad, count in quadrants.items():
        print(f"  {quad}: {count} ({100*count/len(camera_positions):.1f}%)")
    
    # 检查X轴负方向的相机数量
    x_negative = np.sum(camera_positions[:, 0] < 0)
    print(f"\n⚠️  X轴负方向相机数量: {x_negative} ({100*x_negative/len(camera_positions):.1f}%)")
    if x_negative < len(camera_positions) * 0.2:
        print(f"  ⚠️  警告：X轴负方向相机数量较少，可能导致该方向点云稀疏！")
    
    # 分析Z坐标分布
    z_positive = np.sum(camera_positions[:, 2] > 0)
    z_negative = np.sum(camera_positions[:, 2] < 0)
    print(f"\nZ坐标分布:")
    print(f"  Z > 0: {z_positive} ({100*z_positive/len(camera_positions):.1f}%)")
    print(f"  Z < 0: {z_negative} ({100*z_negative/len(camera_positions):.1f}%)")
    
    # 计算相机朝向（应该指向原点）
    to_origin = -camera_positions
    to_origin = to_origin / np.linalg.norm(to_origin, axis=1, keepdims=True)
    dot_products = np.sum(camera_orientations * to_origin, axis=1)
    print(f"\n相机朝向检查（应该指向原点）:")
    print(f"  平均点积: {dot_products.mean():.3f} (应该接近1.0)")
    print(f"  最小点积: {dot_products.min():.3f}")
    if dot_products.mean() < 0.9:
        print(f"  ⚠️  警告：相机朝向可能不正确！")
    
    return camera_positions, camera_orientations

def analyze_point_cloud(point_cloud_path):
    """分析点云坐标分布"""
    print("\n" + "=" * 60)
    print("分析点云坐标分布")
    print("=" * 60)
    
    if not os.path.exists(point_cloud_path):
        print(f"❌ 点云文件不存在: {point_cloud_path}")
        return None
    
    # 读取PLY文件
    plydata = PlyData.read(point_cloud_path)
    vertices = plydata['vertex']
    positions = np.vstack([vertices['x'], vertices['y'], vertices['z']]).T
    
    print(f"✅ 读取 {len(positions)} 个点")
    
    print(f"\n点云坐标统计:")
    print(f"  X范围: [{positions[:, 0].min():.2f}, {positions[:, 0].max():.2f}]")
    print(f"  Y范围: [{positions[:, 1].min():.2f}, {positions[:, 1].max():.2f}]")
    print(f"  Z范围: [{positions[:, 2].min():.2f}, {positions[:, 2].max():.2f}]")
    
    # 分析各象限的点云数量
    quadrants = {
        'X正Y正 (第一象限)': np.sum((positions[:, 0] >= 0) & (positions[:, 1] >= 0)),
        'X负Y正 (第二象限)': np.sum((positions[:, 0] < 0) & (positions[:, 1] >= 0)),
        'X负Y负 (第三象限)': np.sum((positions[:, 0] < 0) & (positions[:, 1] < 0)),
        'X正Y负 (第四象限)': np.sum((positions[:, 0] >= 0) & (positions[:, 1] < 0)),
    }
    
    print(f"\n各象限点云数量:")
    for quad, count in quadrants.items():
        print(f"  {quad}: {count} ({100*count/len(positions):.1f}%)")
    
    # 检查X轴负方向的点云数量
    x_negative = np.sum(positions[:, 0] < 0)
    print(f"\n⚠️  X轴负方向点云数量: {x_negative} ({100*x_negative/len(positions):.1f}%)")
    
    # 检查Z坐标分布
    z_positive = np.sum(positions[:, 2] > 0)
    z_negative = np.sum(positions[:, 2] < 0)
    z_zero = np.sum(np.abs(positions[:, 2]) < 0.01)
    print(f"\nZ坐标分布:")
    print(f"  Z > 0: {z_positive} ({100*z_positive/len(positions):.1f}%)")
    print(f"  Z < 0: {z_negative} ({100*z_negative/len(positions):.1f}%)")
    print(f"  Z ≈ 0: {z_zero} ({100*z_zero/len(positions):.1f}%)")
    
    # 检查关于XOY面的对称性
    # 对于每个点(x, y, z)，检查是否存在点(x, y, -z)
    print(f"\n检查关于XOY面的对称性:")
    z_values = positions[:, 2]
    z_abs = np.abs(z_values)
    z_positive_count = np.sum(z_values > 0.01)
    z_negative_count = np.sum(z_values < -0.01)
    
    if z_positive_count > 0 and z_negative_count > 0:
        symmetry_ratio = min(z_positive_count, z_negative_count) / max(z_positive_count, z_negative_count)
        print(f"  对称性比例: {symmetry_ratio:.3f} (1.0表示完全对称)")
        if symmetry_ratio > 0.8:
            print(f"  ⚠️  警告：点云关于XOY面大致对称，可能存在坐标系统问题！")
    
    # 检查点云中心
    center = positions.mean(axis=0)
    print(f"\n点云中心: ({center[0]:.2f}, {center[1]:.2f}, {center[2]:.2f})")
    
    return positions

def main():
    if len(sys.argv) < 2:
        print("用法: python diagnose_coordinate_issue.py <source_path> [point_cloud_path]")
        print("      或者: python diagnose_coordinate_issue.py <point_cloud_path>")
        print("")
        print("参数说明:")
        print("  source_path: 包含 sparse/0/ 的目录路径")
        print("    例如: F:\\3dgs\\gaussian-splatting\\data\\24")
        print("  point_cloud_path: 点云PLY文件路径")
        print("")
        print("示例:")
        print("  # 同时分析相机位姿和点云")
        print("  python diagnose_coordinate_issue.py F:\\3dgs\\gaussian-splatting\\data\\24 F:\\3dgs\\gaussian-splatting\\output\\sar_reconstruction\\point_cloud\\iteration_30000\\point_cloud_target_only.ply")
        print("  # 只分析相机位姿")
        print("  python diagnose_coordinate_issue.py F:\\3dgs\\gaussian-splatting\\data\\24")
        print("  # 只分析点云")
        print("  python diagnose_coordinate_issue.py F:\\3dgs\\gaussian-splatting\\output\\sar_reconstruction\\point_cloud\\iteration_30000\\point_cloud_target_only.ply")
        sys.exit(1)
    
    # 判断第一个参数是source_path还是point_cloud_path
    arg1 = sys.argv[1]
    if arg1.endswith('.ply') and os.path.exists(arg1):
        # 第一个参数是点云文件
        source_path = None
        point_cloud_path = arg1
    else:
        # 第一个参数是source_path
        source_path = arg1
        point_cloud_path = sys.argv[2] if len(sys.argv) > 2 else None
    
    # 分析相机位姿（如果提供了source_path）
    camera_positions = None
    camera_orientations = None
    if source_path:
        result = analyze_camera_poses(source_path)
        if result[0] is None:
            print("\n⚠️  无法读取相机位姿，跳过相机位姿分析")
            if point_cloud_path:
                print("   继续分析点云坐标分布...\n")
        else:
            camera_positions, camera_orientations = result
    else:
        print("⚠️  未提供source_path，跳过相机位姿分析")
        print("   只分析点云坐标分布\n")
    
    # 分析点云（如果提供了路径）
    if point_cloud_path:
        point_positions = analyze_point_cloud(point_cloud_path)
        
        # 对比分析（如果同时有相机位姿和点云数据）
        if point_positions is not None and camera_positions is not None:
            print("\n" + "=" * 60)
            print("对比分析")
            print("=" * 60)
            
            # 检查相机位置和点云位置的相对关系
            camera_center = camera_positions.mean(axis=0)
            point_center = point_positions.mean(axis=0)
            
            print(f"相机位置中心: ({camera_center[0]:.2f}, {camera_center[1]:.2f}, {camera_center[2]:.2f})")
            print(f"点云位置中心: ({point_center[0]:.2f}, {point_center[1]:.2f}, {point_center[2]:.2f})")
            
            # 检查点云是否在相机包围的区域内
            camera_radius = np.linalg.norm(camera_positions, axis=1).max()
            point_radius = np.linalg.norm(point_positions, axis=1).max()
            
            print(f"\n相机到原点最大距离: {camera_radius:.2f}")
            print(f"点云到原点最大距离: {point_radius:.2f}")
            
            if point_radius > camera_radius * 1.5:
                print(f"  ⚠️  警告：点云范围超出相机包围区域，可能存在坐标系统问题！")
    
    print("\n" + "=" * 60)
    print("诊断完成")
    print("=" * 60)

if __name__ == "__main__":
    main()

