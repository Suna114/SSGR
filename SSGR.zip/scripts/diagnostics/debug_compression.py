#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
调试压缩逻辑
"""

import numpy as np

def test_compression_logic():
    """测试压缩逻辑是否正确"""

    # 模拟目标点云数据
    # 假设这是一个简单的矩形目标，尺寸为 4m x 2m x 1m (长度x宽度x高度)
    np.random.seed(42)

    # 生成点云：长度方向（X轴）4m，宽度方向（Z轴）2m，高度方向（Y轴）1m
    n_points = 1000
    x_coords = np.random.uniform(-2, 2, n_points)  # X轴: -2 to 2 (长度4m)
    y_coords = np.random.uniform(-0.5, 0.5, n_points)  # Y轴: -0.5 to 0.5 (高度1m)
    z_coords = np.random.uniform(-1, 1, n_points)  # Z轴: -1 to 1 (宽度2m)

    target_points = np.column_stack([x_coords, y_coords, z_coords])

    # 计算原始尺寸
    x_size = x_coords.max() - x_coords.min()
    y_size = y_coords.max() - y_coords.min()
    z_size = z_coords.max() - z_coords.min()

    print("测试压缩逻辑")
    print("="*50)
    print(f"模拟点云: {n_points} 个点")
    print(f"原始尺寸: 长={x_size:.3f}, 宽={z_size:.3f}, 高={y_size:.3f}")
    # 计算几何尺寸
    min_coords = target_points.min(axis=0)
    max_coords = target_points.max(axis=0)
    bbox_size = max_coords - min_coords

    print("\n几何尺寸:")
    print(f"  X范围: {bbox_size[0]:.3f}")
    print(f"  Y范围: {bbox_size[1]:.3f}")
    print(f"  Z范围: {bbox_size[2]:.3f}")

    # 确定长度和宽度（XOZ平面，取较大的作为长度）
    x_size = bbox_size[0]
    z_size = bbox_size[2]

    if x_size >= z_size:
        current_length = x_size
        current_width = z_size
        length_axis = 0  # X轴
        width_axis = 2   # Z轴
        print("几何方向: X-长度，Z-宽度")
    else:
        current_length = z_size
        current_width = x_size
        length_axis = 2  # Z轴
        width_axis = 0   # X轴
        print("几何方向: Z-长度，X-宽度")

    current_height = bbox_size[1]  # Y轴高度
    current_h_l_ratio = abs(current_height) / current_length if current_length > 0 else 0
    current_w_l_ratio = current_width / current_length if current_length > 0 else 0

    print("\n比例:")
    print(f"  当前H/L: {current_h_l_ratio:.4f}")
    print(f"  当前W/L: {current_w_l_ratio:.4f}")

    # 设置目标比例
    target_h_l_ratio = 0.25  # 目标高度/长度比例 (1:4)
    target_w_l_ratio = 0.5   # 目标宽度/长度比例 (1:2)

    print("\n目标比例:")
    print(f"  目标H/L: {target_h_l_ratio:.4f}")
    print(f"  目标W/L: {target_w_l_ratio:.4f}")

    # 检查是否需要压缩
    needs_height_compression = current_h_l_ratio > target_h_l_ratio
    needs_width_compression = current_w_l_ratio > target_w_l_ratio

    print("\n压缩判断:")
    print(f"  高度压缩: {needs_height_compression} ({current_h_l_ratio:.4f} > {target_h_l_ratio:.4f})")
    print(f"  宽度压缩: {needs_width_compression} ({current_w_l_ratio:.4f} > {target_w_l_ratio:.4f})")

    # 计算目标尺寸
    target_height = target_h_l_ratio * current_length
    target_width = target_w_l_ratio * current_length

    print("\n目标尺寸:")
    print(f"  目标高度: {target_height:.3f}")
    print(f"  目标宽度: {target_width:.3f}")
    print(f"  长度保持: {current_length:.3f}")

    # 计算压缩比例
    height_compression_ratio = target_height / abs(current_height) if needs_height_compression else 1.0
    width_compression_ratio = target_width / current_width if needs_width_compression else 1.0

    print("\n压缩比例:")
    print(f"  高度压缩: {height_compression_ratio:.4f}")
    print(f"  宽度压缩: {width_compression_ratio:.4f}")

    # 执行压缩
    print("\n执行压缩:")
    # 计算质心
    y_centroid = np.mean(target_points[:, 1])
    width_centroid = np.mean(target_points[:, width_axis])

    compressed_target_points = target_points.copy()

    # 高度压缩
    if needs_height_compression:
        y_relative = target_points[:, 1] - y_centroid
        compressed_target_points[:, 1] = y_centroid + y_relative * height_compression_ratio
        print(f"  高度压缩: {abs(current_height):.3f} -> {target_height:.3f}")

    # 宽度压缩
    if needs_width_compression:
        width_relative = target_points[:, width_axis] - width_centroid
        compressed_target_points[:, width_axis] = width_centroid + width_relative * width_compression_ratio
        axis_name = 'X' if width_axis == 0 else 'Z'
        print(f"  宽度压缩: {current_width:.3f} -> {target_width:.3f} ({axis_name}轴)")

    # 验证结果
    compressed_min = compressed_target_points.min(axis=0)
    compressed_max = compressed_target_points.max(axis=0)
    compressed_bbox_size = compressed_max - compressed_min

    compressed_height = compressed_bbox_size[1]
    compressed_length = compressed_bbox_size[length_axis]
    compressed_width = compressed_bbox_size[width_axis]

    compressed_h_l_ratio = abs(compressed_height) / compressed_length if compressed_length > 0 else 0
    compressed_w_l_ratio = compressed_width / compressed_length if compressed_length > 0 else 0

    print("\n压缩后结果:")
    print(f"  高度: {abs(compressed_height):.3f}")
    print(f"  长度: {compressed_length:.3f}")
    print(f"  宽度: {compressed_width:.3f}")
    print(f"  H/L比例: {compressed_h_l_ratio:.4f}")
    print(f"  W/L比例: {compressed_w_l_ratio:.4f}")

    print("\n验证:")
    h_match = 1.0 - min(abs(compressed_h_l_ratio - target_h_l_ratio) / target_h_l_ratio, 1.0)
    w_match = 1.0 - min(abs(compressed_w_l_ratio - target_w_l_ratio) / target_w_l_ratio, 1.0)
    print(f"  高度匹配度: {h_match:.1%}")
    print(f"  宽度匹配度: {w_match:.1%}")

if __name__ == "__main__":
    test_compression_logic()
