#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
验证SfM和GS训练阶段的焦距一致性
检查俯视角映射是否正确加载和使用
"""

import os
import json
import numpy as np
import sys

def read_cameras_txt(cameras_file):
    """读取COLMAP的cameras.txt文件"""
    cameras = {}
    with open(cameras_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) >= 5:
                cam_id = int(parts[0])
                model = parts[1]
                width = int(parts[2])
                height = int(parts[3])
                if model == 'PINHOLE':
                    fx = float(parts[4])
                    fy = float(parts[5])
                    cx = float(parts[6])
                    cy = float(parts[7])
                    cameras[cam_id] = {
                        'model': model,
                        'width': width,
                        'height': height,
                        'fx': fx,
                        'fy': fy,
                        'cx': cx,
                        'cy': cy
                    }
                elif model == 'SIMPLE_PINHOLE':
                    f = float(parts[4])
                    cx = float(parts[5])
                    cy = float(parts[6])
                    cameras[cam_id] = {
                        'model': model,
                        'width': width,
                        'height': height,
                        'fx': f,
                        'fy': f,
                        'cx': cx,
                        'cy': cy
                    }
    return cameras

def read_images_txt(images_file):
    """读取COLMAP的images.txt文件"""
    images = []
    with open(images_file, 'r') as f:
        lines = f.readlines()
    
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line or line.startswith('#'):
            i += 1
            continue
        
        parts = line.split()
        if len(parts) >= 10:
            img_id = int(parts[0])
            qw, qx, qy, qz = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
            tx, ty, tz = float(parts[5]), float(parts[6]), float(parts[7])
            cam_id = int(parts[8])
            img_name = parts[9]
            
            images.append({
                'id': img_id,
                'name': img_name,
                'camera_id': cam_id,
                'qvec': [qw, qx, qy, qz],
                'tvec': [tx, ty, tz]
            })
        
        i += 2  # 跳过下一行（关键点数据）
    
    return images

def qvec2rotmat(qvec):
    """四元数转旋转矩阵"""
    qw, qx, qy, qz = qvec
    R = np.array([
        [1 - 2*qy**2 - 2*qz**2, 2*qx*qy - 2*qz*qw, 2*qx*qz + 2*qy*qw],
        [2*qx*qy + 2*qz*qw, 1 - 2*qx**2 - 2*qz**2, 2*qy*qz - 2*qx*qw],
        [2*qx*qz - 2*qy*qw, 2*qy*qz + 2*qx*qw, 1 - 2*qx**2 - 2*qy**2]
    ])
    return R

def get_camera_center(R, t):
    """从R和t计算相机中心"""
    return -R.T @ t

def parse_mstar_filename(filename):
    """从MSTAR文件名解析俯视角和方位角"""
    try:
        # 移除扩展名
        name = os.path.splitext(filename)[0]
        # MSTAR格式: HB01000_17_036
        parts = name.split('_')
        if len(parts) >= 3:
            depression = int(parts[1])
            azimuth = int(parts[2])
            return depression, azimuth
    except:
        pass
    return None, None

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--source_path', '-s', required=True, help='数据集路径')
    args = parser.parse_args()
    
    dataset_path = args.source_path
    sparse_path = os.path.join(dataset_path, 'sparse', '0')
    cameras_file = os.path.join(sparse_path, 'cameras.txt')
    images_file = os.path.join(sparse_path, 'images.txt')
    mapping_file = os.path.join(dataset_path, 'depression_angle_mapping.json')
    
    print("="*80)
    print("焦距一致性验证工具")
    print("="*80)
    print(f"数据集路径: {dataset_path}\n")
    
    # 1. 检查映射文件
    print("【1】检查俯视角映射文件")
    print("-"*80)
    if os.path.exists(mapping_file):
        print(f"✅ 映射文件存在: {mapping_file}")
        with open(mapping_file, 'r') as f:
            mapping = json.load(f)
        print(f"   映射数量: {len(mapping)}")
        
        # 显示前5个映射
        print(f"   前5个映射示例:")
        for i, (img_name, dep_angle) in enumerate(list(mapping.items())[:5]):
            file_dep, file_azi = parse_mstar_filename(img_name)
            status = "✅" if file_dep != dep_angle else "⚠️"
            print(f"     {status} {img_name}: 文件名={file_dep}° → 映射={dep_angle}°")
        
        # 统计俯视角分布
        dep_angles = list(mapping.values())
        unique_angles = sorted(set(dep_angles))
        print(f"\n   俯视角分布:")
        for angle in unique_angles:
            count = dep_angles.count(angle)
            print(f"     {angle}°: {count}张图像")
    else:
        print(f"❌ 映射文件不存在: {mapping_file}")
        print(f"   警告: GS训练将使用文件名俯视角，可能导致焦距不一致！")
        mapping = None
    
    print()
    
    # 2. 读取COLMAP相机参数
    print("【2】检查COLMAP相机参数（SfM结果）")
    print("-"*80)
    if not os.path.exists(cameras_file):
        print(f"❌ cameras.txt不存在: {cameras_file}")
        return
    
    cameras = read_cameras_txt(cameras_file)
    print(f"✅ 读取到 {len(cameras)} 个相机模型")
    
    for cam_id, cam in cameras.items():
        print(f"   相机{cam_id}: {cam['model']}")
        print(f"     尺寸: {cam['width']}x{cam['height']}")
        print(f"     焦距: fx={cam['fx']:.2f}, fy={cam['fy']:.2f}")
        print(f"     主点: cx={cam['cx']:.2f}, cy={cam['cy']:.2f}")
    
    print()
    
    # 3. 读取图像位姿
    print("【3】检查相机位姿和高度")
    print("-"*80)
    if not os.path.exists(images_file):
        print(f"❌ images.txt不存在: {images_file}")
        return
    
    images = read_images_txt(images_file)
    print(f"✅ 读取到 {len(images)} 张图像")
    
    # 计算相机中心和高度
    camera_heights = []
    for img in images[:5]:  # 只显示前5张
        R = qvec2rotmat(img['qvec'])
        t = np.array(img['tvec'])
        center = get_camera_center(R, t)
        height = center[1]  # Y坐标（假设Y轴向上）
        camera_heights.append(height)
        
        file_dep, file_azi = parse_mstar_filename(img['name'])
        mapped_dep = mapping.get(img['name'], None) if mapping else None
        
        print(f"   {img['name']}:")
        print(f"     相机中心: [{center[0]:.2f}, {center[1]:.2f}, {center[2]:.2f}]")
        print(f"     相机高度: {height:.2f} m")
        print(f"     文件名俯视角: {file_dep}°")
        if mapped_dep:
            status = "✅" if file_dep != mapped_dep else "⚠️"
            print(f"     映射俯视角: {mapped_dep}° {status}")
    
    # 统计高度范围
    all_heights = []
    for img in images:
        R = qvec2rotmat(img['qvec'])
        t = np.array(img['tvec'])
        center = get_camera_center(R, t)
        all_heights.append(center[1])
    
    print(f"\n   相机高度统计:")
    print(f"     最小高度: {min(all_heights):.2f} m")
    print(f"     最大高度: {max(all_heights):.2f} m")
    print(f"     平均高度: {np.mean(all_heights):.2f} m")
    print(f"     高度标准差: {np.std(all_heights):.2f} m")
    
    # 判断是否使用了循环俯视角
    height_range = max(all_heights) - min(all_heights)
    if height_range < 1000:
        print(f"   ⚠️  警告: 高度范围很小（{height_range:.2f}m），可能所有相机在同一高度")
        print(f"      这表明可能没有使用循环俯视角，或者BA约束过强")
    else:
        print(f"   ✅ 高度范围正常（{height_range:.2f}m），使用了不同俯视角")
    
    print()
    
    # 4. 模拟GS训练时的焦距计算
    print("【4】模拟GS训练时的焦距计算")
    print("-"*80)
    
    # 需要SAR几何模型
    try:
        from sar_geometry import compute_sar_camera_pose, DEFAULT_SAR_PARAMS
        from sar_utils import parse_mstar_filename as parse_fn
        
        sar_params = DEFAULT_SAR_PARAMS.copy()
        
        # 选择第一张图像进行测试
        test_img = images[0]
        test_cam = cameras[test_img['camera_id']]
        
        print(f"测试图像: {test_img['name']}")
        print(f"SfM焦距: fx={test_cam['fx']:.2f}, fy={test_cam['fy']:.2f}")
        
        # 情况1：使用文件名俯视角（无映射）
        file_dep, file_azi = parse_fn(test_img['name'])
        if file_dep and file_azi:
            R1, T1, K1 = compute_sar_camera_pose(file_dep, file_azi, sar_params)
            print(f"\n情况1: 使用文件名俯视角({file_dep}°)")
            print(f"  计算焦距: fx={K1[0,0]:.2f}, fy={K1[1,1]:.2f}")
            print(f"  与SfM差异: Δfx={abs(K1[0,0]-test_cam['fx']):.2f}, Δfy={abs(K1[1,1]-test_cam['fy']):.2f}")
            if abs(K1[0,0]-test_cam['fx']) > 10:
                print(f"  ❌ 焦距差异过大！会导致点云尺度不一致")
        
        # 情况2：使用映射俯视角
        if mapping and test_img['name'] in mapping:
            mapped_dep = mapping[test_img['name']]
            R2, T2, K2 = compute_sar_camera_pose(mapped_dep, file_azi, sar_params)
            print(f"\n情况2: 使用映射俯视角({mapped_dep}°)")
            print(f"  计算焦距: fx={K2[0,0]:.2f}, fy={K2[1,1]:.2f}")
            print(f"  与SfM差异: Δfx={abs(K2[0,0]-test_cam['fx']):.2f}, Δfy={abs(K2[1,1]-test_cam['fy']):.2f}")
            if abs(K2[0,0]-test_cam['fx']) < 10:
                print(f"  ✅ 焦距一致！使用映射可确保尺度一致")
        
    except ImportError as e:
        print(f"⚠️  无法导入SAR几何模块: {e}")
        print(f"   跳过焦距计算模拟")
    
    print()
    
    # 5. 总结和建议
    print("="*80)
    print("【总结】")
    print("="*80)
    
    issues = []
    if not mapping:
        issues.append("❌ 缺少俯视角映射文件")
    if height_range < 1000:
        issues.append("❌ 相机高度范围异常")
    
    if issues:
        print("发现以下问题:")
        for issue in issues:
            print(f"  {issue}")
        print("\n建议:")
        if not mapping:
            print("  1. 重新运行SfM以生成映射文件:")
            print(f"     python sfm.py --source_path {dataset_path}")
        if height_range < 1000:
            print("  2. 修改comple/convert6.py中的BA约束，放宽高度限制")
    else:
        print("✅ 所有检查通过！")
        print("   - 映射文件存在且正确")
        print("   - 相机高度范围正常")
        print("   - GS训练应能使用一致的焦距")
    
    print("="*80)

if __name__ == '__main__':
    main()



