#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
检查训练时使用的相机数据来源
"""

import os
import json
import sys

def check_camera_source(dataset_path):
    """检查训练时使用的相机数据来源"""
    print("="*70)
    print("检查训练时使用的相机数据来源")
    print("="*70)
    
    print(f"\n数据集路径: {dataset_path}")
    
    # 1. 检查COLMAP文件
    print("\n【1. COLMAP相机数据源】")
    print("-"*70)
    
    sparse_path = os.path.join(dataset_path, "sparse", "0")
    if os.path.exists(sparse_path):
        print(f"✅ 找到sparse目录: {sparse_path}")
        
        # 检查二进制文件
        images_bin = os.path.join(sparse_path, "images.bin")
        cameras_bin = os.path.join(sparse_path, "cameras.bin")
        images_txt = os.path.join(sparse_path, "images.txt")
        cameras_txt = os.path.join(sparse_path, "cameras.txt")
        
        if os.path.exists(images_bin) and os.path.exists(cameras_bin):
            print(f"✅ 使用二进制格式:")
            print(f"   - {images_bin}")
            print(f"   - {cameras_bin}")
            print(f"   说明: 训练时从这些文件读取相机外参和内参")
        elif os.path.exists(images_txt) and os.path.exists(cameras_txt):
            print(f"✅ 使用文本格式:")
            print(f"   - {images_txt}")
            print(f"   - {cameras_txt}")
            print(f"   说明: 训练时从这些文件读取相机外参和内参")
        else:
            print(f"❌ 未找到COLMAP相机文件")
    else:
        print(f"❌ 未找到sparse目录: {sparse_path}")
        print(f"   说明: 训练时无法从COLMAP读取相机数据")
    
    # 2. 检查SAR参数文件
    print("\n【2. SAR参数配置】")
    print("-"*70)
    
    sar_scale_params_file = os.path.join(dataset_path, "sar_scale_params.json")
    if os.path.exists(sar_scale_params_file):
        print(f"✅ 找到SAR尺度参数文件: {sar_scale_params_file}")
        with open(sar_scale_params_file, 'r') as f:
            sar_params = json.load(f)
        
        print(f"\n当前配置:")
        print(f"  unified_radius_scale: {sar_params.get('unified_radius_scale', 'N/A')}")
        print(f"  estimated_radius_scale: {sar_params.get('estimated_radius_scale', 'N/A')}")
        print(f"  unified_focal_azimuth: {sar_params.get('unified_focal_azimuth', 'N/A')}")
        print(f"  unified_focal_range: {sar_params.get('unified_focal_range', 'N/A')}")
        
        # 检查是否使用SAR几何
        print(f"\n说明:")
        print(f"  - 如果启用SAR几何（use_sar_geometry=True），")
        print(f"    训练时会使用这些参数重新计算相机位姿和焦距")
        print(f"  - radius_scale用于计算相机位置")
        print(f"  - unified_focal用于计算焦距")
    else:
        print(f"⚠️  未找到SAR尺度参数文件: {sar_scale_params_file}")
        print(f"   说明: 训练时将使用默认SAR参数")
    
    # 3. 检查训练后保存的cameras.json
    print("\n【3. 训练后保存的相机数据】")
    print("-"*70)
    
    # 尝试查找模型输出目录
    possible_model_paths = [
        "output/1",
        "output/test",
        "output/model"
    ]
    
    found_cameras_json = False
    for model_path in possible_model_paths:
        cameras_json = os.path.join(model_path, "cameras.json")
        if os.path.exists(cameras_json):
            print(f"✅ 找到训练后保存的cameras.json: {cameras_json}")
            with open(cameras_json, 'r') as f:
                cameras = json.load(f)
            
            print(f"   相机数量: {len(cameras)}")
            if len(cameras) > 0:
                fx_list = [c.get('fx', 0) for c in cameras if 'fx' in c]
                if fx_list:
                    fx_mean = sum(fx_list) / len(fx_list)
                    print(f"   焦距均值: {fx_mean:.2f}")
                    print(f"   焦距范围: [{min(fx_list):.2f}, {max(fx_list):.2f}]")
            
            print(f"\n   说明: 这是训练后保存的相机数据，不是训练时读取的源数据")
            found_cameras_json = True
            break
    
    if not found_cameras_json:
        print(f"⚠️  未找到训练后保存的cameras.json")
        print(f"   说明: 可能还没有运行训练，或者模型输出路径不同")
    
    # 4. 总结
    print("\n【4. 训练时相机数据流程】")
    print("-"*70)
    print("1. 从COLMAP文件读取:")
    print("   - sparse/0/images.bin (或images.txt) → 相机外参（位置、旋转）")
    print("   - sparse/0/cameras.bin (或cameras.txt) → 相机内参（焦距、中心点）")
    print("\n2. 如果启用SAR几何（use_sar_geometry=True）:")
    print("   - 读取sar_scale_params.json中的参数")
    print("   - 根据文件名解析俯视角和方位角")
    print("   - 使用compute_sar_camera_pose重新计算:")
    print("     * 相机位置（使用radius_scale）")
    print("     * 相机旋转（指向场景中心）")
    print("     * 焦距（使用unified_focal或从K矩阵计算）")
    print("\n3. 训练后保存:")
    print("   - 保存到output/<model>/cameras.json")
    print("   - 包含实际使用的相机参数（可能是重新计算后的）")
    
    print("\n" + "="*70)
    print("检查完成")
    print("="*70)

if __name__ == '__main__':
    if len(sys.argv) > 1:
        dataset_path = sys.argv[1]
    else:
        dataset_path = "data/25"
    
    check_camera_source(dataset_path)

