#!/usr/bin/env python3
"""Diagnose whether the azimuth shadow refiner follows view azimuths."""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from pathlib import Path

import numpy as np
from PIL import Image

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from scripts.rendering.learn_sar_azimuth_shadow_refiner import (  # noqa: E402
    _input_tensor,
    _load_model,
    _select_pairs,
    _target_mask,
)
from scripts.rendering.learn_sar_image_refiner import _load_image  # noqa: E402


def _angle_diff(a: float, b: float) -> float:
    return abs((float(a) - float(b) + 180.0) % 360.0 - 180.0)


def _read_gray(path: Path) -> np.ndarray:
    im = Image.open(path).convert("L")
    return np.asarray(im, dtype=np.float32) / 255.0


def _save_gray(path: Path, img: np.ndarray) -> None:
    arr = np.clip(img * 255.0, 0.0, 255.0).astype(np.uint8)
    Image.fromarray(arr, mode="L").save(path)


def _weighted_centroid(img: np.ndarray, threshold: float = 0.02) -> tuple[float, float, float, float] | None:
    weight = np.where(img > threshold, img, 0.0).astype(np.float64)
    total = float(weight.sum())
    if total <= 1e-9:
        return None
    yy, xx = np.indices(weight.shape, dtype=np.float64)
    cx = float((xx * weight).sum() / total)
    cy = float((yy * weight).sum() / total)
    area = int(np.count_nonzero(weight > 0.0))
    return cx, cy, total, float(area)


def _direction_from_anchor(anchor: np.ndarray, shadow: np.ndarray, threshold: float = 0.02) -> dict:
    a = _weighted_centroid(anchor, threshold=0.5)
    s = _weighted_centroid(shadow, threshold=threshold)
    if a is None or s is None:
        return {
            "angle_deg": None,
            "dx": None,
            "dy": None,
            "area": 0 if s is None else int(s[3]),
            "mass": 0.0 if s is None else float(s[2]),
        }
    dx = float(s[0] - a[0])
    dy = float(s[1] - a[1])
    if abs(dx) + abs(dy) <= 1e-9:
        angle = None
    else:
        angle = (math.degrees(math.atan2(dy, dx)) + 360.0) % 360.0
    return {
        "angle_deg": angle,
        "dx": dx,
        "dy": dy,
        "area": int(s[3]),
        "mass": float(s[2]),
    }


def _parse_iter(path: Path) -> int | None:
    m = re.match(r"iter_(\d+)_", path.name)
    return int(m.group(1)) if m else None


def _summarize(values: list[float]) -> dict:
    if not values:
        return {"n": 0, "mean": None, "median": None, "max": None}
    arr = np.asarray(values, dtype=np.float64)
    return {
        "n": int(arr.size),
        "mean": float(arr.mean()),
        "median": float(np.median(arr)),
        "max": float(arr.max()),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True, type=Path)
    ap.add_argument("--maps_dir", required=True, type=Path)
    ap.add_argument("--output_dir", required=True, type=Path)
    ap.add_argument("--sweep_pair_index", type=int, default=0)
    ap.add_argument("--sweep_angles", type=str, default="0,30,60,90,120,150,180,210,240,270,300,330")
    ap.add_argument("--device", type=str, default="cuda")
    ap.add_argument("--save_sweep_maps", action=argparse.BooleanOptionalAction, default=True)
    args = ap.parse_args()

    import torch

    ckpt = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    ckpt_args = ckpt.get("args", {})
    ns = argparse.Namespace(**ckpt_args)
    pairs = _select_pairs(Path(ns.train_target_dir), Path(ns.train_gt_dir), ns)
    batch_size = int(getattr(ns, "batch_size", 1) or 1)
    offset = float(getattr(ns, "shadow_direction_offset_deg", 180.0) or 0.0)
    sign = float(getattr(ns, "shadow_direction_sign", 1.0) or 1.0)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for gt_path in sorted(args.maps_dir.glob("iter_*_gt_shadow.png")):
        it = _parse_iter(gt_path)
        if it is None:
            continue
        pair_idx = ((it - 1) * batch_size) % len(pairs)
        pair = pairs[pair_idx]
        az = float(pair["azimuth"]) % 360.0
        expected = (az + offset) % 360.0
        stem = f"iter_{it:06d}"
        anchor = _read_gray(args.maps_dir / f"{stem}_gt_anchor_mask.png")
        candidate = _read_gray(args.maps_dir / f"{stem}_candidate.png")
        pred = _read_gray(args.maps_dir / f"{stem}_pred_shadow.png")
        gt = _read_gray(args.maps_dir / f"{stem}_gt_shadow.png")

        cdir = _direction_from_anchor(anchor, candidate)
        pdir = _direction_from_anchor(anchor, pred)
        gdir = _direction_from_anchor(anchor, gt)
        row = {
            "iteration": it,
            "pair_idx": pair_idx,
            "azimuth": az,
            "expected_shadow_angle": expected,
            "target_path": str(pair["target"]),
            "candidate_angle": cdir["angle_deg"],
            "candidate_area": cdir["area"],
            "candidate_mass": cdir["mass"],
            "candidate_expected_error": None if cdir["angle_deg"] is None else _angle_diff(cdir["angle_deg"], expected),
            "pred_angle": pdir["angle_deg"],
            "pred_area": pdir["area"],
            "pred_mass": pdir["mass"],
            "pred_expected_error": None if pdir["angle_deg"] is None else _angle_diff(pdir["angle_deg"], expected),
            "gt_angle": gdir["angle_deg"],
            "gt_area": gdir["area"],
            "gt_mass": gdir["mass"],
            "gt_expected_error": None if gdir["angle_deg"] is None else _angle_diff(gdir["angle_deg"], expected),
            "pred_gt_error": None
            if pdir["angle_deg"] is None or gdir["angle_deg"] is None
            else _angle_diff(pdir["angle_deg"], gdir["angle_deg"]),
        }
        rows.append(row)

    csv_path = args.output_dir / "azimuth_shadow_direction_diagnostics.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else [])
        if rows:
            writer.writeheader()
            writer.writerows(rows)

    def vals(key: str) -> list[float]:
        return [float(r[key]) for r in rows if r.get(key) is not None]

    summary = {
        "checkpoint": str(args.checkpoint),
        "maps_dir": str(args.maps_dir),
        "num_pairs": len(pairs),
        "num_debug_iterations": len(rows),
        "batch_size": batch_size,
        "shadow_candidate_mode": getattr(ns, "shadow_candidate_mode", None),
        "shadow_direction_offset_deg": offset,
        "shadow_direction_sign": sign,
        "shadow_gt_use_global_direction": getattr(ns, "shadow_gt_use_global_direction", None),
        "shadow_gt_global_direction_deg": getattr(ns, "shadow_gt_global_direction_deg", None),
        "shadow_pred_global_direction_deg": getattr(ns, "shadow_pred_global_direction_deg", None),
        "empty_gt_shadow": [int(r["iteration"]) for r in rows if int(r["gt_area"]) == 0],
        "candidate_expected_error_deg": _summarize(vals("candidate_expected_error")),
        "pred_expected_error_deg": _summarize(vals("pred_expected_error")),
        "gt_expected_error_deg": _summarize(vals("gt_expected_error")),
        "pred_gt_error_deg": _summarize(vals("pred_gt_error")),
    }
    json_path = args.output_dir / "azimuth_shadow_direction_summary.json"
    json_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    sweep_rows = []
    sweep_pair_idx = min(max(int(args.sweep_pair_index), 0), len(pairs) - 1)
    sweep_pair = pairs[sweep_pair_idx]
    device = torch.device(args.device if torch.cuda.is_available() or str(args.device) == "cpu" else "cpu")
    model_args = argparse.Namespace(**ckpt_args)
    setattr(model_args, "checkpoint", str(args.checkpoint))
    setattr(model_args, "device", str(device))
    model = _load_model(model_args, device)
    target = _load_image(sweep_pair["target"], model_args).to(device)
    mask = _target_mask(target, model_args)
    anchor_np = mask.detach().float().cpu().numpy()
    sweep_dir = args.output_dir / "azimuth_sweep_maps"
    if bool(args.save_sweep_maps):
        sweep_dir.mkdir(parents=True, exist_ok=True)
        _save_gray(sweep_dir / "fixed_target_mask.png", anchor_np)
    sweep_angles = [float(x.strip()) for x in str(args.sweep_angles).split(",") if x.strip()]
    for az in sweep_angles:
        x, imaps = _input_tensor(target, mask, az, model_args, in_ch=int(ckpt.get("in_ch", 10)))
        with torch.no_grad():
            pred = torch.sigmoid(model(x[None]))[0, 0] * imaps["candidate"]
        pred_np = pred.detach().float().cpu().numpy()
        cand_np = imaps["candidate"].detach().float().cpu().numpy()
        prior_np = imaps.get("direction_prior", imaps["candidate"]).detach().float().cpu().numpy()
        expected = (az + offset) % 360.0
        pdir = _direction_from_anchor(anchor_np, pred_np)
        cdir = _direction_from_anchor(anchor_np, cand_np)
        ddir = _direction_from_anchor(anchor_np, prior_np)
        stem = f"azimuth_{int(round(az)) % 360:03d}"
        if bool(args.save_sweep_maps):
            _save_gray(sweep_dir / f"{stem}_pred_raw.png", pred_np)
            _save_gray(sweep_dir / f"{stem}_candidate.png", cand_np)
            _save_gray(sweep_dir / f"{stem}_direction_prior.png", prior_np)
        sweep_rows.append({
            "azimuth": az,
            "expected_shadow_angle": expected,
            "pred_angle": pdir["angle_deg"],
            "pred_area": pdir["area"],
            "pred_mass": pdir["mass"],
            "pred_expected_error": None if pdir["angle_deg"] is None else _angle_diff(pdir["angle_deg"], expected),
            "candidate_angle": cdir["angle_deg"],
            "candidate_expected_error": None if cdir["angle_deg"] is None else _angle_diff(cdir["angle_deg"], expected),
            "direction_prior_angle": ddir["angle_deg"],
            "direction_prior_expected_error": None if ddir["angle_deg"] is None else _angle_diff(ddir["angle_deg"], expected),
        })

    sweep_csv = args.output_dir / "azimuth_sweep_fixed_target.csv"
    with sweep_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(sweep_rows[0].keys()) if sweep_rows else [])
        if sweep_rows:
            writer.writeheader()
            writer.writerows(sweep_rows)
    summary["sweep"] = {
        "target_path": str(sweep_pair["target"]),
        "pair_idx": sweep_pair_idx,
        "angles": sweep_angles,
        "pred_expected_error_deg": _summarize([
            float(r["pred_expected_error"]) for r in sweep_rows if r["pred_expected_error"] is not None
        ]),
        "candidate_expected_error_deg": _summarize([
            float(r["candidate_expected_error"]) for r in sweep_rows if r["candidate_expected_error"] is not None
        ]),
        "direction_prior_expected_error_deg": _summarize([
            float(r["direction_prior_expected_error"]) for r in sweep_rows if r["direction_prior_expected_error"] is not None
        ]),
        "csv": str(sweep_csv),
        "maps_dir": str(sweep_dir) if bool(args.save_sweep_maps) else None,
    }
    json_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    print(json.dumps(summary, indent=2, ensure_ascii=False))
    print(f"CSV: {csv_path}")
    print(f"JSON: {json_path}")
    print(f"SWEEP CSV: {sweep_csv}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
