#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
简单检查相机位姿JSON文件中的方位角偏差
"""
import json
import re
import os

def parse_mstar_filename(filename):
    """解析MSTAR文件名，提取方位角"""
    basename = os.path.splitext(filename)[0]
    pattern = r'([A-Za-z0-9]+)-(\d+)-(\d+)'
    match = re.search(pattern, basename)
    if match:
        azimuth_angle = int(match.group(3))
        return azimuth_angle
    return None

def normalize_angle_diff(diff):
    """将角度差归一化到[-180, 180]范围"""
    while diff > 180:
        diff -= 360
    while diff < -180:
        diff += 360
    return diff

# 读取JSON文件
json_path = r'data\29\sfm_results\29\point-clouds\camera_poses.json'
with open(json_path, 'r', encoding='utf-8') as f:
    camera_poses = json.load(f)

print(f"📊 检查方位角偏差（容差=2°）")
print(f"{'='*80}")

results = []
large_deviations = []

for img_name, pose in camera_poses.items():
    # 从文件名解析原始方位角
    original_azimuth = parse_mstar_filename(img_name)
    if original_azimuth is None:
        continue
    
    # 获取优化后的方位角
    optimized_azimuth = pose.get('azimuth_angle', None)
    if optimized_azimuth is None:
        continue
    
    # 计算偏差（考虑360度环绕）
    azimuth_diff = optimized_azimuth - original_azimuth
    azimuth_diff = normalize_angle_diff(azimuth_diff)
    abs_diff = abs(azimuth_diff)
    
    # 检查是否存在180度偏移
    if abs_diff > 90.0:
        alt_original = (original_azimuth + 180) % 360
        alt_diff = optimized_azimuth - alt_original
        alt_diff = normalize_angle_diff(alt_diff)
        alt_abs_diff = abs(alt_diff)
        if alt_abs_diff < abs_diff:
            original_azimuth = alt_original
            azimuth_diff = alt_diff
            abs_diff = alt_abs_diff
            corrected = True
        else:
            corrected = False
    else:
        corrected = False
    
    results.append({
        'img_name': img_name,
        'original': original_azimuth,
        'optimized': optimized_azimuth,
        'deviation': abs_diff,
        'corrected': corrected
    })
    
    if abs_diff > 2.0:
        large_deviations.append({
            'img_name': img_name,
            'original': original_azimuth,
            'optimized': optimized_azimuth,
            'deviation': abs_diff,
            'corrected': corrected
        })

# 统计
deviations = [r['deviation'] for r in results]
mean_dev = sum(deviations) / len(deviations) if deviations else 0.0
max_dev = max(deviations) if deviations else 0.0
min_dev = min(deviations) if deviations else 0.0
median_dev = sorted(deviations)[len(deviations)//2] if deviations else 0.0

num_exceeded = len(large_deviations)
total = len(results)
exceed_ratio = (num_exceeded / total * 100) if total > 0 else 0.0

print(f"\n📈 统计信息:")
print(f"  总图像数: {total}")
print(f"  超过容差(2°)的图像数: {num_exceeded} ({exceed_ratio:.1f}%)")
print(f"  平均偏差: {mean_dev:.2f}°")
print(f"  中位数偏差: {median_dev:.2f}°")
print(f"  最大偏差: {max_dev:.2f}°")
print(f"  最小偏差: {min_dev:.2f}°")

if large_deviations:
    print(f"\n⚠️ 偏差超过2°的图像 ({len(large_deviations)}个):")
    print(f"{'='*80}")
    sorted_deviations = sorted(large_deviations, key=lambda x: x['deviation'], reverse=True)
    for i, dev in enumerate(sorted_deviations):
        corrected_mark = " (180°修正)" if dev['corrected'] else ""
        print(f"  {i+1:2d}. {dev['img_name']:20s} 原始={dev['original']:6.1f}° 优化后={dev['optimized']:6.1f}° 偏差={dev['deviation']:5.1f}°{corrected_mark}")
else:
    print(f"\n✅ 所有图像的方位角偏差都在2°容差范围内！")

# 偏差分布
print(f"\n📊 偏差分布:")
bins = [(0, 1), (1, 2), (2, 5), (5, 10), (10, 20), (20, 90), (90, 180)]
for bin_min, bin_max in bins:
    count = sum(1 for r in results if bin_min <= r['deviation'] < bin_max)
    if count > 0:
        print(f"  {bin_min:3.0f}° - {bin_max:3.0f}°: {count:3d} 个图像 ({count/total*100:.1f}%)")

print(f"\n{'='*80}")

