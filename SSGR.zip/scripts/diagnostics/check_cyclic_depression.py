#!/usr/bin/env python

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
检查循环俯视角模式是否正确使用
"""
import sys
import os

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def check_cyclic_depression_usage():
    """检查循环俯视角模式的使用情况"""
    print("="*60)
    print("检查循环俯视角模式使用情况")
    print("="*60)
    
    # 1. 检查config.py中的参数定义
    print("\n1. 检查config.py中的参数定义:")
    try:
        from config import parse_arguments
        import argparse
        
        # 创建解析器并解析参数
        parser = argparse.ArgumentParser()
        parser.add_argument("--enable_cyclic_depression", action='store_true', default=False,
                           help="启用循环俯视角模式")
        parser.add_argument("--cyclic_depression_start", type=float, default=15.0)
        parser.add_argument("--cyclic_depression_end", type=float, default=45.0)
        parser.add_argument("--cyclic_depression_step", type=float, default=15.0)
        
        # 测试不启用的情况
        args_no_enable = parser.parse_args([])
        print(f"   不启用时: enable_cyclic_depression = {args_no_enable.enable_cyclic_depression}")
        
        # 测试启用的情况
        args_enable = parser.parse_args(['--enable_cyclic_depression'])
        print(f"   启用时: enable_cyclic_depression = {args_enable.enable_cyclic_depression}")
        
        print(f"   参数范围: {args_no_enable.cyclic_depression_start}° - {args_no_enable.cyclic_depression_end}°, 步长: {args_no_enable.cyclic_depression_step}°")
        
    except Exception as e:
        print(f"   ❌ 检查config.py失败: {e}")
    
    # 2. 检查sfm.py中的循环俯视角生成逻辑
    print("\n2. 检查循环俯视角生成逻辑:")
    try:
        # 模拟生成循环俯视角序列
        def generate_cyclic_depression_angles(num_images, start_angle=15, end_angle=45, step=15):
            """生成循环俯视角序列"""
            angles = []
            # 上升序列：15° -> 30° -> 45°
            ascending = list(range(start_angle, end_angle + 1, step))
            # 下降序列：30° -> 15°（不包括起始点15，避免与下一个周期重复）
            descending = list(range(end_angle - step, start_angle, -step))
            
            # 组合成一个周期：[15, 30, 45, 30]
            cycle = ascending + descending
            
            # 循环生成足够的角度
            for i in range(num_images):
                angles.append(cycle[i % len(cycle)])
            
            return angles
        
        # 测试生成38个图像的循环俯视角序列
        test_angles = generate_cyclic_depression_angles(38, start_angle=15, end_angle=45, step=15)
        print(f"   生成38个图像的循环俯视角序列:")
        print(f"   前10个: {test_angles[:10]}")
        print(f"   后10个: {test_angles[-10:]}")
        print(f"   唯一值: {sorted(set(test_angles))}")
        print(f"   序列长度: {len(test_angles)}")
        
        # 检查序列是否正确循环
        if len(set(test_angles)) >= 2:
            print(f"   ✅ 序列包含多个不同的俯视角，循环模式工作正常")
        else:
            print(f"   ⚠️ 序列只包含一个俯视角，可能有问题")
            
    except Exception as e:
        print(f"   ❌ 检查生成逻辑失败: {e}")
        import traceback
        traceback.print_exc()
    
    # 3. 检查sar_sorc_sfm.py中是否正确使用循环俯视角
    print("\n3. 检查SO-RCG求解器中循环俯视角的使用:")
    try:
        from sar_sorc_sfm import SORCG_SAR_SfM
        
        # 创建测试用的image_angles（模拟循环俯视角）
        test_image_angles = {}
        cyclic_angles = generate_cyclic_depression_angles(38, start_angle=15, end_angle=45, step=15)
        for i, img_name in enumerate([f"T72-15-{i:03d}" for i in range(2, 40, 1)]):
            test_image_angles[img_name] = {
                'depression': cyclic_angles[i],
                'azimuth': i * 10
            }
        
        print(f"   测试image_angles（前5个）:")
        for i, (img_name, angles) in enumerate(list(test_image_angles.items())[:5]):
            print(f"     {img_name}: 俯视角={angles['depression']}°, 方位角={angles['azimuth']}°")
        
        # 检查俯视角是否多样化
        dep_values = [angles['depression'] for angles in test_image_angles.values()]
        unique_deps = sorted(set(dep_values))
        print(f"   唯一俯视角值: {unique_deps}")
        
        if len(unique_deps) > 1:
            print(f"   ✅ image_angles包含多样化的俯视角，循环模式应该能正常工作")
        else:
            print(f"   ⚠️ image_angles只包含一个俯视角，循环模式可能未启用")
            
    except Exception as e:
        print(f"   ❌ 检查SO-RCG求解器失败: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "="*60)
    print("检查完成")
    print("="*60)
    print("\n💡 提示:")
    print("   要启用循环俯视角模式，请在命令行中添加: --enable_cyclic_depression")
    print("   例如: python convert.py --enable_cyclic_depression ...")

if __name__ == "__main__":
    check_cyclic_depression_usage()
