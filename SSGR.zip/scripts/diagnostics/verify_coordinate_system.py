#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
验证SFM阶段和GS阶段的坐标系一致性

检查：
1. 矩阵转置的正确性
2. 坐标系约定的一致性
3. 相机位置的Y坐标（应该为负值，表示高度在Y轴负方向）
"""

import json
import numpy as np
from scipy.spatial.transform import Rotation as R
import sys
import os

# 添加路径以导入模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from scene.colmap_loader import qvec2rotmat
    from utils.graphics_utils import getWorld2View2
except ImportError as e:
    print(f"⚠️  无法导入模块: {e}")
    print("   将使用简化版本的函数")
    
    def qvec2rotmat(qvec):
        """简化版本的四元数转旋转矩阵"""
        w, x, y, z = qvec[0], qvec[1], qvec[2], qvec[3]
        return np.array([
            [1 - 2 * (y**2 + z**2), 2 * (x*y - z*w), 2 * (x*z + y*w)],
            [2 * (x*y + z*w), 1 - 2 * (x**2 + z**2), 2 * (y*z - x*w)],
            [2 * (x*z - y*w), 2 * (y*z + x*w), 1 - 2 * (x**2 + y**2)]
        ])

print("="*70)
print("坐标系一致性验证")
print("="*70)

# 1. 验证矩阵转置的正确性
print("\n【1. 矩阵转置验证】")
print("-"*70)

# 创建一个测试四元数（COLMAP格式：w, x, y, z）
test_qvec = np.array([0.707, 0.0, 0.707, 0.0])  # 绕Y轴旋转90度
test_tvec = np.array([1.0, -2.0, 3.0])  # 测试平移向量（Y为负值，表示高度）

print(f"测试四元数（COLMAP格式）: {test_qvec}")
print(f"测试平移向量: {test_tvec}")

# 步骤1：qvec2rotmat
R_world_to_cam = qvec2rotmat(test_qvec)
print(f"\n步骤1 - qvec2rotmat返回:")
print(f"  旋转矩阵（从世界到相机）:")
print(f"  {R_world_to_cam}")

# 步骤2：np.transpose（在readColmapCameras中）
R_cam_to_world = np.transpose(R_world_to_cam)
print(f"\n步骤2 - np.transpose后:")
print(f"  旋转矩阵（从相机到世界）:")
print(f"  {R_cam_to_world}")

# 步骤3：getWorld2View2中的转置
Rt = np.zeros((4, 4))
Rt[:3, :3] = R_cam_to_world.transpose()  # 再次转置
Rt[:3, 3] = test_tvec
Rt[3, 3] = 1.0
print(f"\n步骤3 - getWorld2View2中再次转置后:")
print(f"  视图矩阵（从世界到相机）:")
print(f"  {Rt[:3, :3]}")

# 验证：R_cam_to_world.transpose() 应该等于 R_world_to_cam
if np.allclose(R_cam_to_world.transpose(), R_world_to_cam):
    print(f"\n✅ 矩阵转置正确：R_cam_to_world.transpose() == R_world_to_cam")
else:
    print(f"\n❌ 矩阵转置错误：R_cam_to_world.transpose() != R_world_to_cam")
    print(f"   差异: {np.max(np.abs(R_cam_to_world.transpose() - R_world_to_cam))}")

# 2. 验证坐标系约定
print("\n【2. 坐标系约定验证】")
print("-"*70)

print("COLMAP坐标系约定：")
print("  - X轴：向右（right）")
print("  - Y轴：向下（down）")
print("  - Z轴：向前（forward）")
print("  - 高度：正值在Y轴负方向（即Y坐标为负值表示高度）")

# 检查SFM输出的相机位置
sfm_poses_file = "data/25/sfm_results/25/point-clouds/camera_poses.json"
if os.path.exists(sfm_poses_file):
    try:
        with open(sfm_poses_file, 'r') as f:
            sfm_poses = json.load(f)
        print(f"\n✅ 读取SFM相机位姿: {sfm_poses_file}")
        print(f"   相机数量: {len(sfm_poses)}")
        
        # 检查Y坐标
        y_coords = []
        for img_name, pose in list(sfm_poses.items())[:10]:  # 检查前10个
            ty = pose.get('ty', 0)
            y_coords.append(ty)
            if ty > 0:
                print(f"   ⚠️  警告: {img_name} 的Y坐标为正 ({ty:.2f})，不符合COLMAP约定")
        
        if y_coords:
            print(f"\n   Y坐标统计（前10个相机）:")
            print(f"   均值: {np.mean(y_coords):.2f}")
            print(f"   范围: [{np.min(y_coords):.2f}, {np.max(y_coords):.2f}]")
            if np.mean(y_coords) < 0:
                print(f"   ✅ Y坐标均值为负，符合COLMAP约定（高度在Y轴负方向）")
            else:
                print(f"   ⚠️  Y坐标均值为正，可能不符合COLMAP约定")
    except Exception as e:
        print(f"\n❌ 无法读取SFM相机位姿: {e}")
else:
    print(f"\n⚠️  SFM相机位姿文件不存在: {sfm_poses_file}")

# 3. 验证GS阶段的坐标系
print("\n【3. GS阶段坐标系验证】")
print("-"*70)

gs_cameras_file = "output/1/cameras.json"
if os.path.exists(gs_cameras_file):
    try:
        with open(gs_cameras_file, 'r') as f:
            gs_cameras = json.load(f)
        print(f"\n✅ 读取GS相机参数: {gs_cameras_file}")
        print(f"   相机数量: {len(gs_cameras)}")
        
        # 检查Y坐标
        y_coords_gs = []
        for cam in gs_cameras[:10]:  # 检查前10个
            if 'position' in cam:
                ty = cam['position'][1]
                y_coords_gs.append(ty)
                if ty > 0:
                    print(f"   ⚠️  警告: {cam.get('img_name', 'N/A')} 的Y坐标为正 ({ty:.2f})")
        
        if y_coords_gs:
            print(f"\n   Y坐标统计（前10个相机）:")
            print(f"   均值: {np.mean(y_coords_gs):.2f}")
            print(f"   范围: [{np.min(y_coords_gs):.2f}, {np.max(y_coords_gs):.2f}]")
            if np.mean(y_coords_gs) < 0:
                print(f"   ✅ Y坐标均值为负，符合COLMAP约定")
            else:
                print(f"   ⚠️  Y坐标均值为正，可能不符合COLMAP约定")
    except Exception as e:
        print(f"\n❌ 无法读取GS相机参数: {e}")
else:
    print(f"\n⚠️  GS相机参数文件不存在: {gs_cameras_file}")

# 4. 比较SFM和GS的坐标系
print("\n【4. SFM与GS坐标系比较】")
print("-"*70)

if os.path.exists(sfm_poses_file) and os.path.exists(gs_cameras_file):
    try:
        with open(sfm_poses_file, 'r') as f:
            sfm_poses = json.load(f)
        with open(gs_cameras_file, 'r') as f:
            gs_cameras = json.load(f)
        
        # 找到共同的相机
        sfm_names = set(sfm_poses.keys())
        gs_names = set()
        for cam in gs_cameras:
            if 'img_name' in cam:
                gs_names.add(cam['img_name'])
        
        common_names = sfm_names & gs_names
        if common_names:
            print(f"   共同相机数量: {len(common_names)}")
            
            # 比较第一个共同相机
            common_name = list(common_names)[0]
            sfm_pose = sfm_poses[common_name]
            gs_cam = next((c for c in gs_cameras if c.get('img_name') == common_name), None)
            
            if gs_cam:
                print(f"\n   示例相机: {common_name}")
                
                # 比较位置
                sfm_pos = np.array([sfm_pose.get('tx', 0), sfm_pose.get('ty', 0), sfm_pose.get('tz', 0)])
                if 'position' in gs_cam:
                    gs_pos = np.array(gs_cam['position'])
                    print(f"   SFM位置: ({sfm_pos[0]:.2f}, {sfm_pos[1]:.2f}, {sfm_pos[2]:.2f})")
                    print(f"   GS位置:  ({gs_pos[0]:.2f}, {gs_pos[1]:.2f}, {gs_pos[2]:.2f})")
                    diff = np.linalg.norm(sfm_pos - gs_pos)
                    print(f"   位置差异: {diff:.2f}")
                    
                    if diff < 0.01:
                        print("   ✅ 位置一致（坐标系一致）")
                    else:
                        print("   ⚠️  位置不一致（可能坐标系不同或数据来源不同）")
                        
                    # 检查Y坐标符号
                    if sfm_pos[1] * gs_pos[1] > 0:
                        print("   ✅ Y坐标符号一致")
                    else:
                        print("   ⚠️  Y坐标符号不一致（可能坐标系不同）")
        else:
            print("   ⚠️  没有找到共同的相机名称")
    except Exception as e:
        print(f"   ❌ 比较失败: {e}")
else:
    print("   ⚠️  无法比较：缺少SFM或GS的相机数据")

# 5. 总结
print("\n" + "="*70)
print("验证总结")
print("="*70)
print("\n【矩阵转置流程】")
print("  1. qvec2rotmat(qvec) → R_world_to_cam")
print("  2. np.transpose(R_world_to_cam) → R_cam_to_world")
print("  3. getWorld2View2中: R_cam_to_world.transpose() → R_world_to_cam")
print("  ✅ 最终得到视图矩阵所需的'从世界到相机'旋转")
print("\n【坐标系约定】")
print("  - SFM阶段：使用COLMAP坐标系 ✅")
print("  - GS阶段：读取COLMAP格式，使用COLMAP坐标系 ✅")
print("  - 理论上应该一致 ✅")
print("\n【建议】")
print("  - 如果发现Y坐标符号不一致，需要检查坐标系转换")
print("  - 如果位置差异很大，需要检查数据来源是否一致")
print("\n" + "="*70)

