# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""检查GS训练后点云的Z方向展开情况"""
from plyfile import PlyData
import numpy as np
import sys
import os

def check_point_cloud_z_extent(ply_path):
    """检查点云的Z方向展开情况"""
    if not os.path.exists(ply_path):
        print(f"❌ 错误：文件不存在: {ply_path}")
        return
    
    print(f"\n{'='*70}")
    print(f"点云Z方向展开检查")
    print(f"{'='*70}\n")
    print(f"文件: {ply_path}\n")
    
    # 读取点云
    ply = PlyData.read(ply_path)
    xyz = np.vstack([ply['vertex']['x'], ply['vertex']['y'], ply['vertex']['z']]).T
    
    # 计算各方向范围
    x_min, x_max = xyz[:, 0].min(), xyz[:, 0].max()
    y_min, y_max = xyz[:, 1].min(), xyz[:, 1].max()
    z_min, z_max = xyz[:, 2].min(), xyz[:, 2].max()
    
    x_range = x_max - x_min
    y_range = y_max - y_min
    z_range = z_max - z_min
    
    # 计算标准差
    x_std = xyz[:, 0].std()
    y_std = xyz[:, 1].std()
    z_std = xyz[:, 2].std()
    
    print(f"【点云范围】")
    print(f"  X (方位向): {x_range:.2f}米  [{x_min:.2f}, {x_max:.2f}]")
    print(f"  Y (距离向): {y_range:.2f}米  [{y_min:.2f}, {y_max:.2f}]")
    print(f"  Z (高度向): {z_range:.2f}米  [{z_min:.2f}, {z_max:.2f}]  ⚠️\n")
    
    print(f"【标准差】")
    print(f"  X: {x_std:.3f}")
    print(f"  Y: {y_std:.3f}")
    print(f"  Z: {z_std:.3f}  ⚠️\n")
    
    print(f"【比例分析】")
    xy_avg = (x_range + y_range) / 2
    z_ratio_x = z_range / x_range if x_range > 0 else 0
    z_ratio_y = z_range / y_range if y_range > 0 else 0
    z_ratio_xy = z_range / xy_avg if xy_avg > 0 else 0
    
    print(f"  Z/X: {z_ratio_x:.1%}")
    print(f"  Z/Y: {z_ratio_y:.1%}")
    print(f"  Z/XY平均: {z_ratio_xy:.1%}\n")
    
    # 诊断
    print(f"{'='*70}")
    print(f"【诊断结果】")
    print(f"{'='*70}\n")
    
    if z_range < 0.5:
        print("🔴 严重塌陷！Z方向几乎没有厚度")
        print(f"   Z范围: {z_range:.2f}米 < 0.5米")
        print(f"\n【建议】")
        print(f"  1. 增加shape_constraint_weight到 0.5 或更高")
        print(f"  2. 增加min_z_var到 0.5")
        print(f"  3. 提前约束开始到第100迭代")
        status = "严重塌陷"
    elif z_range < 1.0:
        print("🔴 严重塌陷！Z方向展开不足")
        print(f"   Z范围: {z_range:.2f}米 < 1.0米")
        print(f"\n【建议】")
        print(f"  1. 增加shape_constraint_weight到 0.3")
        print(f"  2. 检查train.py是否正确约束Z坐标（xyz[:, 2]）")
        status = "塌陷"
    elif z_range < 2.0:
        print("🟡 轻微塌陷：Z方向展开不够")
        print(f"   Z范围: {z_range:.2f}米，期望 > 2米")
        print(f"\n【建议】")
        print(f"  1. shape_constraint_weight当前可能足够")
        print(f"  2. 继续训练观察")
        print(f"  3. 或微调weight到 0.15-0.2")
        status = "轻微塌陷"
    else:
        if z_ratio_xy < 0.10:  # Z方向应该至少是XY平均的10%
            print("🟡 形状异常：Z方向相对XY太小")
            print(f"   Z/XY比例: {z_ratio_xy:.1%} < 10%")
            print(f"\n【建议】")
            print(f"  1. Z方向绝对值尚可，但相对XY偏小")
            print(f"  2. 如果是坦克等扁平目标，可能正常")
            print(f"  3. 否则考虑增加shape_constraint")
            status = "相对扁平"
        else:
            print("✅ Z方向展开正常！")
            print(f"   Z范围: {z_range:.2f}米 > 2米")
            print(f"   Z/XY比例: {z_ratio_xy:.1%}")
            print(f"\n【形状】合理的3D结构")
            status = "正常"
    
    print(f"\n{'='*70}\n")
    return {
        'x_range': x_range,
        'y_range': y_range,
        'z_range': z_range,
        'z_ratio': z_ratio_xy,
        'status': status
    }


if __name__ == "__main__":
    if len(sys.argv) > 1:
        ply_path = sys.argv[1]
    else:
        # 默认检查最新的训练结果
        import glob
        candidates = glob.glob("output/*/point_cloud/iteration_*/point_cloud.ply")
        if not candidates:
            print("❌ 未找到点云文件")
            print("\n用法:")
            print("  python check_z_extent.py <ply文件路径>")
            print("\n或将训练结果放在 output/ 目录下")
            sys.exit(1)
        
        # 找到最新的
        ply_path = max(candidates, key=os.path.getmtime)
        print(f"自动检测到最新点云: {ply_path}")
    
    result = check_point_cloud_z_extent(ply_path)
    
    # 如果有多个checkpoint，都检查
    if len(sys.argv) == 1:
        import glob
        output_dir = os.path.dirname(os.path.dirname(ply_path))
        all_plys = sorted(glob.glob(f"{output_dir}/point_cloud/iteration_*/point_cloud.ply"))
        
        if len(all_plys) > 1:
            print("\n" + "="*70)
            print("所有迭代的Z范围变化:")
            print("="*70 + "\n")
            
            for ply in all_plys:
                iter_num = os.path.basename(os.path.dirname(ply)).split('_')[1]
                ply_data = PlyData.read(ply)
                xyz = np.vstack([ply_data['vertex']['x'], 
                               ply_data['vertex']['y'], 
                               ply_data['vertex']['z']]).T
                z_range = xyz[:, 2].max() - xyz[:, 2].min()
                print(f"  迭代 {iter_num:>6s}: Z范围 = {z_range:6.2f}米")
            
            print("\n")

