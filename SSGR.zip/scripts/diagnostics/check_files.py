#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""快速检查文件并显示尺寸信息"""

import os
import sys

pointcloud_path = r"F:\3dgs\gaussian-splatting\output\V4\point_cloud\iteration_30000\point_cloud_target_only_compressed.ply"
model_path = r"F:\raysar\T-72.obj"

print("=" * 60)
print("检查文件...")
print("=" * 60)

# 检查文件是否存在
if os.path.exists(pointcloud_path):
    print(f"✅ 点云文件存在: {pointcloud_path}")
    size = os.path.getsize(pointcloud_path) / (1024 * 1024)  # MB
    print(f"   文件大小: {size:.2f} MB")
else:
    print(f"❌ 点云文件不存在: {pointcloud_path}")
    sys.exit(1)

if os.path.exists(model_path):
    print(f"✅ 模型文件存在: {model_path}")
    size = os.path.getsize(model_path) / (1024 * 1024)  # MB
    print(f"   文件大小: {size:.2f} MB")
else:
    print(f"❌ 模型文件不存在: {model_path}")
    sys.exit(1)

print("\n" + "=" * 60)
print("尝试加载文件...")
print("=" * 60)

try:
    import numpy as np
    import open3d as o3d
    
    # 加载点云
    print("\n📂 加载点云...")
    pcd = o3d.io.read_point_cloud(pointcloud_path)
    print(f"   ✅ 成功加载 {len(pcd.points)} 个点")
    
    if len(pcd.points) > 0:
        points = np.asarray(pcd.points)
        min_bound = points.min(axis=0)
        max_bound = points.max(axis=0)
        size = max_bound - min_bound
        center = points.mean(axis=0)
        
        print(f"\n   点云边界框:")
        print(f"     最小: [{min_bound[0]:.6f}, {min_bound[1]:.6f}, {min_bound[2]:.6f}]")
        print(f"     最大: [{max_bound[0]:.6f}, {max_bound[1]:.6f}, {max_bound[2]:.6f}]")
        print(f"     尺寸: [{size[0]:.6f}, {size[1]:.6f}, {size[2]:.6f}]")
        print(f"     中心: [{center[0]:.6f}, {center[1]:.6f}, {center[2]:.6f}]")
    
    # 加载模型
    print("\n📂 加载模型...")
    mesh = o3d.io.read_triangle_mesh(model_path)
    
    if len(mesh.vertices) > 0:
        print(f"   ✅ 成功加载模型，包含 {len(mesh.vertices)} 个顶点")
        vertices = np.asarray(mesh.vertices)
        min_bound = vertices.min(axis=0)
        max_bound = vertices.max(axis=0)
        size = max_bound - min_bound
        center = vertices.mean(axis=0)
        
        print(f"\n   模型边界框:")
        print(f"     最小: [{min_bound[0]:.6f}, {min_bound[1]:.6f}, {min_bound[2]:.6f}]")
        print(f"     最大: [{max_bound[0]:.6f}, {max_bound[1]:.6f}, {max_bound[2]:.6f}]")
        print(f"     尺寸: [{size[0]:.6f}, {size[1]:.6f}, {size[2]:.6f}]")
        print(f"     中心: [{center[0]:.6f}, {center[1]:.6f}, {center[2]:.6f}]")
        
        # 计算缩放因子
        if len(pcd.points) > 0:
            pc_size = np.asarray(pcd.points).max(axis=0) - np.asarray(pcd.points).min(axis=0)
            model_size = size
            
            print(f"\n📐 尺寸对比:")
            print(f"   点云尺寸: [{pc_size[0]:.6f}, {pc_size[1]:.6f}, {pc_size[2]:.6f}]")
            print(f"   模型尺寸: [{model_size[0]:.6f}, {model_size[1]:.6f}, {model_size[2]:.6f}]")
            
            # 计算各轴的缩放比例
            ratios = model_size / (pc_size + 1e-10)
            print(f"\n   各轴缩放比例:")
            print(f"     X轴: {ratios[0]:.6f}")
            print(f"     Y轴: {ratios[1]:.6f}")
            print(f"     Z轴: {ratios[2]:.6f}")
            
            # 推荐缩放因子（匹配最大尺寸）
            scale_factor = np.min(ratios[pc_size > 1e-10])
            print(f"\n   💡 推荐缩放因子（匹配最大尺寸）: {scale_factor:.6f}")
            
            if scale_factor < 1.0:
                print(f"      （点云需要缩小 {1.0/scale_factor:.2f} 倍）")
            else:
                print(f"      （点云需要放大 {scale_factor:.2f} 倍）")
            
            print(f"\n   建议命令:")
            print(f"   python compare_pointcloud_with_model.py \\")
            print(f"       --pointcloud \"{pointcloud_path}\" \\")
            print(f"       --model \"{model_path}\" \\")
            print(f"       --scale-factor {scale_factor:.6f}")
    else:
        print("   ⚠️  模型文件为空或无法读取")
        
except ImportError as e:
    print(f"❌ 缺少依赖: {e}")
    print("   请运行: pip install open3d numpy")
except Exception as e:
    print(f"❌ 错误: {e}")
    import traceback
    traceback.print_exc()

