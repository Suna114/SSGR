#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
相机位姿计算验证脚本

此脚本用于验证SAR相机位姿计算的数学正确性，包括：
1. 旋转矩阵的正交性和行列式
2. 平移向量与相机位置的关系
3. 相机指向场景中心的验证
4. 相机坐标系的正交性和手性
5. 投影矩阵的性质验证
"""

import numpy as np
import sys
import os

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sar_geometry import compute_sar_camera_pose, DEFAULT_SAR_PARAMS


def verify_rotation_matrix(R, name="R"):
    """
    验证旋转矩阵的性质
    
    Args:
        R: 3x3旋转矩阵
        name: 矩阵名称（用于打印）
    
    Returns:
        bool: 验证是否通过
    """
    print(f"\n{'='*60}")
    print(f"验证旋转矩阵 {name}")
    print(f"{'='*60}")
    
    all_pass = True
    
    # 1. 验证R是3x3矩阵
    if R.shape != (3, 3):
        print(f"❌ 错误: {name}不是3x3矩阵，形状为{R.shape}")
        return False
    print(f"✓ {name}是3x3矩阵")
    
    # 2. 验证正交性: R @ R.T = I
    RTR = R @ R.T
    I = np.eye(3)
    orthogonality_error = np.linalg.norm(RTR - I, 'fro')
    print(f"✓ 正交性误差: {orthogonality_error:.2e} (R @ R.T - I的Frobenius范数)")
    if orthogonality_error > 1e-6:
        print(f"  ⚠️ 警告: 正交性误差较大 (> 1e-6)")
        all_pass = False
    
    # 3. 验证行列式为1（右手坐标系）
    det = np.linalg.det(R)
    print(f"✓ 行列式: {det:.6f}")
    if abs(det - 1.0) > 1e-6:
        print(f"  ❌ 错误: 行列式不为1，差值为{abs(det - 1.0):.2e}")
        all_pass = False
    
    # 4. 验证各列向量的范数为1
    for i in range(3):
        col_norm = np.linalg.norm(R[:, i])
        axis_name = ['X轴', 'Y轴', 'Z轴'][i]
        print(f"✓ {axis_name}范数: {col_norm:.6f}")
        if abs(col_norm - 1.0) > 1e-6:
            print(f"  ⚠️ 警告: {axis_name}范数不为1，差值为{abs(col_norm - 1.0):.2e}")
            all_pass = False
    
    # 5. 验证各列向量正交
    for i in range(3):
        for j in range(i+1, 3):
            dot_product = np.dot(R[:, i], R[:, j])
            axis_names = ['X轴', 'Y轴', 'Z轴']
            print(f"✓ {axis_names[i]}·{axis_names[j]}: {dot_product:.2e}")
            if abs(dot_product) > 1e-6:
                print(f"  ⚠️ 警告: {axis_names[i]}和{axis_names[j]}不正交，点积为{dot_product:.2e}")
                all_pass = False
    
    if all_pass:
        print(f"\n✅ 旋转矩阵 {name} 验证通过！")
    else:
        print(f"\n❌ 旋转矩阵 {name} 验证存在问题！")
    
    return all_pass


def verify_camera_position(R, t, expected_position, name="相机"):
    """
    验证相机位置计算
    
    Args:
        R: 旋转矩阵（从世界到相机）
        t: 平移向量
        expected_position: 期望的相机位置（在世界坐标系中）
        name: 相机名称
    
    Returns:
        bool: 验证是否通过
    """
    print(f"\n{'='*60}")
    print(f"验证{name}位置计算")
    print(f"{'='*60}")
    
    # 计算相机位置: C = -R.T @ t
    computed_position = -R.T @ t
    
    print(f"期望位置: [{expected_position[0,0]:8.2f}, {expected_position[1,0]:8.2f}, {expected_position[2,0]:8.2f}]")
    print(f"计算位置: [{computed_position[0,0]:8.2f}, {computed_position[1,0]:8.2f}, {computed_position[2,0]:8.2f}]")
    
    # 计算误差
    position_error = np.linalg.norm(computed_position - expected_position)
    print(f"位置误差: {position_error:.2e} (欧氏距离)")
    
    # 验证关系: t = -R @ C
    computed_t = -R @ expected_position
    t_error = np.linalg.norm(t - computed_t)
    print(f"平移向量关系验证: ||t - (-R @ C)|| = {t_error:.2e}")
    
    if position_error < 1e-6 and t_error < 1e-6:
        print(f"✅ {name}位置计算正确！")
        return True
    else:
        print(f"❌ {name}位置计算存在误差！")
        return False


def verify_camera_orientation(R, camera_position, scene_center=np.array([[0], [0], [0]])):
    """
    验证相机是否指向场景中心
    
    Args:
        R: 旋转矩阵（从世界到相机）
        camera_position: 相机在世界坐标系中的位置
        scene_center: 场景中心位置
    
    Returns:
        bool: 验证是否通过
    """
    print(f"\n{'='*60}")
    print(f"验证相机指向场景中心")
    print(f"{'='*60}")
    
    # 计算从相机到场景中心的方向（在世界坐标系中）
    to_scene_in_world = scene_center - camera_position
    to_scene_in_world = to_scene_in_world / np.linalg.norm(to_scene_in_world)
    
    print(f"相机到场景方向（世界坐标系）: [{to_scene_in_world[0,0]:6.3f}, {to_scene_in_world[1,0]:6.3f}, {to_scene_in_world[2,0]:6.3f}]")
    
    # 相机坐标系的Z轴（前方向）在世界坐标系中的表示
    # R是从世界到相机的旋转，所以R.T是从相机到世界的旋转
    # 相机坐标系的Z轴在世界坐标系中的表示是R.T的第3列
    camera_z_in_world = R.T[:, 2:3]
    
    print(f"相机Z轴方向（世界坐标系）:   [{camera_z_in_world[0,0]:6.3f}, {camera_z_in_world[1,0]:6.3f}, {camera_z_in_world[2,0]:6.3f}]")
    
    # 计算角度偏差
    dot_product = np.dot(to_scene_in_world.flatten(), camera_z_in_world.flatten())
    angle_rad = np.arccos(np.clip(dot_product, -1.0, 1.0))
    angle_deg = np.rad2deg(angle_rad)
    
    print(f"方向点积: {dot_product:.6f}")
    print(f"角度偏差: {angle_deg:.4f}度")
    
    if angle_deg < 1.0:  # 允许1度的误差
        print(f"✅ 相机正确指向场景中心！")
        return True
    else:
        print(f"❌ 相机方向偏差过大（{angle_deg:.2f}度）！")
        return False


def verify_camera_coordinate_system(R):
    """
    验证相机坐标系的手性（右手/左手）
    
    Args:
        R: 旋转矩阵（从世界到相机）
    
    Returns:
        bool: 验证是否通过
    """
    print(f"\n{'='*60}")
    print(f"验证相机坐标系手性")
    print(f"{'='*60}")
    
    # 提取相机坐标系的三个轴（在世界坐标系中的表示）
    # R.T是从相机到世界的旋转
    x_axis = R.T[:, 0]  # X轴（右）
    y_axis = R.T[:, 1]  # Y轴（下）
    z_axis = R.T[:, 2]  # Z轴（前）
    
    print(f"X轴（右）: [{x_axis[0]:6.3f}, {x_axis[1]:6.3f}, {x_axis[2]:6.3f}]")
    print(f"Y轴（下）: [{y_axis[0]:6.3f}, {y_axis[1]:6.3f}, {y_axis[2]:6.3f}]")
    print(f"Z轴（前）: [{z_axis[0]:6.3f}, {z_axis[1]:6.3f}, {z_axis[2]:6.3f}]")
    
    # 验证右手坐标系: X × Y = Z
    cross_product = np.cross(x_axis, y_axis)
    cross_error = np.linalg.norm(cross_product - z_axis)
    
    print(f"\nX × Y = [{cross_product[0]:6.3f}, {cross_product[1]:6.3f}, {cross_product[2]:6.3f}]")
    print(f"X × Y - Z的误差: {cross_error:.2e}")
    
    if cross_error < 1e-6:
        print(f"✅ 相机坐标系是右手坐标系！")
        return True
    else:
        print(f"❌ 相机坐标系不是右手坐标系！")
        return False


def verify_projection_matrix(K, R, t):
    """
    验证投影矩阵P = K[R|t]的基本性质
    
    Args:
        K: 内参矩阵
        R: 旋转矩阵
        t: 平移向量
    
    Returns:
        bool: 验证是否通过
    """
    print(f"\n{'='*60}")
    print(f"验证投影矩阵")
    print(f"{'='*60}")
    
    # 构建投影矩阵
    Rt = np.hstack([R, t])
    P = K @ Rt
    
    print(f"投影矩阵P形状: {P.shape}")
    print(f"内参矩阵K:\n{K}")
    
    # 验证P的秩
    rank = np.linalg.matrix_rank(P)
    print(f"\n投影矩阵的秩: {rank}")
    
    if rank == 3:
        print(f"✅ 投影矩阵的秩为3（正常）！")
        return True
    else:
        print(f"❌ 投影矩阵的秩不为3（异常）！")
        return False


def test_single_camera(depression_angle, azimuth_angle, sar_params):
    """
    测试单个相机的位姿计算
    
    Args:
        depression_angle: 俯视角（度）
        azimuth_angle: 方位角（度）
        sar_params: SAR参数字典
    
    Returns:
        bool: 所有验证是否通过
    """
    print(f"\n\n{'#'*70}")
    print(f"# 测试相机位姿：俯视角={depression_angle}°, 方位角={azimuth_angle}°")
    print(f"{'#'*70}")
    
    # 计算相机位姿
    R, t, K = compute_sar_camera_pose(depression_angle, azimuth_angle, sar_params)
    
    # 计算期望的相机位置（用于验证）
    # 重要：必须与sar_geometry.py中的计算逻辑完全一致
    dep_rad = np.deg2rad(depression_angle)
    azi_rad = np.deg2rad(azimuth_angle)
    
    distribution_mode = sar_params.get('camera_distribution_mode', 'sphere')
    camera_height = sar_params['camera_height']
    
    # 计算R0（参考斜距）
    # 如果提供了unified_sita0_for_radius，使用它；否则使用当前俯视角
    unified_sita0_for_radius = sar_params.get('unified_sita0_for_radius', None)
    if unified_sita0_for_radius is not None:
        sita0_for_radius = unified_sita0_for_radius
    else:
        sita0_for_radius = dep_rad
    
    R0 = camera_height / np.sin(sita0_for_radius)
    
    # 计算半径缩放因子（与sar_geometry.py保持一致）
    default_radius_scale = sar_params.get('default_radius_scale', None)
    if default_radius_scale is None:
        # 自动计算：与图像尺寸相关
        Na = sar_params.get('Na', 512)
        Nr = sar_params.get('Nr', 512)
        scene_scale = sar_params.get('scene_scale', 10.0)
        image_size = max(Na, Nr)
        default_radius_scale = (image_size * scene_scale) / R0 if R0 > 0 else 1.0
    
    radius_scale = sar_params.get('radius_scale', default_radius_scale)
    
    if distribution_mode == 'sphere':
        # 球面分布
        sphere_radius = R0 * radius_scale
        
        expected_x = sphere_radius * np.sin(dep_rad) * np.cos(azi_rad)
        expected_y = sphere_radius * np.sin(dep_rad) * np.sin(azi_rad)
        expected_z = sphere_radius * np.cos(dep_rad)
    else:
        # 水平圆环分布
        R_current = camera_height / np.sin(dep_rad)
        ground_range = np.sqrt(R_current**2 - camera_height**2)
        ground_range = ground_range * radius_scale
        
        expected_x = ground_range * np.cos(azi_rad)
        expected_y = ground_range * np.sin(azi_rad)
        expected_z = camera_height
    
    expected_position = np.array([[expected_x], [expected_y], [expected_z]])
    
    print(f"\nSAR参数:")
    print(f"  - 分布模式: {distribution_mode}")
    print(f"  - 相机高度: {sar_params['camera_height']:.2f}m")
    print(f"  - 参考斜距R0: {R0:.2f}m")
    print(f"  - 半径缩放: {radius_scale:.4f}")
    if distribution_mode == 'sphere':
        print(f"  - 球面半径: {sphere_radius:.2f}m")
    
    # 执行所有验证
    results = []
    
    results.append(verify_rotation_matrix(R, "R"))
    results.append(verify_camera_position(R, t, expected_position))
    results.append(verify_camera_orientation(R, expected_position))
    results.append(verify_camera_coordinate_system(R))
    results.append(verify_projection_matrix(K, R, t))
    
    # 总结
    print(f"\n{'='*60}")
    print(f"测试总结")
    print(f"{'='*60}")
    passed = sum(results)
    total = len(results)
    print(f"通过: {passed}/{total} 项测试")
    
    if all(results):
        print(f"✅ 所有测试通过！")
    else:
        print(f"❌ 存在失败的测试！")
    
    return all(results)


def test_multiple_cameras():
    """
    测试多个相机位姿（模拟MSTAR数据集的典型配置）
    """
    print(f"\n\n{'*'*70}")
    print(f"{'*'*70}")
    print(f"开始验证SAR相机位姿计算")
    print(f"{'*'*70}")
    print(f"{'*'*70}")
    
    # 使用默认的SAR参数
    sar_params = DEFAULT_SAR_PARAMS.copy()
    
    # 测试配置
    test_cases = [
        (15, 0),    # 俯视角15度，方位角0度
        (15, 90),   # 俯视角15度，方位角90度
        (30, 0),    # 俯视角30度，方位角0度
        (45, 45),   # 俯视角45度，方位角45度
        (30, 180),  # 俯视角30度，方位角180度
    ]
    
    results = []
    for dep, azi in test_cases:
        result = test_single_camera(dep, azi, sar_params)
        results.append((dep, azi, result))
    
    # 最终总结
    print(f"\n\n{'*'*70}")
    print(f"最终总结")
    print(f"{'*'*70}")
    
    passed_count = sum(1 for _, _, result in results if result)
    total_count = len(results)
    
    for dep, azi, result in results:
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{status} - 俯视角={dep:2d}°, 方位角={azi:3d}°")
    
    print(f"\n总通过率: {passed_count}/{total_count} ({100*passed_count/total_count:.1f}%)")
    
    if passed_count == total_count:
        print(f"\n🎉 恭喜！所有相机位姿计算验证通过！")
    else:
        print(f"\n⚠️ 警告：存在{total_count - passed_count}个测试失败！")
    
    return passed_count == total_count


if __name__ == "__main__":
    success = test_multiple_cameras()
    sys.exit(0 if success else 1)

