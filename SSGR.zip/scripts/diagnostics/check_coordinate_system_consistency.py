#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
检查SFM阶段和GS阶段的坐标系一致性
"""

import json
import numpy as np
from scipy.spatial.transform import Rotation as R

print("="*70)
print("坐标系一致性检查")
print("="*70)

# 读取SFM输出的相机位姿
sfm_poses_file = "data/25/sfm_results/25/point-clouds/camera_poses.json"
try:
    with open(sfm_poses_file, 'r') as f:
        sfm_poses = json.load(f)
    print(f"\n✅ 读取SFM相机位姿: {sfm_poses_file}")
    print(f"   相机数量: {len(sfm_poses)}")
except Exception as e:
    print(f"\n❌ 无法读取SFM相机位姿: {e}")
    sfm_poses = {}

# 读取GS使用的相机参数（如果存在）
gs_cameras_file = "output/1/cameras.json"
try:
    with open(gs_cameras_file, 'r') as f:
        gs_cameras = json.load(f)
    print(f"\n✅ 读取GS相机参数: {gs_cameras_file}")
    print(f"   相机数量: {len(gs_cameras)}")
except Exception as e:
    print(f"\n❌ 无法读取GS相机参数: {e}")
    gs_cameras = []

# 分析坐标系
print("\n" + "="*70)
print("坐标系分析")
print("="*70)

if sfm_poses:
    # 检查SFM阶段的坐标系
    print("\n【SFM阶段坐标系】")
    print("-"*70)
    
    # 随机选择几个相机检查
    sample_cameras = list(sfm_poses.items())[:3]
    for img_name, pose in sample_cameras:
        tx = pose.get('tx', 0)
        ty = pose.get('ty', 0)
        tz = pose.get('tz', 0)
        print(f"\n相机: {img_name}")
        print(f"  位置: ({tx:.2f}, {ty:.2f}, {tz:.2f})")
        print(f"  Y坐标: {ty:.2f} (COLMAP约定：高度在Y轴负方向，所以Y应该为负值)")
        
        # 检查旋转矩阵
        if 'R' in pose:
            R_mat = np.array(pose['R'])
            # 检查Y轴方向（第二列）
            y_axis = R_mat[:, 1]
            print(f"  旋转矩阵Y轴（第二列）: {y_axis}")
            print(f"  Y轴方向: {'向下' if y_axis[1] > 0.5 else '向上' if y_axis[1] < -0.5 else '其他'}")

if gs_cameras:
    # 检查GS阶段的坐标系
    print("\n【GS阶段坐标系】")
    print("-"*70)
    
    # 检查前几个相机
    for i, cam in enumerate(gs_cameras[:3]):
        if 'position' in cam:
            pos = cam['position']
            print(f"\n相机 {i}: {cam.get('img_name', 'N/A')}")
            print(f"  位置: ({pos[0]:.2f}, {pos[1]:.2f}, {pos[2]:.2f})")
            print(f"  Y坐标: {pos[1]:.2f} (应该与SFM阶段一致)")
        
        if 'rotation' in cam:
            R_mat = np.array(cam['rotation'])
            y_axis = R_mat[:, 1]
            print(f"  旋转矩阵Y轴（第二列）: {y_axis}")
            print(f"  Y轴方向: {'向下' if y_axis[1] > 0.5 else '向上' if y_axis[1] < -0.5 else '其他'}")

# 检查坐标系一致性
print("\n" + "="*70)
print("坐标系一致性检查")
print("="*70)

if sfm_poses and gs_cameras:
    print("\n比较SFM和GS的坐标系：")
    
    # 找到共同的相机
    sfm_names = set(sfm_poses.keys())
    gs_names = set(cam.get('img_name', '') for cam in gs_cameras if 'img_name' in cam)
    common_names = sfm_names & gs_names
    
    if common_names:
        print(f"   共同相机数量: {len(common_names)}")
        
        # 比较第一个共同相机
        common_name = list(common_names)[0]
        sfm_pose = sfm_poses[common_name]
        gs_cam = next((c for c in gs_cameras if c.get('img_name') == common_name), None)
        
        if gs_cam:
            print(f"\n   示例相机: {common_name}")
            
            # 比较位置
            sfm_pos = np.array([sfm_pose.get('tx', 0), sfm_pose.get('ty', 0), sfm_pose.get('tz', 0)])
            if 'position' in gs_cam:
                gs_pos = np.array(gs_cam['position'])
                print(f"   SFM位置: ({sfm_pos[0]:.2f}, {sfm_pos[1]:.2f}, {sfm_pos[2]:.2f})")
                print(f"   GS位置:  ({gs_pos[0]:.2f}, {gs_pos[1]:.2f}, {gs_pos[2]:.2f})")
                diff = np.linalg.norm(sfm_pos - gs_pos)
                print(f"   位置差异: {diff:.2f}")
                
                if diff < 0.01:
                    print("   ✅ 位置一致（坐标系一致）")
                else:
                    print("   ⚠️  位置不一致（可能坐标系不同）")
            else:
                print("   ⚠️  GS相机没有位置信息")
    else:
        print("   ⚠️  没有找到共同的相机名称")
else:
    print("\n⚠️  无法比较：缺少SFM或GS的相机数据")

# 结论
print("\n" + "="*70)
print("结论")
print("="*70)
print("\n【COLMAP坐标系约定】")
print("  - X轴：向右")
print("  - Y轴：向下（高度正值在Y轴负方向）")
print("  - Z轴：向前")
print("\n【SFM阶段】")
print("  - 使用COLMAP坐标系 ✅")
print("  - 相机位置：y = -sphere_radius * cos(depression)")
print("  - 高度在Y轴负方向 ✅")
print("\n【GS阶段】")
print("  - 读取COLMAP格式 ✅")
print("  - 直接使用COLMAP的R和T ✅")
print("  - 理论上应该与SFM阶段一致 ✅")
print("\n【潜在问题】")
print("  - 如果GS期望其他坐标系（如OpenGL），需要转换")
print("  - 需要验证实际运行时的坐标系是否一致")
print("\n" + "="*70)

