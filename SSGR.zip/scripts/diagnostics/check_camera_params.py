#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
快速检查相机参数的脚本
"""

import numpy as np
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sar_geometry import compute_sar_camera_pose, DEFAULT_SAR_PARAMS

# 测试参数
depression_angle = 15  # 度
azimuth_angle = 0  # 度

print("="*70)
print("检查SAR相机参数")
print("="*70)

# 使用默认参数
sar_params = DEFAULT_SAR_PARAMS.copy()

print(f"\n输入参数:")
print(f"  - 俯视角: {depression_angle}°")
print(f"  - 方位角: {azimuth_angle}°")
print(f"  - 相机高度: {sar_params['camera_height']:.2f}m")
print(f"  - 图像尺寸: {sar_params['Na']} x {sar_params['Nr']}")
print(f"  - 分布模式: {sar_params.get('camera_distribution_mode', 'sphere')}")

# 计算相机位姿
R, t, K = compute_sar_camera_pose(depression_angle, azimuth_angle, sar_params)

# 计算相机位置
camera_position = -R.T @ t

print(f"\n计算结果:")
print(f"  - 相机位置: [{camera_position[0,0]:.2f}, {camera_position[1,0]:.2f}, {camera_position[2,0]:.2f}]")
print(f"  - 相机到原点距离: {np.linalg.norm(camera_position):.2f}m")

# 手动计算期望值（用于对比）
dep_rad = np.deg2rad(depression_angle)
azi_rad = np.deg2rad(azimuth_angle)

camera_height = sar_params['camera_height']
R0 = camera_height / np.sin(dep_rad)

print(f"\n手动计算（无缩放）:")
print(f"  - 参考斜距R0: {R0:.2f}m")
print(f"  - 期望位置: [{R0 * np.sin(dep_rad) * np.cos(azi_rad):.2f}, {R0 * np.sin(dep_rad) * np.sin(azi_rad):.2f}, {R0 * np.cos(dep_rad):.2f}]")
print(f"  - 期望距离: {R0:.2f}m")

# 计算缩放因子
actual_radius = np.linalg.norm(camera_position)
scale_factor = actual_radius / R0

print(f"\n推断的缩放因子:")
print(f"  - 实际半径 / R0 = {actual_radius:.2f} / {R0:.2f} = {scale_factor:.4f}")

# 计算自动缩放因子
Na = sar_params.get('Na', 512)
Nr = sar_params.get('Nr', 512)
scene_scale = sar_params.get('scene_scale', 10.0)
image_size = max(Na, Nr)
auto_scale = (image_size * scene_scale) / R0

print(f"\n自动计算的缩放因子:")
print(f"  - (image_size * scene_scale) / R0")
print(f"  - ({image_size} * {scene_scale}) / {R0:.2f}")
print(f"  - = {auto_scale:.4f}")

print(f"\n✅ 验证: 自动缩放因子 {'匹配' if abs(scale_factor - auto_scale) < 0.01 else '不匹配'}")

print(f"\n内参矩阵K:")
print(K)

print("\n" + "="*70)

