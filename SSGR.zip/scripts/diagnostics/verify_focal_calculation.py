#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
验证和展示相机焦距的计算过程
"""

import math
import json
import os
import sys

def fov2focal(fov, pixels):
    """
    将视场角（FOV）转换为焦距
    
    公式: focal = pixels / (2 * tan(fov / 2))
    """
    return pixels / (2 * math.tan(fov / 2))

def focal2fov(focal, pixels):
    """
    将焦距转换为视场角（FOV）
    
    公式: fov = 2 * atan(pixels / (2 * focal))
    """
    return 2 * math.atan(pixels / (2 * focal))

def analyze_camera_focal(camera_file):
    """分析相机文件中的焦距信息"""
    
    if not os.path.exists(camera_file):
        print(f"❌ 错误: 找不到相机文件: {camera_file}")
        return
    
    # 读取相机数据
    with open(camera_file, 'r', encoding='utf-8') as f:
        cameras = json.load(f)
    
    if len(cameras) == 0:
        print("⚠️ 警告: 相机列表为空")
        return
    
    # 分析第一个相机
    cam = cameras[0]
    width = cam['width']
    height = cam['height']
    fx = cam['fx']
    fy = cam['fy']
    
    print("=" * 70)
    print("相机焦距分析")
    print("=" * 70)
    print(f"图像尺寸: {width} x {height} 像素")
    print(f"焦距: fx = {fx:.2f}, fy = {fy:.2f}")
    print()
    
    # 计算FOV
    fovx = focal2fov(fx, width)
    fovy = focal2fov(fy, height)
    
    print("视场角（FOV）:")
    print(f"  FOV X: {math.degrees(fovx):.4f}° ({fovx:.6f} 弧度)")
    print(f"  FOV Y: {math.degrees(fovy):.4f}° ({fovy:.6f} 弧度)")
    print()
    
    # 验证：从FOV转换回焦距
    fx_calc = fov2focal(fovx, width)
    fy_calc = fov2focal(fovy, height)
    
    print("验证计算:")
    print(f"  从FOV计算的 fx: {fx_calc:.6f} (原始值: {fx:.2f})")
    print(f"  从FOV计算的 fy: {fy_calc:.6f} (原始值: {fy:.2f})")
    print(f"  误差: fx={abs(fx_calc - fx):.6f}, fy={abs(fy_calc - fy):.6f}")
    print()
    
    # 分析焦距与图像尺寸的关系
    print("焦距与图像尺寸的关系:")
    focal_scale_x = fx / width
    focal_scale_y = fy / height
    print(f"  fx / width = {focal_scale_x:.4f}")
    print(f"  fy / height = {focal_scale_y:.4f}")
    
    if abs(focal_scale_x - 1.5) < 0.1:
        print(f"  ✅ 焦距大约是图像宽度的1.5倍（标准SAR设置）")
    elif abs(focal_scale_x - 1.0) < 0.1:
        print(f"  ✅ 焦距等于图像宽度（1:1比例）")
    else:
        print(f"  ℹ️ 焦距是图像宽度的 {focal_scale_x:.2f} 倍")
    print()
    
    # 统计所有相机的焦距
    print("=" * 70)
    print("所有相机的焦距统计")
    print("=" * 70)
    
    fx_values = [c['fx'] for c in cameras]
    fy_values = [c['fy'] for c in cameras]
    
    print(f"焦距范围:")
    print(f"  fx: [{min(fx_values):.2f}, {max(fx_values):.2f}]")
    print(f"  fy: [{min(fy_values):.2f}, {max(fy_values):.2f}]")
    print(f"平均焦距:")
    print(f"  fx: {sum(fx_values)/len(fx_values):.2f}")
    print(f"  fy: {sum(fy_values)/len(fy_values):.2f}")
    
    # 检查是否所有相机使用相同焦距
    fx_unique = set(fx_values)
    fy_unique = set(fy_values)
    
    if len(fx_unique) == 1 and len(fy_unique) == 1:
        print(f"\n✅ 所有相机使用统一焦距: fx={fx_values[0]:.2f}, fy={fy_values[0]:.2f}")
        print(f"   这是SAR模式的标准设置，确保尺度一致性")
    else:
        print(f"\n⚠️ 警告: 不同相机使用不同的焦距值")
        print(f"   这可能导致尺度不一致的问题")
    
    # 计算不同图像尺寸下的等效焦距
    print("\n" + "=" * 70)
    print("不同图像尺寸下的等效焦距（假设缩放因子=1.5）")
    print("=" * 70)
    
    test_sizes = [64, 128, 256, 512, 1024]
    for size in test_sizes:
        equivalent_focal = size * 1.5
        print(f"  {size}x{size} 图像: 焦距 ≈ {equivalent_focal:.1f}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python verify_focal_calculation.py <cameras.json路径>")
        print("例如: python verify_focal_calculation.py ./output/sar_reconstruction1/cameras.json")
        sys.exit(1)
    
    camera_file = sys.argv[1]
    analyze_camera_focal(camera_file)

