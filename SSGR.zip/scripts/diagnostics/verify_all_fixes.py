#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
_repo_root = None
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _repo_root = _repo
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
REPO_ROOT = _repo_root
del _Path, _repo, _s, _repo_root
# --- end auto ---

# -*- coding: utf-8 -*-
"""
验证所有关键修复是否已应用
"""

import os
import re

print("="*70)
print("验证关键修复是否已应用")
print("="*70)

all_good = True

# 1. 检查config.py中radius_scale默认值
print("\n1. 检查 config.py 中 radius_scale 默认值...")
with open(REPO_ROOT / 'config.py', 'r', encoding='utf-8') as f:
    config_content = f.read()
    
radius_scale_match = re.search(r'--sar_radius_scale.*?default=([\w\.]+)', config_content, re.DOTALL)
if radius_scale_match:
    default_val = radius_scale_match.group(1)
    if default_val == 'None':
        print(f"   ✅ radius_scale默认值为None（自动计算）")
    elif default_val == '1.0' or default_val == '1':
        print(f"   ❌ radius_scale默认值为{default_val}（需要改为None）")
        all_good = False
    else:
        print(f"   ⚠️  radius_scale默认值为{default_val}")
else:
    print("   ⚠️  无法找到sar_radius_scale参数")

# 2. 检查convert.py中radius_scale的条件检查
print("\n2. 检查 convert.py 中 radius_scale 条件检查...")
with open(REPO_ROOT / 'convert.py', 'r', encoding='utf-8') as f:
    convert_content = f.read()
    
if 'args.sar_radius_scale is not None' in convert_content:
    print("   ✅ convert.py 正确检查 radius_scale is not None")
else:
    print("   ❌ convert.py 缺少 radius_scale is not None 检查")
    all_good = False

# 3. 检查sfm.py中注释修复
print("\n3. 检查 sfm.py 中 t向量注释...")
with open(REPO_ROOT / 'sfm.py', 'r', encoding='utf-8') as f:
    sfm_content = f.read()
    
if 't = -R @ C' in sfm_content and '其中C是相机' in sfm_content:
    print("   ✅ sfm.py 注释已修复（包含 t = -R @ C 说明）")
else:
    print("   ⚠️  sfm.py 注释可能需要更新")

# 4. 检查sfm.py中unified_radius_scale的设置
if 'self.unified_radius_scale = unified_radius_scale' in sfm_content:
    print("\n4. 检查 sfm.py 中 unified_radius_scale 设置...")
    print("   ✅ sfm.py 正确设置 unified_radius_scale")
    
    # 检查是否在SO-RCG模式下保留
    if 'radius_scale应该始终使用统一值' in sfm_content or 'unified_radius_scale必须保留' in sfm_content:
        print("   ✅ unified_radius_scale 在SO-RCG模式下也保留")
    else:
        print("   ⚠️  SO-RCG模式下可能未保留unified_radius_scale")
else:
    print("\n4. 检查 sfm.py 中 unified_radius_scale 设置...")
    print("   ❌ sfm.py 未设置 unified_radius_scale")
    all_good = False

# 5. 检查sar_geometry.py中坐标系定义
print("\n5. 检查 sar/geometry.py 中坐标系定义...")
with open(REPO_ROOT / 'sar' / 'geometry.py', 'r', encoding='utf-8') as f:
    geom_content = f.read()
    
if 'world_up = np.array([0, 0, 1])' in geom_content:
    print("   ✅ sar/geometry.py 使用世界'上'方向构建坐标系")
else:
    print("   ❌ sar/geometry.py 坐标系定义需要更新")
    all_good = False

# 6. 检查sar_sorc_sfm.py中R0计算（三角化）
print("\n6. 检查 sar/sorc_sfm.py 中三角化R0计算...")
with open(REPO_ROOT / 'sar' / 'sorc_sfm.py', 'r', encoding='utf-8') as f:
    sorc_content = f.read()
    
if 'R0_1 = np.linalg.norm(P_radar1)' in sorc_content and 'R0_2 = np.linalg.norm(P_radar2)' in sorc_content:
    print("   ✅ sar/sorc_sfm.py 三角化使用实际相机位置计算R0")
else:
    print("   ❌ sar/sorc_sfm.py 三角化R0计算需要修复")
    all_good = False

# 7. 检查sar_sorc_sfm.py中误导性警告的修复
if '球面分布模式' in sorc_content and 'Z坐标随俯视角变化（正常）' in sorc_content:
    print("\n7. 检查 sar/sorc_sfm.py 中Z坐标警告...")
    print("   ✅ sar/sorc_sfm.py Z坐标警告已修复（区分分布模式）")
else:
    print("\n7. 检查 sar/sorc_sfm.py 中Z坐标警告...")
    print("   ⚠️  sar/sorc_sfm.py Z坐标警告可能仍有误导性")

# 8. 检查config.py中camera_height默认值（关键！）
print("\n8. 检查 config.py 中 camera_height 默认值...")
camera_height_match = re.search(r'--sar_camera_height.*?default=([\d\.]+)', config_content, re.DOTALL)
if camera_height_match:
    default_height = float(camera_height_match.group(1))
    if default_height >= 5000 and default_height <= 15000:
        print(f"   ✅ camera_height默认值为{default_height}米（合理范围）")
    elif default_height < 100:
        print(f"   ❌ camera_height默认值为{default_height}米（严重错误！应该是12000.0米）")
        all_good = False
    else:
        print(f"   ⚠️  camera_height默认值为{default_height}米（可能不适合机载SAR）")
else:
    print("   ⚠️  无法找到sar_camera_height参数")
    all_good = False

print("\n" + "="*70)
if all_good:
    print("✅ 所有关键修复都已正确应用！")
else:
    print("⚠️  部分修复可能需要重新应用")
print("="*70)

