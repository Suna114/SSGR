#!/usr/bin/env python3
"""Debug target and shadow recognition without training the refiner."""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import torch
import torchvision
from tqdm import tqdm

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from scripts.rendering.learn_sar_azimuth_shadow_refiner import (  # noqa: E402
    _apply_mask_from_sources,
    _candidates,
    _input_tensor,
    _nearest,
    _recognition_shadow_gate,
    _region_classification_rgb,
    _shadow_apply_alpha_from_gate,
    _shadow_recognition_mask,
)
from scripts.rendering.learn_sar_image_refiner import (  # noqa: E402
    _image_files,
    _load_image,
    _parse_azimuth,
    _resize_chw,
)


def _overlay_regions(image: torch.Tensor, target_mask: torch.Tensor, shadow_mask: torch.Tensor) -> torch.Tensor:
    base = image.mean(dim=0, keepdim=True).clamp(0.0, 1.0).repeat(3, 1, 1)
    target = (target_mask.float().clamp(0.0, 1.0) > 0.5).float()
    shadow = (shadow_mask.float().clamp(0.0, 1.0) > 0.5).float() * (1.0 - target)
    red = torch.tensor([1.0, 0.05, 0.02], device=image.device, dtype=image.dtype)[:, None, None]
    blue = torch.tensor([0.05, 0.25, 1.0], device=image.device, dtype=image.dtype)[:, None, None]
    overlay = base * (1.0 - 0.65 * torch.maximum(target, shadow).unsqueeze(0))
    overlay = overlay + red * target.unsqueeze(0) * 0.65 + blue * shadow.unsqueeze(0) * 0.65
    return overlay.clamp(0.0, 1.0)


def _mask_stats(mask: torch.Tensor) -> tuple[int, float]:
    m = mask.float().clamp(0.0, 1.0)
    return int((m > 0.5).sum().detach().cpu()), float(m.mean().detach().cpu())


def _build_args(args: argparse.Namespace) -> argparse.Namespace:
    ns = argparse.Namespace()
    ns.apply_mask_source = args.apply_mask_source
    ns.target_mask_mode = args.target_mask_mode
    ns.target_mask_filter_percentile = args.percentile
    ns.target_mask_filter_largest_cc = True
    ns.target_mask_filter_min_target_ratio = args.min_target_ratio
    ns.target_mask_filter_max_target_ratio = 0.0
    ns.target_mask_filter_adaptive_max_percentile = args.percentile
    ns.target_mask_filter_erode_px = args.erode
    ns.target_mask_threshold = 0.08
    ns.target_mask_quantile = 0.35
    ns.target_mask_dilate = args.target_dilate
    ns.target_mask_min_pixels = args.min_pixels
    ns.target_mask_visibility_refiner_percentile = 0.0
    ns.target_mask_visibility_dilate = 1
    ns.shadow_train_target_mask_max_ratio = args.max_target_ratio
    ns.shadow_candidate_mode = args.candidate_mode
    ns.shadow_fixed_direction_deg = args.fixed_direction_deg
    ns.shadow_candidate_length = args.candidate_length
    ns.shadow_candidate_decay = args.candidate_decay
    ns.shadow_candidate_lateral_blur = args.candidate_lateral_blur
    ns.shadow_direction_offset_deg = args.direction_offset_deg
    ns.shadow_direction_sign = args.direction_sign
    ns.shadow_target_protect_dilate = args.target_protect_dilate
    ns.shadow_shape_prior_mode = "none"
    ns.shadow_shape_prior_weight = 0.0
    ns.shadow_shape_prior_threshold = 0.05
    ns.shadow_shape_prior_min_pixels = 4.0
    ns.shadow_include_target = False
    ns.shadow_target_overlap_weight = 0.0
    ns.shadow_joint_mask_refiner = False
    ns.shadow_image_use_joint_mask = False
    ns.shadow_recognition_source = args.recognition_source
    ns.shadow_recognition_threshold = args.recognition_threshold
    ns.shadow_recognition_gate_threshold = args.recognition_gate_threshold
    ns.shadow_apply_feather_blur = args.apply_feather_blur
    ns.shadow_apply_feather_core = args.apply_feather_core
    return ns


def main() -> int:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--render_dir", required=True, type=Path, help="Images to inspect.")
    parser.add_argument("--target_dir", type=Path, default=None, help="Optional target/mask source images matched by stem or azimuth.")
    parser.add_argument("--output_dir", required=True, type=Path)
    parser.add_argument("--apply_mask_source", choices=["render", "target"], default="render")
    parser.add_argument("--target_mask_mode", choices=["scatter95_largest", "filter_background", "legacy"], default="scatter95_largest")
    parser.add_argument("--percentile", type=float, default=95.0)
    parser.add_argument("--candidate_mode", choices=["directional", "directional_prior", "fixed_direction", "fixed_direction_prior"], default="fixed_direction")
    parser.add_argument("--fixed_direction_deg", type=float, default=178.74)
    parser.add_argument("--candidate_length", type=int, default=58)
    parser.add_argument("--candidate_decay", type=float, default=24.0)
    parser.add_argument("--candidate_lateral_blur", type=int, default=5)
    parser.add_argument("--direction_offset_deg", type=float, default=180.0)
    parser.add_argument("--direction_sign", type=float, default=1.0)
    parser.add_argument("--target_protect_dilate", type=int, default=1)
    parser.add_argument("--target_dilate", type=int, default=0)
    parser.add_argument("--erode", type=int, default=0)
    parser.add_argument("--min_pixels", type=float, default=16.0)
    parser.add_argument("--min_target_ratio", type=float, default=0.0005)
    parser.add_argument("--max_target_ratio", type=float, default=0.35)
    parser.add_argument("--recognition_source", choices=["candidate", "shape_prior", "prediction", "compose_alpha"], default="candidate")
    parser.add_argument("--recognition_threshold", type=float, default=0.4)
    parser.add_argument("--recognition_gate_threshold", type=float, default=0.4)
    parser.add_argument("--apply_feather_blur", type=int, default=4)
    parser.add_argument("--apply_feather_core", type=float, default=0.80)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()

    device = torch.device(args.device if str(args.device) == "cpu" or torch.cuda.is_available() else "cpu")
    recog_args = _build_args(args)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    maps_dir = args.output_dir / "maps"
    maps_dir.mkdir(parents=True, exist_ok=True)

    target_dir = args.target_dir or args.render_dir
    targets = _candidates(target_dir)
    target_by_stem = {item["path"].stem: item for item in targets}
    rows: list[dict[str, object]] = []
    render_paths = _image_files(args.render_dir)
    if args.limit and args.limit > 0:
        render_paths = render_paths[: int(args.limit)]

    for render_path in tqdm(render_paths, desc="debug shadow recognition", unit="img"):
        render = _load_image(render_path, recog_args).to(device)
        azimuth = _parse_azimuth(render_path)
        titem = target_by_stem.get(render_path.stem) or _nearest(targets, azimuth)
        target_source = _resize_chw(_load_image(titem["path"], recog_args).to(device), tuple(render.shape[-2:]))

        mask, mask_source, visibility_maps = _apply_mask_from_sources(render, target_source, recog_args)
        x, imaps = _input_tensor(mask_source if args.apply_mask_source == "render" else target_source, mask, azimuth, recog_args)
        recognition = _shadow_recognition_mask(mask, imaps, None, None, recog_args, azimuth=azimuth)
        final_shadow = _recognition_shadow_gate(recognition, recog_args, target_mask=mask)
        apply_alpha = _shadow_apply_alpha_from_gate(final_shadow, recog_args)
        classification, background = _region_classification_rgb(mask, final_shadow, shadow_threshold=0.5)
        overlay = _overlay_regions(render, mask, final_shadow)

        stem = render_path.stem
        torchvision.utils.save_image(mask_source.clamp(0.0, 1.0), str(maps_dir / f"{stem}_mask_source.png"))
        torchvision.utils.save_image(mask[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_mask.png"))
        torchvision.utils.save_image(imaps["candidate"][None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_candidate.png"))
        torchvision.utils.save_image(imaps.get("direction_prior", imaps["candidate"])[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_direction_prior.png"))
        torchvision.utils.save_image(recognition[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_recognition_mask.png"))
        torchvision.utils.save_image(final_shadow[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_final_shadow_mask.png"))
        torchvision.utils.save_image(apply_alpha[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_shadow_apply_alpha.png"))
        torchvision.utils.save_image(classification, str(maps_dir / f"{stem}_region_classification.png"))
        torchvision.utils.save_image(background, str(maps_dir / f"{stem}_background_mask.png"))
        torchvision.utils.save_image(overlay, str(maps_dir / f"{stem}_overlay.png"))
        if visibility_maps is not None:
            torchvision.utils.save_image(visibility_maps["core_mask"][None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_core_mask.png"))

        target_pixels, target_ratio = _mask_stats(mask)
        candidate_pixels, candidate_ratio = _mask_stats(imaps["candidate"] > args.recognition_threshold)
        shadow_pixels, shadow_ratio = _mask_stats(final_shadow)
        rows.append({
            "stem": stem,
            "render_path": str(render_path),
            "target_path": str(titem["path"]),
            "azimuth": azimuth,
            "target_pixels": target_pixels,
            "target_ratio": target_ratio,
            "candidate_pixels_at_threshold": candidate_pixels,
            "candidate_ratio_at_threshold": candidate_ratio,
            "shadow_pixels": shadow_pixels,
            "shadow_ratio": shadow_ratio,
        })

    csv_path = args.output_dir / "recognition_debug.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        fieldnames = list(rows[0].keys()) if rows else [
            "stem",
            "render_path",
            "target_path",
            "azimuth",
            "target_pixels",
            "target_ratio",
            "candidate_pixels_at_threshold",
            "candidate_ratio_at_threshold",
            "shadow_pixels",
            "shadow_ratio",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"[recognition debug] wrote {len(rows)} images -> {maps_dir}")
    print(f"[recognition debug] stats: {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
