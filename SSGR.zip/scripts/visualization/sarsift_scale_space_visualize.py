#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SAR-SIFT 多尺度空间 + 对数梯度 (Gx,Gy,|∇|,θ) + SAR-Harris 角点响应 R — 图像化/量化导出

与 scripts/data_prep/feature_extraction.py::build_scale 算法一致（同一公式与数值防护），
额外返回每层 Gx、Gy 便于画「梯度分量」热图。

依赖: numpy, scipy, matplotlib；读图推荐 opencv-python（无则用 matplotlib 读 PNG）

用法示例:
  # 默认即：总览 + 统计 CSV + gray_scales 单张（band）
  python scripts/visualization/sarsift_scale_space_visualize.py -i foo.png -o out_viz

输出（默认一次全要：不要加 --skip_*；--gray_mode 默认 band 会写 gray_scales）:
  - overview.png（--skip_overview 可关）每层一行: |∇|, 方向伪彩, Gx, Gy, Harris R
  - input_preprocessed.png（--skip_overview 可关，matplotlib 预览含标题）
  - gray_scales/scale_XX.png  与输入同分辨率、无标注纯灰度（--gray_mode 默认 band；none 可关）
  - scale_space_stats.csv（--skip_stats 可关）
  - tensors.npz（可选 --npz）
"""
from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np
import scipy.ndimage

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.colors as mcolors
    import matplotlib.pyplot as plt
except ImportError as e:
    print("需要 matplotlib:", e)
    sys.exit(1)


def fspecial_gauss(size: int, sigma: float) -> np.ndarray:
    x, y = np.mgrid[-size // 2 + 1 : size // 2 + 1, -size // 2 + 1 : size // 2 + 1]
    g = np.float64(np.exp(-((x**2 + y**2) / (2.0 * sigma**2))))
    return g / g.sum()


def preprocess_sar_like_repo(image: np.ndarray) -> np.ndarray:
    """与 sar/utils.py preprocess_sar_image 一致思路：eps + [0,1]。"""
    img = image.astype(np.float64)
    img = np.maximum(img, 1e-8)
    if img.max() > 1.0:
        img = img / 255.0
    return img


def load_grayscale(path: Path) -> np.ndarray:
    """
    读取灰度图。Windows 下 cv2.imread 对含中文等非 ANSI 路径会失败，改用内存解码。
    """
    path = path.expanduser()
    if not path.is_file():
        raise FileNotFoundError(f"图像不存在或不是文件: {path}")

    try:
        import cv2

        data = path.read_bytes()
        buf = np.frombuffer(data, dtype=np.uint8)
        im = cv2.imdecode(buf, cv2.IMREAD_GRAYSCALE)
        if im is None:
            raise FileNotFoundError(
                f"cv2.imdecode 失败（文件损坏或格式不支持）: {path}"
            )
        return im
    except ImportError:
        p = str(path)
        im = plt.imread(p)
        if im.ndim == 3:
            im = 0.299 * im[..., 0] + 0.587 * im[..., 1] + 0.114 * im[..., 2]
        return (im * 255.0).astype(np.uint8) if im.max() <= 1.0 else im.astype(np.uint8)


def resolve_layer_count(height: int, width: int, Mmax: int) -> int:
    diag = math.sqrt(height * height + width * width)
    if diag > 500:
        return min(Mmax, 8)
    if diag > 200:
        return min(Mmax, 10)
    return Mmax


def imwrite_gray_png(path: Path, gray_u8: np.ndarray) -> None:
    """写入单通道 PNG，兼容 Windows 下 Unicode 路径。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    import cv2

    ok, buf = cv2.imencode(".png", gray_u8)
    if not ok:
        raise RuntimeError(f"cv2.imencode 失败: {path}")
    path.write_bytes(buf.tobytes())


def _float_to_uint8_robust(x: np.ndarray, lo: float = 0.5, hi: float = 99.5) -> np.ndarray:
    a = np.percentile(x, lo)
    b = np.percentile(x, hi)
    if b <= a:
        b = a + 1e-12
    y = (x - a) / (b - a)
    return np.clip(np.round(y * 255.0), 0, 255).astype(np.uint8)


def build_exponential_kernel_weights(
    height: int,
    width: int,
    sigma: float,
    ratio: float,
    layer_index: int,
) -> np.ndarray:
    """与 build_scale_space 相同的指数权全核 W（返回未归一化，与内部一致）。"""
    scale = float(sigma * ratio ** layer_index)
    max_allowed_radius = min(height, width) // 4
    radius = min(int(round(2 * scale)), max_allowed_radius)
    radius = max(radius, 1)
    j = np.arange(-radius, radius + 1, dtype=np.float64)
    xarry, yarry = np.meshgrid(j, j)
    W = np.exp(-(np.abs(xarry) + np.abs(yarry)) / scale)
    return W


def multi_scale_smoothed_stack(
    image: np.ndarray,
    sigma: float,
    ratio: float,
    L: int,
) -> np.ndarray:
    """每层：I 与完整 SAR-SIFT 指数核相关；核归一化使常数图近似保持不变。"""
    M, N = image.shape
    S = np.zeros((M, N, L), dtype=np.float64)
    for i in range(L):
        W = build_exponential_kernel_weights(M, N, sigma, ratio, i)
        Wn = W / (np.sum(W) + 1e-12)
        S[:, :, i] = scipy.ndimage.correlate(image, Wn, mode="nearest")
    return S


def export_plain_gray_scales(
    out_dir: Path,
    img_float: np.ndarray,
    sigma: float,
    ratio: float,
    Mmax: int,
    mode: str,
    G_stack: np.ndarray | None = None,
    include_input_ref: bool = False,
) -> int:
    """
    导出纯灰度 PNG：无标题、与 img_float 同尺寸。
    mode: smoothed | band | gradmag
    """
    M, N = img_float.shape
    L = resolve_layer_count(M, N, Mmax)
    sub = out_dir / "gray_scales"
    sub.mkdir(parents=True, exist_ok=True)

    if mode == "gradmag":
        if G_stack is None:
            raise ValueError("gradmag 需要 G_stack")
        for i in range(G_stack.shape[2]):
            u8 = _float_to_uint8_robust(G_stack[:, :, i])
            imwrite_gray_png(sub / f"scale_{i:02d}.png", u8)
    else:
        S = multi_scale_smoothed_stack(img_float, sigma, ratio, L)
        if mode == "smoothed":
            for i in range(L):
                u8 = _float_to_uint8_robust(S[:, :, i])
                imwrite_gray_png(sub / f"scale_{i:02d}.png", u8)
        elif mode == "band":
            # 尺度分离：相邻平滑之差；最后一层为最粗平滑（低频残差）
            for i in range(L - 1):
                d = S[:, :, i] - S[:, :, i + 1]
                u8 = _float_to_uint8_robust(d)
                imwrite_gray_png(sub / f"scale_{i:02d}.png", u8)
            u8_last = _float_to_uint8_robust(S[:, :, L - 1])
            imwrite_gray_png(sub / f"scale_{L - 1:02d}.png", u8_last)
        else:
            raise ValueError(f"未知 gray_mode: {mode}")

    if include_input_ref:
        u8_in = _float_to_uint8_robust(img_float)
        imwrite_gray_png(sub / "input_preprocessed.png", u8_in)

    return L


def build_scale_space(
    image: np.ndarray,
    sigma: float,
    Mmax: int,
    ratio: float,
    d: float,
):
    """
    与 feature_extraction.build_scale 同款；另返回 Gx, Gy (每层 M×N)。

    返回:
      R: SAR-Harris 响应 (M,N,L)
      G: sqrt(Gx^2+Gy^2)
      angle: 度 [0,360)
      Gx, Gy: 对数梯度分量
      effective_Mmax: 大图裁层后的实际层数
      sigmas: 每层尺度 sigma_i = sigma * ratio^i
    """
    M, N = image.shape
    L = resolve_layer_count(M, N, Mmax)
    R = np.zeros((M, N, L))
    G = np.zeros((M, N, L))
    ang = np.zeros((M, N, L))
    Gx_all = np.zeros((M, N, L))
    Gy_all = np.zeros((M, N, L))
    sigmas = []

    for i in range(L):
        scale = float(sigma * ratio ** i)
        sigmas.append(scale)
        max_allowed_radius = min(M, N) // 4
        radius = min(int(round(2 * scale)), max_allowed_radius)
        radius = max(radius, 1)

        j = list(range(-radius, radius + 1))
        k = list(range(-radius, radius + 1))
        xarry, yarry = np.meshgrid(j, k)
        W = np.exp(-(np.abs(xarry) + np.abs(yarry)) / scale)

        W34 = np.zeros((2 * radius + 1, 2 * radius + 1), dtype=float)
        W12 = np.zeros((2 * radius + 1, 2 * radius + 1), dtype=float)
        W14 = np.zeros((2 * radius + 1, 2 * radius + 1), dtype=float)
        W23 = np.zeros((2 * radius + 1, 2 * radius + 1), dtype=float)

        center_idx = radius
        if center_idx + 1 <= 2 * radius:
            W34[center_idx + 1 : 2 * radius + 1, :] = W[center_idx + 1 : 2 * radius + 1, :]
        W12[0:center_idx, :] = W[0:center_idx, :]
        if center_idx + 1 <= 2 * radius:
            W14[:, center_idx + 1 : 2 * radius + 1] = W[:, center_idx + 1 : 2 * radius + 1]
        W23[:, 0:center_idx] = W[:, 0:center_idx]

        M34 = scipy.ndimage.correlate(image, W34, mode="nearest")
        M12 = scipy.ndimage.correlate(image, W12, mode="nearest")
        M14 = scipy.ndimage.correlate(image, W14, mode="nearest")
        M23 = scipy.ndimage.correlate(image, W23, mode="nearest")

        with np.errstate(divide="ignore", invalid="ignore"):
            Gx = np.log(np.where(M23 != 0, M14 / M23, 1.0))
            Gy = np.log(np.where(M12 != 0, M34 / M12, 1.0))

        Gx = np.nan_to_num(Gx, nan=0.0, posinf=0.0, neginf=0.0)
        Gy = np.nan_to_num(Gy, nan=0.0, posinf=0.0, neginf=0.0)
        Gx[np.where(np.imag(Gx))] = np.abs(Gx[np.where(np.imag(Gx))])
        Gy[np.where(np.imag(Gy))] = np.abs(Gy[np.where(np.imag(Gy))])
        Gx[np.where(np.isfinite(Gx) == 0)] = 0
        Gy[np.where(np.isfinite(Gy) == 0)] = 0

        Gx_all[:, :, i] = Gx
        Gy_all[:, :, i] = Gy
        G[:, :, i] = np.sqrt(np.square(Gx) + np.square(Gy))
        temp_angle = np.arctan2(Gy, Gx)
        temp_angle = temp_angle / math.pi * 180.0
        temp_angle[np.where(temp_angle < 0)] = temp_angle[np.where(temp_angle < 0)] + 360.0
        ang[:, :, i] = temp_angle

        Csh_11 = scale**2 * np.square(Gx)
        Csh_12 = scale**2 * Gx * Gy
        Csh_22 = scale**2 * np.square(Gy)

        gaussian_sigma = math.sqrt(2) * scale
        width = round(3 * gaussian_sigma)
        width = min(width, min(M, N) // 4)
        width_windows = int(2 * width + 1)

        if width_windows > 1:
            W_g = fspecial_gauss(width_windows, gaussian_sigma)
            l = list(range(0, width_windows))
            a, b = np.meshgrid(l, l)
            idx0, idx1 = np.where((np.square(a - width) - 1) + np.square(b - width - 1) > width**2)
            W_g[idx0, idx1] = 0
            C11 = scipy.ndimage.correlate(Csh_11, W_g, mode="nearest")
            C12 = scipy.ndimage.correlate(Csh_12, W_g, mode="nearest")
            C22 = scipy.ndimage.correlate(Csh_22, W_g, mode="nearest")
            R[:, :, i] = C11 * C22 - C12 * C12 - d * (C11 + C22) ** 2
        else:
            R[:, :, i] = Csh_11 * Csh_22 - Csh_12 * Csh_12 - d * (Csh_11 + Csh_22) ** 2

    return R, G, ang, Gx_all, Gy_all, L, np.array(sigmas, dtype=np.float64)


def _robust_norm01(x: np.ndarray, lo: float = 1.0, hi: float = 99.0) -> np.ndarray:
    a = np.percentile(x, lo)
    b = np.percentile(x, hi)
    if b <= a:
        b = a + 1e-12
    return np.clip((x - a) / (b - a), 0.0, 1.0)


def angle_rgb(theta_deg: np.ndarray, mag: np.ndarray) -> np.ndarray:
    """HSV: hue=方向, value=|∇| 归一化。"""
    vn = _robust_norm01(mag)
    h = (theta_deg % 360.0) / 360.0
    s = np.full_like(h, 0.92)
    v = vn
    hsv = np.stack([h, s, v], axis=-1)
    return mcolors.hsv_to_rgb(hsv)


def save_overview(
    image: np.ndarray,
    R: np.ndarray,
    G: np.ndarray,
    ang: np.ndarray,
    Gx: np.ndarray,
    Gy: np.ndarray,
    sigmas: np.ndarray,
    out_png: Path,
    dpi: int,
):
    """每层一行 × 5 列：|∇|, 方向伪彩, Gx, Gy, R"""
    L = R.shape[2]
    fig_w = 3.2 * 5
    fig_h = max(2.2, 1.8 * L)
    fig, axes = plt.subplots(L, 5, figsize=(fig_w, fig_h), constrained_layout=True)
    if L == 1:
        axes = np.array([axes])

    for i in range(L):
        g = G[:, :, i]
        gx = Gx[:, :, i]
        gy = Gy[:, :, i]
        r = R[:, :, i]
        th = ang[:, :, i]

        ax0, ax1, ax2, ax3, ax4 = axes[i]

        ax0.imshow(_robust_norm01(g), cmap="magma", vmin=0, vmax=1)
        ax0.set_title(f"L{i} σ={sigmas[i]:.3f} |∇|", fontsize=9)
        ax0.axis("off")

        ax1.imshow(angle_rgb(th, g))
        ax1.set_title("θ (HSV×|∇|)", fontsize=9)
        ax1.axis("off")

        gx_d = _robust_norm01(gx, 0.5, 99.5)
        ax2.imshow(gx_d, cmap="RdBu_r", vmin=0, vmax=1)
        ax2.set_title("Gx (log比 分位拉伸)", fontsize=9)
        ax2.axis("off")

        gy_d = _robust_norm01(gy, 0.5, 99.5)
        ax3.imshow(gy_d, cmap="RdBu_r", vmin=0, vmax=1)
        ax3.set_title("Gy (log比 分位拉伸)", fontsize=9)
        ax3.axis("off")

        rlo, rhi = np.percentile(r, 1.0), np.percentile(r, 99.0)
        if rlo >= 0:
            ax4.imshow(_robust_norm01(r), cmap="viridis", vmin=0, vmax=1)
        else:
            vmax = max(abs(rlo), abs(rhi), 1e-12)
            ax4.imshow(r, cmap="coolwarm", vmin=-vmax, vmax=vmax)
        ax4.set_title("Harris R", fontsize=9)
        ax4.axis("off")

    fig.suptitle("SAR-SIFT 多尺度：梯度幅值 / 方向 / Gx,Gy / Harris 响应（与 feature_extraction.build_scale 一致）", fontsize=11)
    fig.savefig(out_png, dpi=dpi)
    plt.close(fig)


def write_stats_csv(path: Path, R, G, sigmas: np.ndarray):
    lines = ["layer,sigma,G_mean,G_std,G_p95,G_max,R_mean,R_std,R_p95,R_max,R_min,R_frac_pos"]
    L = R.shape[2]
    for i in range(L):
        g = G[:, :, i].ravel()
        r = R[:, :, i].ravel()
        frac_pos = float(np.mean(r > 0))
        lines.append(
            f"{i},{sigmas[i]:.8f},"
            f"{float(np.mean(g)):.8f},{float(np.std(g)):.8f},{float(np.percentile(g,95)):.8f},{float(np.max(g)):.8f},"
            f"{float(np.mean(r)):.8f},{float(np.std(r)):.8f},{float(np.percentile(r,95)):.8f},{float(np.max(r)):.8f},{float(np.min(r)):.8f},"
            f"{frac_pos:.8f}"
        )
    path.write_text("\n".join(lines), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description="SAR-SIFT 尺度空间 + 梯度 + Harris 可视化")
    ap.add_argument("-i", "--input", type=Path, required=True, help="输入灰度图路径")
    ap.add_argument("-o", "--output_dir", type=Path, default=Path("sarsift_scale_viz_out"))
    ap.add_argument("--sigma", type=float, default=2.0, help="初始尺度 σ")
    ap.add_argument("--ratio", type=float, default=2 ** (1.0 / 3.0), help="层间比例 r，σ_i=σ·r^i")
    ap.add_argument("--Mmax", type=int, default=8, help="尺度层数上限（大图会截断）")
    ap.add_argument("--d", type=float, default=0.04, help="Harris 抑制项系数 d")
    ap.add_argument("--no_preprocess", action="store_true", help="不归一化/eps（不推荐）")
    ap.add_argument("--dpi", type=int, default=140)
    ap.add_argument(
        "--gray_mode",
        choices=("none", "smoothed", "band", "gradmag"),
        default="band",
        help="导出 gray_scales/scale_XX.png（默认 band，与总览/统计一并生成；设 none 可关闭单张导出）",
    )
    ap.add_argument(
        "--gray_include_input",
        action="store_true",
        help="在 gray_scales 下额外写入 input_preprocessed.png（默认不写，仅各尺度）",
    )
    ap.add_argument("--skip_overview", action="store_true", help="不生成 overview.png 与 matplotlib 版 input_preprocessed（默认会生成）")
    ap.add_argument("--skip_stats", action="store_true", help="不写 scale_space_stats.csv（默认会写）")
    ap.add_argument("--npz", action="store_true", help="额外写入 tensors.npz")
    args = ap.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)

    raw = load_grayscale(args.input)
    if args.no_preprocess:
        img = raw.astype(np.float64)
        if img.max() > 1.0:
            img = img / 255.0
    else:
        img = preprocess_sar_like_repo(raw)

    R, G, ang, Gx, Gy, L, sigmas = build_scale_space(img, args.sigma, args.Mmax, args.ratio, args.d)

    if args.gray_mode != "none":
        export_plain_gray_scales(
            args.output_dir,
            img,
            args.sigma,
            args.ratio,
            args.Mmax,
            args.gray_mode,
            G_stack=G if args.gray_mode == "gradmag" else None,
            include_input_ref=bool(args.gray_include_input),
        )

    if not args.skip_overview:
        out_over = args.output_dir / "overview.png"
        save_overview(img, R, G, ang, Gx, Gy, sigmas, out_over, args.dpi)
        plt.figure(figsize=(4, 4))
        plt.imshow(img, cmap="gray", vmin=0, vmax=1)
        plt.axis("off")
        plt.title("输入（预处理后）")
        plt.tight_layout()
        plt.savefig(args.output_dir / "input_preprocessed.png", dpi=args.dpi)
        plt.close()
    if not args.skip_stats:
        write_stats_csv(args.output_dir / "scale_space_stats.csv", R, G, sigmas)

    if args.npz:
        np.savez_compressed(
            args.output_dir / "tensors.npz",
            image=img.astype(np.float32),
            R=R.astype(np.float32),
            G=G.astype(np.float32),
            angle=ang.astype(np.float32),
            Gx=Gx.astype(np.float32),
            Gy=Gy.astype(np.float32),
            sigmas=sigmas.astype(np.float32),
            sigma0=args.sigma,
            ratio=args.ratio,
            d=args.d,
        )

    print(f"完成: {args.output_dir}")
    parts = []
    if not args.skip_overview:
        parts.append("总览 overview.png + input_preprocessed.png")
    if not args.skip_stats:
        parts.append("统计 scale_space_stats.csv")
    if args.gray_mode != "none":
        parts.append(f"单尺度灰度 gray_scales/scale_XX.png ({args.gray_mode})")
    if args.npz:
        parts.append("tensors.npz")
    if parts:
        print("已生成: " + "；".join(parts) + "。")
    if args.gray_mode != "none":
        print(f"  单张目录: {args.output_dir / 'gray_scales'}")
    if not args.skip_overview:
        print(f"  总览: {args.output_dir / 'overview.png'}")
    if not args.skip_stats:
        print(f"  统计: {args.output_dir / 'scale_space_stats.csv'}")
    if args.npz:
        print(f"  NPZ: {args.output_dir / 'tensors.npz'}")
    print(f"有效层数 L={L}, 各层 σ={np.array2string(sigmas, precision=4)}")


if __name__ == "__main__":
    main()
