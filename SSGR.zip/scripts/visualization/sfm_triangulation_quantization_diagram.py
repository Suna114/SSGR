#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SAR SfM 三角化「图像量化 → RD 物理观测 → 双球面求交」示意图

与 sar/sorc_sfm.py::_triangulate_point、compute_rd_reprojection_error 一致。

用法:
  python scripts/visualization/sfm_triangulation_quantization_diagram.py
  python scripts/visualization/sfm_triangulation_quantization_diagram.py -o docs/figures/triangulation_quant.png
  python scripts/visualization/sfm_triangulation_quantization_diagram.py --dpi 200 --format pdf

依赖: numpy, matplotlib
"""
from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np

# --- repo root on sys.path ---
for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _root = _repo
        if str(_repo) not in sys.path:
            sys.path.insert(0, str(_repo))
        break
else:
    raise RuntimeError("无法定位仓库根目录（缺少 train.py）")

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle
    from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
except ImportError as e:
    print("需要 matplotlib:", e)
    sys.exit(1)

try:
    from sar.geometry import DEFAULT_SAR_PARAMS, compute_sar_camera_pose
except ImportError:
    DEFAULT_SAR_PARAMS = {
        "camera_height": 12000.0,
        "Va": 250.0,
        "prf": 2500.0,
        "fs": 500e6,
        "C": 3e8,
        "Na": 128,
        "Nr": 128,
        "scene_scale": 0.1,
        "camera_distribution_mode": "sphere",
    }
    compute_sar_camera_pose = None


def _setup_chinese_font() -> None:
    from matplotlib import font_manager

    for name in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Arial Unicode MS"):
        if any(name in f.name for f in font_manager.fontManager.ttflist):
            plt.rcParams["font.sans-serif"] = [name, "DejaVu Sans"]
            plt.rcParams["font.monospace"] = [name, "DejaVu Sans Mono"]
            plt.rcParams["axes.unicode_minus"] = False
            return
    plt.rcParams["axes.unicode_minus"] = False


def pixel_to_rd_obs(
    u: float,
    v: float,
    R0: float,
    Na: float,
    Nr: float,
    delta_a: float,
    delta_r: float,
) -> tuple[float, float]:
    """像素 → RD 物理观测 (a_obs, R_obs)。"""
    x_c = u - Na / 2.0
    y_c = v - Nr / 2.0
    a_obs = x_c * delta_a
    r_obs = R0 + y_c * delta_r
    return a_obs, r_obs


def triangulate_two_spheres(
    P1: np.ndarray,
    P2: np.ndarray,
    R1: float,
    R2: float,
) -> tuple[np.ndarray | None, np.ndarray | None]:
    """双球面交（与 sar/sorc_sfm.py::_triangulate_point 同型）。"""
    d_vec = P2 - P1
    d = float(np.linalg.norm(d_vec))
    if d < 1e-9:
        return None, None
    u = d_vec / d
    min_r, max_r = min(R1, R2), max(R1, R2)
    if not (abs(max_r - min_r) <= d <= min_r + max_r):
        return None, None
    a = (R1 * R1 - R2 * R2 + d * d) / (2.0 * d)
    h_sq = max(0.0, R1 * R1 - a * a)
    h = math.sqrt(h_sq)
    to_origin = -P1
    if np.linalg.norm(to_origin) < 1e-9:
        to_origin = np.array([1.0, 0.0, 0.0])
    v = to_origin - np.dot(to_origin, u) * u
    vn = np.linalg.norm(v)
    if vn < 1e-9:
        ref = np.array([0.0, 1.0, 0.0]) if abs(u[1]) < 0.9 else np.array([1.0, 0.0, 0.0])
        v = ref - np.dot(ref, u) * u
        vn = np.linalg.norm(v)
    v = v / vn
    c = P1 + a * u
    X1 = c + h * v
    X2 = c - h * v
    return X1, X2


def build_demo_geometry(
    Na: int,
    Nr: int,
    dep1: float,
    azi1: float,
    dep2: float,
    azi2: float,
    u1: float,
    v1: float,
    u2: float,
    v2: float,
) -> dict:
    """构造与仓库默认参数一致的演示几何。"""
    sp = DEFAULT_SAR_PARAMS.copy()
    sp["Na"] = Na
    sp["Nr"] = Nr
    C = sp["C"]
    fs = sp["fs"]
    Va = sp["Va"]
    prf = sp["prf"]
    delta_r = C / (2.0 * fs)
    delta_a = Va / prf

    if compute_sar_camera_pose is not None:
        dep_rad = math.radians(dep1)
        R0_ref = sp["camera_height"] / math.sin(dep_rad)
        sp["unified_sita0_for_radius"] = dep_rad
        sp.setdefault("radius_scale", (max(Na, Nr) * sp.get("scene_scale", 0.1)) / R0_ref)
        R1, t1, _ = compute_sar_camera_pose(dep1, azi1, sp)
        R2, t2, _ = compute_sar_camera_pose(dep2, azi2, sp)
        P1 = (-R1.T @ t1).flatten()
        P2 = (-R2.T @ t2).flatten()
    else:
        # 简化演示位姿
        r = 12.0
        P1 = np.array([r * math.sin(math.radians(dep1)) * math.cos(math.radians(azi1)),
                       -r * math.cos(math.radians(dep1)),
                       r * math.sin(math.radians(dep1)) * math.sin(math.radians(azi1))])
        P2 = np.array([r * math.sin(math.radians(dep2)) * math.cos(math.radians(azi2)),
                       -r * math.cos(math.radians(dep2)),
                       r * math.sin(math.radians(dep2)) * math.sin(math.radians(azi2))])
        R1 = t1 = R2 = t2 = None

    R0_1 = float(np.linalg.norm(P1))
    R0_2 = float(np.linalg.norm(P2))
    a1, r1 = pixel_to_rd_obs(u1, v1, R0_1, Na, Nr, delta_a, delta_r)
    a2, r2 = pixel_to_rd_obs(u2, v2, R0_2, Na, Nr, delta_a, delta_r)
    Xa, Xb = triangulate_two_spheres(P1, P2, r1, r2)
    X = Xa if Xa is not None else np.zeros(3)
    if Xa is not None and Xb is not None:
        # 选更靠近原点的解（场景中心）
        X = Xa if np.linalg.norm(Xa) <= np.linalg.norm(Xb) else Xb

    return {
        "Na": Na,
        "Nr": Nr,
        "delta_a": delta_a,
        "delta_r": delta_r,
        "P1": P1,
        "P2": P2,
        "R0_1": R0_1,
        "R0_2": R0_2,
        "u1": u1,
        "v1": v1,
        "u2": u2,
        "v2": v2,
        "a1": a1,
        "r1": r1,
        "a2": a2,
        "r2": r2,
        "X": X,
        "X_candidates": (Xa, Xb),
        "R1": R1,
        "t1": t1,
        "R2": R2,
        "t2": t2,
    }


def _draw_pixel_panel(ax, geom: dict, view: int) -> None:
    Na, Nr = geom["Na"], geom["Nr"]
    u, v = (geom["u1"], geom["v1"]) if view == 1 else (geom["u2"], geom["v2"])
    a_obs, r_obs = (geom["a1"], geom["r1"]) if view == 1 else (geom["a2"], geom["r2"])
    dep = 30.0 if view == 1 else 35.0

    ax.set_xlim(-0.5, Na - 0.5)
    ax.set_ylim(Nr - 0.5, -0.5)
    ax.set_aspect("equal")
    ax.set_title(f"视图 {view}：像素量化网格  ({Na}×{Nr})", fontsize=11, fontweight="bold")

    # 网格
    step = max(1, Na // 8)
    for i in range(0, Na + 1, step):
        ax.axvline(i - 0.5, color="#cccccc", lw=0.5, zorder=0)
    for j in range(0, Nr + 1, step):
        ax.axhline(j - 0.5, color="#cccccc", lw=0.5, zorder=0)

    # 图像中心
    cx, cy = Na / 2.0, Nr / 2.0
    ax.plot(cx, cy, "k+", ms=10, mew=1.5, zorder=2)
    ax.annotate("中心 (Na/2, Nr/2)", (cx, cy), xytext=(cx + 8, cy + 6),
                fontsize=8, color="#333333",
                arrowprops=dict(arrowstyle="->", color="#666666", lw=0.8))

    # 关键点
    ax.plot(u, v, "o", color="#e74c3c", ms=10, zorder=5, label="匹配关键点")
    ax.annotate(
        f"$(u_{view}, v_{view})=({u:.0f}, {v:.0f})$",
        (u, v),
        xytext=(u + 10, v - 12),
        fontsize=9,
        color="#c0392b",
        arrowprops=dict(arrowstyle="->", color="#e74c3c", lw=1.2),
    )

    # 偏移量标注
    ax.annotate(
        "",
        xy=(u, cy),
        xytext=(cx, cy),
        arrowprops=dict(arrowstyle="<->", color="#2980b9", lw=1.5),
    )
    ax.text((u + cx) / 2, cy + 4, f"$x_c=u-{Na}/2={u - cx:.0f}$ px", ha="center", fontsize=8, color="#2980b9")
    ax.annotate(
        "",
        xy=(cx, v),
        xytext=(cx, cy),
        arrowprops=dict(arrowstyle="<->", color="#27ae60", lw=1.5),
    )
    ax.text(cx + 6, (v + cy) / 2, f"$y_c=v-{Nr}/2={v - cy:.0f}$ px", fontsize=8, color="#27ae60")

    # 合成示意 SAR 条带
    rng = np.random.default_rng(42 + view)
    bg = rng.uniform(0.15, 0.85, (Nr, Na))
    ax.imshow(bg, extent=[-0.5, Na - 0.5, Nr - 0.5, -0.5], cmap="gray", alpha=0.35, zorder=0)

    info = (
        f"$\\delta_A = V_a/\\mathrm{{PRF}} = {geom['delta_a']:.4f}$ m/px\n"
        f"$\\delta_R = c/(2f_s) = {geom['delta_r']:.4f}$ m/px\n"
        f"$R_0 = \\|P_{{radar,{view}}}\\| = {geom['R0_1' if view == 1 else 'R0_2']:.2f}$ m\n"
        f"$a_{{obs}} = x_c \\delta_A = {a_obs:.3f}$ m\n"
        f"$R_{{obs}} = R_0 + y_c \\delta_R = {r_obs:.3f}$ m"
    )
    ax.text(
        0.02,
        0.98,
        info,
        transform=ax.transAxes,
        va="top",
        fontsize=7.5,
        bbox=dict(boxstyle="round,pad=0.35", facecolor="white", edgecolor="#aaaaaa", alpha=0.92),
        family="monospace",
    )
    ax.set_xlabel("方位向 u (像素)")
    ax.set_ylabel("距离向 v (像素)")


def _draw_mapping_panel(ax, geom: dict) -> None:
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis("off")
    ax.set_title("量化映射：离散像素 → RD 物理观测", fontsize=11, fontweight="bold")

    boxes = [
        (0.3, 7.2, 4.2, 2.2, "#ebf5fb", "① 像素量化（离散）",
         r"$\mathbf{p}=(u,v)\in\mathbb{Z}^2$" + "\n"
         r"$x_c = u - N_a/2,\; y_c = v - N_r/2$"),
        (5.5, 7.2, 4.2, 2.2, "#e8f8f5", "② 物理步长",
         r"$\delta_A = V_a/\mathrm{PRF}$" + "\n"
         r"$\delta_R = c/(2f_s)$"),
        (0.3, 3.8, 4.2, 2.5, "#fef9e7", "③ RD 观测",
         r"$a_{\mathrm{obs}} = x_c \cdot \delta_A$" + "\n"
         r"$R_{\mathrm{obs}} = R_0 + y_c \cdot \delta_R$" + "\n"
         r"$R_0 = \|P_{\mathrm{radar}}\|$"),
        (5.5, 3.8, 4.2, 2.5, "#fdedec", "④ 双球面约束",
         r"$\|X-P_1\| = R_{\mathrm{obs},1}$" + "\n"
         r"$\|X-P_2\| = R_{\mathrm{obs},2}$" + "\n"
         r"$\Rightarrow$ 求交得 $X\in\mathbb{R}^3$"),
    ]
    for x, y, w, h, color, title, body in boxes:
        ax.add_patch(FancyBboxPatch(
            (x, y), w, h, boxstyle="round,pad=0.08,rounding_size=0.15",
            facecolor=color, edgecolor="#7f8c8d", linewidth=1.2,
        ))
        ax.text(x + 0.15, y + h - 0.35, title, fontsize=9.5, fontweight="bold", va="top")
        ax.text(x + 0.15, y + h - 0.85, body, fontsize=9, va="top")

    arrows = [
        ((4.5, 8.3), (5.5, 8.3)),
        ((2.4, 7.2), (2.4, 6.3)),
        ((7.6, 7.2), (7.6, 6.3)),
        ((4.5, 5.0), (5.5, 5.0)),
    ]
    for p0, p1 in arrows:
        ax.annotate(
            "",
            xy=p1,
            xytext=p0,
            arrowprops=dict(arrowstyle="->", color="#2c3e50", lw=1.8, mutation_scale=12),
        )

    # 数值实例
    ex = (
        f"示例（视图1/2）:\n"
        f"  (u1,v1)=({geom['u1']:.0f},{geom['v1']:.0f}) -> R1={geom['r1']:.2f} m\n"
        f"  (u2,v2)=({geom['u2']:.0f},{geom['v2']:.0f}) -> R2={geom['r2']:.2f} m\n"
        f"  重建 X ~ ({geom['X'][0]:.2f}, {geom['X'][1]:.2f}, {geom['X'][2]:.2f}) m"
    )
    ax.text(
        0.3, 0.35, ex, fontsize=8.5,
        bbox=dict(boxstyle="round", facecolor="white", edgecolor="#bdc3c7"),
        family="monospace",
    )


def _draw_sphere_panel(ax, geom: dict) -> None:
    P1, P2 = geom["P1"], geom["P2"]
    R1, R2 = geom["r1"], geom["r2"]
    X = geom["X"]

    ax.set_title("双球面三角化（3D）", fontsize=11, fontweight="bold")

    # 球面网格（线框）
    u = np.linspace(0, 2 * np.pi, 24)
    v = np.linspace(0, np.pi, 16)

    def sphere_mesh(center, radius, color, alpha=0.12):
        x = center[0] + radius * np.outer(np.cos(u), np.sin(v))
        y = center[1] + radius * np.outer(np.sin(u), np.sin(v))
        z = center[2] + radius * np.outer(np.ones_like(u), np.cos(v))
        ax.plot_surface(x, y, z, color=color, alpha=alpha, linewidth=0, shade=True)

    sphere_mesh(P1, R1, "#3498db")
    sphere_mesh(P2, R2, "#e67e22")

    ax.scatter(*P1, color="#2980b9", s=60, depthshade=True, label=r"$P_{radar,1}$")
    ax.scatter(*P2, color="#d35400", s=60, depthshade=True, label=r"$P_{radar,2}$")
    ax.scatter(0, 0, 0, color="black", s=30, marker="x", label="场景中心 O")
    ax.scatter(*X, color="#c0392b", s=80, depthshade=True, label=r"三角化点 $X$")

    ax.plot([P1[0], X[0]], [P1[1], X[1]], [P1[2], X[2]], "b--", lw=1.2, alpha=0.8)
    ax.plot([P2[0], X[0]], [P2[1], X[1]], [P2[2], X[2]], color="#e67e22", ls="--", lw=1.2, alpha=0.8)
    ax.text(X[0], X[1], X[2], "  X", fontsize=9, color="#c0392b")

    # 等比例
    pts = np.vstack([P1, P2, X, [0, 0, 0]])
    center = pts.mean(axis=0)
    span = max(float(np.max(np.abs(pts - center))) * 1.35, R1 * 0.15, 1.0)
    ax.set_xlim(center[0] - span, center[0] + span)
    ax.set_ylim(center[1] - span, center[1] + span)
    ax.set_zlim(center[2] - span, center[2] + span)
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_zlabel("Z (m)")
    ax.legend(loc="upper left", fontsize=7.5)
    ax.view_init(elev=22, azim=-58)


def _draw_flow_panel(ax, geom: dict) -> None:
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.set_title("三角化数据流（与 sfm/sorc_sfm.py 一致）", fontsize=11, fontweight="bold")

    steps = [
        (0.04, 0.55, "SAR-SIFT\n匹配 track", "#ecf0f1"),
        (0.22, 0.55, "像素 (u,v)\n离散量化", "#d6eaf8"),
        (0.40, 0.55, r"$a_obs, R_obs$" + "\nRD 物理量", "#d5f5e3"),
        (0.58, 0.55, "双球面求交\n‖X−P_k‖=R_k", "#fdebd0"),
        (0.76, 0.55, "多对选优\nRD 重投影", "#f5eef8"),
        (0.92, 0.55, "3D 点云", "#fadbd8"),
    ]
    w, h = 0.14, 0.28
    for x, y, label, color in steps:
        ax.add_patch(FancyBboxPatch(
            (x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.03",
            transform=ax.transAxes, facecolor=color, edgecolor="#566573", linewidth=1,
        ))
        ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", fontsize=8, transform=ax.transAxes)

    for i in range(len(steps) - 1):
        x0 = steps[i][0] + w
        x1 = steps[i + 1][0]
        y = steps[i][1] + h / 2
        ax.annotate(
            "",
            xy=(x1, y),
            xytext=(x0, y),
            xycoords=ax.transAxes,
            arrowprops=dict(arrowstyle="->", color="#2c3e50", lw=1.5),
        )

    note = (
        "说明: 距离向像素 v 经 δ_R 直接决定 R_obs 并驱动球面半径；"
        "方位向 u 经 δ_A 得 a_obs，用于重投影选优与 SO-RCG 优化。"
    )
    ax.text(0.5, 0.18, note, ha="center", va="center", fontsize=8.5, transform=ax.transAxes,
            bbox=dict(boxstyle="round", facecolor="white", edgecolor="#bdc3c7"))


def render_diagram(out_path: Path, dpi: int = 150) -> Path:
    _setup_chinese_font()
    geom = build_demo_geometry(
        Na=128,
        Nr=128,
        dep1=30.0,
        azi1=45.0,
        dep2=35.0,
        azi2=60.0,
        u1=78.0,
        v1=52.0,
        u2=70.0,
        v2=58.0,
    )

    fig = plt.figure(figsize=(16, 11), facecolor="white")
    fig.suptitle(
        "SAR SfM 三维点三角化：图像量化表示与双球面几何",
        fontsize=14,
        fontweight="bold",
        y=0.98,
    )

    gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 1.05, 0.55], hspace=0.38, wspace=0.22)

    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    _draw_pixel_panel(ax1, geom, view=1)
    _draw_pixel_panel(ax2, geom, view=2)

    ax_map = fig.add_subplot(gs[1, 0])
    _draw_mapping_panel(ax_map, geom)

    ax_3d = fig.add_subplot(gs[1, 1], projection="3d")
    _draw_sphere_panel(ax_3d, geom)

    ax_flow = fig.add_subplot(gs[2, :])
    _draw_flow_panel(ax_flow, geom)

    footer = (
        f"默认 SAR 参数: H={DEFAULT_SAR_PARAMS.get('camera_height', 12000):.0f} m, "
        f"Va={DEFAULT_SAR_PARAMS.get('Va', 250)} m/s, PRF={DEFAULT_SAR_PARAMS.get('prf', 2500)} Hz, "
        f"fs={DEFAULT_SAR_PARAMS.get('fs', 500e6)/1e6:.0f} MHz | "
        f"代码: sar/sorc_sfm.py::_triangulate_point"
    )
    fig.text(0.5, 0.01, footer, ha="center", fontsize=8, color="#666666")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=dpi, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(description="绘制 SAR SfM 三角化量化表示图")
    parser.add_argument(
        "-o", "--output",
        type=Path,
        default=_root / "docs" / "figures" / "sfm_triangulation_quantization.png",
        help="输出路径（默认 docs/figures/sfm_triangulation_quantization.png）",
    )
    parser.add_argument("--dpi", type=int, default=150, help="输出 DPI")
    parser.add_argument(
        "--format",
        choices=("png", "pdf", "svg"),
        default=None,
        help="输出格式（默认由扩展名推断）",
    )
    args = parser.parse_args()

    out = args.output
    if args.format:
        out = out.with_suffix(f".{args.format}")

    path = render_diagram(out, dpi=args.dpi)
    print(f"已保存: {path.resolve()}")


if __name__ == "__main__":
    main()
