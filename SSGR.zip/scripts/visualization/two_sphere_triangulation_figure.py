#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Minimal dual-sphere SAR triangulation figure.

Two semi-transparent intersecting spheres with math-symbol labels only.

Usage:
  # Interactive 3D viewer (rotate to find angle, then press s to save)
  python scripts/visualization/two_sphere_triangulation_figure.py --interactive

  # Static export
  python scripts/visualization/two_sphere_triangulation_figure.py -o docs/figures/two_sphere_triangulation.png

Interactive controls:
  drag mouse  rotate view
  scroll      zoom
  s           save screenshot (uses -o path)
  p           print current elev / azim
  q           quit

Requires: numpy, matplotlib
"""
from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _root = _repo
        if str(_repo) not in sys.path:
            sys.path.insert(0, str(_repo))
        break
else:
    raise RuntimeError("Cannot locate repo root (train.py missing)")

try:
    from sar.geometry import DEFAULT_SAR_PARAMS, compute_sar_camera_pose
except ImportError:
    DEFAULT_SAR_PARAMS = {
        "camera_height": 12000.0,
        "Va": 250.0,
        "prf": 2500.0,
        "fs": 500e6,
        "C": 3e8,
        "Na": 128,
        "Nr": 128,
        "scene_scale": 0.1,
        "camera_distribution_mode": "sphere",
    }
    compute_sar_camera_pose = None


def _import_pyplot(*, interactive: bool):
    import matplotlib

    if interactive:
        for backend in ("Qt5Agg", "TkAgg", "WXAgg", "MacOSX"):
            try:
                matplotlib.use(backend, force=True)
                break
            except ImportError:
                continue
    else:
        matplotlib.use("Agg")

    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

    return plt


def _pixel_to_r_obs(u, v, R0, Na, Nr, delta_a, delta_r):
    x_c = u - Na / 2.0
    y_c = v - Nr / 2.0
    return x_c * delta_a, R0 + y_c * delta_r


def _triangulate_two_spheres(P1, P2, R1, R2):
    d_vec = P2 - P1
    d = float(np.linalg.norm(d_vec))
    if d < 1e-9:
        return None, None
    u = d_vec / d
    min_r, max_r = min(R1, R2), max(R1, R2)
    if not (abs(max_r - min_r) <= d <= min_r + max_r):
        return None, None
    a = (R1 * R1 - R2 * R2 + d * d) / (2.0 * d)
    h = math.sqrt(max(0.0, R1 * R1 - a * a))
    to_origin = -P1
    if np.linalg.norm(to_origin) < 1e-9:
        to_origin = np.array([1.0, 0.0, 0.0])
    v = to_origin - np.dot(to_origin, u) * u
    vn = np.linalg.norm(v)
    if vn < 1e-9:
        ref = np.array([0.0, 1.0, 0.0]) if abs(u[1]) < 0.9 else np.array([1.0, 0.0, 0.0])
        v = ref - np.dot(ref, u) * u
        vn = np.linalg.norm(v)
    v = v / vn
    c = P1 + a * u
    return c + h * v, c - h * v


def build_geometry(
    Na=128,
    Nr=128,
    dep1=28.0,
    azi1=15.0,
    dep2=34.0,
    azi2=135.0,
    u1=78.0,
    v1=52.0,
    u2=70.0,
    v2=58.0,
):
    sp = DEFAULT_SAR_PARAMS.copy()
    sp["Na"] = Na
    sp["Nr"] = Nr
    C, fs, Va, prf = sp["C"], sp["fs"], sp["Va"], sp["prf"]
    delta_r = C / (2.0 * fs)
    delta_a = Va / prf

    if compute_sar_camera_pose is not None:
        dep_rad = math.radians(dep1)
        R0_ref = sp["camera_height"] / math.sin(dep_rad)
        sp["unified_sita0_for_radius"] = dep_rad
        sp.setdefault("radius_scale", (max(Na, Nr) * sp.get("scene_scale", 0.1)) / R0_ref)
        R1m, t1, _ = compute_sar_camera_pose(dep1, azi1, sp)
        R2m, t2, _ = compute_sar_camera_pose(dep2, azi2, sp)
        P1 = (-R1m.T @ t1).flatten()
        P2 = (-R2m.T @ t2).flatten()
    else:
        r = 12.0
        P1 = np.array([
            r * math.sin(math.radians(dep1)) * math.cos(math.radians(azi1)),
            -r * math.cos(math.radians(dep1)),
            r * math.sin(math.radians(dep1)) * math.sin(math.radians(azi1)),
        ])
        P2 = np.array([
            r * math.sin(math.radians(dep2)) * math.cos(math.radians(azi2)),
            -r * math.cos(math.radians(dep2)),
            r * math.sin(math.radians(dep2)) * math.sin(math.radians(azi2)),
        ])

    R0_1, R0_2 = float(np.linalg.norm(P1)), float(np.linalg.norm(P2))
    _, r1 = _pixel_to_r_obs(u1, v1, R0_1, Na, Nr, delta_a, delta_r)
    _, r2 = _pixel_to_r_obs(u2, v2, R0_2, Na, Nr, delta_a, delta_r)
    Xa, Xb = _triangulate_two_spheres(P1, P2, r1, r2)
    X = Xa if Xa is not None else np.zeros(3)
    if Xa is not None and Xb is not None:
        X = Xa if np.linalg.norm(Xa) <= np.linalg.norm(Xb) else Xb
    return {"P1": P1, "P2": P2, "r1": r1, "r2": r2, "X": X}


def _sphere_mesh(center, radius, n_u=36, n_v=24):
    u = np.linspace(0, 2 * np.pi, n_u)
    v = np.linspace(0, np.pi, n_v)
    x = center[0] + radius * np.outer(np.cos(u), np.sin(v))
    y = center[1] + radius * np.outer(np.sin(u), np.sin(v))
    z = center[2] + radius * np.outer(np.ones_like(u), np.cos(v))
    return x, y, z


def _label(ax, pos, text, offset=(0.0, 0.0, 0.0), fontsize=13, color="black"):
    p = np.asarray(pos, dtype=float) + np.asarray(offset, dtype=float)
    ax.text(p[0], p[1], p[2], text, fontsize=fontsize, color=color, ha="center", va="center")


def _set_equal_aspect(ax, points, margin=1.25):
    pts = np.asarray(points)
    center = pts.mean(axis=0)
    span = max(float(np.max(np.linalg.norm(pts - center, axis=1))) * margin, 1.0)
    ax.set_xlim(center[0] - span, center[0] + span)
    ax.set_ylim(center[1] - span, center[1] + span)
    ax.set_zlim(center[2] - span, center[2] + span)


def _hide_axes(ax):
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_zticks([])
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.set_zlabel("")
    ax.grid(False)
    try:
        ax.set_box_aspect([1, 1, 1])
    except AttributeError:
        pass
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.pane.set_facecolor((1.0, 1.0, 1.0, 0.0))
        axis.pane.set_edgecolor((1.0, 1.0, 1.0, 0.0))
    ax.xaxis.line.set_color((1.0, 1.0, 1.0, 0.0))
    ax.yaxis.line.set_color((1.0, 1.0, 1.0, 0.0))
    ax.zaxis.line.set_color((1.0, 1.0, 1.0, 0.0))


def _configure_style(plt):
    plt.rcParams.update({
        "mathtext.fontset": "stix",
        "font.family": "STIXGeneral",
    })


def build_scene(plt, elev: float = 22.0, azim: float = -58.0, **geom_kwargs):
    _configure_style(plt)
    geom = build_geometry(**geom_kwargs)
    P1, P2, R1, R2, X = geom["P1"], geom["P2"], geom["r1"], geom["r2"], geom["X"]

    fig = plt.figure(figsize=(9, 9), facecolor="white")
    ax = fig.add_subplot(111, projection="3d")

    x1, y1, z1 = _sphere_mesh(P1, R1)
    x2, y2, z2 = _sphere_mesh(P2, R2)
    ax.plot_surface(x1, y1, z1, color="#4A90D9", alpha=0.28, linewidth=0, shade=True, antialiased=True)
    ax.plot_surface(x2, y2, z2, color="#E8943A", alpha=0.28, linewidth=0, shade=True, antialiased=True)

    ax.scatter(*P1, color="#2E6DA4", s=55, depthshade=False, zorder=5)
    ax.scatter(*P2, color="#C76B1D", s=55, depthshade=False, zorder=5)
    ax.scatter(*X, color="#C0392B", s=70, depthshade=False, zorder=6)

    ax.plot([P1[0], X[0]], [P1[1], X[1]], [P1[2], X[2]], color="#2E6DA4", ls="--", lw=1.4, alpha=0.85)
    ax.plot([P2[0], X[0]], [P2[1], X[1]], [P2[2], X[2]], color="#C76B1D", ls="--", lw=1.4, alpha=0.85)

    span_hint = max(R1, R2, float(np.linalg.norm(P2 - P1))) * 0.12
    _label(ax, P1, r"$P_1$", offset=(-span_hint * 0.9, span_hint * 0.5, span_hint * 0.3), color="#2E6DA4")
    _label(ax, P2, r"$P_2$", offset=(span_hint * 0.9, span_hint * 0.4, span_hint * 0.2), color="#C76B1D")
    _label(ax, X, r"$X$", offset=(span_hint * 0.35, span_hint * 0.35, span_hint * 0.45), color="#C0392B", fontsize=14)

    mid1 = 0.55 * P1 + 0.45 * X
    mid2 = 0.55 * P2 + 0.45 * X
    n1 = np.cross(P1 - X, P2 - P1)
    n1 = n1 / (np.linalg.norm(n1) + 1e-9)
    n2 = np.cross(P2 - X, P1 - P2)
    n2 = n2 / (np.linalg.norm(n2) + 1e-9)
    _label(ax, mid1, r"$R_{\mathrm{obs},1}$", offset=n1 * span_hint * 0.55, color="#2E6DA4", fontsize=12)
    _label(ax, mid2, r"$R_{\mathrm{obs},2}$", offset=n2 * span_hint * 0.55, color="#C76B1D", fontsize=12)

    _set_equal_aspect(ax, np.vstack([P1, P2, X]))
    _hide_axes(ax)
    ax.view_init(elev=elev, azim=azim)
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    return fig, ax


def _save_figure(fig, out_path: Path, dpi: int) -> Path:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=dpi, bbox_inches="tight", pad_inches=0.05, facecolor="white", transparent=False)
    return out_path


def render_figure(
    out_path: Path,
    dpi: int = 200,
    elev: float = 22.0,
    azim: float = -58.0,
    **geom_kwargs,
) -> Path:
    plt = _import_pyplot(interactive=False)
    fig, _ = build_scene(plt, elev=elev, azim=azim, **geom_kwargs)
    path = _save_figure(fig, out_path, dpi)
    plt.close(fig)
    return path


def show_interactive(
    out_path: Path,
    dpi: int = 200,
    elev: float = 22.0,
    azim: float = -58.0,
    **geom_kwargs,
) -> None:
    plt = _import_pyplot(interactive=True)
    fig, ax = build_scene(plt, elev=elev, azim=azim, **geom_kwargs)

    print("Interactive 3D viewer opened.")
    print("  drag mouse : rotate")
    print("  scroll     : zoom")
    print("  s          : save screenshot ->", out_path)
    print("  p          : print current elev / azim")
    print("  q          : quit")

    def on_key(event):
        if event.key == "s":
            path = _save_figure(fig, out_path, dpi)
            print(f"Saved: {path.resolve()}  (elev={ax.elev:.2f}, azim={ax.azim:.2f})")
            print(f"  Reproduce: --elev {ax.elev:.2f} --azim {ax.azim:.2f}")
        elif event.key == "p":
            print(f"elev={ax.elev:.2f}, azim={ax.azim:.2f}")
            print(f"  Reproduce: --elev {ax.elev:.2f} --azim {ax.azim:.2f}")
        elif event.key in ("q", "escape"):
            plt.close(fig)

    fig.canvas.mpl_connect("key_press_event", on_key)
    plt.show()


def main() -> None:
    parser = argparse.ArgumentParser(description="Dual-sphere triangulation figure (math labels only)")
    parser.add_argument(
        "-o", "--output",
        type=Path,
        default=_root / "docs" / "figures" / "two_sphere_triangulation.png",
        help="Output path for save (key s in interactive mode, or static export)",
    )
    parser.add_argument(
        "-i", "--interactive",
        action="store_true",
        help="Open interactive 3D viewer to rotate and screenshot",
    )
    parser.add_argument("--dpi", type=int, default=200)
    parser.add_argument("--elev", type=float, default=22.0, help="Initial elevation (deg)")
    parser.add_argument("--azim", type=float, default=-58.0, help="Initial azimuth (deg)")
    parser.add_argument("--dep1", type=float, default=28.0, help="Depression angle for P1 (deg)")
    parser.add_argument("--azi1", type=float, default=15.0, help="Azimuth angle for P1 (deg)")
    parser.add_argument("--dep2", type=float, default=34.0, help="Depression angle for P2 (deg)")
    parser.add_argument("--azi2", type=float, default=135.0, help="Azimuth angle for P2 (deg)")
    parser.add_argument("--format", choices=("png", "pdf", "svg"), default=None)
    args = parser.parse_args()

    out = args.output.with_suffix(f".{args.format}") if args.format else args.output
    geom_kwargs = dict(dep1=args.dep1, azi1=args.azi1, dep2=args.dep2, azi2=args.azi2)

    if args.interactive:
        show_interactive(out, dpi=args.dpi, elev=args.elev, azim=args.azim, **geom_kwargs)
    else:
        path = render_figure(out, dpi=args.dpi, elev=args.elev, azim=args.azim, **geom_kwargs)
        print(f"Saved: {path.resolve()}")


if __name__ == "__main__":
    main()
