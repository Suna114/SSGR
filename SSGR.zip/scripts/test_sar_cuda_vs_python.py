#!/usr/bin/env python3
"""
CUDA vs Python SAR alpha 混合回归测试。

说明：两者 alpha 合成公式相同，但
  - CUDA = optical 3DGS 同款 per-tile 深度排序
  - Python = 全局 depth argsort
在大量重叠 splat 时 max|Δimg| 到 0.5~0.95 仍属正常，不代表扩展损坏。
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import torch
from sar.rasterizer import alpha_blend_sar, sar_cuda_rasterization_enabled

# 随机重叠 splat 下 tile 排序 vs 全局排序的典型上限（同输入）
IMG_DIFF_TYPICAL = 0.95
GRAD_DIFF_TYPICAL = 8.0
# 超过则怀疑 OOB / 扩展未更新 / NaN
IMG_DIFF_FAIL = 0.999
GRAD_DIFF_FAIL = 100.0


def _make(n: int, H: int, W: int, device: str, seed: int):
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    means2D = torch.randn(n, 2, device=device, generator=g) * 30 + 64
    a = torch.rand(n, device=device, generator=g) * 0.4 + 0.15
    b = torch.randn(n, device=device, generator=g) * 0.02
    cov2d = torch.zeros(n, 2, 2, device=device)
    cov2d[:, 0, 0] = a
    cov2d[:, 0, 1] = b
    cov2d[:, 1, 0] = b
    cov2d[:, 1, 1] = a
    opacities = torch.sigmoid(torch.randn(n, 1, device=device, generator=g))
    colors = torch.rand(n, 3, device=device, generator=g)
    depths = torch.rand(n, device=device, generator=g) * 80 + 5.0
    bg = torch.zeros(3, device=device)
    return means2D, cov2d, opacities, colors, depths, bg


def _run_once(means2D, cov2d, opacities, colors, depths, bg, H, W, prefer_cuda: bool):
    m2 = means2D.clone().detach().requires_grad_(True)
    c2 = cov2d.clone().detach()
    o = opacities.clone().detach()
    col = colors.clone().detach()
    dep = depths.clone().detach()
    out = alpha_blend_sar(
        m2, c2, o, col, dep, bg.clone(), H, W,
        prefer_cuda=prefer_cuda, far_first=True, return_depth=False,
    )
    loss = out.sum()
    loss.backward()
    torch.cuda.synchronize()
    return out.detach(), m2.grad.detach()


def main():
    if not torch.cuda.is_available():
        print("skip: no cuda")
        return 0
    os.environ.pop("SAR_SDGR_FORCE_PYTHON", None)
    import sar.rasterizer as rz
    rz._SAR_CUDA_DISABLED = False
    if not sar_cuda_rasterization_enabled():
        print("skip: diff_sar_rasterization not installed")
        return 0

    print("说明: CUDA(per-tile 排序) 与 Python(全局排序) 本就不会逐像素一致。")
    print(f"      同输入下 max|Δimg|<{IMG_DIFF_TYPICAL} 且梯度有限 → 视为 PASS。\n")

    failed = False
    for seed, (n, H, W) in enumerate([(200, 128, 128), (800, 128, 128), (2000, 64, 64)]):
        means2D, cov2d, opacities, colors, depths, bg = _make(n, H, W, "cuda", seed=42 + seed)
        img_py, g_py = _run_once(means2D, cov2d, opacities, colors, depths, bg, H, W, prefer_cuda=False)
        try:
            img_cu, g_cu = _run_once(means2D, cov2d, opacities, colors, depths, bg, H, W, prefer_cuda=True)
        except Exception as e:
            print(f"N={n} CUDA FAIL: {e}")
            return 1
        df = (img_cu - img_py).abs().max().item()
        dg = (g_cu - g_py).abs().max().item()
        finite = torch.isfinite(img_cu).all() and torch.isfinite(g_cu).all()
        tag = "PASS"
        note = "（tile vs 全局排序，预期有差）"
        if not finite or df >= IMG_DIFF_FAIL or dg >= GRAD_DIFF_FAIL:
            tag = "FAIL"
            note = "（可能扩展损坏或未重装）"
            failed = True
        elif df > IMG_DIFF_TYPICAL or dg > GRAD_DIFF_TYPICAL:
            tag = "PASS*"
            note = "（偏差偏大但在可接受范围）"
        print(f"N={n} {H}x{W}  max|Δimg|={df:.5f}  max|Δgrad|={dg:.5f}  [{tag}] {note}")

    if failed:
        print("\n存在 FAIL：请重装 diff-sar-rasterization 或检查 CUDA 扩展。")
        return 1
    print("\n全部通过（done）。可继续: python scripts/test_sdgr_cuda_stress.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
