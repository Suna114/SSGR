#!/usr/bin/env python3
"""
Learn an image-domain SAR-like refiner from paired target-only renders and real images.

The intended workflow is:
  1) 3DGS renders clean target-only training/novel views.
  2) This script learns background, shadow, and layover from paired train views.
  3) The learned refiner is applied to novel target-only renders.

This deliberately keeps SAR artifacts out of 3DGS geometry optimization.
"""

from __future__ import annotations

import math
import os
import re
import sys
from argparse import ArgumentParser, BooleanOptionalAction
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from PIL import Image
from tqdm import tqdm


for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))


def _image_files(path: Path) -> list[Path]:
    exts = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
    return sorted([p for p in path.iterdir() if p.suffix.lower() in exts])


def _parse_azimuth(path_or_name) -> float:
    stem = Path(str(path_or_name)).stem
    m = re.search(r"(?i)azimuth[_-]?(\d+(?:\.\d+)?)", stem)
    if m:
        return float(m.group(1)) % 360.0
    parts = re.split(r"[-_]", stem)
    for part in reversed(parts):
        if re.fullmatch(r"\d+(?:\.\d+)?", part):
            return float(part) % 360.0
    nums = re.findall(r"(?<!\d)(\d{1,3})(?!\d)", stem)
    if nums:
        return float(nums[-1]) % 360.0
    return 0.0


def _load_image(path: Path, args=None) -> torch.Tensor:
    img = Image.open(path).convert("RGB")
    arr = np.asarray(img, dtype=np.float32) / 255.0
    x = torch.from_numpy(arr).permute(2, 0, 1).contiguous()
    if args is None or bool(getattr(args, "grayscale_sar", True)):
        gray = x.mean(dim=0, keepdim=True)
        x = gray.expand(3, -1, -1).contiguous()
    return x


def _to_loss_domain(x: torch.Tensor, args) -> torch.Tensor:
    mode = str(getattr(args, "intensity_loss_domain", "log") or "linear").lower().strip()
    if mode == "linear":
        return x
    scale = float(getattr(args, "log_intensity_scale", 20.0) or 20.0)
    return torch.log1p(scale * x.clamp_min(0.0)) / math.log1p(scale)


def _resize_chw(x: torch.Tensor, size_hw: tuple[int, int]) -> torch.Tensor:
    if tuple(x.shape[-2:]) == tuple(size_hw):
        return x
    return F.interpolate(x[None], size=size_hw, mode="bilinear", align_corners=False)[0]


def _blur01(x: torch.Tensor, radius: int) -> torch.Tensor:
    if radius <= 0:
        return x.clamp(0.0, 1.0)
    sigma = max(1.0, float(radius) / 2.0)
    xs = torch.arange(-radius, radius + 1, device=x.device, dtype=x.dtype)
    yy, xx = torch.meshgrid(xs, xs, indexing="ij")
    k = torch.exp(-(xx * xx + yy * yy) / (2.0 * sigma * sigma))
    k = (k / k.sum().clamp_min(1e-8)).view(1, 1, 2 * radius + 1, 2 * radius + 1)
    y = F.conv2d(x.view(1, 1, x.shape[-2], x.shape[-1]), k, padding=radius)
    return y.view_as(x).clamp(0.0, 1.0)


def _dilate01(x: torch.Tensor, iterations: int) -> torch.Tensor:
    if iterations <= 0:
        return x.float().clamp(0.0, 1.0)
    y = x.float()[None, None]
    for _ in range(int(iterations)):
        y = F.max_pool2d(y, kernel_size=3, stride=1, padding=1)
    return y[0, 0].clamp(0.0, 1.0)


def _erode01(x: torch.Tensor, iterations: int) -> torch.Tensor:
    if iterations <= 0:
        return x.float().clamp(0.0, 1.0)
    y = 1.0 - x.float()
    y = _dilate01(y, iterations)
    return (1.0 - y).clamp(0.0, 1.0)


def _shift_zero(x: torch.Tensor, dx: int, dy: int) -> torch.Tensor:
    out = torch.zeros_like(x)
    h, w = x.shape[-2], x.shape[-1]
    if abs(dx) >= w or abs(dy) >= h:
        return out
    src_x0 = max(0, -dx)
    src_x1 = min(w, w - dx)
    dst_x0 = max(0, dx)
    dst_x1 = min(w, w + dx)
    src_y0 = max(0, -dy)
    src_y1 = min(h, h - dy)
    dst_y0 = max(0, dy)
    dst_y1 = min(h, h + dy)
    out[..., dst_y0:dst_y1, dst_x0:dst_x1] = x[..., src_y0:src_y1, src_x0:src_x1]
    return out


def _directional_trail(source: torch.Tensor, angle_deg: float, length_px: int, decay: float, blur_radius: int) -> torch.Tensor:
    length_px = max(0, int(length_px))
    if length_px <= 0:
        return torch.zeros_like(source)
    a = math.radians(float(angle_deg))
    ux = math.cos(a)
    uy = math.sin(a)
    trail = torch.zeros_like(source)
    norm = 0.0
    for i in range(1, length_px + 1):
        dx = int(round(ux * i))
        dy = int(round(uy * i))
        weight = math.exp(-float(i) / max(float(decay), 1e-6))
        trail = trail + weight * _shift_zero(source, dx, dy)
        norm += weight
    trail = trail / max(norm, 1e-6)
    if blur_radius > 0:
        if trail.dim() == 2:
            trail = _blur01(trail, blur_radius)
        else:
            chans = [_blur01(trail[c], blur_radius) for c in range(trail.shape[0])]
            trail = torch.stack(chans, dim=0)
    return trail.clamp(0.0, 1.0)


def _target_mask(target: torch.Tensor, threshold: float, quantile: float, dilate: int, blur: int) -> tuple[torch.Tensor, torch.Tensor]:
    gray = target.mean(dim=0)
    nz = gray[gray > 1e-5]
    th = float(threshold)
    if th <= 0.0 and int(nz.numel()) > 16:
        th = float(torch.quantile(nz, min(max(float(quantile), 0.0), 1.0)).item())
    hard = (gray > th).float()
    if int(hard.sum().item()) < 16:
        hard = (gray >= torch.quantile(gray.reshape(-1), 0.90)).float()
    if int(dilate) > 0:
        hard = _dilate01(hard, dilate)
    elif int(dilate) < 0:
        hard = _erode01(hard, -int(dilate))
    soft = _blur01(hard, blur)
    return hard, soft


def _coord_angle_channels(h: int, w: int, azimuth_deg: float, device, dtype) -> torch.Tensor:
    yy = torch.linspace(-1.0, 1.0, h, device=device, dtype=dtype).view(1, h, 1).expand(1, h, w)
    xx = torch.linspace(-1.0, 1.0, w, device=device, dtype=dtype).view(1, 1, w).expand(1, h, w)
    a = math.radians(float(azimuth_deg))
    ca = torch.full((1, h, w), math.cos(a), device=device, dtype=dtype)
    sa = torch.full((1, h, w), math.sin(a), device=device, dtype=dtype)
    return torch.cat([xx, yy, ca, sa], dim=0)


def _noise_condition_channels(
    h: int,
    w: int,
    azimuth_deg: float,
    args,
    device,
    dtype,
    training: bool,
) -> torch.Tensor:
    n = int(getattr(args, "noise_channels", 2) or 0)
    if n <= 0:
        return torch.empty((0, h, w), device=device, dtype=dtype)
    if training:
        gen = None
    else:
        gen = torch.Generator(device=device)
        gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)))
    chans = []
    raw = torch.rand((h, w), device=device, dtype=dtype, generator=gen)
    speckle = -torch.log(raw.clamp_min(1e-6))
    speckle = speckle / speckle.mean().clamp_min(1e-6)
    chans.append((speckle - 1.0).clamp(-2.0, 4.0) / 4.0)
    if n >= 2:
        low = torch.randn((h, w), device=device, dtype=dtype, generator=gen)
        low = _blur01(low, int(getattr(args, "noise_lowfreq_radius", 9) or 9))
        low = (low - low.mean()) / low.std(unbiased=False).clamp_min(1e-6)
        chans.append(low.clamp(-3.0, 3.0) / 3.0)
    for _ in range(len(chans), n):
        chans.append(torch.randn((h, w), device=device, dtype=dtype, generator=gen).clamp(-3.0, 3.0) / 3.0)
    return torch.stack(chans[:n], dim=0)


class ConvBlock(nn.Module):
    def __init__(self, cin: int, cout: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(cin, cout, 3, padding=1, padding_mode="reflect"),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
            nn.Conv2d(cout, cout, 3, padding=1, padding_mode="reflect"),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
        )

    def forward(self, x):
        return self.net(x)


class LocalFeatureEnhancer(nn.Module):
    """DHFR-style local spatial enhancement with neutral initialization."""

    def __init__(self, channels: int, strength: float = 0.25):
        super().__init__()
        hidden = max(8, int(channels) // 4)
        self.strength = float(strength)
        self.mask = nn.Sequential(
            nn.Conv2d(channels, hidden, 3, padding=1),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, 1, 1),
        )
        nn.init.zeros_(self.mask[-1].weight)
        nn.init.zeros_(self.mask[-1].bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        mask = torch.sigmoid(self.mask(x))
        gain = 1.0 + self.strength * (mask - 0.5) * 2.0
        return x * gain


class DynamicHierarchicalFusion(nn.Module):
    """Fuse decoder and skip features with input-adaptive branch weights."""

    def __init__(self, decoder_ch: int, skip_ch: int):
        super().__init__()
        self.skip_enhance = LocalFeatureEnhancer(skip_ch)
        hidden = max(8, (int(decoder_ch) + int(skip_ch)) // 8)
        self.global_gate = nn.Sequential(
            nn.Linear(int(decoder_ch) + int(skip_ch), hidden),
            nn.SiLU(inplace=True),
            nn.Linear(hidden, 2),
        )
        nn.init.zeros_(self.global_gate[-1].weight)
        nn.init.zeros_(self.global_gate[-1].bias)

    def forward(self, decoder: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        skip = self.skip_enhance(skip)
        gd = F.adaptive_avg_pool2d(decoder, 1).flatten(1)
        gs = F.adaptive_avg_pool2d(skip, 1).flatten(1)
        weights = torch.softmax(self.global_gate(torch.cat([gd, gs], dim=1)), dim=1)
        decoder = decoder * (2.0 * weights[:, 0].view(-1, 1, 1, 1))
        skip = skip * (2.0 * weights[:, 1].view(-1, 1, 1, 1))
        return torch.cat([decoder, skip], dim=1)


class ResidualRefineBlock(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1),
            nn.GroupNorm(4, channels),
            nn.SiLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1),
            nn.GroupNorm(4, channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.silu(x + self.net(x), inplace=True)


class SmallUNet(nn.Module):
    def __init__(self, in_ch: int = 11, base: int = 32):
        super().__init__()
        self.e1 = ConvBlock(in_ch, base)
        self.e2 = ConvBlock(base, base * 2)
        self.e3 = ConvBlock(base * 2, base * 4)
        self.mid = ConvBlock(base * 4, base * 4)
        self.d2 = ConvBlock(base * 6, base * 2)
        self.d1 = ConvBlock(base * 3, base)
        self.out = nn.Conv2d(base, 3, 1)

    def forward(self, x):
        e1 = self.e1(x)
        e2 = self.e2(F.avg_pool2d(e1, 2))
        e3 = self.e3(F.avg_pool2d(e2, 2))
        y = self.mid(e3)
        y = F.interpolate(y, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d2(torch.cat([y, e2], dim=1))
        y = F.interpolate(y, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d1(torch.cat([y, e1], dim=1))
        return torch.sigmoid(self.out(y))


class ResidualDHFRRefiner(nn.Module):
    """Residual SAR refiner: target-only render -> full SAR image."""

    def __init__(self, in_ch: int = 11, base: int = 32, residual_scale: float = 8.0):
        super().__init__()
        self.residual_scale = float(residual_scale)
        self.e1 = ConvBlock(in_ch, base)
        self.e2 = ConvBlock(base, base * 2)
        self.e3 = ConvBlock(base * 2, base * 4)
        self.mid = nn.Sequential(
            ResidualRefineBlock(base * 4),
            ResidualRefineBlock(base * 4),
        )
        self.fuse2 = DynamicHierarchicalFusion(base * 4, base * 2)
        self.fuse1 = DynamicHierarchicalFusion(base * 2, base)
        self.d2 = ConvBlock(base * 6, base * 2)
        self.d1 = ConvBlock(base * 3, base)
        self.delta = nn.Conv2d(base, 3, 1)
        nn.init.zeros_(self.delta.weight)
        nn.init.zeros_(self.delta.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        target = x[:, :3].clamp(1e-3, 1.0 - 1e-3)
        e1 = self.e1(x)
        e2 = self.e2(F.avg_pool2d(e1, 2))
        e3 = self.e3(F.avg_pool2d(e2, 2))
        y = self.mid(e3)
        y = F.interpolate(y, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d2(self.fuse2(y, e2))
        y = F.interpolate(y, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d1(self.fuse1(y, e1))
        delta = torch.tanh(self.delta(y)) * self.residual_scale
        return torch.sigmoid(torch.logit(target) + delta)


class FullDHFRRefiner(nn.Module):
    """Direct full-image SAR refiner: target-only render -> target/background/shadow SAR image."""

    def __init__(
        self,
        in_ch: int = 11,
        base: int = 32,
        target_detail_mix: float = 0.65,
        target_detail_logit_scale: float = 4.0,
    ):
        super().__init__()
        self.target_detail_mix = min(max(float(target_detail_mix), 0.0), 1.0)
        self.target_detail_logit_scale = float(target_detail_logit_scale)
        self.e1 = ConvBlock(in_ch, base)
        self.e2 = ConvBlock(base, base * 2)
        self.e3 = ConvBlock(base * 2, base * 4)
        self.mid = nn.Sequential(
            ResidualRefineBlock(base * 4),
            ResidualRefineBlock(base * 4),
            ResidualRefineBlock(base * 4),
        )
        self.fuse2 = DynamicHierarchicalFusion(base * 4, base * 2)
        self.fuse1 = DynamicHierarchicalFusion(base * 2, base)
        self.d2 = ConvBlock(base * 6, base * 2)
        self.d1 = ConvBlock(base * 3, base)
        self.out = nn.Conv2d(base, 3, 1)
        self.target_delta = nn.Conv2d(base, 3, 1)
        nn.init.zeros_(self.target_delta.weight)
        nn.init.zeros_(self.target_delta.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        target = x[:, :3].clamp(1e-3, 1.0 - 1e-3)
        target_alpha = x[:, 4:5].clamp(0.0, 1.0) if x.shape[1] >= 5 else torch.zeros_like(target[:, :1])
        e1 = self.e1(x)
        e2 = self.e2(F.avg_pool2d(e1, 2))
        e3 = self.e3(F.avg_pool2d(e2, 2))
        y = self.mid(e3)
        y = F.interpolate(y, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d2(self.fuse2(y, e2))
        y = F.interpolate(y, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d1(self.fuse1(y, e1))
        full = torch.sigmoid(self.out(y))
        if self.target_detail_mix <= 0.0:
            return full
        detail_delta = torch.tanh(self.target_delta(y)) * self.target_detail_logit_scale
        target_detail = torch.sigmoid(torch.logit(target) + detail_delta)
        alpha = (target_alpha * self.target_detail_mix).clamp(0.0, 1.0)
        return (full * (1.0 - alpha) + target_detail * alpha).clamp(0.0, 1.0)


class ConditionalDiscriminator(nn.Module):
    def __init__(self, in_ch: int = 12, base: int = 32):
        super().__init__()

        def conv(cin, cout):
            return nn.Sequential(
                nn.utils.spectral_norm(nn.Conv2d(cin, cout, 4, stride=2, padding=1)),
                nn.LeakyReLU(0.2, inplace=True),
            )

        self.body = nn.Sequential(
            conv(in_ch, base),
            conv(base, base * 2),
            conv(base * 2, base * 4),
            conv(base * 4, base * 8),
        )
        self.real_head = nn.utils.spectral_norm(nn.Conv2d(base * 8, 1, 3, padding=1))
        self.az_head = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.utils.spectral_norm(nn.Linear(base * 8, 10)),
        )

    def forward(self, candidate: torch.Tensor, cond: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        feat = self.body(torch.cat([candidate, cond], dim=1))
        return self.real_head(feat), torch.tanh(self.az_head(feat))


def _azimuth_vec_tensor(azimuths: list[float], device, dtype) -> torch.Tensor:
    az = torch.as_tensor(azimuths, device=device, dtype=dtype).view(-1, 1)
    rad = torch.deg2rad(az)
    parts = []
    for k in range(1, 6):
        parts.append(torch.cos(k * rad))
        parts.append(torch.sin(k * rad))
    return torch.cat(parts, dim=1)


def _masked_batch_mean_std(x: torch.Tensor, mask: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    while mask.dim() < x.dim():
        mask = mask.unsqueeze(1)
    denom = mask.sum(dim=(-3, -2, -1)).clamp_min(1.0)
    mean = (x * mask).sum(dim=(-3, -2, -1)) / denom
    var = (((x - mean.view(-1, 1, 1, 1)) ** 2) * mask).sum(dim=(-3, -2, -1)) / denom
    return mean, torch.sqrt(var.clamp_min(1e-8))


def _parse_quantiles(text: str) -> list[float]:
    vals = []
    for part in str(text or "").split(","):
        part = part.strip()
        if not part:
            continue
        vals.append(min(max(float(part), 0.0), 1.0))
    return vals or [0.50, 0.75, 0.90, 0.97]


def _masked_quantile_loss(pred: torch.Tensor, gt: torch.Tensor, mask: torch.Tensor, quantiles: list[float]) -> torch.Tensor:
    while mask.dim() < pred.dim():
        mask = mask.unsqueeze(1)
    losses = []
    q = torch.as_tensor(quantiles, device=pred.device, dtype=pred.dtype)
    for b in range(pred.shape[0]):
        valid = mask[b].expand_as(pred[b]) > 0.5
        if int(valid.sum().item()) < max(16, len(quantiles)):
            continue
        pred_vals = pred[b][valid]
        gt_vals = gt[b][valid]
        losses.append((torch.quantile(pred_vals, q) - torch.quantile(gt_vals, q)).abs().mean())
    if not losses:
        return torch.zeros((), device=pred.device, dtype=pred.dtype)
    return torch.stack(losses).mean()


def _local_std_map(x: torch.Tensor, radius: int) -> torch.Tensor:
    radius = max(1, int(radius))
    k = 2 * radius + 1
    mean = F.avg_pool2d(x, kernel_size=k, stride=1, padding=radius)
    mean2 = F.avg_pool2d(x * x, kernel_size=k, stride=1, padding=radius)
    return torch.sqrt((mean2 - mean * mean).clamp_min(1e-8))


def _local_mean_map(x: torch.Tensor, radius: int) -> torch.Tensor:
    radius = max(1, int(radius))
    k = 2 * radius + 1
    return F.avg_pool2d(x, kernel_size=k, stride=1, padding=radius)


def _gradient_mag_map(x: torch.Tensor) -> torch.Tensor:
    gray = x.mean(dim=1, keepdim=True)
    kx = torch.tensor(
        [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]],
        device=x.device,
        dtype=x.dtype,
    ).view(1, 1, 3, 3) / 4.0
    ky = kx.transpose(-1, -2)
    gx = F.conv2d(gray, kx, padding=1)
    gy = F.conv2d(gray, ky, padding=1)
    return torch.sqrt(gx * gx + gy * gy + 1e-8)


def _masked_l1(x: torch.Tensor, y: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    while mask.dim() < x.dim():
        mask = mask.unsqueeze(1)
    return ((x - y).abs() * mask).sum() / (mask.sum().clamp_min(1.0) * float(x.shape[1]))


def _border_mask_batch(
    batch_size: int,
    height: int,
    width: int,
    border: int,
    device,
    dtype,
) -> torch.Tensor:
    border = max(0, int(border))
    mask = torch.zeros((batch_size, height, width), device=device, dtype=dtype)
    if border <= 0:
        return mask
    b = min(border, max(height, width))
    mask[:, : min(b, height), :] = 1.0
    mask[:, max(0, height - b) :, :] = 1.0
    mask[:, :, : min(b, width)] = 1.0
    mask[:, :, max(0, width - b) :] = 1.0
    return mask


def _crop_around_mask_batch(
    image: torch.Tensor,
    cond: torch.Tensor,
    mask: torch.Tensor,
    crop_size: int,
    pad_frac: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    crops_i = []
    crops_c = []
    bsz, _ch, h, w = image.shape
    crop_size = max(16, int(crop_size))
    pad_frac = max(0.0, float(pad_frac))
    for b in range(bsz):
        ys, xs = torch.where(mask[b] > 0.5)
        if int(xs.numel()) < 4:
            side = min(h, w)
            x0 = max(0, (w - side) // 2)
            y0 = max(0, (h - side) // 2)
            x1 = x0 + side
            y1 = y0 + side
        else:
            x0i = int(xs.min().item())
            x1i = int(xs.max().item()) + 1
            y0i = int(ys.min().item())
            y1i = int(ys.max().item()) + 1
            bw = max(1, x1i - x0i)
            bh = max(1, y1i - y0i)
            pad = int(round(max(bw, bh) * pad_frac))
            cx = (x0i + x1i) // 2
            cy = (y0i + y1i) // 2
            side = max(bw, bh) + 2 * pad
            x0 = max(0, cx - side // 2)
            y0 = max(0, cy - side // 2)
            x1 = min(w, x0 + side)
            y1 = min(h, y0 + side)
            x0 = max(0, x1 - side)
            y0 = max(0, y1 - side)
        ci = image[b : b + 1, :, y0:y1, x0:x1]
        cc = cond[b : b + 1, :, y0:y1, x0:x1]
        crops_i.append(F.interpolate(ci, size=(crop_size, crop_size), mode="bilinear", align_corners=False)[0])
        crops_c.append(F.interpolate(cc, size=(crop_size, crop_size), mode="bilinear", align_corners=False)[0])
    return torch.stack(crops_i, dim=0), torch.stack(crops_c, dim=0)


def _model_input_channels(args) -> int:
    extra = 1 if float(getattr(args, "shadow_prior_input_weight", 0.0) or 0.0) > 0.0 else 0
    return 9 + int(getattr(args, "noise_channels", 2) or 0) + extra


def _shadow_prior_from_mask(
    mask: torch.Tensor,
    azimuth_deg: float,
    args,
    *,
    force: bool = False,
    strength: float | None = None,
) -> torch.Tensor:
    input_weight = float(getattr(args, "shadow_prior_input_weight", 0.0) or 0.0)
    if not force and input_weight <= 0.0:
        return torch.empty((0, *mask.shape[-2:]), device=mask.device, dtype=mask.dtype)
    angle = float(getattr(args, "shadow_prior_angle_deg", 180.0))
    if bool(getattr(args, "shadow_prior_rotate_with_azimuth", True)):
        angle = float(azimuth_deg) + float(getattr(args, "shadow_prior_angle_offset", 180.0))
    source = mask.float().clamp(0.0, 1.0)
    if bool(getattr(args, "shadow_prior_use_edge_source", True)):
        a = math.radians(float(angle))
        dx = int(round(math.cos(a)))
        dy = int(round(math.sin(a)))
        edge = (source - _shift_zero(source, -dx, -dy)).clamp(0.0, 1.0)
        if int((edge > 1e-4).sum().item()) >= 3:
            source = edge
    length_px = int(round(float(getattr(args, "shadow_prior_length_frac", 0.28)) * max(mask.shape[-2:])))
    trail = _directional_trail(
        source,
        angle,
        length_px,
        decay=max(1.0, length_px * float(getattr(args, "shadow_prior_decay_frac", 0.85))),
        blur_radius=int(getattr(args, "shadow_prior_blur_radius", 2)),
    )
    block = _dilate01(mask, int(getattr(args, "shadow_prior_target_gap", 1) or 0))
    prior = (trail * (1.0 - block)).clamp(0.0, 1.0)
    out_strength = input_weight if strength is None else float(strength)
    if out_strength <= 0.0 and force:
        out_strength = 1.0
    return (prior * out_strength).clamp(0.0, 1.0).unsqueeze(0)


def _build_input(target: torch.Tensor, azimuth_deg: float, args, training: bool = False) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    hard, soft = _target_mask(
        target,
        threshold=float(args.mask_threshold),
        quantile=float(args.mask_quantile),
        dilate=int(args.mask_dilate),
        blur=int(args.mask_blur_radius),
    )
    coord = _coord_angle_channels(target.shape[-2], target.shape[-1], azimuth_deg, target.device, target.dtype)
    noise = _noise_condition_channels(
        target.shape[-2],
        target.shape[-1],
        azimuth_deg,
        args,
        target.device,
        target.dtype,
        training=training,
    )
    shadow_prior = _shadow_prior_from_mask(hard, azimuth_deg, args)
    x = torch.cat([target, hard.unsqueeze(0), soft.unsqueeze(0), coord, noise, shadow_prior], dim=0)
    preserve = (soft >= float(args.target_preserve_threshold)).float()
    preserve = _blur01(preserve, int(args.target_preserve_blur_radius))
    preserve = (preserve * float(args.target_preserve_strength)).clamp(0.0, 1.0)
    return x, hard, preserve


def _compose_prediction(raw: torch.Tensor, target: torch.Tensor, preserve: torch.Tensor) -> torch.Tensor:
    return (raw * (1.0 - preserve.unsqueeze(0)) + target * preserve.unsqueeze(0)).clamp(0.0, 1.0)


def _is_target_modulation_mode(args) -> bool:
    return str(getattr(args, "refiner_mode", "image") or "image").lower().strip() == "target_modulation"


def _is_unified_residual_mode(args) -> bool:
    return str(getattr(args, "refiner_mode", "image") or "image").lower().strip() in {
        "unified_residual",
        "residual",
        "residual_refiner",
    }


def _is_unified_full_mode(args) -> bool:
    return str(getattr(args, "refiner_mode", "image") or "image").lower().strip() in {
        "unified_full",
        "full_dhfr",
        "direct_full",
    }


def _build_refiner_model(args, in_ch: int) -> nn.Module:
    if _is_unified_full_mode(args):
        return FullDHFRRefiner(
            in_ch=in_ch,
            base=int(args.model_base),
            target_detail_mix=float(getattr(args, "target_detail_mix", 0.65) or 0.0),
            target_detail_logit_scale=float(getattr(args, "target_detail_logit_scale", 4.0) or 4.0),
        )
    if _is_unified_residual_mode(args):
        return ResidualDHFRRefiner(
            in_ch=in_ch,
            base=int(args.model_base),
            residual_scale=float(getattr(args, "residual_logit_scale", 8.0) or 8.0),
        )
    return SmallUNet(in_ch=in_ch, base=int(args.model_base))


def _compose_target_modulation_batch(
    raw: torch.Tensor,
    target: torch.Tensor,
    hard_mask: torch.Tensor,
    args,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    raw = raw.clamp(0.0, 1.0)
    if raw.shape[1] < 3:
        raise RuntimeError("target_modulation mode expects a 3-channel refiner output")

    support = hard_mask.float().clamp(0.0, 1.0)
    dilate = int(getattr(args, "target_modulation_mask_dilate", 0) or 0)
    if dilate > 0:
        support = _dilate01_batch(support, dilate)
    blur = int(getattr(args, "target_modulation_mask_blur", 1) or 0)
    if blur > 0:
        support = F.avg_pool2d(support[:, None], kernel_size=2 * blur + 1, stride=1, padding=blur)[:, 0].clamp(0.0, 1.0)
    support = support[:, None]

    speckle_raw = raw[:, 0:1]
    dark_raw = raw[:, 1:2]
    visibility_raw = raw[:, 2:3]

    speckle_strength = max(float(getattr(args, "target_modulation_speckle_strength", 0.55) or 0.0), 0.0)
    mult = torch.exp((speckle_raw - 0.5) * (2.0 * speckle_strength))
    mult_min = float(getattr(args, "target_modulation_mult_min", 0.35) or 0.35)
    mult_max = float(getattr(args, "target_modulation_mult_max", 1.65) or 1.65)
    mult = mult.clamp(min(mult_min, mult_max), max(mult_min, mult_max))

    dark_strength = min(max(float(getattr(args, "target_modulation_dark_strength", 0.75) or 0.0), 0.0), 1.0)
    dark_gamma = max(float(getattr(args, "target_modulation_dark_gamma", 1.25) or 1.25), 0.05)
    dark_floor = min(max(float(getattr(args, "target_modulation_dark_floor", 0.08) or 0.08), 0.0), 1.0)
    dark_factor = (1.0 - dark_strength * dark_raw.pow(dark_gamma)).clamp(dark_floor, 1.0)

    vis_floor = min(max(float(getattr(args, "target_modulation_visibility_floor", 0.12) or 0.12), 0.0), 1.0)
    vis_gamma = max(float(getattr(args, "target_modulation_visibility_gamma", 1.0) or 1.0), 0.05)
    visibility = (vis_floor + (1.0 - vis_floor) * visibility_raw.pow(vis_gamma)).clamp(vis_floor, 1.0)

    factor = (mult * dark_factor * visibility).clamp(0.0, float(getattr(args, "target_modulation_factor_max", 1.8) or 1.8))
    modulated = (target * factor).clamp(0.0, 1.0)
    out = (target * (1.0 - support) + modulated * support).clamp(0.0, 1.0)
    maps = {
        "speckle_multiplier": mult,
        "dark_factor": dark_factor,
        "visibility": visibility,
        "support": support,
        "factor": factor,
    }
    return out, maps


def _compose_target_modulation(
    raw: torch.Tensor,
    target: torch.Tensor,
    hard_mask: torch.Tensor,
    args,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    out, maps = _compose_target_modulation_batch(raw[None], target[None], hard_mask[None], args)
    return out[0], {k: v[0] for k, v in maps.items()}


def _force_grayscale_batch(x: torch.Tensor, args) -> torch.Tensor:
    if not bool(getattr(args, "force_grayscale_output", True)):
        return x
    gray = x.mean(dim=1, keepdim=True)
    return gray.expand(-1, 3, -1, -1).contiguous()


def _force_grayscale_chw(x: torch.Tensor, args) -> torch.Tensor:
    if not bool(getattr(args, "force_grayscale_output", True)):
        return x
    gray = x.mean(dim=0, keepdim=True)
    return gray.expand_as(x).contiguous()


def _target_intensity_alpha(target: torch.Tensor, hard_mask: torch.Tensor, args, prefix: str) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    threshold = float(getattr(args, f"{prefix}_threshold", 0.015))
    high = float(getattr(args, f"{prefix}_high", 0.18))
    alpha = ((gray - threshold) / max(high - threshold, 1e-6)).clamp(0.0, 1.0)
    gamma = max(float(getattr(args, f"{prefix}_gamma", 0.75)), 0.05)
    alpha = alpha.pow(gamma)
    if bool(getattr(args, f"{prefix}_use_mask_floor", False)):
        floor = float(getattr(args, f"{prefix}_mask_floor", 0.25))
        alpha = torch.maximum(alpha, hard_mask.float().clamp(0.0, 1.0) * floor)
    dilate = int(getattr(args, f"{prefix}_dilate", 0))
    if dilate > 0:
        alpha = _dilate01(alpha, dilate)
    elif dilate < 0:
        alpha = _erode01(alpha, -dilate)
    blur = int(getattr(args, f"{prefix}_blur", 0))
    if blur > 0:
        alpha = _blur01(alpha, blur)
    return alpha.clamp(0.0, 1.0)


def _apply_target_passthrough(image: torch.Tensor, target: torch.Tensor, hard_mask: torch.Tensor, args) -> torch.Tensor:
    strength = float(getattr(args, "target_passthrough_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)
    alpha = _target_intensity_alpha(target, hard_mask, args, "target_passthrough_alpha")
    alpha = (alpha * strength).clamp(0.0, 1.0)
    scale = float(getattr(args, "target_passthrough_scale", 1.0) or 1.0)
    gamma = max(float(getattr(args, "target_passthrough_gamma", 1.0) or 1.0), 0.05)
    bias = float(getattr(args, "target_passthrough_bias", 0.0) or 0.0)
    target_src = (target.clamp(0.0, 1.0).pow(gamma) * scale + bias).clamp(0.0, 1.0)
    dark_keep = float(getattr(args, "target_passthrough_preserve_dark_strength", 0.0) or 0.0)
    if dark_keep > 0.0:
        img_gray = image.mean(dim=0).clamp(0.0, 1.0)
        target_gray = target_src.mean(dim=0).clamp(0.0, 1.0)
        th = max(float(getattr(args, "target_passthrough_preserve_dark_threshold", 0.06) or 0.06), 1e-6)
        dark = (torch.relu(target_gray - img_gray) / th).clamp(0.0, 1.0)
        dark = dark * hard_mask.float().clamp(0.0, 1.0)
        blur = int(getattr(args, "target_passthrough_preserve_dark_blur", 1) or 0)
        if blur > 0:
            dark = (_blur01(dark, blur) * hard_mask.float().clamp(0.0, 1.0)).clamp(0.0, 1.0)
        alpha = (alpha * (1.0 - min(max(dark_keep, 0.0), 1.0) * dark)).clamp(0.0, 1.0)
    return (image * (1.0 - alpha.unsqueeze(0)) + target_src * alpha.unsqueeze(0)).clamp(0.0, 1.0)


def _apply_learned_target_envelope(
    image: torch.Tensor,
    target: torch.Tensor,
    learned: torch.Tensor,
    hard_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "learned_target_envelope_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    target_region = hard_mask.float().clamp(0.0, 1.0)
    if int((target_region > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    radius = max(1, int(getattr(args, "learned_target_envelope_radius", 5) or 5))
    learned_gray = learned.mean(dim=0).clamp(0.0, 1.0)
    target_gray = target.mean(dim=0).clamp(0.0, 1.0)
    learned_low = _blur01(learned_gray, radius)
    target_low = _blur01(target_gray, radius)
    ratio = (learned_low + 1e-4) / (target_low + 1e-4)
    ratio_min = float(getattr(args, "learned_target_envelope_min_ratio", 0.35) or 0.35)
    ratio_max = float(getattr(args, "learned_target_envelope_max_ratio", 1.25) or 1.25)
    ratio = ratio.clamp(ratio_min, ratio_max)

    support = _target_intensity_alpha(target, hard_mask, args, "learned_target_envelope_alpha")
    support = (support * target_region).clamp(0.0, 1.0)
    if int(getattr(args, "learned_target_envelope_erode", 0) or 0) > 0:
        support = _erode01(support, int(getattr(args, "learned_target_envelope_erode", 0)))
    support = (support * min(max(strength, 0.0), 1.0)).clamp(0.0, 1.0)

    adjusted_target = (target * ratio.unsqueeze(0)).clamp(0.0, 1.0)
    return (image * (1.0 - support.unsqueeze(0)) + adjusted_target * support.unsqueeze(0)).clamp(0.0, 1.0)


def _apply_learned_target_visibility(
    image: torch.Tensor,
    target: torch.Tensor,
    learned: torch.Tensor,
    hard_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "learned_target_visibility_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    target_region = hard_mask.float().clamp(0.0, 1.0)
    in_target = target_region > 0.5
    if int(in_target.sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    radius = int(getattr(args, "learned_target_visibility_radius", 1) or 0)
    learned_gray = learned.mean(dim=0).clamp(0.0, 1.0)
    if radius > 0:
        learned_gray = _blur01(learned_gray, radius)
    vals = learned_gray[in_target]
    q_low = min(max(float(getattr(args, "learned_target_visibility_low_quantile", 0.20)), 0.0), 1.0)
    q_high = min(max(float(getattr(args, "learned_target_visibility_high_quantile", 0.82)), 0.0), 1.0)
    lo = float(torch.quantile(vals, q_low).detach().item())
    hi = float(torch.quantile(vals, q_high).detach().item())
    visible = ((learned_gray - lo) / max(hi - lo, 1e-6)).clamp(0.0, 1.0)
    gamma = max(float(getattr(args, "learned_target_visibility_gamma", 1.0) or 1.0), 0.05)
    visible = visible.pow(gamma)
    visible_floor = float(getattr(args, "learned_target_visibility_floor", 0.10) or 0.10)
    visibility_scale = (visible_floor + (1.0 - visible_floor) * visible).clamp(0.0, 1.0)

    alpha = _target_intensity_alpha(target, hard_mask, args, "learned_target_visibility_alpha")
    alpha = (alpha * target_region * min(max(strength, 0.0), 1.0)).clamp(0.0, 1.0)
    adjusted_target = (target * visibility_scale.unsqueeze(0)).clamp(0.0, 1.0)
    return (image * (1.0 - alpha.unsqueeze(0)) + adjusted_target * alpha.unsqueeze(0)).clamp(0.0, 1.0)


def _apply_target_layover(image: torch.Tensor, target: torch.Tensor, hard_mask: torch.Tensor, azimuth_deg: float, args) -> torch.Tensor:
    strength = float(getattr(args, "target_layover_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    gray = target.mean(dim=0)
    in_target = hard_mask > 0.5
    if int(in_target.sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    th = float(getattr(args, "target_layover_threshold", 0.0) or 0.0)
    if th <= 0.0:
        q = min(max(float(getattr(args, "target_layover_quantile", 0.78)), 0.0), 1.0)
        th = float(torch.quantile(gray[in_target], q).detach().item())
        max_auto_th = float(getattr(args, "target_layover_max_auto_threshold", 0.95) or 0.95)
        th = min(th, max_auto_th)
    bright = torch.relu(gray - th) / max(1e-6, 1.0 - th)
    bright = (bright * hard_mask).clamp(0.0, 1.0)
    if int((bright > 1e-4).sum().item()) < 4:
        return image.clamp(0.0, 1.0)

    length_px = int(round(float(getattr(args, "target_layover_length_frac", 0.08)) * max(image.shape[-2:])))
    angle = float(azimuth_deg) + float(getattr(args, "target_layover_angle_offset", 180.0))
    trail = _directional_trail(
        bright,
        angle,
        length_px,
        decay=max(1.0, length_px * float(getattr(args, "target_layover_decay_frac", 0.65))),
        blur_radius=int(getattr(args, "target_layover_blur_radius", 1)),
    )

    region = _dilate01(hard_mask, int(getattr(args, "target_layover_mask_dilate", 2)))
    region = _blur01(region, int(getattr(args, "target_layover_mask_blur_radius", 1)))
    inside_strength = min(max(float(getattr(args, "target_layover_inside_strength", 1.0) or 0.0), 0.0), 1.0)
    inside = hard_mask.float().clamp(0.0, 1.0)
    target_gate = (1.0 - inside) + inside_strength * inside
    trail = (trail * region * target_gate).clamp(0.0, 1.0)
    trail_rgb = trail.unsqueeze(0).expand_as(image)

    # Bright layover piles high-scattering responses in the radar direction.
    # A pure screen blend is invisible on saturated target pixels, so keep a
    # small explicit intensity floor along the trail.
    floor = float(getattr(args, "target_layover_floor", 0.35) or 0.0)
    out = image + strength * trail_rgb * (1.0 - image)
    if floor > 0.0:
        out = torch.maximum(out, (floor * strength) * trail_rgb)
    dark = float(getattr(args, "target_layover_local_dark_strength", 0.0) or 0.0)
    if dark > 0.0:
        source_shadow = _directional_trail(
            bright,
            angle + 180.0,
            max(1, length_px // 2),
            decay=max(1.0, length_px * 0.35),
            blur_radius=int(getattr(args, "target_layover_blur_radius", 1)),
        )
        out = out * (1.0 - dark * source_shadow.unsqueeze(0) * region.unsqueeze(0))
    return out.clamp(0.0, 1.0)


def _apply_target_occlusion(image: torch.Tensor, target: torch.Tensor, hard_mask: torch.Tensor, azimuth_deg: float, args) -> torch.Tensor:
    strength = float(getattr(args, "target_occlusion_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    target_region = hard_mask.float().clamp(0.0, 1.0)
    if int((target_region > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    gray = target.mean(dim=0).clamp(0.0, 1.0)
    th = float(getattr(args, "target_occlusion_threshold", 0.0) or 0.0)
    if th <= 0.0:
        q = min(max(float(getattr(args, "target_occlusion_quantile", 0.55)), 0.0), 1.0)
        th = float(torch.quantile(gray[target_region > 0.5], q).detach().item())
        max_auto_th = float(getattr(args, "target_occlusion_max_auto_threshold", 0.90) or 0.90)
        th = min(th, max_auto_th)
    bright = (torch.relu(gray - th) / max(1e-6, 1.0 - th) * target_region).clamp(0.0, 1.0)

    length_px = int(round(float(getattr(args, "target_occlusion_length_frac", 0.08)) * max(image.shape[-2:])))
    angle = float(azimuth_deg) + float(getattr(args, "target_occlusion_angle_offset", 180.0))
    trail = _directional_trail(
        bright,
        angle,
        length_px,
        decay=max(1.0, length_px * float(getattr(args, "target_occlusion_decay_frac", 0.65))),
        blur_radius=int(getattr(args, "target_occlusion_blur_radius", 1)),
    )

    side_weight = float(getattr(args, "target_occlusion_side_weight", 0.0) or 0.0)
    if side_weight > 0.0:
        h, w = gray.shape[-2:]
        yy = torch.linspace(-1.0, 1.0, h, device=gray.device, dtype=gray.dtype).view(h, 1).expand(h, w)
        xx = torch.linspace(-1.0, 1.0, w, device=gray.device, dtype=gray.dtype).view(1, w).expand(h, w)
        a = math.radians(angle)
        coord = xx * math.cos(a) + yy * math.sin(a)
        vals = coord[target_region > 0.5]
        if int(vals.numel()) > 1:
            coord = (coord - vals.min()) / (vals.max() - vals.min()).clamp_min(1e-6)
            start = min(max(float(getattr(args, "target_occlusion_side_start", 0.58) or 0.58), 0.0), 1.0)
            gamma = max(float(getattr(args, "target_occlusion_side_gamma", 1.4) or 1.4), 0.05)
            side = (torch.relu(coord - start) / max(1e-6, 1.0 - start)).clamp(0.0, 1.0).pow(gamma)
            trail = torch.maximum(trail, side_weight * side * target_region)

    occlusion = (trail * target_region).clamp(0.0, 1.0)
    blur = int(getattr(args, "target_occlusion_edge_blur", 0) or 0)
    if blur > 0:
        occlusion = (_blur01(occlusion, blur) * target_region).clamp(0.0, 1.0)
    floor = float(getattr(args, "target_occlusion_floor", 0.0) or 0.0)
    amount = (strength * occlusion).clamp(0.0, 1.0).unsqueeze(0)
    return (image * (1.0 - amount) + floor * amount).clamp(0.0, 1.0)


def _apply_post_speckle(image: torch.Tensor, hard_mask: torch.Tensor, azimuth_deg: float, args) -> torch.Tensor:
    strength = float(getattr(args, "post_speckle_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)
    h, w = image.shape[-2:]
    gen = torch.Generator(device=image.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 991)
    looks = max(1, int(getattr(args, "post_speckle_looks", 2) or 2))
    speckle = torch.zeros((h, w), device=image.device, dtype=image.dtype)
    for _ in range(looks):
        u = torch.rand((h, w), device=image.device, dtype=image.dtype, generator=gen).clamp_min(1e-6)
        speckle = speckle + (-torch.log(u))
    speckle = speckle / float(looks)
    speckle = speckle / speckle.mean().clamp_min(1e-6)
    if int(getattr(args, "post_speckle_blur_radius", 0) or 0) > 0:
        speckle = _blur01(speckle, int(getattr(args, "post_speckle_blur_radius", 0)))
        speckle = speckle / speckle.mean().clamp_min(1e-6)
    gap = int(getattr(args, "post_speckle_target_gap", 1) or 0)
    if gap > 0:
        target_keep = _blur01(_dilate01(hard_mask, gap), 1)
    else:
        target_keep = hard_mask.float().clamp(0.0, 1.0)
    target_amount = float(getattr(args, "post_speckle_on_target", 0.25) or 0.0)
    amount = strength * ((1.0 - target_keep) + target_amount * target_keep)
    out = image * (1.0 + amount.unsqueeze(0) * (speckle.unsqueeze(0) - 1.0))
    floor = float(getattr(args, "post_speckle_floor", 0.0) or 0.0)
    if floor > 0.0:
        out = out.clamp_min(floor)
    return out.clamp(0.0, 1.0)


def _apply_target_radiometry(image: torch.Tensor, target: torch.Tensor, hard_mask: torch.Tensor, azimuth_deg: float, args) -> torch.Tensor:
    strength = float(getattr(args, "target_radiometry_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    shrink = int(getattr(args, "target_radiometry_mask_shrink", 0) or 0)
    if shrink > 0:
        mask = _erode01(mask, shrink)
    edge_blur = int(getattr(args, "target_radiometry_edge_blur", 0) or 0)
    alpha = _blur01(mask, edge_blur) if edge_blur > 0 else mask
    if int((alpha > 1e-4).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    h, w = image.shape[-2:]
    gen = torch.Generator(device=image.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 1777)

    out = image.clamp(0.0, 1.0)
    gray = out.mean(dim=0)
    inside = alpha > 0.05
    if int(inside.sum().item()) >= 8:
        q = min(max(float(getattr(args, "target_radiometry_high_quantile", 0.92)), 0.0), 1.0)
        qv = torch.quantile(gray[inside], q)
        rolloff = min(max(float(getattr(args, "target_radiometry_high_rolloff", 0.45)), 0.0), 1.0) * strength
        compressed = torch.where(out > qv, qv + (out - qv) * (1.0 - rolloff), out)
        out = out * (1.0 - alpha.unsqueeze(0)) + compressed * alpha.unsqueeze(0)

    gamma = max(float(getattr(args, "target_radiometry_gamma", 1.0) or 1.0), 0.05)
    if abs(gamma - 1.0) > 1e-4:
        toned = out.clamp_min(1e-6).pow(gamma)
        out = out * (1.0 - alpha.unsqueeze(0) * strength) + toned * (alpha.unsqueeze(0) * strength)

    dark_strength = float(getattr(args, "target_dark_patch_strength", 0.0) or 0.0) * strength
    if dark_strength > 0.0:
        field = torch.rand((h, w), device=image.device, dtype=image.dtype, generator=gen)
        field = _blur01(field, int(getattr(args, "target_dark_patch_radius", 7) or 7))
        field = (field - field.min()) / (field.max() - field.min()).clamp_min(1e-6)
        field = field.pow(float(getattr(args, "target_dark_patch_gamma", 1.6) or 1.6))
        attenuation = (1.0 - dark_strength * field * alpha).clamp(0.0, 1.0)
        out = out * attenuation.unsqueeze(0)

    mid_strength = float(getattr(args, "target_mid_suppression_strength", 0.0) or 0.0) * strength
    if mid_strength > 0.0 and int(inside.sum().item()) >= 16:
        gray = out.mean(dim=0)
        lo_q = min(max(float(getattr(args, "target_mid_suppression_low_quantile", 0.35)), 0.0), 1.0)
        hi_q = min(max(float(getattr(args, "target_mid_suppression_high_quantile", 0.88)), 0.0), 1.0)
        vals = gray[inside]
        lo = torch.quantile(vals, min(lo_q, hi_q))
        hi = torch.quantile(vals, max(lo_q, hi_q))
        width = (hi - lo).clamp_min(1e-6)
        rise = ((gray - lo) / width).clamp(0.0, 1.0)
        fall = ((hi - gray) / width).clamp(0.0, 1.0)
        mid = (4.0 * rise * fall).clamp(0.0, 1.0) * alpha
        out = out * (1.0 - mid_strength * mid).unsqueeze(0)

    speckle_strength = float(getattr(args, "target_speckle_strength", 0.0) or 0.0) * strength
    if speckle_strength > 0.0:
        looks = max(1, int(getattr(args, "target_speckle_looks", 1) or 1))
        speckle = torch.zeros((h, w), device=image.device, dtype=image.dtype)
        for _ in range(looks):
            u = torch.rand((h, w), device=image.device, dtype=image.dtype, generator=gen).clamp_min(1e-6)
            speckle = speckle + (-torch.log(u))
        speckle = speckle / float(looks)
        speckle = speckle / speckle.mean().clamp_min(1e-6)
        if int(getattr(args, "target_speckle_blur_radius", 0) or 0) > 0:
            speckle = _blur01(speckle, int(getattr(args, "target_speckle_blur_radius", 0)))
            speckle = speckle / speckle.mean().clamp_min(1e-6)
        out = out * (1.0 + speckle_strength * alpha.unsqueeze(0) * (speckle.unsqueeze(0) - 1.0))

    scale = float(getattr(args, "target_brightness_scale", 1.0) or 1.0)
    if abs(scale - 1.0) > 1e-4:
        scaled = out * scale
        out = out * (1.0 - alpha.unsqueeze(0) * strength) + scaled * (alpha.unsqueeze(0) * strength)
    return out.clamp(0.0, 1.0)


def _apply_target_scatter_falloff(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "target_falloff_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    shrink = int(getattr(args, "target_falloff_mask_shrink", 0) or 0)
    if shrink > 0:
        mask = _erode01(mask, shrink)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    gray = image.mean(dim=0).clamp(0.0, 1.0)
    inside = mask > 0.5
    vals = gray[inside]
    if int(vals.numel()) < 8:
        return image.clamp(0.0, 1.0)

    q = min(max(float(getattr(args, "target_falloff_peak_quantile", 0.82)), 0.0), 1.0)
    peak_th = torch.quantile(vals, q)
    peak_scale = (vals.max() - peak_th).clamp_min(1e-6)
    peaks = (torch.relu(gray - peak_th) / peak_scale * mask).clamp(0.0, 1.0)
    if int((peaks > 1e-4).sum().item()) < 2:
        return image.clamp(0.0, 1.0)

    radius = int(getattr(args, "target_falloff_radius", 4) or 4)
    spread = _blur01(peaks, max(1, radius))
    if bool(getattr(args, "target_falloff_directional", True)):
        angle = float(azimuth_deg) + float(getattr(args, "target_falloff_angle_offset", 180.0))
        length_px = int(round(float(getattr(args, "target_falloff_length_frac", 0.08)) * max(image.shape[-2:])))
        trail = _directional_trail(
            peaks,
            angle,
            length_px,
            decay=max(1.0, length_px * float(getattr(args, "target_falloff_decay_frac", 0.70))),
            blur_radius=max(0, int(getattr(args, "target_falloff_trail_blur_radius", 1))),
        )
        spread = torch.maximum(spread, trail * float(getattr(args, "target_falloff_trail_weight", 0.65)))
    spread = spread / spread.max().clamp_min(1e-6)
    support_gamma = max(float(getattr(args, "target_falloff_support_gamma", 1.4) or 1.4), 0.05)
    support = (spread.pow(support_gamma) * mask).clamp(0.0, 1.0)

    low_q = min(max(float(getattr(args, "target_falloff_low_quantile", 0.22)), 0.0), 1.0)
    mid_q = min(max(float(getattr(args, "target_falloff_mid_quantile", 0.58)), 0.0), 1.0)
    low = torch.quantile(vals, low_q)
    mid = torch.quantile(vals, mid_q)
    floor = float(getattr(args, "target_falloff_floor", 0.06) or 0.06)
    ceiling = float(getattr(args, "target_falloff_ceiling", 0.55) or 0.55)
    desired = (low + (mid - low).clamp_min(0.0) * spread).clamp(floor, ceiling)

    # Fill only the valleys near strong scattering centers. Peaks stay sharp,
    # and unrelated background stays controlled by the real-SAR style sampler.
    valley = torch.relu(desired - gray)
    alpha = (strength * support * (1.0 - peaks)).clamp(0.0, 1.0)
    out_gray = (gray + alpha * valley).clamp(0.0, 1.0)
    ratio = out_gray / gray.clamp_min(1e-4)
    out = image * ratio.unsqueeze(0)
    return out.clamp(0.0, 1.0)


def _apply_target_peak_soften(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "target_peak_soften_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    shrink = int(getattr(args, "target_peak_soften_mask_shrink", 0) or 0)
    if shrink > 0:
        mask = _erode01(mask, shrink)
    inside = mask > 0.5
    if int(inside.sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    gray = image.mean(dim=0).clamp(0.0, 1.0)
    vals = gray[inside]
    q = min(max(float(getattr(args, "target_peak_soften_quantile", 0.72)), 0.0), 1.0)
    th = torch.quantile(vals, q)
    peak = (torch.relu(gray - th) / (vals.max() - th).clamp_min(1e-6) * mask).clamp(0.0, 1.0)
    if int((peak > 1e-4).sum().item()) < 2:
        return image.clamp(0.0, 1.0)

    radius = max(1, int(getattr(args, "target_peak_soften_radius", 2) or 2))
    lowpass = torch.stack([_blur01(image[c], radius) for c in range(image.shape[0])], dim=0)
    peak_edge = (_blur01(peak, radius) - _erode01(peak, 1)).clamp(0.0, 1.0)
    peak_edge = (peak_edge * mask).clamp(0.0, 1.0)
    core_keep = 1.0 - float(getattr(args, "target_peak_soften_core_keep", 0.65) or 0.65) * peak
    alpha = (strength * peak_edge * core_keep).clamp(0.0, 1.0)
    out = image * (1.0 - alpha.unsqueeze(0)) + lowpass * alpha.unsqueeze(0)
    return out.clamp(0.0, 1.0)


def _load_style_refs(args, device: torch.device) -> list[tuple[float, torch.Tensor, str]]:
    ref_dir = getattr(args, "background_reference_dir", None) or getattr(args, "train_gt_dir", None)
    if not ref_dir:
        return []
    path = Path(ref_dir)
    if not path.is_dir():
        return []
    refs = []
    for p in _image_files(path):
        refs.append((_parse_azimuth(p), _load_image(p, args).to(device), p.name))
    return refs


def _nearest_style_ref(refs: list[tuple[float, torch.Tensor, str]], azimuth_deg: float):
    if not refs:
        return None

    def dist(item):
        d = abs(float(item[0]) - float(azimuth_deg)) % 360.0
        return min(d, 360.0 - d)

    return min(refs, key=dist)


def _sample_empirical_background(
    ref: torch.Tensor,
    exclude_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    gray = ref.mean(dim=0)
    valid = exclude_mask < 0.5
    vals = gray[valid]
    if int(vals.numel()) < 64:
        vals = gray.reshape(-1)
    h, w = gray.shape
    gen = torch.Generator(device=ref.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 3301)
    idx = torch.randint(0, int(vals.numel()), (h * w,), device=ref.device, generator=gen)
    bg = vals[idx].view(h, w)
    blur = int(getattr(args, "background_style_blur_radius", 0) or 0)
    if blur > 0:
        low = _blur01(bg, blur)
        mix = min(max(float(getattr(args, "background_style_lowfreq_mix", 0.0)), 0.0), 1.0)
        bg = bg * (1.0 - mix) + low * mix
    return bg.unsqueeze(0).expand_as(ref).contiguous()


def _apply_background_style(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "background_style_strength", 0.0) or 0.0)
    if strength <= 0.0 or style_ref is None:
        return image.clamp(0.0, 1.0)

    style_ref = _resize_chw(style_ref, tuple(image.shape[-2:]))
    hmask = hard_mask.float().clamp(0.0, 1.0)
    fg = _dilate01(hmask, int(getattr(args, "background_style_foreground_dilate", 5)))
    band = _dilate01(hmask, int(getattr(args, "background_style_shadow_search_dilate", 28)))
    gray = image.mean(dim=0)
    shadow_th = float(getattr(args, "background_style_shadow_threshold", 0.10))
    shadow = ((gray < shadow_th).float() * band).clamp(0.0, 1.0)
    if bool(getattr(args, "background_style_replace_local_shadow", False)):
        keep = fg
    else:
        keep = torch.maximum(fg, shadow)
    keep = _blur01(keep, int(getattr(args, "background_style_blend_blur", 2)))

    exclude = _dilate01(hmask, int(getattr(args, "background_style_reference_exclude_dilate", 18)))
    ref_bg = _sample_empirical_background(style_ref, exclude, azimuth_deg, args)

    bg_scale = float(getattr(args, "background_style_scale", 1.0) or 1.0)
    bg_bias = float(getattr(args, "background_style_bias", 0.0) or 0.0)
    ref_bg = (ref_bg * bg_scale + bg_bias).clamp(0.0, 1.0)

    alpha = (1.0 - keep).unsqueeze(0) * strength
    out = image * (1.0 - alpha) + ref_bg * alpha
    return out.clamp(0.0, 1.0)


def _apply_learned_target_reference_match(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "learned_target_reference_match_strength", 0.0) or 0.0)
    if strength <= 0.0 or style_ref is None:
        return image.clamp(0.0, 1.0)

    style_ref = _resize_chw(style_ref, tuple(image.shape[-2:]))
    mask = hard_mask.float().clamp(0.0, 1.0)
    dilate = int(getattr(args, "learned_target_reference_match_dilate", 0) or 0)
    if dilate > 0:
        mask = _dilate01(mask, dilate)
    elif dilate < 0:
        mask = _erode01(mask, -dilate)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    src = image.mean(dim=0).clamp(0.0, 1.0)
    ref = style_ref.mean(dim=0).clamp(0.0, 1.0)
    inside = mask > 0.5
    qlo = min(max(float(getattr(args, "learned_target_reference_match_low_quantile", 0.25)), 0.0), 1.0)
    qhi = min(max(float(getattr(args, "learned_target_reference_match_high_quantile", 0.92)), 0.0), 1.0)
    src_lo = torch.quantile(src[inside], qlo)
    src_hi = torch.quantile(src[inside], qhi)
    ref_lo = torch.quantile(ref[inside], qlo)
    ref_hi = torch.quantile(ref[inside], qhi)
    scale = ((ref_hi - ref_lo) / (src_hi - src_lo).clamp_min(1e-6)).detach()
    min_scale = float(getattr(args, "learned_target_reference_match_min_scale", 0.65) or 0.65)
    max_scale = float(getattr(args, "learned_target_reference_match_max_scale", 1.45) or 1.45)
    scale = scale.clamp(min_scale, max_scale)
    bias = (ref_lo - src_lo * scale).detach()
    matched = (image * scale + bias).clamp(0.0, 1.0)

    blur = int(getattr(args, "learned_target_reference_match_blur", 0) or 0)
    alpha = mask
    if blur > 0:
        alpha = _blur01(alpha, blur)
    alpha = (alpha * min(max(strength, 0.0), 1.0)).unsqueeze(0)
    return (image * (1.0 - alpha) + matched * alpha).clamp(0.0, 1.0)


def _apply_learned_target_clean_composite(
    image: torch.Tensor,
    target: torch.Tensor,
    learned: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "learned_target_clean_composite_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    out = image.clamp(0.0, 1.0)
    if style_ref is not None:
        style_ref = _resize_chw(style_ref, tuple(image.shape[-2:]))
        cleanup = _dilate01(mask, int(getattr(args, "learned_target_clean_composite_cleanup_dilate", 14) or 0))
        cleanup_blur = int(getattr(args, "learned_target_clean_composite_cleanup_blur", 1) or 0)
        if cleanup_blur > 0:
            cleanup = _blur01(cleanup, cleanup_blur)
        exclude = _dilate01(mask, int(getattr(args, "learned_target_clean_composite_reference_exclude_dilate", 18) or 0))
        bg = _sample_empirical_background(style_ref, exclude, azimuth_deg, args)
        cleanup_alpha = (cleanup * min(max(strength, 0.0), 1.0)).unsqueeze(0)
        out = out * (1.0 - cleanup_alpha) + bg * cleanup_alpha

    target_alpha = _target_intensity_alpha(target, hard_mask, args, "learned_target_clean_composite_alpha")
    target_alpha = (target_alpha * min(max(strength, 0.0), 1.0)).clamp(0.0, 1.0)
    scale = float(getattr(args, "learned_target_clean_composite_target_scale", 1.0) or 1.0)
    gamma = max(float(getattr(args, "learned_target_clean_composite_target_gamma", 1.0) or 1.0), 0.05)
    bias = float(getattr(args, "learned_target_clean_composite_target_bias", 0.0) or 0.0)
    learned_target = (learned.clamp(0.0, 1.0).pow(gamma) * scale + bias).clamp(0.0, 1.0)
    return (out * (1.0 - target_alpha.unsqueeze(0)) + learned_target * target_alpha.unsqueeze(0)).clamp(0.0, 1.0)


def _apply_refiner_guided_target_composite(
    image: torch.Tensor,
    target: torch.Tensor,
    learned: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "refiner_guided_target_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    out = image.clamp(0.0, 1.0)
    if style_ref is not None:
        style_ref = _resize_chw(style_ref, tuple(image.shape[-2:]))
        cleanup = _dilate01(mask, int(getattr(args, "refiner_guided_target_cleanup_dilate", 18) or 0))
        cleanup_blur = int(getattr(args, "refiner_guided_target_cleanup_blur", 1) or 0)
        if cleanup_blur > 0:
            cleanup = _blur01(cleanup, cleanup_blur)
        exclude = _dilate01(mask, int(getattr(args, "refiner_guided_target_reference_exclude_dilate", 22) or 0))
        bg = _sample_empirical_background(style_ref, exclude, azimuth_deg, args)
        out = out * (1.0 - cleanup.unsqueeze(0)) + bg * cleanup.unsqueeze(0)

    learned_gray = learned.mean(dim=0).clamp(0.0, 1.0)
    guide_region = _dilate01(mask, int(getattr(args, "refiner_guided_target_guide_dilate", 5) or 0))
    if int((guide_region > 0.5).sum().item()) < 8:
        guide_region = mask
    radius = int(getattr(args, "refiner_guided_target_guide_blur", 1) or 0)
    guide_source = _blur01(learned_gray, radius) if radius > 0 else learned_gray
    vals = guide_source[guide_region > 0.5]
    qlo = min(max(float(getattr(args, "refiner_guided_target_low_quantile", 0.18)), 0.0), 1.0)
    qhi = min(max(float(getattr(args, "refiner_guided_target_high_quantile", 0.82)), 0.0), 1.0)
    lo = float(torch.quantile(vals, qlo).detach().item())
    hi = float(torch.quantile(vals, qhi).detach().item())
    guide = ((guide_source - lo) / max(hi - lo, 1e-6)).clamp(0.0, 1.0)
    gamma = max(float(getattr(args, "refiner_guided_target_gamma", 1.0) or 1.0), 0.05)
    guide = (guide.pow(gamma) * guide_region).clamp(0.0, 1.0)

    target_alpha = _target_intensity_alpha(target, hard_mask, args, "refiner_guided_target_alpha")
    alpha_floor = float(getattr(args, "refiner_guided_target_alpha_floor", 0.04) or 0.0)
    alpha = target_alpha * (alpha_floor + (1.0 - alpha_floor) * guide)
    alpha = (alpha * min(max(strength, 0.0), 1.0)).clamp(0.0, 1.0)

    shadow_suppress = float(getattr(args, "refiner_guided_target_shadow_alpha_suppression", 0.0) or 0.0)
    if shadow_suppress > 0.0:
        edge_width = int(getattr(args, "refiner_guided_target_shadow_alpha_edge_width", 6) or 6)
        edge = (mask - _erode01(mask, edge_width)).clamp(0.0, 1.0)
        learned_vals = learned_gray[mask > 0.5]
        low_q = min(max(float(getattr(args, "refiner_guided_target_shadow_alpha_low_quantile", 0.48)), 0.0), 1.0)
        low = float(torch.quantile(learned_vals, low_q).detach().item())
        learned_dark = (torch.relu(low - learned_gray) / max(low, 1e-6)).clamp(0.0, 1.0)

        angle = float(getattr(args, "shadow_synth_angle_deg", 180.0))
        if bool(getattr(args, "shadow_synth_rotate_with_azimuth", False)):
            angle = float(azimuth_deg) + float(getattr(args, "shadow_synth_angle_offset", 180.0))
        h, w = mask.shape[-2:]
        yy = torch.linspace(-1.0, 1.0, h, device=mask.device, dtype=mask.dtype).view(h, 1).expand(h, w)
        xx = torch.linspace(-1.0, 1.0, w, device=mask.device, dtype=mask.dtype).view(1, w).expand(h, w)
        a = math.radians(angle)
        coord = xx * math.cos(a) + yy * math.sin(a)
        vals_coord = coord[mask > 0.5]
        if int(vals_coord.numel()) > 1:
            coord = (coord - vals_coord.min()) / (vals_coord.max() - vals_coord.min()).clamp_min(1e-6)
        side_start = min(max(float(getattr(args, "refiner_guided_target_shadow_alpha_side_start", 0.35) or 0.35), 0.0), 1.0)
        side_gamma = max(float(getattr(args, "refiner_guided_target_shadow_alpha_side_gamma", 1.0) or 1.0), 0.05)
        side = (torch.relu(coord - side_start) / max(1e-6, 1.0 - side_start)).clamp(0.0, 1.0).pow(side_gamma)
        side_floor = min(max(float(getattr(args, "refiner_guided_target_shadow_alpha_side_floor", 0.25) or 0.25), 0.0), 1.0)
        side = (side_floor + (1.0 - side_floor) * side).clamp(0.0, 1.0)

        gen = torch.Generator(device=mask.device)
        gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 9311)
        noise = torch.rand((h, w), device=mask.device, dtype=mask.dtype, generator=gen)
        noise_blur = int(getattr(args, "refiner_guided_target_shadow_alpha_noise_blur", 2) or 2)
        if noise_blur > 0:
            noise = _blur01(noise, noise_blur)
        noise = (noise - noise.min()) / (noise.max() - noise.min()).clamp_min(1e-6)
        noise_floor = float(getattr(args, "refiner_guided_target_shadow_alpha_noise_floor", 0.20) or 0.20)
        irregular = (noise_floor + (1.0 - noise_floor) * noise).clamp(0.0, 1.0)
        suppress_map = ((edge + 0.65 * learned_dark * mask) * side * irregular * mask).clamp(0.0, 1.0)
        suppress_blur = int(getattr(args, "refiner_guided_target_shadow_alpha_blur", 1) or 1)
        if suppress_blur > 0:
            suppress_map = (_blur01(suppress_map, suppress_blur) * mask).clamp(0.0, 1.0)
        alpha = (alpha * (1.0 - min(max(shadow_suppress, 0.0), 1.0) * suppress_map)).clamp(0.0, 1.0)

    tex_scale = float(getattr(args, "refiner_guided_target_texture_scale", 1.0) or 1.0)
    tex_gamma = max(float(getattr(args, "refiner_guided_target_texture_gamma", 1.0) or 1.0), 0.05)
    tex_bias = float(getattr(args, "refiner_guided_target_texture_bias", 0.0) or 0.0)
    texture = (target.clamp(0.0, 1.0).pow(tex_gamma) * tex_scale + tex_bias).clamp(0.0, 1.0)

    visibility_floor = float(getattr(args, "refiner_guided_target_visibility_floor", 0.08) or 0.08)
    shaded_texture = (texture * (visibility_floor + (1.0 - visibility_floor) * guide).unsqueeze(0)).clamp(0.0, 1.0)
    return (out * (1.0 - alpha.unsqueeze(0)) + shaded_texture * alpha.unsqueeze(0)).clamp(0.0, 1.0)


def _apply_target_boundary_seam_repair(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "target_boundary_seam_repair_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    outer = _dilate01(mask, int(getattr(args, "target_boundary_seam_repair_outer", 2) or 2))
    inner = _erode01(mask, int(getattr(args, "target_boundary_seam_repair_inner", 1) or 1))
    band = (outer - inner).clamp(0.0, 1.0)
    if int((band > 1e-4).sum().item()) < 4:
        return image.clamp(0.0, 1.0)

    if style_ref is not None:
        style_ref = _resize_chw(style_ref, tuple(image.shape[-2:]))
        exclude = _dilate01(mask, int(getattr(args, "target_boundary_seam_repair_reference_exclude_dilate", 18) or 18))
        fill = _sample_empirical_background(style_ref, exclude, azimuth_deg, args)
    else:
        fill_gray = _blur01(image.mean(dim=0), int(getattr(args, "target_boundary_seam_repair_blur_radius", 2) or 2))
        fill = fill_gray.unsqueeze(0).expand_as(image)

    gray = image.mean(dim=0).clamp(0.0, 1.0)
    fill_gray = fill.mean(dim=0).clamp(0.0, 1.0)
    dark_gap = torch.relu(fill_gray - gray)
    threshold = float(getattr(args, "target_boundary_seam_repair_threshold", 0.035) or 0.035)
    gap_gate = (dark_gap / max(threshold, 1e-6)).clamp(0.0, 1.0)
    alpha = (band * gap_gate * min(max(strength, 0.0), 1.0)).unsqueeze(0)
    return (image * (1.0 - alpha) + fill * alpha).clamp(0.0, 1.0)


def _apply_target_shadow_interface_breakup(
    image: torch.Tensor,
    target: torch.Tensor,
    learned: torch.Tensor,
    hard_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "target_shadow_interface_breakup_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    edge = (mask - _erode01(mask, int(getattr(args, "target_shadow_interface_breakup_edge_width", 2) or 2))).clamp(0.0, 1.0)
    inside = _erode01(mask, int(getattr(args, "target_shadow_interface_breakup_inner_erode", 1) or 1))
    learned_gray = learned.mean(dim=0).clamp(0.0, 1.0)
    vals = learned_gray[mask > 0.5]
    if int(vals.numel()) < 8:
        return image.clamp(0.0, 1.0)
    low_q = min(max(float(getattr(args, "target_shadow_interface_breakup_low_quantile", 0.38)), 0.0), 1.0)
    low = float(torch.quantile(vals, low_q).detach().item())
    dark_learned = (torch.relu(low - learned_gray) / max(low, 1e-6)).clamp(0.0, 1.0)

    angle = float(getattr(args, "shadow_synth_angle_deg", 180.0))
    if bool(getattr(args, "shadow_synth_rotate_with_azimuth", False)):
        angle = float(azimuth_deg) + float(getattr(args, "shadow_synth_angle_offset", 180.0))
    h, w = mask.shape[-2:]
    yy = torch.linspace(-1.0, 1.0, h, device=mask.device, dtype=mask.dtype).view(h, 1).expand(h, w)
    xx = torch.linspace(-1.0, 1.0, w, device=mask.device, dtype=mask.dtype).view(1, w).expand(h, w)
    a = math.radians(angle)
    coord = xx * math.cos(a) + yy * math.sin(a)
    vals_coord = coord[mask > 0.5]
    if int(vals_coord.numel()) > 1:
        coord = (coord - vals_coord.min()) / (vals_coord.max() - vals_coord.min()).clamp_min(1e-6)
    side_start = min(max(float(getattr(args, "target_shadow_interface_breakup_side_start", 0.52) or 0.52), 0.0), 1.0)
    side_gamma = max(float(getattr(args, "target_shadow_interface_breakup_side_gamma", 1.2) or 1.2), 0.05)
    shadow_side = (torch.relu(coord - side_start) / max(1e-6, 1.0 - side_start)).clamp(0.0, 1.0).pow(side_gamma)

    gen = torch.Generator(device=mask.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 7409)
    noise = torch.rand((h, w), device=mask.device, dtype=mask.dtype, generator=gen)
    noise = _blur01(noise, int(getattr(args, "target_shadow_interface_breakup_noise_blur", 1) or 1))
    noise = (noise - noise.min()) / (noise.max() - noise.min()).clamp_min(1e-6)
    th = float(getattr(args, "target_shadow_interface_breakup_noise_threshold", 0.50) or 0.50)
    holes = (torch.relu(th - noise) / max(th, 1e-6)).clamp(0.0, 1.0)

    support = ((edge + 0.45 * inside * dark_learned) * shadow_side * holes * mask).clamp(0.0, 1.0)
    blur = int(getattr(args, "target_shadow_interface_breakup_support_blur", 0) or 0)
    if blur > 0:
        support = (_blur01(support, blur) * mask).clamp(0.0, 1.0)
    floor = float(getattr(args, "target_shadow_interface_breakup_floor", 0.04) or 0.04)
    amount = (support * min(max(strength, 0.0), 1.0)).unsqueeze(0)
    return (image * (1.0 - amount) + floor * amount).clamp(0.0, 1.0)


def _apply_target_shadow_interface_soften(
    image: torch.Tensor,
    learned: torch.Tensor,
    hard_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "target_shadow_interface_soften_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    edge_width = int(getattr(args, "target_shadow_interface_soften_edge_width", 4) or 4)
    edge = (mask - _erode01(mask, edge_width)).clamp(0.0, 1.0)
    inside = _erode01(mask, int(getattr(args, "target_shadow_interface_soften_inner_erode", 1) or 1))

    learned_gray = learned.mean(dim=0).clamp(0.0, 1.0)
    vals = learned_gray[mask > 0.5]
    if int(vals.numel()) < 8:
        return image.clamp(0.0, 1.0)
    low_q = min(max(float(getattr(args, "target_shadow_interface_soften_low_quantile", 0.48)), 0.0), 1.0)
    low = float(torch.quantile(vals, low_q).detach().item())
    learned_dark = (torch.relu(low - learned_gray) / max(low, 1e-6)).clamp(0.0, 1.0)

    angle = float(getattr(args, "shadow_synth_angle_deg", 180.0))
    if bool(getattr(args, "shadow_synth_rotate_with_azimuth", False)):
        angle = float(azimuth_deg) + float(getattr(args, "shadow_synth_angle_offset", 180.0))
    h, w = mask.shape[-2:]
    yy = torch.linspace(-1.0, 1.0, h, device=mask.device, dtype=mask.dtype).view(h, 1).expand(h, w)
    xx = torch.linspace(-1.0, 1.0, w, device=mask.device, dtype=mask.dtype).view(1, w).expand(h, w)
    a = math.radians(angle)
    coord = xx * math.cos(a) + yy * math.sin(a)
    vals_coord = coord[mask > 0.5]
    if int(vals_coord.numel()) > 1:
        coord = (coord - vals_coord.min()) / (vals_coord.max() - vals_coord.min()).clamp_min(1e-6)
    side_start = min(max(float(getattr(args, "target_shadow_interface_soften_side_start", 0.38) or 0.38), 0.0), 1.0)
    side_gamma = max(float(getattr(args, "target_shadow_interface_soften_side_gamma", 1.0) or 1.0), 0.05)
    shadow_side = (torch.relu(coord - side_start) / max(1e-6, 1.0 - side_start)).clamp(0.0, 1.0).pow(side_gamma)
    side_floor = min(max(float(getattr(args, "target_shadow_interface_soften_side_floor", 0.0) or 0.0), 0.0), 1.0)
    shadow_side = (side_floor + (1.0 - side_floor) * shadow_side).clamp(0.0, 1.0)

    gen = torch.Generator(device=mask.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 8461)
    noise = torch.rand((h, w), device=mask.device, dtype=mask.dtype, generator=gen)
    noise_blur = int(getattr(args, "target_shadow_interface_soften_noise_blur", 2) or 2)
    if noise_blur > 0:
        noise = _blur01(noise, noise_blur)
    noise = (noise - noise.min()) / (noise.max() - noise.min()).clamp_min(1e-6)
    noise_floor = float(getattr(args, "target_shadow_interface_soften_noise_floor", 0.25) or 0.25)
    irregular = (noise_floor + (1.0 - noise_floor) * noise).clamp(0.0, 1.0)

    support = ((edge + 0.60 * inside * learned_dark) * shadow_side * irregular * mask).clamp(0.0, 1.0)
    support_blur = int(getattr(args, "target_shadow_interface_soften_support_blur", 1) or 1)
    if support_blur > 0:
        support = (_blur01(support, support_blur) * mask).clamp(0.0, 1.0)

    radius = int(getattr(args, "target_shadow_interface_soften_radius", 3) or 3)
    if radius <= 0:
        blurred = image
    else:
        blurred = torch.stack([_blur01(image[c], radius) for c in range(image.shape[0])], dim=0)
    alpha = (support * min(max(strength, 0.0), 1.0)).unsqueeze(0)
    out = image * (1.0 - alpha) + blurred * alpha

    darken = float(getattr(args, "target_shadow_interface_soften_darken", 0.35) or 0.35)
    floor = float(getattr(args, "target_shadow_interface_soften_floor", 0.035) or 0.035)
    dark_alpha = (alpha * darken).clamp(0.0, 1.0)
    out = out * (1.0 - dark_alpha) + floor * dark_alpha
    return out.clamp(0.0, 1.0)


def _apply_occluded_target_speckle_patch(
    image: torch.Tensor,
    target: torch.Tensor,
    learned: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "occluded_target_speckle_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    learned_gray = learned.mean(dim=0).clamp(0.0, 1.0)
    target_gray = target.mean(dim=0).clamp(0.0, 1.0)
    vals = learned_gray[mask > 0.5]
    if int(vals.numel()) < 8:
        return image.clamp(0.0, 1.0)
    low_q = min(max(float(getattr(args, "occluded_target_speckle_low_quantile", 0.46)), 0.0), 1.0)
    high_q = min(max(float(getattr(args, "occluded_target_speckle_high_quantile", 0.82)), 0.0), 1.0)
    lo = torch.quantile(vals, low_q)
    hi = torch.quantile(vals, high_q)
    dark = ((hi - learned_gray) / (hi - lo).clamp_min(1e-6)).clamp(0.0, 1.0)

    bright_keep_q = min(max(float(getattr(args, "occluded_target_speckle_bright_keep_quantile", 0.70)), 0.0), 1.0)
    bright_th = torch.quantile(target_gray[mask > 0.5], bright_keep_q)
    not_bright = (1.0 - (torch.relu(target_gray - bright_th) / (1.0 - bright_th).clamp_min(1e-6)).clamp(0.0, 1.0))

    image_gray = image.mean(dim=0).clamp(0.0, 1.0)
    current_vals = image_gray[mask > 0.5]
    current_q = min(max(float(getattr(args, "occluded_target_speckle_current_dark_quantile", 0.55)), 0.0), 1.0)
    current_dark_th = torch.quantile(current_vals, current_q)
    current_dark = (torch.relu(current_dark_th - image_gray) / current_dark_th.clamp_min(1e-6)).clamp(0.0, 1.0)

    angle = float(getattr(args, "shadow_synth_angle_deg", 180.0))
    if bool(getattr(args, "shadow_synth_rotate_with_azimuth", False)):
        angle = float(azimuth_deg) + float(getattr(args, "shadow_synth_angle_offset", 180.0))
    h, w = mask.shape[-2:]
    yy = torch.linspace(-1.0, 1.0, h, device=mask.device, dtype=mask.dtype).view(h, 1).expand(h, w)
    xx = torch.linspace(-1.0, 1.0, w, device=mask.device, dtype=mask.dtype).view(1, w).expand(h, w)
    a = math.radians(angle)
    coord = xx * math.cos(a) + yy * math.sin(a)
    vals_coord = coord[mask > 0.5]
    if int(vals_coord.numel()) > 1:
        coord = (coord - vals_coord.min()) / (vals_coord.max() - vals_coord.min()).clamp_min(1e-6)
    side_start = min(max(float(getattr(args, "occluded_target_speckle_side_start", 0.38) or 0.38), 0.0), 1.0)
    side_gamma = max(float(getattr(args, "occluded_target_speckle_side_gamma", 1.0) or 1.0), 0.05)
    shadow_side = (torch.relu(coord - side_start) / max(1e-6, 1.0 - side_start)).clamp(0.0, 1.0).pow(side_gamma)

    gen = torch.Generator(device=image.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 11807)
    if style_ref is not None:
        style_ref = _resize_chw(style_ref, tuple(image.shape[-2:]))
        ref_gray = style_ref.mean(dim=0).clamp(0.0, 1.0)
        exclude = _dilate01(mask, int(getattr(args, "occluded_target_speckle_reference_exclude_dilate", 12) or 12))
        valid = exclude < 0.5
        ref_vals = ref_gray[valid]
        if int(ref_vals.numel()) < 64:
            ref_vals = ref_gray.reshape(-1)
        rq = min(max(float(getattr(args, "occluded_target_speckle_reference_quantile", 0.55)), 0.0), 1.0)
        ref_th = torch.quantile(ref_vals, rq)
        low_vals = ref_vals[ref_vals <= ref_th]
        if int(low_vals.numel()) < 16:
            low_vals = ref_vals
        idx = torch.randint(0, int(low_vals.numel()), (h * w,), device=image.device, generator=gen)
        patch = low_vals[idx].view(h, w)
    else:
        patch = torch.rand((h, w), device=image.device, dtype=image.dtype, generator=gen) * float(
            getattr(args, "occluded_target_speckle_fallback_max", 0.22) or 0.22
        )
    patch_blur = int(getattr(args, "occluded_target_speckle_patch_blur", 0) or 0)
    if patch_blur > 0:
        patch = _blur01(patch, patch_blur)

    gate_noise = torch.rand((h, w), device=image.device, dtype=image.dtype, generator=gen)
    gate_blur = int(getattr(args, "occluded_target_speckle_gate_noise_blur", 1) or 1)
    if gate_blur > 0:
        gate_noise = _blur01(gate_noise, gate_blur)
    gate_noise = (gate_noise - gate_noise.min()) / (gate_noise.max() - gate_noise.min()).clamp_min(1e-6)
    gate_th = float(getattr(args, "occluded_target_speckle_gate_threshold", 0.42) or 0.42)
    gate = (torch.relu(gate_th - gate_noise) / max(gate_th, 1e-6)).clamp(0.0, 1.0)

    shadow_region_strength = float(getattr(args, "occluded_target_speckle_shadow_region_strength", 0.0) or 0.0)
    support_region = mask
    shadow_region = torch.zeros_like(mask)
    if shadow_region_strength > 0.0:
        shadow_len = int(round(float(getattr(args, "occluded_target_speckle_shadow_length_frac", 0.12) or 0.12) * max(h, w)))
        shadow_region = _directional_trail(
            mask,
            angle,
            shadow_len,
            decay=max(1.0, shadow_len * float(getattr(args, "occluded_target_speckle_shadow_decay_frac", 0.70) or 0.70)),
            blur_radius=int(getattr(args, "occluded_target_speckle_shadow_blur_radius", 1) or 1),
        )
        shadow_region = (shadow_region * (1.0 - _erode01(mask, 1))).clamp(0.0, 1.0)
        support_region = torch.maximum(mask, shadow_region_strength * shadow_region).clamp(0.0, 1.0)

    edge = (mask - _erode01(mask, int(getattr(args, "occluded_target_speckle_edge_width", 4) or 4))).clamp(0.0, 1.0)
    edge = torch.maximum(edge, shadow_region).clamp(0.0, 1.0)
    interior_weight = float(getattr(args, "occluded_target_speckle_interior_weight", 0.45) or 0.45)
    support = ((edge + interior_weight * mask) * dark * current_dark * not_bright * shadow_side * gate * support_region).clamp(0.0, 1.0)
    edge_override = float(getattr(args, "occluded_target_speckle_shadow_edge_override", 0.0) or 0.0)
    if edge_override > 0.0:
        edge_override_width = int(getattr(args, "occluded_target_speckle_shadow_edge_override_width", 2) or 2)
        target_edge = (mask - _erode01(mask, edge_override_width)).clamp(0.0, 1.0)
        edge_gate = (target_edge * shadow_side * gate * support_region).clamp(0.0, 1.0)
        support = torch.maximum(support, min(max(edge_override, 0.0), 1.0) * edge_gate).clamp(0.0, 1.0)
    support_blur = int(getattr(args, "occluded_target_speckle_support_blur", 1) or 1)
    if support_blur > 0:
        support = (_blur01(support, support_blur) * support_region).clamp(0.0, 1.0)

    patch = patch.unsqueeze(0).expand_as(image)
    alpha = (support * min(max(strength, 0.0), 1.0)).unsqueeze(0)
    return (image * (1.0 - alpha) + patch * alpha).clamp(0.0, 1.0)


def _apply_target_sar_texture(
    image: torch.Tensor,
    target: torch.Tensor,
    learned: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "target_sar_texture_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    h, w = mask.shape[-2:]
    angle = float(getattr(args, "shadow_synth_angle_deg", 180.0))
    if bool(getattr(args, "shadow_synth_rotate_with_azimuth", False)):
        angle = float(azimuth_deg) + float(getattr(args, "shadow_synth_angle_offset", 180.0))

    shadow_len = int(round(float(getattr(args, "target_sar_texture_shadow_length_frac", 0.16) or 0.16) * max(h, w)))
    shadow_region = _directional_trail(
        mask,
        angle,
        shadow_len,
        decay=max(1.0, shadow_len * float(getattr(args, "target_sar_texture_shadow_decay_frac", 0.75) or 0.75)),
        blur_radius=int(getattr(args, "target_sar_texture_shadow_blur_radius", 1) or 1),
    )
    target_alpha = _target_intensity_alpha(target, hard_mask, args, "target_sar_texture_alpha")
    shadow_weight = float(getattr(args, "target_sar_texture_shadow_weight", 0.75) or 0.75)
    support = torch.maximum(target_alpha, shadow_weight * shadow_region).clamp(0.0, 1.0)

    image_gray = image.mean(dim=0).clamp(0.0, 1.0)
    vals = image_gray[support > 0.05]
    if int(vals.numel()) < 8:
        vals = image_gray[mask > 0.5]
    if int(vals.numel()) < 8:
        return image.clamp(0.0, 1.0)
    dark_q = min(max(float(getattr(args, "target_sar_texture_dark_quantile", 0.48)), 0.0), 1.0)
    dark_th = torch.quantile(vals, dark_q)
    dark_gate = (torch.relu(dark_th - image_gray) / dark_th.clamp_min(1e-6)).clamp(0.0, 1.0)

    gen = torch.Generator(device=image.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 17713)
    looks = max(1, int(getattr(args, "target_sar_texture_looks", 1) or 1))
    speckle = torch.zeros((h, w), device=image.device, dtype=image.dtype)
    for _ in range(looks):
        u = torch.rand((h, w), device=image.device, dtype=image.dtype, generator=gen).clamp_min(1e-6)
        speckle = speckle + (-torch.log(u))
    speckle = speckle / float(looks)
    block_blur = int(getattr(args, "target_sar_texture_block_blur", 1) or 1)
    if block_blur > 0:
        speckle = _blur01(speckle, block_blur)
    speckle = speckle / speckle[support > 0.05].mean().clamp_min(1e-6)

    bright_amount = float(getattr(args, "target_sar_texture_bright_amount", 0.16) or 0.16)
    dark_amount = float(getattr(args, "target_sar_texture_dark_amount", 0.35) or 0.35)
    amount = strength * support * ((1.0 - dark_gate) * bright_amount + dark_gate * dark_amount)
    textured = image * (1.0 + amount.unsqueeze(0) * (speckle.unsqueeze(0) - 1.0))

    low_patch_strength = float(getattr(args, "target_sar_texture_low_patch_strength", 0.0) or 0.0)
    if low_patch_strength > 0.0:
        if style_ref is not None:
            style_ref = _resize_chw(style_ref, tuple(image.shape[-2:]))
            ref_gray = style_ref.mean(dim=0).clamp(0.0, 1.0)
            exclude = _dilate01(mask, int(getattr(args, "target_sar_texture_reference_exclude_dilate", 12) or 12))
            ref_vals = ref_gray[exclude < 0.5]
            if int(ref_vals.numel()) < 64:
                ref_vals = ref_gray.reshape(-1)
            ref_q = min(max(float(getattr(args, "target_sar_texture_reference_quantile", 0.65)), 0.0), 1.0)
            ref_th = torch.quantile(ref_vals, ref_q)
            low_vals = ref_vals[ref_vals <= ref_th]
            if int(low_vals.numel()) < 16:
                low_vals = ref_vals
            idx = torch.randint(0, int(low_vals.numel()), (h * w,), device=image.device, generator=gen)
            patch = low_vals[idx].view(h, w)
        else:
            patch = torch.rand((h, w), device=image.device, dtype=image.dtype, generator=gen) * 0.25
        patch_blur = int(getattr(args, "target_sar_texture_low_patch_blur", 0) or 0)
        if patch_blur > 0:
            patch = _blur01(patch, patch_blur)
        patch_gate = (support * dark_gate * shadow_region).clamp(0.0, 1.0)
        gate_blur = int(getattr(args, "target_sar_texture_low_patch_gate_blur", 1) or 1)
        if gate_blur > 0:
            patch_gate = _blur01(patch_gate, gate_blur).clamp(0.0, 1.0)
        alpha = (strength * low_patch_strength * patch_gate).clamp(0.0, 1.0).unsqueeze(0)
        patch_rgb = patch.unsqueeze(0).expand_as(textured)
        textured = textured * (1.0 - alpha) + patch_rgb * alpha

    dropout_strength = float(getattr(args, "target_sar_texture_bright_dropout_strength", 0.0) or 0.0)
    if dropout_strength > 0.0:
        high_q = min(max(float(getattr(args, "target_sar_texture_bright_dropout_quantile", 0.72)), 0.0), 1.0)
        high_vals = image_gray[support > 0.05]
        if int(high_vals.numel()) >= 8:
            high_th = torch.quantile(high_vals, high_q)
            high_gate = (torch.relu(image_gray - high_th) / (1.0 - high_th).clamp_min(1e-6)).clamp(0.0, 1.0)
            high_gate = (high_gate * support * (1.0 - dark_gate)).clamp(0.0, 1.0)
            dropout_noise = torch.rand((h, w), device=image.device, dtype=image.dtype, generator=gen)
            dropout_blur = int(getattr(args, "target_sar_texture_bright_dropout_noise_blur", 0) or 0)
            if dropout_blur > 0:
                dropout_noise = _blur01(dropout_noise, dropout_blur)
                dropout_noise = (dropout_noise - dropout_noise.min()) / (dropout_noise.max() - dropout_noise.min()).clamp_min(1e-6)
            dropout_th = float(getattr(args, "target_sar_texture_bright_dropout_threshold", 0.45) or 0.45)
            holes = (torch.relu(dropout_th - dropout_noise) / max(dropout_th, 1e-6)).clamp(0.0, 1.0)
            drop_scale = float(getattr(args, "target_sar_texture_bright_dropout_scale", 0.42) or 0.42)
            alpha = (strength * dropout_strength * high_gate * holes).clamp(0.0, 1.0).unsqueeze(0)
            dimmed = (textured * drop_scale).clamp(0.0, 1.0)
            textured = textured * (1.0 - alpha) + dimmed * alpha

    return textured.clamp(0.0, 1.0)


def _apply_target_scatter_falloff(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "target_scatter_falloff_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    shrink = int(getattr(args, "target_scatter_falloff_mask_shrink", 0) or 0)
    if shrink > 0:
        mask = _erode01(mask, shrink)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    gray = image.mean(dim=0)
    inside = mask > 0.5
    vals = gray[inside]
    if int(vals.numel()) < 8:
        return image.clamp(0.0, 1.0)

    q = min(max(float(getattr(args, "target_scatter_falloff_source_quantile", 0.72)), 0.0), 1.0)
    th = torch.quantile(vals, q)
    denom = (torch.quantile(vals, 0.98) - th).clamp_min(1e-6)
    source = (torch.relu(gray - th) / denom).clamp(0.0, 1.0) * mask
    if int((source > 1e-4).sum().item()) < 3:
        return image.clamp(0.0, 1.0)

    small = _blur01(source, int(getattr(args, "target_scatter_falloff_small_radius", 1)))
    mid = _blur01(source, int(getattr(args, "target_scatter_falloff_mid_radius", 3)))
    large = _blur01(source, int(getattr(args, "target_scatter_falloff_large_radius", 6)))
    falloff = (
        float(getattr(args, "target_scatter_falloff_small_weight", 0.50)) * small
        + float(getattr(args, "target_scatter_falloff_mid_weight", 0.35)) * mid
        + float(getattr(args, "target_scatter_falloff_large_weight", 0.15)) * large
    )

    dir_strength = float(getattr(args, "target_scatter_falloff_directional_strength", 0.0) or 0.0)
    if dir_strength > 0.0:
        angle = float(getattr(args, "target_scatter_falloff_angle_deg", 180.0))
        if bool(getattr(args, "target_scatter_falloff_rotate_with_azimuth", False)):
            angle = float(azimuth_deg) + float(getattr(args, "target_scatter_falloff_angle_offset", 180.0))
        length_px = int(round(float(getattr(args, "target_scatter_falloff_length_frac", 0.08)) * max(image.shape[-2:])))
        trail = _directional_trail(
            source,
            angle,
            length_px,
            decay=max(1.0, length_px * float(getattr(args, "target_scatter_falloff_decay_frac", 0.8))),
            blur_radius=int(getattr(args, "target_scatter_falloff_blur_radius", 1)),
        )
        falloff = falloff * (1.0 - dir_strength) + trail * dir_strength

    support_radius = int(getattr(args, "target_scatter_falloff_support_radius", 2) or 0)
    support = _dilate01(mask, support_radius) if support_radius > 0 else mask
    support = torch.maximum(support, (falloff > 1e-4).float())
    support = _blur01(support, int(getattr(args, "target_scatter_falloff_support_blur", 1) or 0))
    falloff = (falloff * support).clamp(0.0, 1.0)
    if falloff.max() > 1e-6:
        falloff = falloff / falloff.max().clamp_min(1e-6)

    # Diffuse strong scattering centers into neighboring weak pixels. This
    # creates a PSF-like strong-to-weak transition without keeping a box mask.
    lift = float(getattr(args, "target_scatter_falloff_lift", 0.35) or 0.0) * strength
    out = image
    if lift > 0.0:
        target_floor = falloff.unsqueeze(0) * lift
        out = torch.maximum(out, target_floor)

    blend = float(getattr(args, "target_scatter_falloff_blend", 0.35) or 0.0) * strength
    if blend > 0.0:
        smoothed = _blur01(gray, int(getattr(args, "target_scatter_falloff_smooth_radius", 2) or 2))
        smoothed = smoothed.unsqueeze(0).expand_as(out)
        alpha = (falloff * support).unsqueeze(0) * blend
        out = out * (1.0 - alpha) + smoothed * alpha

    peak_rolloff = float(getattr(args, "target_scatter_falloff_peak_rolloff", 0.0) or 0.0) * strength
    if peak_rolloff > 0.0:
        hi_q = min(max(float(getattr(args, "target_scatter_falloff_peak_quantile", 0.96)), 0.0), 1.0)
        hi = torch.quantile(vals, hi_q)
        compressed = torch.where(out > hi, hi + (out - hi) * (1.0 - peak_rolloff), out)
        out = out * (1.0 - support.unsqueeze(0)) + compressed * support.unsqueeze(0)
    return out.clamp(0.0, 1.0)


def _apply_synthetic_shadow(image: torch.Tensor, hard_mask: torch.Tensor, azimuth_deg: float, args) -> torch.Tensor:
    strength = float(getattr(args, "shadow_synth_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0)

    mask = hard_mask.float().clamp(0.0, 1.0)
    shrink = int(getattr(args, "shadow_synth_mask_shrink", 0) or 0)
    if shrink > 0:
        mask = _erode01(mask, shrink)
    if int((mask > 0.5).sum().item()) < 8:
        return image.clamp(0.0, 1.0)

    angle = float(getattr(args, "shadow_synth_angle_deg", 180.0))
    if bool(getattr(args, "shadow_synth_rotate_with_azimuth", False)):
        angle = float(azimuth_deg) + float(getattr(args, "shadow_synth_angle_offset", 180.0))
    source = mask
    if bool(getattr(args, "shadow_synth_use_edge_source", True)):
        a = math.radians(float(angle))
        dx = int(round(math.cos(a)))
        dy = int(round(math.sin(a)))
        # Keep only the side of the target that casts the shadow. Using the
        # full target support makes a blurry dark rectangle around the target.
        source = (mask - _shift_zero(mask, -dx, -dy)).clamp(0.0, 1.0)
        if int((source > 1e-4).sum().item()) < 4:
            source = mask
        side_frac = min(max(float(getattr(args, "shadow_synth_source_side_fraction", 0.35) or 0.35), 0.02), 1.0)
        if side_frac < 1.0 and int((source > 1e-4).sum().item()) >= 4:
            h, w = mask.shape[-2:]
            yy = torch.linspace(-1.0, 1.0, h, device=mask.device, dtype=mask.dtype).view(h, 1).expand(h, w)
            xx = torch.linspace(-1.0, 1.0, w, device=mask.device, dtype=mask.dtype).view(1, w).expand(h, w)
            coord = xx * math.cos(a) + yy * math.sin(a)
            vals = coord[mask > 0.5]
            if int(vals.numel()) > 4:
                q = torch.quantile(vals, 1.0 - side_frac)
                side = (coord >= q).float() * mask
                side = _blur01(side, int(getattr(args, "shadow_synth_source_side_blur", 0) or 0))
                gated = (source * side).clamp(0.0, 1.0)
                if int((gated > 1e-4).sum().item()) >= 3:
                    source = gated
    length_px = int(round(float(getattr(args, "shadow_synth_length_frac", 0.18)) * max(image.shape[-2:])))
    trail = _directional_trail(
        source,
        angle,
        length_px,
        decay=max(1.0, length_px * float(getattr(args, "shadow_synth_decay_frac", 0.85))),
        blur_radius=int(getattr(args, "shadow_synth_blur_radius", 1)),
    )
    # Remove the target body from the shadow support so the target itself is not darkened.
    block_target = _dilate01(mask, int(getattr(args, "shadow_synth_target_gap", 1) or 0))
    shadow = (trail * (1.0 - block_target)).clamp(0.0, 1.0)
    if int(getattr(args, "shadow_synth_edge_blur", 0) or 0) > 0:
        shadow = _blur01(shadow, int(getattr(args, "shadow_synth_edge_blur", 0)))

    floor = float(getattr(args, "shadow_synth_floor", 0.0) or 0.0)
    out = image * (1.0 - strength * shadow.unsqueeze(0)).clamp(0.0, 1.0)
    if floor > 0.0:
        out = torch.maximum(out, floor * shadow.unsqueeze(0))
    return out.clamp(0.0, 1.0)


def _match_pairs(target_dir: Path, gt_dir: Path) -> list[tuple[Path, Path, float]]:
    targets = {p.stem: p for p in _image_files(target_dir)}
    gts = {p.stem: p for p in _image_files(gt_dir)}
    pairs = []
    for stem, tp in targets.items():
        gp = gts.get(stem)
        if gp is not None:
            pairs.append((tp, gp, _parse_azimuth(stem)))
    if not pairs:
        raise RuntimeError(f"No paired images found: {target_dir} vs {gt_dir}")
    return sorted(pairs, key=lambda x: x[0].name)


def _derive_paths(args):
    model_path = Path(args.model_path) if args.model_path else None
    if model_path is not None:
        args.train_target_dir = args.train_target_dir or str(model_path / "train_renders")
        args.train_gt_dir = args.train_gt_dir or str(model_path / "train_gt")
        args.apply_target_dir = args.apply_target_dir or str(model_path / "novel_target_only" / "target_renders")
        args.output_dir = args.output_dir or str(model_path / "novel_learned_sar_like")
        args.checkpoint = args.checkpoint or str(model_path / "learned_sar_refiner.pth")
    if not args.checkpoint:
        args.checkpoint = str(Path(args.output_dir or ".") / "learned_sar_refiner.pth")


def train_refiner(args, device: torch.device) -> SmallUNet:
    pairs = _match_pairs(Path(args.train_target_dir), Path(args.train_gt_dir))
    print(f"[learn refiner] train pairs: {len(pairs)}")
    init_ckpt = None
    if getattr(args, "init_checkpoint", None):
        init_path = Path(args.init_checkpoint)
        if not init_path.is_file():
            raise RuntimeError(f"--init_checkpoint not found: {init_path}")
        init_ckpt = torch.load(init_path, map_location=device)
        init_args = init_ckpt.get("args", {})
        if "model_base" in init_args and not getattr(args, "_model_base_explicit", False):
            args.model_base = int(init_args["model_base"])
        if "noise_channels" in init_args and not getattr(args, "_noise_channels_explicit", False):
            args.noise_channels = int(init_args["noise_channels"])
    in_ch = _model_input_channels(args)
    model = _build_refiner_model(args, in_ch).to(device)
    if init_ckpt is not None:
        ckpt_in_ch = int(init_ckpt.get("in_ch", in_ch))
        if ckpt_in_ch != in_ch:
            raise RuntimeError(f"--init_checkpoint input channels mismatch: checkpoint={ckpt_in_ch}, current={in_ch}")
        model.load_state_dict(init_ckpt["model"], strict=True)
        print(f"[learn refiner] initialized from: {args.init_checkpoint}")
    opt = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
    target_modulation = _is_target_modulation_mode(args)
    use_gan = float(getattr(args, "gan_weight", 0.0) or 0.0) > 0.0 and not target_modulation
    use_crop_gan = float(getattr(args, "target_crop_gan_weight", 0.0) or 0.0) > 0.0 and not target_modulation
    disc = ConditionalDiscriminator(in_ch=3 + in_ch, base=int(args.discriminator_base)).to(device) if use_gan else None
    crop_disc = (
        ConditionalDiscriminator(in_ch=3 + in_ch, base=int(args.target_crop_discriminator_base)).to(device)
        if use_crop_gan
        else None
    )
    opt_d = (
        torch.optim.AdamW(disc.parameters(), lr=float(args.lr_d), betas=(0.0, 0.9), weight_decay=float(args.weight_decay))
        if disc is not None
        else None
    )
    opt_crop_d = (
        torch.optim.AdamW(
            crop_disc.parameters(), lr=float(args.lr_crop_d), betas=(0.0, 0.9), weight_decay=float(args.weight_decay)
        )
        if crop_disc is not None
        else None
    )
    scaler = torch.amp.GradScaler("cuda", enabled=bool(args.amp) and device.type == "cuda")
    quantiles = _parse_quantiles(args.stat_quantiles)

    loaded = []
    for tp, gp, az in pairs:
        t = _load_image(tp, args).to(device)
        g = _load_image(gp, args).to(device)
        g = _resize_chw(g, tuple(t.shape[-2:]))
        loaded.append((t, g, az, tp.name))

    pbar = tqdm(range(1, int(args.iterations) + 1), desc="train learned SAR refiner")
    ema = None
    for it in pbar:
        idx = torch.randint(0, len(loaded), (int(args.batch_size),), device="cpu").tolist()
        xs, targets, gts, preserves, hard_masks, azimuths = [], [], [], [], [], []
        for i in idx:
            target, gt, az, _name = loaded[i]
            x, hard, preserve = _build_input(target, az, args, training=True)
            xs.append(x)
            targets.append(target)
            gts.append(gt)
            preserves.append(preserve)
            hard_masks.append(hard)
            azimuths.append(float(az))
        x = torch.stack(xs, dim=0)
        target_b = torch.stack(targets, dim=0)
        gt_b = torch.stack(gts, dim=0)
        preserve_b = torch.stack(preserves, dim=0)
        hard_b = torch.stack(hard_masks, dim=0)

        if (use_gan and it >= int(args.gan_start_iter)) or (use_crop_gan and it >= int(args.target_crop_gan_start_iter)):
            for _ in range(max(1, int(args.gan_d_steps))):
                with torch.no_grad():
                    raw_d = model(x)
                    if target_modulation:
                        fake_d, _maps_d = _compose_target_modulation_batch(raw_d, target_b, hard_b, args)
                    else:
                        raw_d = _force_grayscale_batch(raw_d, args)
                        fake_d = raw_d * (1.0 - preserve_b[:, None]) + target_b * preserve_b[:, None]
                    if float(getattr(args, "target_layover_strength", 0.0) or 0.0) > 0.0:
                        fake_d = torch.stack(
                            [
                                _apply_target_layover(fake_d[j], target_b[j], hard_b[j], azimuths[j], args)
                                for j in range(fake_d.shape[0])
                            ],
                            dim=0,
                        )
                az_vec = _azimuth_vec_tensor(azimuths, device=device, dtype=gt_b.dtype)
                if use_gan and it >= int(args.gan_start_iter):
                    opt_d.zero_grad(set_to_none=True)
                    real_logits, real_az = disc(gt_b, x)
                    fake_logits, fake_az = disc(fake_d.detach(), x)
                    d_adv = F.relu(1.0 - real_logits).mean() + F.relu(1.0 + fake_logits).mean()
                    d_az = F.mse_loss(real_az, az_vec) + F.mse_loss(fake_az, az_vec)
                    d_loss = d_adv + float(args.gan_az_weight) * d_az
                    d_loss.backward()
                    opt_d.step()
                if use_crop_gan and it >= int(args.target_crop_gan_start_iter):
                    opt_crop_d.zero_grad(set_to_none=True)
                    real_crop, crop_cond = _crop_around_mask_batch(
                        gt_b,
                        x,
                        hard_b,
                        int(args.target_crop_size),
                        float(args.target_crop_pad_frac),
                    )
                    fake_crop, _ = _crop_around_mask_batch(
                        fake_d.detach(),
                        x,
                        hard_b,
                        int(args.target_crop_size),
                        float(args.target_crop_pad_frac),
                    )
                    real_logits, real_az = crop_disc(real_crop, crop_cond)
                    fake_logits, fake_az = crop_disc(fake_crop, crop_cond)
                    d_adv = F.relu(1.0 - real_logits).mean() + F.relu(1.0 + fake_logits).mean()
                    d_az = F.mse_loss(real_az, az_vec) + F.mse_loss(fake_az, az_vec)
                    d_loss = d_adv + float(args.target_crop_gan_az_weight) * d_az
                    d_loss.backward()
                    opt_crop_d.step()

        opt.zero_grad(set_to_none=True)
        with torch.amp.autocast("cuda", enabled=bool(args.amp) and device.type == "cuda"):
            raw = model(x)
            modulation_maps = None
            if target_modulation:
                pred, modulation_maps = _compose_target_modulation_batch(raw, target_b, hard_b, args)
            elif _is_unified_full_mode(args):
                raw = _force_grayscale_batch(raw, args)
                pred = raw.clamp(0.0, 1.0)
            else:
                raw = _force_grayscale_batch(raw, args)
                pred = raw * (1.0 - preserve_b[:, None]) + target_b * preserve_b[:, None]
            if float(getattr(args, "target_layover_strength", 0.0) or 0.0) > 0.0:
                pred = torch.stack(
                    [
                        _apply_target_layover(pred[j], target_b[j], hard_b[j], azimuths[j], args)
                        for j in range(pred.shape[0])
                    ],
                    dim=0,
                )
            pred_ld = _to_loss_domain(pred, args)
            gt_ld = _to_loss_domain(gt_b, args)
            full_l1 = (pred_ld - gt_ld).abs().mean()
            outside = (1.0 - _dilate01_batch(hard_b, int(args.loss_target_exclude_dilate)))[:, None]
            outside_l1 = ((pred_ld - gt_ld).abs() * outside).sum() / (outside.sum().clamp_min(1.0) * 3.0)
            target_area = _dilate01_batch(hard_b, int(args.target_scatter_mask_dilate))[:, None]
            target_scatter_l1 = ((pred_ld - gt_ld).abs() * target_area).sum() / (
                target_area.sum().clamp_min(1.0) * 3.0
            )
            if float(getattr(args, "shadow_region_loss_weight", 0.0) or 0.0) > 0.0:
                shadow_region = torch.stack(
                    [
                        _shadow_prior_from_mask(hard_b[j], azimuths[j], args, force=True, strength=1.0).squeeze(0)
                        for j in range(hard_b.shape[0])
                    ],
                    dim=0,
                )
                shadow_region = shadow_region[:, None]
                if int(getattr(args, "shadow_region_extra_dilate", 0) or 0) > 0:
                    shadow_region = _dilate01_batch(shadow_region[:, 0], int(args.shadow_region_extra_dilate)).unsqueeze(1)
                if int(getattr(args, "shadow_region_blur_radius", 0) or 0) > 0:
                    r = int(args.shadow_region_blur_radius)
                    shadow_region = F.avg_pool2d(shadow_region, kernel_size=2 * r + 1, stride=1, padding=r).clamp(0.0, 1.0)
                shadow_region = (shadow_region * (1.0 - target_area.clamp(0.0, 1.0))).clamp(0.0, 1.0)
                shadow_region_l1 = ((pred_ld - gt_ld).abs() * shadow_region).sum() / (
                    shadow_region.sum().clamp_min(1.0) * 3.0
                )
            else:
                shadow_region_l1 = torch.zeros((), device=device, dtype=pred_ld.dtype)
            gt_gray = gt_ld.mean(dim=1, keepdim=True)
            bright_weight = 1.0 + float(args.target_bright_loss_gain) * gt_gray.pow(float(args.target_bright_loss_gamma))
            target_bright_l1 = ((pred_ld - gt_ld).abs() * target_area * bright_weight).sum() / (
                (target_area * bright_weight).sum().clamp_min(1.0) * 3.0
            )
            bg_pred_mean, bg_pred_std = _masked_batch_mean_std(pred_ld, outside)
            bg_gt_mean, bg_gt_std = _masked_batch_mean_std(gt_ld, outside)
            bg_stat = (bg_pred_mean - bg_gt_mean).abs().mean() + (bg_pred_std - bg_gt_std).abs().mean()
            border_mask = _border_mask_batch(
                pred_ld.shape[0],
                pred_ld.shape[-2],
                pred_ld.shape[-1],
                int(getattr(args, "border_loss_width", 0) or 0),
                pred_ld.device,
                pred_ld.dtype,
            )[:, None]
            border_l1 = ((pred_ld - gt_ld).abs() * border_mask).sum() / (
                border_mask.sum().clamp_min(1.0) * 3.0
            )
            border_pred_mean, border_pred_std = _masked_batch_mean_std(pred_ld, border_mask)
            border_gt_mean, border_gt_std = _masked_batch_mean_std(gt_ld, border_mask)
            border_stat = (border_pred_mean - border_gt_mean).abs().mean() + (
                border_pred_std - border_gt_std
            ).abs().mean()
            target_quant = _masked_quantile_loss(pred_ld, gt_ld, target_area[:, 0], quantiles)
            background_quant = _masked_quantile_loss(pred_ld, gt_ld, outside[:, 0], quantiles)
            pred_std = _local_std_map(pred_ld, int(args.local_texture_radius))
            gt_std = _local_std_map(gt_ld, int(args.local_texture_radius))
            target_texture = _masked_l1(pred_std, gt_std, target_area[:, 0])
            background_texture = _masked_l1(pred_std, gt_std, outside[:, 0])
            pred_env = _local_mean_map(pred_ld, int(args.target_envelope_radius))
            gt_env = _local_mean_map(gt_ld, int(args.target_envelope_radius))
            target_envelope = _masked_l1(pred_env, gt_env, target_area[:, 0])
            pred_grad = _gradient_mag_map(pred_ld)
            gt_grad = _gradient_mag_map(gt_ld)
            target_gradient = _masked_l1(pred_grad, gt_grad, target_area[:, 0])
            intensity_mse = F.mse_loss(pred, gt_b)
            target_keep = ((pred - target_b).abs() * preserve_b[:, None]).sum() / (
                preserve_b.sum().clamp_min(1.0) * 3.0
            )
            if target_modulation:
                target_mse = (((pred - gt_b) ** 2) * target_area).sum() / (
                    target_area.sum().clamp_min(1.0) * 3.0
                )
                tv_loss = torch.zeros((), device=device, dtype=pred.dtype)
                factor_mean = torch.zeros((), device=device, dtype=pred.dtype)
                if modulation_maps is not None:
                    factor = modulation_maps["factor"]
                    tv_h = (factor[:, :, 1:, :] - factor[:, :, :-1, :]).abs().mean()
                    tv_w = (factor[:, :, :, 1:] - factor[:, :, :, :-1]).abs().mean()
                    tv_loss = tv_h + tv_w
                    factor_mean = (((factor - 1.0).abs() * target_area).sum() / target_area.sum().clamp_min(1.0))
                loss = (
                    float(args.target_scatter_loss_weight) * target_scatter_l1
                    + float(args.target_bright_loss_weight) * target_bright_l1
                    + float(args.target_quantile_loss_weight) * target_quant
                    + float(args.target_texture_loss_weight) * target_texture
                    + float(args.target_envelope_loss_weight) * target_envelope
                    + float(args.target_gradient_loss_weight) * target_gradient
                    + float(args.intensity_mse_weight) * target_mse
                    + float(args.target_modulation_tv_weight) * tv_loss
                    + float(args.target_modulation_identity_weight) * factor_mean
                )
            else:
                loss = (
                    full_l1
                    + float(args.outside_loss_weight) * outside_l1
                    + float(args.target_scatter_loss_weight) * target_scatter_l1
                    + float(args.shadow_region_loss_weight) * shadow_region_l1
                    + float(args.target_bright_loss_weight) * target_bright_l1
                    + float(args.background_stat_loss_weight) * bg_stat
                    + float(args.border_loss_weight) * border_l1
                    + float(args.border_stat_loss_weight) * border_stat
                    + float(args.target_quantile_loss_weight) * target_quant
                    + float(args.background_quantile_loss_weight) * background_quant
                    + float(args.target_texture_loss_weight) * target_texture
                    + float(args.background_texture_loss_weight) * background_texture
                    + float(args.target_envelope_loss_weight) * target_envelope
                    + float(args.target_gradient_loss_weight) * target_gradient
                    + float(args.intensity_mse_weight) * intensity_mse
                    + float(args.target_keep_weight) * target_keep
                )
            adv_g = torch.zeros((), device=device, dtype=loss.dtype)
            if use_gan and it >= int(args.gan_start_iter):
                fake_logits, fake_az = disc(pred, x)
                az_vec = _azimuth_vec_tensor(azimuths, device=device, dtype=gt_b.dtype)
                adv_g = -fake_logits.mean() + float(args.gan_az_weight) * F.mse_loss(fake_az, az_vec)
                loss = loss + float(args.gan_weight) * adv_g
            crop_adv_g = torch.zeros((), device=device, dtype=loss.dtype)
            if use_crop_gan and it >= int(args.target_crop_gan_start_iter):
                fake_crop, crop_cond = _crop_around_mask_batch(
                    pred,
                    x,
                    hard_b,
                    int(args.target_crop_size),
                    float(args.target_crop_pad_frac),
                )
                fake_logits, fake_az = crop_disc(fake_crop, crop_cond)
                az_vec = _azimuth_vec_tensor(azimuths, device=device, dtype=gt_b.dtype)
                crop_adv_g = -fake_logits.mean() + float(args.target_crop_gan_az_weight) * F.mse_loss(fake_az, az_vec)
                loss = loss + float(args.target_crop_gan_weight) * crop_adv_g
        scaler.scale(loss).backward()
        scaler.step(opt)
        scaler.update()

        lv = float(loss.detach().item())
        ema = lv if ema is None else 0.9 * ema + 0.1 * lv
        if it % 20 == 0:
            pbar.set_postfix(
                loss=f"{ema:.5f}",
                full=f"{float(full_l1.detach()):.5f}",
                shadow=f"{float(shadow_region_l1.detach()):.5f}",
                gan=f"{float(adv_g.detach()):.3f}" if use_gan else "off",
                cropgan=f"{float(crop_adv_g.detach()):.3f}" if use_crop_gan else "off",
            )

    ckpt = {
        "model": model.state_dict(),
        "args": vars(args),
        "in_ch": in_ch,
        "train_pairs": [name for *_rest, name in loaded],
    }
    Path(args.checkpoint).parent.mkdir(parents=True, exist_ok=True)
    torch.save(ckpt, args.checkpoint)
    print(f"[learn refiner] saved checkpoint: {args.checkpoint}")
    return model


def _dilate01_batch(x: torch.Tensor, iterations: int) -> torch.Tensor:
    if iterations <= 0:
        return x.float().clamp(0.0, 1.0)
    y = x.float()[:, None]
    for _ in range(int(iterations)):
        y = F.max_pool2d(y, kernel_size=3, stride=1, padding=1)
    return y[:, 0].clamp(0.0, 1.0)


def load_refiner(args, device: torch.device) -> SmallUNet:
    ckpt = torch.load(args.checkpoint, map_location=device)
    ckpt_args = ckpt.get("args", {})
    if "refiner_mode" in ckpt_args and not getattr(args, "_refiner_mode_explicit", False):
        args.refiner_mode = str(ckpt_args["refiner_mode"])
    if "model_base" in ckpt_args and not getattr(args, "_model_base_explicit", False):
        args.model_base = int(ckpt_args["model_base"])
    if "noise_channels" in ckpt_args and not getattr(args, "_noise_channels_explicit", False):
        args.noise_channels = int(ckpt_args["noise_channels"])
    in_ch = int(ckpt.get("in_ch", _model_input_channels(args)))
    expected_without_prior = 9 + int(getattr(args, "noise_channels", 2) or 0)
    if in_ch <= expected_without_prior and float(getattr(args, "shadow_prior_input_weight", 0.0) or 0.0) > 0.0:
        print(
            "[learn refiner] checkpoint has no shadow-prior input channel; "
            "disabling --shadow_prior_input_weight for compatibility"
        )
        args.shadow_prior_input_weight = 0.0
    model = _build_refiner_model(args, in_ch).to(device)
    if _is_unified_full_mode(args):
        missing, unexpected = model.load_state_dict(ckpt["model"], strict=False)
        if missing or unexpected:
            print(
                "[learn refiner] warning: checkpoint/model keys differ; "
                f"missing={list(missing)[:6]}, unexpected={list(unexpected)[:6]}. "
                "Retrain for best unified_full target-detail quality."
            )
    else:
        model.load_state_dict(ckpt["model"], strict=True)
    model.eval()
    print(f"[learn refiner] loaded checkpoint: {args.checkpoint}")
    return model


def _target_layover_enabled_for_stage(args, stage: str) -> bool:
    if float(getattr(args, "target_layover_strength", 0.0) or 0.0) <= 0.0:
        return False
    mode = str(getattr(args, "target_layover_stage", "both") or "both").lower().strip()
    if mode == "both":
        return True
    return mode == stage


def apply_refiner(model: SmallUNet, args, device: torch.device) -> None:
    target_dir = Path(args.apply_target_dir)
    out_root = Path(args.output_dir)
    renders_dir = out_root / "renders"
    target_dir_out = out_root / "target_renders"
    masks_dir = out_root / "masks"
    maps_dir = out_root / "modulation_maps"
    renders_dir.mkdir(parents=True, exist_ok=True)
    target_dir_out.mkdir(parents=True, exist_ok=True)
    if bool(args.save_masks):
        masks_dir.mkdir(parents=True, exist_ok=True)
    if bool(getattr(args, "save_modulation_maps", False)):
        for name in ("speckle_multiplier", "dark_factor", "visibility", "factor"):
            (maps_dir / name).mkdir(parents=True, exist_ok=True)
    files = _image_files(target_dir)
    if not files:
        raise RuntimeError(f"No target renders found: {target_dir}")
    style_refs = _load_style_refs(args, device)
    if float(getattr(args, "background_style_strength", 0.0) or 0.0) > 0.0:
        if style_refs:
            print(f"[learn refiner] background style refs: {len(style_refs)} from {getattr(args, 'background_reference_dir', None) or getattr(args, 'train_gt_dir', None)}")
        else:
            print("[learn refiner] warning: background style requested but no reference images were found")
    with torch.inference_mode():
        for path in tqdm(files, desc="apply learned SAR refiner", unit="img"):
            target = _load_image(path, args).to(device)
            az = _parse_azimuth(path)
            x, hard, preserve = _build_input(target, az, args, training=False)
            raw = model(x[None])[0]
            if _is_target_modulation_mode(args):
                learned_pred, modulation_maps = _compose_target_modulation(raw, target, hard, args)
                pred = target.clone()
            elif _is_unified_full_mode(args):
                raw = _force_grayscale_chw(raw, args)
                pred = raw.clamp(0.0, 1.0)
                learned_pred = pred.clone()
            else:
                raw = _force_grayscale_chw(raw, args)
                pred = _compose_prediction(raw, target, preserve)
                learned_pred = pred.clone()
            pred = _apply_target_passthrough(pred, target, hard, args)
            if _target_layover_enabled_for_stage(args, "before"):
                pred = _apply_target_layover(pred, target, hard, az, args)
            pred = _apply_target_radiometry(pred, target, hard, az, args)
            pred = _apply_target_scatter_falloff(pred, hard, az, args)
            pred = _apply_target_peak_soften(pred, hard, args)
            pred = _apply_post_speckle(pred, hard, az, args)
            style_item = _nearest_style_ref(style_refs, az)
            pred = _apply_background_style(pred, hard, style_item[1] if style_item is not None else None, az, args)
            if _is_target_modulation_mode(args):
                target_alpha = _target_intensity_alpha(target, hard, args, "target_modulation_alpha")
                pred = (pred * (1.0 - target_alpha.unsqueeze(0)) + learned_pred * target_alpha.unsqueeze(0)).clamp(0.0, 1.0)
            pred = _apply_refiner_guided_target_composite(pred, target, learned_pred, hard, style_item[1] if style_item is not None else None, az, args)
            pred = _apply_learned_target_clean_composite(pred, target, learned_pred, hard, style_item[1] if style_item is not None else None, az, args)
            pred = _apply_learned_target_reference_match(pred, hard, style_item[1] if style_item is not None else None, args)
            pred = _apply_target_boundary_seam_repair(pred, hard, style_item[1] if style_item is not None else None, az, args)
            pred = _apply_target_shadow_interface_breakup(pred, target, learned_pred, hard, az, args)
            pred = _apply_target_shadow_interface_soften(pred, learned_pred, hard, az, args)
            pred = _apply_target_passthrough(pred, target, hard, args)
            pred = _apply_learned_target_envelope(pred, target, learned_pred, hard, args)
            pred = _apply_learned_target_visibility(pred, target, learned_pred, hard, args)
            pred = _apply_target_occlusion(pred, target, hard, az, args)
            if _target_layover_enabled_for_stage(args, "after"):
                pred = _apply_target_layover(pred, target, hard, az, args)
            pred = _apply_occluded_target_speckle_patch(pred, target, learned_pred, hard, style_item[1] if style_item is not None else None, az, args)
            pred = _apply_target_sar_texture(pred, target, learned_pred, hard, style_item[1] if style_item is not None else None, az, args)
            # Keep synthetic shadow last so texture/speckle passes cannot wash it out.
            pred = _apply_synthetic_shadow(pred, hard, az, args)
            pred = _force_grayscale_chw(pred, args)
            torchvision.utils.save_image(pred, str(renders_dir / path.name))
            torchvision.utils.save_image(target, str(target_dir_out / path.name))
            if bool(args.save_masks):
                torchvision.utils.save_image(hard.unsqueeze(0), str(masks_dir / path.name))
            if _is_target_modulation_mode(args) and bool(getattr(args, "save_modulation_maps", False)):
                for name in ("speckle_multiplier", "dark_factor", "visibility", "factor"):
                    val = modulation_maps[name].clamp(0.0, 1.0)
                    if name in ("speckle_multiplier", "factor"):
                        val = (val / max(float(getattr(args, "target_modulation_factor_max", 1.8) or 1.8), 1e-6)).clamp(0.0, 1.0)
                    torchvision.utils.save_image(val, str(maps_dir / name / path.name))
    print(f"[learn refiner] done: {renders_dir}")


def main() -> None:
    parser = ArgumentParser(description="Learn and apply an image-domain SAR shadow/layover refiner")
    parser.add_argument("-m", "--model_path", type=str, default=None)
    parser.add_argument("--train_target_dir", type=str, default=None)
    parser.add_argument("--train_gt_dir", type=str, default=None)
    parser.add_argument("--apply_target_dir", type=str, default=None)
    parser.add_argument("--output_dir", type=str, default=None)
    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--init_checkpoint", type=str, default=None)
    parser.add_argument(
        "--refiner_mode",
        type=str,
        default="image",
        choices=("image", "target_modulation", "unified_residual", "unified_full", "full_dhfr", "direct_full"),
    )
    parser.add_argument("--train_only", action="store_true", default=False)
    parser.add_argument("--apply_only", action="store_true", default=False)
    parser.add_argument("--iterations", type=int, default=2000)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--model_base", type=int, default=32)
    parser.add_argument("--residual_logit_scale", type=float, default=8.0)
    parser.add_argument("--target_detail_mix", type=float, default=0.65)
    parser.add_argument("--target_detail_logit_scale", type=float, default=4.0)
    parser.add_argument("--discriminator_base", type=int, default=32)
    parser.add_argument("--amp", action="store_true", default=False)
    parser.add_argument("--grayscale_sar", action=BooleanOptionalAction, default=True)
    parser.add_argument("--force_grayscale_output", action=BooleanOptionalAction, default=True)
    parser.add_argument("--intensity_loss_domain", choices=["log", "linear"], default="log")
    parser.add_argument("--log_intensity_scale", type=float, default=20.0)
    parser.add_argument("--noise_channels", type=int, default=2)
    parser.add_argument("--noise_seed", type=int, default=1234)
    parser.add_argument("--noise_lowfreq_radius", type=int, default=9)
    parser.add_argument("--mask_threshold", type=float, default=0.08)
    parser.add_argument("--mask_quantile", type=float, default=0.35)
    parser.add_argument("--mask_dilate", type=int, default=1)
    parser.add_argument("--mask_blur_radius", type=int, default=2)
    parser.add_argument("--target_passthrough_strength", type=float, default=0.0)
    parser.add_argument("--target_passthrough_alpha_threshold", type=float, default=0.015)
    parser.add_argument("--target_passthrough_alpha_high", type=float, default=0.18)
    parser.add_argument("--target_passthrough_alpha_gamma", type=float, default=0.75)
    parser.add_argument("--target_passthrough_alpha_dilate", type=int, default=0)
    parser.add_argument("--target_passthrough_alpha_blur", type=int, default=0)
    parser.add_argument("--target_passthrough_alpha_use_mask_floor", action=BooleanOptionalAction, default=False)
    parser.add_argument("--target_passthrough_alpha_mask_floor", type=float, default=0.25)
    parser.add_argument("--target_passthrough_scale", type=float, default=1.0)
    parser.add_argument("--target_passthrough_gamma", type=float, default=1.0)
    parser.add_argument("--target_passthrough_bias", type=float, default=0.0)
    parser.add_argument("--target_passthrough_preserve_dark_strength", type=float, default=0.0)
    parser.add_argument("--target_passthrough_preserve_dark_threshold", type=float, default=0.06)
    parser.add_argument("--target_passthrough_preserve_dark_blur", type=int, default=1)
    parser.add_argument("--learned_target_envelope_strength", type=float, default=0.0)
    parser.add_argument("--learned_target_envelope_radius", type=int, default=5)
    parser.add_argument("--learned_target_envelope_min_ratio", type=float, default=0.35)
    parser.add_argument("--learned_target_envelope_max_ratio", type=float, default=1.25)
    parser.add_argument("--learned_target_envelope_erode", type=int, default=0)
    parser.add_argument("--learned_target_envelope_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--learned_target_envelope_alpha_high", type=float, default=0.20)
    parser.add_argument("--learned_target_envelope_alpha_gamma", type=float, default=0.80)
    parser.add_argument("--learned_target_envelope_alpha_dilate", type=int, default=0)
    parser.add_argument("--learned_target_envelope_alpha_blur", type=int, default=0)
    parser.add_argument("--learned_target_envelope_alpha_use_mask_floor", action=BooleanOptionalAction, default=False)
    parser.add_argument("--learned_target_envelope_alpha_mask_floor", type=float, default=0.25)
    parser.add_argument("--learned_target_visibility_strength", type=float, default=0.0)
    parser.add_argument("--learned_target_visibility_radius", type=int, default=1)
    parser.add_argument("--learned_target_visibility_low_quantile", type=float, default=0.20)
    parser.add_argument("--learned_target_visibility_high_quantile", type=float, default=0.82)
    parser.add_argument("--learned_target_visibility_gamma", type=float, default=1.0)
    parser.add_argument("--learned_target_visibility_floor", type=float, default=0.10)
    parser.add_argument("--learned_target_visibility_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--learned_target_visibility_alpha_high", type=float, default=0.20)
    parser.add_argument("--learned_target_visibility_alpha_gamma", type=float, default=0.80)
    parser.add_argument("--learned_target_visibility_alpha_dilate", type=int, default=0)
    parser.add_argument("--learned_target_visibility_alpha_blur", type=int, default=0)
    parser.add_argument("--learned_target_visibility_alpha_use_mask_floor", action=BooleanOptionalAction, default=False)
    parser.add_argument("--learned_target_visibility_alpha_mask_floor", type=float, default=0.25)
    parser.add_argument("--target_preserve_strength", type=float, default=0.0)
    parser.add_argument("--target_preserve_threshold", type=float, default=0.45)
    parser.add_argument("--target_preserve_blur_radius", type=int, default=1)
    parser.add_argument("--outside_loss_weight", type=float, default=1.5)
    parser.add_argument("--target_keep_weight", type=float, default=0.0)
    parser.add_argument("--loss_target_exclude_dilate", type=int, default=2)
    parser.add_argument("--target_scatter_loss_weight", type=float, default=2.0)
    parser.add_argument("--target_scatter_mask_dilate", type=int, default=2)
    parser.add_argument("--target_bright_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_bright_loss_gain", type=float, default=4.0)
    parser.add_argument("--target_bright_loss_gamma", type=float, default=2.0)
    parser.add_argument("--background_stat_loss_weight", type=float, default=0.8)
    parser.add_argument("--border_loss_weight", type=float, default=0.0)
    parser.add_argument("--border_stat_loss_weight", type=float, default=0.0)
    parser.add_argument("--border_loss_width", type=int, default=12)
    parser.add_argument("--stat_quantiles", type=str, default="0.50,0.75,0.90,0.97")
    parser.add_argument("--target_quantile_loss_weight", type=float, default=0.0)
    parser.add_argument("--background_quantile_loss_weight", type=float, default=0.0)
    parser.add_argument("--local_texture_radius", type=int, default=3)
    parser.add_argument("--target_texture_loss_weight", type=float, default=0.0)
    parser.add_argument("--background_texture_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_envelope_radius", type=int, default=3)
    parser.add_argument("--target_envelope_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_gradient_loss_weight", type=float, default=0.0)
    parser.add_argument("--intensity_mse_weight", type=float, default=0.0)
    parser.add_argument("--shadow_prior_input_weight", type=float, default=0.0)
    parser.add_argument("--shadow_prior_angle_deg", type=float, default=180.0)
    parser.add_argument("--shadow_prior_rotate_with_azimuth", action=BooleanOptionalAction, default=True)
    parser.add_argument("--shadow_prior_angle_offset", type=float, default=180.0)
    parser.add_argument("--shadow_prior_length_frac", type=float, default=0.28)
    parser.add_argument("--shadow_prior_decay_frac", type=float, default=0.85)
    parser.add_argument("--shadow_prior_blur_radius", type=int, default=2)
    parser.add_argument("--shadow_prior_target_gap", type=int, default=1)
    parser.add_argument("--shadow_prior_use_edge_source", action=BooleanOptionalAction, default=True)
    parser.add_argument("--shadow_region_loss_weight", type=float, default=0.0)
    parser.add_argument("--shadow_region_extra_dilate", type=int, default=1)
    parser.add_argument("--shadow_region_blur_radius", type=int, default=1)
    parser.add_argument("--target_layover_strength", type=float, default=0.0)
    parser.add_argument("--target_layover_length_frac", type=float, default=0.08)
    parser.add_argument("--target_layover_decay_frac", type=float, default=0.65)
    parser.add_argument("--target_layover_blur_radius", type=int, default=1)
    parser.add_argument("--target_layover_threshold", type=float, default=0.0)
    parser.add_argument("--target_layover_quantile", type=float, default=0.78)
    parser.add_argument("--target_layover_max_auto_threshold", type=float, default=0.95)
    parser.add_argument("--target_layover_angle_offset", type=float, default=180.0)
    parser.add_argument("--target_layover_mask_dilate", type=int, default=2)
    parser.add_argument("--target_layover_mask_blur_radius", type=int, default=1)
    parser.add_argument("--target_layover_local_dark_strength", type=float, default=0.0)
    parser.add_argument("--target_layover_floor", type=float, default=0.35)
    parser.add_argument("--target_layover_inside_strength", type=float, default=1.0)
    parser.add_argument("--target_layover_stage", type=str, default="both", choices=("both", "before", "after", "none"))
    parser.add_argument("--target_occlusion_strength", type=float, default=0.0)
    parser.add_argument("--target_occlusion_length_frac", type=float, default=0.08)
    parser.add_argument("--target_occlusion_decay_frac", type=float, default=0.65)
    parser.add_argument("--target_occlusion_blur_radius", type=int, default=1)
    parser.add_argument("--target_occlusion_edge_blur", type=int, default=0)
    parser.add_argument("--target_occlusion_threshold", type=float, default=0.0)
    parser.add_argument("--target_occlusion_quantile", type=float, default=0.55)
    parser.add_argument("--target_occlusion_max_auto_threshold", type=float, default=0.90)
    parser.add_argument("--target_occlusion_angle_offset", type=float, default=180.0)
    parser.add_argument("--target_occlusion_side_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_side_start", type=float, default=0.58)
    parser.add_argument("--target_occlusion_side_gamma", type=float, default=1.4)
    parser.add_argument("--target_occlusion_floor", type=float, default=0.0)
    parser.add_argument("--target_radiometry_strength", type=float, default=0.0)
    parser.add_argument("--target_radiometry_mask_shrink", type=int, default=0)
    parser.add_argument("--target_radiometry_edge_blur", type=int, default=0)
    parser.add_argument("--target_radiometry_high_quantile", type=float, default=0.92)
    parser.add_argument("--target_radiometry_high_rolloff", type=float, default=0.45)
    parser.add_argument("--target_radiometry_gamma", type=float, default=1.0)
    parser.add_argument("--target_brightness_scale", type=float, default=1.0)
    parser.add_argument("--target_dark_patch_strength", type=float, default=0.0)
    parser.add_argument("--target_dark_patch_radius", type=int, default=7)
    parser.add_argument("--target_dark_patch_gamma", type=float, default=1.6)
    parser.add_argument("--target_mid_suppression_strength", type=float, default=0.0)
    parser.add_argument("--target_mid_suppression_low_quantile", type=float, default=0.35)
    parser.add_argument("--target_mid_suppression_high_quantile", type=float, default=0.88)
    parser.add_argument("--target_speckle_strength", type=float, default=0.0)
    parser.add_argument("--target_speckle_looks", type=int, default=1)
    parser.add_argument("--target_speckle_blur_radius", type=int, default=0)
    parser.add_argument("--target_falloff_strength", type=float, default=0.0)
    parser.add_argument("--target_falloff_mask_shrink", type=int, default=0)
    parser.add_argument("--target_falloff_peak_quantile", type=float, default=0.82)
    parser.add_argument("--target_falloff_radius", type=int, default=4)
    parser.add_argument("--target_falloff_directional", action=BooleanOptionalAction, default=True)
    parser.add_argument("--target_falloff_angle_offset", type=float, default=180.0)
    parser.add_argument("--target_falloff_length_frac", type=float, default=0.08)
    parser.add_argument("--target_falloff_decay_frac", type=float, default=0.70)
    parser.add_argument("--target_falloff_trail_blur_radius", type=int, default=1)
    parser.add_argument("--target_falloff_trail_weight", type=float, default=0.65)
    parser.add_argument("--target_falloff_support_gamma", type=float, default=1.4)
    parser.add_argument("--target_falloff_low_quantile", type=float, default=0.22)
    parser.add_argument("--target_falloff_mid_quantile", type=float, default=0.58)
    parser.add_argument("--target_falloff_floor", type=float, default=0.06)
    parser.add_argument("--target_falloff_ceiling", type=float, default=0.55)
    parser.add_argument("--target_peak_soften_strength", type=float, default=0.0)
    parser.add_argument("--target_peak_soften_mask_shrink", type=int, default=0)
    parser.add_argument("--target_peak_soften_quantile", type=float, default=0.72)
    parser.add_argument("--target_peak_soften_radius", type=int, default=2)
    parser.add_argument("--target_peak_soften_core_keep", type=float, default=0.65)
    parser.add_argument("--background_reference_dir", type=str, default=None)
    parser.add_argument("--background_style_strength", type=float, default=0.0)
    parser.add_argument("--background_style_foreground_dilate", type=int, default=5)
    parser.add_argument("--background_style_shadow_search_dilate", type=int, default=28)
    parser.add_argument("--background_style_shadow_threshold", type=float, default=0.10)
    parser.add_argument("--background_style_replace_local_shadow", action=BooleanOptionalAction, default=False)
    parser.add_argument("--background_style_reference_exclude_dilate", type=int, default=18)
    parser.add_argument("--background_style_blend_blur", type=int, default=2)
    parser.add_argument("--background_style_blur_radius", type=int, default=0)
    parser.add_argument("--background_style_lowfreq_mix", type=float, default=0.0)
    parser.add_argument("--background_style_scale", type=float, default=1.0)
    parser.add_argument("--background_style_bias", type=float, default=0.0)
    parser.add_argument("--learned_target_reference_match_strength", type=float, default=0.0)
    parser.add_argument("--learned_target_reference_match_dilate", type=int, default=0)
    parser.add_argument("--learned_target_reference_match_low_quantile", type=float, default=0.25)
    parser.add_argument("--learned_target_reference_match_high_quantile", type=float, default=0.92)
    parser.add_argument("--learned_target_reference_match_min_scale", type=float, default=0.65)
    parser.add_argument("--learned_target_reference_match_max_scale", type=float, default=1.45)
    parser.add_argument("--learned_target_reference_match_blur", type=int, default=0)
    parser.add_argument("--learned_target_clean_composite_strength", type=float, default=0.0)
    parser.add_argument("--learned_target_clean_composite_cleanup_dilate", type=int, default=14)
    parser.add_argument("--learned_target_clean_composite_cleanup_blur", type=int, default=1)
    parser.add_argument("--learned_target_clean_composite_reference_exclude_dilate", type=int, default=18)
    parser.add_argument("--learned_target_clean_composite_target_scale", type=float, default=1.0)
    parser.add_argument("--learned_target_clean_composite_target_gamma", type=float, default=1.0)
    parser.add_argument("--learned_target_clean_composite_target_bias", type=float, default=0.0)
    parser.add_argument("--learned_target_clean_composite_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--learned_target_clean_composite_alpha_high", type=float, default=0.20)
    parser.add_argument("--learned_target_clean_composite_alpha_gamma", type=float, default=0.80)
    parser.add_argument("--learned_target_clean_composite_alpha_dilate", type=int, default=0)
    parser.add_argument("--learned_target_clean_composite_alpha_blur", type=int, default=0)
    parser.add_argument("--learned_target_clean_composite_alpha_use_mask_floor", action=BooleanOptionalAction, default=False)
    parser.add_argument("--learned_target_clean_composite_alpha_mask_floor", type=float, default=0.25)
    parser.add_argument("--refiner_guided_target_strength", type=float, default=0.0)
    parser.add_argument("--refiner_guided_target_cleanup_dilate", type=int, default=18)
    parser.add_argument("--refiner_guided_target_cleanup_blur", type=int, default=1)
    parser.add_argument("--refiner_guided_target_reference_exclude_dilate", type=int, default=22)
    parser.add_argument("--refiner_guided_target_guide_dilate", type=int, default=5)
    parser.add_argument("--refiner_guided_target_guide_blur", type=int, default=1)
    parser.add_argument("--refiner_guided_target_low_quantile", type=float, default=0.18)
    parser.add_argument("--refiner_guided_target_high_quantile", type=float, default=0.82)
    parser.add_argument("--refiner_guided_target_gamma", type=float, default=1.0)
    parser.add_argument("--refiner_guided_target_alpha_floor", type=float, default=0.04)
    parser.add_argument("--refiner_guided_target_visibility_floor", type=float, default=0.08)
    parser.add_argument("--refiner_guided_target_texture_scale", type=float, default=1.0)
    parser.add_argument("--refiner_guided_target_texture_gamma", type=float, default=1.0)
    parser.add_argument("--refiner_guided_target_texture_bias", type=float, default=0.0)
    parser.add_argument("--refiner_guided_target_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--refiner_guided_target_alpha_high", type=float, default=0.20)
    parser.add_argument("--refiner_guided_target_alpha_gamma", type=float, default=0.80)
    parser.add_argument("--refiner_guided_target_alpha_dilate", type=int, default=0)
    parser.add_argument("--refiner_guided_target_alpha_blur", type=int, default=0)
    parser.add_argument("--refiner_guided_target_alpha_use_mask_floor", action=BooleanOptionalAction, default=False)
    parser.add_argument("--refiner_guided_target_alpha_mask_floor", type=float, default=0.25)
    parser.add_argument("--refiner_guided_target_shadow_alpha_suppression", type=float, default=0.0)
    parser.add_argument("--refiner_guided_target_shadow_alpha_edge_width", type=int, default=6)
    parser.add_argument("--refiner_guided_target_shadow_alpha_low_quantile", type=float, default=0.48)
    parser.add_argument("--refiner_guided_target_shadow_alpha_side_start", type=float, default=0.35)
    parser.add_argument("--refiner_guided_target_shadow_alpha_side_gamma", type=float, default=1.0)
    parser.add_argument("--refiner_guided_target_shadow_alpha_side_floor", type=float, default=0.25)
    parser.add_argument("--refiner_guided_target_shadow_alpha_noise_blur", type=int, default=2)
    parser.add_argument("--refiner_guided_target_shadow_alpha_noise_floor", type=float, default=0.20)
    parser.add_argument("--refiner_guided_target_shadow_alpha_blur", type=int, default=1)
    parser.add_argument("--target_boundary_seam_repair_strength", type=float, default=0.0)
    parser.add_argument("--target_boundary_seam_repair_outer", type=int, default=2)
    parser.add_argument("--target_boundary_seam_repair_inner", type=int, default=1)
    parser.add_argument("--target_boundary_seam_repair_reference_exclude_dilate", type=int, default=18)
    parser.add_argument("--target_boundary_seam_repair_blur_radius", type=int, default=2)
    parser.add_argument("--target_boundary_seam_repair_threshold", type=float, default=0.035)
    parser.add_argument("--target_shadow_interface_breakup_strength", type=float, default=0.0)
    parser.add_argument("--target_shadow_interface_breakup_edge_width", type=int, default=2)
    parser.add_argument("--target_shadow_interface_breakup_inner_erode", type=int, default=1)
    parser.add_argument("--target_shadow_interface_breakup_low_quantile", type=float, default=0.38)
    parser.add_argument("--target_shadow_interface_breakup_side_start", type=float, default=0.52)
    parser.add_argument("--target_shadow_interface_breakup_side_gamma", type=float, default=1.2)
    parser.add_argument("--target_shadow_interface_breakup_noise_blur", type=int, default=1)
    parser.add_argument("--target_shadow_interface_breakup_noise_threshold", type=float, default=0.50)
    parser.add_argument("--target_shadow_interface_breakup_support_blur", type=int, default=0)
    parser.add_argument("--target_shadow_interface_breakup_floor", type=float, default=0.04)
    parser.add_argument("--occluded_target_speckle_strength", type=float, default=0.0)
    parser.add_argument("--occluded_target_speckle_low_quantile", type=float, default=0.46)
    parser.add_argument("--occluded_target_speckle_high_quantile", type=float, default=0.82)
    parser.add_argument("--occluded_target_speckle_bright_keep_quantile", type=float, default=0.70)
    parser.add_argument("--occluded_target_speckle_current_dark_quantile", type=float, default=0.55)
    parser.add_argument("--occluded_target_speckle_side_start", type=float, default=0.38)
    parser.add_argument("--occluded_target_speckle_side_gamma", type=float, default=1.0)
    parser.add_argument("--occluded_target_speckle_reference_exclude_dilate", type=int, default=12)
    parser.add_argument("--occluded_target_speckle_reference_quantile", type=float, default=0.55)
    parser.add_argument("--occluded_target_speckle_fallback_max", type=float, default=0.22)
    parser.add_argument("--occluded_target_speckle_patch_blur", type=int, default=0)
    parser.add_argument("--occluded_target_speckle_gate_noise_blur", type=int, default=1)
    parser.add_argument("--occluded_target_speckle_gate_threshold", type=float, default=0.42)
    parser.add_argument("--occluded_target_speckle_edge_width", type=int, default=4)
    parser.add_argument("--occluded_target_speckle_interior_weight", type=float, default=0.45)
    parser.add_argument("--occluded_target_speckle_shadow_region_strength", type=float, default=0.0)
    parser.add_argument("--occluded_target_speckle_shadow_length_frac", type=float, default=0.12)
    parser.add_argument("--occluded_target_speckle_shadow_decay_frac", type=float, default=0.70)
    parser.add_argument("--occluded_target_speckle_shadow_blur_radius", type=int, default=1)
    parser.add_argument("--occluded_target_speckle_shadow_edge_override", type=float, default=0.0)
    parser.add_argument("--occluded_target_speckle_shadow_edge_override_width", type=int, default=2)
    parser.add_argument("--occluded_target_speckle_support_blur", type=int, default=1)
    parser.add_argument("--target_sar_texture_strength", type=float, default=0.0)
    parser.add_argument("--target_sar_texture_shadow_length_frac", type=float, default=0.16)
    parser.add_argument("--target_sar_texture_shadow_decay_frac", type=float, default=0.75)
    parser.add_argument("--target_sar_texture_shadow_blur_radius", type=int, default=1)
    parser.add_argument("--target_sar_texture_shadow_weight", type=float, default=0.75)
    parser.add_argument("--target_sar_texture_dark_quantile", type=float, default=0.48)
    parser.add_argument("--target_sar_texture_looks", type=int, default=1)
    parser.add_argument("--target_sar_texture_block_blur", type=int, default=1)
    parser.add_argument("--target_sar_texture_bright_amount", type=float, default=0.16)
    parser.add_argument("--target_sar_texture_dark_amount", type=float, default=0.35)
    parser.add_argument("--target_sar_texture_low_patch_strength", type=float, default=0.0)
    parser.add_argument("--target_sar_texture_reference_exclude_dilate", type=int, default=12)
    parser.add_argument("--target_sar_texture_reference_quantile", type=float, default=0.65)
    parser.add_argument("--target_sar_texture_low_patch_blur", type=int, default=0)
    parser.add_argument("--target_sar_texture_low_patch_gate_blur", type=int, default=1)
    parser.add_argument("--target_sar_texture_bright_dropout_strength", type=float, default=0.0)
    parser.add_argument("--target_sar_texture_bright_dropout_quantile", type=float, default=0.72)
    parser.add_argument("--target_sar_texture_bright_dropout_noise_blur", type=int, default=0)
    parser.add_argument("--target_sar_texture_bright_dropout_threshold", type=float, default=0.45)
    parser.add_argument("--target_sar_texture_bright_dropout_scale", type=float, default=0.42)
    parser.add_argument("--target_sar_texture_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--target_sar_texture_alpha_high", type=float, default=0.20)
    parser.add_argument("--target_sar_texture_alpha_gamma", type=float, default=0.80)
    parser.add_argument("--target_sar_texture_alpha_dilate", type=int, default=0)
    parser.add_argument("--target_sar_texture_alpha_blur", type=int, default=0)
    parser.add_argument("--target_sar_texture_alpha_use_mask_floor", action=BooleanOptionalAction, default=False)
    parser.add_argument("--target_sar_texture_alpha_mask_floor", type=float, default=0.25)
    parser.add_argument("--target_modulation_mask_dilate", type=int, default=0)
    parser.add_argument("--target_modulation_mask_blur", type=int, default=1)
    parser.add_argument("--target_modulation_speckle_strength", type=float, default=0.55)
    parser.add_argument("--target_modulation_mult_min", type=float, default=0.35)
    parser.add_argument("--target_modulation_mult_max", type=float, default=1.65)
    parser.add_argument("--target_modulation_dark_strength", type=float, default=0.75)
    parser.add_argument("--target_modulation_dark_gamma", type=float, default=1.25)
    parser.add_argument("--target_modulation_dark_floor", type=float, default=0.08)
    parser.add_argument("--target_modulation_visibility_floor", type=float, default=0.12)
    parser.add_argument("--target_modulation_visibility_gamma", type=float, default=1.0)
    parser.add_argument("--target_modulation_factor_max", type=float, default=1.8)
    parser.add_argument("--target_modulation_tv_weight", type=float, default=0.02)
    parser.add_argument("--target_modulation_identity_weight", type=float, default=0.02)
    parser.add_argument("--target_modulation_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--target_modulation_alpha_high", type=float, default=0.20)
    parser.add_argument("--target_modulation_alpha_gamma", type=float, default=0.80)
    parser.add_argument("--target_modulation_alpha_dilate", type=int, default=0)
    parser.add_argument("--target_modulation_alpha_blur", type=int, default=0)
    parser.add_argument("--target_modulation_alpha_use_mask_floor", action=BooleanOptionalAction, default=False)
    parser.add_argument("--target_modulation_alpha_mask_floor", type=float, default=0.25)
    parser.add_argument("--target_shadow_interface_soften_strength", type=float, default=0.0)
    parser.add_argument("--target_shadow_interface_soften_edge_width", type=int, default=4)
    parser.add_argument("--target_shadow_interface_soften_inner_erode", type=int, default=1)
    parser.add_argument("--target_shadow_interface_soften_low_quantile", type=float, default=0.48)
    parser.add_argument("--target_shadow_interface_soften_side_start", type=float, default=0.38)
    parser.add_argument("--target_shadow_interface_soften_side_gamma", type=float, default=1.0)
    parser.add_argument("--target_shadow_interface_soften_side_floor", type=float, default=0.0)
    parser.add_argument("--target_shadow_interface_soften_noise_blur", type=int, default=2)
    parser.add_argument("--target_shadow_interface_soften_noise_floor", type=float, default=0.25)
    parser.add_argument("--target_shadow_interface_soften_support_blur", type=int, default=1)
    parser.add_argument("--target_shadow_interface_soften_radius", type=int, default=3)
    parser.add_argument("--target_shadow_interface_soften_darken", type=float, default=0.35)
    parser.add_argument("--target_shadow_interface_soften_floor", type=float, default=0.035)
    parser.add_argument("--shadow_synth_strength", type=float, default=0.0)
    parser.add_argument("--shadow_synth_angle_deg", type=float, default=180.0)
    parser.add_argument("--shadow_synth_rotate_with_azimuth", action=BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_synth_angle_offset", type=float, default=180.0)
    parser.add_argument("--shadow_synth_length_frac", type=float, default=0.18)
    parser.add_argument("--shadow_synth_decay_frac", type=float, default=0.85)
    parser.add_argument("--shadow_synth_blur_radius", type=int, default=1)
    parser.add_argument("--shadow_synth_edge_blur", type=int, default=0)
    parser.add_argument("--shadow_synth_use_edge_source", action=BooleanOptionalAction, default=True)
    parser.add_argument("--shadow_synth_source_side_fraction", type=float, default=0.35)
    parser.add_argument("--shadow_synth_source_side_blur", type=int, default=0)
    parser.add_argument("--shadow_synth_mask_shrink", type=int, default=0)
    parser.add_argument("--shadow_synth_target_gap", type=int, default=1)
    parser.add_argument("--shadow_synth_floor", type=float, default=0.0)
    parser.add_argument("--gan_weight", type=float, default=0.0)
    parser.add_argument("--gan_start_iter", type=int, default=200)
    parser.add_argument("--gan_d_steps", type=int, default=1)
    parser.add_argument("--gan_az_weight", type=float, default=0.5)
    parser.add_argument("--lr_d", type=float, default=4e-4)
    parser.add_argument("--target_crop_gan_weight", type=float, default=0.0)
    parser.add_argument("--target_crop_gan_start_iter", type=int, default=300)
    parser.add_argument("--target_crop_gan_az_weight", type=float, default=0.5)
    parser.add_argument("--target_crop_discriminator_base", type=int, default=24)
    parser.add_argument("--target_crop_size", type=int, default=96)
    parser.add_argument("--target_crop_pad_frac", type=float, default=0.45)
    parser.add_argument("--lr_crop_d", type=float, default=2.5e-4)
    parser.add_argument("--post_speckle_strength", type=float, default=0.0)
    parser.add_argument("--post_speckle_looks", type=int, default=2)
    parser.add_argument("--post_speckle_blur_radius", type=int, default=0)
    parser.add_argument("--post_speckle_target_gap", type=int, default=1)
    parser.add_argument("--post_speckle_on_target", type=float, default=0.25)
    parser.add_argument("--post_speckle_floor", type=float, default=0.0)
    parser.add_argument("--save_masks", action="store_true", default=False)
    parser.add_argument("--save_modulation_maps", action="store_true", default=False)
    parser.add_argument("--device", type=str, default="cuda")
    args = parser.parse_args()
    args._refiner_mode_explicit = any(a == "--refiner_mode" or str(a).startswith("--refiner_mode=") for a in sys.argv[1:])
    args._model_base_explicit = any(a == "--model_base" or str(a).startswith("--model_base=") for a in sys.argv[1:])
    args._noise_channels_explicit = any(a == "--noise_channels" or str(a).startswith("--noise_channels=") for a in sys.argv[1:])
    _derive_paths(args)

    if args.apply_only and not Path(args.checkpoint).is_file():
        raise RuntimeError(f"--apply_only requires an existing checkpoint: {args.checkpoint}")
    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    if device.type == "cpu":
        print("[learn refiner] using CPU")

    if args.apply_only:
        model = load_refiner(args, device)
    else:
        if not args.train_target_dir or not args.train_gt_dir:
            raise RuntimeError("Training requires --train_target_dir and --train_gt_dir, or -m with train_renders/train_gt")
        model = train_refiner(args, device)
    if not args.train_only:
        if not args.apply_target_dir:
            raise RuntimeError("Apply requires --apply_target_dir, or -m with novel_target_only/target_renders")
        apply_refiner(model, args, device)


if __name__ == "__main__":
    main()
