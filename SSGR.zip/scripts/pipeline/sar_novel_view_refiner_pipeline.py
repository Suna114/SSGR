#!/usr/bin/env python3
"""Integrated SAR novel-view refiner workflow.

The full training workflow keeps every stage output under
``<model_path>/output``:

1. Train a base image refiner from scratch.
2. Fine-tune background from the base checkpoint.
3. Apply the fine-tuned checkpoint to novel target renders.
4. Run local target/shadow postprocess.
5. Optionally evaluate against GT with train/novel-view split summaries.

The shorter apply/eval workflow is still available for existing checkpoints.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def _find_repo_root(start: Path) -> Path:
    for p in [start, *start.parents]:
        if (p / "scripts" / "rendering" / "learn_sar_target_modulation_refiner.py").is_file():
            return p
        if (p / "train.py").is_file():
            return p
    return Path.cwd()


def _default_work_dir(model_path: Path, *, timestamped: bool = False) -> Path:
    root = model_path / "output"
    if timestamped:
        return root / datetime.now().strftime("%Y%m%d_%H%M%S")
    return root


def _default_target_mask_dir(model_path: Path, work_dir: Path) -> Path:
    candidates = [
        model_path / "novel_target_only" / "target_renders",
        model_path / "\u65b0\u5efa\u6587\u4ef6\u5939" / "novel_target_only" / "target_renders",
        work_dir / "novel_target_only" / "target_renders",
    ]
    for path in candidates:
        if path.exists():
            return path
    return work_dir / "novel_target_only" / "target_renders"


def _image_dir_for_semantic_masks(data_dir: Path, fallback_gt_dir: Path | None) -> Path:
    if fallback_gt_dir is not None and fallback_gt_dir.is_dir():
        return fallback_gt_dir
    for name in ("input", "images"):
        candidate = data_dir / name
        if candidate.is_dir():
            return candidate
    return data_dir


def _export_semantic_target_mask_dir(
    data_dir: Path | None,
    fallback_gt_dir: Path | None,
    *,
    run_id: str = "latest",
    repo_root: Path | None = None,
) -> Path | None:
    """Export target labels 1/2 from convert semantic masks as binary PNGs."""
    if data_dir is None or not data_dir.is_dir():
        return None
    if repo_root is not None:
        repo_root_str = str(repo_root)
        if repo_root_str not in sys.path:
            sys.path.insert(0, repo_root_str)
    try:
        import numpy as np
        from PIL import Image
        from sar.semantic_mask_config import load_convert_scattering_masks
    except Exception as exc:
        print(f"[semantic target masks] unavailable: {exc}")
        return None

    image_dir = _image_dir_for_semantic_masks(data_dir, fallback_gt_dir)
    loaded = load_convert_scattering_masks(str(data_dir), str(image_dir), run_id=run_id)
    if loaded is None:
        return None
    masks, mask_dir_raw = loaded
    mask_dir = Path(mask_dir_raw)
    out_dir = data_dir / "scattering_masks" / "target_masks_from_convert" / "latest"
    out_dir.mkdir(parents=True, exist_ok=True)

    image_exts = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}
    written = 0
    for src in sorted(p for p in image_dir.iterdir() if p.is_file() and p.suffix.lower() in image_exts):
        mask = masks.get(src.name)
        if mask is None:
            continue
        target = ((np.asarray(mask) == 1) | (np.asarray(mask) == 2)).astype(np.uint8) * 255
        Image.fromarray(target, mode="L").save(out_dir / f"{src.stem}.png")
        written += 1

    meta = {
        "source_data_dir": str(data_dir),
        "source_image_dir": str(image_dir),
        "source_mask_dir": str(mask_dir),
        "run_id": str(run_id),
        "target_labels": [1, 2],
        "count": written,
        "saved_at": datetime.now().isoformat(timespec="seconds"),
    }
    (out_dir / "semantic_target_mask_manifest.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    if written <= 0:
        return None
    print(f"[semantic target masks] exported {written} masks from {mask_dir} -> {out_dir}")
    return out_dir


def _default_train_gt_dir(repo_root: Path, model_path: Path) -> Path | None:
    candidates = [
        repo_root / "data" / "360-3" / "input",
        model_path / "train_gt",
    ]
    for path in candidates:
        if path.exists():
            return path
    return candidates[0]


def _default_eval_gt_dir() -> Path | None:
    path = Path("F:/3dgs") / "\u65b0\u5efa\u6587\u4ef6\u5939" / "T72" / "SN_812"
    return path if path.exists() else None


def _default_classification_root() -> Path:
    return Path("F:/3dgs/PyTorch-Image-Models-Multi-Label-Classification-main")


def _resolve_user_path(path: Path | None, base_dir: Path) -> Path | None:
    """Resolve relative CLI paths against the user's launch directory."""
    if path is None:
        return None
    path = Path(path)
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


def _has_png_images(path: Path) -> bool:
    return path.is_dir() and any(path.glob("*.png"))


def _repo_relative_script(repo_root: Path, relative: str) -> str:
    return str((repo_root / relative).resolve())


def _run(cmd: list[str], cwd: Path, dry_run: bool = False) -> None:
    print("\n" + "=" * 96)
    print(_format_cmd(cmd))
    print("=" * 96)
    if dry_run:
        return
    subprocess.run(cmd, cwd=str(cwd), check=True)


def _format_duration(seconds: float | None) -> str:
    if seconds is None:
        return "n/a"
    seconds = max(0.0, float(seconds))
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = seconds % 60
    if hours:
        return f"{hours:d}h {minutes:02d}m {secs:05.2f}s"
    if minutes:
        return f"{minutes:d}m {secs:05.2f}s"
    return f"{secs:.2f}s"


def _run_recorded(
    stage: str,
    cmd: list[str],
    cwd: Path,
    executed_commands: list[dict],
    dry_run: bool = False,
) -> None:
    item = {
        "stage": stage,
        "command": _format_cmd(cmd),
        "cwd": str(cwd),
        "started_at": datetime.now().isoformat(timespec="seconds"),
    }
    executed_commands.append(item)
    start = time.perf_counter()
    try:
        _run(cmd, cwd, dry_run=dry_run)
    except Exception:
        item["status"] = "failed"
        raise
    else:
        item["status"] = "dry_run" if dry_run else "ok"
    finally:
        elapsed = time.perf_counter() - start
        item["duration_sec"] = round(elapsed, 3)
        item["ended_at"] = datetime.now().isoformat(timespec="seconds")
        print(f"[timing] {stage}: {_format_duration(elapsed)}")


def _summarize_stage_timings(executed_commands: list[dict], total_sec: float | None = None) -> dict:
    stages = []
    for item in executed_commands:
        duration = item.get("duration_sec")
        stages.append(
            {
                "stage": item.get("stage"),
                "duration_sec": duration,
                "duration": _format_duration(duration),
                "status": item.get("status"),
                "started_at": item.get("started_at"),
                "ended_at": item.get("ended_at"),
            }
        )
    measured_total = sum(float(item.get("duration_sec") or 0.0) for item in executed_commands)
    total = measured_total if total_sec is None else float(total_sec)
    return {
        "total_sec": round(total, 3),
        "total": _format_duration(total),
        "measured_stage_total_sec": round(measured_total, 3),
        "measured_stage_total": _format_duration(measured_total),
        "stages": stages,
    }


def _print_timing_summary(timing_summary: dict) -> None:
    if not timing_summary:
        return
    print("\n[timing summary]")
    for item in timing_summary.get("stages", []):
        print(f"  {str(item.get('stage', 'stage')):22s}: {item.get('duration', 'n/a')}")
    print(f"  {'total':22s}: {timing_summary.get('total', 'n/a')}")


def _format_cmd(cmd: list[str]) -> str:
    return " ".join(f'"{x}"' if (" " in x or "\t" in x) else x for x in cmd)


def _json_safe(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(v) for v in value]
    return str(value)


def _unique_result_dir(result_root: Path, timestamp: str, stage: str) -> Path:
    stem = f"{timestamp}_{stage}"
    path = result_root / stem
    idx = 2
    while path.exists():
        path = result_root / f"{stem}_{idx:02d}"
        idx += 1
    return path


def _copy_metric_artifacts(src_dir: Path, dst_dir: Path) -> list[str]:
    copied: list[str] = []
    if not src_dir.exists():
        return copied
    for path in src_dir.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".json", ".txt", ".csv"}:
            continue
        rel = path.relative_to(src_dir)
        out = dst_dir / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, out)
        copied.append(str(rel))
    return copied


def _copy_metric_artifacts_flat(src_dir: Path, dst_dir: Path) -> list[str]:
    copied: list[str] = []
    if not src_dir.exists():
        return copied
    dst_dir.mkdir(parents=True, exist_ok=True)
    for path in src_dir.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".json", ".txt", ".csv"}:
            continue
        rel = path.relative_to(src_dir)
        out = dst_dir / path.name
        if out.exists():
            prefix = "__".join(rel.parts[:-1])
            out = dst_dir / f"{prefix}__{path.name}" if prefix else out
        shutil.copy2(path, out)
        copied.append(out.name)
    return copied


DEBUG_ARCHIVE_SUFFIXES = {
    ".json",
    ".txt",
    ".csv",
    ".png",
    ".jpg",
    ".jpeg",
    ".tif",
    ".tiff",
    ".bmp",
    ".npy",
    ".npz",
}


def _copy_debug_artifacts(src_dir: Path, dst_dir: Path) -> dict:
    stats = {
        "source": str(src_dir),
        "destination": str(dst_dir),
        "files": 0,
        "bytes": 0,
    }
    if not src_dir.exists():
        stats["missing"] = True
        return stats
    for path in src_dir.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in DEBUG_ARCHIVE_SUFFIXES:
            continue
        rel = path.relative_to(src_dir)
        out = dst_dir / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, out)
        stats["files"] += 1
        try:
            stats["bytes"] += int(path.stat().st_size)
        except OSError:
            pass
    return stats


def _sample_dirs_identical(a_dir: Path, b_dir: Path, *, limit: int = 5) -> bool | None:
    """Return True when sampled same-name files are byte-identical, False otherwise.

    None means the directories could not be sampled.
    """
    if not a_dir.exists() or not b_dir.exists():
        return None
    exts = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}
    a_files = [p for p in sorted(a_dir.iterdir(), key=lambda p: p.name.lower()) if p.is_file() and p.suffix.lower() in exts]
    if not a_files:
        return None
    checked = 0
    for a_path in a_files:
        b_path = b_dir / a_path.name
        if not b_path.is_file():
            continue
        try:
            if a_path.read_bytes() != b_path.read_bytes():
                return False
        except OSError:
            return None
        checked += 1
        if checked >= max(int(limit), 1):
            break
    return True if checked > 0 else None


def _mirror_render_images(src_dir: Path, dst_dir: Path, backup_dir: Path | None = None) -> int:
    if not src_dir.exists():
        return 0
    if backup_dir is not None and dst_dir.exists() and not backup_dir.exists():
        shutil.copytree(dst_dir, backup_dir)
    dst_dir.mkdir(parents=True, exist_ok=True)
    copied = 0
    for path in src_dir.iterdir():
        if not path.is_file() or path.suffix.lower() not in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}:
            continue
        shutil.copy2(path, dst_dir / path.name)
        copied += 1
    return copied


def _paper_metric_summary_group(data: dict, path: Path) -> dict:
    summary = data.get("summary", {}) if isinstance(data, dict) else {}
    all_summary = summary.get("ALL") if isinstance(summary, dict) else None
    return {
        "paper_metrics_json": str(path),
        "summary": all_summary if isinstance(all_summary, dict) else {},
        "summary_by_class": {
            key: value
            for key, value in summary.items()
            if key != "ALL" and isinstance(value, dict)
        } if isinstance(summary, dict) else {},
        "image_count": data.get("pair_count"),
        "skipped_count": data.get("skipped_count"),
        "metric_definition": data.get("metric_definition", {}),
    }


def _load_single_metric_summary(path: Path) -> dict | None:
    if not path.is_file():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        return {"error": f"could not read {path}: {e}"}
    if path.name == "paper_metrics_summary.json":
        return _paper_metric_summary_group(data, path)
    return {
        "comparison_json": str(path),
        "summary": data.get("summary", {}),
        "summary_by_view_split": data.get("summary_by_view_split", {}),
        "image_count": len(data.get("per_image", []) or []),
    }


def _load_metric_summary(eval_output: Path) -> dict:
    path = eval_output / "comparison_results.json"
    direct = _load_single_metric_summary(path)
    if direct is not None:
        return direct
    path = eval_output / "paper_metrics_summary.json"
    direct = _load_single_metric_summary(path)
    if direct is not None:
        return direct

    grouped: dict[str, dict] = {}
    subdirs = sorted((p for p in eval_output.iterdir() if p.is_dir()), key=lambda p: p.name) if eval_output.exists() else []
    for subdir in subdirs:
        for name in ("paper_metrics_summary.json", "comparison_results.json"):
            sub_summary = _load_single_metric_summary(subdir / name)
            if sub_summary is not None:
                grouped[subdir.name] = sub_summary
                break
    return grouped


def _metric_mean(metrics: dict, metric_name: str):
    try:
        value = metrics.get("summary", {}).get(metric_name, {}).get("mean")
        return float(value) if value is not None else None
    except Exception:
        return None


def _format_metric(value, digits: int = 4) -> str:
    return "n/a" if value is None else f"{value:.{digits}f}"


def _print_metric_broadcast(metric_summary: dict, eval_skipped_reason: str | None = None) -> None:
    if eval_skipped_reason:
        print(f"\n[metrics] skipped: {eval_skipped_reason}")
        return
    if not metric_summary:
        print("\n[metrics] no comparison metrics found.")
        return

    groups = metric_summary if any(isinstance(v, dict) and "summary" in v for v in metric_summary.values()) else {"target": metric_summary}
    labels = {
        "target": "target",
        "target_shadow": "target+shadow",
        "full": "global",
    }
    print("\n[metrics summary]")
    for key in ("target", "target_shadow", "full"):
        item = groups.get(key)
        if not isinstance(item, dict):
            continue
        image_count = item.get("image_count")
        parts = [
            f"SAR_SSIM={_format_metric(_metric_mean(item, 'SAR_SSIM'))}",
            f"SAR_TOL_PSNR={_format_metric(_metric_mean(item, 'SAR_TOL_PSNR'))}",
            f"SSIM={_format_metric(_metric_mean(item, 'SSIM'))}",
            f"PSNR={_format_metric(_metric_mean(item, 'PSNR'))}",
            f"LPIPS={_format_metric(_metric_mean(item, 'LPIPS'))}",
        ]
        if key == "target":
            parts.extend([
                f"SAR_SSIM_full={_format_metric(_metric_mean(item, 'SAR_SSIM_full'))}",
                f"PSNR_full={_format_metric(_metric_mean(item, 'PSNR_full'))}",
            ])
        count_text = f", n={image_count}" if image_count is not None else ""
        print(f"  {labels.get(key, key):13s}: " + ", ".join(parts) + count_text)


def _load_checkpoint_training_args(checkpoint_path: Path | None) -> dict:
    if checkpoint_path is None or not Path(checkpoint_path).is_file():
        return {}
    try:
        import torch

        ckpt = torch.load(str(checkpoint_path), map_location="cpu")
    except Exception as e:
        return {"error": f"could not read checkpoint args from {checkpoint_path}: {e}"}
    if not isinstance(ckpt, dict):
        return {"error": f"checkpoint is not a dict: {checkpoint_path}"}
    args = ckpt.get("args", {})
    out = {
        "checkpoint": str(checkpoint_path),
        "refiner_mode": ckpt.get("refiner_mode", args.get("refiner_mode") if isinstance(args, dict) else None),
        "in_ch": ckpt.get("in_ch"),
        "out_ch": ckpt.get("out_ch"),
    }
    if isinstance(args, dict):
        out["args"] = _json_safe(args)
    else:
        out["args_error"] = f"checkpoint args are not a dict: {type(args).__name__}"
    if "train_pairs" in ckpt:
        out["train_pairs"] = _json_safe(ckpt.get("train_pairs"))
    return out


def _collect_checkpoint_training_args(output_paths: dict) -> dict:
    collected: dict[str, dict] = {}
    for label in ("base_checkpoint", "background_checkpoint", "apply_checkpoint"):
        path = output_paths.get(label)
        info = _load_checkpoint_training_args(Path(path) if path else None)
        if info:
            collected[label] = info
    return collected


def _write_run_archive(
    args: argparse.Namespace,
    *,
    model_path: Path,
    work_dir: Path,
    result_root: Path,
    eval_output: Path,
    delta_output: Path | None,
    adjacent_output: Path | None,
    eval_ran: bool,
    output_paths: dict,
    executed_commands: list[dict],
    timing_summary: dict | None = None,
    dry_run: bool = False,
) -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = _unique_result_dir(result_root, timestamp, str(args.stage))
    metrics_dir = run_dir / "metrics"
    delta_dir = run_dir / "refiner_delta"
    adjacent_dir = run_dir / "adjacent_similarity"
    run_dir.mkdir(parents=True, exist_ok=True)
    metrics_dir.mkdir(parents=True, exist_ok=True)

    copied_metrics = [] if dry_run or not eval_ran else _copy_metric_artifacts(eval_output, metrics_dir)
    copied_delta = (
        []
        if dry_run or not eval_ran or delta_output is None
        else _copy_metric_artifacts(delta_output, delta_dir)
    )
    copied_adjacent = (
        []
        if dry_run or not eval_ran or adjacent_output is None
        else _copy_metric_artifacts(adjacent_output, adjacent_dir)
    )
    copied_flat_metrics = [] if dry_run or not eval_ran else _copy_metric_artifacts_flat(eval_output, run_dir)
    copied_flat_delta = (
        []
        if dry_run or not eval_ran or delta_output is None
        else _copy_metric_artifacts_flat(delta_output, run_dir)
    )
    metric_summary = {} if dry_run or not eval_ran else _load_metric_summary(eval_output)
    checkpoint_training_args = {} if dry_run else _collect_checkpoint_training_args(output_paths)
    copied_debug_artifacts = []
    if not dry_run and bool(getattr(args, "record_debug_artifacts", True)):
        debug_root = run_dir / "debug_artifacts"
        debug_sources = {
            "eval_intermediate_debug": eval_output / "intermediate_debug",
            "refiner_delta": delta_output,
            "source_target_renders": output_paths.get("source_target_renders"),
            "refiner_target_renders": output_paths.get("refiner_target_renders"),
            "pre_shadow_renders": output_paths.get("pre_shadow_renders"),
            "azimuth_shadow_renders": output_paths.get("azimuth_shadow_renders"),
            "final_renders": output_paths.get("final_renders"),
            "apply_maps": output_paths.get("apply_maps"),
            "azimuth_shadow_maps": output_paths.get("azimuth_shadow_maps"),
        }
        for label, source in debug_sources.items():
            if source is None:
                continue
            source_path = Path(source)
            stats = _copy_debug_artifacts(source_path, debug_root / label)
            if stats.get("files") or not stats.get("missing"):
                stats["label"] = label
                copied_debug_artifacts.append(stats)
    intermediate_metrics = (
        {}
        if dry_run or not eval_ran
        else _load_metric_summary(eval_output / "intermediate_debug")
    )
    archive = {
        "timestamp": timestamp,
        "stage": args.stage,
        "dry_run": bool(dry_run),
        "eval_ran": bool(eval_ran),
        "model_path": str(model_path),
        "work_dir": str(work_dir),
        "result_dir": str(run_dir),
        "effective_args": _json_safe(vars(args)),
        "output_paths": _json_safe(output_paths),
        "checkpoint_training_args": checkpoint_training_args,
        "executed_commands": executed_commands,
        "timing": timing_summary or _summarize_stage_timings(executed_commands),
        "metrics": metric_summary,
        "intermediate_metrics": intermediate_metrics,
        "copied_metric_files": copied_metrics,
        "copied_delta_files": copied_delta,
        "copied_adjacent_similarity_files": copied_adjacent,
        "copied_flat_metric_files": copied_flat_metrics,
        "copied_flat_delta_files": copied_flat_delta,
        "copied_debug_artifacts": copied_debug_artifacts,
    }
    with open(run_dir / "run_record.json", "w", encoding="utf-8") as f:
        json.dump(archive, f, indent=2, ensure_ascii=False)
    with open(run_dir / "parameters.json", "w", encoding="utf-8") as f:
        json.dump(_json_safe(vars(args)), f, indent=2, ensure_ascii=False)
    with open(run_dir / "checkpoint_training_args.json", "w", encoding="utf-8") as f:
        json.dump(checkpoint_training_args, f, indent=2, ensure_ascii=False)
    with open(run_dir / "metrics_summary.json", "w", encoding="utf-8") as f:
        json.dump(metric_summary, f, indent=2, ensure_ascii=False)
    with open(run_dir / "timing_summary.json", "w", encoding="utf-8") as f:
        json.dump(timing_summary or _summarize_stage_timings(executed_commands), f, indent=2, ensure_ascii=False)
    with open(run_dir / "intermediate_metrics_summary.json", "w", encoding="utf-8") as f:
        json.dump(intermediate_metrics, f, indent=2, ensure_ascii=False)
    with open(run_dir / "commands.txt", "w", encoding="utf-8") as f:
        for item in executed_commands:
            f.write(f"[{item.get('stage', 'stage')}]\n")
            f.write(item.get("command", "") + "\n\n")
    latest_files = [
        "run_record.json",
        "parameters.json",
        "checkpoint_training_args.json",
        "metrics_summary.json",
        "timing_summary.json",
        "intermediate_metrics_summary.json",
        "commands.txt",
    ]
    for name in latest_files:
        src = run_dir / name
        if src.is_file():
            shutil.copy2(src, result_root / f"latest_{name}")
    with open(result_root / "latest_result_dir.txt", "w", encoding="utf-8") as f:
        f.write(str(run_dir) + "\n")
    return run_dir


def _supported_cli_options(python: str, cwd: Path, script: str) -> set[str]:
    try:
        proc = subprocess.run(
            [python, script, "--help"],
            cwd=str(cwd),
            check=False,
            text=True,
            capture_output=True,
        )
    except Exception as e:
        print(f"[compat] warning: could not inspect {script}: {e}")
        return set()
    text = (proc.stdout or "") + "\n" + (proc.stderr or "")
    opts = set(re.findall(r"--[A-Za-z0-9][A-Za-z0-9_-]*", text))
    try:
        source = Path(script).read_text(encoding="utf-8", errors="ignore")
        opts.update(re.findall(r"""["'](--[A-Za-z0-9][A-Za-z0-9_-]*)["']""", source))
    except Exception:
        pass
    if proc.returncode not in {0, 1}:
        print(f"[compat] warning: {script} --help returned {proc.returncode}; using conservative CLI args")
    return opts


def _append_if_supported(cmd: list[str], supported: set[str], *items: str) -> list[str]:
    if not items:
        return cmd
    option = items[0]
    if option.startswith("--") and option not in supported:
        print(f"[compat] skipped unsupported option: {option}")
        return cmd
    return cmd + list(items)


def _filter_unsupported_options(cmd: list[str], supported: set[str], *, prefix_len: int = 2) -> list[str]:
    """Remove long options unsupported by the selected child script.

    Some child scripts use parse_known_args(), so unsupported options would be
    silently ignored. Filtering here keeps commands.txt honest and prevents
    false confidence when tuning a pipeline-level parameter.
    """
    if not supported:
        return cmd
    out = list(cmd[:prefix_len])
    skipped: list[str] = []
    i = prefix_len
    while i < len(cmd):
        item = cmd[i]
        if item.startswith("--") and item not in supported:
            skipped.append(item)
            if i + 1 < len(cmd) and not cmd[i + 1].startswith("-"):
                i += 2
            else:
                i += 1
            continue
        out.append(item)
        i += 1
    if skipped:
        uniq = sorted(set(skipped))
        shown = ", ".join(uniq[:12])
        suffix = "" if len(uniq) <= 12 else f", ... (+{len(uniq) - 12})"
        print(f"[compat] removed unsupported child-script options: {shown}{suffix}")
    return out


def _add_clean_layover_flags(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    passthrough = [
        ("--target_loss_mask_threshold", str(args.target_loss_mask_threshold)),
        ("--target_loss_mask_dilate", str(args.target_loss_mask_dilate)),
        ("--target_loss_mask_min_pixels", str(args.target_loss_mask_min_pixels)),
        ("--azimuth_harmonics", str(args.azimuth_harmonics)),
        ("--compose_alpha_threshold", str(args.compose_alpha_threshold)),
        ("--compose_alpha_high", str(args.compose_alpha_high)),
        ("--compose_alpha_gamma", str(args.compose_alpha_gamma)),
        ("--compose_alpha_dilate", str(args.compose_alpha_dilate)),
        ("--compose_alpha_blur", str(args.compose_alpha_blur)),
        ("--extinction_compose_alpha_weight", str(args.extinction_compose_alpha_weight)),
        ("--extinction_compose_alpha_gamma", str(args.extinction_compose_alpha_gamma)),
        ("--delta_log_scale", str(args.delta_log_scale)),
        ("--bright_log_scale", str(args.bright_log_scale)),
        ("--extinction_log_strength", str(args.extinction_log_strength)),
        ("--dark_src_threshold", str(args.dark_src_threshold)),
        ("--dark_gap_threshold", str(args.dark_gap_threshold)),
        ("--dark_gap_softness", str(args.dark_gap_softness)),
        ("--dark_supervision_blur", str(args.dark_supervision_blur)),
        ("--content_loss_use_dark_gt_support" if bool(args.content_loss_use_dark_gt_support) else "--no-content_loss_use_dark_gt_support", None),
        ("--content_gt_support_threshold", str(args.content_gt_support_threshold)),
        ("--content_gt_support_dilate", str(args.content_gt_support_dilate)),
        ("--content_gt_support_blur", str(args.content_gt_support_blur)),
        ("--extinction_target_reference", str(args.extinction_target_reference)),
        ("--extinction_target_gamma", str(args.extinction_target_gamma)),
        ("--extinction_target_margin", str(args.extinction_target_margin)),
        ("--extinction_target_blur", str(args.extinction_target_blur)),
        ("--target_l1_weight", str(args.target_l1_weight)),
        ("--log_mse_weight", str(args.log_mse_weight)),
        ("--sar_ssim_loss_weight", str(args.sar_ssim_loss_weight)),
        ("--sar_ssim_loss_window", str(args.sar_ssim_loss_window)),
        ("--dark_ceiling_weight", str(args.dark_ceiling_weight)),
        ("--dark_mse_weight", str(args.dark_mse_weight)),
        ("--extinction_bce_weight", str(args.extinction_bce_weight)),
        ("--extinction_regression_weight", str(args.extinction_regression_weight)),
        ("--extinction_structure_weight", str(args.extinction_structure_weight)),
        ("--bright_profile_loss_weight", str(args.bright_profile_loss_weight)),
        ("--bright_profile_core_quantile", str(args.bright_profile_core_quantile)),
        ("--bright_profile_core_threshold", str(args.bright_profile_core_threshold)),
        ("--bright_profile_min_core_pixels", str(args.bright_profile_min_core_pixels)),
        ("--bright_profile_core_dilate", str(args.bright_profile_core_dilate)),
        ("--bright_profile_radius", str(args.bright_profile_radius)),
        ("--bright_profile_decay", str(args.bright_profile_decay)),
        ("--bright_profile_floor_log", str(args.bright_profile_floor_log)),
        ("--bright_profile_near_log", str(args.bright_profile_near_log)),
        ("--bright_profile_distance_power", str(args.bright_profile_distance_power)),
        ("--bright_profile_min_distance", str(args.bright_profile_min_distance)),
        ("--boundary_suppression_weight", str(args.boundary_suppression_weight)),
        ("--boundary_ring_width", str(args.boundary_ring_width)),
        ("--boundary_far_distance", str(args.boundary_far_distance)),
        ("--boundary_ceiling_log", str(args.boundary_ceiling_log)),
        ("--visible_identity_weight", str(args.visible_identity_weight)),
        ("--quantile_loss_weight", str(args.quantile_loss_weight)),
        ("--bright_scatter_mse_weight", str(args.bright_scatter_mse_weight)),
        ("--bright_scatter_threshold_log", str(args.bright_scatter_threshold_log)),
        ("--extinction_sparsity_weight", str(args.extinction_sparsity_weight)),
        ("--local_texture_radius", str(args.local_texture_radius)),
        ("--stat_quantiles", str(args.stat_quantiles)),
    ]
    for option, value in passthrough:
        if value is None:
            cmd = _append_if_supported(cmd, supported, option)
        else:
            cmd = _append_if_supported(cmd, supported, option, value)
    return cmd


def _add_clean_layover_apply_flags(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    if bool(getattr(args, "target_only_compose_context", False)):
        passthrough = [
            ("--compose_order", "background_then_target_shadow"),
            ("--empirical_background_strength", str(args.empirical_background_strength)),
            ("--empirical_background_mode", str(args.empirical_background_mode)),
            ("--empirical_background_patch_size", str(args.empirical_background_patch_size)),
            ("--empirical_background_patch_overlap", str(args.empirical_background_patch_overlap)),
            ("--empirical_background_patch_smooth", str(args.empirical_background_patch_smooth)),
            ("--empirical_background_patch_smooth_mix", str(args.empirical_background_patch_smooth_mix)),
            ("--empirical_background_patch_fallback_weight", str(args.empirical_background_patch_fallback_weight)),
            ("--empirical_background_clean_reference" if bool(args.empirical_background_clean_reference) else "--no-empirical_background_clean_reference",),
            ("--empirical_background_reference_exclude_dilate", str(getattr(args, "empirical_background_reference_exclude_dilate", 24))),
            ("--empirical_background_scale", str(getattr(args, "empirical_background_scale", 1.0))),
            ("--empirical_background_bias", str(getattr(args, "empirical_background_bias", 0.0))),
            ("--empirical_background_match_target_peak" if bool(getattr(args, "empirical_background_match_target_peak", False)) else "--no-empirical_background_match_target_peak",),
            ("--empirical_background_target_peak_quantile", str(getattr(args, "empirical_background_target_peak_quantile", 0.95))),
            ("--empirical_background_peak_quantile", str(getattr(args, "empirical_background_peak_quantile", 0.995))),
            ("--empirical_background_peak_mix", str(getattr(args, "empirical_background_peak_mix", 1.0))),
            ("--empirical_background_peak_max_scale", str(getattr(args, "empirical_background_peak_max_scale", 2.5))),
            ("--layer_target_alpha_threshold", str(getattr(args, "layer_target_alpha_threshold", 0.035))),
            ("--layer_target_alpha_high", str(getattr(args, "layer_target_alpha_high", 0.12))),
            ("--layer_target_alpha_gamma", str(getattr(args, "layer_target_alpha_gamma", 0.75))),
            ("--layer_target_use_compose_alpha" if bool(getattr(args, "layer_target_use_compose_alpha", False)) else "--no-layer_target_use_compose_alpha",),
            ("--layer_target_compose_alpha_mix", str(getattr(args, "layer_target_compose_alpha_mix", 0.35))),
            ("--layer_target_dilate", str(getattr(args, "layer_target_dilate", 0))),
            ("--layer_target_blur", str(getattr(args, "layer_target_blur", 1))),
            ("--layer_target_strength", str(getattr(args, "layer_target_strength", 1.0))),
            ("--layer_target_mask_floor", str(getattr(args, "layer_target_mask_floor", 0.35))),
            ("--layer_target_contact_width", str(getattr(args, "layer_target_contact_width", 2))),
            ("--layer_target_contact_strength", str(getattr(args, "layer_target_contact_strength", 0.45))),
            ("--layer_target_contact_blur", str(getattr(args, "layer_target_contact_blur", 1))),
            (
                "--fail_on_degenerate_background_compose"
                if bool(getattr(args, "fail_on_degenerate_background_compose", True))
                else "--no-fail_on_degenerate_background_compose",
            ),
            ("--background_compose_min_mean_abs_diff", str(getattr(args, "background_compose_min_mean_abs_diff", 5e-4))),
            ("--shadow_restore_strength", str(args.shadow_restore_strength)),
            ("--shadow_restore_mode", str(getattr(args, "shadow_restore_mode", "darken"))),
            ("--shadow_restore_threshold", str(getattr(args, "shadow_restore_threshold", 0.18))),
            ("--shadow_restore_target_dilate", str(getattr(args, "shadow_restore_target_dilate", 40))),
            ("--shadow_restore_target_protect_dilate", str(args.shadow_restore_target_protect_dilate)),
            ("--shadow_restore_clean_reference" if bool(args.shadow_restore_clean_reference) else "--no-shadow_restore_clean_reference",),
            ("--shadow_restore_reference_blur", str(getattr(args, "shadow_restore_reference_blur", 4))),
            ("--shadow_restore_blur", str(getattr(args, "shadow_restore_blur", 4))),
            ("--shadow_restore_context_blur", str(getattr(args, "shadow_restore_context_blur", 21))),
            ("--shadow_restore_ratio_mix", str(getattr(args, "shadow_restore_ratio_mix", 0.75))),
            ("--shadow_restore_min_attenuation", str(getattr(args, "shadow_restore_min_attenuation", 0.04))),
            ("--shadow_restore_attenuation_power", str(getattr(args, "shadow_restore_attenuation_power", 1.7))),
            ("--shadow_restore_floor", str(getattr(args, "shadow_restore_floor", 0.0))),
            ("--shadow_restore_max_darken", str(getattr(args, "shadow_restore_max_darken", 0.90))),
            ("--shadow_geometry", str(getattr(args, "shadow_geometry", "reference_connected"))),
            ("--shadow_reference_min_evidence", str(getattr(args, "shadow_reference_min_evidence", 0.05))),
            ("--shadow_reference_floor", str(getattr(args, "shadow_reference_floor", 0.25))),
            ("--shadow_contact_width", str(getattr(args, "shadow_contact_width", 6))),
            ("--shadow_contact_strength", str(getattr(args, "shadow_contact_strength", 0.25))),
            ("--shadow_connected_decay", str(getattr(args, "shadow_connected_decay", 24.0))),
            ("--shadow_connected_blur", str(getattr(args, "shadow_connected_blur", 2))),
            ("--shadow_directional_strength", str(getattr(args, "shadow_directional_strength", 1.0))),
            ("--shadow_directional_length", str(getattr(args, "shadow_directional_length", 42))),
            ("--shadow_directional_decay", str(getattr(args, "shadow_directional_decay", 18.0))),
            ("--shadow_directional_lateral_blur", str(getattr(args, "shadow_directional_lateral_blur", 5))),
            ("--shadow_directional_reference_mix", str(getattr(args, "shadow_directional_reference_mix", 0.65))),
            ("--shadow_direction_offset_deg", str(getattr(args, "shadow_direction_offset_deg", 180.0))),
            ("--shadow_direction_sign", str(getattr(args, "shadow_direction_sign", 1.0))),
        ]
    else:
        passthrough = [
            ("--compose_order", "refiner_then_background"),
            ("--empirical_background_strength", "0.0"),
            ("--shadow_restore_strength", "0.0"),
        ]
    for items in passthrough:
        cmd = _append_if_supported(cmd, supported, *items)
    return cmd


def _add_common_apply_defaults(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    if bool(getattr(args, "target_only_refiner", False)):
        cmd = cmd + ["--refiner_mode", str(args.refiner_mode), "--conv_padding_mode", "reflect"]
        if str(getattr(args, "refiner_mode", "") or "") == "target_layover_clean":
            cmd = _add_clean_layover_flags(cmd, args, supported)
            cmd = _add_clean_layover_apply_flags(cmd, args, supported)
            cmd = _append_if_supported(cmd, supported, "--target_only_refiner")
            cmd += ["--no-save_maps"]
            return cmd
        if str(getattr(args, "refiner_ablation", "none") or "none").lower().strip() not in {"", "none"}:
            cmd = _append_if_supported(cmd, supported, "--refiner_ablation", str(args.refiner_ablation))
        if bool(getattr(args, "target_only_compose_context", False)):
            cmd += [
                "--compose_order",
                "background_then_target_shadow",
                "--empirical_background_strength",
                str(args.empirical_background_strength),
                "--empirical_background_mode",
                str(args.empirical_background_mode),
                "--empirical_background_patch_size",
                str(args.empirical_background_patch_size),
                "--empirical_background_patch_overlap",
                str(args.empirical_background_patch_overlap),
                "--empirical_background_patch_smooth",
                str(args.empirical_background_patch_smooth),
                "--empirical_background_patch_fallback_weight",
                str(args.empirical_background_patch_fallback_weight),
                "--empirical_background_scale",
                str(getattr(args, "empirical_background_scale", 1.0)),
                "--empirical_background_bias",
                str(getattr(args, "empirical_background_bias", 0.0)),
                "--empirical_background_clean_reference" if bool(args.empirical_background_clean_reference) else "--no-empirical_background_clean_reference",
                "--empirical_background_blend_blur",
                "2",
                "--empirical_background_target_dilate",
                "2",
                "--empirical_background_reference_exclude_dilate",
                "24",
                "--target_extinction_apply_gamma",
                str(args.target_extinction_apply_gamma),
                "--target_extinction_apply_mode",
                str(args.target_extinction_apply_mode),
                "--target_extinction_apply_threshold",
                str(args.target_extinction_apply_threshold),
                "--target_extinction_apply_softness",
                str(args.target_extinction_apply_softness),
                "--target_extinction_apply_sigmoid_mix",
                str(args.target_extinction_apply_sigmoid_mix),
                "--target_extinction_strength",
                str(args.target_extinction_strength),
                "--target_extinction_floor",
                str(args.target_extinction_floor),
                "--dark_patch_strength",
                str(args.dark_patch_strength),
                "--dark_patch_floor",
                str(args.dark_patch_floor),
                "--target_preserve_strength",
                str(args.target_preserve_strength),
                "--target_preserve_threshold",
                str(args.target_preserve_threshold),
                "--target_preserve_blur_radius",
                str(args.target_preserve_blur_radius),
                "--target_preserve_occlusion_cut",
                str(args.target_preserve_occlusion_cut),
                "--multiplier_min",
                str(args.multiplier_min),
                "--multiplier_max",
                str(args.multiplier_max),
                "--visibility_min",
                str(args.visibility_min),
                "--visibility_max",
                str(args.visibility_max),
                "--layover_spatial_only" if bool(args.layover_spatial_only) else "--no-layover_spatial_only",
                "--layover_spatial_baseline",
                str(args.layover_spatial_baseline),
                "--layover_spatial_gain",
                str(args.layover_spatial_gain),
                "--layover_spatial_bias",
                str(args.layover_spatial_bias),
                "--layover_spatial_blur_radius",
                str(args.layover_spatial_blur_radius),
                "--dark_patch_spatial_floor",
                str(args.dark_patch_spatial_floor),
                "--target_extinction_spatial_floor",
                str(args.target_extinction_spatial_floor),
                "--layer_target_dilate",
                "0",
                "--layer_target_blur",
                "0",
                "--layer_target_strength",
                "1.0",
            ]
            shadow_restore_strength = float(getattr(args, "shadow_restore_strength", 0.0) or 0.0)
            if shadow_restore_strength > 0.0:
                cmd += [
                    "--shadow_restore_source",
                    "reference",
                    "--shadow_restore_strength",
                    str(shadow_restore_strength),
                    "--shadow_restore_mode",
                    "extinguish",
                    "--shadow_restore_threshold",
                    "0.20",
                    "--shadow_restore_target_dilate",
                    "34",
                    "--shadow_restore_target_protect_dilate",
                    str(args.shadow_restore_target_protect_dilate),
                    "--shadow_restore_clean_reference" if bool(args.shadow_restore_clean_reference) else "--no-shadow_restore_clean_reference",
                    "--shadow_restore_reference_blur",
                    "8",
                    "--shadow_restore_blur",
                    "4",
                    "--shadow_restore_context_blur",
                    "15",
                    "--shadow_restore_ratio_mix",
                    "0.8",
                    "--shadow_restore_min_attenuation",
                    "0.05",
                    "--shadow_restore_attenuation_power",
                    "1.8",
                    "--shadow_restore_max_coverage",
                    "0.22",
                    "--shadow_restore_coverage_softness",
                    "0.12",
                    "--shadow_restore_coverage_blur",
                    "5",
                    "--shadow_restore_floor",
                    "0",
                ]
            else:
                cmd += ["--shadow_restore_strength", "0.0"]
        else:
            cmd += [
                "--compose_order",
                "refiner_then_background",
                "--empirical_background_strength",
                "0.0",
                "--shadow_restore_strength",
                "0.0",
                "--target_extinction_apply_gamma",
                str(args.target_extinction_apply_gamma),
                "--target_extinction_apply_mode",
                str(args.target_extinction_apply_mode),
                "--target_extinction_apply_threshold",
                str(args.target_extinction_apply_threshold),
                "--target_extinction_apply_softness",
                str(args.target_extinction_apply_softness),
                "--target_extinction_apply_sigmoid_mix",
                str(args.target_extinction_apply_sigmoid_mix),
                "--target_extinction_strength",
                str(args.target_extinction_strength),
                "--target_extinction_floor",
                str(args.target_extinction_floor),
                "--dark_patch_strength",
                str(args.dark_patch_strength),
                "--dark_patch_floor",
                str(args.dark_patch_floor),
                "--target_preserve_strength",
                str(args.target_preserve_strength),
                "--target_preserve_threshold",
                str(args.target_preserve_threshold),
                "--target_preserve_blur_radius",
                str(args.target_preserve_blur_radius),
                "--target_preserve_occlusion_cut",
                str(args.target_preserve_occlusion_cut),
                "--multiplier_min",
                str(args.multiplier_min),
                "--multiplier_max",
                str(args.multiplier_max),
                "--visibility_min",
                str(args.visibility_min),
                "--visibility_max",
                str(args.visibility_max),
                "--layover_spatial_only" if bool(args.layover_spatial_only) else "--no-layover_spatial_only",
                "--layover_spatial_baseline",
                str(args.layover_spatial_baseline),
                "--layover_spatial_gain",
                str(args.layover_spatial_gain),
                "--layover_spatial_bias",
                str(args.layover_spatial_bias),
                "--layover_spatial_blur_radius",
                str(args.layover_spatial_blur_radius),
                "--dark_patch_spatial_floor",
                str(args.dark_patch_spatial_floor),
                "--target_extinction_spatial_floor",
                str(args.target_extinction_spatial_floor),
                "--layer_target_dilate",
                "0",
                "--layer_target_blur",
                "0",
            ]
        cmd = _append_if_supported(cmd, supported, "--target_only_refiner")
        cmd = _append_if_supported(cmd, supported, "--layer_target_use_preserve" if bool(args.layer_target_use_preserve) else "--no-layer_target_use_preserve")
        cmd += ["--no-save_maps"]
        return cmd

    # These mirror the stable apply settings now also used as script defaults.
    cmd = cmd + [
        "--refiner_mode",
        "image",
        "--conv_padding_mode",
        "reflect",
        "--compose_order",
        "background_then_target_shadow",
        "--empirical_background_strength",
        str(args.empirical_background_strength),
        "--empirical_background_mode",
        str(args.empirical_background_mode),
        "--empirical_background_patch_size",
        str(args.empirical_background_patch_size),
        "--empirical_background_patch_overlap",
        str(args.empirical_background_patch_overlap),
        "--empirical_background_patch_smooth",
        str(args.empirical_background_patch_smooth),
        "--empirical_background_patch_fallback_weight",
        str(args.empirical_background_patch_fallback_weight),
        "--empirical_background_scale",
        str(getattr(args, "empirical_background_scale", 1.0)),
        "--empirical_background_bias",
        str(getattr(args, "empirical_background_bias", 0.0)),
        "--empirical_background_match_target_peak" if bool(getattr(args, "empirical_background_match_target_peak", False)) else "--no-empirical_background_match_target_peak",
        "--empirical_background_target_peak_quantile",
        str(getattr(args, "empirical_background_target_peak_quantile", 0.95)),
        "--empirical_background_peak_quantile",
        str(getattr(args, "empirical_background_peak_quantile", 0.995)),
        "--empirical_background_peak_mix",
        str(getattr(args, "empirical_background_peak_mix", 1.0)),
        "--empirical_background_peak_max_scale",
        str(getattr(args, "empirical_background_peak_max_scale", 2.5)),
        "--empirical_background_blend_blur",
        "2",
        "--empirical_background_target_dilate",
        "2",
        "--empirical_background_reference_exclude_dilate",
        "20",
        "--target_preserve_strength",
        str(args.target_preserve_strength),
        "--target_preserve_threshold",
        str(args.target_preserve_threshold),
        "--target_preserve_blur_radius",
        str(args.target_preserve_blur_radius),
        "--target_preserve_occlusion_cut",
        str(args.target_preserve_occlusion_cut),
        "--shadow_restore_source",
        "mod_target",
        "--shadow_restore_strength",
        str(args.shadow_restore_strength),
        "--shadow_restore_mode",
        "extinguish",
        "--shadow_restore_threshold",
        "0.22",
        "--shadow_restore_target_dilate",
        "80",
        "--shadow_restore_blur",
        "2",
        "--shadow_restore_context_blur",
        "15",
        "--shadow_restore_ratio_mix",
        "0.9",
        "--shadow_restore_min_attenuation",
        "0.01",
        "--shadow_restore_attenuation_power",
        "2.5",
        "--shadow_restore_floor",
        "0",
        "--layer_target_dilate",
        "0",
        "--layer_target_blur",
        "1",
        "--layer_target_strength",
        "1.0",
    ]
    cmd = _append_if_supported(cmd, supported, "--layer_target_use_preserve" if bool(args.layer_target_use_preserve) else "--no-layer_target_use_preserve")
    if int(args.empirical_background_patch_smooth) > 0:
        cmd = _append_if_supported(
            cmd,
            supported,
            "--empirical_background_patch_smooth_mix",
            str(args.empirical_background_patch_smooth_mix),
        )
    cmd = _append_if_supported(
        cmd,
        supported,
        "--empirical_background_lowfreq_smooth_strength",
        str(args.empirical_background_lowfreq_smooth_strength),
    )
    cmd = _append_if_supported(
        cmd,
        supported,
        "--empirical_background_lowfreq_radius",
        str(args.empirical_background_lowfreq_radius),
    )
    cmd = _append_if_supported(
        cmd,
        supported,
        "--empirical_background_lowfreq_extra_radius",
        str(args.empirical_background_lowfreq_extra_radius),
    )
    cmd = _append_if_supported(
        cmd,
        supported,
        "--empirical_background_highfreq_keep",
        str(args.empirical_background_highfreq_keep),
    )
    cmd += ["--no-save_maps"]
    return cmd


def _add_postprocess_defaults(cmd: list[str], args: argparse.Namespace) -> list[str]:
    return cmd + [
        "--target_strength",
        str(args.target_strength),
        "--target_alpha_dilate",
        "0",
        "--target_alpha_blur",
        "0",
        "--target_alpha_gamma",
        "1.0",
        "--shadow_strength",
        str(args.shadow_strength),
        "--shadow_mode",
        "min_reference",
        "--shadow_search_dilate",
        str(args.shadow_search_dilate),
        "--shadow_target_exclude_dilate",
        "1",
        "--shadow_dark_threshold",
        "0.18",
        "--shadow_ratio_threshold",
        "0.16",
        "--shadow_context_blur",
        "17",
        "--shadow_soft_blur",
        "1",
    ]


def _add_refiner_postprocess_defaults(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    passthrough = [
        ("--postprocess_target_strength", str(args.target_strength)),
        ("--postprocess_target_alpha_dilate", "0"),
        ("--postprocess_target_alpha_blur", "0"),
        ("--postprocess_target_alpha_gamma", "1.0"),
        ("--postprocess_shadow_strength", str(args.shadow_strength)),
        ("--postprocess_shadow_mode", "min_reference"),
        ("--postprocess_shadow_search_dilate", str(args.shadow_search_dilate)),
        ("--postprocess_shadow_target_exclude_dilate", "1"),
        ("--postprocess_shadow_dark_threshold", "0.18"),
        ("--postprocess_shadow_ratio_threshold", "0.16"),
        ("--postprocess_shadow_context_blur", "17"),
        ("--postprocess_shadow_soft_blur", "1"),
        ("--postprocess_save_maps" if bool(args.postprocess_save_maps) else "--no-postprocess_save_maps",),
    ]
    for items in passthrough:
        cmd = _append_if_supported(cmd, supported, *items)
    return cmd


def _add_training_runtime_flags(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    cmd += [
        "--device",
        str(args.device),
    ]
    cmd = _append_if_supported(cmd, supported, "--allow_tf32" if bool(args.allow_tf32) else "--no-allow_tf32")
    cmd = _append_if_supported(
        cmd,
        supported,
        "--cudnn_benchmark" if bool(args.cudnn_benchmark) else "--no-cudnn_benchmark",
    )
    if bool(args.amp):
        cmd = _append_if_supported(cmd, supported, "--amp")
    cmd = _append_if_supported(cmd, supported, "--progress_metrics", str(args.progress_metrics))
    cmd = _append_if_supported(cmd, supported, "--progress_interval", str(args.progress_interval))
    cmd = _append_if_supported(cmd, supported, "--progress_refresh_seconds", str(args.progress_refresh_seconds))
    cmd = _append_if_supported(cmd, supported, "--max_grad_norm", str(args.max_grad_norm))
    return cmd


def _add_target_layover_training_flags(cmd: list[str], args: argparse.Namespace, supported: set[str]) -> list[str]:
    if str(getattr(args, "refiner_mode", "") or "") == "target_layover_clean":
        return _add_clean_layover_flags(cmd, args, supported)

    passthrough = [
        ("--refiner_ablation", str(args.refiner_ablation)),
        ("--focus_azimuths", str(args.focus_azimuths)),
        ("--focus_azimuth_repeat", str(args.focus_azimuth_repeat)),
        ("--focus_azimuth_tolerance", str(args.focus_azimuth_tolerance)),
        ("--mask_dilate", str(args.mask_dilate)),
        ("--full_image_l1_weight", str(args.full_image_l1_weight)),
        ("--target_l1_weight", str(args.target_l1_weight)),
        ("--ssim_loss_weight", str(args.ssim_loss_weight)),
        ("--intensity_mse_weight", str(args.intensity_mse_weight)),
        ("--quantile_loss_weight", str(args.quantile_loss_weight)),
        ("--target_loss_mask_threshold", str(args.target_loss_mask_threshold)),
        ("--target_loss_mask_quantile", str(args.target_loss_mask_quantile)),
        ("--target_loss_mask_dilate", str(args.target_loss_mask_dilate)),
        ("--target_loss_mask_min_pixels", str(args.target_loss_mask_min_pixels)),
        ("--target_compose_mask_dilate", str(args.target_compose_mask_dilate)),
        ("--target_extinction_strength", str(args.target_extinction_strength)),
        ("--target_extinction_floor", str(args.target_extinction_floor)),
        ("--dark_patch_strength", str(args.dark_patch_strength)),
        ("--dark_patch_floor", str(args.dark_patch_floor)),
        ("--target_preserve_strength", str(args.target_preserve_strength)),
        ("--target_preserve_threshold", str(args.target_preserve_threshold)),
        ("--target_preserve_blur_radius", str(args.target_preserve_blur_radius)),
        ("--target_preserve_occlusion_cut", str(args.target_preserve_occlusion_cut)),
        ("--multiplier_min", str(args.multiplier_min)),
        ("--multiplier_max", str(args.multiplier_max)),
        ("--visibility_min", str(args.visibility_min)),
        ("--visibility_max", str(args.visibility_max)),
        ("--layover_spatial_only" if bool(args.layover_spatial_only) else "--no-layover_spatial_only",),
        ("--layover_spatial_baseline", str(args.layover_spatial_baseline)),
        ("--layover_spatial_gain", str(args.layover_spatial_gain)),
        ("--layover_spatial_bias", str(args.layover_spatial_bias)),
        ("--layover_spatial_blur_radius", str(args.layover_spatial_blur_radius)),
        ("--dark_patch_spatial_floor", str(args.dark_patch_spatial_floor)),
        ("--target_extinction_spatial_floor", str(args.target_extinction_spatial_floor)),
        ("--target_extinction_gate_loss_weight", str(args.target_extinction_gate_loss_weight)),
        ("--target_extinction_neighbor_reduce", str(args.target_extinction_neighbor_reduce)),
        ("--target_extinction_dice_loss_weight", str(args.target_extinction_dice_loss_weight)),
        ("--target_extinction_focal_loss_weight", str(args.target_extinction_focal_loss_weight)),
        ("--target_extinction_focal_gamma", str(args.target_extinction_focal_gamma)),
        ("--target_extinction_render_gate_floor", str(args.target_extinction_render_gate_floor)),
        ("--target_extinction_apply_gamma", str(args.target_extinction_apply_gamma)),
        ("--target_extinction_apply_mode", str(args.target_extinction_apply_mode)),
        ("--target_extinction_apply_threshold", str(args.target_extinction_apply_threshold)),
        ("--target_extinction_apply_softness", str(args.target_extinction_apply_softness)),
        ("--target_extinction_apply_sigmoid_mix", str(args.target_extinction_apply_sigmoid_mix)),
        ("--target_extinction_residual_loss_weight", str(args.target_extinction_residual_loss_weight)),
        ("--target_extinction_residual_power", str(args.target_extinction_residual_power)),
        ("--target_extinction_ceiling_loss_weight", str(args.target_extinction_ceiling_loss_weight)),
        ("--target_extinction_ceiling_max_intensity", str(args.target_extinction_ceiling_max_intensity)),
        ("--target_extinction_ceiling_margin", str(args.target_extinction_ceiling_margin)),
        ("--target_extinction_ceiling_context_ratio", str(args.target_extinction_ceiling_context_ratio)),
        ("--target_extinction_ceiling_context_blur", str(args.target_extinction_ceiling_context_blur)),
        ("--target_extinction_ceiling_power", str(args.target_extinction_ceiling_power)),
        ("--target_extinction_positive_gain", str(args.target_extinction_positive_gain)),
        ("--target_extinction_sparsity_weight", str(args.target_extinction_sparsity_weight)),
        ("--target_extinction_target_threshold", str(args.target_extinction_target_threshold)),
        ("--target_extinction_target_high", str(args.target_extinction_target_high)),
        ("--target_extinction_dark_threshold", str(args.target_extinction_dark_threshold)),
        ("--target_extinction_ratio_threshold", str(args.target_extinction_ratio_threshold)),
        ("--target_extinction_context_blur", str(args.target_extinction_context_blur)),
        ("--target_extinction_soft_blur", str(args.target_extinction_soft_blur)),
        ("--target_extinction_gamma", str(args.target_extinction_gamma)),
        ("--target_geometry_loss_weight", str(args.target_geometry_loss_weight)),
        ("--target_geometry_min_visible", str(args.target_geometry_min_visible)),
        ("--rotated_structure_prior_weight", str(args.rotated_structure_prior_weight)),
        ("--rotated_structure_prior_strength", str(args.rotated_structure_prior_strength)),
        ("--rotated_structure_prior_reduce", str(args.rotated_structure_prior_reduce)),
        ("--rotated_structure_prior_angle_sign", str(args.rotated_structure_prior_angle_sign)),
        ("--rotated_structure_prior_max_delta", str(args.rotated_structure_prior_max_delta)),
        ("--rotated_structure_prior_dilate", str(args.rotated_structure_prior_dilate)),
        ("--rotated_structure_prior_blur", str(args.rotated_structure_prior_blur)),
        ("--rotated_structure_prior_padding_mode", str(args.rotated_structure_prior_padding_mode)),
        ("--rotated_structure_prior_gate_loss_weight", str(args.rotated_structure_prior_gate_loss_weight)),
        ("--rotated_structure_prior_dice_loss_weight", str(args.rotated_structure_prior_dice_loss_weight)),
        ("--rotated_structure_prior_positive_gain", str(args.rotated_structure_prior_positive_gain)),
        ("--rotated_structure_prior_residual_loss_weight", str(args.rotated_structure_prior_residual_loss_weight)),
        ("--rotated_structure_prior_residual_power", str(args.rotated_structure_prior_residual_power)),
        ("--rotated_structure_prior_max_intensity", str(args.rotated_structure_prior_max_intensity)),
        ("--rotated_structure_prior_margin", str(args.rotated_structure_prior_margin)),
        ("--rotated_structure_prior_edge_loss_weight", str(args.rotated_structure_prior_edge_loss_weight)),
        ("--rotated_structure_prior_edge_dilate", str(args.rotated_structure_prior_edge_dilate)),
        ("--rotated_structure_prior_local_ratio_weight", str(args.rotated_structure_prior_local_ratio_weight)),
        ("--rotated_structure_prior_local_ratio_pool", str(args.rotated_structure_prior_local_ratio_pool)),
        ("--rotated_structure_prior_dark_threshold", str(args.rotated_structure_prior_dark_threshold)),
        ("--rotated_structure_prior_dark_softness", str(args.rotated_structure_prior_dark_softness)),
        ("--target_speckle_loss_weight", str(args.target_speckle_loss_weight)),
        ("--target_speckle_stat_quantiles", str(args.target_speckle_stat_quantiles)),
        ("--target_speckle_std_quantile_weight", str(args.target_speckle_std_quantile_weight)),
        ("--target_speckle_highfreq_quantile_weight", str(args.target_speckle_highfreq_quantile_weight)),
        ("--target_speckle_intensity_quantile_weight", str(args.target_speckle_intensity_quantile_weight)),
        ("--target_speckle_dark_ratio_weight", str(args.target_speckle_dark_ratio_weight)),
        ("--target_speckle_dark_threshold", str(args.target_speckle_dark_threshold)),
        ("--target_speckle_dark_softness", str(args.target_speckle_dark_softness)),
        ("--multiplier_identity_weight", str(args.multiplier_identity_weight)),
        ("--visibility_identity_weight", str(args.visibility_identity_weight)),
        ("--dark_patch_sparsity_weight", str(args.dark_patch_sparsity_weight)),
        ("--target_shadow_mse_weight", str(args.target_shadow_mse_weight)),
        ("--target_shadow_ssim_loss_weight", str(args.target_shadow_ssim_loss_weight)),
        ("--target_shadow_quantile_loss_weight", str(args.target_shadow_quantile_loss_weight)),
        ("--target_shadow_patchgan_weight", str(args.target_shadow_patchgan_weight)),
        ("--target_occlusion_l1_weight", str(args.target_occlusion_l1_weight)),
        ("--target_occlusion_linear_l1_weight", str(args.target_occlusion_linear_l1_weight)),
        ("--target_occlusion_mse_weight", str(args.target_occlusion_mse_weight)),
        ("--target_occlusion_extinction_weight", str(args.target_occlusion_extinction_weight)),
        ("--target_occlusion_texture_loss_weight", str(args.target_occlusion_texture_loss_weight)),
        ("--target_occlusion_gradient_loss_weight", str(args.target_occlusion_gradient_loss_weight)),
        ("--target_occlusion_quantile_loss_weight", str(args.target_occlusion_quantile_loss_weight)),
        ("--target_occlusion_target_threshold", str(args.target_occlusion_target_threshold)),
        ("--target_occlusion_target_high", str(args.target_occlusion_target_high)),
        ("--target_occlusion_dark_threshold", str(args.target_occlusion_dark_threshold)),
        ("--target_occlusion_ratio_threshold", str(args.target_occlusion_ratio_threshold)),
        ("--target_occlusion_context_blur", str(args.target_occlusion_context_blur)),
        ("--target_occlusion_soft_blur", str(args.target_occlusion_soft_blur)),
        ("--target_occlusion_gamma", str(args.target_occlusion_gamma)),
        ("--target_occlusion_max_intensity", str(args.target_occlusion_max_intensity)),
        ("--target_occlusion_dark_margin", str(args.target_occlusion_dark_margin)),
        ("--target_occlusion_context_ratio", str(args.target_occlusion_context_ratio)),
        ("--train_gt_neighbor_mode", str(args.train_gt_neighbor_mode)),
        ("--train_gt_neighbor_angle_source", str(args.train_gt_neighbor_angle_source)),
        ("--train_gt_neighbor_mix_domain", str(args.train_gt_neighbor_mix_domain)),
        ("--train_gt_neighbor_supervision", str(args.train_gt_neighbor_supervision)),
    ]
    for items in passthrough:
        if len(items) == 1:
            cmd = _append_if_supported(cmd, supported, items[0])
            continue
        option, value = items
        if option == "--focus_azimuths" and not value.strip():
            continue
        if option == "--refiner_ablation" and value.strip().lower() in {"", "none"}:
            continue
        cmd = _append_if_supported(cmd, supported, option, value)
    merge_option = (
        "--rotated_structure_prior_merge_extinction"
        if bool(args.rotated_structure_prior_merge_extinction)
        else "--no-rotated_structure_prior_merge_extinction"
    )
    cmd = _append_if_supported(cmd, supported, merge_option)
    return cmd


def _specified_options(argv: list[str]) -> set[str]:
    """Return canonical --option names that were explicitly set by the user."""
    out = set()
    for item in argv:
        if not item.startswith("--"):
            continue
        opt = item.split("=", 1)[0]
        if opt.startswith("--no-"):
            opt = "--" + opt[5:]
        out.add(opt)
    return out


def _set_if_unset(args: argparse.Namespace, specified: set[str], name: str, value) -> None:
    option = "--" + name.replace("_", "-")
    alt_option = "--" + name
    no_option = "--no-" + name.replace("_", "-")
    no_alt_option = "--no-" + name
    if option in specified or alt_option in specified or no_option in specified or no_alt_option in specified:
        return
    setattr(args, name, value)


def _any_specified(specified: set[str], *names: str) -> bool:
    for name in names:
        option = "--" + name.replace("_", "-")
        alt_option = "--" + name
        if option in specified or alt_option in specified:
            return True
    return False


def _load_dataset_convention_from_candidates(candidates: list[Path]) -> dict | None:
    seen: set[Path] = set()
    for root in candidates:
        if root is None:
            continue
        try:
            root = Path(root).resolve()
        except Exception:
            continue
        if root in seen:
            continue
        seen.add(root)
        paths = [
            root / "adaptive_threshold_visualization" / "dataset_convention_probe.json",
            root / "dataset_convention_probe.json",
        ]
        for path in paths:
            if not path.is_file():
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if isinstance(data, dict):
                data["_path"] = str(path)
                return data
    return None


def _apply_dataset_convention_refiner_defaults(
    args: argparse.Namespace,
    specified: set[str],
    *,
    repo_root: Path,
    model_path: Path,
    train_gt_dir: Path | None,
) -> None:
    candidates: list[Path] = [model_path, model_path.parent]
    if train_gt_dir is not None:
        candidates.extend([train_gt_dir, train_gt_dir.parent])
    candidates.append(repo_root / "data" / model_path.name)
    conv = _load_dataset_convention_from_candidates(candidates)
    if not conv:
        return
    changed: list[str] = []
    offset = conv.get("refiner_shadow_direction_offset_deg")
    if offset is not None and not _any_specified(
        specified,
        "azimuth_shadow_direction_offset_deg",
        "shadow_direction_offset_deg",
    ):
        try:
            args.azimuth_shadow_direction_offset_deg = float(offset)
            args.shadow_direction_offset_deg = float(offset)
            changed.append(f"shadow_direction_offset={float(offset):.1f}")
        except (TypeError, ValueError):
            pass
    sign = conv.get("refiner_shadow_direction_sign")
    if sign is not None and not _any_specified(
        specified,
        "azimuth_shadow_direction_sign",
        "shadow_direction_sign",
    ):
        try:
            s = -1.0 if float(sign) < 0.0 else 1.0
            args.azimuth_shadow_direction_sign = s
            args.shadow_direction_sign = s
            changed.append(f"shadow_direction_sign={s:g}")
        except (TypeError, ValueError):
            pass
    if changed:
        print(
            "[dataset-convention] "
            f"{', '.join(changed)} from {conv.get('_path')} "
            f"(shadow={conv.get('shadow_side')}, rotation={conv.get('rotation_direction')})"
        )


def _apply_sar_structure_stat_preset(args: argparse.Namespace, specified: set[str]) -> None:
    """Prefer the best known target-region baseline over aggressive dark gating."""
    if not bool(getattr(args, "sar_structure_stat_preset", False)):
        return

    # These defaults intentionally match the v14 target-quality baseline.  Later
    # experiments made extinction gating harder, but target SAR-SSIM and edge
    # quality regressed, so the preset now favors the stable target baseline.
    _set_if_unset(args, specified, "target_l1_weight", 0.35)
    _set_if_unset(args, specified, "full_image_l1_weight", 0.0)
    _set_if_unset(args, specified, "ssim_loss_weight", 0.0)
    _set_if_unset(args, specified, "target_ssim_loss_weight", 0.24)
    _set_if_unset(args, specified, "target_mse_weight", 0.0)
    _set_if_unset(args, specified, "intensity_mse_weight", 0.10)

    # Keep bright scatterers as a distribution, not as exact pixels.
    _set_if_unset(args, specified, "bright_loss_weight", 0.42)
    _set_if_unset(args, specified, "texture_loss_weight", 1.65)
    _set_if_unset(args, specified, "gradient_loss_weight", 0.45)
    _set_if_unset(args, specified, "target_speckle_loss_weight", 0.22)
    _set_if_unset(args, specified, "target_speckle_std_quantile_weight", 1.0)
    _set_if_unset(args, specified, "target_speckle_highfreq_quantile_weight", 0.8)
    _set_if_unset(args, specified, "target_speckle_intensity_quantile_weight", 0.55)
    _set_if_unset(args, specified, "target_speckle_dark_ratio_weight", 0.65)
    _set_if_unset(args, specified, "target_speckle_dark_threshold", 0.22)
    _set_if_unset(args, specified, "target_speckle_dark_softness", 0.03)

    # Keep extinction structural, but avoid the v17 over-hard gate that reduced
    # target quality and increased edge error.
    _set_if_unset(args, specified, "target_extinction_gate_loss_weight", 0.80)
    _set_if_unset(args, specified, "target_extinction_dice_loss_weight", 0.55)
    _set_if_unset(args, specified, "target_extinction_focal_loss_weight", 0.30)
    _set_if_unset(args, specified, "target_extinction_residual_loss_weight", 0.45)
    _set_if_unset(args, specified, "target_extinction_ceiling_loss_weight", 0.55)
    _set_if_unset(args, specified, "target_extinction_ceiling_max_intensity", 0.06)
    _set_if_unset(args, specified, "target_extinction_ceiling_margin", 0.008)
    _set_if_unset(args, specified, "target_extinction_ceiling_context_ratio", 0.35)
    _set_if_unset(args, specified, "target_extinction_ceiling_context_blur", 9)
    _set_if_unset(args, specified, "target_extinction_ceiling_power", 2.0)
    _set_if_unset(args, specified, "target_extinction_positive_gain", 3.0)
    _set_if_unset(args, specified, "target_extinction_sparsity_weight", 0.001)
    _set_if_unset(args, specified, "target_extinction_neighbor_reduce", "max")
    _set_if_unset(args, specified, "target_extinction_render_gate_floor", 0.30)
    _set_if_unset(args, specified, "target_extinction_apply_gamma", 0.70)
    _set_if_unset(args, specified, "target_extinction_apply_mode", "power")
    _set_if_unset(args, specified, "target_extinction_apply_threshold", 0.0)
    _set_if_unset(args, specified, "target_extinction_apply_softness", 0.08)
    _set_if_unset(args, specified, "target_extinction_apply_sigmoid_mix", 0.5)
    _set_if_unset(args, specified, "target_extinction_strength", 1.0)
    _set_if_unset(args, specified, "target_extinction_floor", 0.0)
    _set_if_unset(args, specified, "target_extinction_dark_threshold", 0.17)
    _set_if_unset(args, specified, "target_extinction_ratio_threshold", 0.10)
    _set_if_unset(args, specified, "target_geometry_loss_weight", 0.06)
    _set_if_unset(args, specified, "target_geometry_min_visible", 8.0)
    _set_if_unset(args, specified, "rotated_structure_prior_weight", 0.70)
    _set_if_unset(args, specified, "rotated_structure_prior_strength", 0.90)
    _set_if_unset(args, specified, "rotated_structure_prior_reduce", "weighted_max")
    _set_if_unset(args, specified, "rotated_structure_prior_max_delta", 15.0)
    _set_if_unset(args, specified, "rotated_structure_prior_dilate", 0)
    _set_if_unset(args, specified, "rotated_structure_prior_blur", 1)
    _set_if_unset(args, specified, "rotated_structure_prior_merge_extinction", True)
    _set_if_unset(args, specified, "rotated_structure_prior_gate_loss_weight", 0.42)
    _set_if_unset(args, specified, "rotated_structure_prior_dice_loss_weight", 0.28)
    _set_if_unset(args, specified, "rotated_structure_prior_positive_gain", 2.8)
    _set_if_unset(args, specified, "rotated_structure_prior_residual_loss_weight", 0.35)
    _set_if_unset(args, specified, "rotated_structure_prior_max_intensity", 0.055)
    _set_if_unset(args, specified, "rotated_structure_prior_edge_loss_weight", 0.18)
    _set_if_unset(args, specified, "rotated_structure_prior_local_ratio_weight", 0.20)
    _set_if_unset(args, specified, "rotated_structure_prior_dark_threshold", 0.14)

    # Adjacent GTs should support the dark shape without averaging it away.
    _set_if_unset(args, specified, "train_gt_neighbor_mode", "linear")
    _set_if_unset(args, specified, "train_gt_neighbor_angle_source", "target")
    _set_if_unset(args, specified, "train_gt_neighbor_supervision", "mix")
    _set_if_unset(args, specified, "train_gt_neighbor_mix_domain", "log")
    _set_if_unset(args, specified, "target_loss_mask_dilate", 1)
    _set_if_unset(args, specified, "target_compose_mask_dilate", 0)


def _apply_azimuth_shadow_pipeline_defaults(args: argparse.Namespace, specified: set[str]) -> None:
    if not bool(getattr(args, "enable_azimuth_shadow_refiner", False)):
        return

    # Add the azimuth shadow stage on top of the stable clean-layover refiner
    # path.  Avoid switching the base target refiner to nearest-GT image fitting.
    if not _any_specified(specified, "refiner_mode", "target_only_refiner"):
        args.refiner_mode = "target_layover_clean"
        args.target_only_refiner = True

    if str(getattr(args, "refiner_mode", "auto") or "auto") == "target_layover_clean":
        args.target_only_refiner = True
        args.skip_bg_finetune = True
        _set_if_unset(args, specified, "base_lr", 2e-5)
        _set_if_unset(args, specified, "train_use_all_targets", True)
        _set_if_unset(args, specified, "azimuth_shadow_refine_mode", "image")
        _set_if_unset(args, specified, "azimuth_shadow_candidate_mode", "fixed_direction_prior")
        _set_if_unset(args, specified, "azimuth_shadow_apply_mask_source", "target")
        _set_if_unset(args, specified, "azimuth_shadow_train_mask_mode", "gt_background_black")
        _set_if_unset(args, specified, "azimuth_shadow_fail_on_degenerate_train_inputs", False)
        _set_if_unset(args, specified, "azimuth_shadow_shape_prior_mode", "semantic")
        _set_if_unset(args, specified, "azimuth_shadow_shape_prior_weight", 1.0)
        _set_if_unset(args, specified, "azimuth_shadow_shape_prior_threshold", 0.05)
        _set_if_unset(args, specified, "azimuth_shadow_shape_prior_mix_mode", "weighted_mean")
        _set_if_unset(args, specified, "azimuth_shadow_recognition_source", "shape_prior")
        _set_if_unset(args, specified, "azimuth_shadow_image_compose_alpha_threshold", 0.35)
        _set_if_unset(args, specified, "azimuth_shadow_image_compose_alpha_softness", 0.25)
        _set_if_unset(args, specified, "azimuth_shadow_image_compose_alpha_floor", 0.0)
        _set_if_unset(args, specified, "azimuth_shadow_image_compose_alpha_min_support_mean", 0.04)
        _set_if_unset(args, specified, "azimuth_shadow_target_protect_dilate", 2)
        _set_if_unset(args, specified, "azimuth_shadow_target_exclude_dilate", 1)
        _set_if_unset(args, specified, "azimuth_shadow_image_compose_blur", 1)
        _set_if_unset(args, specified, "azimuth_shadow_recognition_threshold", 0.2)
        _set_if_unset(args, specified, "azimuth_shadow_recognition_gate_threshold", 0.2)
        _set_if_unset(args, specified, "azimuth_shadow_apply_feather_blur", 1)
        _set_if_unset(args, specified, "azimuth_shadow_apply_feather_core", 0.80)
        _set_if_unset(args, specified, "azimuth_shadow_apply_recognition_mask", True)
        _set_if_unset(args, specified, "azimuth_shadow_include_target", False)
        _set_if_unset(args, specified, "azimuth_shadow_image_use_joint_mask", False)
        _set_if_unset(args, specified, "azimuth_shadow_joint_mask_bbox_fill", False)
        _set_if_unset(args, specified, "azimuth_shadow_joint_mask_connect_radius", 4)
        _set_if_unset(args, specified, "azimuth_shadow_joint_mask_weight", 0.35)
        _set_if_unset(args, specified, "azimuth_shadow_target_overlap_weight", 0.0)
        _set_if_unset(args, specified, "azimuth_shadow_candidate_supervision_mix", 1.0)
        _set_if_unset(args, specified, "azimuth_shadow_supervision_mode", "mixed")
        _set_if_unset(args, specified, "azimuth_shadow_joint_mask_refiner", False)
        _set_if_unset(args, specified, "azimuth_shadow_gt_component_filter", True)
        _set_if_unset(args, specified, "azimuth_shadow_gt_use_fixed_direction_gate", True)
        _set_if_unset(args, specified, "azimuth_shadow_gt_fixed_direction_fallback", True)
        _set_if_unset(args, specified, "azimuth_shadow_pred_component_filter", False)
        _set_if_unset(args, specified, "azimuth_shadow_pred_component_min_keep_ratio", 0.08)
        _set_if_unset(args, specified, "azimuth_shadow_semantic_dilate", 1)
        _set_if_unset(args, specified, "azimuth_shadow_semantic_blur", 1)
        _set_if_unset(args, specified, "azimuth_shadow_target_mask_mode", "semantic_binary")
        _set_if_unset(args, specified, "azimuth_shadow_target_mask_threshold", 0.02)
        _set_if_unset(args, specified, "azimuth_shadow_train_min_candidate_pixels", 1.0)
        _set_if_unset(args, specified, "azimuth_shadow_geometry_extent_gate", False)
        _set_if_unset(args, specified, "azimuth_shadow_geometry_extent_apply_to_recognition", False)
        _set_if_unset(args, specified, "azimuth_shadow_geometry_extent_require_dataset_direction", False)
        _set_if_unset(args, specified, "azimuth_shadow_learned_intensity_prior", True)
        _set_if_unset(args, specified, "azimuth_shadow_intensity_strength", 1.22)
        _set_if_unset(args, specified, "azimuth_shadow_intensity_min_attenuation", 0.38)
        _set_if_unset(args, specified, "azimuth_shadow_intensity_max_attenuation", 0.93)
        _set_if_unset(args, specified, "azimuth_shadow_intensity_gamma", 0.80)
        _set_if_unset(args, specified, "azimuth_shadow_intensity_context_radius", 13)
        _set_if_unset(args, specified, "azimuth_shadow_intensity_block_radius", 7)
        _set_if_unset(args, specified, "azimuth_shadow_intensity_exclude_dilate", 2)
        _set_if_unset(args, specified, "background_after_shadow", True)
        _set_if_unset(args, specified, "background_after_shadow_shadow_alpha_source", "compose_alpha")
        _set_if_unset(args, specified, "background_after_shadow_target_mask_dilate", 1)
        _set_if_unset(args, specified, "background_after_shadow_blend_dilate", 0)
        _set_if_unset(args, specified, "background_after_shadow_target_mask_blur", 1)
        _set_if_unset(args, specified, "background_after_shadow_target_gap_dark_threshold", 0.012)
        _set_if_unset(args, specified, "background_after_shadow_target_gap_edge_px", 2)
        _set_if_unset(args, specified, "background_after_shadow_target_gap_shadow_protect_threshold", 0.02)
        _set_if_unset(args, specified, "background_after_shadow_union_mask_dilate", 1)
        _set_if_unset(args, specified, "background_after_shadow_union_mask_blur", 6)
        _set_if_unset(args, specified, "background_after_shadow_strength", 1.0)
        _set_if_unset(args, specified, "background_after_shadow_hard_target_copy", False)
        _set_if_unset(args, specified, "background_after_shadow_hard_shadow_copy", False)
        _set_if_unset(args, specified, "background_after_shadow_reference_clean_blend_refs", 4)
        _set_if_unset(args, specified, "background_after_shadow_reference_clean_blend_mix", 0.45)
        _set_if_unset(args, specified, "background_after_shadow_reference_clean_angle_sigma", 12.0)
        _set_if_unset(args, specified, "background_after_shadow_reference_clean_patch_mix", 0.20)


def _apply_historical_shadow_rollback(args: argparse.Namespace, specified: set[str]) -> None:
    """Disable the experimental constant-carrier/final-background shadow path.

    The 20260611_155223 run used background_then_target_shadow before the
    azimuth-shadow refiner.  The later carrier-background experiment can hide
    the real background and broaden the shadow alpha enough to damage target
    SSIM, so keep it inert unless this function is removed intentionally.
    """
    if (
        str(getattr(args, "shadow_carrier_background", "none") or "none").lower().strip() != "none"
        and not _any_specified(specified, "shadow_carrier_background")
    ):
        print("[rollback] disabling experimental --shadow_carrier_background; using original render/background as shadow input")
        args.shadow_carrier_background = "none"


def _normalize_refiner_mode(args: argparse.Namespace, specified: set[str]) -> None:
    mode = str(getattr(args, "refiner_mode", "auto") or "auto").lower().strip()
    aliases = {
        "modulation": "target_modulation",
        "target": "target_modulation",
        "layover": "target_layover",
        "target-layover": "target_layover",
        "clean_layover": "target_layover_clean",
        "target-clean-layover": "target_layover_clean",
        "target_layover_v2": "target_layover_clean",
        "direct": "image",
        "full": "image",
    }
    mode = aliases.get(mode, mode)
    if mode == "auto":
        mode = "target_modulation" if bool(getattr(args, "target_only_refiner", False)) else "image"
    if mode in {"target_layover", "target_layover_clean"}:
        args.target_only_refiner = True
    args.refiner_mode = mode


def _apply_target_layover_pipeline_defaults(args: argparse.Namespace, specified: set[str]) -> None:
    if str(getattr(args, "refiner_mode", "image") or "image") not in {"target_layover", "target_layover_clean"}:
        return

    args.target_only_refiner = True
    args.skip_bg_finetune = True
    _set_if_unset(args, specified, "target_only_compose_context", False)
    _set_if_unset(args, specified, "train_gt_neighbor_mode", "linear")
    _set_if_unset(args, specified, "train_gt_neighbor_angle_source", "target")
    _set_if_unset(args, specified, "train_gt_neighbor_supervision", "mix")
    _set_if_unset(args, specified, "train_gt_neighbor_mix_domain", "log")

    _set_if_unset(args, specified, "target_preserve_strength", 0.0)
    if "--layer_target_use_preserve" not in specified and "--no-layer_target_use_preserve" not in specified:
        args.layer_target_use_preserve = False
    if "--postprocess_after_apply" not in specified and "--no-postprocess_after_apply" not in specified:
        args.final_postprocess = False
    if str(getattr(args, "refiner_mode", "image") or "image") == "target_layover_clean":
        if bool(getattr(args, "background_after_shadow", False)):
            _set_if_unset(args, specified, "target_only_compose_context", False)
        else:
            _set_if_unset(args, specified, "target_only_compose_context", True)
        _set_if_unset(args, specified, "shadow_restore_strength", 0.42)
        _set_if_unset(args, specified, "empirical_background_strength", 0.72)
        _set_if_unset(args, specified, "empirical_background_mode", "patch")
        _set_if_unset(args, specified, "empirical_background_patch_smooth", 1)
        _set_if_unset(args, specified, "empirical_background_patch_smooth_mix", 0.30)
        _set_if_unset(args, specified, "empirical_background_reference_exclude_dilate", 24)
        _set_if_unset(args, specified, "shadow_restore_target_protect_dilate", 1)
        _set_if_unset(args, specified, "shadow_restore_target_dilate", 40)
        _set_if_unset(args, specified, "shadow_restore_mode", "darken")
        _set_if_unset(args, specified, "shadow_restore_max_darken", 0.90)
        _set_if_unset(args, specified, "shadow_restore_reference_blur", 4)
        _set_if_unset(args, specified, "shadow_restore_blur", 4)
        _set_if_unset(args, specified, "shadow_geometry", "hybrid")
        _set_if_unset(args, specified, "shadow_reference_min_evidence", 0.05)
        _set_if_unset(args, specified, "shadow_reference_floor", 0.25)
        _set_if_unset(args, specified, "shadow_contact_width", 6)
        _set_if_unset(args, specified, "shadow_contact_strength", 0.25)
        _set_if_unset(args, specified, "shadow_connected_decay", 24.0)
        _set_if_unset(args, specified, "shadow_connected_blur", 2)
        _set_if_unset(args, specified, "shadow_directional_strength", 0.55)
        _set_if_unset(args, specified, "shadow_directional_length", 42)
        _set_if_unset(args, specified, "shadow_directional_lateral_blur", 5)
        _set_if_unset(args, specified, "layer_target_blur", 1)
        _set_if_unset(args, specified, "layer_target_mask_floor", 0.35)
        _set_if_unset(args, specified, "layer_target_contact_width", 2)
        _set_if_unset(args, specified, "layer_target_contact_strength", 0.45)
        _set_if_unset(args, specified, "layer_target_contact_blur", 1)
    else:
        _set_if_unset(args, specified, "shadow_restore_strength", 0.0)
        _set_if_unset(args, specified, "empirical_background_strength", 0.0)

    _set_if_unset(args, specified, "multiplier_min", 0.55)
    _set_if_unset(args, specified, "multiplier_max", 1.20)
    _set_if_unset(args, specified, "visibility_min", 0.28)
    _set_if_unset(args, specified, "visibility_max", 1.0)
    _set_if_unset(args, specified, "dark_patch_strength", 0.40)
    _set_if_unset(args, specified, "dark_patch_floor", 0.0)
    _set_if_unset(args, specified, "target_extinction_strength", 0.60)
    _set_if_unset(args, specified, "target_extinction_floor", 0.0)
    _set_if_unset(args, specified, "target_extinction_apply_gamma", 0.85)
    _set_if_unset(args, specified, "target_extinction_apply_mode", "power")
    _set_if_unset(args, specified, "target_extinction_apply_threshold", 0.0)
    _set_if_unset(args, specified, "target_extinction_apply_softness", 0.08)
    _set_if_unset(args, specified, "target_extinction_apply_sigmoid_mix", 0.35)
    _set_if_unset(args, specified, "layover_spatial_only", True)
    _set_if_unset(args, specified, "layover_spatial_baseline", "masked_mean")
    _set_if_unset(args, specified, "layover_spatial_gain", 4.0)
    _set_if_unset(args, specified, "layover_spatial_bias", 0.0)
    _set_if_unset(args, specified, "layover_spatial_blur_radius", 9)
    _set_if_unset(args, specified, "dark_patch_spatial_floor", 0.0)
    _set_if_unset(args, specified, "target_extinction_spatial_floor", 0.0)

    _set_if_unset(args, specified, "target_l1_weight", 0.55)
    _set_if_unset(args, specified, "target_ssim_loss_weight", 0.18)
    _set_if_unset(args, specified, "intensity_mse_weight", 0.10)
    _set_if_unset(args, specified, "quantile_loss_weight", 0.20)
    _set_if_unset(args, specified, "texture_loss_weight", 0.45)
    _set_if_unset(args, specified, "gradient_loss_weight", 0.30)
    _set_if_unset(args, specified, "full_image_l1_weight", 0.0)
    _set_if_unset(args, specified, "ssim_loss_weight", 0.0)
    _set_if_unset(args, specified, "bright_loss_weight", 0.30)
    _set_if_unset(args, specified, "bright_loss_gain", 5.0)

    _set_if_unset(args, specified, "target_extinction_gate_loss_weight", 0.22)
    _set_if_unset(args, specified, "target_extinction_dice_loss_weight", 0.14)
    _set_if_unset(args, specified, "target_extinction_focal_loss_weight", 0.08)
    _set_if_unset(args, specified, "target_extinction_residual_loss_weight", 0.08)
    _set_if_unset(args, specified, "target_extinction_ceiling_loss_weight", 0.0)
    _set_if_unset(args, specified, "target_extinction_positive_gain", 2.0)
    _set_if_unset(args, specified, "target_extinction_sparsity_weight", 0.008)
    _set_if_unset(args, specified, "target_extinction_neighbor_reduce", "weighted_max")
    _set_if_unset(args, specified, "target_extinction_render_gate_floor", 0.32)
    _set_if_unset(args, specified, "target_occlusion_l1_weight", 0.05)
    _set_if_unset(args, specified, "target_occlusion_extinction_weight", 0.08)
    _set_if_unset(args, specified, "target_occlusion_texture_loss_weight", 0.02)
    _set_if_unset(args, specified, "target_occlusion_gradient_loss_weight", 0.02)
    _set_if_unset(args, specified, "target_speckle_loss_weight", 0.10)
    _set_if_unset(args, specified, "target_speckle_std_quantile_weight", 0.9)
    _set_if_unset(args, specified, "target_speckle_highfreq_quantile_weight", 0.7)
    _set_if_unset(args, specified, "target_speckle_intensity_quantile_weight", 0.45)
    _set_if_unset(args, specified, "target_speckle_dark_ratio_weight", 0.30)
    _set_if_unset(args, specified, "target_geometry_loss_weight", 0.03)

    _set_if_unset(args, specified, "multiplier_identity_weight", 0.020)
    _set_if_unset(args, specified, "visibility_identity_weight", 0.012)
    _set_if_unset(args, specified, "dark_patch_sparsity_weight", 0.010)
    _set_if_unset(args, specified, "rotated_structure_prior_weight", 0.0)
    _set_if_unset(args, specified, "save_maps", True)

    if str(getattr(args, "refiner_mode", "image") or "image") == "target_layover_clean":
        _set_if_unset(args, specified, "target_l1_weight", 0.55)
        _set_if_unset(args, specified, "texture_loss_weight", 0.45)
        _set_if_unset(args, specified, "gradient_loss_weight", 0.30)
        _set_if_unset(args, specified, "quantile_loss_weight", 0.20)
        _set_if_unset(args, specified, "dark_supervision_blur", 1)
        _set_if_unset(args, specified, "content_loss_use_dark_gt_support", False)
        _set_if_unset(args, specified, "content_gt_support_threshold", 0.015)
        _set_if_unset(args, specified, "content_gt_support_dilate", 1)
        _set_if_unset(args, specified, "content_gt_support_blur", 0)
        _set_if_unset(args, specified, "extinction_target_reference", "min_mix")
        _set_if_unset(args, specified, "extinction_target_gamma", 1.0)
        _set_if_unset(args, specified, "extinction_target_blur", 0)
        _set_if_unset(args, specified, "extinction_regression_weight", 0.0)
        _set_if_unset(args, specified, "extinction_structure_weight", 0.0)
        _set_if_unset(args, specified, "bright_profile_loss_weight", 0.0)
        _set_if_unset(args, specified, "bright_profile_core_quantile", 0.82)
        _set_if_unset(args, specified, "bright_profile_core_threshold", 0.12)
        _set_if_unset(args, specified, "bright_profile_core_dilate", 1)
        _set_if_unset(args, specified, "bright_profile_radius", 14)
        _set_if_unset(args, specified, "bright_profile_decay", 3.5)
        _set_if_unset(args, specified, "bright_profile_floor_log", 0.025)
        _set_if_unset(args, specified, "bright_profile_near_log", 0.24)
        _set_if_unset(args, specified, "bright_profile_distance_power", 1.5)
        _set_if_unset(args, specified, "boundary_suppression_weight", 0.0)
        _set_if_unset(args, specified, "boundary_ring_width", 2)
        _set_if_unset(args, specified, "boundary_far_distance", 0.35)
        _set_if_unset(args, specified, "boundary_ceiling_log", 0.04)
        _set_if_unset(args, specified, "extinction_compose_alpha_weight", 0.0)
        _set_if_unset(args, specified, "extinction_compose_alpha_gamma", 1.0)


def _apply_refiner_ablation_pipeline_defaults(args: argparse.Namespace, specified: set[str]) -> None:
    mode = str(getattr(args, "refiner_ablation", "none") or "none").lower().strip()
    if mode in {"", "none"}:
        return

    args.target_only_refiner = True
    args.skip_bg_finetune = True

    def setv(name: str, value) -> None:
        setattr(args, name, value)

    if mode == "no_spatial_gate":
        setv("layover_spatial_only", False)
        setv("dark_patch_spatial_floor", 0.0)
        setv("target_extinction_spatial_floor", 0.0)
        print("[refiner ablation] no_spatial_gate: disabled spatial-only dark/extinction gate.")
        return

    if mode == "wide_maps":
        setv("multiplier_min", 0.35)
        setv("multiplier_max", 1.85)
        setv("visibility_min", 0.12)
        setv("visibility_max", 1.0)
        setv("dark_patch_strength", 0.85)
        setv("target_extinction_strength", 1.0)
        print("[refiner ablation] wide_maps: restored v11-style modulation ranges.")
        return

    if mode == "no_extinction_losses":
        for name in (
            "target_extinction_gate_loss_weight",
            "target_extinction_dice_loss_weight",
            "target_extinction_focal_loss_weight",
            "target_extinction_residual_loss_weight",
            "target_extinction_ceiling_loss_weight",
            "target_occlusion_extinction_weight",
        ):
            setv(name, 0.0)
        print("[refiner ablation] no_extinction_losses: disabled explicit extinction/occlusion gate losses.")
        return

    if mode == "nearest_gt":
        setv("train_gt_neighbor_mode", "nearest")
        setv("train_gt_neighbor_supervision", "sample")
        setv("train_gt_neighbor_mix_domain", "pixel")
        setv("target_extinction_neighbor_reduce", "max")
        print("[refiner ablation] nearest_gt: using old nearest/sample GT supervision.")
        return

    if mode == "old_structure_stat":
        # Recreate the older v11 structure/stat behavior as closely as possible:
        # target_modulation, no spatial-only gate, wide modulation maps, strong
        # extinction supervision, and statistical target losses.
        setv("refiner_mode", "target_modulation")
        setv("layover_spatial_only", False)
        setv("multiplier_min", 0.35)
        setv("multiplier_max", 1.85)
        setv("visibility_min", 0.12)
        setv("visibility_max", 1.0)
        setv("dark_patch_strength", 0.85)
        setv("dark_patch_floor", 0.02)
        setv("dark_patch_sparsity_weight", 0.006)
        setv("target_extinction_strength", 1.0)
        setv("target_extinction_apply_gamma", 0.70)
        setv("target_extinction_gate_loss_weight", 0.80)
        setv("target_extinction_dice_loss_weight", 0.55)
        setv("target_extinction_focal_loss_weight", 0.30)
        setv("target_extinction_residual_loss_weight", 0.45)
        setv("target_extinction_ceiling_loss_weight", 0.0)
        setv("target_extinction_positive_gain", 3.0)
        setv("target_extinction_sparsity_weight", 0.001)
        setv("target_extinction_neighbor_reduce", "max")
        setv("target_extinction_render_gate_floor", 0.30)
        setv("target_extinction_dark_threshold", 0.17)
        setv("target_extinction_ratio_threshold", 0.10)
        setv("target_l1_weight", 0.35)
        setv("target_ssim_loss_weight", 0.24)
        setv("bright_loss_weight", 0.42)
        setv("bright_loss_gain", 7.0)
        setv("quantile_loss_weight", 0.45)
        setv("texture_loss_weight", 1.65)
        setv("gradient_loss_weight", 0.45)
        setv("target_speckle_loss_weight", 0.22)
        setv("target_speckle_std_quantile_weight", 1.0)
        setv("target_speckle_highfreq_quantile_weight", 0.8)
        setv("target_speckle_intensity_quantile_weight", 0.55)
        setv("target_speckle_dark_ratio_weight", 0.65)
        setv("target_speckle_dark_threshold", 0.22)
        setv("target_speckle_dark_softness", 0.03)
        setv("target_geometry_loss_weight", 0.0)
        setv("rotated_structure_prior_weight", 0.0)
        for name in (
            "target_occlusion_l1_weight",
            "target_occlusion_linear_l1_weight",
            "target_occlusion_mse_weight",
            "target_occlusion_extinction_weight",
            "target_occlusion_texture_loss_weight",
            "target_occlusion_gradient_loss_weight",
            "target_occlusion_quantile_loss_weight",
        ):
            setv(name, 0.0)
        print("[refiner ablation] old_structure_stat: using v11-style target_modulation structure/stat settings.")
        return

    raise ValueError(f"Unknown --refiner_ablation: {mode}")


def _warn_ablation_workdir_mismatch(work_dir: Path, args: argparse.Namespace) -> None:
    ablation = str(getattr(args, "refiner_ablation", "none") or "none").lower().strip()
    if ablation in {"", "none"}:
        return
    name = work_dir.name.lower()
    known = {
        "no_spatial_gate",
        "wide_maps",
        "no_extinction_losses",
        "nearest_gt",
        "old_structure_stat",
    }
    mentioned = [item for item in known if item in name]
    if mentioned and ablation not in mentioned:
        print(
            "[refiner ablation] warning: work_dir name suggests "
            f"{mentioned}, but --refiner_ablation is {ablation}. "
            "The CLI flag controls the actual run."
        )


def _apply_target_only_pipeline_defaults(args: argparse.Namespace, specified: set[str] | None = None) -> None:
    if not bool(getattr(args, "target_only_refiner", False)):
        return
    specified = specified or set()
    args.skip_bg_finetune = True
    _set_if_unset(args, specified, "mask_dilate", 1)
    _set_if_unset(args, specified, "loss_mask_dilate", 0)
    _set_if_unset(args, specified, "target_loss_mask_dilate", 1)
    _set_if_unset(args, specified, "target_compose_mask_dilate", 0)
    args.target_ring_width = 0
    args.target_ring_l1_weight = 0.0
    args.target_ring_texture_loss_weight = 0.0
    args.target_ring_gradient_loss_weight = 0.0
    args.target_ring_quantile_loss_weight = 0.0
    args.target_ring_patchgan_weight = 0.0

    shadow_loss_names = (
        "target_shadow_l1_weight",
        "target_shadow_linear_l1_weight",
        "target_shadow_mse_weight",
        "target_shadow_extinction_weight",
        "target_shadow_texture_loss_weight",
        "target_shadow_gradient_loss_weight",
        "target_shadow_ssim_loss_weight",
        "target_shadow_quantile_loss_weight",
        "target_shadow_patchgan_weight",
    )
    if _any_specified(specified, *shadow_loss_names):
        _set_if_unset(args, specified, "target_shadow_width", 18)
    else:
        args.target_shadow_width = 0
        for name in shadow_loss_names:
            setattr(args, name, 0.0)

    occlusion_loss_names = (
        "target_occlusion_l1_weight",
        "target_occlusion_linear_l1_weight",
        "target_occlusion_mse_weight",
        "target_occlusion_extinction_weight",
        "target_occlusion_texture_loss_weight",
        "target_occlusion_gradient_loss_weight",
        "target_occlusion_quantile_loss_weight",
    )
    if not _any_specified(specified, *occlusion_loss_names):
        for name in occlusion_loss_names:
            setattr(args, name, 0.0)

    args.background_patchgan_weight = 0.0
    _set_if_unset(args, specified, "target_preserve_strength", 0.0)
    if "--layer_target_use_preserve" not in specified and "--no-layer_target_use_preserve" not in specified:
        args.layer_target_use_preserve = False
    if bool(getattr(args, "target_only_compose_context", False)):
        if "--empirical_background_strength" not in specified and float(args.empirical_background_strength) >= 1.0:
            args.empirical_background_strength = 0.62
        args.empirical_background_mode = "patch"
        if "--empirical_background_patch_smooth" not in specified:
            args.empirical_background_patch_smooth = 1
        if "--empirical_background_patch_smooth_mix" not in specified:
            args.empirical_background_patch_smooth_mix = 0.30
        if "--empirical_background_patch_fallback_weight" not in specified:
            args.empirical_background_patch_fallback_weight = 1.0
    else:
        if bool(getattr(args, "background_after_shadow", False)):
            _set_if_unset(args, specified, "empirical_background_strength", 0.72)
        else:
            args.empirical_background_strength = 0.0
    _set_if_unset(args, specified, "shadow_restore_strength", 0.0)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="SAR refiner pipeline: train base -> bg finetune -> apply -> optional postprocess/eval.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--repo_root", type=Path, default=None)
    parser.add_argument("--python", type=str, default=sys.executable)
    parser.add_argument(
        "--stage",
        choices=[
            "full_train",
            "train_base",
            "finetune_bg",
            "apply",
            "train_shadow",
            "apply_shadow",
            "postprocess",
            "eval",
            "apply_eval",
        ],
        default="full_train",
        help="full_train runs base training, background finetune, final apply, and optional eval.",
    )
    parser.add_argument("--dry_run", action="store_true")
    parser.add_argument(
        "--keep_intermediate_apply",
        action="store_true",
        default=False,
        help="Also apply/postprocess after base and background training. Disabled by default to avoid weak/repeated stages.",
    )
    parser.add_argument(
        "--final_postprocess",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Run the final local target/shadow postprocess after apply. Disabled by default because it is usually nearly identical.",
    )
    parser.add_argument(
        "--postprocess_after_apply",
        dest="final_postprocess",
        action=argparse.BooleanOptionalAction,
        default=argparse.SUPPRESS,
        help="Alias for --final_postprocess/--no-final_postprocess, accepted for refiner CLI compatibility.",
    )
    parser.add_argument(
        "--skip_bg_finetune",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Skip background fine-tuning and apply the base refiner checkpoint directly.",
    )
    parser.add_argument(
        "--target_only_refiner",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Train/apply the target-layover modulation path. Background/ring/PatchGAN losses "
            "are disabled by default; target shadow/occlusion losses are opt-in via explicit weights."
        ),
    )
    parser.add_argument(
        "--refiner_mode",
        choices=[
            "auto",
            "image",
            "residual",
            "target_modulation",
            "target_layover",
            "modulation",
            "target",
            "layover",
            "target-layover",
            "target_layover_clean",
            "clean_layover",
            "target_layover_v2",
            "direct",
            "full",
        ],
        default="target_layover_clean",
        help=(
            "auto keeps existing behavior. target_layover keeps the legacy modulation path. "
            "target_layover_clean uses the rebuilt target-only log-domain layover refiner."
        ),
    )
    parser.add_argument(
        "--target_only_compose_context",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="For target-only apply, synthesize empirical background around the refiner-modulated target layer.",
    )
    parser.add_argument(
        "--sar_structure_stat_preset",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Use a robust SAR target preset: reduce pixel/SSIM averaging and emphasize "
            "extinction structure plus speckle/statistical losses. Explicit CLI weights still win."
        ),
    )
    parser.add_argument(
        "--refiner_ablation",
        choices=[
            "none",
            "no_spatial_gate",
            "wide_maps",
            "no_extinction_losses",
            "nearest_gt",
            "old_structure_stat",
        ],
        default="none",
        help=(
            "One-change-at-a-time debug preset for refiner regression checks. "
            "old_structure_stat restores the v11-style target_modulation structure/stat setup."
        ),
    )

    parser.add_argument("-m", "--model_path", type=Path, default=Path("output/360-2-target-nofilm-5000"))
    parser.add_argument("--work_dir", type=Path, default=None)
    parser.add_argument(
        "--record_results",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Record each run's effective parameters, commands, paths, and metric artifacts under <model_path>/result.",
    )
    parser.add_argument(
        "--result_dir",
        type=Path,
        default=None,
        help="Override the run archive directory. Defaults to <model_path>/result.",
    )

    parser.add_argument("--base_checkpoint", type=Path, default=None)
    parser.add_argument("--bg_checkpoint", type=Path, default=None)
    parser.add_argument("--checkpoint", type=Path, default=None, help="Checkpoint used by apply/apply_eval.")

    parser.add_argument("--base_output", type=Path, default=None)
    parser.add_argument("--base_post_output", type=Path, default=None)
    parser.add_argument("--bg_output", type=Path, default=None)
    parser.add_argument("--bg_post_output", type=Path, default=None)
    parser.add_argument("--apply_output", type=Path, default=None)
    parser.add_argument("--final_render_dir", type=Path, default=None)

    parser.add_argument("--target_mask_dir", type=Path, default=None)
    parser.add_argument("--gt_dir", type=Path, default=None)
    parser.add_argument("--train_target_dir", type=Path, default=None)
    parser.add_argument("--train_gt_dir", type=Path, default=None)
    parser.add_argument("--dark_gt_dir", type=Path, default=None)
    parser.add_argument("--eval_output", type=Path, default=None)
    parser.add_argument(
        "--export_classification_labels",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="After final apply, export target masks and class labels for downstream classification.",
    )
    parser.add_argument(
        "--classification_label_output_dir",
        type=Path,
        default=None,
        help="Output root for exported target masks/labels. Defaults to the pipeline work_dir.",
    )
    parser.add_argument(
        "--classification_root",
        type=Path,
        default=None,
        help="Classification repo root used for relative CSV paths.",
    )
    parser.add_argument("--classification_source", type=str, default="extra")
    parser.add_argument("--background_filtered_eval", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--background_filtered_eval_gt_dir", type=Path, default=None)
    parser.add_argument("--background_filtered_eval_output_dir", type=Path, default=None)
    parser.add_argument("--background_filtered_eval_percentile", type=float, default=90.0)
    parser.add_argument("--azimuth_match_tolerance", type=int, default=0)
    parser.add_argument(
        "--sar_tolerant_radius",
        type=int,
        default=1,
        help="Pixel tolerance used by SAR_TOL_* metrics. 1 is the default tolerant SAR novel-view evaluation.",
    )
    parser.add_argument(
        "--intermediate_debug_eval",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Evaluate source/refiner/pre-shadow/shadow/final stages and save visual diagnosis panels.",
    )
    parser.add_argument(
        "--target_shadow_eval",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Evaluate the combined target+shadow region in addition to target-only and global metrics.",
    )
    parser.add_argument(
        "--visual_diagnosis",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Save target visual diagnosis panels during metric evaluation.",
    )
    parser.add_argument(
        "--refiner_delta_eval",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Compare source/refiner/final target deltas against GT and save diagnostic panels.",
    )
    parser.add_argument(
        "--record_debug_artifacts",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Copy intermediate renders, maps, panels, and metric files into the run archive.",
    )
    parser.add_argument(
        "--postprocess_save_maps",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Save postprocess map outputs during refiner postprocess.",
    )

    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--amp", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--allow_tf32", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--cudnn_benchmark", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument(
        "--progress_metrics",
        choices=["compact", "full", "none"],
        default="compact",
        help="Refiner training progress postfix verbosity. compact avoids long tqdm lines on Windows terminals.",
    )
    parser.add_argument("--progress_interval", type=int, default=20)
    parser.add_argument("--progress_refresh_seconds", type=float, default=0.5)
    parser.add_argument(
        "--max_grad_norm",
        type=float,
        default=1.0,
        help="Clip refiner gradients; prevents NaN checkpoints in aggressive layover training.",
    )
    parser.add_argument("--view_split_train_angle_step", type=int, default=0)
    parser.add_argument("--view_split_train_angles", type=str, default=None)
    parser.add_argument("--view_split_train_dir", type=Path, default=None)

    parser.add_argument("--base_iterations", type=int, default=5000)
    parser.add_argument("--bg_iterations", type=int, default=3000)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--azimuth_harmonics", type=int, default=5)
    parser.add_argument("--base_lr", type=float, default=2e-5)
    parser.add_argument("--bg_lr", type=float, default=3e-5)
    parser.add_argument("--train_azimuth_step", type=float, default=10.0)
    parser.add_argument("--train_azimuth_unique", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--train_use_all_targets", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--train_gt_neighbor_mode", choices=["nearest", "linear"], default="nearest")
    parser.add_argument("--train_gt_neighbor_angle_source", choices=["target", "slot"], default="target")
    parser.add_argument("--train_gt_neighbor_mix_domain", choices=["pixel", "log"], default="pixel")
    parser.add_argument("--train_gt_neighbor_supervision", choices=["sample", "mix"], default="sample")
    parser.add_argument("--focus_azimuths", type=str, default="")
    parser.add_argument("--focus_azimuth_repeat", type=int, default=1)
    parser.add_argument("--focus_azimuth_tolerance", type=float, default=2.5)
    parser.add_argument("--target_l1_weight", type=float, default=0.55)
    parser.add_argument("--log_mse_weight", type=float, default=0.3)
    parser.add_argument("--sar_ssim_loss_weight", type=float, default=0.12)
    parser.add_argument("--sar_ssim_loss_window", type=int, default=7)
    parser.add_argument("--dark_patch_strength", type=float, default=0.85)
    parser.add_argument("--dark_patch_floor", type=float, default=0.02)
    parser.add_argument("--target_extinction_strength", type=float, default=1.0)
    parser.add_argument("--target_extinction_floor", type=float, default=0.0)
    parser.add_argument("--target_extinction_gate_loss_weight", type=float, default=0.65)
    parser.add_argument("--target_extinction_neighbor_reduce", choices=["max", "weighted_max", "weighted_mean", "mix"], default="max")
    parser.add_argument("--target_extinction_dice_loss_weight", type=float, default=0.45)
    parser.add_argument("--target_extinction_focal_loss_weight", type=float, default=0.25)
    parser.add_argument("--target_extinction_focal_gamma", type=float, default=2.0)
    parser.add_argument("--target_extinction_render_gate_floor", type=float, default=0.35)
    parser.add_argument("--target_extinction_apply_gamma", type=float, default=0.70)
    parser.add_argument("--target_extinction_apply_mode", choices=["power", "sigmoid", "threshold", "power_sigmoid", "sigmoid_power"], default="power")
    parser.add_argument("--target_extinction_apply_threshold", type=float, default=0.0)
    parser.add_argument("--target_extinction_apply_softness", type=float, default=0.08)
    parser.add_argument("--target_extinction_apply_sigmoid_mix", type=float, default=0.5)
    parser.add_argument("--target_extinction_residual_loss_weight", type=float, default=0.35)
    parser.add_argument("--target_extinction_residual_power", type=float, default=2.0)
    parser.add_argument("--target_extinction_ceiling_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_extinction_ceiling_max_intensity", type=float, default=0.07)
    parser.add_argument("--target_extinction_ceiling_margin", type=float, default=0.01)
    parser.add_argument("--target_extinction_ceiling_context_ratio", type=float, default=0.40)
    parser.add_argument("--target_extinction_ceiling_context_blur", type=int, default=9)
    parser.add_argument("--target_extinction_ceiling_power", type=float, default=2.0)
    parser.add_argument("--target_extinction_positive_gain", type=float, default=2.0)
    parser.add_argument("--target_extinction_sparsity_weight", type=float, default=0.002)
    parser.add_argument("--target_extinction_target_threshold", type=float, default=0.08)
    parser.add_argument("--target_extinction_target_high", type=float, default=0.28)
    parser.add_argument("--target_extinction_dark_threshold", type=float, default=0.16)
    parser.add_argument("--target_extinction_ratio_threshold", type=float, default=0.12)
    parser.add_argument("--target_extinction_context_blur", type=int, default=9)
    parser.add_argument("--target_extinction_soft_blur", type=int, default=1)
    parser.add_argument("--target_extinction_gamma", type=float, default=1.0)
    parser.add_argument("--delta_log_scale", type=float, default=0.35)
    parser.add_argument("--bright_log_scale", type=float, default=0.18)
    parser.add_argument("--extinction_log_strength", type=float, default=0.55)
    parser.add_argument("--dark_src_threshold", type=float, default=0.16)
    parser.add_argument("--dark_gap_threshold", type=float, default=0.12)
    parser.add_argument("--dark_gap_softness", type=float, default=0.18)
    parser.add_argument("--dark_supervision_blur", type=int, default=1)
    parser.add_argument("--content_loss_use_dark_gt_support", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--content_gt_support_threshold", type=float, default=0.015)
    parser.add_argument("--content_gt_support_dilate", type=int, default=1)
    parser.add_argument("--content_gt_support_blur", type=int, default=0)
    parser.add_argument("--extinction_target_reference", choices=["min_mix", "mix", "dark"], default="min_mix")
    parser.add_argument("--extinction_target_gamma", type=float, default=1.0)
    parser.add_argument("--extinction_target_margin", type=float, default=0.0)
    parser.add_argument("--extinction_target_blur", type=int, default=0)
    parser.add_argument("--dark_ceiling_weight", type=float, default=1.6)
    parser.add_argument("--dark_mse_weight", type=float, default=0.25)
    parser.add_argument("--extinction_bce_weight", type=float, default=0.9)
    parser.add_argument("--extinction_regression_weight", type=float, default=0.0)
    parser.add_argument("--extinction_structure_weight", type=float, default=0.0)
    parser.add_argument("--bright_profile_loss_weight", type=float, default=0.0)
    parser.add_argument("--bright_profile_core_quantile", type=float, default=0.82)
    parser.add_argument("--bright_profile_core_threshold", type=float, default=0.12)
    parser.add_argument("--bright_profile_min_core_pixels", type=float, default=8.0)
    parser.add_argument("--bright_profile_core_dilate", type=int, default=1)
    parser.add_argument("--bright_profile_radius", type=int, default=14)
    parser.add_argument("--bright_profile_decay", type=float, default=3.5)
    parser.add_argument("--bright_profile_floor_log", type=float, default=0.025)
    parser.add_argument("--bright_profile_near_log", type=float, default=0.24)
    parser.add_argument("--bright_profile_distance_power", type=float, default=1.5)
    parser.add_argument("--bright_profile_min_distance", type=float, default=0.05)
    parser.add_argument("--boundary_suppression_weight", type=float, default=0.0)
    parser.add_argument("--boundary_ring_width", type=int, default=2)
    parser.add_argument("--boundary_far_distance", type=float, default=0.35)
    parser.add_argument("--boundary_ceiling_log", type=float, default=0.04)
    parser.add_argument("--visible_identity_weight", type=float, default=0.06)
    parser.add_argument("--extinction_sparsity_weight", type=float, default=0.004)
    parser.add_argument("--local_texture_radius", type=int, default=2)
    parser.add_argument("--stat_quantiles", type=str, default="0.05,0.10,0.25,0.50,0.75,0.90,0.97")
    parser.add_argument("--target_geometry_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_geometry_min_visible", type=float, default=8.0)
    parser.add_argument("--rotated_structure_prior_weight", type=float, default=0.0)
    parser.add_argument("--rotated_structure_prior_strength", type=float, default=1.0)
    parser.add_argument("--rotated_structure_prior_reduce", choices=["max", "mean", "weighted_max", "weighted_mean"], default="weighted_max")
    parser.add_argument("--rotated_structure_prior_angle_sign", type=float, default=1.0)
    parser.add_argument("--rotated_structure_prior_max_delta", type=float, default=15.0)
    parser.add_argument("--rotated_structure_prior_dilate", type=int, default=0)
    parser.add_argument("--rotated_structure_prior_blur", type=int, default=1)
    parser.add_argument("--rotated_structure_prior_padding_mode", choices=["zeros", "border", "reflection"], default="border")
    parser.add_argument("--rotated_structure_prior_merge_extinction", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--rotated_structure_prior_gate_loss_weight", type=float, default=0.45)
    parser.add_argument("--rotated_structure_prior_dice_loss_weight", type=float, default=0.30)
    parser.add_argument("--rotated_structure_prior_positive_gain", type=float, default=2.5)
    parser.add_argument("--rotated_structure_prior_residual_loss_weight", type=float, default=0.35)
    parser.add_argument("--rotated_structure_prior_residual_power", type=float, default=2.0)
    parser.add_argument("--rotated_structure_prior_max_intensity", type=float, default=0.055)
    parser.add_argument("--rotated_structure_prior_margin", type=float, default=0.005)
    parser.add_argument("--rotated_structure_prior_edge_loss_weight", type=float, default=0.18)
    parser.add_argument("--rotated_structure_prior_edge_dilate", type=int, default=2)
    parser.add_argument("--rotated_structure_prior_local_ratio_weight", type=float, default=0.20)
    parser.add_argument("--rotated_structure_prior_local_ratio_pool", type=int, default=9)
    parser.add_argument("--rotated_structure_prior_dark_threshold", type=float, default=0.14)
    parser.add_argument("--rotated_structure_prior_dark_softness", type=float, default=0.035)
    parser.add_argument("--full_image_l1_weight", type=float, default=0.55)
    parser.add_argument("--ssim_loss_weight", type=float, default=0.65)
    parser.add_argument("--intensity_mse_weight", type=float, default=0.20)
    parser.add_argument("--target_ssim_loss_weight", type=float, default=0.35)
    parser.add_argument("--target_mse_weight", type=float, default=0.0)
    parser.add_argument("--mask_dilate", type=int, default=1)
    parser.add_argument("--loss_mask_dilate", type=int, default=6)
    parser.add_argument("--target_loss_mask_threshold", type=float, default=0.08)
    parser.add_argument("--target_loss_mask_quantile", type=float, default=0.0)
    parser.add_argument("--target_loss_mask_dilate", type=int, default=0)
    parser.add_argument("--target_loss_mask_min_pixels", type=float, default=16.0)
    parser.add_argument("--target_compose_mask_dilate", type=int, default=0)
    parser.add_argument("--compose_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--compose_alpha_high", type=float, default=0.08)
    parser.add_argument("--compose_alpha_gamma", type=float, default=0.8)
    parser.add_argument("--compose_alpha_dilate", type=int, default=0)
    parser.add_argument("--compose_alpha_blur", type=int, default=0)
    parser.add_argument("--extinction_compose_alpha_weight", type=float, default=0.0)
    parser.add_argument("--extinction_compose_alpha_gamma", type=float, default=1.0)
    parser.add_argument("--bright_loss_weight", type=float, default=0.50)
    parser.add_argument("--bright_loss_gain", type=float, default=7.0)
    parser.add_argument("--quantile_loss_weight", type=float, default=0.20)
    parser.add_argument("--bright_scatter_mse_weight", type=float, default=0.15)
    parser.add_argument("--bright_scatter_threshold_log", type=float, default=0.45)
    parser.add_argument("--texture_loss_weight", type=float, default=0.45)
    parser.add_argument("--gradient_loss_weight", type=float, default=0.30)
    parser.add_argument("--target_speckle_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_speckle_stat_quantiles", type=str, default="0.05,0.10,0.25,0.50,0.75,0.90,0.97")
    parser.add_argument("--target_speckle_std_quantile_weight", type=float, default=1.0)
    parser.add_argument("--target_speckle_highfreq_quantile_weight", type=float, default=0.8)
    parser.add_argument("--target_speckle_intensity_quantile_weight", type=float, default=0.6)
    parser.add_argument("--target_speckle_dark_ratio_weight", type=float, default=0.6)
    parser.add_argument("--target_speckle_dark_threshold", type=float, default=0.22)
    parser.add_argument("--target_speckle_dark_softness", type=float, default=0.035)
    parser.add_argument("--multiplier_identity_weight", type=float, default=0.015)
    parser.add_argument("--visibility_identity_weight", type=float, default=0.010)
    parser.add_argument("--dark_patch_sparsity_weight", type=float, default=0.006)
    parser.add_argument("--target_ring_width", type=int, default=10)
    parser.add_argument("--target_ring_inner_dilate", type=int, default=0)
    parser.add_argument("--target_ring_l1_weight", type=float, default=0.45)
    parser.add_argument("--target_ring_texture_loss_weight", type=float, default=0.35)
    parser.add_argument("--target_ring_gradient_loss_weight", type=float, default=0.18)
    parser.add_argument("--target_ring_quantile_loss_weight", type=float, default=0.25)
    parser.add_argument("--target_ring_patchgan_weight", type=float, default=0.015)
    parser.add_argument("--target_shadow_width", type=int, default=18)
    parser.add_argument("--target_shadow_l1_weight", type=float, default=0.35)
    parser.add_argument("--target_shadow_linear_l1_weight", type=float, default=0.25)
    parser.add_argument("--target_shadow_mse_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_extinction_weight", type=float, default=0.18)
    parser.add_argument("--target_shadow_texture_loss_weight", type=float, default=0.20)
    parser.add_argument("--target_shadow_gradient_loss_weight", type=float, default=0.10)
    parser.add_argument("--target_shadow_ssim_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_quantile_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_patchgan_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_l1_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_linear_l1_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_mse_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_extinction_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_texture_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_gradient_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_quantile_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_target_threshold", type=float, default=0.08)
    parser.add_argument("--target_occlusion_target_high", type=float, default=0.28)
    parser.add_argument("--target_occlusion_dark_threshold", type=float, default=0.16)
    parser.add_argument("--target_occlusion_ratio_threshold", type=float, default=0.12)
    parser.add_argument("--target_occlusion_context_blur", type=int, default=9)
    parser.add_argument("--target_occlusion_soft_blur", type=int, default=1)
    parser.add_argument("--target_occlusion_gamma", type=float, default=1.0)
    parser.add_argument("--target_occlusion_max_intensity", type=float, default=0.08)
    parser.add_argument("--target_occlusion_dark_margin", type=float, default=0.005)
    parser.add_argument("--target_occlusion_context_ratio", type=float, default=0.40)
    parser.add_argument("--azimuth_consistency_weight", type=float, default=0.0)
    parser.add_argument("--azimuth_consistency_max_gap", type=float, default=12.0)
    parser.add_argument("--azimuth_consistency_samples", type=int, default=1)
    parser.add_argument("--azimuth_consistency_texture_weight", type=float, default=0.25)
    parser.add_argument("--background_patchgan_weight", type=float, default=0.04)
    parser.add_argument("--patchgan_lr", type=float, default=1e-4)
    parser.add_argument("--patchgan_base", type=int, default=32)

    parser.add_argument("--target_strength", type=float, default=0.6)
    parser.add_argument("--shadow_strength", type=float, default=0.9)
    parser.add_argument("--shadow_search_dilate", type=int, default=45)
    parser.add_argument("--shadow_restore_strength", type=float, default=0.0)
    parser.add_argument("--shadow_restore_mode", choices=["extinguish", "attenuate", "blend", "darken"], default="darken")
    parser.add_argument("--shadow_restore_threshold", type=float, default=0.18)
    parser.add_argument("--shadow_restore_target_dilate", type=int, default=40)
    parser.add_argument("--shadow_restore_target_protect_dilate", type=int, default=3)
    parser.add_argument("--shadow_restore_reference_blur", type=int, default=4)
    parser.add_argument("--shadow_restore_blur", type=int, default=4)
    parser.add_argument("--shadow_restore_context_blur", type=int, default=21)
    parser.add_argument("--shadow_restore_ratio_mix", type=float, default=0.75)
    parser.add_argument("--shadow_restore_min_attenuation", type=float, default=0.04)
    parser.add_argument("--shadow_restore_attenuation_power", type=float, default=1.7)
    parser.add_argument("--shadow_restore_floor", type=float, default=0.0)
    parser.add_argument("--shadow_restore_max_darken", type=float, default=0.90)
    parser.add_argument("--shadow_geometry", choices=["reference_connected", "directional", "hybrid"], default="reference_connected")
    parser.add_argument("--shadow_reference_min_evidence", type=float, default=0.05)
    parser.add_argument("--shadow_reference_floor", type=float, default=0.25)
    parser.add_argument("--shadow_contact_width", type=int, default=6)
    parser.add_argument("--shadow_contact_strength", type=float, default=0.25)
    parser.add_argument("--shadow_connected_decay", type=float, default=24.0)
    parser.add_argument("--shadow_connected_blur", type=int, default=2)
    parser.add_argument("--shadow_directional_strength", type=float, default=0.0)
    parser.add_argument("--shadow_directional_length", type=int, default=42)
    parser.add_argument("--shadow_directional_decay", type=float, default=18.0)
    parser.add_argument("--shadow_directional_lateral_blur", type=int, default=5)
    parser.add_argument("--shadow_directional_reference_mix", type=float, default=0.65)
    parser.add_argument("--shadow_direction_offset_deg", type=float, default=180.0)
    parser.add_argument("--shadow_direction_sign", type=float, default=1.0)
    parser.add_argument("--enable_azimuth_shadow_refiner", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--azimuth_shadow_checkpoint", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_output", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_apply_use_render_input", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--azimuth_shadow_apply_mask_source", choices=["target", "render"], default="target")
    parser.add_argument("--azimuth_shadow_train_target_dir", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_train_gt_dir", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_train_mask_target_dir", type=Path, default=None)
    parser.add_argument(
        "--azimuth_shadow_train_on_refined",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Train the azimuth shadow refiner on target-refiner outputs instead of raw training renders. Off by default so shadow supervision stays tied to real GT semantic masks.",
    )
    parser.add_argument(
        "--azimuth_shadow_fail_on_degenerate_train_inputs",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Fail if the prepared shadow-train renders and target_modulated_renders are identical.",
    )
    parser.add_argument("--azimuth_shadow_refined_train_output", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_train_use_all_targets", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--azimuth_shadow_refine_mode", choices=["image", "opacity"], default="opacity")
    parser.add_argument("--azimuth_shadow_iterations", type=int, default=2500)
    parser.add_argument("--azimuth_shadow_lr", type=float, default=3e-4)
    parser.add_argument("--azimuth_shadow_model_base", type=int, default=32)
    parser.add_argument(
        "--azimuth_shadow_candidate_mode",
        choices=["directional", "directional_prior", "fixed_direction", "fixed_direction_prior"],
        default="fixed_direction",
    )
    parser.add_argument("--azimuth_shadow_fixed_direction_deg", type=float, default=None)
    parser.add_argument("--azimuth_shadow_gt_auto_fixed_direction_gate", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_gt_use_fixed_direction_gate", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_gt_fixed_direction_min_concentration", type=float, default=0.90)
    parser.add_argument("--azimuth_shadow_gt_fixed_direction_gate_tolerance_deg", type=float, default=28.0)
    parser.add_argument("--azimuth_shadow_gt_fixed_direction_gate_min_dist", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_gt_fixed_direction_gate_max_width", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_gt_low_seed_min_evidence", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_gt_fixed_direction_fallback", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_gt_fixed_direction_fallback_tolerance_deg", type=float, default=35.0)
    parser.add_argument("--azimuth_shadow_gt_fixed_direction_fallback_threshold", type=float, default=0.10)
    parser.add_argument("--azimuth_shadow_gt_fixed_direction_fallback_components", type=int, default=1)
    parser.add_argument("--azimuth_shadow_gt_fixed_direction_fallback_grow", type=int, default=1)
    parser.add_argument("--azimuth_shadow_geometry_extent_gate", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_geometry_extent_apply_to_recognition", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_geometry_extent_require_dataset_direction", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_geometry_extent_forward_scale", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_geometry_extent_lateral_scale", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_geometry_extent_margin_px", type=float, default=1.5)
    parser.add_argument("--azimuth_shadow_geometry_extent_min_forward_px", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_candidate_supervision_mix", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_candidate_length", type=int, default=40)
    parser.add_argument("--azimuth_shadow_candidate_decay", type=float, default=18.0)
    parser.add_argument("--azimuth_shadow_candidate_lateral_blur", type=int, default=5)
    parser.add_argument("--azimuth_shadow_target_protect_dilate", type=int, default=1)
    parser.add_argument("--azimuth_shadow_target_exclude_dilate", type=int, default=1)
    parser.add_argument("--azimuth_shadow_direction_offset_deg", type=float, default=180.0)
    parser.add_argument("--azimuth_shadow_direction_sign", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_shape_prior_mode", choices=["none", "neighbor_gt", "semantic", "hybrid", "semantic_neighbor"], default="none")
    parser.add_argument("--azimuth_shadow_shape_prior_gt_dir", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_shape_prior_weight", type=float, default=0.65)
    parser.add_argument("--azimuth_shadow_shape_prior_threshold", type=float, default=0.05)
    parser.add_argument("--azimuth_shadow_shape_prior_mix_mode", choices=["weighted_mean", "weighted_max"], default="weighted_mean")
    parser.add_argument("--azimuth_shadow_shape_prior_min_pixels", type=float, default=4.0)
    parser.add_argument("--azimuth_shadow_semantic_mask_dir", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_semantic_mask_run", type=str, default="latest")
    parser.add_argument("--azimuth_shadow_supervision_source", choices=["semantic_gt", "heuristic_gt"], default="semantic_gt")
    parser.add_argument("--azimuth_shadow_semantic_target_labels", type=str, default="1,2")
    parser.add_argument("--azimuth_shadow_semantic_shadow_label", type=int, default=3)
    parser.add_argument("--azimuth_shadow_semantic_supervision_mix", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_semantic_dilate", type=int, default=0)
    parser.add_argument("--azimuth_shadow_semantic_blur", type=int, default=0)
    parser.add_argument("--azimuth_shadow_target_mask_threshold", type=float, default=0.08)
    parser.add_argument("--azimuth_shadow_target_mask_quantile", type=float, default=0.35)
    parser.add_argument("--azimuth_shadow_target_mask_dilate", type=int, default=0)
    parser.add_argument("--azimuth_shadow_target_mask_min_pixels", type=float, default=16.0)
    parser.add_argument(
        "--azimuth_shadow_target_mask_mode",
        choices=[
            "legacy",
            "filter_background",
            "render_visibility",
            "scatter95_largest",
            "binary",
            "semantic",
            "semantic_binary",
        ],
        default="scatter95_largest",
    )
    parser.add_argument("--azimuth_shadow_target_mask_filter_percentile", type=float, default=95.0)
    parser.add_argument("--azimuth_shadow_target_mask_filter_largest_cc", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--azimuth_shadow_target_mask_filter_min_target_ratio", type=float, default=0.0005)
    parser.add_argument("--azimuth_shadow_target_mask_filter_max_target_ratio", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_target_mask_filter_adaptive_max_percentile", type=float, default=98.0)
    parser.add_argument("--azimuth_shadow_target_mask_filter_erode_px", type=int, default=0)
    parser.add_argument("--azimuth_shadow_target_mask_visibility_refiner_percentile", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_target_mask_visibility_dilate", type=int, default=1)
    parser.add_argument("--azimuth_shadow_residual_layover_cleanup_strength", type=float, default=0.55)
    parser.add_argument("--azimuth_shadow_residual_layover_cleanup_ceiling", type=float, default=0.04)
    parser.add_argument("--azimuth_shadow_residual_layover_cleanup_blur", type=int, default=1)
    parser.add_argument("--azimuth_shadow_gt_dark_threshold", type=float, default=0.18)
    parser.add_argument("--azimuth_shadow_gt_ratio_threshold", type=float, default=0.16)
    parser.add_argument("--azimuth_shadow_gt_low_percentile", type=float, default=5.0)
    parser.add_argument("--azimuth_shadow_gt_use_global_direction", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--azimuth_shadow_gt_global_direction_deg", type=float, default=None)
    parser.add_argument("--azimuth_shadow_gt_global_direction_tolerance_deg", type=float, default=65.0)
    parser.add_argument("--azimuth_shadow_gt_anchor_threshold", type=float, default=0.12)
    parser.add_argument("--azimuth_shadow_gt_anchor_quantile", type=float, default=0.95)
    parser.add_argument("--azimuth_shadow_gt_anchor_fallback_quantile", type=float, default=0.90)
    parser.add_argument("--azimuth_shadow_gt_anchor_min_pixels", type=float, default=12.0)
    parser.add_argument("--azimuth_shadow_gt_anchor_search_dilate", type=int, default=0)
    parser.add_argument("--azimuth_shadow_gt_anchor_dilate", type=int, default=2)
    parser.add_argument("--azimuth_shadow_gt_anchor_render_mask_mix", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_gt_component_filter", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_gt_component_threshold", type=float, default=0.22)
    parser.add_argument("--azimuth_shadow_gt_component_score_min", type=float, default=0.34)
    parser.add_argument("--azimuth_shadow_gt_min_component_area_ratio", type=float, default=0.08)
    parser.add_argument("--azimuth_shadow_gt_max_component_area_ratio", type=float, default=2.5)
    parser.add_argument("--azimuth_shadow_gt_min_component_pixels", type=float, default=8.0)
    parser.add_argument("--azimuth_shadow_gt_max_components", type=int, default=1)
    parser.add_argument("--azimuth_shadow_gt_direction_tolerance_deg", type=float, default=55.0)
    parser.add_argument("--azimuth_shadow_gt_contact_dilate", type=int, default=4)
    parser.add_argument("--azimuth_shadow_gt_component_open", type=int, default=1)
    parser.add_argument("--azimuth_shadow_gt_component_density_radius", type=int, default=2)
    parser.add_argument("--azimuth_shadow_gt_component_min_density", type=float, default=0.22)
    parser.add_argument("--azimuth_shadow_gt_component_min_bbox_density", type=float, default=0.12)
    parser.add_argument("--azimuth_shadow_gt_component_grow", type=int, default=0)
    parser.add_argument("--azimuth_shadow_gt_component_grow_threshold", type=float, default=None)
    parser.add_argument("--azimuth_shadow_apply_strength", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_apply_max_darken", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_apply_mode", choices=["multiply", "subtract", "ceiling"], default="subtract")
    parser.add_argument("--azimuth_shadow_apply_subtract", type=float, default=0.20)
    parser.add_argument("--azimuth_shadow_apply_ceiling", type=float, default=0.025)
    parser.add_argument("--shadow_carrier_background", choices=["none", "constant", "constant_rgb"], default="none")
    parser.add_argument("--shadow_carrier_value", type=float, default=0.85)
    parser.add_argument("--shadow_carrier_color", type=str, default="1.0,0.85,0.05")
    parser.add_argument("--shadow_carrier_target_dilate", type=int, default=1)
    parser.add_argument("--shadow_carrier_target_blur", type=int, default=1)
    parser.add_argument("--azimuth_shadow_input_color_channels", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_force_grayscale_output", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--azimuth_shadow_image_support_dilate", type=int, default=0)
    parser.add_argument("--azimuth_shadow_image_use_joint_mask", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_image_include_full_target", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_image_delta_log_scale", type=float, default=0.28)
    parser.add_argument("--azimuth_shadow_image_bright_log_scale", type=float, default=0.20)
    parser.add_argument("--azimuth_shadow_image_extinction_log_strength", type=float, default=0.42)
    parser.add_argument("--azimuth_shadow_image_compose_alpha_mode", choices=["prediction", "support"], default="prediction")
    parser.add_argument("--azimuth_shadow_image_compose_alpha_threshold", type=float, default=0.50)
    parser.add_argument("--azimuth_shadow_image_compose_alpha_softness", type=float, default=0.15)
    parser.add_argument("--azimuth_shadow_image_compose_alpha_floor", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_image_compose_alpha_min_support_mean", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_image_compose_blur", type=int, default=4)
    parser.add_argument("--azimuth_shadow_image_detail_radius", type=int, default=2)
    parser.add_argument("--azimuth_shadow_image_target_detail_preserve_weight", type=float, default=0.75)
    parser.add_argument("--azimuth_shadow_image_shadow_detail_preserve_weight", type=float, default=0.35)
    parser.add_argument("--azimuth_shadow_image_log_l1_weight", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_image_log_mse_weight", type=float, default=0.15)
    parser.add_argument("--azimuth_shadow_image_sar_ssim_weight", type=float, default=0.15)
    parser.add_argument("--azimuth_shadow_image_sar_ssim_window", type=int, default=7)
    parser.add_argument("--azimuth_shadow_image_gradient_weight", type=float, default=0.45)
    parser.add_argument("--azimuth_shadow_image_dark_leak_weight", type=float, default=0.18)
    parser.add_argument("--azimuth_shadow_image_target_l1_weight", type=float, default=0.12)
    parser.add_argument("--azimuth_shadow_image_target_identity_weight", type=float, default=0.35)
    parser.add_argument("--azimuth_shadow_image_target_identity_threshold_log", type=float, default=0.42)
    parser.add_argument("--azimuth_shadow_image_outside_identity_weight", type=float, default=0.20)
    parser.add_argument("--azimuth_shadow_image_extinction_reg_weight", type=float, default=0.02)
    parser.add_argument("--azimuth_shadow_output_gain", type=float, default=2.0)
    parser.add_argument("--azimuth_shadow_candidate_prior_strength", type=float, default=0.10)
    parser.add_argument("--azimuth_shadow_output_dilate", type=int, default=1)
    parser.add_argument("--azimuth_shadow_output_blur", type=int, default=2)
    parser.add_argument("--azimuth_shadow_output_gamma", type=float, default=0.65)
    parser.add_argument("--azimuth_shadow_output_mask_floor", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_output_mask_threshold", type=float, default=0.02)
    parser.add_argument("--azimuth_shadow_recognition_source", choices=["reference_connected", "legacy_opacity", "geometry", "shape_prior", "candidate", "prediction", "compose_alpha"], default="candidate")
    parser.add_argument("--azimuth_shadow_recognition_checkpoint", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_recognition_map_dir", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_recognition_threshold", type=float, default=0.4)
    parser.add_argument("--azimuth_shadow_recognition_connect_length", type=int, default=40)
    parser.add_argument("--azimuth_shadow_recognition_connect_decay", type=float, default=24.0)
    parser.add_argument("--azimuth_shadow_recognition_connect_blur", type=int, default=2)
    parser.add_argument("--azimuth_shadow_recognition_min_evidence", type=float, default=0.05)
    parser.add_argument("--azimuth_shadow_recognition_reference_blur", type=int, default=4)
    parser.add_argument("--azimuth_shadow_recognition_context_blur", type=int, default=21)
    parser.add_argument("--azimuth_shadow_recognition_reference_threshold", type=float, default=0.18)
    parser.add_argument("--azimuth_shadow_recognition_ratio_mix", type=float, default=0.75)
    parser.add_argument("--azimuth_shadow_apply_recognition_mask", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_recognition_gate_threshold", type=float, default=0.4)
    parser.add_argument("--azimuth_shadow_apply_feather_blur", type=int, default=4)
    parser.add_argument("--azimuth_shadow_apply_feather_core", type=float, default=0.80)
    parser.add_argument(
        "--azimuth_shadow_learned_intensity_prior",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="After background fusion and shadow-region recognition, apply GT-learned shadow attenuation instead of using refiner pixels.",
    )
    parser.add_argument("--azimuth_shadow_intensity_output", type=Path, default=None)
    parser.add_argument("--azimuth_shadow_intensity_context_radius", type=int, default=13)
    parser.add_argument("--azimuth_shadow_intensity_block_radius", type=int, default=7)
    parser.add_argument("--azimuth_shadow_intensity_exclude_dilate", type=int, default=2)
    parser.add_argument("--azimuth_shadow_intensity_strength", type=float, default=1.22)
    parser.add_argument("--azimuth_shadow_intensity_min_attenuation", type=float, default=0.38)
    parser.add_argument("--azimuth_shadow_intensity_max_attenuation", type=float, default=0.93)
    parser.add_argument("--azimuth_shadow_intensity_gamma", type=float, default=0.80)
    parser.add_argument("--azimuth_shadow_intensity_min_context", type=float, default=0.02)
    parser.add_argument("--azimuth_shadow_intensity_use_apply_alpha", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--azimuth_shadow_intensity_hard_region", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--background_after_shadow", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--background_after_shadow_output", type=Path, default=None)
    parser.add_argument("--background_after_shadow_data_dir", type=Path, default=None)
    parser.add_argument("--background_after_shadow_reference_dir", type=Path, default=None)
    parser.add_argument("--background_after_shadow_background_mode", choices=["patch", "reference_clean"], default="reference_clean")
    parser.add_argument("--background_after_shadow_strength", type=float, default=1.0)
    parser.add_argument("--background_after_shadow_target_mask_threshold", type=float, default=0.02)
    parser.add_argument("--background_after_shadow_target_mask_dilate", type=int, default=1)
    parser.add_argument("--background_after_shadow_blend_dilate", type=int, default=0)
    parser.add_argument("--background_after_shadow_target_mask_blur", type=int, default=1)
    parser.add_argument("--background_after_shadow_target_gap_dark_threshold", type=float, default=0.012)
    parser.add_argument("--background_after_shadow_target_gap_edge_px", type=int, default=2)
    parser.add_argument("--background_after_shadow_target_gap_shadow_protect_threshold", type=float, default=0.02)
    parser.add_argument("--background_after_shadow_shadow_alpha_source", choices=["apply_alpha", "opacity", "compose_alpha", "max"], default="compose_alpha")
    parser.add_argument("--background_after_shadow_shadow_alpha_threshold", type=float, default=0.20)
    parser.add_argument("--background_after_shadow_carrier_replace", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--background_after_shadow_carrier_color", type=str, default="1.0,0.85,0.05")
    parser.add_argument("--background_after_shadow_carrier_tolerance", type=float, default=0.18)
    parser.add_argument("--background_after_shadow_carrier_dilate", type=int, default=1)
    parser.add_argument("--background_after_shadow_carrier_blur", type=int, default=1)
    parser.add_argument("--background_after_shadow_union_mask_dilate", type=int, default=1)
    parser.add_argument("--background_after_shadow_union_mask_blur", type=int, default=6)
    parser.add_argument("--background_after_shadow_union_mask_gamma", type=float, default=1.0)
    parser.add_argument("--background_after_shadow_hard_target_copy", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--background_after_shadow_target_copy_threshold", type=float, default=0.5)
    parser.add_argument("--background_after_shadow_hard_shadow_copy", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--background_after_shadow_shadow_copy_threshold", type=float, default=0.5)
    parser.add_argument("--background_after_shadow_nearest_refs", type=int, default=6)
    parser.add_argument("--background_after_shadow_reference_exclude_dilate", type=int, default=2)
    parser.add_argument("--background_after_shadow_reference_clean_blend_refs", type=int, default=4)
    parser.add_argument("--background_after_shadow_reference_clean_blend_mix", type=float, default=0.45)
    parser.add_argument("--background_after_shadow_reference_clean_angle_sigma", type=float, default=12.0)
    parser.add_argument("--background_after_shadow_reference_clean_patch_mix", type=float, default=0.20)
    parser.add_argument("--background_after_shadow_fallback_blur", type=int, default=11)
    parser.add_argument("--background_after_shadow_target_shadow_directional_grow", type=int, default=0)
    parser.add_argument("--background_after_shadow_target_shadow_directional_strength", type=float, default=0.0)
    parser.add_argument("--background_after_shadow_target_shadow_directional_blur", type=int, default=0)
    parser.add_argument("--background_after_shadow_target_shadow_directional_intersect_shadow", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--background_after_shadow_target_shadow_directional_use_render_intensity", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--background_after_shadow_min_background_fraction", type=float, default=0.96)
    parser.add_argument("--background_after_shadow_stat_match", choices=["none", "mean_std", "quantile"], default="mean_std")
    parser.add_argument("--background_after_shadow_shadow_from_render_percentile", type=float, default=20.0)
    parser.add_argument("--background_after_shadow_speckle_sigma", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_include_target", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_target_overlap_weight", type=float, default=0.55)
    parser.add_argument("--azimuth_shadow_target_overlap_dark_threshold", type=float, default=0.12)
    parser.add_argument("--azimuth_shadow_target_overlap_quantile", type=float, default=0.35)
    parser.add_argument("--azimuth_shadow_target_overlap_dilate", type=int, default=0)
    parser.add_argument(
        "--azimuth_shadow_train_mask_mode",
        choices=["support", "candidate", "candidate_hard", "gt_background_black", "candidate_gt_background_black"],
        default="candidate",
    )
    parser.add_argument("--azimuth_shadow_train_mask_threshold", type=float, default=0.01)
    parser.add_argument("--azimuth_shadow_train_mask_dilate", type=int, default=0)
    parser.add_argument("--azimuth_shadow_train_repair_empty_candidate", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--azimuth_shadow_train_target_mask_max_ratio", type=float, default=0.35)
    parser.add_argument("--azimuth_shadow_train_min_candidate_pixels", type=float, default=8.0)
    parser.add_argument("--azimuth_shadow_fail_on_empty_supervision", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--azimuth_shadow_supervision_mode", choices=["gt_shadow", "source_to_gt", "mixed"], default="mixed")
    parser.add_argument("--azimuth_shadow_source_gt_min_gap", type=float, default=0.010)
    parser.add_argument("--azimuth_shadow_source_gt_softness", type=float, default=0.10)
    parser.add_argument("--azimuth_shadow_source_gt_blur", type=int, default=1)
    parser.add_argument("--azimuth_shadow_source_gt_gamma", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_source_gt_mix", type=float, default=0.65)
    parser.add_argument("--azimuth_shadow_bce_weight", type=float, default=0.15)
    parser.add_argument("--azimuth_shadow_dice_weight", type=float, default=0.25)
    parser.add_argument("--azimuth_shadow_l1_weight", type=float, default=0.35)
    parser.add_argument("--azimuth_shadow_render_l1_weight", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_area_weight", type=float, default=0.05)
    parser.add_argument("--azimuth_shadow_leak_weight", type=float, default=0.02)
    parser.add_argument("--azimuth_shadow_positive_weight", type=float, default=4.0)
    parser.add_argument("--azimuth_shadow_negative_weight", type=float, default=0.15)
    parser.add_argument("--azimuth_shadow_joint_mask_refiner", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_joint_mask_threshold", type=float, default=0.05)
    parser.add_argument("--azimuth_shadow_joint_mask_connect_radius", type=int, default=12)
    parser.add_argument("--azimuth_shadow_joint_mask_bbox_fill", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_joint_mask_dilate", type=int, default=0)
    parser.add_argument("--azimuth_shadow_joint_mask_weight", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_joint_target_min_gap", type=float, default=0.015)
    parser.add_argument("--azimuth_shadow_joint_target_softness", type=float, default=0.10)
    parser.add_argument("--azimuth_shadow_joint_target_mix", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_joint_target_blur", type=int, default=1)
    parser.add_argument("--azimuth_shadow_pred_component_filter", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_pred_global_direction_deg", type=float, default=None)
    parser.add_argument("--azimuth_shadow_pred_global_direction_tolerance_deg", type=float, default=65.0)
    parser.add_argument("--azimuth_shadow_pred_component_threshold", type=float, default=0.08)
    parser.add_argument("--azimuth_shadow_pred_component_score_min", type=float, default=0.28)
    parser.add_argument("--azimuth_shadow_pred_min_component_area_ratio", type=float, default=0.06)
    parser.add_argument("--azimuth_shadow_pred_max_component_area_ratio", type=float, default=2.5)
    parser.add_argument("--azimuth_shadow_pred_min_component_pixels", type=float, default=8.0)
    parser.add_argument("--azimuth_shadow_pred_max_components", type=int, default=1)
    parser.add_argument("--azimuth_shadow_pred_direction_tolerance_deg", type=float, default=55.0)
    parser.add_argument("--azimuth_shadow_pred_contact_dilate", type=int, default=4)
    parser.add_argument("--azimuth_shadow_pred_component_open", type=int, default=1)
    parser.add_argument("--azimuth_shadow_pred_component_density_radius", type=int, default=2)
    parser.add_argument("--azimuth_shadow_pred_component_min_density", type=float, default=0.18)
    parser.add_argument("--azimuth_shadow_pred_component_min_bbox_density", type=float, default=0.10)
    parser.add_argument("--azimuth_shadow_pred_component_grow", type=int, default=0)
    parser.add_argument("--azimuth_shadow_pred_component_grow_threshold", type=float, default=None)
    parser.add_argument("--azimuth_shadow_pred_component_min_keep_ratio", type=float, default=0.0)
    parser.add_argument("--empirical_background_strength", type=float, default=1.0)
    parser.add_argument("--empirical_background_mode", choices=["patch", "reference", "pixel"], default="reference")
    parser.add_argument("--empirical_background_patch_size", type=int, default=24)
    parser.add_argument("--empirical_background_patch_overlap", type=int, default=6)
    parser.add_argument("--empirical_background_patch_smooth", type=int, default=0)
    parser.add_argument("--empirical_background_patch_smooth_mix", type=float, default=0.35)
    parser.add_argument("--empirical_background_patch_fallback_weight", type=float, default=1.0)
    parser.add_argument("--empirical_background_reference_exclude_dilate", type=int, default=24)
    parser.add_argument("--empirical_background_scale", type=float, default=1.35)
    parser.add_argument("--empirical_background_bias", type=float, default=0.025)
    parser.add_argument("--empirical_background_match_target_peak", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--empirical_background_target_peak_quantile", type=float, default=0.95)
    parser.add_argument("--empirical_background_peak_quantile", type=float, default=0.995)
    parser.add_argument("--empirical_background_peak_mix", type=float, default=1.0)
    parser.add_argument("--empirical_background_peak_max_scale", type=float, default=2.5)
    parser.add_argument("--empirical_background_clean_reference", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--shadow_restore_clean_reference", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--empirical_background_lowfreq_smooth_strength", type=float, default=0.35)
    parser.add_argument("--empirical_background_lowfreq_radius", type=int, default=3)
    parser.add_argument("--empirical_background_lowfreq_extra_radius", type=int, default=7)
    parser.add_argument("--empirical_background_highfreq_keep", type=float, default=0.90)
    parser.add_argument("--save_maps", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--save_training_masks", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--adjacent_similarity_eval", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--adjacent_similarity_threshold", type=float, default=0.985)
    parser.add_argument("--adjacent_similarity_severe_threshold", type=float, default=0.995)
    parser.add_argument("--target_preserve_strength", type=float, default=0.0)
    parser.add_argument("--target_preserve_threshold", type=float, default=0.45)
    parser.add_argument("--target_preserve_blur_radius", type=int, default=1)
    parser.add_argument("--target_preserve_occlusion_cut", type=float, default=0.85)
    parser.add_argument("--layer_target_use_preserve", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--layer_target_alpha_threshold", type=float, default=0.035)
    parser.add_argument("--layer_target_alpha_high", type=float, default=0.12)
    parser.add_argument("--layer_target_alpha_gamma", type=float, default=0.75)
    parser.add_argument("--layer_target_use_compose_alpha", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--layer_target_compose_alpha_mix", type=float, default=0.35)
    parser.add_argument("--layer_target_dilate", type=int, default=0)
    parser.add_argument("--layer_target_blur", type=int, default=1)
    parser.add_argument("--layer_target_strength", type=float, default=1.0)
    parser.add_argument("--layer_target_mask_floor", type=float, default=0.35)
    parser.add_argument("--layer_target_contact_width", type=int, default=2)
    parser.add_argument("--layer_target_contact_strength", type=float, default=0.45)
    parser.add_argument("--layer_target_contact_blur", type=int, default=1)
    parser.add_argument("--fail_on_degenerate_background_compose", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--background_compose_min_mean_abs_diff", type=float, default=5e-4)
    parser.add_argument("--multiplier_min", type=float, default=0.35)
    parser.add_argument("--multiplier_max", type=float, default=1.85)
    parser.add_argument("--visibility_min", type=float, default=0.12)
    parser.add_argument("--visibility_max", type=float, default=1.0)
    parser.add_argument("--layover_spatial_only", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--layover_spatial_baseline", choices=["masked_mean", "blur"], default="masked_mean")
    parser.add_argument("--layover_spatial_gain", type=float, default=4.0)
    parser.add_argument("--layover_spatial_bias", type=float, default=0.0)
    parser.add_argument("--layover_spatial_blur_radius", type=int, default=9)
    parser.add_argument("--dark_patch_spatial_floor", type=float, default=0.0)
    parser.add_argument("--target_extinction_spatial_floor", type=float, default=0.0)

    specified_options = _specified_options(sys.argv[1:])
    args = parser.parse_args()
    _apply_azimuth_shadow_pipeline_defaults(args, specified_options)
    _apply_historical_shadow_rollback(args, specified_options)
    _normalize_refiner_mode(args, specified_options)
    _apply_sar_structure_stat_preset(args, specified_options)
    _apply_target_only_pipeline_defaults(args, specified_options)
    _apply_target_layover_pipeline_defaults(args, specified_options)
    _apply_refiner_ablation_pipeline_defaults(args, specified_options)
    if bool(getattr(args, "enable_azimuth_shadow_refiner", False)) and not _any_specified(
        specified_options,
        "shadow_restore_strength",
    ):
        args.shadow_restore_strength = 0.0
    if (
        bool(getattr(args, "enable_azimuth_shadow_refiner", False))
        and str(getattr(args, "azimuth_shadow_supervision_source", "semantic_gt") or "semantic_gt") == "semantic_gt"
        and bool(getattr(args, "azimuth_shadow_train_on_refined", False))
    ):
        print(
            "[azimuth shadow] semantic_gt supervision uses real GT labels 1/2/3; "
            "ignoring --azimuth_shadow_train_on_refined."
        )
        args.azimuth_shadow_train_on_refined = False

    launch_dir = Path.cwd()
    repo_root = _find_repo_root(Path(__file__).resolve())
    if args.repo_root:
        requested_repo_root = _resolve_user_path(args.repo_root, launch_dir)
        if requested_repo_root and requested_repo_root.resolve() != repo_root.resolve():
            print(
                f"[compat] ignoring --repo_root {requested_repo_root}; "
                f"pipeline now runs only from its own repo {repo_root}"
            )
    if str(getattr(args, "refiner_mode", "auto") or "auto") == "target_layover_clean":
        refiner_script = _repo_relative_script(repo_root, "scripts/rendering/learn_sar_target_layover_refiner_clean.py")
    else:
        refiner_script = _repo_relative_script(repo_root, "scripts/rendering/learn_sar_target_modulation_refiner.py")
    postprocess_script = _repo_relative_script(repo_root, "scripts/rendering/postprocess_sar_target_shadow.py")
    azimuth_shadow_script = _repo_relative_script(repo_root, "scripts/rendering/learn_sar_azimuth_shadow_refiner.py")
    background_after_shadow_script = _repo_relative_script(repo_root, "scripts/data_prep/background_after_shadow_preview.py")
    shadow_intensity_prior_script = _repo_relative_script(repo_root, "scripts/tools/apply_semantic_shadow_intensity_prior.py")
    classification_export_script = _repo_relative_script(repo_root, "scripts/tools/export_target_masks_for_classification.py")
    classification_voc_export_script = _repo_relative_script(repo_root, "scripts/tools/export_voc_labels_for_classification.py")
    legacy_eval_script = _repo_relative_script(repo_root, "scripts/evaluation/compare_render_gt.py")
    paper_eval_script = _repo_relative_script(repo_root, "scripts/evaluation/paper_consistent_sar_metrics.py")
    background_filtered_eval_script = _repo_relative_script(repo_root, "scripts/evaluation/compare_render_gt_background_filtered.py")
    delta_eval_script = _repo_relative_script(repo_root, "scripts/evaluation/compare_refiner_target_delta.py")
    adjacent_eval_script = _repo_relative_script(repo_root, "scripts/evaluation/check_adjacent_similarity.py")
    refiner_supported = _supported_cli_options(
        args.python,
        repo_root,
        refiner_script,
    )
    model_path = _resolve_user_path(args.model_path, launch_dir)
    timestamp_default_work_dir = args.stage in {"full_train", "train_base", "finetune_bg", "train_shadow"}
    work_dir = (
        _resolve_user_path(args.work_dir, launch_dir)
        if args.work_dir
        else _default_work_dir(model_path, timestamped=timestamp_default_work_dir)
    )
    _warn_ablation_workdir_mismatch(work_dir, args)
    train_target_dir = _resolve_user_path(args.train_target_dir, launch_dir)
    if train_target_dir is None and str(getattr(args, "refiner_mode", "auto") or "auto") == "target_layover_clean":
        train_target_dir = model_path / "train_renders"
    train_gt_dir = _resolve_user_path(args.train_gt_dir, launch_dir)
    if train_gt_dir is None:
        train_gt_dir = _default_train_gt_dir(repo_root, model_path)
    _apply_dataset_convention_refiner_defaults(
        args,
        specified_options,
        repo_root=repo_root,
        model_path=model_path,
        train_gt_dir=train_gt_dir,
    )
    azimuth_shadow_train_target_dir = (
        _resolve_user_path(args.azimuth_shadow_train_target_dir, launch_dir)
        if args.azimuth_shadow_train_target_dir
        else train_target_dir
    )
    azimuth_shadow_train_gt_dir = (
        _resolve_user_path(args.azimuth_shadow_train_gt_dir, launch_dir)
        if args.azimuth_shadow_train_gt_dir
        else train_gt_dir
    )
    azimuth_shadow_shape_prior_gt_dir = (
        _resolve_user_path(args.azimuth_shadow_shape_prior_gt_dir, launch_dir)
        if args.azimuth_shadow_shape_prior_gt_dir
        else azimuth_shadow_train_gt_dir
    )
    if args.azimuth_shadow_semantic_mask_dir:
        azimuth_shadow_semantic_mask_dir = _resolve_user_path(args.azimuth_shadow_semantic_mask_dir, launch_dir)
    elif args.background_after_shadow_data_dir:
        azimuth_shadow_semantic_mask_dir = _resolve_user_path(args.background_after_shadow_data_dir, launch_dir)
    elif azimuth_shadow_train_gt_dir is not None and azimuth_shadow_train_gt_dir.name.lower() in {"input", "images"}:
        azimuth_shadow_semantic_mask_dir = azimuth_shadow_train_gt_dir.parent
    else:
        azimuth_shadow_semantic_mask_dir = azimuth_shadow_train_gt_dir
    semantic_target_mask_dir = None
    if (
        bool(getattr(args, "enable_azimuth_shadow_refiner", False))
        and not args.target_mask_dir
        and str(getattr(args, "azimuth_shadow_shape_prior_mode", "") or "").lower().strip()
        in {"semantic", "hybrid", "semantic_neighbor"}
    ):
        semantic_target_mask_dir = _export_semantic_target_mask_dir(
            azimuth_shadow_semantic_mask_dir,
            azimuth_shadow_train_gt_dir,
            run_id=str(getattr(args, "azimuth_shadow_semantic_mask_run", "latest") or "latest"),
            repo_root=repo_root,
        )
        if semantic_target_mask_dir is None:
            raise RuntimeError(
                "Semantic shadow refiner requires semantic target masks from data/<class>/scattering_masks/from_convert. "
                "Could not export labels 1/2; pass --target_mask_dir explicitly only if you want to override this."
            )
    target_mask_dir = (
        _resolve_user_path(args.target_mask_dir, launch_dir)
        if args.target_mask_dir
        else semantic_target_mask_dir or _default_target_mask_dir(model_path, work_dir)
    )
    azimuth_shadow_recognition_checkpoint = (
        _resolve_user_path(args.azimuth_shadow_recognition_checkpoint, launch_dir)
        if args.azimuth_shadow_recognition_checkpoint
        else None
    )
    azimuth_shadow_recognition_map_dir = (
        _resolve_user_path(args.azimuth_shadow_recognition_map_dir, launch_dir)
        if args.azimuth_shadow_recognition_map_dir
        else None
    )
    azimuth_shadow_train_mask_target_dir = (
        _resolve_user_path(args.azimuth_shadow_train_mask_target_dir, launch_dir)
        if args.azimuth_shadow_train_mask_target_dir
        else semantic_target_mask_dir
    )
    dark_gt_dir = _resolve_user_path(args.dark_gt_dir, launch_dir)
    gt_dir = _resolve_user_path(args.gt_dir, launch_dir)
    if gt_dir is None:
        gt_dir = _default_eval_gt_dir()
    view_split_train_dir = _resolve_user_path(args.view_split_train_dir, launch_dir)

    stage01_dir = work_dir / "01.refiner"
    stage02_dir = work_dir / "02.background_finetune"
    stage03_dir = work_dir / "03.apply_postprocess"
    stage04_dir = work_dir / "04.evaluation"
    stage_shadow_dir = stage03_dir / "azimuth_shadow_refiner"

    base_checkpoint = _resolve_user_path(args.base_checkpoint, launch_dir) if args.base_checkpoint else stage01_dir / "sar_target_modulation_refiner_patchgan_no_ring.pth"
    bg_checkpoint = _resolve_user_path(args.bg_checkpoint, launch_dir) if args.bg_checkpoint else stage02_dir / "sar_target_modulation_refiner_bg_finetune.pth"
    explicit_checkpoint = _resolve_user_path(args.checkpoint, launch_dir)
    apply_checkpoint = explicit_checkpoint or (
        base_checkpoint if bool(args.skip_bg_finetune) or bool(args.target_only_refiner) else bg_checkpoint
    )
    azimuth_shadow_checkpoint = (
        _resolve_user_path(args.azimuth_shadow_checkpoint, launch_dir)
        if args.azimuth_shadow_checkpoint
        else stage01_dir / "azimuth_shadow_refiner.pth"
    )

    base_output = _resolve_user_path(args.base_output, launch_dir) if args.base_output else stage01_dir / "apply"
    base_post_output = _resolve_user_path(args.base_post_output, launch_dir) if args.base_post_output else stage01_dir / "postprocess" / "renders"
    bg_output = _resolve_user_path(args.bg_output, launch_dir) if args.bg_output else stage02_dir / "apply"
    bg_post_output = _resolve_user_path(args.bg_post_output, launch_dir) if args.bg_post_output else stage02_dir / "postprocess" / "renders"
    apply_output = _resolve_user_path(args.apply_output, launch_dir) if args.apply_output else stage03_dir / "apply"
    if args.final_render_dir:
        final_render_dir = _resolve_user_path(args.final_render_dir, launch_dir)
    elif bool(args.final_postprocess):
        final_render_dir = stage03_dir / "postprocess" / "renders"
    else:
        final_render_dir = apply_output / "renders"
    eval_output = _resolve_user_path(args.eval_output, launch_dir) if args.eval_output else stage04_dir / "novel_metrics"
    delta_output = stage04_dir / "refiner_delta"
    adjacent_output = stage04_dir / "adjacent_similarity"
    azimuth_shadow_output = (
        _resolve_user_path(args.azimuth_shadow_output, launch_dir)
        if args.azimuth_shadow_output
        else stage_shadow_dir / "apply"
    )
    azimuth_shadow_refined_train_output = (
        _resolve_user_path(args.azimuth_shadow_refined_train_output, launch_dir)
        if args.azimuth_shadow_refined_train_output
        else stage_shadow_dir / "train_refined_input"
    )
    background_after_shadow_output = (
        _resolve_user_path(args.background_after_shadow_output, launch_dir)
        if args.background_after_shadow_output
        else stage03_dir / "background_after_shadow"
    )
    azimuth_shadow_intensity_output = (
        _resolve_user_path(args.azimuth_shadow_intensity_output, launch_dir)
        if args.azimuth_shadow_intensity_output
        else stage_shadow_dir / "learned_intensity_prior"
    )
    result_root = _resolve_user_path(args.result_dir, launch_dir) if args.result_dir else model_path / "result"
    classification_label_output_dir = (
        _resolve_user_path(args.classification_label_output_dir, launch_dir)
        if args.classification_label_output_dir
        else work_dir
    )
    dataset_name = model_path.parent.name
    background_filtered_eval_gt_dir = (
        _resolve_user_path(args.background_filtered_eval_gt_dir, launch_dir)
        if args.background_filtered_eval_gt_dir
        else train_gt_dir
    )
    background_filtered_eval_output_dir = (
        _resolve_user_path(args.background_filtered_eval_output_dir, launch_dir)
        if args.background_filtered_eval_output_dir
        else stage04_dir / "background_filtered_metrics"
    )
    classification_root = (
        _resolve_user_path(args.classification_root, launch_dir)
        if args.classification_root
        else _default_classification_root()
    )
    refiner_mode = str(args.refiner_mode)
    executed_commands: list[dict] = []
    eval_skipped_reason: str | None = None
    eval_ran = False
    eval_target_ran = False
    eval_target_shadow_ran = False
    eval_intermediate_debug_ran = False

    output_paths = {
        "base_checkpoint": base_checkpoint,
        "base_apply": base_output,
        "base_post": base_post_output,
        "background_checkpoint": bg_checkpoint,
        "background_apply": bg_output,
        "background_post": bg_post_output,
        "apply_checkpoint": apply_checkpoint,
        "azimuth_shadow_checkpoint": azimuth_shadow_checkpoint,
        "azimuth_shadow_apply": azimuth_shadow_output,
        "azimuth_shadow_refined_train_input": azimuth_shadow_refined_train_output / "renders",
        "background_after_shadow": background_after_shadow_output,
        "background_after_shadow_maps": background_after_shadow_output / "maps",
        "final_apply": apply_output,
        "final_renders": final_render_dir,
        "source_target_renders": model_path / "novel_target_only" / "target_renders",
        "refiner_target_renders": apply_output / "target_modulated_renders",
        "apply_maps": apply_output / "maps",
        "azimuth_shadow_maps": azimuth_shadow_output / "maps",
        "azimuth_shadow_intensity_prior": azimuth_shadow_intensity_output,
        "azimuth_shadow_intensity_prior_renders": azimuth_shadow_intensity_output / "renders",
        "azimuth_shadow_intensity_prior_maps": azimuth_shadow_intensity_output / "maps",
        "eval": eval_output,
        "refiner_delta": delta_output,
        "adjacent_similarity": adjacent_output,
        "result_root": result_root,
        "classification_label_output_dir": classification_label_output_dir,
        "background_filtered_eval_output_dir": background_filtered_eval_output_dir,
        "classification_root": classification_root,
        "target_mask_dir": target_mask_dir,
        "train_target_dir": train_target_dir,
        "azimuth_shadow_train_target_dir": azimuth_shadow_train_target_dir,
        "azimuth_shadow_train_mask_target_dir": azimuth_shadow_train_mask_target_dir,
        "train_gt_dir": train_gt_dir,
        "azimuth_shadow_train_gt_dir": azimuth_shadow_train_gt_dir,
        "dark_gt_dir": dark_gt_dir,
        "gt_dir": gt_dir,
    }
    pipeline_start = time.perf_counter()

    if args.stage in {"full_train", "train_base"}:
        cmd = [
            args.python,
            refiner_script,
            "-m",
            str(model_path),
            "--refiner_mode",
            refiner_mode,
        ]
        if train_target_dir is not None:
            cmd += ["--train_target_dir", str(train_target_dir)]
        if train_gt_dir is not None:
            cmd += ["--train_gt_dir", str(train_gt_dir)]
        if dark_gt_dir is not None:
            cmd = _append_if_supported(cmd, refiner_supported, "--dark_gt_dir", str(dark_gt_dir))
        cmd += [
            "--checkpoint",
            str(base_checkpoint),
            "--output_dir",
            str(base_output),
            "--postprocess_output_dir",
            str(base_post_output),
            "--iterations",
            str(args.base_iterations),
            "--batch_size",
            str(args.batch_size),
            "--lr",
            str(args.base_lr),
            "--train_azimuth_step",
            str(args.train_azimuth_step),
            "--conv_padding_mode",
            "reflect",
            "--deterministic_train_noise",
            "--target_ring_width",
            str(args.target_ring_width),
            "--target_ring_inner_dilate",
            str(args.target_ring_inner_dilate),
            "--target_ring_l1_weight",
            str(args.target_ring_l1_weight),
            "--target_ring_texture_loss_weight",
            str(args.target_ring_texture_loss_weight),
            "--target_ring_gradient_loss_weight",
            str(args.target_ring_gradient_loss_weight),
            "--target_ring_quantile_loss_weight",
            str(args.target_ring_quantile_loss_weight),
            "--target_ring_patchgan_weight",
            str(args.target_ring_patchgan_weight),
            "--target_shadow_width",
            str(args.target_shadow_width),
            "--target_shadow_l1_weight",
            str(args.target_shadow_l1_weight),
            "--target_shadow_linear_l1_weight",
            str(args.target_shadow_linear_l1_weight),
            "--target_shadow_extinction_weight",
            str(args.target_shadow_extinction_weight),
            "--target_shadow_texture_loss_weight",
            str(args.target_shadow_texture_loss_weight),
            "--target_shadow_gradient_loss_weight",
            str(args.target_shadow_gradient_loss_weight),
            "--loss_mask_dilate",
            str(args.loss_mask_dilate),
            "--bright_loss_weight",
            str(args.bright_loss_weight),
            "--bright_loss_gain",
            str(args.bright_loss_gain),
            "--texture_loss_weight",
            str(args.texture_loss_weight),
            "--gradient_loss_weight",
            str(args.gradient_loss_weight),
            "--target_ssim_loss_weight",
            str(args.target_ssim_loss_weight),
            "--target_mse_weight",
            str(args.target_mse_weight),
            "--azimuth_consistency_weight",
            str(args.azimuth_consistency_weight),
            "--azimuth_consistency_max_gap",
            str(args.azimuth_consistency_max_gap),
            "--azimuth_consistency_samples",
            str(args.azimuth_consistency_samples),
            "--azimuth_consistency_texture_weight",
            str(args.azimuth_consistency_texture_weight),
            "--background_patchgan_weight",
            str(args.background_patchgan_weight),
            "--patchgan_lr",
            str(args.patchgan_lr),
            "--patchgan_base",
            str(args.patchgan_base),
        ]
        if bool(args.save_training_masks):
            cmd = _append_if_supported(cmd, refiner_supported, "--save_training_masks")
        cmd = _add_training_runtime_flags(cmd, args, refiner_supported)
        cmd = _add_target_layover_training_flags(cmd, args, refiner_supported)
        if bool(args.target_only_refiner):
            cmd = _append_if_supported(cmd, refiner_supported, "--target_only_refiner")
        if bool(args.train_use_all_targets):
            cmd = _append_if_supported(cmd, refiner_supported, "--train_use_all_targets")
        if bool(args.train_azimuth_unique):
            cmd += ["--train_azimuth_unique"]
        if not bool(args.keep_intermediate_apply):
            cmd += ["--train_only"]
        cmd = _filter_unsupported_options(cmd, refiner_supported)
        _run_recorded("train_base", cmd, repo_root, executed_commands, dry_run=args.dry_run)

    if args.stage in {"full_train", "finetune_bg"} and not bool(args.skip_bg_finetune) and not bool(args.target_only_refiner):
        cmd = [
            args.python,
            refiner_script,
            "-m",
            str(model_path),
            "--refiner_mode",
            "image",
        ]
        if train_target_dir is not None:
            cmd += ["--train_target_dir", str(train_target_dir)]
        if train_gt_dir is not None:
            cmd += ["--train_gt_dir", str(train_gt_dir)]
        cmd += [
            "--init_checkpoint",
            str(base_checkpoint),
            "--checkpoint",
            str(bg_checkpoint),
            "--output_dir",
            str(bg_output),
            "--postprocess_output_dir",
            str(bg_post_output),
            "--background_finetune",
            "--iterations",
            str(args.bg_iterations),
            "--batch_size",
            str(args.batch_size),
            "--lr",
            str(args.bg_lr),
            "--train_azimuth_step",
            str(args.train_azimuth_step),
            "--conv_padding_mode",
            "reflect",
            "--deterministic_train_noise",
            "--target_ring_width",
            str(args.target_ring_width),
            "--target_ring_inner_dilate",
            str(args.target_ring_inner_dilate),
            "--target_ring_l1_weight",
            str(args.target_ring_l1_weight),
            "--target_ring_texture_loss_weight",
            str(args.target_ring_texture_loss_weight),
            "--target_ring_gradient_loss_weight",
            str(args.target_ring_gradient_loss_weight),
            "--target_ring_quantile_loss_weight",
            str(args.target_ring_quantile_loss_weight),
            "--target_ring_patchgan_weight",
            str(args.target_ring_patchgan_weight),
            "--target_shadow_width",
            str(args.target_shadow_width),
            "--target_shadow_l1_weight",
            str(args.target_shadow_l1_weight),
            "--target_shadow_linear_l1_weight",
            str(args.target_shadow_linear_l1_weight),
            "--target_shadow_extinction_weight",
            str(args.target_shadow_extinction_weight),
            "--target_shadow_texture_loss_weight",
            str(args.target_shadow_texture_loss_weight),
            "--target_shadow_gradient_loss_weight",
            str(args.target_shadow_gradient_loss_weight),
            "--loss_mask_dilate",
            str(args.loss_mask_dilate),
            "--bright_loss_weight",
            str(args.bright_loss_weight),
            "--bright_loss_gain",
            str(args.bright_loss_gain),
            "--texture_loss_weight",
            str(args.texture_loss_weight),
            "--gradient_loss_weight",
            str(args.gradient_loss_weight),
            "--target_ssim_loss_weight",
            str(args.target_ssim_loss_weight),
            "--target_mse_weight",
            str(args.target_mse_weight),
            "--azimuth_consistency_weight",
            str(args.azimuth_consistency_weight),
            "--azimuth_consistency_max_gap",
            str(args.azimuth_consistency_max_gap),
            "--azimuth_consistency_samples",
            str(args.azimuth_consistency_samples),
            "--azimuth_consistency_texture_weight",
            str(args.azimuth_consistency_texture_weight),
            "--background_patchgan_weight",
            str(args.background_patchgan_weight),
            "--patchgan_lr",
            str(args.patchgan_lr),
            "--patchgan_base",
            str(args.patchgan_base),
        ]
        cmd = _add_training_runtime_flags(cmd, args, refiner_supported)
        cmd = _add_target_layover_training_flags(cmd, args, refiner_supported)
        if bool(args.target_only_refiner):
            cmd = _append_if_supported(cmd, refiner_supported, "--target_only_refiner")
        if bool(args.train_use_all_targets):
            cmd = _append_if_supported(cmd, refiner_supported, "--train_use_all_targets")
        if bool(args.train_azimuth_unique):
            cmd += ["--train_azimuth_unique"]
        if not bool(args.keep_intermediate_apply):
            cmd += ["--train_only"]
        cmd = _filter_unsupported_options(cmd, refiner_supported)
        _run_recorded("finetune_bg", cmd, repo_root, executed_commands, dry_run=args.dry_run)
    elif args.stage in {"full_train", "finetune_bg"}:
        reason = "target-only refiner has no background stage" if bool(args.target_only_refiner) else "using base checkpoint for apply"
        print(f"\n[bg finetune] skipped: {reason}.")

    should_apply_target_refiner = args.stage in {"full_train", "apply", "apply_eval"} or (
        args.stage == "apply_shadow" and args.final_render_dir is None
    )
    if should_apply_target_refiner:
        cmd = [
            args.python,
            refiner_script,
            "-m",
            str(model_path),
            "--apply_only",
            "--checkpoint",
            str(apply_checkpoint),
            "--output_dir",
            str(apply_output),
            "--postprocess_output_dir",
            str(final_render_dir),
        ]
        if train_gt_dir is not None:
            cmd += [
                "--train_gt_dir",
                str(train_gt_dir),
                "--background_reference_dir",
                str(train_gt_dir),
            ]
        cmd = _add_common_apply_defaults(cmd, args, refiner_supported)
        if not bool(args.final_postprocess):
            cmd += ["--no-postprocess_after_apply"]
        else:
            cmd = _add_refiner_postprocess_defaults(cmd, args, refiner_supported)
        cmd = _filter_unsupported_options(cmd, refiner_supported)
        _run_recorded("apply", cmd, repo_root, executed_commands, dry_run=args.dry_run)

    if args.stage == "apply_shadow" and args.final_render_dir is not None:
        output_paths["shadow_base_renders"] = final_render_dir
        print(f"[azimuth shadow] using explicit shadow/background base: {final_render_dir}")

    shadow_train_source_dir = azimuth_shadow_train_target_dir
    shadow_train_mask_source_dir = azimuth_shadow_train_mask_target_dir
    if (
        bool(args.enable_azimuth_shadow_refiner)
        and args.stage in {"full_train", "train_shadow"}
        and bool(getattr(args, "azimuth_shadow_train_on_refined", True))
        and str(getattr(args, "refiner_mode", "") or "") == "target_layover_clean"
    ):
        if azimuth_shadow_train_target_dir is None:
            raise RuntimeError("--azimuth_shadow_train_on_refined requires --train_target_dir/--azimuth_shadow_train_target_dir")
        cmd = [
            args.python,
            refiner_script,
            "-m",
            str(model_path),
            "--apply_only",
            "--checkpoint",
            str(apply_checkpoint),
            "--apply_target_dir",
            str(azimuth_shadow_train_target_dir),
            "--output_dir",
            str(azimuth_shadow_refined_train_output),
            "--postprocess_output_dir",
            str(azimuth_shadow_refined_train_output / "postprocess" / "renders"),
        ]
        if azimuth_shadow_train_gt_dir is not None:
            cmd += [
                "--train_gt_dir",
                str(azimuth_shadow_train_gt_dir),
                "--background_reference_dir",
                str(azimuth_shadow_train_gt_dir),
            ]
        cmd = _add_common_apply_defaults(cmd, args, refiner_supported)
        cmd = _filter_unsupported_options(cmd, refiner_supported)
        _run_recorded("prepare_shadow_train_inputs", cmd, repo_root, executed_commands, dry_run=args.dry_run)
        shadow_train_source_dir = azimuth_shadow_refined_train_output / "renders"
        shadow_train_target_reference_dir = azimuth_shadow_refined_train_output / "target_modulated_renders"
        if shadow_train_mask_source_dir is None:
            shadow_train_mask_source_dir = train_target_dir or azimuth_shadow_train_target_dir
        same_refined_outputs = None if bool(args.dry_run) else _sample_dirs_identical(shadow_train_source_dir, shadow_train_target_reference_dir)
        if same_refined_outputs is True:
            message = (
                "prepare_shadow_train_inputs produced identical renders and target_modulated_renders. "
                "This means the shadow trainer would see no composed background difference; "
                "check target_only_compose_context/background_reference settings."
            )
            if bool(getattr(args, "azimuth_shadow_fail_on_degenerate_train_inputs", True)):
                raise RuntimeError(message)
            print(f"[azimuth shadow] warning: {message}")
        print(f"[azimuth shadow] train source: {shadow_train_source_dir}")
        print(f"[azimuth shadow] mask source : {shadow_train_mask_source_dir}")
        print(f"[azimuth shadow] target-only reference: {shadow_train_target_reference_dir}")

    if bool(args.enable_azimuth_shadow_refiner) and args.stage in {"full_train", "train_shadow"}:
        if shadow_train_source_dir is None or azimuth_shadow_train_gt_dir is None:
            raise RuntimeError("--enable_azimuth_shadow_refiner training requires a training target dir and --train_gt_dir/--azimuth_shadow_train_gt_dir")
        cmd = [
            args.python,
            azimuth_shadow_script,
            "-m",
            str(model_path),
            "--train_target_dir",
            str(shadow_train_source_dir),
            "--train_gt_dir",
            str(azimuth_shadow_train_gt_dir),
            "--checkpoint",
            str(azimuth_shadow_checkpoint),
            "--output_dir",
            str(stage_shadow_dir / "train"),
            "--iterations",
            str(args.azimuth_shadow_iterations),
            "--batch_size",
            str(args.batch_size),
            "--lr",
            str(args.azimuth_shadow_lr),
            "--model_base",
            str(args.azimuth_shadow_model_base),
            "--shadow_refine_mode",
            str(args.azimuth_shadow_refine_mode),
            "--shadow_candidate_mode",
            str(args.azimuth_shadow_candidate_mode),
            "--shadow_train_mask_mode",
            str(args.azimuth_shadow_train_mask_mode),
            "--shadow_train_mask_threshold",
            str(args.azimuth_shadow_train_mask_threshold),
            "--shadow_train_mask_dilate",
            str(args.azimuth_shadow_train_mask_dilate),
            "--shadow_train_target_mask_max_ratio",
            str(args.azimuth_shadow_train_target_mask_max_ratio),
            "--shadow_train_min_candidate_pixels",
            str(args.azimuth_shadow_train_min_candidate_pixels),
            "--shadow_supervision_mode",
            str(args.azimuth_shadow_supervision_mode),
            "--shadow_source_gt_min_gap",
            str(args.azimuth_shadow_source_gt_min_gap),
            "--shadow_source_gt_softness",
            str(args.azimuth_shadow_source_gt_softness),
            "--shadow_source_gt_blur",
            str(args.azimuth_shadow_source_gt_blur),
            "--shadow_source_gt_gamma",
            str(args.azimuth_shadow_source_gt_gamma),
            "--shadow_source_gt_mix",
            str(args.azimuth_shadow_source_gt_mix),
            "--shadow_gt_fixed_direction_min_concentration",
            str(args.azimuth_shadow_gt_fixed_direction_min_concentration),
            "--shadow_gt_fixed_direction_gate_tolerance_deg",
            str(args.azimuth_shadow_gt_fixed_direction_gate_tolerance_deg),
            "--shadow_gt_fixed_direction_gate_min_dist",
            str(args.azimuth_shadow_gt_fixed_direction_gate_min_dist),
            "--shadow_gt_fixed_direction_gate_max_width",
            str(args.azimuth_shadow_gt_fixed_direction_gate_max_width),
            "--shadow_gt_low_seed_min_evidence",
            str(args.azimuth_shadow_gt_low_seed_min_evidence),
            "--shadow_gt_fixed_direction_fallback_tolerance_deg",
            str(args.azimuth_shadow_gt_fixed_direction_fallback_tolerance_deg),
            "--shadow_gt_fixed_direction_fallback_threshold",
            str(args.azimuth_shadow_gt_fixed_direction_fallback_threshold),
            "--shadow_gt_fixed_direction_fallback_components",
            str(args.azimuth_shadow_gt_fixed_direction_fallback_components),
            "--shadow_gt_fixed_direction_fallback_grow",
            str(args.azimuth_shadow_gt_fixed_direction_fallback_grow),
            "--shadow_candidate_supervision_mix",
            str(args.azimuth_shadow_candidate_supervision_mix),
            "--train_azimuth_step",
            str(args.train_azimuth_step),
            "--shadow_candidate_length",
            str(args.azimuth_shadow_candidate_length),
            "--shadow_candidate_decay",
            str(args.azimuth_shadow_candidate_decay),
            "--shadow_candidate_lateral_blur",
            str(args.azimuth_shadow_candidate_lateral_blur),
            "--shadow_target_protect_dilate",
            str(args.azimuth_shadow_target_protect_dilate),
            "--shadow_target_exclude_dilate",
            str(args.azimuth_shadow_target_exclude_dilate),
            "--shadow_direction_offset_deg",
            str(args.azimuth_shadow_direction_offset_deg),
            "--shadow_direction_sign",
            str(args.azimuth_shadow_direction_sign),
            "--shadow_shape_prior_mode",
            str(args.azimuth_shadow_shape_prior_mode),
            "--shadow_shape_prior_weight",
            str(args.azimuth_shadow_shape_prior_weight),
            "--shadow_shape_prior_threshold",
            str(args.azimuth_shadow_shape_prior_threshold),
            "--shadow_shape_prior_mix_mode",
            str(args.azimuth_shadow_shape_prior_mix_mode),
            "--shadow_shape_prior_min_pixels",
            str(args.azimuth_shadow_shape_prior_min_pixels),
            "--shadow_semantic_mask_run",
            str(args.azimuth_shadow_semantic_mask_run),
            "--shadow_supervision_source",
            str(args.azimuth_shadow_supervision_source),
            "--shadow_semantic_target_labels",
            str(args.azimuth_shadow_semantic_target_labels),
            "--shadow_semantic_shadow_label",
            str(args.azimuth_shadow_semantic_shadow_label),
            "--shadow_semantic_supervision_mix",
            str(args.azimuth_shadow_semantic_supervision_mix),
            "--shadow_semantic_dilate",
            str(args.azimuth_shadow_semantic_dilate),
            "--shadow_semantic_blur",
            str(args.azimuth_shadow_semantic_blur),
            "--shadow_geometry_extent_forward_scale",
            str(args.azimuth_shadow_geometry_extent_forward_scale),
            "--shadow_geometry_extent_lateral_scale",
            str(args.azimuth_shadow_geometry_extent_lateral_scale),
            "--shadow_geometry_extent_margin_px",
            str(args.azimuth_shadow_geometry_extent_margin_px),
            "--shadow_geometry_extent_min_forward_px",
            str(args.azimuth_shadow_geometry_extent_min_forward_px),
            "--target_mask_threshold",
            str(args.azimuth_shadow_target_mask_threshold),
            "--target_mask_quantile",
            str(args.azimuth_shadow_target_mask_quantile),
            "--target_mask_dilate",
            str(args.azimuth_shadow_target_mask_dilate),
            "--target_mask_min_pixels",
            str(args.azimuth_shadow_target_mask_min_pixels),
            "--shadow_train_target_mask_max_ratio",
            str(args.azimuth_shadow_train_target_mask_max_ratio),
            "--target_mask_mode",
            str(args.azimuth_shadow_target_mask_mode),
            "--target_mask_filter_percentile",
            str(args.azimuth_shadow_target_mask_filter_percentile),
            "--target_mask_filter_min_target_ratio",
            str(args.azimuth_shadow_target_mask_filter_min_target_ratio),
            "--target_mask_filter_max_target_ratio",
            str(args.azimuth_shadow_target_mask_filter_max_target_ratio),
            "--target_mask_filter_adaptive_max_percentile",
            str(args.azimuth_shadow_target_mask_filter_adaptive_max_percentile),
            "--target_mask_filter_erode_px",
            str(args.azimuth_shadow_target_mask_filter_erode_px),
            "--target_mask_visibility_refiner_percentile",
            str(args.azimuth_shadow_target_mask_visibility_refiner_percentile),
            "--target_mask_visibility_dilate",
            str(args.azimuth_shadow_target_mask_visibility_dilate),
            "--shadow_gt_dark_threshold",
            str(args.azimuth_shadow_gt_dark_threshold),
            "--shadow_gt_ratio_threshold",
            str(args.azimuth_shadow_gt_ratio_threshold),
            "--shadow_gt_low_percentile",
            str(args.azimuth_shadow_gt_low_percentile),
            "--shadow_gt_global_direction_tolerance_deg",
            str(args.azimuth_shadow_gt_global_direction_tolerance_deg),
            "--shadow_gt_anchor_threshold",
            str(args.azimuth_shadow_gt_anchor_threshold),
            "--shadow_gt_anchor_quantile",
            str(args.azimuth_shadow_gt_anchor_quantile),
            "--shadow_gt_anchor_fallback_quantile",
            str(args.azimuth_shadow_gt_anchor_fallback_quantile),
            "--shadow_gt_anchor_min_pixels",
            str(args.azimuth_shadow_gt_anchor_min_pixels),
            "--shadow_gt_anchor_search_dilate",
            str(args.azimuth_shadow_gt_anchor_search_dilate),
            "--shadow_gt_anchor_dilate",
            str(args.azimuth_shadow_gt_anchor_dilate),
            "--shadow_gt_anchor_render_mask_mix",
            str(args.azimuth_shadow_gt_anchor_render_mask_mix),
            "--shadow_gt_component_threshold",
            str(args.azimuth_shadow_gt_component_threshold),
            "--shadow_gt_component_score_min",
            str(args.azimuth_shadow_gt_component_score_min),
            "--shadow_gt_min_component_area_ratio",
            str(args.azimuth_shadow_gt_min_component_area_ratio),
            "--shadow_gt_max_component_area_ratio",
            str(args.azimuth_shadow_gt_max_component_area_ratio),
            "--shadow_gt_min_component_pixels",
            str(args.azimuth_shadow_gt_min_component_pixels),
            "--shadow_gt_max_components",
            str(args.azimuth_shadow_gt_max_components),
            "--shadow_gt_direction_tolerance_deg",
            str(args.azimuth_shadow_gt_direction_tolerance_deg),
            "--shadow_gt_contact_dilate",
            str(args.azimuth_shadow_gt_contact_dilate),
            "--shadow_gt_component_open",
            str(args.azimuth_shadow_gt_component_open),
            "--shadow_gt_component_density_radius",
            str(args.azimuth_shadow_gt_component_density_radius),
            "--shadow_gt_component_min_density",
            str(args.azimuth_shadow_gt_component_min_density),
            "--shadow_gt_component_min_bbox_density",
            str(args.azimuth_shadow_gt_component_min_bbox_density),
            "--shadow_gt_component_grow",
            str(args.azimuth_shadow_gt_component_grow),
            "--shadow_apply_strength",
            str(args.azimuth_shadow_apply_strength),
            "--shadow_apply_max_darken",
            str(args.azimuth_shadow_apply_max_darken),
            "--shadow_apply_mode",
            str(args.azimuth_shadow_apply_mode),
            "--shadow_apply_subtract",
            str(args.azimuth_shadow_apply_subtract),
            "--shadow_apply_ceiling",
            str(args.azimuth_shadow_apply_ceiling),
            "--shadow_carrier_background",
            str(args.shadow_carrier_background),
            "--shadow_carrier_value",
            str(args.shadow_carrier_value),
            "--shadow_carrier_color",
            str(args.shadow_carrier_color),
            "--shadow_carrier_target_dilate",
            str(args.shadow_carrier_target_dilate),
            "--shadow_carrier_target_blur",
            str(args.shadow_carrier_target_blur),
            "--shadow_image_support_dilate",
            str(args.azimuth_shadow_image_support_dilate),
            "--shadow_image_delta_log_scale",
            str(args.azimuth_shadow_image_delta_log_scale),
            "--shadow_image_bright_log_scale",
            str(args.azimuth_shadow_image_bright_log_scale),
            "--shadow_image_extinction_log_strength",
            str(args.azimuth_shadow_image_extinction_log_strength),
            "--shadow_image_compose_alpha_mode",
            str(args.azimuth_shadow_image_compose_alpha_mode),
            "--shadow_image_compose_alpha_threshold",
            str(args.azimuth_shadow_image_compose_alpha_threshold),
            "--shadow_image_compose_alpha_softness",
            str(args.azimuth_shadow_image_compose_alpha_softness),
            "--shadow_image_compose_alpha_floor",
            str(args.azimuth_shadow_image_compose_alpha_floor),
            "--shadow_image_compose_alpha_min_support_mean",
            str(args.azimuth_shadow_image_compose_alpha_min_support_mean),
            "--shadow_image_compose_blur",
            str(args.azimuth_shadow_image_compose_blur),
            "--shadow_image_detail_radius",
            str(args.azimuth_shadow_image_detail_radius),
            "--shadow_image_target_detail_preserve_weight",
            str(args.azimuth_shadow_image_target_detail_preserve_weight),
            "--shadow_image_shadow_detail_preserve_weight",
            str(args.azimuth_shadow_image_shadow_detail_preserve_weight),
            "--shadow_image_log_l1_weight",
            str(args.azimuth_shadow_image_log_l1_weight),
            "--shadow_image_log_mse_weight",
            str(args.azimuth_shadow_image_log_mse_weight),
            "--shadow_image_sar_ssim_weight",
            str(args.azimuth_shadow_image_sar_ssim_weight),
            "--shadow_image_sar_ssim_window",
            str(args.azimuth_shadow_image_sar_ssim_window),
            "--shadow_image_gradient_weight",
            str(args.azimuth_shadow_image_gradient_weight),
            "--shadow_image_dark_leak_weight",
            str(args.azimuth_shadow_image_dark_leak_weight),
            "--shadow_image_target_l1_weight",
            str(args.azimuth_shadow_image_target_l1_weight),
            "--shadow_image_target_identity_weight",
            str(args.azimuth_shadow_image_target_identity_weight),
            "--shadow_image_target_identity_threshold_log",
            str(args.azimuth_shadow_image_target_identity_threshold_log),
            "--shadow_image_outside_identity_weight",
            str(args.azimuth_shadow_image_outside_identity_weight),
            "--shadow_image_extinction_reg_weight",
            str(args.azimuth_shadow_image_extinction_reg_weight),
            "--shadow_bce_weight",
            str(args.azimuth_shadow_bce_weight),
            "--shadow_dice_weight",
            str(args.azimuth_shadow_dice_weight),
            "--shadow_l1_weight",
            str(args.azimuth_shadow_l1_weight),
            "--shadow_render_l1_weight",
            str(args.azimuth_shadow_render_l1_weight),
            "--shadow_area_weight",
            str(args.azimuth_shadow_area_weight),
            "--shadow_leak_weight",
            str(args.azimuth_shadow_leak_weight),
            "--shadow_positive_weight",
            str(args.azimuth_shadow_positive_weight),
            "--shadow_negative_weight",
            str(args.azimuth_shadow_negative_weight),
            "--shadow_target_overlap_weight",
            str(args.azimuth_shadow_target_overlap_weight),
            "--shadow_target_overlap_dark_threshold",
            str(args.azimuth_shadow_target_overlap_dark_threshold),
            "--shadow_target_overlap_quantile",
            str(args.azimuth_shadow_target_overlap_quantile),
            "--shadow_target_overlap_dilate",
            str(args.azimuth_shadow_target_overlap_dilate),
            "--shadow_joint_mask_threshold",
            str(args.azimuth_shadow_joint_mask_threshold),
            "--shadow_joint_mask_connect_radius",
            str(args.azimuth_shadow_joint_mask_connect_radius),
            "--shadow_joint_mask_dilate",
            str(args.azimuth_shadow_joint_mask_dilate),
            "--shadow_joint_mask_weight",
            str(args.azimuth_shadow_joint_mask_weight),
            "--shadow_joint_target_min_gap",
            str(args.azimuth_shadow_joint_target_min_gap),
            "--shadow_joint_target_softness",
            str(args.azimuth_shadow_joint_target_softness),
            "--shadow_joint_target_mix",
            str(args.azimuth_shadow_joint_target_mix),
            "--shadow_joint_target_blur",
            str(args.azimuth_shadow_joint_target_blur),
            "--progress_interval",
            str(args.progress_interval),
            "--device",
            args.device,
            "--train_only",
        ]
        if shadow_train_mask_source_dir is not None:
            cmd += ["--train_mask_target_dir", str(shadow_train_mask_source_dir)]
        if azimuth_shadow_shape_prior_gt_dir is not None:
            cmd += ["--shadow_shape_prior_gt_dir", str(azimuth_shadow_shape_prior_gt_dir)]
        if azimuth_shadow_semantic_mask_dir is not None:
            cmd += ["--shadow_semantic_mask_dir", str(azimuth_shadow_semantic_mask_dir)]
        if bool(args.allow_tf32):
            cmd += ["--allow_tf32"]
        else:
            cmd += ["--no-allow_tf32"]
        if bool(args.cudnn_benchmark):
            cmd += ["--cudnn_benchmark"]
        else:
            cmd += ["--no-cudnn_benchmark"]
        if bool(args.azimuth_shadow_train_repair_empty_candidate):
            cmd += ["--shadow_train_repair_empty_candidate"]
        else:
            cmd += ["--no-shadow_train_repair_empty_candidate"]
        if bool(args.azimuth_shadow_fail_on_empty_supervision):
            cmd += ["--shadow_fail_on_empty_supervision"]
        else:
            cmd += ["--no-shadow_fail_on_empty_supervision"]
        if bool(args.azimuth_shadow_geometry_extent_gate):
            cmd += ["--shadow_geometry_extent_gate"]
        else:
            cmd += ["--no-shadow_geometry_extent_gate"]
        if bool(args.azimuth_shadow_geometry_extent_apply_to_recognition):
            cmd += ["--shadow_geometry_extent_apply_to_recognition"]
        else:
            cmd += ["--no-shadow_geometry_extent_apply_to_recognition"]
        if bool(args.azimuth_shadow_geometry_extent_require_dataset_direction):
            cmd += ["--shadow_geometry_extent_require_dataset_direction"]
        else:
            cmd += ["--no-shadow_geometry_extent_require_dataset_direction"]
        shadow_train_all = (
            bool(args.train_use_all_targets)
            if args.azimuth_shadow_train_use_all_targets is None
            else bool(args.azimuth_shadow_train_use_all_targets)
        )
        if shadow_train_all:
            cmd += ["--train_use_all_targets"]
        if bool(args.azimuth_shadow_gt_component_filter):
            cmd += ["--shadow_gt_component_filter"]
        else:
            cmd += ["--no-shadow_gt_component_filter"]
        if bool(args.azimuth_shadow_gt_use_global_direction):
            cmd += ["--shadow_gt_use_global_direction"]
        else:
            cmd += ["--no-shadow_gt_use_global_direction"]
        if bool(args.azimuth_shadow_gt_auto_fixed_direction_gate):
            cmd += ["--shadow_gt_auto_fixed_direction_gate"]
        else:
            cmd += ["--no-shadow_gt_auto_fixed_direction_gate"]
        if bool(args.azimuth_shadow_gt_use_fixed_direction_gate):
            cmd += ["--shadow_gt_use_fixed_direction_gate"]
        else:
            cmd += ["--no-shadow_gt_use_fixed_direction_gate"]
        if bool(args.azimuth_shadow_gt_fixed_direction_fallback):
            cmd += ["--shadow_gt_fixed_direction_fallback"]
        else:
            cmd += ["--no-shadow_gt_fixed_direction_fallback"]
        if bool(args.azimuth_shadow_include_target):
            cmd += ["--shadow_include_target"]
        else:
            cmd += ["--no-shadow_include_target"]
        if bool(args.azimuth_shadow_image_use_joint_mask):
            cmd += ["--shadow_image_use_joint_mask"]
        else:
            cmd += ["--no-shadow_image_use_joint_mask"]
        if bool(args.azimuth_shadow_image_include_full_target):
            cmd += ["--shadow_image_include_full_target"]
        else:
            cmd += ["--no-shadow_image_include_full_target"]
        if bool(args.azimuth_shadow_input_color_channels):
            cmd += ["--shadow_input_color_channels"]
        else:
            cmd += ["--no-shadow_input_color_channels"]
        if bool(args.azimuth_shadow_force_grayscale_output):
            cmd += ["--force_grayscale_output"]
        else:
            cmd += ["--no-force_grayscale_output"]
        if bool(args.azimuth_shadow_joint_mask_refiner):
            cmd += ["--shadow_joint_mask_refiner"]
        else:
            cmd += ["--no-shadow_joint_mask_refiner"]
        if bool(args.azimuth_shadow_joint_mask_bbox_fill):
            cmd += ["--shadow_joint_mask_bbox_fill"]
        else:
            cmd += ["--no-shadow_joint_mask_bbox_fill"]
        if bool(args.azimuth_shadow_target_mask_filter_largest_cc):
            cmd += ["--target_mask_filter_largest_cc"]
        else:
            cmd += ["--no-target_mask_filter_largest_cc"]
        use_fixed_shadow_direction = (
            str(args.azimuth_shadow_candidate_mode) in {"fixed_direction", "fixed_direction_prior"}
            or bool(args.azimuth_shadow_gt_use_fixed_direction_gate)
            or bool(args.azimuth_shadow_gt_fixed_direction_fallback)
        )
        if use_fixed_shadow_direction and args.azimuth_shadow_fixed_direction_deg is not None:
            cmd += ["--shadow_fixed_direction_deg", str(args.azimuth_shadow_fixed_direction_deg)]
        if args.azimuth_shadow_gt_global_direction_deg is not None:
            cmd += ["--shadow_gt_global_direction_deg", str(args.azimuth_shadow_gt_global_direction_deg)]
        if args.azimuth_shadow_gt_component_grow_threshold is not None:
            cmd += ["--shadow_gt_component_grow_threshold", str(args.azimuth_shadow_gt_component_grow_threshold)]
        cmd += ["--no-save_maps"]
        _run_recorded("train_azimuth_shadow", cmd, repo_root, executed_commands, dry_run=args.dry_run)

    background_after_shadow_pre_applied = False
    if (
        bool(args.enable_azimuth_shadow_refiner)
        and bool(getattr(args, "background_after_shadow", False))
        and args.stage in {"full_train", "apply", "apply_eval", "apply_shadow"}
    ):
        bg_ref_dir = (
            _resolve_user_path(args.background_after_shadow_reference_dir, launch_dir)
            if args.background_after_shadow_reference_dir
            else (train_gt_dir or azimuth_shadow_train_gt_dir)
        )
        if bg_ref_dir is None:
            raise RuntimeError("--background_after_shadow requires --train_gt_dir or --azimuth_shadow_train_gt_dir")
        bg_after_renders = background_after_shadow_output / "renders"
        bg_after_maps = background_after_shadow_output / "keep_masks"
        bg_data_dir = (
            _resolve_user_path(args.background_after_shadow_data_dir, launch_dir)
            if args.background_after_shadow_data_dir
            else None
        )
        cmd = [
            args.python,
            background_after_shadow_script,
            "--render_dir",
            str(final_render_dir),
            "--target_mask_dir",
            str(target_mask_dir),
            "--reference_dir",
            str(bg_ref_dir),
            "--output_dir",
            str(background_after_shadow_output),
            "--background_mode",
            str(args.background_after_shadow_background_mode),
            "--target_threshold",
            str(args.background_after_shadow_target_mask_threshold),
            "--target_dilate",
            str(args.background_after_shadow_target_mask_dilate),
            "--blend_dilate",
            str(args.background_after_shadow_blend_dilate),
            "--blend_blur",
            str(args.background_after_shadow_target_mask_blur),
            "--target_gap_dark_threshold",
            str(args.background_after_shadow_target_gap_dark_threshold),
            "--target_gap_edge_px",
            str(args.background_after_shadow_target_gap_edge_px),
            "--target_gap_shadow_protect_threshold",
            str(args.background_after_shadow_target_gap_shadow_protect_threshold),
            "--shadow_alpha_threshold",
            str(args.background_after_shadow_shadow_alpha_threshold),
            "--shadow_alpha_source",
            str(args.background_after_shadow_shadow_alpha_source),
            "--shadow_from_render_percentile",
            str(args.background_after_shadow_shadow_from_render_percentile),
            "--keep_dilate",
            str(args.background_after_shadow_union_mask_dilate),
            "--keep_blur",
            str(args.background_after_shadow_union_mask_blur),
            "--keep_gamma",
            str(args.background_after_shadow_union_mask_gamma),
            "--strength",
            str(args.background_after_shadow_strength),
            "--hard_target_copy" if bool(args.background_after_shadow_hard_target_copy) else "--no-hard_target_copy",
            "--target_copy_threshold",
            str(args.background_after_shadow_target_copy_threshold),
            "--hard_shadow_copy" if bool(args.background_after_shadow_hard_shadow_copy) else "--no-hard_shadow_copy",
            "--shadow_copy_threshold",
            str(args.background_after_shadow_shadow_copy_threshold),
            "--patch_size",
            str(args.empirical_background_patch_size),
            "--patch_overlap",
            str(args.empirical_background_patch_overlap),
            "--nearest_refs",
            str(args.background_after_shadow_nearest_refs),
            "--patch_smooth",
            str(args.empirical_background_patch_smooth),
            "--patch_smooth_mix",
            str(args.empirical_background_patch_smooth_mix),
            "--fallback_blur",
            str(args.background_after_shadow_fallback_blur),
            "--target_shadow_directional_grow",
            str(args.background_after_shadow_target_shadow_directional_grow),
            "--target_shadow_directional_strength",
            str(args.background_after_shadow_target_shadow_directional_strength),
            "--target_shadow_directional_blur",
            str(args.background_after_shadow_target_shadow_directional_blur),
            "--target_shadow_directional_intersect_shadow"
            if bool(args.background_after_shadow_target_shadow_directional_intersect_shadow)
            else "--no-target_shadow_directional_intersect_shadow",
            "--target_shadow_directional_use_render_intensity"
            if bool(args.background_after_shadow_target_shadow_directional_use_render_intensity)
            else "--no-target_shadow_directional_use_render_intensity",
            "--reference_exclude_dilate",
            str(args.background_after_shadow_reference_exclude_dilate),
            "--reference_clean_blend_refs",
            str(args.background_after_shadow_reference_clean_blend_refs),
            "--reference_clean_blend_mix",
            str(args.background_after_shadow_reference_clean_blend_mix),
            "--reference_clean_angle_sigma",
            str(args.background_after_shadow_reference_clean_angle_sigma),
            "--reference_clean_patch_mix",
            str(args.background_after_shadow_reference_clean_patch_mix),
            "--min_background_fraction",
            str(args.background_after_shadow_min_background_fraction),
            "--stat_match",
            str(args.background_after_shadow_stat_match),
            "--speckle_sigma",
            str(args.background_after_shadow_speckle_sigma),
            "--seed",
            str(getattr(args, "noise_seed", 1234)),
            "--semantic_target_labels",
            "1,2",
            "--semantic_hard_target_copy",
        ]
        if bg_data_dir is not None:
            cmd += ["--data_dir", str(bg_data_dir)]
        _run_recorded("background_before_azimuth_shadow", cmd, repo_root, executed_commands, dry_run=args.dry_run)
        final_render_dir = bg_after_renders
        background_after_shadow_pre_applied = True
        output_paths["background_after_shadow_renders"] = bg_after_renders
        output_paths["background_after_shadow_maps"] = bg_after_maps
        output_paths["background_after_shadow_index"] = background_after_shadow_output / "index.html"

    if bool(args.enable_azimuth_shadow_refiner) and args.stage in {"full_train", "apply", "apply_eval", "apply_shadow"}:
        cmd = [
            args.python,
            azimuth_shadow_script,
            "-m",
            str(model_path),
            "--apply_only",
            "--checkpoint",
            str(azimuth_shadow_checkpoint),
            "--render_dir",
            str(final_render_dir),
            "--apply_target_dir",
            str(target_mask_dir),
            "--target_mask_dir",
            str(target_mask_dir),
            "--output_dir",
            str(azimuth_shadow_output),
            "--apply_use_render_input" if bool(args.azimuth_shadow_apply_use_render_input) else "--no-apply_use_render_input",
            "--apply_mask_source",
            str(args.azimuth_shadow_apply_mask_source),
            "--model_base",
            str(args.azimuth_shadow_model_base),
            "--shadow_refine_mode",
            str(args.azimuth_shadow_refine_mode),
            "--shadow_candidate_mode",
            str(args.azimuth_shadow_candidate_mode),
            "--shadow_candidate_length",
            str(args.azimuth_shadow_candidate_length),
            "--shadow_candidate_decay",
            str(args.azimuth_shadow_candidate_decay),
            "--shadow_candidate_lateral_blur",
            str(args.azimuth_shadow_candidate_lateral_blur),
            "--shadow_target_protect_dilate",
            str(args.azimuth_shadow_target_protect_dilate),
            "--shadow_target_exclude_dilate",
            str(args.azimuth_shadow_target_exclude_dilate),
            "--shadow_direction_offset_deg",
            str(args.azimuth_shadow_direction_offset_deg),
            "--shadow_direction_sign",
            str(args.azimuth_shadow_direction_sign),
            "--shadow_shape_prior_mode",
            str(args.azimuth_shadow_shape_prior_mode),
            "--shadow_shape_prior_weight",
            str(args.azimuth_shadow_shape_prior_weight),
            "--shadow_shape_prior_threshold",
            str(args.azimuth_shadow_shape_prior_threshold),
            "--shadow_shape_prior_mix_mode",
            str(args.azimuth_shadow_shape_prior_mix_mode),
            "--shadow_shape_prior_min_pixels",
            str(args.azimuth_shadow_shape_prior_min_pixels),
            "--shadow_semantic_mask_run",
            str(args.azimuth_shadow_semantic_mask_run),
            "--shadow_supervision_source",
            str(args.azimuth_shadow_supervision_source),
            "--shadow_semantic_target_labels",
            str(args.azimuth_shadow_semantic_target_labels),
            "--shadow_semantic_shadow_label",
            str(args.azimuth_shadow_semantic_shadow_label),
            "--shadow_semantic_supervision_mix",
            str(args.azimuth_shadow_semantic_supervision_mix),
            "--shadow_semantic_dilate",
            str(args.azimuth_shadow_semantic_dilate),
            "--shadow_semantic_blur",
            str(args.azimuth_shadow_semantic_blur),
            "--target_mask_threshold",
            str(args.azimuth_shadow_target_mask_threshold),
            "--target_mask_quantile",
            str(args.azimuth_shadow_target_mask_quantile),
            "--target_mask_dilate",
            str(args.azimuth_shadow_target_mask_dilate),
            "--target_mask_min_pixels",
            str(args.azimuth_shadow_target_mask_min_pixels),
            "--shadow_train_target_mask_max_ratio",
            str(args.azimuth_shadow_train_target_mask_max_ratio),
            "--target_mask_mode",
            str(args.azimuth_shadow_target_mask_mode),
            "--target_mask_filter_percentile",
            str(args.azimuth_shadow_target_mask_filter_percentile),
            "--target_mask_filter_min_target_ratio",
            str(args.azimuth_shadow_target_mask_filter_min_target_ratio),
            "--target_mask_filter_max_target_ratio",
            str(args.azimuth_shadow_target_mask_filter_max_target_ratio),
            "--target_mask_filter_adaptive_max_percentile",
            str(args.azimuth_shadow_target_mask_filter_adaptive_max_percentile),
            "--target_mask_filter_erode_px",
            str(args.azimuth_shadow_target_mask_filter_erode_px),
            "--target_mask_visibility_refiner_percentile",
            str(args.azimuth_shadow_target_mask_visibility_refiner_percentile),
            "--target_mask_visibility_dilate",
            str(args.azimuth_shadow_target_mask_visibility_dilate),
            "--shadow_apply_strength",
            str(args.azimuth_shadow_apply_strength),
            "--shadow_apply_max_darken",
            str(args.azimuth_shadow_apply_max_darken),
            "--shadow_apply_mode",
            str(args.azimuth_shadow_apply_mode),
            "--shadow_apply_subtract",
            str(args.azimuth_shadow_apply_subtract),
            "--shadow_apply_ceiling",
            str(args.azimuth_shadow_apply_ceiling),
            "--shadow_carrier_background",
            str(args.shadow_carrier_background),
            "--shadow_carrier_value",
            str(args.shadow_carrier_value),
            "--shadow_carrier_color",
            str(args.shadow_carrier_color),
            "--shadow_carrier_target_dilate",
            str(args.shadow_carrier_target_dilate),
            "--shadow_carrier_target_blur",
            str(args.shadow_carrier_target_blur),
            "--shadow_image_support_dilate",
            str(args.azimuth_shadow_image_support_dilate),
            "--shadow_image_delta_log_scale",
            str(args.azimuth_shadow_image_delta_log_scale),
            "--shadow_image_bright_log_scale",
            str(args.azimuth_shadow_image_bright_log_scale),
            "--shadow_image_extinction_log_strength",
            str(args.azimuth_shadow_image_extinction_log_strength),
            "--shadow_image_compose_alpha_mode",
            str(args.azimuth_shadow_image_compose_alpha_mode),
            "--shadow_image_compose_alpha_threshold",
            str(args.azimuth_shadow_image_compose_alpha_threshold),
            "--shadow_image_compose_alpha_softness",
            str(args.azimuth_shadow_image_compose_alpha_softness),
            "--shadow_image_compose_alpha_floor",
            str(args.azimuth_shadow_image_compose_alpha_floor),
            "--shadow_image_compose_alpha_min_support_mean",
            str(args.azimuth_shadow_image_compose_alpha_min_support_mean),
            "--shadow_image_compose_blur",
            str(args.azimuth_shadow_image_compose_blur),
            "--shadow_image_detail_radius",
            str(args.azimuth_shadow_image_detail_radius),
            "--shadow_image_target_detail_preserve_weight",
            str(args.azimuth_shadow_image_target_detail_preserve_weight),
            "--shadow_image_shadow_detail_preserve_weight",
            str(args.azimuth_shadow_image_shadow_detail_preserve_weight),
            "--shadow_output_gain",
            str(args.azimuth_shadow_output_gain),
            "--shadow_candidate_prior_strength",
            str(args.azimuth_shadow_candidate_prior_strength),
            "--shadow_output_dilate",
            str(args.azimuth_shadow_output_dilate),
            "--shadow_output_blur",
            str(args.azimuth_shadow_output_blur),
            "--shadow_output_gamma",
            str(args.azimuth_shadow_output_gamma),
            "--shadow_output_mask_floor",
            str(args.azimuth_shadow_output_mask_floor),
            "--shadow_output_mask_threshold",
            str(args.azimuth_shadow_output_mask_threshold),
            "--shadow_recognition_source",
            str(args.azimuth_shadow_recognition_source),
            "--shadow_recognition_threshold",
            str(args.azimuth_shadow_recognition_threshold),
            "--shadow_recognition_connect_length",
            str(args.azimuth_shadow_recognition_connect_length),
            "--shadow_recognition_connect_decay",
            str(args.azimuth_shadow_recognition_connect_decay),
            "--shadow_recognition_connect_blur",
            str(args.azimuth_shadow_recognition_connect_blur),
            "--shadow_recognition_min_evidence",
            str(args.azimuth_shadow_recognition_min_evidence),
            "--shadow_recognition_reference_blur",
            str(args.azimuth_shadow_recognition_reference_blur),
            "--shadow_recognition_context_blur",
            str(args.azimuth_shadow_recognition_context_blur),
            "--shadow_recognition_reference_threshold",
            str(args.azimuth_shadow_recognition_reference_threshold),
            "--shadow_recognition_ratio_mix",
            str(args.azimuth_shadow_recognition_ratio_mix),
            "--shadow_recognition_gate_threshold",
            str(args.azimuth_shadow_recognition_gate_threshold),
            "--shadow_geometry_extent_forward_scale",
            str(args.azimuth_shadow_geometry_extent_forward_scale),
            "--shadow_geometry_extent_lateral_scale",
            str(args.azimuth_shadow_geometry_extent_lateral_scale),
            "--shadow_geometry_extent_margin_px",
            str(args.azimuth_shadow_geometry_extent_margin_px),
            "--shadow_geometry_extent_min_forward_px",
            str(args.azimuth_shadow_geometry_extent_min_forward_px),
            "--shadow_apply_feather_blur",
            str(args.azimuth_shadow_apply_feather_blur),
            "--shadow_apply_feather_core",
            str(args.azimuth_shadow_apply_feather_core),
            "--residual_layover_cleanup_strength",
            str(args.azimuth_shadow_residual_layover_cleanup_strength),
            "--residual_layover_cleanup_ceiling",
            str(args.azimuth_shadow_residual_layover_cleanup_ceiling),
            "--residual_layover_cleanup_blur",
            str(args.azimuth_shadow_residual_layover_cleanup_blur),
            "--shadow_target_overlap_weight",
            str(args.azimuth_shadow_target_overlap_weight),
            "--shadow_target_overlap_dark_threshold",
            str(args.azimuth_shadow_target_overlap_dark_threshold),
            "--shadow_target_overlap_quantile",
            str(args.azimuth_shadow_target_overlap_quantile),
            "--shadow_target_overlap_dilate",
            str(args.azimuth_shadow_target_overlap_dilate),
            "--shadow_joint_mask_threshold",
            str(args.azimuth_shadow_joint_mask_threshold),
            "--shadow_joint_mask_connect_radius",
            str(args.azimuth_shadow_joint_mask_connect_radius),
            "--shadow_joint_mask_dilate",
            str(args.azimuth_shadow_joint_mask_dilate),
            "--shadow_joint_mask_weight",
            str(args.azimuth_shadow_joint_mask_weight),
            "--shadow_joint_target_min_gap",
            str(args.azimuth_shadow_joint_target_min_gap),
            "--shadow_joint_target_softness",
            str(args.azimuth_shadow_joint_target_softness),
            "--shadow_joint_target_mix",
            str(args.azimuth_shadow_joint_target_mix),
            "--shadow_joint_target_blur",
            str(args.azimuth_shadow_joint_target_blur),
            "--shadow_pred_component_threshold",
            str(args.azimuth_shadow_pred_component_threshold),
            "--shadow_pred_global_direction_tolerance_deg",
            str(args.azimuth_shadow_pred_global_direction_tolerance_deg),
            "--shadow_pred_component_score_min",
            str(args.azimuth_shadow_pred_component_score_min),
            "--shadow_pred_min_component_area_ratio",
            str(args.azimuth_shadow_pred_min_component_area_ratio),
            "--shadow_pred_max_component_area_ratio",
            str(args.azimuth_shadow_pred_max_component_area_ratio),
            "--shadow_pred_min_component_pixels",
            str(args.azimuth_shadow_pred_min_component_pixels),
            "--shadow_pred_max_components",
            str(args.azimuth_shadow_pred_max_components),
            "--shadow_pred_direction_tolerance_deg",
            str(args.azimuth_shadow_pred_direction_tolerance_deg),
            "--shadow_pred_contact_dilate",
            str(args.azimuth_shadow_pred_contact_dilate),
            "--shadow_pred_component_open",
            str(args.azimuth_shadow_pred_component_open),
            "--shadow_pred_component_density_radius",
            str(args.azimuth_shadow_pred_component_density_radius),
            "--shadow_pred_component_min_density",
            str(args.azimuth_shadow_pred_component_min_density),
            "--shadow_pred_component_min_bbox_density",
            str(args.azimuth_shadow_pred_component_min_bbox_density),
            "--shadow_pred_component_grow",
            str(args.azimuth_shadow_pred_component_grow),
            "--shadow_pred_component_min_keep_ratio",
            str(args.azimuth_shadow_pred_component_min_keep_ratio),
            "--device",
            args.device,
        ]
        if azimuth_shadow_train_gt_dir is not None:
            cmd += ["--train_gt_dir", str(azimuth_shadow_train_gt_dir)]
        if azimuth_shadow_shape_prior_gt_dir is not None:
            cmd += ["--shadow_shape_prior_gt_dir", str(azimuth_shadow_shape_prior_gt_dir)]
        if azimuth_shadow_semantic_mask_dir is not None:
            cmd += ["--shadow_semantic_mask_dir", str(azimuth_shadow_semantic_mask_dir)]
        if azimuth_shadow_recognition_checkpoint is not None:
            cmd += ["--shadow_recognition_checkpoint", str(azimuth_shadow_recognition_checkpoint)]
        if azimuth_shadow_recognition_map_dir is not None:
            cmd += ["--shadow_recognition_map_dir", str(azimuth_shadow_recognition_map_dir)]
        if bool(args.azimuth_shadow_apply_recognition_mask):
            cmd += ["--shadow_apply_recognition_mask"]
        else:
            cmd += ["--no-shadow_apply_recognition_mask"]
        if bool(args.azimuth_shadow_geometry_extent_gate):
            cmd += ["--shadow_geometry_extent_gate"]
        else:
            cmd += ["--no-shadow_geometry_extent_gate"]
        if bool(args.azimuth_shadow_geometry_extent_apply_to_recognition):
            cmd += ["--shadow_geometry_extent_apply_to_recognition"]
        else:
            cmd += ["--no-shadow_geometry_extent_apply_to_recognition"]
        if bool(args.azimuth_shadow_geometry_extent_require_dataset_direction):
            cmd += ["--shadow_geometry_extent_require_dataset_direction"]
        else:
            cmd += ["--no-shadow_geometry_extent_require_dataset_direction"]
        if bool(args.azimuth_shadow_pred_component_filter):
            cmd += ["--shadow_pred_component_filter"]
        else:
            cmd += ["--no-shadow_pred_component_filter"]
        if bool(args.azimuth_shadow_include_target):
            cmd += ["--shadow_include_target"]
        else:
            cmd += ["--no-shadow_include_target"]
        if bool(args.azimuth_shadow_image_use_joint_mask):
            cmd += ["--shadow_image_use_joint_mask"]
        else:
            cmd += ["--no-shadow_image_use_joint_mask"]
        if bool(args.azimuth_shadow_image_include_full_target):
            cmd += ["--shadow_image_include_full_target"]
        else:
            cmd += ["--no-shadow_image_include_full_target"]
        if bool(args.azimuth_shadow_input_color_channels):
            cmd += ["--shadow_input_color_channels"]
        else:
            cmd += ["--no-shadow_input_color_channels"]
        if bool(args.azimuth_shadow_force_grayscale_output):
            cmd += ["--force_grayscale_output"]
        else:
            cmd += ["--no-force_grayscale_output"]
        if bool(args.azimuth_shadow_joint_mask_refiner):
            cmd += ["--shadow_joint_mask_refiner"]
        else:
            cmd += ["--no-shadow_joint_mask_refiner"]
        if bool(args.azimuth_shadow_joint_mask_bbox_fill):
            cmd += ["--shadow_joint_mask_bbox_fill"]
        else:
            cmd += ["--no-shadow_joint_mask_bbox_fill"]
        if bool(args.azimuth_shadow_target_mask_filter_largest_cc):
            cmd += ["--target_mask_filter_largest_cc"]
        else:
            cmd += ["--no-target_mask_filter_largest_cc"]
        use_fixed_shadow_direction = str(args.azimuth_shadow_candidate_mode) in {"fixed_direction", "fixed_direction_prior"}
        if use_fixed_shadow_direction and args.azimuth_shadow_fixed_direction_deg is not None:
            cmd += ["--shadow_fixed_direction_deg", str(args.azimuth_shadow_fixed_direction_deg)]
        if args.azimuth_shadow_pred_global_direction_deg is not None:
            cmd += ["--shadow_pred_global_direction_deg", str(args.azimuth_shadow_pred_global_direction_deg)]
        if args.azimuth_shadow_pred_component_grow_threshold is not None:
            cmd += ["--shadow_pred_component_grow_threshold", str(args.azimuth_shadow_pred_component_grow_threshold)]
        cmd += ["--save_maps" if bool(getattr(args, "background_after_shadow", False)) else "--no-save_maps"]
        _run_recorded("apply_azimuth_shadow", cmd, repo_root, executed_commands, dry_run=args.dry_run)
        shadow_render_dir = azimuth_shadow_output / "renders"
        final_shadow_source_dir = shadow_render_dir
        if bool(getattr(args, "azimuth_shadow_learned_intensity_prior", False)):
            if not bool(getattr(args, "background_after_shadow", False)):
                raise RuntimeError("--azimuth_shadow_learned_intensity_prior requires --background_after_shadow")
            if azimuth_shadow_semantic_mask_dir is None:
                raise RuntimeError("--azimuth_shadow_learned_intensity_prior requires semantic masks")
            if azimuth_shadow_train_gt_dir is None:
                raise RuntimeError("--azimuth_shadow_learned_intensity_prior requires --train_gt_dir or --azimuth_shadow_train_gt_dir")
            cmd = [
                args.python,
                shadow_intensity_prior_script,
                "--background_dir",
                str(final_render_dir),
                "--region_map_dir",
                str(azimuth_shadow_output / "maps"),
                "--gt_dir",
                str(azimuth_shadow_train_gt_dir),
                "--semantic_mask_dir",
                str(azimuth_shadow_semantic_mask_dir),
                "--semantic_mask_run",
                str(args.azimuth_shadow_semantic_mask_run),
                "--output_dir",
                str(azimuth_shadow_intensity_output),
                "--target_labels",
                str(args.azimuth_shadow_semantic_target_labels),
                "--shadow_label",
                str(args.azimuth_shadow_semantic_shadow_label),
                "--context_radius",
                str(args.azimuth_shadow_intensity_context_radius),
                "--block_radius",
                str(args.azimuth_shadow_intensity_block_radius),
                "--exclude_dilate",
                str(args.azimuth_shadow_intensity_exclude_dilate),
                "--strength",
                str(args.azimuth_shadow_intensity_strength),
                "--min_attenuation",
                str(args.azimuth_shadow_intensity_min_attenuation),
                "--max_attenuation",
                str(args.azimuth_shadow_intensity_max_attenuation),
                "--gamma",
                str(args.azimuth_shadow_intensity_gamma),
                "--min_context",
                str(args.azimuth_shadow_intensity_min_context),
                "--use_apply_alpha" if bool(args.azimuth_shadow_intensity_use_apply_alpha) else "--no-use_apply_alpha",
                "--hard_region" if bool(args.azimuth_shadow_intensity_hard_region) else "--no-hard_region",
            ]
            _run_recorded("apply_azimuth_shadow_intensity_prior", cmd, repo_root, executed_commands, dry_run=args.dry_run)
            final_shadow_source_dir = azimuth_shadow_intensity_output / "renders"
            output_paths["azimuth_shadow_intensity_prior"] = azimuth_shadow_intensity_output
            output_paths["azimuth_shadow_intensity_prior_renders"] = final_shadow_source_dir
            output_paths["azimuth_shadow_intensity_prior_maps"] = azimuth_shadow_intensity_output / "maps"
        if bool(getattr(args, "background_after_shadow", False)) and not background_after_shadow_pre_applied:
            bg_ref_dir = (
                _resolve_user_path(args.background_after_shadow_reference_dir, launch_dir)
                if args.background_after_shadow_reference_dir
                else (train_gt_dir or azimuth_shadow_train_gt_dir)
            )
            if bg_ref_dir is None:
                raise RuntimeError("--background_after_shadow requires --train_gt_dir or --azimuth_shadow_train_gt_dir")
            bg_after_renders = background_after_shadow_output / "renders"
            bg_after_maps = background_after_shadow_output / "keep_masks"
            bg_data_dir = (
                _resolve_user_path(args.background_after_shadow_data_dir, launch_dir)
                if args.background_after_shadow_data_dir
                else None
            )
            cmd = [
                args.python,
                background_after_shadow_script,
                "--render_dir",
                str(shadow_render_dir),
                "--target_mask_dir",
                str(target_mask_dir),
                "--shadow_map_dir",
                str(azimuth_shadow_output / "maps"),
                "--reference_dir",
                str(bg_ref_dir),
                "--output_dir",
                str(background_after_shadow_output),
                "--background_mode",
                str(args.background_after_shadow_background_mode),
                "--target_threshold",
                str(args.background_after_shadow_target_mask_threshold),
                "--target_dilate",
                str(args.background_after_shadow_target_mask_dilate),
                "--blend_dilate",
                str(args.background_after_shadow_blend_dilate),
                "--blend_blur",
                str(args.background_after_shadow_target_mask_blur),
                "--target_gap_dark_threshold",
                str(args.background_after_shadow_target_gap_dark_threshold),
                "--target_gap_edge_px",
                str(args.background_after_shadow_target_gap_edge_px),
                "--target_gap_shadow_protect_threshold",
                str(args.background_after_shadow_target_gap_shadow_protect_threshold),
                "--shadow_alpha_threshold",
                str(args.background_after_shadow_shadow_alpha_threshold),
                "--shadow_alpha_source",
                str(args.background_after_shadow_shadow_alpha_source),
                "--shadow_from_render_percentile",
                str(args.background_after_shadow_shadow_from_render_percentile),
                "--keep_dilate",
                str(args.background_after_shadow_union_mask_dilate),
                "--keep_blur",
                str(args.background_after_shadow_union_mask_blur),
                "--keep_gamma",
                str(args.background_after_shadow_union_mask_gamma),
                "--strength",
                str(args.background_after_shadow_strength),
                "--hard_target_copy" if bool(args.background_after_shadow_hard_target_copy) else "--no-hard_target_copy",
                "--target_copy_threshold",
                str(args.background_after_shadow_target_copy_threshold),
                "--hard_shadow_copy" if bool(args.background_after_shadow_hard_shadow_copy) else "--no-hard_shadow_copy",
                "--shadow_copy_threshold",
                str(args.background_after_shadow_shadow_copy_threshold),
                "--patch_size",
                str(args.empirical_background_patch_size),
                "--patch_overlap",
                str(args.empirical_background_patch_overlap),
                "--nearest_refs",
                str(args.background_after_shadow_nearest_refs),
                "--patch_smooth",
                str(args.empirical_background_patch_smooth),
                "--patch_smooth_mix",
                str(args.empirical_background_patch_smooth_mix),
                "--fallback_blur",
                str(args.background_after_shadow_fallback_blur),
                "--target_shadow_directional_grow",
                str(args.background_after_shadow_target_shadow_directional_grow),
                "--target_shadow_directional_strength",
                str(args.background_after_shadow_target_shadow_directional_strength),
                "--target_shadow_directional_blur",
                str(args.background_after_shadow_target_shadow_directional_blur),
                "--target_shadow_directional_intersect_shadow"
                if bool(args.background_after_shadow_target_shadow_directional_intersect_shadow)
                else "--no-target_shadow_directional_intersect_shadow",
                "--target_shadow_directional_use_render_intensity"
                if bool(args.background_after_shadow_target_shadow_directional_use_render_intensity)
                else "--no-target_shadow_directional_use_render_intensity",
                "--reference_exclude_dilate",
                str(args.background_after_shadow_reference_exclude_dilate),
                "--reference_clean_blend_refs",
                str(args.background_after_shadow_reference_clean_blend_refs),
                "--reference_clean_blend_mix",
                str(args.background_after_shadow_reference_clean_blend_mix),
                "--reference_clean_angle_sigma",
                str(args.background_after_shadow_reference_clean_angle_sigma),
                "--reference_clean_patch_mix",
                str(args.background_after_shadow_reference_clean_patch_mix),
                "--min_background_fraction",
                str(args.background_after_shadow_min_background_fraction),
                "--stat_match",
                str(args.background_after_shadow_stat_match),
                "--speckle_sigma",
                str(args.background_after_shadow_speckle_sigma),
                "--seed",
                str(getattr(args, "noise_seed", 1234)),
                "--semantic_target_labels",
                "1,2",
                "--semantic_hard_target_copy",
            ]
            if bg_data_dir is not None:
                cmd += ["--data_dir", str(bg_data_dir)]
            _run_recorded("background_after_shadow", cmd, repo_root, executed_commands, dry_run=args.dry_run)
            final_shadow_source_dir = bg_after_renders
            output_paths["background_after_shadow_renders"] = bg_after_renders
            output_paths["background_after_shadow_maps"] = bg_after_maps
            output_paths["background_after_shadow_index"] = background_after_shadow_output / "index.html"
        integrated_render_dir = apply_output / "renders"
        pre_shadow_backup_dir = apply_output / "renders_pre_shadow"
        staged_background_shadow_dir = stage03_dir / "apply_background_then_shadow" / "renders"
        if not bool(args.dry_run):
            staged_copied = _mirror_render_images(final_shadow_source_dir, staged_background_shadow_dir)
            print(f"[azimuth shadow] staged {staged_copied} shadow/background renders -> {staged_background_shadow_dir}")
            copied = _mirror_render_images(staged_background_shadow_dir, integrated_render_dir, backup_dir=pre_shadow_backup_dir)
            print(f"[azimuth shadow] synced {copied} staged renders -> {integrated_render_dir}")
            if pre_shadow_backup_dir.exists():
                print(f"[azimuth shadow] pre-shadow backup: {pre_shadow_backup_dir}")
        final_render_dir = integrated_render_dir
        output_paths["final_renders"] = final_render_dir
        output_paths["background_then_shadow_renders"] = staged_background_shadow_dir
        output_paths["azimuth_shadow_renders"] = shadow_render_dir
        output_paths["pre_shadow_renders"] = pre_shadow_backup_dir

    if args.stage == "postprocess":
        cmd = [
            args.python,
            postprocess_script,
            "--render_dir",
            str(apply_output / "renders"),
            "--output_dir",
            str(final_render_dir),
            "--target_mask_dir",
            str(target_mask_dir),
            "--target_source_dir",
            str(apply_output / "target_modulated_renders"),
            "--shadow_source_dir",
            str(apply_output / "target_modulated_renders"),
        ]
        cmd = _add_postprocess_defaults(cmd, args)
        _run_recorded("postprocess", cmd, repo_root, executed_commands, dry_run=args.dry_run)

    if args.stage in {"full_train", "eval", "apply_eval", "apply_shadow"}:
        if gt_dir is None:
            print("\n[eval] skipped: pass --gt_dir to compute PSNR/SSIM/SAR metrics.")
            eval_skipped_reason = "missing --gt_dir"
        else:
            def _base_eval_cmd(output_dir: Path, render_dir: Path | None = None) -> list[str]:
                cmd = [
                    args.python,
                    legacy_eval_script,
                    "--render_dir",
                    str(render_dir or final_render_dir),
                    "--gt_dir",
                    str(gt_dir),
                    "--output_dir",
                    str(output_dir),
                    "--device",
                    args.device,
                    "--sar_metrics",
                    "--sar_metric_log_scale",
                    "20",
                    "--sar_metric_smooth_radius",
                    "0",
                    "--sar_tolerant_radius",
                    str(args.sar_tolerant_radius),
                    "--azimuth_match_tolerance",
                    str(args.azimuth_match_tolerance),
                ]
                if args.view_split_train_angle_step:
                    cmd += ["--view_split_train_angle_step", str(args.view_split_train_angle_step)]
                if args.view_split_train_angles:
                    cmd += ["--view_split_train_angles", args.view_split_train_angles]
                if view_split_train_dir:
                    cmd += ["--view_split_train_dir", str(view_split_train_dir)]
                return cmd

            def _paper_eval_cmd(output_dir: Path, render_dir: Path | None = None) -> list[str]:
                return [
                    args.python,
                    paper_eval_script,
                    "--render_root",
                    str(render_dir or final_render_dir),
                    "--gt_root",
                    str(gt_dir),
                    "--output_dir",
                    str(output_dir),
                ]

            def _target_eval_cmd(output_dir: Path, render_dir: Path) -> list[str]:
                cmd = _base_eval_cmd(output_dir, render_dir=render_dir) + [
                    "--target_only",
                    "--target_mask_dir",
                    str(target_mask_dir),
                    "--target_mask_threshold",
                    "0.08",
                    "--target_mask_quantile",
                    "0.35",
                    "--target_mask_dilate",
                    "0",
                ]
                cmd.append("--visual_diagnosis" if bool(args.visual_diagnosis) else "--no-visual_diagnosis")
                return cmd

            eval_target_output = eval_output / "target"
            eval_target_shadow_output = eval_output / "target_shadow"
            eval_full_output = eval_output / "full"
            eval_intermediate_output = eval_output / "intermediate_debug"
            output_paths["eval_target"] = eval_target_output
            if bool(args.target_shadow_eval):
                output_paths["eval_target_shadow"] = eval_target_shadow_output
            output_paths["eval_full"] = eval_full_output
            output_paths["eval_intermediate_debug"] = eval_intermediate_output

            run_legacy_target_eval = bool(args.visual_diagnosis) or bool(args.target_shadow_eval)
            if run_legacy_target_eval:
                cmd = _target_eval_cmd(eval_target_output, final_render_dir)
                _run_recorded("eval_target", cmd, repo_root, executed_commands, dry_run=args.dry_run)
                eval_target_ran = not bool(args.dry_run)

            if bool(args.target_shadow_eval):
                cmd = _base_eval_cmd(eval_target_shadow_output) + [
                    "--target_shadow",
                    "--target_mask_dir",
                    str(target_mask_dir),
                    "--target_mask_threshold",
                    "0.08",
                    "--target_mask_quantile",
                    "0.35",
                    "--target_mask_dilate",
                    "0",
                    "--shadow_mask_source",
                    "union",
                    "--shadow_search_dilate",
                    str(args.shadow_search_dilate),
                    "--shadow_target_exclude_dilate",
                    "1",
                    "--shadow_dark_threshold",
                    "0.18",
                    "--shadow_dark_quantile",
                    "0.15",
                    "--shadow_mask_dilate",
                    "0",
                ]
                _run_recorded("eval_target_shadow", cmd, repo_root, executed_commands, dry_run=args.dry_run)
                eval_target_shadow_ran = not bool(args.dry_run)

            cmd = _paper_eval_cmd(eval_full_output)
            _run_recorded("eval_full", cmd, repo_root, executed_commands, dry_run=args.dry_run)
            eval_ran = not bool(args.dry_run)

            if bool(args.background_filtered_eval):
                if background_filtered_eval_gt_dir is None:
                    print("\n[background filtered eval] skipped: missing GT directory.")
                else:
                    cmd = [
                        args.python,
                        background_filtered_eval_script,
                        "--render_dir",
                        str(final_render_dir),
                        "--gt_dir",
                        str(background_filtered_eval_gt_dir),
                        "--output_dir",
                        str(background_filtered_eval_output_dir),
                        "--dataset",
                        str(dataset_name),
                        "--picture_root",
                        str(classification_label_output_dir / "background_filtered_picture"),
                        "--label_root",
                        str(classification_label_output_dir / "background_filtered_label"),
                        "--azimuth_match_tolerance",
                        str(args.azimuth_match_tolerance),
                        "--device",
                        args.device,
                        "--percentile",
                        str(args.background_filtered_eval_percentile),
                    ]
                    _run_recorded("background_filtered_eval", cmd, repo_root, executed_commands, dry_run=args.dry_run)
                    output_paths["background_filtered_eval"] = background_filtered_eval_output_dir

            if bool(args.intermediate_debug_eval):
                eval_intermediate_debug_ran = not bool(args.dry_run)
                intermediate_render_dirs = [
                    ("source_target", model_path / "novel_target_only" / "target_renders"),
                    ("refiner_target", apply_output / "target_modulated_renders"),
                    ("pre_shadow_renders", apply_output / "renders_pre_shadow"),
                    ("shadow_renders", azimuth_shadow_output / "renders"),
                    ("final_renders", final_render_dir),
                ]
                for label, render_dir in intermediate_render_dirs:
                    output_paths[f"eval_intermediate_{label}"] = eval_intermediate_output / label
                    if not bool(args.dry_run) and not render_dir.exists():
                        print(f"[intermediate debug] skipped {label}: missing {render_dir}")
                        continue
                    cmd = _target_eval_cmd(eval_intermediate_output / label, render_dir)
                    _run_recorded(
                        f"eval_intermediate_{label}",
                        cmd,
                        repo_root,
                        executed_commands,
                        dry_run=args.dry_run,
                    )

            if bool(args.refiner_delta_eval):
                cmd = [
                    args.python,
                    delta_eval_script,
                    "--source_target_dir",
                    str(model_path / "novel_target_only" / "target_renders"),
                    "--refiner_target_dir",
                    str(apply_output / "target_modulated_renders"),
                    "--final_render_dir",
                    str(final_render_dir),
                    "--gt_dir",
                    str(gt_dir),
                    "--output_dir",
                    str(delta_output),
                    "--target_mask_dir",
                    str(target_mask_dir),
                    "--target_mask_threshold",
                    "0.08",
                    "--target_mask_quantile",
                    "0.35",
                    "--target_mask_dilate",
                    "0",
                    "--log_scale",
                    "20",
                    "--delta_threshold",
                    "0.025",
                    "--save_panels",
                ]
                _run_recorded("refiner_delta", cmd, repo_root, executed_commands, dry_run=args.dry_run)

            if bool(args.adjacent_similarity_eval):
                cmd = [
                    args.python,
                    adjacent_eval_script,
                    "--render_dir",
                    str(final_render_dir),
                    "--output_dir",
                    str(adjacent_output),
                    "--threshold",
                    str(args.adjacent_similarity_threshold),
                    "--severe_threshold",
                    str(args.adjacent_similarity_severe_threshold),
                    "--log_scale",
                    "20",
                    "--target_threshold",
                    "0.012",
                    "--target_quantile",
                    "0.85",
                    "--target_dilate",
                    "2",
                    "--bbox_margin",
                    "12",
                ]
                _run_recorded("adjacent_similarity", cmd, repo_root, executed_commands, dry_run=args.dry_run)

    if bool(args.export_classification_labels):
        cmd = [
            args.python,
            classification_export_script,
            "--model_path",
            str(model_path),
            "--run_dir",
            str(work_dir),
            "--target_dir",
            str(target_mask_dir),
            "--image_dir",
            str(final_render_dir),
            "--gt_dir",
            str(train_gt_dir or gt_dir or _default_train_gt_dir(repo_root, model_path)),
            "--output_dir",
            str(classification_label_output_dir),
            "--classification_root",
            str(classification_root),
            "--source",
            str(args.classification_source),
            "--mask_root_name",
            "mask_label",
            "--azimuth_match_tolerance",
            str(args.azimuth_match_tolerance),
            "--percentile",
            str(args.azimuth_shadow_target_mask_filter_percentile),
            "--threshold",
            str(args.azimuth_shadow_target_mask_threshold),
            "--quantile",
            str(args.azimuth_shadow_target_mask_quantile),
            "--min_pixels",
            str(args.azimuth_shadow_target_mask_min_pixels),
            "--copy_original_images",
            "--no-write_class_txt",
        ]
        _run_recorded("export_classification_labels", cmd, repo_root, executed_commands, dry_run=args.dry_run)

        voc_cmd = [
            args.python,
            classification_voc_export_script,
            "--run_dir",
            str(classification_label_output_dir),
            "--source",
            str(args.classification_source),
            "--image_dir",
            str(classification_label_output_dir / "picture" / str(args.classification_source)),
            "--mask_dir",
            str(classification_label_output_dir / "mask_label" / str(args.classification_source)),
            "--output_dir",
            str(classification_label_output_dir / "label" / str(args.classification_source)),
            "--manifest_name",
            "voc_export_manifest.json",
        ]
        _run_recorded("export_voc_classification_labels", voc_cmd, repo_root, executed_commands, dry_run=args.dry_run)

    if eval_skipped_reason:
        output_paths["eval_skipped_reason"] = eval_skipped_reason

    timing_summary = _summarize_stage_timings(
        executed_commands,
        total_sec=time.perf_counter() - pipeline_start,
    )
    _print_timing_summary(timing_summary)

    result_run_dir = None
    if bool(args.record_results):
        result_run_dir = _write_run_archive(
            args,
            model_path=model_path,
            work_dir=work_dir,
            result_root=result_root,
            eval_output=eval_output,
            delta_output=delta_output if bool(args.refiner_delta_eval) else None,
            adjacent_output=adjacent_output if bool(args.adjacent_similarity_eval) else None,
            eval_ran=eval_ran,
            output_paths=output_paths,
            executed_commands=executed_commands,
            timing_summary=timing_summary,
            dry_run=args.dry_run,
        )
        print(f"\n[result archive] {result_run_dir}")

    metric_summary = {} if args.dry_run or not eval_ran else _load_metric_summary(eval_output)
    _print_metric_broadcast(metric_summary, eval_skipped_reason)

    print("\n[pipeline outputs]")
    print(f"  base checkpoint : {base_checkpoint}")
    print(f"  base apply      : {base_output}")
    print(f"  base post       : {base_post_output}")
    print(f"  bg checkpoint   : {bg_checkpoint}")
    print(f"  bg apply        : {bg_output}")
    print(f"  bg post         : {bg_post_output}")
    if bool(args.enable_azimuth_shadow_refiner):
        print(f"  shadow ckpt     : {azimuth_shadow_checkpoint}")
        print(f"  shadow apply    : {azimuth_shadow_output}")
    print(f"  final apply     : {apply_output}")
    print(f"  final renders   : {final_render_dir}")
    print(f"  eval            : {eval_output}")
    if eval_ran:
        if eval_target_ran:
            print(f"    target        : {eval_output / 'target'}")
        if eval_target_shadow_ran:
            print(f"    target+shadow : {eval_output / 'target_shadow'}")
        print(f"    global        : {eval_output / 'full'}")
        if eval_intermediate_debug_ran:
            print(f"    intermediate  : {eval_output / 'intermediate_debug'}")
    print(f"  adjacent sim    : {adjacent_output}")
    if bool(args.export_classification_labels):
        print(f"  class masks     : {classification_label_output_dir / 'mask_label'}")
        print(f"  class VOC labels: {classification_label_output_dir / 'label'}")
        print(f"  class images    : {classification_label_output_dir / 'picture'}")
        print(f"  class csv       : {classification_label_output_dir / 'mstar-exp'}")
    if result_run_dir is not None:
        print(f"  result archive  : {result_run_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
