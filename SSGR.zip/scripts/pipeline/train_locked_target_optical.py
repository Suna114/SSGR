#!/usr/bin/env python3
"""
Train a target-only optical 3DGS model on SAR-like top-down views.

This entry is for the workflow where SAR images are treated as top-down optical
views. Geometry is trainable by default so the result can support novel-view
rendering; use --freeze_geometry only for a pure appearance fine-tune.
"""

from __future__ import annotations

import os
import random
import sys
import argparse
from argparse import ArgumentParser, Namespace
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import torchvision
from tqdm import tqdm

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from arguments import ModelParams, OptimizationParams, PipelineParams
from gaussian_renderer import render
from scene import GaussianModel, Scene
from utils.general_utils import safe_state
from utils.graphics_utils import geom_transform_points

try:
    from diff_gaussian_rasterization import SparseGaussianAdam

    SPARSE_ADAM_AVAILABLE = True
except Exception:
    SPARSE_ADAM_AVAILABLE = False


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}


def _count_images(path: str | os.PathLike) -> int:
    p = Path(path)
    if not p.is_dir():
        return 0
    return sum(1 for child in p.iterdir() if child.is_file() and child.suffix.lower() in IMAGE_EXTS)


def _images_dir_for_arg(source_path: str | os.PathLike, images_arg: str) -> Path:
    image_dir = Path(images_arg).expanduser()
    if image_dir.is_absolute():
        return image_dir
    return Path(source_path) / image_dir


def _resolve_training_images_arg(args) -> None:
    requested = str(getattr(args, "images", "") or "images")
    requested_dir = _images_dir_for_arg(args.source_path, requested)
    if _count_images(requested_dir) > 0:
        return

    for fallback in ("images", "input"):
        if fallback == requested:
            continue
        fallback_dir = Path(args.source_path) / fallback
        if _count_images(fallback_dir) > 0:
            print(
                "[images] requested image directory has no images: "
                f"{requested_dir}; using '{fallback}' instead."
            )
            args.images = fallback
            return

    raise FileNotFoundError(
        "No training images found for --images "
        f"'{requested}' under {args.source_path}. Checked {requested_dir}, "
        f"{Path(args.source_path) / 'images'}, and {Path(args.source_path) / 'input'}."
    )


def _load_convert_masks(source_path: str, images_subdir: str, run_id: str | None):
    images_folder = os.path.join(source_path, images_subdir or "images")
    try:
        from sar.semantic_mask_config import load_convert_scattering_masks
    except Exception as e:
        print(f"[target mask] 无法导入 convert mask loader: {e}")
        return None, None
    loaded = load_convert_scattering_masks(source_path, images_folder, run_id=run_id)
    if loaded is None:
        print("[target mask] 未加载 convert scattering mask，将用图像亮度阈值回退。")
        return None, None
    masks, cache_dir = loaded
    print(f"[target mask] 已加载 convert mask: {cache_dir} ({len(masks)} 张)")
    return masks, cache_dir


def _mask_for_camera(cam, masks: dict | None, gt_image: torch.Tensor, threshold: float) -> torch.Tensor:
    h, w = gt_image.shape[-2], gt_image.shape[-1]
    mask = None
    if masks:
        name = os.path.basename(getattr(cam, "image_name", ""))
        stem = os.path.splitext(name)[0]
        if name in masks:
            mask = masks[name]
        elif stem in masks:
            mask = masks[stem]
        else:
            for k, v in masks.items():
                if os.path.splitext(os.path.basename(k))[0] == stem:
                    mask = v
                    break
    if mask is not None:
        m = torch.as_tensor(mask, dtype=torch.float32, device=gt_image.device)
        if m.shape != (h, w):
            m = F.interpolate(m[None, None], size=(h, w), mode="nearest").squeeze()
        # 1=target interior, 2=edge. Keep both; ignore background/shadow.
        return ((m == 1) | (m == 2)).float()

    gray = gt_image[:3].mean(dim=0)
    m = (gray > float(threshold)).float()
    if int(m.sum().item()) < 16:
        q = torch.quantile(gray.reshape(-1), 0.90)
        m = (gray >= q).float()
    return m


def _dilate_mask(mask: torch.Tensor, iterations: int) -> torch.Tensor:
    if iterations <= 0:
        return mask.float()
    x = mask.float()[None, None]
    for _ in range(int(iterations)):
        x = F.max_pool2d(x, kernel_size=3, stride=1, padding=1)
    return x[0, 0].clamp(0.0, 1.0)


def _masked_mean(x: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    while mask.dim() < x.dim():
        mask = mask.unsqueeze(0)
    return (x * mask).sum() / mask.sum().clamp_min(eps)


def _masked_std(x: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    mean = _masked_mean(x, mask, eps)
    while mask.dim() < x.dim():
        mask = mask.unsqueeze(0)
    var = (((x - mean) ** 2) * mask).sum() / mask.sum().clamp_min(eps)
    return torch.sqrt(var.clamp_min(eps))


def _sobel_magnitude(gray: torch.Tensor) -> torch.Tensor:
    kx = torch.tensor(
        [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]],
        dtype=gray.dtype,
        device=gray.device,
    )[None, None]
    ky = torch.tensor(
        [[-1.0, -2.0, -1.0], [0.0, 0.0, 0.0], [1.0, 2.0, 1.0]],
        dtype=gray.dtype,
        device=gray.device,
    )[None, None]
    x = gray[None, None]
    gx = F.conv2d(x, kx, padding=1)
    gy = F.conv2d(x, ky, padding=1)
    return torch.sqrt(gx * gx + gy * gy + 1e-8)[0, 0]


def _set_appearance_learning_rates(gaussians: GaussianModel, args) -> None:
    wanted = {
        "f_dc": float(args.appearance_feature_lr),
        "f_rest": float(args.appearance_rest_lr),
        "opacity": float(args.appearance_opacity_lr),
    }
    for group in gaussians.optimizer.param_groups:
        name = group.get("name")
        if name in wanted:
            group["lr"] = wanted[name]


def _configure_torch_runtime(args) -> None:
    if not torch.cuda.is_available():
        return
    allow_tf32 = bool(getattr(args, "allow_tf32", True))
    if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
        torch.backends.cuda.matmul.allow_tf32 = allow_tf32
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.allow_tf32 = allow_tf32
        torch.backends.cudnn.benchmark = bool(getattr(args, "cudnn_benchmark", True))
    try:
        torch.set_float32_matmul_precision("high" if allow_tf32 else "highest")
    except Exception:
        pass


def _coerce_index_tensor(idx) -> torch.Tensor:
    if idx is None:
        return torch.empty(0, dtype=torch.long, device="cuda")
    if isinstance(idx, torch.Tensor):
        if idx.numel() == 0:
            return torch.empty(0, dtype=torch.long, device=idx.device)
        return idx.reshape(-1).long()
    return torch.as_tensor(idx, dtype=torch.long, device="cuda").reshape(-1)


def _normalize_index(idx, n: int) -> torch.Tensor:
    flat = _coerce_index_tensor(idx)
    if n <= 0 or flat.numel() == 0:
        return torch.empty(0, dtype=torch.long, device=flat.device)
    valid = (flat >= 0) & (flat < n)
    return flat[valid]


def _align_radii(radii: torch.Tensor, n: int) -> torch.Tensor:
    flat = radii.reshape(-1)
    if flat.numel() == n:
        return flat
    if flat.numel() > n:
        return flat[:n]
    return torch.cat([flat, flat.new_zeros(n - flat.numel())], dim=0)


def _update_densification_stats(gaussians: GaussianModel, render_pkg: dict) -> None:
    viewspace_points = render_pkg.get("viewspace_points")
    radii = render_pkg.get("radii")
    visibility_filter = render_pkg.get("visibility_filter")
    if viewspace_points is None or radii is None:
        return
    gaussians.ensure_densification_buffers()
    n = int(gaussians.get_xyz.shape[0])
    n_vs = int(viewspace_points.shape[0])
    n_eff = min(n, n_vs, int(gaussians.xyz_gradient_accum.shape[0]))
    if n_eff <= 0:
        return
    vf = torch.unique(_normalize_index(visibility_filter, n_eff))
    if vf.numel() == 0:
        return
    r = _align_radii(radii, n_eff)
    gaussians.max_radii2D[vf] = torch.max(gaussians.max_radii2D[vf], r[vf])
    gaussians.add_densification_stats(viewspace_points, vf)


def _project_points_to_camera(xyz: torch.Tensor, cam):
    p = geom_transform_points(xyz, cam.full_proj_transform)
    x = ((p[:, 0] + 1.0) * 0.5 * float(cam.image_width)).long()
    y = ((1.0 - p[:, 1]) * 0.5 * float(cam.image_height)).long()
    visible = (
        (p[:, 2] > -1.0)
        & (p[:, 2] < 1.0)
        & (x >= 0)
        & (x < int(cam.image_width))
        & (y >= 0)
        & (y < int(cam.image_height))
    )
    return x, y, visible


def _prune_gaussians_by_multiview_target_masks(
    gaussians: GaussianModel,
    train_cams,
    masks: dict | None,
    args,
) -> None:
    if not bool(args.post_prune_by_mask):
        return
    if gaussians.get_xyz.shape[0] == 0:
        return
    xyz = gaussians.get_xyz.detach()
    n = int(xyz.shape[0])
    observed = torch.zeros((n,), dtype=torch.float32, device=xyz.device)
    inside = torch.zeros((n,), dtype=torch.float32, device=xyz.device)
    for cam in train_cams:
        gt = cam.original_image[:3].cuda().clamp(0.0, 1.0)
        m = _mask_for_camera(cam, masks, gt, float(args.fallback_target_threshold))
        m = _dilate_mask(m, int(args.post_prune_mask_dilate))
        x, y, visible = _project_points_to_camera(xyz, cam)
        if not bool(visible.any().item()):
            continue
        idx = torch.nonzero(visible, as_tuple=False).reshape(-1)
        observed[idx] += 1.0
        inside[idx] += m[y[idx], x[idx]]

    min_views = float(args.post_prune_min_views)
    ratio = inside / observed.clamp_min(1.0)
    enough = observed >= min_views
    prune = enough & (ratio < float(args.post_prune_min_inside_ratio))

    # Keep very opaque points that were barely observed only if the projection
    # test is inconclusive. Points repeatedly observed outside the target masks
    # are precisely the boundary leakage we want to remove.
    n_prune = int(prune.sum().item())
    if n_prune <= 0:
        print("[post-prune] no mask-inconsistent Gaussians removed")
        return
    before = int(gaussians.get_xyz.shape[0])
    tmp_radii = getattr(gaussians, "tmp_radii", None)
    if tmp_radii is None or tmp_radii.shape[0] != before:
        gaussians.tmp_radii = torch.zeros((before,), dtype=torch.float32, device=xyz.device)
    gaussians.prune_points(prune)
    after = int(gaussians.get_xyz.shape[0])
    print(
        f"[post-prune] removed {before - after}/{before} Gaussians "
        f"(inside_ratio < {float(args.post_prune_min_inside_ratio):g}, "
        f"observed >= {int(args.post_prune_min_views)} views)"
    )


def _freeze_geometry(gaussians: GaussianModel) -> None:
    for p in (gaussians._xyz, gaussians._scaling, gaussians._rotation):
        p.requires_grad_(False)
    for group in gaussians.optimizer.param_groups:
        if group.get("name") in {"xyz", "scaling", "rotation"}:
            group["lr"] = 0.0


def _zero_geometry_grads(gaussians: GaussianModel) -> None:
    for p in (gaussians._xyz, gaussians._scaling, gaussians._rotation):
        if p.grad is not None:
            p.grad = None


def _halo_args_from_train_args(args) -> Namespace:
    return Namespace(
        target_halo_suppress_strength=float(args.target_halo_suppress_strength),
        target_halo_threshold=float(args.target_halo_threshold),
        target_halo_quantile=float(args.target_halo_quantile),
        target_halo_dilate=int(args.target_halo_dilate),
        target_halo_soft_radius=int(args.target_halo_soft_radius),
        target_halo_black_floor=float(args.target_halo_black_floor),
    )


def _suppress_render_halo(image: torch.Tensor, halo_args: Namespace) -> torch.Tensor:
    try:
        from scripts.rendering.render_novel_optical_sar_like import suppress_target_halo
    except Exception:
        return image.clamp(0.0, 1.0)
    return suppress_target_halo(image, halo_args).clamp(0.0, 1.0)


def _render_training_views(scene, gaussians, pipeline, out_dir: Path, use_trained_exp: bool, args) -> None:
    renders_dir = out_dir / "train_renders"
    gt_dir = out_dir / "train_gt"
    renders_dir.mkdir(parents=True, exist_ok=True)
    gt_dir.mkdir(parents=True, exist_ok=True)
    background = torch.tensor([0.0, 0.0, 0.0], dtype=torch.float32, device="cuda")
    cams = list(scene.getTrainCameras() or [])
    halo_args = _halo_args_from_train_args(args)
    with torch.inference_mode():
        for idx, cam in enumerate(tqdm(cams, desc="render target train views", unit="img")):
            pkg = render(
                cam,
                gaussians,
                pipeline,
                background,
                use_trained_exp=use_trained_exp,
                separate_sh=SPARSE_ADAM_AVAILABLE,
                sar_mode=False,
            )
            name = os.path.splitext(os.path.basename(getattr(cam, "image_name", f"{idx:05d}")))[0] + ".png"
            image = _suppress_render_halo(pkg["render"].clamp(0.0, 1.0), halo_args)
            torchvision.utils.save_image(image, str(renders_dir / name))
            torchvision.utils.save_image(cam.original_image[:3].clamp(0.0, 1.0), str(gt_dir / name))


def _render_novel_target_views_after_train(args, model_params, pipeline_params) -> None:
    try:
        from scripts.rendering.render_novel_optical_sar_like import render_novel_views
    except Exception as e:
        print(f"[novel render] skipped: could not import renderer: {e}")
        return

    out_dir = args.novel_output_dir or os.path.join(
        model_params.model_path,
        "novel_sar_like" if bool(args.novel_sar_like) else "novel_target_only",
    )
    render_args = Namespace(
        iteration=int(args.iterations),
        output_dir=out_dir,
        azimuths=str(args.novel_azimuths or ""),
        azimuth_start=int(args.novel_azimuth_start),
        azimuth_end=int(args.novel_azimuth_end),
        azimuth_step=int(args.novel_azimuth_step),
        azimuth_offset_deg=float(args.novel_azimuth_offset_deg),
        depression_angle=float(args.novel_depression_angle),
        novel_pose_mode=str(args.novel_pose_mode),
        colmap_track_nearest_only=bool(args.novel_colmap_track_nearest_only),
        colmap_track_azimuth_space=str(args.novel_colmap_track_azimuth_space),
        orbit_stat="median",
        override_radius=None,
        override_height=None,
        mask_threshold=float(args.novel_mask_threshold),
        mask_quantile=float(args.novel_mask_quantile),
        mask_dilate=int(args.novel_mask_dilate),
        mask_blur_radius=int(args.novel_mask_blur_radius),
        shadow_source_dilate=int(args.novel_shadow_source_dilate),
        target_shadow_gap=int(args.novel_target_shadow_gap),
        target_preserve_strength=float(args.novel_target_preserve_strength),
        target_preserve_threshold=float(args.novel_target_preserve_threshold),
        target_preserve_blur_radius=int(args.novel_target_preserve_blur_radius),
        background_level=float(args.novel_background_level),
        background_texture=float(args.novel_background_texture),
        auto_background_from_train=bool(args.novel_auto_background_from_train),
        auto_background_level_quantile=float(args.novel_auto_background_level_quantile),
        auto_background_texture_scale=float(args.novel_auto_background_texture_scale),
        auto_background_exclude_dilate=int(args.novel_auto_background_exclude_dilate),
        auto_background_max_samples=int(args.novel_auto_background_max_samples),
        auto_background_fallback_target_threshold=float(args.fallback_target_threshold),
        auto_background_print=True,
        speckle_strength=float(args.novel_speckle_strength),
        speckle_looks=int(args.novel_speckle_looks),
        shadow_length_frac=float(args.novel_shadow_length_frac),
        shadow_decay_frac=float(args.novel_shadow_decay_frac),
        shadow_blur_radius=int(args.novel_shadow_blur_radius),
        shadow_strength=float(args.novel_shadow_strength),
        shadow_angle_offset=float(args.novel_shadow_angle_offset),
        layover_threshold=float(args.novel_layover_threshold),
        layover_length_frac=float(args.novel_layover_length_frac),
        layover_blur_radius=int(args.novel_layover_blur_radius),
        layover_strength=float(args.novel_layover_strength),
        gamma=float(args.novel_gamma),
        seed=int(args.novel_seed),
        target_halo_suppress_strength=float(args.target_halo_suppress_strength),
        target_halo_threshold=float(args.target_halo_threshold),
        target_halo_quantile=float(args.target_halo_quantile),
        target_halo_dilate=int(args.target_halo_dilate),
        target_halo_soft_radius=int(args.target_halo_soft_radius),
        target_halo_black_floor=float(args.target_halo_black_floor),
        target_only=not bool(args.novel_sar_like),
        save_masks=bool(args.novel_save_masks),
        quiet=bool(args.quiet),
    )
    print("=" * 78)
    print("Rendering integrated novel target views")
    print("=" * 78)
    print(f"output: {out_dir}")
    if render_args.azimuths:
        azimuth_summary = f"azimuths: {render_args.azimuths}"
    else:
        azimuth_summary = (
            f"azimuth: {render_args.azimuth_start}..{render_args.azimuth_end - render_args.azimuth_step} "
            f"step={render_args.azimuth_step}"
        )
    print(
        f"{azimuth_summary}; pose={render_args.novel_pose_mode}; "
        f"mode={'SAR-like full image' if bool(args.novel_sar_like) else 'target-only'}; "
        f"halo_threshold={render_args.target_halo_threshold:g}"
    )
    render_novel_views(render_args, model_params, pipeline_params)


def train_locked_target(args, model_params, opt, pipeline_params) -> None:
    # This script is deliberately optical-only. SAR mode would attach SAR
    # projection matrices to Camera and defeat the "top-down optical" assumption.
    model_params.sar_mode = False
    args.sar_mode = False
    os.makedirs(model_params.model_path, exist_ok=True)
    cfg_dump = vars(args).copy()
    cfg_dump["sar_mode"] = False
    with open(os.path.join(model_params.model_path, "cfg_args"), "w", encoding="utf-8") as f:
        f.write(str(Namespace(**cfg_dump)))

    gaussians = GaussianModel(model_params.sh_degree)
    scene = Scene(model_params, gaussians, load_iteration=None, shuffle=False)

    if args.init_gaussian_ply:
        init_path = os.path.abspath(args.init_gaussian_ply)
        print(f"[init] 用已有 Gaussian PLY 覆盖初始化: {init_path}")
        gaussians.load_ply(init_path, getattr(model_params, "train_test_exp", False))
        gaussians.max_radii2D = torch.zeros((gaussians.get_xyz.shape[0]), device="cuda")

    if args.full_sh_from_start:
        gaussians.active_sh_degree = gaussians.max_sh_degree

    # Geometry is trainable by default. For short 500-iteration target runs, make
    # densification start earlier than the generic 3DGS defaults unless the user
    # explicitly asks to freeze geometry.
    opt.iterations = int(args.iterations)
    gaussians.training_setup(opt)
    if args.freeze_geometry:
        opt.densify_until_iter = 0
        for group in gaussians.optimizer.param_groups:
            if group.get("name") in {"xyz", "scaling", "rotation"}:
                group["lr"] = 0.0
        _freeze_geometry(gaussians)
    _set_appearance_learning_rates(gaussians, args)

    masks, _cache_dir = (None, None)
    if not args.no_convert_target_masks:
        masks, _cache_dir = _load_convert_masks(
            model_params.source_path,
            model_params.images,
            args.scattering_masks_run,
        )

    train_cams = list(scene.getTrainCameras() or [])
    if not train_cams:
        raise RuntimeError("No training cameras found")

    bg = torch.tensor([0.0, 0.0, 0.0], dtype=torch.float32, device="cuda")
    initial_xyz = gaussians.get_xyz.detach().clone()
    initial_scaling = gaussians.get_scaling.detach().clone()
    initial_rotation = gaussians._rotation.detach().clone()
    initial_count = int(initial_xyz.shape[0])
    initial_extent = (initial_xyz.max(dim=0).values - initial_xyz.min(dim=0).values).clamp_min(1e-6)
    initial_extent_norm = torch.linalg.norm(initial_extent).clamp_min(1e-6)

    print("=" * 78)
    print("Target optical/SAR-look training")
    print("=" * 78)
    print(f"source: {model_params.source_path}")
    print(f"model:  {model_params.model_path}")
    print(f"iterations: {opt.iterations}")
    print(f"gaussians: {gaussians.get_xyz.shape[0]}")
    print(
        "geometry: "
        + (
            "frozen"
            if args.freeze_geometry
            else (
                f"trainable, xyz_lr={float(opt.position_lr_init):g}->{float(opt.position_lr_final):g}, "
                f"scaling_lr={float(opt.scaling_lr):g}, rotation_lr={float(opt.rotation_lr):g}"
            )
        )
    )
    print(
        "densify: "
        + (
            "disabled"
            if args.freeze_geometry or int(opt.densify_until_iter) <= 0
            else (
                f"from={int(opt.densify_from_iter)}, until={int(opt.densify_until_iter)}, "
                f"interval={int(opt.densification_interval)}, grad={float(opt.densify_grad_threshold):g}"
            )
        )
    )
    print(
        "appearance lr: "
        f"f_dc={float(args.appearance_feature_lr):g}, "
        f"f_rest={float(args.appearance_rest_lr):g}, "
        f"opacity={float(args.appearance_opacity_lr):g}"
    )
    print(
        "loss weights: "
        f"bright={float(args.target_bright_weight):g}, "
        f"gradient={float(args.target_gradient_weight):g}, "
        f"contrast={float(args.target_contrast_weight):g}, "
        f"silhouette={float(args.silhouette_weight):g}/every {int(args.silhouette_interval)}"
    )
    if float(args.max_gaussian_scale) > 0.0:
        print(
            f"scale control: max_gaussian_scale={float(args.max_gaussian_scale):g}, "
            f"scale_cap_weight={float(args.scale_cap_weight):g}"
        )
    print("SAR renderer/background-shadow logic disabled; target geometry is not locked unless requested")
    print("=" * 78)

    ema = None
    pbar = tqdm(range(1, opt.iterations + 1), desc="target train")
    for iteration in pbar:
        if not args.freeze_geometry:
            gaussians.update_learning_rate(iteration)
        cam = random.choice(train_cams)
        render_pkg = render(
            cam,
            gaussians,
            pipeline_params,
            bg,
            use_trained_exp=getattr(model_params, "train_test_exp", False),
            separate_sh=SPARSE_ADAM_AVAILABLE,
            sar_mode=False,
        )
        pred = render_pkg["render"].clamp(0.0, 1.0)
        gt = cam.original_image[:3].cuda().clamp(0.0, 1.0)
        raw_target_mask = _mask_for_camera(cam, masks, gt, float(args.fallback_target_threshold))
        target_mask = _dilate_mask(raw_target_mask, int(args.target_mask_dilate))
        denom = target_mask.sum().clamp_min(1.0)

        gt_gray = gt[:3].mean(dim=0)
        pred_gray = pred[:3].mean(dim=0)
        pixel_weight = target_mask
        if float(args.target_bright_weight) > 0.0 and int(raw_target_mask.sum().item()) > 8:
            q = torch.quantile(gt_gray[raw_target_mask > 0.5], float(args.target_bright_quantile))
            bright = (gt_gray >= q).float() * target_mask
            pixel_weight = target_mask + float(args.target_bright_weight) * bright

        target_l1 = (torch.abs(pred - gt) * pixel_weight.unsqueeze(0)).sum() / (
            pixel_weight.sum().clamp_min(1.0) * 3.0
        )

        # Keep the rest of the image black, but with a tiny weight so it cannot
        # dominate the target. This prevents free haze/background without asking
        # the model to synthesize background/shadow.
        outside = (1.0 - target_mask).unsqueeze(0)
        outside_loss = (pred * outside).sum() / (denom * 3.0)
        loss = target_l1 + float(args.outside_black_weight) * outside_loss

        if float(args.target_gradient_weight) > 0.0:
            pred_grad = _sobel_magnitude(pred_gray)
            gt_grad = _sobel_magnitude(gt_gray)
            grad_mask = _dilate_mask(target_mask, int(args.gradient_mask_dilate))
            grad_loss = (torch.abs(pred_grad - gt_grad) * grad_mask).sum() / grad_mask.sum().clamp_min(1.0)
            loss = loss + float(args.target_gradient_weight) * grad_loss

        if float(args.target_contrast_weight) > 0.0:
            pred_mean = _masked_mean(pred_gray, target_mask)
            gt_mean = _masked_mean(gt_gray, target_mask)
            pred_std = _masked_std(pred_gray, target_mask)
            gt_std = _masked_std(gt_gray, target_mask)
            contrast_loss = torch.abs(pred_mean - gt_mean) + torch.abs(pred_std - gt_std)
            loss = loss + float(args.target_contrast_weight) * contrast_loss
        else:
            pred_mean = _masked_mean(pred_gray, target_mask)
            gt_mean = _masked_mean(gt_gray, target_mask)

        brightness_cap_loss = torch.zeros((), device=gt.device, dtype=gt.dtype)
        if float(args.target_brightness_cap_weight) > 0.0 and int(target_mask.sum().item()) > 8:
            valid = target_mask > 0.5
            q = min(max(float(args.target_brightness_cap_quantile), 0.0), 1.0)
            pred_q = torch.quantile(pred_gray[valid], q)
            gt_q = torch.quantile(gt_gray[valid], q)
            ratio_margin = max(float(args.target_brightness_cap_ratio_margin), 0.0)
            abs_margin = max(float(args.target_brightness_cap_abs_margin), 0.0)
            mean_excess = torch.relu(pred_mean - gt_mean * (1.0 + ratio_margin) - abs_margin)
            quantile_excess = torch.relu(pred_q - gt_q * (1.0 + ratio_margin) - abs_margin)
            brightness_cap_loss = mean_excess * mean_excess + quantile_excess * quantile_excess
            loss = loss + float(args.target_brightness_cap_weight) * brightness_cap_loss

        do_silhouette = (
            float(args.silhouette_weight) > 0.0
            and int(args.silhouette_interval) > 0
            and (iteration == 1 or iteration % int(args.silhouette_interval) == 0)
        )
        if do_silhouette:
            white = torch.ones((gaussians.get_xyz.shape[0], 3), dtype=torch.float32, device="cuda")
            alpha_pkg = render(
                cam,
                gaussians,
                pipeline_params,
                bg,
                use_trained_exp=False,
                separate_sh=False,
                override_color=white,
                sar_mode=False,
            )
            alpha_proxy = alpha_pkg["render"].mean(dim=0).clamp(0.0, 1.0)
            alpha_target = _dilate_mask(raw_target_mask, int(args.silhouette_mask_dilate))
            sil_pos = torch.abs(alpha_proxy - alpha_target) * alpha_target
            sil_neg = alpha_proxy * (1.0 - alpha_target)
            silhouette_loss = sil_pos.sum() / alpha_target.sum().clamp_min(1.0)
            silhouette_loss = silhouette_loss + float(args.silhouette_outside_scale) * (
                sil_neg.sum() / alpha_target.sum().clamp_min(1.0)
            )
            loss = loss + float(args.silhouette_weight) * silhouette_loss

        if args.opacity_l2_weight > 0.0:
            loss = loss + float(args.opacity_l2_weight) * (gaussians.get_opacity ** 2).mean()

        if float(args.scale_cap_weight) > 0.0 and float(args.max_gaussian_scale) > 0.0:
            scale_over = torch.relu(gaussians.get_scaling - float(args.max_gaussian_scale))
            loss = loss + float(args.scale_cap_weight) * scale_over.pow(2).mean()

        if float(args.geometry_anchor_weight) > 0.0 and initial_count > 0:
            n_anchor = min(initial_count, int(gaussians.get_xyz.shape[0]))
            xyz_anchor = ((gaussians.get_xyz[:n_anchor] - initial_xyz[:n_anchor]) / initial_extent_norm).pow(2).mean()
            scale_anchor = (gaussians._scaling[:n_anchor] - gaussians.scaling_inverse_activation(initial_scaling[:n_anchor])).pow(2).mean()
            rot_anchor = (gaussians._rotation[:n_anchor] - initial_rotation[:n_anchor]).pow(2).mean()
            loss = loss + float(args.geometry_anchor_weight) * (
                xyz_anchor
                + float(args.geometry_scale_anchor_factor) * scale_anchor
                + float(args.geometry_rotation_anchor_factor) * rot_anchor
            )

        if float(args.geometry_extent_weight) > 0.0 and int(gaussians.get_xyz.shape[0]) >= 8:
            cur_xyz = gaussians.get_xyz
            cur_extent = (cur_xyz.max(dim=0).values - cur_xyz.min(dim=0).values).clamp_min(1e-6)
            extent_loss = ((cur_extent / initial_extent) - 1.0).pow(2).mean()
            loss = loss + float(args.geometry_extent_weight) * extent_loss

        loss.backward()
        if args.freeze_geometry:
            _zero_geometry_grads(gaussians)

        with torch.no_grad():
            if not args.freeze_geometry and iteration < int(opt.densify_until_iter):
                _update_densification_stats(gaussians, render_pkg)
                if iteration > int(opt.densify_from_iter) and iteration % int(opt.densification_interval) == 0:
                    size_threshold = 20 if iteration > int(opt.opacity_reset_interval) else None
                    gaussians.densify_and_prune(
                        float(opt.densify_grad_threshold),
                        float(args.densify_min_opacity),
                        scene.cameras_extent,
                        size_threshold,
                        render_pkg["radii"],
                    )
                if int(opt.opacity_reset_interval) > 0 and iteration % int(opt.opacity_reset_interval) == 0:
                    gaussians.reset_opacity()

        gaussians.optimizer.step()
        if float(args.max_gaussian_scale) > 0.0:
            with torch.no_grad():
                max_log_scale = float(np.log(float(args.max_gaussian_scale)))
                min_log_scale = float(np.log(max(float(args.min_gaussian_scale), 1e-8)))
                gaussians._scaling.data.clamp_(min=min_log_scale, max=max_log_scale)
        gaussians.optimizer.zero_grad(set_to_none=True)
        gaussians.exposure_optimizer.zero_grad(set_to_none=True)
        if args.freeze_geometry:
            _freeze_geometry(gaussians)
        _set_appearance_learning_rates(gaussians, args)

        lv = float(loss.detach().item())
        ema = lv if ema is None else 0.6 * ema + 0.4 * lv
        if iteration % 10 == 0:
            pbar.set_postfix(
                loss=f"{ema:.5f}",
                target=f"{float(target_l1.detach()):.5f}",
                cap=f"{float(brightness_cap_loss.detach()):.5f}",
                pts=int(gaussians.get_xyz.shape[0]),
            )

    final_xyz = gaussians.get_xyz.detach()
    final_scaling = gaussians.get_scaling.detach()
    xyz_drift = float((final_xyz - initial_xyz).abs().max().item()) if final_xyz.shape == initial_xyz.shape else float("nan")
    scale_drift = (
        float((final_scaling - initial_scaling).abs().max().item())
        if final_scaling.shape == initial_scaling.shape
        else float("nan")
    )
    print(f"[geometry check] max |xyz change|={xyz_drift:.6g}, max |scale change|={scale_drift:.6g}")

    _prune_gaussians_by_multiview_target_masks(gaussians, train_cams, masks, args)

    scene.save(opt.iterations)
    _render_training_views(
        scene,
        gaussians,
        pipeline_params,
        Path(model_params.model_path),
        use_trained_exp=getattr(model_params, "train_test_exp", False),
        args=args,
    )
    if bool(args.render_novel_after_train):
        _render_novel_target_views_after_train(args, model_params, pipeline_params)
    print(f"done: {model_params.model_path}")


def main():
    parser = ArgumentParser(description="Target-only optical/SAR-look 3DGS training")
    model = ModelParams(parser)
    opt_group = OptimizationParams(parser)
    pipeline = PipelineParams(parser)
    parser.add_argument("--iteration", type=int, default=-1, help="unused; accepted for cfg compatibility")
    parser.add_argument(
        "--init_gaussian_ply",
        type=str,
        default=None,
        help="Optional existing Gaussian PLY to preserve as target geometry/appearance initialization",
    )
    parser.add_argument("--scattering_masks_run", type=str, default="latest")
    parser.add_argument("--no_convert_target_masks", action="store_true", default=False)
    parser.add_argument("--fallback_target_threshold", type=float, default=0.08)
    parser.add_argument("--outside_black_weight", type=float, default=0.03)
    parser.add_argument("--opacity_l2_weight", type=float, default=0.0)
    parser.add_argument("--full_sh_from_start", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--appearance_feature_lr", type=float, default=0.02)
    parser.add_argument("--appearance_rest_lr", type=float, default=0.004)
    parser.add_argument("--appearance_opacity_lr", type=float, default=0.12)
    parser.add_argument("--target_mask_dilate", type=int, default=0)
    parser.add_argument("--target_bright_weight", type=float, default=3.0)
    parser.add_argument("--target_bright_quantile", type=float, default=0.82)
    parser.add_argument("--target_gradient_weight", type=float, default=0.12)
    parser.add_argument("--gradient_mask_dilate", type=int, default=1)
    parser.add_argument("--target_contrast_weight", type=float, default=0.0)
    parser.add_argument("--target_brightness_cap_weight", type=float, default=0.0)
    parser.add_argument("--target_brightness_cap_quantile", type=float, default=0.90)
    parser.add_argument("--target_brightness_cap_ratio_margin", type=float, default=0.05)
    parser.add_argument("--target_brightness_cap_abs_margin", type=float, default=0.01)
    parser.add_argument("--silhouette_weight", type=float, default=0.2)
    parser.add_argument("--silhouette_outside_scale", type=float, default=2.0)
    parser.add_argument("--silhouette_interval", type=int, default=5)
    parser.add_argument("--silhouette_mask_dilate", type=int, default=0)
    parser.add_argument("--geometry_anchor_weight", type=float, default=0.05)
    parser.add_argument("--geometry_scale_anchor_factor", type=float, default=0.25)
    parser.add_argument("--geometry_rotation_anchor_factor", type=float, default=0.10)
    parser.add_argument("--geometry_extent_weight", type=float, default=0.02)
    parser.add_argument("--max_gaussian_scale", type=float, default=0.10)
    parser.add_argument("--min_gaussian_scale", type=float, default=0.0005)
    parser.add_argument("--scale_cap_weight", type=float, default=0.05)
    parser.add_argument(
        "--freeze_geometry",
        action="store_true",
        default=False,
        help="Freeze xyz/scaling/rotation and disable densify. Default is trainable geometry.",
    )
    parser.add_argument("--densify_min_opacity", type=float, default=0.01)
    parser.add_argument("--post_prune_by_mask", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--no_post_prune_by_mask", dest="post_prune_by_mask", action="store_false")
    parser.add_argument("--post_prune_min_inside_ratio", type=float, default=0.12)
    parser.add_argument("--post_prune_min_views", type=int, default=3)
    parser.add_argument("--post_prune_mask_dilate", type=int, default=3)
    parser.add_argument("--render_novel_after_train", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--novel_output_dir", type=str, default=None)
    parser.add_argument("--novel_azimuth_start", type=int, default=0)
    parser.add_argument("--novel_azimuth_end", type=int, default=360)
    parser.add_argument("--novel_azimuth_step", type=int, default=5)
    parser.add_argument("--novel_azimuths", type=str, default=None)
    parser.add_argument("--novel_azimuth_offset_deg", type=float, default=0.0)
    parser.add_argument("--novel_depression_angle", type=float, default=15.0)
    parser.add_argument("--novel_pose_mode", choices=["colmap_track", "orbit"], default="colmap_track")
    parser.add_argument("--novel_colmap_track_nearest_only", action="store_true", default=False)
    parser.add_argument("--novel_colmap_track_azimuth_space", choices=["filename", "geom"], default="filename")
    parser.add_argument(
        "--novel_sar_like",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="After training, compose target renders with image-domain SAR-like background/shadow/layover. Disabled by default so renders stay target-only.",
    )
    parser.add_argument("--novel_mask_threshold", type=float, default=0.08)
    parser.add_argument("--novel_mask_quantile", type=float, default=0.35)
    parser.add_argument("--novel_mask_dilate", type=int, default=0)
    parser.add_argument("--novel_mask_blur_radius", type=int, default=2)
    parser.add_argument("--novel_shadow_source_dilate", type=int, default=1)
    parser.add_argument("--novel_target_shadow_gap", type=int, default=1)
    parser.add_argument("--novel_target_preserve_strength", type=float, default=0.92)
    parser.add_argument("--novel_target_preserve_threshold", type=float, default=0.45)
    parser.add_argument("--novel_target_preserve_blur_radius", type=int, default=1)
    parser.add_argument("--novel_background_level", type=float, default=0.06)
    parser.add_argument("--novel_background_texture", type=float, default=0.08)
    parser.add_argument("--novel_auto_background_from_train", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--novel_auto_background_level_quantile", type=float, default=0.50)
    parser.add_argument("--novel_auto_background_texture_scale", type=float, default=1.4)
    parser.add_argument("--novel_auto_background_exclude_dilate", type=int, default=5)
    parser.add_argument("--novel_auto_background_max_samples", type=int, default=250000)
    parser.add_argument("--novel_speckle_strength", type=float, default=0.65)
    parser.add_argument("--novel_speckle_looks", type=int, default=2)
    parser.add_argument("--novel_shadow_length_frac", type=float, default=0.34)
    parser.add_argument("--novel_shadow_decay_frac", type=float, default=0.55)
    parser.add_argument("--novel_shadow_blur_radius", type=int, default=5)
    parser.add_argument("--novel_shadow_strength", type=float, default=0.72)
    parser.add_argument("--novel_shadow_angle_offset", type=float, default=0.0)
    parser.add_argument("--novel_layover_threshold", type=float, default=0.35)
    parser.add_argument("--novel_layover_length_frac", type=float, default=0.06)
    parser.add_argument("--novel_layover_blur_radius", type=int, default=2)
    parser.add_argument("--novel_layover_strength", type=float, default=0.22)
    parser.add_argument("--novel_gamma", type=float, default=0.95)
    parser.add_argument("--novel_seed", type=int, default=1234)
    parser.add_argument("--target_halo_suppress_strength", type=float, default=0.0)
    parser.add_argument("--target_halo_threshold", type=float, default=0.12)
    parser.add_argument("--target_halo_quantile", type=float, default=0.35)
    parser.add_argument("--target_halo_dilate", type=int, default=0)
    parser.add_argument("--target_halo_soft_radius", type=int, default=0)
    parser.add_argument("--target_halo_black_floor", type=float, default=0.0)
    parser.add_argument("--novel_target_halo_threshold", type=float, default=None, help="Deprecated alias for --target_halo_threshold")
    parser.add_argument("--novel_save_masks", action="store_true", default=False)
    parser.add_argument("--allow_tf32", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--cudnn_benchmark", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--quiet", action="store_true", default=False)

    args = parser.parse_args(sys.argv[1:])
    if args.novel_target_halo_threshold is not None:
        args.target_halo_threshold = float(args.novel_target_halo_threshold)
    if not any(a == "--iterations" or str(a).startswith("--iterations=") for a in sys.argv[1:]):
        args.iterations = 500
    if not args.freeze_geometry:
        if not any(a == "--densify_from_iter" or str(a).startswith("--densify_from_iter=") for a in sys.argv[1:]):
            args.densify_from_iter = min(100, max(1, int(args.iterations) // 5))
        if not any(a == "--densify_until_iter" or str(a).startswith("--densify_until_iter=") for a in sys.argv[1:]):
            args.densify_until_iter = max(
                int(args.densify_from_iter) + 1,
                min(int(int(args.iterations) * 0.85), 1000),
            )
        if not any(a == "--densification_interval" or str(a).startswith("--densification_interval=") for a in sys.argv[1:]):
            args.densification_interval = 100 if int(args.iterations) > 1000 else 50
    _resolve_training_images_arg(args)
    safe_state(bool(args.quiet))
    _configure_torch_runtime(args)
    model_params = model.extract(args)
    opt = opt_group.extract(args)
    pipeline_params = pipeline.extract(args)
    train_locked_target(args, model_params, opt, pipeline_params)


if __name__ == "__main__":
    main()
