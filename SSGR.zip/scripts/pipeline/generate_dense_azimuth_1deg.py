#!/usr/bin/env python3
"""
MSTAR 单俯角 360° 稀疏观测 → 逐度（1°）合成 SAR 图像流水线。

典型数据：data/360-1 (BTR70)、360-2 (BMP2)、360-3 (T72)，各约 36 张，方位约每 10° 一张。

流程：
  1) convert.py：SAR-SIFT + SO-RCG SfM（若已有 sparse/0 可跳过）
  2) train_sar_complete.py：3D Gaussian + SDGR，用 36 张真图训练
  3) render_novel_sar_views.py：在训练俯角上，0°..359° 步长 1° 渲染（共 360 张）

新视角外参默认 colmap_track：在相邻训练方位之间 SLERP 插值（如 10° 与 20° 之间生成 15°），
与 SfM 重建的 COLMAP 轨迹一致。

示例（360-1 已有 SfM，只训练 + 逐度渲染）：
  python scripts/pipeline/generate_dense_azimuth_1deg.py \\
    --datasets 360-1 --skip_convert \\
    --train_iterations 30000

仅渲染（已有训练结果 output/360-1）：
  python scripts/pipeline/generate_dense_azimuth_1deg.py \\
    --datasets 360-1 --skip_convert --skip_train \\
    -m output/360-1 --iteration 30000
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


def _run(cmd: list[str], cwd: Path | None = None, dry_run: bool = False) -> None:
    line = " ".join(cmd)
    print(f"\n>>> {line}\n")
    if dry_run:
        return
    subprocess.run(cmd, cwd=str(cwd or REPO_ROOT), check=True)


def _has_sfm(source: Path) -> bool:
    sparse = source / "sparse" / "0"
    return (sparse / "images.bin").is_file() or (sparse / "images.txt").is_file()


def _count_images(source: Path) -> int:
    img_dir = source / "images"
    if not img_dir.is_dir():
        return 0
    exts = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}
    return sum(1 for p in img_dir.iterdir() if p.suffix.lower() in exts)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="MSTAR 360° 稀疏(≈10°) → 逐度 1° 合成流水线（SfM + 3DGS + 新视角渲染）",
    )
    parser.add_argument(
        "--datasets",
        nargs="+",
        default=["360-1", "360-2", "360-3"],
        help="data/ 下子目录名",
    )
    parser.add_argument(
        "--data_root",
        type=str,
        default=None,
        help="数据根目录，默认 <repo>/data",
    )
    parser.add_argument(
        "--output_root",
        type=str,
        default=None,
        help="训练输出根目录，默认 <repo>/output；每数据集写入 output/<name>/",
    )
    parser.add_argument("--skip_convert", action="store_true", help="跳过 convert（要求已有 sparse/0）")
    parser.add_argument("--skip_train", action="store_true", help="跳过训练，仅渲染（需 -m）")
    parser.add_argument(
        "-m",
        "--model_path",
        type=str,
        default=None,
        help="单数据集渲染时指定模型目录；多数据集时默认 output/<dataset>",
    )
    parser.add_argument("--iteration", type=int, default=-1, help="渲染用 checkpoint 迭代（-1=最新）")
    parser.add_argument("--train_iterations", type=int, default=30000, help="训练迭代数")
    parser.add_argument("--azimuth_start", type=int, default=0)
    parser.add_argument("--azimuth_end", type=int, default=360, help="不含上界，360 表示 0..359")
    parser.add_argument("--azimuth_step", type=int, default=1)
    parser.add_argument(
        "--novel_pose_mode",
        type=str,
        default="colmap_track",
        choices=["colmap_track", "colmap_ring", "sar"],
        help="推荐 colmap_track（SfM 轨迹方位插值）",
    )
    parser.add_argument(
        "--output_filename_style",
        type=str,
        default="mstar",
        choices=["mstar", "legacy"],
        help="mstar=目标-俯角-方位.jpg，与 MSTAR 一致",
    )
    parser.add_argument("--dry_run", action="store_true", help="只打印命令不执行")
    args = parser.parse_args()

    data_root = Path(args.data_root) if args.data_root else REPO_ROOT / "data"
    output_root = Path(args.output_root) if args.output_root else REPO_ROOT / "output"
    py = sys.executable

    for name in args.datasets:
        source = data_root / name
        if not source.is_dir():
            print(f"⚠️  跳过 {name}：目录不存在 {source}")
            continue

        n_img = _count_images(source)
        print("=" * 72)
        print(f"数据集: {name}  ({n_img} 张图像, {source})")
        print("=" * 72)

        if n_img < 2:
            print(f"⚠️  图像过少，跳过")
            continue

        # --- 1) SfM / convert ---
        if not args.skip_convert:
            if _has_sfm(source):
                print(f"ℹ️  已有 SfM 结果，跳过 convert（可加 --skip_convert 显式跳过）")
            else:
                _run(
                    [py, str(REPO_ROOT / "convert.py"), "-s", str(source)],
                    dry_run=args.dry_run,
                )
        elif not _has_sfm(source):
            print(f"❌ {name} 无 sparse/0，请先运行 convert 或去掉 --skip_convert")
            sys.exit(1)

        model_path = Path(args.model_path) if args.model_path and len(args.datasets) == 1 else output_root / name

        # --- 2) Train ---
        if not args.skip_train:
            model_path.parent.mkdir(parents=True, exist_ok=True)
            train_cmd = [
                py,
                str(REPO_ROOT / "train_sar_complete.py"),
                "-s",
                str(source),
                "-m",
                str(model_path),
                "--iterations",
                str(args.train_iterations),
                "--sar_stratify_azimuth",
                "--reuse_convert_scattering_masks",
                "--no_auto_novel_render",
                "--no_auto_render_train_views",
            ]
            _run(train_cmd, dry_run=args.dry_run)
        else:
            if not model_path.is_dir() or not (model_path / "cfg_args").is_file():
                print(f"❌ 跳过训练但模型目录无效: {model_path}")
                sys.exit(1)

        # --- 3) Dense 1° render ---
        render_out = model_path / "novel_views_dense_1deg"
        render_cmd = [
            py,
            str(REPO_ROOT / "scripts" / "rendering" / "render_novel_sar_views.py"),
            "-m",
            str(model_path),
            "--iteration",
            str(args.iteration),
            "--output_dir",
            str(render_out),
            "--same_depression_only",
            "--azimuth_start",
            str(args.azimuth_start),
            "--azimuth_end",
            str(args.azimuth_end),
            "--azimuth_step",
            str(args.azimuth_step),
            "--novel_pose_mode",
            args.novel_pose_mode,
            "--colmap_track_azimuth_space",
            "filename",
            "--output_filename_style",
            args.output_filename_style,
            "--depression_angles",
            "15",
        ]
        n_az = len(range(args.azimuth_start, args.azimuth_end, args.azimuth_step))
        print(f"将生成约 {n_az} 张/数据集（单俯角 15°，步长 {args.azimuth_step}°）")
        print(f"输出: {render_out / 'novel_views' / 'depression_15.0' / 'renders'}")
        _run(render_cmd, dry_run=args.dry_run)

    print("\n✅ 流水线完成。")
    print("说明：")
    print("  - 训练角（约 36 张）在 data/<name>/images/；合成角在 novel_views_dense_1deg/。")
    print("  - 15° 等中间方位由 colmap_track 在相邻训练帧外参间插值，非 GAN 2D 生成。")
    print("  - 若合成图模糊，可增大 train_iterations 或检查 sar_scale_params.json 与 ring 训练一致。")


if __name__ == "__main__":
    main()
