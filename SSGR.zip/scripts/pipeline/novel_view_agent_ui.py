#!/usr/bin/env python3
"""Tiny local web UI for novel_view_agent.py.

Run:
    python scripts/pipeline/novel_view_agent_ui.py

Then open http://127.0.0.1:8765/
"""

from __future__ import annotations

import argparse
import html as html_lib
import json
import mimetypes
import os
import inspect
import re
import shlex
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from dataclasses import dataclass, field
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse


REPO_ROOT = Path(__file__).resolve().parents[2]
AGENT_SCRIPT = REPO_ROOT / "scripts" / "pipeline" / "novel_view_agent.py"
DATA_ROOT = REPO_ROOT / "data"
DEFAULT_CONDA_ENV = "3dgs"
DEFAULT_MODEL = "gpt-5.4-mini-fast"
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}
INTERNAL_DATA_PARTS = {
    "adaptive_threshold_visualization",
    "adaptive_threshold_visualization_auto_shadow_test",
    "adaptive_threshold_visualization_auto_shadow_test_cached",
    "adaptive_threshold_visualization_auto_shadow_test_multi",
    "agent_batches",
    "agent_runs",
    "convert_logs",
    "error_logs",
    "feature_matches",
    "feature_visualization",
    "features",
    "geometry_prior",
    "images",
    "images_target_black",
    "images_target_masked",
    "input",
    "matches",
    "sar_imaging_verify",
    "sar_imaging_verify_nominal_fixed",
    "sar_imaging_verify_scale220_probe",
    "sar_imaging_verify_scale231_probe",
    "sar_imaging_verify_scale240_probe",
    "scattering_masks",
    "sfm",
    "sfm_results",
    "sparse",
}


SYSTEM_PROMPT = """You are a local SAR novel-view generation agent for the SSGR repo.
You can answer questions and call tools. The user works in f:\\3dgs\\SSGR.

Rules:
- Do not invent filesystem paths, job ids, metrics, or logs. Use tools when you need current local state.
- If the user asks to generate, train, process a folder, dry-run, or rerun a stage, call run_pipeline.
- If the user asks what datasets exist, call list_datasets.
- If the user asks about a job, status, terminal output, failure, or latest logs, call get_job_status or read_latest_log.
- If the user asks to analyze metrics, quantitative results, result quality, or optimization direction, call analyze_quantitative_results.
- If the user asks what the workflow does, explain_pipeline is enough.
- For quantitative-result analysis, make optimization directions parameter-only: mention concrete flags and increase/decrease directions, not inspection or workflow advice.
- Treat requests like "run/generate/process data/xxx" or "对 data/xxx 处理/生成新视角" as permission to run the pipeline for real.
- Use dry_run=true only when the user explicitly says dry-run, preview, test, check commands, or 预演/先看看命令.
- Prefer concise Chinese answers. Mention the terminal panel when a job is started.
"""


TOOLS = [
    {
        "type": "function",
        "name": "list_datasets",
        "description": "List available local datasets under the repo data folder.",
        "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "type": "function",
        "name": "run_pipeline",
        "description": "Run or dry-run the SfM -> 3DGS -> refiner pipeline.",
        "parameters": {
            "type": "object",
            "properties": {
                "data_dir": {"type": "string", "description": "Dataset path, for example data/360-1."},
                "dry_run": {"type": "boolean", "description": "Use true to only print commands."},
                "start_at": {"type": "string", "enum": ["sfm", "gs", "render", "refiner"]},
                "stop_after": {"type": "string", "enum": ["sfm", "gs", "render", "refiner"]},
                "conda_env": {"type": "string", "description": "Conda env name, usually 3dgs."},
                "device": {"type": "string", "enum": ["cuda", "cpu"]},
                "raysar_target_only": {"type": "boolean"},
                "refiner_azimuth_shadow": {"type": "boolean"},
                "matched_real_background": {"type": "boolean"},
                "matched_background_strength": {"type": "number"},
                "matched_background_shadow_alpha_source": {"type": "string", "enum": ["apply_alpha", "opacity", "compose_alpha", "max"]},
                "matched_background_hard_shadow_copy": {"type": "boolean"},
                "matched_background_patch_size": {"type": "integer"},
                "matched_background_patch_overlap": {"type": "integer"},
                "matched_background_patch_smooth": {"type": "integer"},
                "matched_background_patch_smooth_mix": {"type": "number"},
                "matched_background_reference_exclude_dilate": {"type": "integer"},
                "matched_background_nearest_refs": {"type": "integer"},
                "matched_background_reference_clean_blend_refs": {"type": "integer"},
                "matched_background_reference_clean_blend_mix": {"type": "number"},
                "matched_background_reference_clean_angle_sigma": {"type": "number"},
                "matched_background_reference_clean_patch_mix": {"type": "number"},
                "matched_background_min_background_fraction": {"type": "number"},
                "matched_background_shadow_from_render_percentile": {"type": "number"},
                "matched_background_target_mask_dilate": {"type": "integer"},
                "matched_background_blend_dilate": {"type": "integer"},
                "matched_background_target_mask_blur": {"type": "integer"},
                "matched_background_target_gap_dark_threshold": {"type": "number"},
                "matched_background_target_gap_edge_px": {"type": "integer"},
                "matched_background_target_gap_shadow_protect_threshold": {"type": "number"},
                "matched_background_hard_target_copy": {"type": "boolean"},
                "target_percentile": {"type": "number"},
                "target_mask_min_component_area_px": {"type": "integer"},
                "target_edge_outer_px": {"type": "integer"},
                "shadow_percentile": {"type": "number"},
                "shadow_min_area_fraction": {"type": "number"},
                "shadow_min_target_area_fraction": {"type": "number"},
                "azimuth_shadow_geometry_extent_gate": {"type": "boolean"},
                "azimuth_shadow_geometry_extent_apply_to_recognition": {"type": "boolean"},
                "azimuth_shadow_geometry_extent_require_dataset_direction": {"type": "boolean"},
                "azimuth_shadow_geometry_extent_forward_scale": {"type": "number"},
                "azimuth_shadow_geometry_extent_lateral_scale": {"type": "number"},
                "azimuth_shadow_geometry_extent_margin_px": {"type": "number"},
                "azimuth_shadow_geometry_extent_min_forward_px": {"type": "number"},
                "azimuth_shadow_intensity_strength": {"type": "number"},
                "azimuth_shadow_intensity_min_attenuation": {"type": "number"},
                "azimuth_shadow_intensity_max_attenuation": {"type": "number"},
                "azimuth_shadow_intensity_gamma": {"type": "number"},
                "azimuth_shadow_intensity_context_radius": {"type": "integer"},
                "azimuth_shadow_intensity_block_radius": {"type": "integer"},
                "azimuth_shadow_intensity_exclude_dilate": {"type": "integer"},
                "export_classification_labels": {"type": "boolean"},
                "novel_azimuth_start": {"type": "integer"},
                "novel_azimuth_end": {"type": "integer"},
                "novel_azimuth_step": {"type": "integer"},
                "novel_azimuths": {"type": "string", "description": "Explicit comma-separated azimuth degrees."},
                "output_root": {"type": "string"},
                "classification_label_output_dir": {"type": "string"},
                "classification_root": {"type": "string"},
                "classification_source": {"type": "string"},
                "fast_io": {"type": "boolean"},
                "extra_agent_args": {"type": "string", "description": "Raw CLI args appended to novel_view_agent.py."},
            },
            "required": ["data_dir", "dry_run"],
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "get_job_status",
        "description": "Get status for a UI job by id, or the latest job if no id is provided.",
        "parameters": {
            "type": "object",
            "properties": {"job_id": {"type": "string"}},
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "read_latest_log",
        "description": "Read the tail of a UI job terminal log.",
        "parameters": {
            "type": "object",
            "properties": {
                "job_id": {"type": "string"},
                "max_chars": {"type": "integer", "minimum": 200, "maximum": 12000},
            },
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "explain_pipeline",
        "description": "Explain what the local SfM, 3DGS, and refiner workflow does.",
        "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "type": "function",
        "name": "suggest_refiner_params",
        "description": "Suggest refiner parameter changes for common visual problems. Prefer analyze_quantitative_results when metric JSON exists.",
        "parameters": {
            "type": "object",
            "properties": {"problem": {"type": "string"}},
            "additionalProperties": False,
        },
    },
    {
        "type": "function",
        "name": "analyze_quantitative_results",
        "description": "Read existing paper_metrics_summary.json, metrics_summary.json, or comparison_results.json files and diagnose result quality with optimization directions.",
        "parameters": {
            "type": "object",
            "properties": {
                "result_path": {
                    "type": "string",
                    "description": "Optional file or directory under the repo, for example output/agent/2S1/gaussian/result/latest_run.",
                },
                "data_dir": {"type": "string", "description": "Optional dataset path used to prioritize matching output metrics."},
                "output_root": {"type": "string", "description": "Optional result root directory, for example output/final."},
                "include_per_view": {"type": "boolean", "description": "Load per-view data when available and report worst views."},
            },
            "additionalProperties": False,
        },
    },
]


ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def _clean_terminal_text(text: str) -> str:
    return ANSI_RE.sub("", str(text)).replace("\r\n", "\n").replace("\r", "\n")


def _progress_key(line: str) -> str | None:
    text = ANSI_RE.sub("", str(line)).strip()
    if not text:
        return None
    match = re.match(r"^([^:\n]{1,90}):\s*\d{1,3}%\s*\|", text)
    if match:
        return f"tqdm:{match.group(1).strip()}"
    match = re.match(r"^(\[[^\]]+\])\s+\[[#=\-\. ]+\]\s+", text)
    if match:
        return f"agent:{match.group(1)}"
    return None


@dataclass
class Job:
    id: str
    command: list[str]
    created_at: str
    conda_env: str = DEFAULT_CONDA_ENV
    status: str = "queued"
    returncode: int | None = None
    logs: list[str] = field(default_factory=list)
    process: subprocess.Popen | None = None
    lock: threading.Lock = field(default_factory=threading.Lock)

    def append(self, line: str) -> None:
        with self.lock:
            for part in _clean_terminal_text(line).splitlines(True):
                key = _progress_key(part)
                if key is not None:
                    for idx in range(len(self.logs) - 1, max(-1, len(self.logs) - 200), -1):
                        if _progress_key(self.logs[idx]) == key:
                            del self.logs[idx]
                            break
                    self.logs.append(part if part.endswith("\n") else part + "\n")
                else:
                    self.logs.append(part)
            if len(self.logs) > 8000:
                self.logs = self.logs[-8000:]

    def snapshot(self) -> dict:
        with self.lock:
            return {
                "id": self.id,
                "status": self.status,
                "returncode": self.returncode,
                "created_at": self.created_at,
                "command": _format_cmd(self.command),
                "logs": "".join(self.logs),
            }


JOBS: dict[str, Job] = {}
JOBS_LOCK = threading.Lock()


def _format_cmd(cmd: list[str]) -> str:
    if os.name == "nt":
        return subprocess.list2cmdline([str(x) for x in cmd])
    import shlex

    return shlex.join([str(x) for x in cmd])


def _count_images(path: Path) -> int:
    if not path.is_dir():
        return 0
    return sum(1 for p in path.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS)


def _has_dataset_images(path: Path) -> bool:
    if not path.is_dir():
        return False
    for name in ("input", "images", "images_target_black"):
        if _count_images(path / name) > 0:
            return True
    return _count_images(path) > 0


def _looks_like_internal_data_dir(path: Path) -> bool:
    try:
        parts = [part.lower() for part in path.relative_to(DATA_ROOT).parts]
    except ValueError:
        return False
    if len(parts) >= 2 and parts[-1] == parts[-2]:
        return True
    return any(part in INTERNAL_DATA_PARTS for part in parts)


def _dataset_dirs_for_ui() -> list[Path]:
    if not DATA_ROOT.is_dir():
        return []
    out: list[Path] = []
    for child in sorted((p for p in DATA_ROOT.iterdir() if p.is_dir()), key=lambda p: p.name.lower()):
        if _looks_like_internal_data_dir(child) or not _has_dataset_images(child):
            continue
        out.append(child)
    return sorted(out, key=lambda p: str(p.relative_to(REPO_ROOT)).lower())


def _dataset_dirs_named(name: str) -> list[Path]:
    target = str(name or "").lower()
    if not target:
        return []
    return [path for path in _dataset_dirs_for_ui() if path.name.lower() == target]


def _list_datasets() -> list[str]:
    return [str(path.relative_to(REPO_ROOT)) for path in _dataset_dirs_for_ui()]


def _resolve_repo_path(raw: str) -> Path:
    text = str(raw or "").strip().strip("\"'`")
    if not text:
        raise ValueError("path is empty")
    path = Path(text)
    if not path.is_absolute():
        path = REPO_ROOT / path
    resolved = path.resolve()
    try:
        resolved.relative_to(REPO_ROOT)
    except ValueError as exc:
        raise ValueError(f"path must stay inside repo: {raw}") from exc
    return resolved


def _resolve_data_dir(raw: str) -> Path:
    if not str(raw or "").strip():
        raise ValueError("Select a data folder first.")
    path = _resolve_repo_path(raw)
    if not path.is_dir():
        raise ValueError(f"Data folder not found: {raw}")
    return path


def _repo_rel(path: Path) -> str:
    return str(path.resolve().relative_to(REPO_ROOT)).replace("\\", "/")


METRIC_FILENAMES = ("metrics_summary.json", "paper_metrics_summary.json", "comparison_results.json")
METRIC_KEY_METRICS = (
    "SAR_SSIM",
    "SAR_TOL_PSNR",
    "SAR_PSNR",
    "SSIM",
    "PSNR",
    "LPIPS",
    "edge_similarity_target",
    "edge_similarity",
    "contrast_similarity_target",
    "contrast_similarity",
    "histogram_correlation_target",
    "histogram_correlation",
    "diagnosis_extra_bright_ratio",
    "diagnosis_missing_bright_ratio",
    "diagnosis_dark_region_leak_ratio",
    "diagnosis_mae_target_log",
    "target_mask_ratio",
)
METRIC_HIGHER_IS_BETTER = {
    "SAR_SSIM",
    "SAR_TOL_PSNR",
    "SAR_PSNR",
    "SSIM",
    "PSNR",
    "edge_similarity_target",
    "edge_similarity",
    "contrast_similarity_target",
    "contrast_similarity",
    "histogram_correlation_target",
    "histogram_correlation",
}


def _safe_float(value) -> float | None:
    try:
        if value is None:
            return None
        out = float(value)
    except (TypeError, ValueError):
        return None
    if out != out or out in (float("inf"), float("-inf")):
        return None
    return out


def _metric_mean(metrics: dict, name: str, default: float | None = None) -> float | None:
    summary = metrics.get("summary") if isinstance(metrics, dict) else None
    if not isinstance(summary, dict):
        return default
    item = summary.get(name)
    if isinstance(item, dict):
        return _safe_float(item.get("mean"))
    return _safe_float(item)


def _metric_std(metrics: dict, name: str) -> float | None:
    summary = metrics.get("summary") if isinstance(metrics, dict) else None
    if not isinstance(summary, dict):
        return None
    item = summary.get(name)
    return _safe_float(item.get("std")) if isinstance(item, dict) else None


def _metric_value(metrics: dict, *names: str) -> float | None:
    for name in names:
        value = _metric_mean(metrics, name)
        if value is not None:
            return value
    return None


def _fmt_metric(value: float | None, digits: int = 4) -> str:
    if value is None:
        return "n/a"
    if abs(value) >= 10:
        return f"{value:.2f}"
    return f"{value:.{digits}f}"


def _load_json_metric(path: Path) -> dict | None:
    try:
        if not path.is_file() or path.stat().st_size <= 1:
            return None
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return None
    return data if isinstance(data, dict) and data else None


def _metric_files_under(root: Path, limit: int = 200) -> list[Path]:
    if not root.exists():
        return []
    if root.is_file() and root.name in METRIC_FILENAMES:
        return [root]
    files: list[Path] = []
    if root.is_dir():
        for name in METRIC_FILENAMES:
            files.extend(root.rglob(name))
    files = [p for p in files if p.is_file() and p.stat().st_size > 1]
    priority = {"metrics_summary.json": 0, "paper_metrics_summary.json": 1, "comparison_results.json": 2}
    files.sort(key=lambda p: (priority.get(p.name, 99), -p.stat().st_mtime))
    return files[:limit]


def _metric_data_name(data_dir: str) -> str:
    text = str(data_dir or "").strip().strip("\"'`").rstrip(",;，。；")
    if not text:
        return ""
    try:
        return _resolve_repo_path(text).name.lower()
    except Exception:
        return Path(text.replace("\\", "/")).name.lower()


def _path_has_part(path: Path, name: str) -> bool:
    target = str(name or "").strip().lower()
    if not target:
        return True
    return any(part.lower() == target for part in path.parts)


def _metric_available_kinds(root: Path) -> list[str]:
    if not root.is_dir():
        return []
    noisy = {
        "agent_batches",
        "figure",
        "label",
        "mask_label",
        "picture",
        "picture2",
        "__pycache__",
    }
    kinds: set[str] = set()
    for path in _metric_files_under(root, limit=2000):
        try:
            rel_parts = path.resolve().relative_to(root.resolve()).parts
        except ValueError:
            continue
        if not rel_parts:
            continue
        first = rel_parts[0]
        if first.lower() in noisy or first.lower().startswith("figure_"):
            continue
        kinds.add(first)
    return sorted(kinds, key=str.lower)


def _latest_metric_files(data_dir: str = "", output_hint: str = "") -> list[Path]:
    roots: list[Path] = []
    strict_roots = False
    if output_hint:
        try:
            roots.append(_resolve_repo_path(output_hint))
            strict_roots = True
        except Exception:
            pass
    output_root = REPO_ROOT / "output"
    if output_root.is_dir() and not strict_roots:
        roots.append(output_root)

    seen: set[Path] = set()
    files: list[Path] = []
    for root in roots:
        for path in _metric_files_under(root):
            resolved = path.resolve()
            if resolved not in seen:
                seen.add(resolved)
                files.append(path)

    data_name = _metric_data_name(data_dir)
    if data_name:
        files = [path for path in files if _path_has_part(path, data_name)]

    def _score(path: Path) -> tuple[int, int, float]:
        name_score = 1 if data_name and _path_has_part(path, data_name) else 0
        summary_score = 2 if path.name == "metrics_summary.json" else (1 if path.name == "paper_metrics_summary.json" else 0)
        return (name_score, summary_score, path.stat().st_mtime)

    files.sort(key=_score, reverse=True)
    return files


def _normalize_metric_groups(data: dict, source_path: Path) -> dict[str, dict]:
    summary = data.get("summary") if isinstance(data, dict) else None
    if isinstance(summary, dict) and isinstance(summary.get("ALL"), dict):
        group_name = source_path.parent.name
        if group_name.lower() not in {"target", "full", "target_shadow", "novel_metrics"}:
            group_name = "full"
        return {
            group_name: {
                "paper_metrics_json": str(source_path),
                "summary": summary["ALL"],
                "summary_by_class": {
                    key: value
                    for key, value in summary.items()
                    if key != "ALL" and isinstance(value, dict)
                },
                "image_count": data.get("pair_count"),
                "skipped_count": data.get("skipped_count"),
                "metric_definition": data.get("metric_definition", {}),
            }
        }
    if "summary" in data:
        group_name = source_path.parent.name
        if group_name.lower() not in {"target", "full", "target_shadow", "novel_metrics"}:
            group_name = "target" if "target" in str(source_path).lower() else "full"
        return {group_name: data}
    groups: dict[str, dict] = {}
    for key, value in data.items():
        if isinstance(value, dict) and "summary" in value:
            groups[str(key)] = value
    return groups


def _compact_metric_summary(groups: dict[str, dict]) -> dict[str, dict]:
    compact: dict[str, dict] = {}
    for group, metrics in groups.items():
        values = {}
        for key in METRIC_KEY_METRICS:
            value = _metric_mean(metrics, key)
            if value is not None:
                values[key] = value
        compact[group] = {
            "image_count": metrics.get("image_count"),
            "metrics": values,
        }
    return compact


def _add_issue(issues: list[dict], severity: str, title: str, detail: str, suggestions: list[str]) -> None:
    issues.append({
        "severity": severity,
        "title": title,
        "detail": detail,
        "suggestions": suggestions,
    })


def _diagnose_metric_groups(groups: dict[str, dict]) -> tuple[list[dict], list[str]]:
    issues: list[dict] = []
    notes: list[str] = []
    target = groups.get("target") or next((v for k, v in groups.items() if "target" in k.lower()), None)
    full = groups.get("full") or next((v for k, v in groups.items() if "full" in k.lower()), None)
    primary = target or full or next(iter(groups.values()), {})

    if not groups:
        return issues, ["没有找到可用的 summary 指标。"]

    target_ssim = _metric_value(primary, "SAR_SSIM", "SSIM")
    target_psnr = _metric_value(primary, "SAR_TOL_PSNR", "SAR_PSNR", "PSNR")
    lpips = _metric_value(primary, "LPIPS")
    edge = _metric_value(primary, "edge_similarity_target", "edge_similarity")
    contrast = _metric_value(primary, "contrast_similarity_target", "contrast_similarity")
    hist = _metric_value(primary, "histogram_correlation_target", "histogram_correlation")
    extra = _metric_value(primary, "diagnosis_extra_bright_ratio")
    missing = _metric_value(primary, "diagnosis_missing_bright_ratio")
    dark_leak = _metric_value(primary, "diagnosis_dark_region_leak_ratio")
    mask_ratio = _metric_value(primary, "target_mask_ratio")
    mae_target = _metric_value(primary, "diagnosis_mae_target_log", "SAR_MAE", "MAE")

    if target_ssim is not None and target_ssim < 0.72:
        _add_issue(
            issues,
            "high" if target_ssim < 0.60 else "medium",
            "目标区域结构相似度偏低",
            f"目标/主区域 SAR_SSIM={_fmt_metric(target_ssim)}，说明目标纹理、亮暗结构或姿态对齐仍不稳。",
            [
                "上调 --quantile_loss_weight，例如从 0.20 提到 0.30-0.45，增强目标强度分布约束。",
                "上调 --target_speckle_std_quantile_weight 与 --target_speckle_highfreq_quantile_weight，各增加 0.1-0.2。",
                "若同时边缘偏弱，上调 --target_ring_quantile_loss_weight 或 --target_edge_outer_px。",
            ],
        )
    elif target_ssim is not None:
        notes.append(f"目标结构指标可用：SAR_SSIM={_fmt_metric(target_ssim)}。")

    if target_psnr is not None and target_psnr < 15.0:
        _add_issue(
            issues,
            "medium",
            "目标像素误差较高",
            f"目标/主区域 SAR_TOL_PSNR={_fmt_metric(target_psnr)}，低于常用调试阈值 15。",
            [
                "上调 --quantile_loss_weight 0.1-0.2，优先收敛目标区域强度误差。",
                "降低过强后处理项：适当下调 --matched_background_strength 或 --azimuth_shadow_intensity_strength。",
            ],
        )

    if lpips is not None and lpips > 0.32:
        _add_issue(
            issues,
            "medium",
            "感知差异偏大",
            f"LPIPS={_fmt_metric(lpips)}，渲染纹理观感与 GT 差异较明显。",
            [
                "上调 --target_speckle_highfreq_quantile_weight 0.1-0.2，增强高频纹理统计约束。",
                "下调 --matched_background_patch_smooth_mix 0.05-0.10，减少背景平滑对纹理的削弱。",
            ],
        )

    if edge is not None and edge < 0.45:
        _add_issue(
            issues,
            "medium",
            "边缘与轮廓匹配偏弱",
            f"edge_similarity={_fmt_metric(edge)}，目标轮廓或强散射边缘不够贴合。",
            [
                "上调 --target_edge_outer_px 1-2 个像素，扩大边缘约束区域。",
                "上调 --target_ring_quantile_loss_weight 0.05-0.15，增强轮廓/环带约束。",
            ],
        )

    if contrast is not None and contrast < 0.62:
        _add_issue(
            issues,
            "medium",
            "对比度统计不匹配",
            f"contrast_similarity={_fmt_metric(contrast)}，目标亮暗动态范围与 GT 偏差较大。",
            [
                "上调 --quantile_loss_weight，例如从 0.20 提到 0.30-0.45。",
                "上调 --target_speckle_intensity_quantile_weight 0.1-0.2，增强强度分位数匹配。",
            ],
        )

    if hist is not None and hist < 0.62:
        _add_issue(
            issues,
            "low",
            "直方图分布仍有差异",
            f"histogram_correlation={_fmt_metric(hist)}，强度分布没有完全对齐。",
            [
                "上调 --quantile_loss_weight 0.05-0.15。",
                "将 --stat_quantiles 设为覆盖低/中/高亮的序列，例如 0.03,0.10,0.25,0.50,0.75,0.90,0.97。",
            ],
        )

    if extra is not None and missing is not None:
        if extra > 0.045 and extra > missing * 1.2:
            _add_issue(
                issues,
                "high" if extra > 0.075 else "medium",
                "额外亮斑偏多",
                f"extra_bright_ratio={_fmt_metric(extra)} 高于 missing_bright_ratio={_fmt_metric(missing)}。",
                [
                    "上调 --target_percentile 2-5，收紧目标高亮区域选择。",
                    "下调 --matched_background_strength 0.05-0.15，降低背景亮斑注入强度。",
                    "关闭 --matched_background_hard_target_copy，或下调 --matched_background_reference_clean_patch_mix 0.05-0.10。",
                ],
            )
        elif missing > 0.045 and missing > extra * 1.2:
            _add_issue(
                issues,
                "high" if missing > 0.075 else "medium",
                "GT 高亮缺失偏多",
                f"missing_bright_ratio={_fmt_metric(missing)} 高于 extra_bright_ratio={_fmt_metric(extra)}。",
                [
                    "下调 --target_percentile 2-5，放宽目标高亮保留范围。",
                    "上调 --target_speckle_intensity_quantile_weight 0.1-0.2，补强目标高亮分布。",
                    "降低 --matched_background_target_gap_dark_threshold 0.002-0.005，减少目标高亮被暗区规则压制。",
                ],
            )
        else:
            notes.append(f"亮斑误差较均衡：extra={_fmt_metric(extra)}，missing={_fmt_metric(missing)}。")

    if dark_leak is not None and dark_leak > 0.68:
        _add_issue(
            issues,
            "medium",
            "暗区泄漏比例偏高",
            f"diagnosis_dark_region_leak_ratio={_fmt_metric(dark_leak)}，暗区/阴影区域仍有较多不该出现的能量。",
            [
                "上调 --azimuth_shadow_intensity_strength 0.05-0.15，增强阴影压制。",
                "下调 --azimuth_shadow_intensity_max_attenuation 0.03-0.08，限制阴影区残余亮度。",
                "上调 --matched_background_target_gap_shadow_protect_threshold 0.005-0.015，增强目标间隙阴影保护。",
            ],
        )

    if mask_ratio is not None:
        if mask_ratio < 0.008:
            _add_issue(
                issues,
                "medium",
                "目标 mask 过窄",
                f"target_mask_ratio={_fmt_metric(mask_ratio)}，可能只覆盖了少量高亮点。",
                [
                    "下调 --target_mask_quantile 0.05-0.10，扩大目标 mask。",
                    "上调 --matched_background_target_mask_dilate 1-2 个像素。",
                ],
            )
        elif mask_ratio > 0.12:
            _add_issue(
                issues,
                "medium",
                "目标 mask 过宽",
                f"target_mask_ratio={_fmt_metric(mask_ratio)}，可能把背景也纳入目标优化。",
                [
                    "上调 --target_mask_quantile 0.05-0.10，收紧目标 mask。",
                    "下调 --matched_background_target_mask_dilate 1-2 个像素，必要时设为 0。",
                    "上调 --target_mask_min_component_area_px 5-15，过滤小背景连通域。",
                ],
            )

    if full is not None and target is not None:
        full_ssim = _metric_value(full, "SAR_SSIM", "SSIM")
        full_psnr = _metric_value(full, "SAR_TOL_PSNR", "SAR_PSNR", "PSNR")
        if full_ssim is not None and target_ssim is not None and full_ssim + 0.25 < target_ssim:
            _add_issue(
                issues,
                "medium",
                "全图结构明显落后于目标区",
                f"target SAR_SSIM={_fmt_metric(target_ssim)}，full SAR_SSIM={_fmt_metric(full_ssim)}，差距较大。",
                [
                    "下调 --matched_background_strength 0.05-0.15，减少背景融合对全图结构的扰动。",
                    "下调 --matched_background_patch_smooth_mix 0.05-0.10，保留更多局部结构。",
                    "若阴影拖累全图，上调 --azimuth_shadow_geometry_extent_margin_px 0.5-1.5 控制阴影作用范围。",
                ],
            )
            notes.append(
                f"target 明显好于 full：target SAR_SSIM={_fmt_metric(target_ssim)}，full SAR_SSIM={_fmt_metric(full_ssim)}，主要问题可能在背景/阴影融合。"
            )
        if full_psnr is not None and full_psnr < 16.0:
            _add_issue(
                issues,
                "low",
                "全图 SAR 质量偏低",
                f"full SAR_TOL_PSNR={_fmt_metric(full_psnr)}，背景或阴影融合会拖低全图指标。",
                [
                    "下调 --matched_background_strength 0.05-0.15。",
                    "下调 --matched_background_reference_clean_blend_mix 0.05-0.10。",
                    "下调 --matched_background_reference_clean_patch_mix 0.05-0.10。",
                ],
            )

    if mae_target is not None:
        notes.append(f"目标平均绝对误差参考：MAE/log={_fmt_metric(mae_target)}。")

    issues.sort(key=lambda item: {"high": 0, "medium": 1, "low": 2}.get(item["severity"], 3))
    return issues, notes


def _worst_per_view(groups: dict[str, dict], include_per_view: bool, limit: int = 6) -> list[dict]:
    if not include_per_view:
        return []
    candidates: list[dict] = []
    for group, metrics in groups.items():
        data = metrics
        comparison_json = metrics.get("comparison_json")
        if comparison_json:
            loaded = _load_json_metric(Path(comparison_json))
            if isinstance(loaded, dict):
                data = loaded
        rows = data.get("per_image") if isinstance(data, dict) else None
        if not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, dict):
                continue
            ssim = _safe_float(row.get("SAR_SSIM") or row.get("SSIM"))
            psnr = _safe_float(row.get("SAR_TOL_PSNR") or row.get("SAR_PSNR") or row.get("PSNR"))
            extra = _safe_float(row.get("diagnosis_extra_bright_ratio"))
            missing = _safe_float(row.get("diagnosis_missing_bright_ratio"))
            leak = _safe_float(row.get("diagnosis_dark_region_leak_ratio"))
            score = 0.0
            if ssim is not None:
                score += max(0.0, 0.90 - ssim) * 3.0
            if psnr is not None:
                score += max(0.0, 18.0 - psnr) / 8.0
            if extra is not None:
                score += extra
            if missing is not None:
                score += missing
            if leak is not None:
                score += max(0.0, leak - 0.55) * 0.5
            candidates.append({
                "group": group,
                "image": row.get("image_name"),
                "azimuth": row.get("azimuth"),
                "SAR_SSIM": ssim,
                "SAR_TOL_PSNR": psnr,
                "extra_bright_ratio": extra,
                "missing_bright_ratio": missing,
                "dark_region_leak_ratio": leak,
                "score": score,
            })
    candidates.sort(key=lambda item: item.get("score") or 0.0, reverse=True)
    return candidates[:limit]


def _metric_analysis_to_text(analysis: dict) -> str:
    if analysis.get("error"):
        return str(analysis["error"])
    lines = [
        "量化结果分析：",
        f"- 指标来源：{analysis.get('source')}",
    ]
    compact = analysis.get("compact_metrics") or {}
    for group in ("target", "full", "target_shadow"):
        item = compact.get(group)
        if not item:
            continue
        m = item.get("metrics") or {}
        parts = []
        for key in ("SAR_SSIM", "SAR_TOL_PSNR", "PSNR", "LPIPS", "edge_similarity_target", "diagnosis_extra_bright_ratio", "diagnosis_missing_bright_ratio"):
            if key in m:
                parts.append(f"{key}={_fmt_metric(m[key])}")
        if parts:
            lines.append(f"- {group}: " + ", ".join(parts))

    issues = analysis.get("issues") or []
    if not issues:
        lines.append("\n结论：未发现明显硬阈值问题，建议继续看最差视角和视觉诊断图做细调。")
    else:
        lines.append("\n主要问题与参数调整方向：")
        for idx, issue in enumerate(issues[:5], 1):
            lines.append(f"{idx}. [{issue.get('severity')}] {issue.get('title')}：{issue.get('detail')}")
            for suggestion in (issue.get("suggestions") or [])[:2]:
                lines.append(f"   - {suggestion}")

    notes = analysis.get("notes") or []
    if notes:
        lines.append("\n补充观察：")
        lines.extend(f"- {note}" for note in notes[:4])

    worst = analysis.get("worst_views") or []
    if worst:
        lines.append("\n指标最差视角：")
        for row in worst[:6]:
            label = row.get("image") or f"azimuth_{row.get('azimuth')}"
            lines.append(
                f"- {row.get('group')} / {label}: "
                f"SAR_SSIM={_fmt_metric(row.get('SAR_SSIM'))}, "
                f"PSNR={_fmt_metric(row.get('SAR_TOL_PSNR'))}, "
                f"extra={_fmt_metric(row.get('extra_bright_ratio'))}, "
                f"missing={_fmt_metric(row.get('missing_bright_ratio'))}"
            )
    return "\n".join(lines)


def _analyze_quantitative_results(arguments: dict, ui_payload: dict | None = None) -> dict:
    ui_payload = ui_payload or {}
    result_path = str(arguments.get("result_path") or "").strip()
    data_dir = str(arguments.get("data_dir") or ui_payload.get("data_dir") or "").strip()
    include_per_view = bool(arguments.get("include_per_view", True))
    output_hint = str(arguments.get("output_root") or ui_payload.get("output_root") or "").strip()
    data_name = _metric_data_name(data_dir)
    search_root: Path | None = None

    metric_files: list[Path] = []
    if result_path:
        try:
            search_root = _resolve_repo_path(result_path)
            metric_files = _metric_files_under(search_root, limit=200)
        except Exception as exc:
            return {"error": f"指标路径无效：{exc}"}
        if data_name:
            metric_files = [path for path in metric_files if _path_has_part(path, data_name)]
    if not metric_files:
        if output_hint:
            try:
                search_root = _resolve_repo_path(output_hint)
            except Exception:
                search_root = None
        metric_files = _latest_metric_files(data_dir=data_dir, output_hint=output_hint)

    if data_name and not metric_files:
        available = _metric_available_kinds(search_root or (REPO_ROOT / "output"))
        available_text = "\n".join(f"- {name}" for name in available) if available else "- 未找到带指标的结果种类"
        root_text = _repo_rel(search_root) if search_root and search_root.exists() else (output_hint or "output")
        return {
            "error": (
                f"在 {root_text} 中没有找到种类 `{data_name}` 的可读取量化结果。\n\n"
                "当前可分析的已有种类：\n"
                f"{available_text}"
            ),
            "available_kinds": available,
            "tried": [],
        }

    tried: list[str] = []
    for path in metric_files:
        tried.append(_repo_rel(path))
        data = _load_json_metric(path)
        if not data:
            continue
        groups = _normalize_metric_groups(data, path)
        if not groups:
            continue
        issues, notes = _diagnose_metric_groups(groups)
        analysis = {
            "source": _repo_rel(path),
            "groups": list(groups.keys()),
            "compact_metrics": _compact_metric_summary(groups),
            "issues": issues,
            "notes": notes,
            "worst_views": _worst_per_view(groups, include_per_view),
            "tried": tried[:12],
        }
        analysis["analysis_text"] = _metric_analysis_to_text(analysis)
        return analysis

    return {
        "error": (
            "没有找到可读取的指标 JSON。请先运行带 GT 的评估，或指定包含 "
            "paper_metrics_summary.json / metrics_summary.json / comparison_results.json 的 result_path。"
        ),
        "tried": tried[:12],
    }


def _semantic_preview_files(data_dir: Path, limit: int = 80) -> dict:
    preview_dir = data_dir / "adaptive_threshold_visualization"
    images: list[dict] = []
    diagnostics: list[dict] = []
    if preview_dir.is_dir():
        image_files = sorted(
            preview_dir.glob("region_classification_*.png"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        diag_files = sorted(
            preview_dir.glob("shadow_diagnostic_*.txt"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        images = [
            {
                "name": p.name,
                "path": _repo_rel(p),
                "mtime": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"),
            }
            for p in image_files[:limit]
        ]
        diagnostics = [
            {
                "name": p.name,
                "path": _repo_rel(p),
                "mtime": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"),
            }
            for p in diag_files[:limit]
        ]
    return {
        "data_dir": _repo_rel(data_dir),
        "preview_dir": _repo_rel(preview_dir),
        "exists": preview_dir.is_dir(),
        "images": images,
        "diagnostics": diagnostics,
    }


def _send_file_response(handler: BaseHTTPRequestHandler, path: Path) -> None:
    resolved = _resolve_repo_path(str(path))
    if not resolved.is_file():
        handler.send_error(HTTPStatus.NOT_FOUND, "file not found")
        return
    if resolved.suffix.lower() not in IMAGE_EXTS | {".txt"}:
        handler.send_error(HTTPStatus.FORBIDDEN, "unsupported file type")
        return
    body = resolved.read_bytes()
    content_type = mimetypes.guess_type(str(resolved))[0] or "application/octet-stream"
    if resolved.suffix.lower() == ".txt":
        content_type = "text/plain; charset=utf-8"
    handler.send_response(HTTPStatus.OK)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def _send_semantic_preview_html(handler: BaseHTTPRequestHandler, data_dir_raw: str) -> None:
    try:
        info = _semantic_preview_files(_resolve_data_dir(data_dir_raw))
    except Exception as exc:
        handler.send_error(HTTPStatus.BAD_REQUEST, str(exc))
        return

    title = f"Semantic preview - {info['data_dir']}"
    image_cards = []
    for item in info["images"]:
        file_url = f"/semantic_preview/file?path={quote(item['path'])}"
        image_cards.append(
            "<figure>"
            f"<a href=\"{file_url}\" target=\"_blank\"><img src=\"{file_url}\" loading=\"lazy\"></a>"
            f"<figcaption>{html_lib.escape(item['name'])}<br><span>{html_lib.escape(item['mtime'])}</span></figcaption>"
            "</figure>"
        )

    diag_blocks = []
    for item in info["diagnostics"][:20]:
        diag_path = _resolve_repo_path(item["path"])
        try:
            text = diag_path.read_text(encoding="utf-8", errors="replace")[:3000]
        except OSError:
            text = ""
        diag_blocks.append(
            "<details>"
            f"<summary>{html_lib.escape(item['name'])} <span>{html_lib.escape(item['mtime'])}</span></summary>"
            f"<pre>{html_lib.escape(text)}</pre>"
            "</details>"
        )

    missing = ""
    if not info["exists"]:
        missing = (
            "<p class=\"warn\">No adaptive_threshold_visualization folder exists yet. "
            "Run SfM/convert or a pipeline stage that exports semantic masks first.</p>"
        )
    elif not info["images"]:
        missing = "<p class=\"warn\">No region_classification_*.png files were found in this preview folder.</p>"

    body = f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>{html_lib.escape(title)}</title>
  <style>
    body {{ margin: 0; font: 14px/1.45 Arial, sans-serif; color: #111827; background: #f8fafc; }}
    header {{ position: sticky; top: 0; z-index: 1; padding: 14px 18px; background: #fff; border-bottom: 1px solid #d9e2ec; }}
    h1 {{ margin: 0 0 4px; font-size: 18px; }}
    .meta {{ color: #52616b; font-size: 12px; }}
    main {{ padding: 18px; }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 14px; }}
    figure {{ margin: 0; border: 1px solid #d9e2ec; border-radius: 8px; background: #fff; overflow: hidden; }}
    img {{ display: block; width: 100%; height: auto; background: #111827; }}
    figcaption {{ padding: 8px 10px; font-size: 12px; color: #374151; word-break: break-word; }}
    span, .meta {{ color: #6b7280; }}
    details {{ margin: 10px 0; border: 1px solid #d9e2ec; border-radius: 8px; background: #fff; }}
    summary {{ cursor: pointer; padding: 10px 12px; font-weight: 700; }}
    pre {{ margin: 0; padding: 12px; overflow: auto; border-top: 1px solid #d9e2ec; white-space: pre-wrap; font: 12px/1.45 Consolas, monospace; }}
    .warn {{ padding: 12px; border: 1px solid #f0c36d; background: #fff7df; border-radius: 8px; }}
  </style>
</head>
<body>
  <header>
    <h1>{html_lib.escape(title)}</h1>
    <div class="meta">Preview folder: {html_lib.escape(info['preview_dir'])} | images: {len(info['images'])} | diagnostics: {len(info['diagnostics'])}</div>
  </header>
  <main>
    {missing}
    <section class="grid">{''.join(image_cards)}</section>
    <h2>Shadow diagnostics</h2>
    {''.join(diag_blocks) if diag_blocks else '<p class="meta">No shadow diagnostic txt files found.</p>'}
  </main>
</body>
</html>
"""
    encoded = body.encode("utf-8")
    handler.send_response(HTTPStatus.OK)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(encoded)))
    handler.end_headers()
    handler.wfile.write(encoded)


def _dataset_dirs_mentioned_in_message(text: str) -> list[str]:
    message = str(text or "")
    if not message or not DATA_ROOT.is_dir():
        return []
    out: list[str] = []
    seen: set[str] = set()
    names = sorted({path.name for path in _dataset_dirs_for_ui()}, key=len, reverse=True)
    for name in names:
        pattern = rf"(?<![A-Za-z0-9_.-]){re.escape(name)}(?![A-Za-z0-9_.-])"
        if re.search(pattern, message, flags=re.IGNORECASE):
            for path in _dataset_dirs_named(name):
                rel = str(path.relative_to(REPO_ROOT))
                key = rel.lower().replace("/", "\\")
                if key not in seen:
                    seen.add(key)
                    out.append(rel)
    return out


def _looks_like_exclusion_request(text: str) -> bool:
    lowered = str(text or "").lower()
    return any(
        token in lowered
        for token in (
            "except",
            "exclude",
            "excluding",
            "without",
            "other than",
            "\u9664\u4e86",
            "\u6392\u9664",
            "\u5254\u9664",
            "\u4e0d\u5305\u62ec",
            "\u9664\u53bb",
        )
    )


def _mask_dataset_tokens_for_azimuth_parse(text: str) -> str:
    masked = str(text or "")
    if DATA_ROOT.is_dir():
        for path in sorted(_dataset_dirs_for_ui(), key=lambda p: len(p.name), reverse=True):
            masked = re.sub(
                rf"(?<![A-Za-z0-9_.-]){re.escape(path.name)}(?![A-Za-z0-9_.-])",
                " ",
                masked,
                flags=re.IGNORECASE,
            )
    masked = re.sub(r"(?:\.?[\\/])?output[\\/][A-Za-z0-9_.-]+", " ", masked, flags=re.IGNORECASE)
    masked = re.sub(r"[A-Za-z]:[\\/][^\s,;锛屻€傦紱]+", " ", masked)
    return masked


def _data_dirs_from_message(text: str) -> str:
    message = str(text or "")
    normalized = message.lower().replace("/", "\\")
    candidates: list[str] = []

    mentioned = _dataset_dirs_mentioned_in_message(message)
    if mentioned:
        if _looks_like_exclusion_request(message) and ("data" in normalized or "\u6570\u636e" in normalized):
            return str(DATA_ROOT)
        return ";".join(mentioned)

    explicit_data_child = re.search(r"(?:\.?[\\/])?data[\\/][A-Za-z0-9_.-]+", message) is not None
    asks_for_data_root = "data" in normalized and (
        not explicit_data_child
        or any(
            token in normalized
            for token in (
                "内",
                "中",
                "下",
                "所有",
                "全部",
                "不同种类",
                "分别",
                "每个",
                "all",
            )
        )
    )
    if asks_for_data_root:
        candidates.append(str(DATA_ROOT))

    for match in re.finditer(r"[A-Za-z]:[\\/][^\s,;，。；]+|(?:\.?[\\/])?data[\\/][A-Za-z0-9_.-]+", message):
        candidates.append(match.group(0))
    for match in re.finditer(r"(?<![A-Za-z0-9_.-])([A-Za-z]*\d{2,4}-\d+[A-Za-z0-9_.-]*)(?![A-Za-z0-9_.-])", message):
        name = match.group(1)
        matches = _dataset_dirs_named(name)
        if matches:
            candidates.extend(str(path.relative_to(REPO_ROOT)) for path in matches)

    out: list[str] = []
    seen: set[str] = set()
    for raw in candidates:
        item = raw.strip().strip("\"'`").rstrip(",;，。；")
        if re.search(r"(^|[\\/])output([\\/]|$)", item, flags=re.IGNORECASE):
            continue
        resolved_items = [item]
        p = Path(item)
        if not p.is_absolute():
            p = (REPO_ROOT / p).resolve()
        if not p.exists():
            matches = _dataset_dirs_named(p.name)
            if matches:
                resolved_items = [str(path.relative_to(REPO_ROOT)) for path in matches]
        for resolved in resolved_items:
            key = resolved.replace("/", "\\").lower()
            if resolved and key not in seen:
                seen.add(key)
                out.append(resolved)
    return ";".join(out)


def _dataset_tokens_from_message(text: str) -> list[str]:
    message = str(text or "")
    tokens: list[str] = []
    tokens.extend(
        match.group(1)
        for match in re.finditer(r"(?:^|[\\/])data[\\/]+([A-Za-z0-9_.-]+)", message, flags=re.IGNORECASE)
    )
    tokens.extend(
        match.group(1)
        for match in re.finditer(r"(?<![A-Za-z0-9_.-])([A-Za-z0-9]+-[A-Za-z0-9_.-]+)(?![A-Za-z0-9_.-])", message)
    )
    for path in _dataset_dirs_for_ui():
        pattern = rf"(?<![A-Za-z0-9_.-]){re.escape(path.name)}(?![A-Za-z0-9_.-])"
        if re.search(pattern, message, flags=re.IGNORECASE):
            tokens.append(path.name)
    out: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        clean = token.strip().strip("\"'`").rstrip(",;锛屻€傦紱")
        key = clean.lower()
        if clean and key not in seen:
            seen.add(key)
            out.append(clean)
    return out


def _missing_dataset_tokens_from_message(text: str) -> list[str]:
    missing: list[str] = []
    existing = {path.name.lower() for path in _dataset_dirs_for_ui()}
    for token in _dataset_tokens_from_message(text):
        if token.lower() not in existing:
            missing.append(token)
    return missing


def _output_root_from_message(text: str) -> str:
    normalized = str(text or "").strip()
    matches = list(re.finditer(r"[A-Za-z]:[\\/][^\s,;，。；]+|(?:\.?[\\/])?output[\\/][A-Za-z0-9_.-]+", normalized))
    if matches:
        return _clean_mentioned_path(matches[-1].group(0))
    if "output\\step" in normalized.lower() or "output/step" in normalized.lower():
        return str(REPO_ROOT / "output" / "step")
    return ""


def _clean_mentioned_path(raw: str) -> str:
    text = str(raw or "").strip().strip("\"'`").rstrip(",;，。；")
    # Natural-language suffixes often touch a Windows path, e.g. "output\\final中".
    text = text.rstrip("中内里下")
    return text.rstrip(",;，。；")


def _metric_result_path_from_message(text: str) -> str:
    normalized = str(text or "").strip()
    if not normalized:
        return ""
    pattern = r"[A-Za-z]:[\\/][^\s,;，。；]+|(?:\.?[\\/])?output[\\/][^\s,;，。；]+"
    matches = [_clean_mentioned_path(m.group(0)) for m in re.finditer(pattern, normalized)]
    metric_matches = [
        item
        for item in matches
        if any(token in item.lower() for token in ("metrics", "result", "comparison_results", "refiner", "gaussian"))
    ]
    return (metric_matches or matches or [""])[-1]


def _looks_like_metric_analysis_request(text: str) -> bool:
    lowered = str(text or "").lower()
    return any(
        token in lowered
        for token in (
            "量化",
            "指标",
            "结果分析",
            "分析结果",
            "优化方向",
            "调参",
            "调试",
            "评估",
            "评价",
            "metric",
            "metrics",
            "comparison_results",
            "metrics_summary",
            "psnr",
            "ssim",
            "lpips",
            "sar_ssim",
            "analyze result",
            "analyse result",
            "optimization direction",
        )
    )


def _format_angle_number(value: float) -> str:
    return str(int(value)) if float(value).is_integer() else f"{value:g}"


def _azimuth_params_from_message(text: str) -> dict:
    message = _mask_dataset_tokens_for_azimuth_parse(str(text or ""))
    if not message:
        return {}
    degree = r"(?:\s*(?:deg|degree|degrees|\u00b0|\u5ea6))?"
    sep = r"(?:-|~|\uff5e|\u301c|\uff0d|\.\.|\u2013|\u2014|\u5230|\u81f3)"
    step_words = r"(?:\u95f4\u9694|\u6bcf\u9694|\u6b65\u957f|step)"
    range_match = re.search(
        r"(?P<start>-?\d+)"
        + degree
        + r"\s*"
        + sep
        + r"\s*(?P<end>-?\d+)"
        + degree
        + r"[^,;\n\u3002\uff1b]{0,80}?"
        + step_words
        + r"\s*(?:\u4e3a|\u662f|=|:)?\s*(?P<step>\d+)"
        + degree,
        message,
        flags=re.IGNORECASE,
    )
    if range_match:
        return {
            "novel_azimuth_start": int(range_match.group("start")),
            "novel_azimuth_end": int(range_match.group("end")),
            "novel_azimuth_step": int(range_match.group("step")),
        }

    list_match = re.search(
        r"(?:azimuths?|azimuth|\u65b9\u4f4d\u89d2)"
        + r"[^0-9\-\n]{0,12}"
        + r"(?P<angles>-?\d+(?:\.\d+)?(?:\s*(?:,|;|\u3001|\uff0c|\uff1b|\s)\s*-?\d+(?:\.\d+)?)+)",
        message,
        flags=re.IGNORECASE,
    )
    if list_match and not re.search(sep, list_match.group("angles")):
        values = [
            float(token.strip())
            for token in re.split(r"[\s,;\u3001\uff0c\uff1b]+", list_match.group("angles"))
            if token.strip()
        ]
        if values:
            return {"novel_azimuths": ",".join(_format_angle_number(v) for v in values)}
    return {}


def _as_bool(value) -> bool:
    return bool(value) and str(value).lower() not in {"0", "false", "no", "off"}


def _conda_executable() -> str | None:
    candidates = [
        os.environ.get("CONDA_EXE"),
        str(Path.home() / "miniconda3" / "Scripts" / "conda.exe"),
        str(Path.home() / "anaconda3" / "Scripts" / "conda.exe"),
        "conda",
    ]
    for candidate in candidates:
        if not candidate:
            continue
        if candidate == "conda" or Path(candidate).is_file():
            return candidate
    return None


def _python_for_env(env_name: str) -> str | None:
    if not env_name:
        return sys.executable
    conda_prefix = Path(os.environ.get("CONDA_PREFIX", ""))
    if conda_prefix.name.lower() == env_name.lower():
        return sys.executable
    base_candidates = [
        Path.home() / "miniconda3" / "envs" / env_name / "python.exe",
        Path.home() / "anaconda3" / "envs" / env_name / "python.exe",
    ]
    for candidate in base_candidates:
        if candidate.is_file():
            return str(candidate)
    return None


def _env_prefix(env_name: str) -> Path | None:
    if not env_name or env_name.lower() in {"current", "none"}:
        return None
    conda_prefix = Path(os.environ.get("CONDA_PREFIX", ""))
    if conda_prefix.name.lower() == env_name.lower() and conda_prefix.is_dir():
        return conda_prefix
    for candidate in [
        Path.home() / "miniconda3" / "envs" / env_name,
        Path.home() / "anaconda3" / "envs" / env_name,
    ]:
        if candidate.is_dir():
            return candidate
    return None


def _subprocess_env(env_name: str) -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    prefix = _env_prefix(env_name)
    if prefix is not None:
        path_parts = [
            prefix,
            prefix / "Library" / "mingw-w64" / "bin",
            prefix / "Library" / "usr" / "bin",
            prefix / "Library" / "bin",
            prefix / "Scripts",
            prefix / "bin",
            prefix / "DLLs",
        ]
        existing = env.get("PATH", "")
        env["PATH"] = os.pathsep.join(str(p) for p in path_parts if p.exists()) + os.pathsep + existing
        env["CONDA_PREFIX"] = str(prefix)
        env["CONDA_DEFAULT_ENV"] = env_name
    return env


def _agent_launcher(payload: dict) -> tuple[list[str], str]:
    env_name = str(payload.get("conda_env") or DEFAULT_CONDA_ENV).strip()
    if env_name.lower() in {"", "current", "none"}:
        return [sys.executable, "-u", str(AGENT_SCRIPT)], sys.executable

    py = _python_for_env(env_name)
    if py:
        return [py, "-u", str(AGENT_SCRIPT)], py
    conda = _conda_executable()
    if conda:
        return [conda, "run", "-n", env_name, "--no-capture-output", "python", "-u", str(AGENT_SCRIPT)], "python"
    raise ValueError(f"Cannot find conda environment or python for: {env_name}")


def _build_agent_command(payload: dict) -> list[str]:
    cmd, inner_python = _agent_launcher(payload)

    request = str(payload.get("request") or "").strip()
    data_dir = str(payload.get("data_dir") or "").strip()
    if data_dir:
        cmd += ["--data_dir", data_dir]
    elif request:
        cmd += [request]
    else:
        raise ValueError("Enter a request or data folder.")

    cmd += ["--python", inner_python]

    fields = {
        "model_dir": "--model_dir",
        "refiner_work_dir": "--refiner_work_dir",
        "gt_dir": "--gt_dir",
        "eval_gt_dir": "--eval_gt_dir",
        "images": "--images",
        "start_at": "--start_at",
        "stop_after": "--stop_after",
        "device": "--device",
        "novel_pose_mode": "--novel_pose_mode",
        "novel_azimuths": "--novel_azimuths",
        "azimuth_shadow_fixed_direction_deg": "--azimuth_shadow_fixed_direction_deg",
        "classification_label_output_dir": "--classification_label_output_dir",
        "output_root": "--output_root",
        "classification_root": "--classification_root",
        "classification_source": "--classification_source",
        "background_filtered_eval_gt_dir": "--background_filtered_eval_gt_dir",
        "background_filtered_eval_output_dir": "--background_filtered_eval_output_dir",
    }
    for key, flag in fields.items():
        value = payload.get(key)
        if value is not None and str(value).strip() != "":
            cmd += [flag, str(value).strip()]

    numeric_defaults = {
        "gs_iterations": 5000,
        "novel_azimuth_start": 0,
        "novel_azimuth_end": 360,
        "novel_azimuth_step": 5,
        "novel_depression_angle": 15.0,
        "sfm_gs_optical_depression_horizon_deg": 75.0,
        "matched_background_strength": 1.0,
        "matched_background_patch_size": 24,
        "matched_background_patch_overlap": 6,
        "matched_background_patch_smooth": 1,
        "matched_background_patch_smooth_mix": 0.30,
        "matched_background_reference_exclude_dilate": 2,
        "matched_background_nearest_refs": 6,
        "matched_background_reference_clean_blend_refs": 4,
        "matched_background_reference_clean_blend_mix": 0.45,
        "matched_background_reference_clean_angle_sigma": 12.0,
        "matched_background_reference_clean_patch_mix": 0.20,
        "matched_background_min_background_fraction": 0.96,
        "matched_background_shadow_from_render_percentile": 20,
        "matched_background_target_mask_dilate": 1,
        "matched_background_blend_dilate": 0,
        "matched_background_target_mask_blur": 1,
        "matched_background_target_gap_dark_threshold": 0.012,
        "matched_background_target_gap_edge_px": 2,
        "matched_background_target_gap_shadow_protect_threshold": 0.02,
        "target_percentile": 95,
        "target_mask_min_component_area_px": 15,
        "target_edge_outer_px": 1,
        "shadow_percentile": 25,
        "shadow_min_area_fraction": 0.006,
        "shadow_min_target_area_fraction": 0.2,
        "azimuth_shadow_geometry_extent_forward_scale": 1.0,
        "azimuth_shadow_geometry_extent_lateral_scale": 1.0,
        "azimuth_shadow_geometry_extent_margin_px": 1.5,
        "azimuth_shadow_geometry_extent_min_forward_px": 0.0,
        "azimuth_shadow_intensity_strength": 1.22,
        "azimuth_shadow_intensity_min_attenuation": 0.38,
        "azimuth_shadow_intensity_max_attenuation": 0.93,
        "azimuth_shadow_intensity_gamma": 0.80,
        "azimuth_shadow_intensity_context_radius": 13,
        "azimuth_shadow_intensity_block_radius": 7,
        "azimuth_shadow_intensity_exclude_dilate": 2,
        "matched_background_target_mask_dilate": 1,
        "matched_background_blend_dilate": 0,
        "matched_background_target_mask_blur": 1,
        "matched_background_target_gap_dark_threshold": 0.012,
        "matched_background_target_gap_edge_px": 2,
        "matched_background_target_gap_shadow_protect_threshold": 0.02,
    }
    for key, default in numeric_defaults.items():
        value = payload.get(key)
        if value is not None and str(value).strip() != "" and str(value).strip() != str(default):
            cmd += [f"--{key}", str(value).strip()]

    if _as_bool(payload.get("dry_run")):
        cmd += ["--dry_run"]
    if _as_bool(payload.get("skip_sfm")):
        cmd += ["--skip_sfm"]
    if _as_bool(payload.get("skip_gs")):
        cmd += ["--skip_gs"]
    if _as_bool(payload.get("skip_refiner")):
        cmd += ["--skip_refiner"]
    if _as_bool(payload.get("fast_io")):
        cmd += ["--fast_io"]
    is_raysar_data = "raysar" in data_dir.lower()
    is_sfm_only = str(payload.get("start_at") or "").lower() == "sfm" and str(payload.get("stop_after") or "").lower() == "sfm"
    if is_raysar_data and not is_sfm_only and _as_bool(payload.get("raysar_target_only")):
        cmd += ["--raysar_target_only"]
    if str(payload.get("refiner_azimuth_shadow")).lower() in {"0", "false", "no", "off"}:
        cmd += ["--no-refiner_azimuth_shadow"]
    if str(payload.get("azimuth_shadow_geometry_extent_gate")).lower() in {"0", "false", "no", "off"}:
        cmd += ["--no-azimuth_shadow_geometry_extent_gate"]
    elif payload.get("azimuth_shadow_geometry_extent_gate") is not None:
        cmd += ["--azimuth_shadow_geometry_extent_gate"]
    if str(payload.get("azimuth_shadow_geometry_extent_apply_to_recognition")).lower() in {"0", "false", "no", "off"}:
        cmd += ["--no-azimuth_shadow_geometry_extent_apply_to_recognition"]
    elif payload.get("azimuth_shadow_geometry_extent_apply_to_recognition") is not None:
        cmd += ["--azimuth_shadow_geometry_extent_apply_to_recognition"]
    if str(payload.get("azimuth_shadow_geometry_extent_require_dataset_direction")).lower() in {"0", "false", "no", "off"}:
        cmd += ["--no-azimuth_shadow_geometry_extent_require_dataset_direction"]
    elif payload.get("azimuth_shadow_geometry_extent_require_dataset_direction") is not None:
        cmd += ["--azimuth_shadow_geometry_extent_require_dataset_direction"]
    if str(payload.get("matched_real_background")).lower() in {"0", "false", "no", "off"}:
        cmd += ["--no-matched_real_background"]
    else:
        cmd += ["--matched_real_background"]
    shadow_alpha_source = str(payload.get("matched_background_shadow_alpha_source") or "").strip()
    if shadow_alpha_source and shadow_alpha_source != "apply_alpha":
        cmd += ["--matched_background_shadow_alpha_source", shadow_alpha_source]
    if str(payload.get("matched_background_hard_shadow_copy")).lower() in {"1", "true", "yes", "on"}:
        cmd += ["--matched_background_hard_shadow_copy"]
    elif payload.get("matched_background_hard_shadow_copy") is not None:
        cmd += ["--no-matched_background_hard_shadow_copy"]
    if str(payload.get("matched_background_hard_target_copy")).lower() in {"1", "true", "yes", "on"}:
        cmd += ["--matched_background_hard_target_copy"]
    elif payload.get("matched_background_hard_target_copy") is not None:
        cmd += ["--no-matched_background_hard_target_copy"]
    if str(payload.get("export_classification_labels")).lower() in {"0", "false", "no", "off"}:
        cmd += ["--no-export_classification_labels"]
    else:
        cmd += ["--export_classification_labels"]
    if str(payload.get("background_filtered_eval")).lower() in {"0", "false", "no", "off"}:
        cmd += ["--no-background_filtered_eval"]
    elif payload.get("background_filtered_eval") is not None:
        cmd += ["--background_filtered_eval"]
    extra_args = _split_extra_agent_args(str(payload.get("extra_agent_args") or ""))
    if extra_args:
        cmd += extra_args
    if data_dir and request:
        cmd += [request]
    return cmd


def _split_extra_agent_args(raw: str) -> list[str]:
    """Parse raw CLI args from the UI; use this when natural language is too fuzzy."""
    text = str(raw or "").strip()
    if not text:
        return []
    try:
        parts = shlex.split(text, posix=False)
    except ValueError as exc:
        raise ValueError(f"Extra agent args parse failed: {exc}") from exc
    out = []
    for part in parts:
        p = str(part)
        if len(p) >= 2 and p[0] == p[-1] and p[0] in {"'", '"'}:
            p = p[1:-1]
        out.append(p)
    return out


def _run_job(job: Job) -> None:
    job.status = "running"
    job.append(f"[agent ui] started {datetime.now().isoformat(timespec='seconds')}\n")
    job.append(f"[agent ui] cwd: {REPO_ROOT}\n")
    job.append(f"[agent ui] command: {_format_cmd(job.command)}\n\n")
    try:
        env = _subprocess_env(job.conda_env)
        plan_cmd = list(job.command) + ["--plan_only"]
        job.append(f"[agent ui] preflight plan: {_format_cmd(plan_cmd)}\n\n")
        plan_proc = subprocess.run(
            plan_cmd,
            cwd=str(REPO_ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=env,
        )
        if plan_proc.stdout:
            job.append(plan_proc.stdout)
            if not plan_proc.stdout.endswith("\n"):
                job.append("\n")
        if plan_proc.returncode != 0:
            job.returncode = plan_proc.returncode
            job.status = "failed"
            job.append(f"\n[agent ui] preflight failed with code {plan_proc.returncode}; pipeline not started.\n")
            return
        job.append("\n[agent ui] preflight ok; starting pipeline.\n\n")
        proc = subprocess.Popen(
            job.command,
            cwd=str(REPO_ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            env=env,
        )
        job.process = proc
        assert proc.stdout is not None
        for line in proc.stdout:
            job.append(line)
        job.returncode = proc.wait()
        job.status = "ok" if job.returncode == 0 else "failed"
        job.append(f"\n[agent ui] finished with code {job.returncode}\n")
    except Exception as exc:
        job.status = "failed"
        job.append(f"\n[agent ui] failed: {exc}\n")


def _start_job(payload: dict) -> Job:
    cmd = _build_agent_command(payload)
    env_name = str(payload.get("conda_env") or DEFAULT_CONDA_ENV).strip() or DEFAULT_CONDA_ENV
    job = Job(
        id=uuid.uuid4().hex[:12],
        command=cmd,
        created_at=datetime.now().isoformat(timespec="seconds"),
        conda_env=env_name,
    )
    with JOBS_LOCK:
        JOBS[job.id] = job
    thread = threading.Thread(target=_run_job, args=(job,), daemon=True)
    thread.start()
    return job


def _latest_job() -> Job | None:
    with JOBS_LOCK:
        if not JOBS:
            return None
        return sorted(JOBS.values(), key=lambda j: j.created_at)[-1]


def _job_by_id(job_id: str | None) -> Job | None:
    if job_id:
        return JOBS.get(str(job_id))
    return _latest_job()


def _client_kwargs() -> dict:
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("OPENAI_API_KEY is not set.")
    kwargs = {"api_key": key}
    base_url = os.getenv("OPENAI_BASE_URL", "").strip()
    if base_url:
        kwargs["base_url"] = base_url.rstrip("/")
    return kwargs


def _openai_client():
    try:
        from openai import OpenAI
    except Exception as exc:
        raise RuntimeError("Python package 'openai' is not installed in the UI environment.") from exc
    kwargs = _client_kwargs()
    params = inspect.signature(OpenAI).parameters
    if "timeout" in params:
        kwargs["timeout"] = float(os.getenv("OPENAI_TIMEOUT", "60"))
    return OpenAI(**kwargs)


def _tool_result(name: str, arguments: dict, ui_payload: dict) -> dict:
    if name == "list_datasets":
        return {"datasets": _list_datasets()}

    if name == "run_pipeline":
        payload = dict(ui_payload)
        payload.update({k: v for k, v in arguments.items() if v is not None})
        payload.setdefault("conda_env", ui_payload.get("conda_env") or DEFAULT_CONDA_ENV)
        payload.setdefault("device", ui_payload.get("device") or "cuda")
        payload.setdefault("start_at", "sfm")
        payload.setdefault("stop_after", "refiner")
        if "dry_run" not in payload:
            payload["dry_run"] = False
        job = _start_job(payload)
        return {
            "job_id": job.id,
            "status": job.status,
            "dry_run": bool(payload.get("dry_run")),
            "command": _format_cmd(job.command),
            "terminal": True,
        }

    if name == "get_job_status":
        job = _job_by_id(arguments.get("job_id"))
        if not job:
            return {"error": "No job found."}
        snap = job.snapshot()
        snap["logs"] = snap.get("logs", "")[-1200:]
        return snap

    if name == "read_latest_log":
        job = _job_by_id(arguments.get("job_id"))
        if not job:
            return {"error": "No job found."}
        max_chars = int(arguments.get("max_chars") or 4000)
        snap = job.snapshot()
        return {
            "job_id": job.id,
            "status": snap["status"],
            "returncode": snap["returncode"],
            "log_tail": snap.get("logs", "")[-max(200, min(max_chars, 12000)) :],
        }

    if name == "explain_pipeline":
        return {
            "summary": (
                "The workflow runs convert.py for SAR SfM and geometry prior preparation, "
                "train_locked_target_optical.py for target-only 3D Gaussian Splatting, "
                "then sar_novel_view_refiner_pipeline.py for target layover cleanup and azimuth-shadow refinement."
            ),
            "default_outputs": {
                "sfm": "output/<name>/SFM",
                "gs": "output/<name>/gaussian",
                "refiner": "output/<name>/refiner",
                "final_renders": "output/<name>/refiner/03.apply_postprocess/apply/renders",
            },
        }

    if name == "suggest_refiner_params":
        problem = str(arguments.get("problem") or "").lower()
        suggestions = []
        if any(x in problem for x in ["shadow", "阴影"]):
            suggestions.extend([
                "If the shadow is too long, reduce --azimuth_shadow_candidate_length.",
                "If the shadow is too wide/blurred, reduce --azimuth_shadow_candidate_lateral_blur or compose blur.",
                "If shadow direction is wrong, keep --azimuth_shadow_gt_use_global_direction and inspect the estimated train-set direction in logs.",
            ])
        if any(x in problem for x in ["target", "目标", "layover", "叠掩"]):
            suggestions.extend([
                "Inspect intermediate_debug/refiner_target and pre_shadow_renders first.",
                "For target over-cleaning, reduce aggressive extinction/cleanup weights in the refiner stage.",
            ])
        if not suggestions:
            suggestions.append("Start with a dry-run, then compare target-only and global metrics before enabling extra diagnostics.")
        return {"problem": problem, "suggestions": suggestions}

    if name == "analyze_quantitative_results":
        return _analyze_quantitative_results(arguments, ui_payload)

    return {"error": f"Unknown tool: {name}"}


def _message_text_from_responses(response) -> str:
    text = getattr(response, "output_text", None)
    if text:
        return text
    chunks: list[str] = []
    for item in getattr(response, "output", []) or []:
        for content in getattr(item, "content", []) or []:
            value = getattr(content, "text", None)
            if value:
                chunks.append(value)
    return "\n".join(chunks).strip()


def _clean_text_response(value) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.startswith("data:"):
        payloads = []
        for line in text.splitlines():
            line = line.strip()
            if not line.startswith("data:"):
                continue
            raw = line[5:].strip()
            if raw == "[DONE]":
                continue
            try:
                payloads.append(json.loads(raw))
            except Exception:
                pass
        chunks = []
        for payload in payloads:
            for choice in payload.get("choices") or []:
                delta = choice.get("delta") or {}
                msg = choice.get("message") or {}
                content = delta.get("content") or msg.get("content")
                if content:
                    chunks.append(str(content))
        if chunks:
            return "".join(chunks).strip()
        return ""
    return text


def _responses_function_calls(response) -> list[dict]:
    calls = []
    for item in getattr(response, "output", []) or []:
        if getattr(item, "type", None) == "function_call":
            raw_args = getattr(item, "arguments", "{}") or "{}"
            try:
                args = json.loads(raw_args)
            except Exception:
                args = {}
            calls.append({
                "name": getattr(item, "name", ""),
                "arguments": args,
                "call_id": getattr(item, "call_id", None),
            })
    return calls


def _chat_with_responses(user_message: str, ui_payload: dict) -> dict:
    client = _openai_client()
    model = os.getenv("OPENAI_MODEL", DEFAULT_MODEL)
    response = client.responses.create(
        model=model,
        input=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_message},
        ],
        tools=TOOLS,
    )
    calls = _responses_function_calls(response)
    if not calls:
        return {"message": _message_text_from_responses(response) or "我没有得到可显示的回复。"}

    tool_outputs = []
    job_id = None
    for call in calls:
        result = _tool_result(call["name"], call["arguments"], ui_payload)
        if result.get("job_id"):
            job_id = result["job_id"]
        tool_outputs.append({
            "type": "function_call_output",
            "call_id": call["call_id"],
            "output": json.dumps(result, ensure_ascii=False),
        })

    if job_id:
        return {
            "message": f"已启动任务。\n任务 ID：{job_id}\n右侧终端会显示命令和日志。",
            "job_id": job_id,
            "terminal": True,
        }
    if tool_outputs:
        try:
            payload = json.loads(tool_outputs[-1].get("output") or "{}")
        except Exception:
            payload = {}
        if "datasets" in payload:
            datasets = payload.get("datasets") or []
            return {"message": "当前可用数据集：\n" + "\n".join(f"- {x}" for x in datasets)}
        if "summary" in payload:
            return {"message": str(payload["summary"])}
        if "analysis_text" in payload:
            return {"message": str(payload["analysis_text"])}
        if "log_tail" in payload:
            return {"message": str(payload["log_tail"])}
        if "status" in payload:
            return {"message": f"任务状态：{payload.get('status')}，返回码：{payload.get('returncode')}"}

    follow = client.responses.create(
        model=model,
        input=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_message},
            {"role": "assistant", "content": "Local tool calls have completed."},
            {"role": "user", "content": json.dumps(tool_outputs, ensure_ascii=False)},
        ],
        tools=TOOLS,
    )
    return {
        "message": _message_text_from_responses(follow) or "工具已执行，结果见右侧终端。",
        "job_id": job_id,
        "terminal": bool(job_id),
    }


def _chat_tools_for_completions() -> list[dict]:
    return [{"type": "function", "function": {k: v for k, v in tool.items() if k != "type"}} for tool in TOOLS]


def _chat_with_completions(user_message: str, ui_payload: dict) -> dict:
    client = _openai_client()
    model = os.getenv("OPENAI_MODEL", DEFAULT_MODEL)
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_message},
    ]
    first = client.chat.completions.create(
        model=model,
        messages=messages,
        tools=_chat_tools_for_completions(),
    )
    if isinstance(first, str):
        text = _clean_text_response(first)
        if not text:
            raise RuntimeError("Chat Completions returned an empty SSE stream from the proxy.")
        return {"message": text}
    msg = first.choices[0].message
    tool_calls = msg.tool_calls or []
    if not tool_calls:
        return {"message": msg.content or "我没有得到可显示的回复。"}

    messages.append(msg)
    job_id = None
    for call in tool_calls:
        args = json.loads(call.function.arguments or "{}")
        result = _tool_result(call.function.name, args, ui_payload)
        if result.get("job_id"):
            job_id = result["job_id"]
        messages.append({
            "role": "tool",
            "tool_call_id": call.id,
            "content": json.dumps(result, ensure_ascii=False),
        })

    second = client.chat.completions.create(model=model, messages=messages)
    if isinstance(second, str):
        final = _clean_text_response(second)
        if not final:
            final = "工具已执行，但代理返回了空文本；请看右侧终端。"
        return {"message": final, "job_id": job_id, "terminal": bool(job_id)}
    final = second.choices[0].message.content or "工具已执行，结果见右侧终端。"
    return {"message": final, "job_id": job_id, "terminal": bool(job_id)}


def _chat(user_message: str, ui_payload: dict) -> dict:
    lowered = user_message.lower()
    cn_list = ["\u6709\u54ea\u4e9b\u6570\u636e", "\u5217\u51fa\u6570\u636e", "\u6570\u636e\u96c6"]
    cn_explain = ["\u89e3\u91ca\u6d41\u7a0b", "\u6d41\u7a0b\u662f\u4ec0\u4e48"]
    cn_status = ["\u72b6\u6001"]
    cn_log = ["\u65e5\u5fd7", "\u5931\u8d25", "\u9519\u8bef"]
    cn_run = ["\u65b0\u89c6\u89d2", "\u751f\u6210", "\u8bad\u7ec3", "\u5904\u7406", "\u9884\u6f14", "\u6267\u884c", "\u91cd\u8dd1"]
    cn_real_run = ["\u6b63\u5f0f\u8fd0\u884c", "\u771f\u6b63\u8fd0\u884c", "\u53d6\u6d88dry", "\u53d6\u6d88 dry"]
    cn_dry_run = ["\u9884\u6f14", "\u6d4b\u8bd5", "\u5148\u770b\u770b\u547d\u4ee4", "\u770b\u770b\u547d\u4ee4", "\u53ea\u6253\u5370"]
    if any(token in lowered for token in cn_list):
        data = _tool_result("list_datasets", {}, ui_payload)
        datasets = data.get("datasets", [])
        return {"message": "当前可用数据集：\n" + "\n".join(f"- {x}" for x in datasets)}
    if any(token in lowered for token in cn_explain):
        data = _tool_result("explain_pipeline", {}, ui_payload)
        outputs = data["default_outputs"]
        return {
            "message": (
                data["summary"]
                + "\n\n默认输出：\n"
                + f"- SfM: {outputs['sfm']}\n"
                + f"- 3DGS: {outputs['gs']}\n"
                + f"- Refiner: {outputs['refiner']}\n"
                + f"- Final renders: {outputs['final_renders']}"
            )
        }
    if any(token in lowered for token in cn_status + cn_log):
        if any(token in lowered for token in cn_log):
            data = _tool_result("read_latest_log", {"max_chars": 5000}, ui_payload)
            if data.get("error"):
                return {"message": data["error"]}
            return {"message": f"最近任务 {data['job_id']} 状态：{data['status']}\n\n日志尾部：\n{data['log_tail']}"}
        data = _tool_result("get_job_status", {}, ui_payload)
        if data.get("error"):
            return {"message": data["error"]}
        return {"message": f"最近任务 {data['id']} 状态：{data['status']}，返回码：{data['returncode']}"}
    if any(token in lowered for token in ["有哪些数据", "列出数据", "list datasets", "show datasets"]):
        data = _tool_result("list_datasets", {}, ui_payload)
        datasets = data.get("datasets", [])
        return {"message": "当前可用数据集：\n" + "\n".join(f"- {x}" for x in datasets)}

    if any(token in lowered for token in ["解释流程", "流程是什么", "pipeline", "explain workflow"]):
        data = _tool_result("explain_pipeline", {}, ui_payload)
        outputs = data["default_outputs"]
        return {
            "message": (
                data["summary"]
                + "\n\n默认输出：\n"
                + f"- SfM: {outputs['sfm']}\n"
                + f"- 3DGS: {outputs['gs']}\n"
                + f"- Refiner: {outputs['refiner']}\n"
                + f"- Final renders: {outputs['final_renders']}"
            )
        }

    if any(token in lowered for token in ["状态", "status", "日志", "log", "失败", "error"]):
        if "日志" in lowered or "log" in lowered or "失败" in lowered or "error" in lowered:
            data = _tool_result("read_latest_log", {"max_chars": 5000}, ui_payload)
            if data.get("error"):
                return {"message": data["error"]}
            return {"message": f"最近任务 {data['job_id']} 状态：{data['status']}\n\n日志尾部：\n{data['log_tail']}"}
        data = _tool_result("get_job_status", {}, ui_payload)
        if data.get("error"):
            return {"message": data["error"]}
        return {"message": f"最近任务 {data['id']} 状态：{data['status']}，返回码：{data['returncode']}"}

    def _looks_like_all_data_training_request() -> bool:
        has_data = "data" in lowered or "\u6570\u636e" in lowered
        has_all = any(
            token in lowered
            for token in (
                "\u4e0d\u540c\u79cd\u7c7b",
                "\u6240\u6709\u5b50\u6587\u4ef6\u5939",
                "\u5168\u90e8\u5b50\u6587\u4ef6\u5939",
                "\u5206\u522b",
                "all subfolders",
                "all datasets",
            )
        )
        has_action = any(token in lowered for token in cn_run) or any(
            token in lowered for token in ("train", "process", "generate", "run")
        )
        return has_data and has_all and has_action

    data_dir = ""
    missing_dataset_tokens = _missing_dataset_tokens_from_message(user_message)
    mentioned_data_dirs = _dataset_dirs_mentioned_in_message(user_message)
    if mentioned_data_dirs:
        if _looks_like_exclusion_request(user_message) and ("data" in lowered or "\u6570\u636e" in lowered):
            data_dir = str(DATA_ROOT)
        else:
            data_dir = ";".join(mentioned_data_dirs)
    elif _looks_like_all_data_training_request() and not missing_dataset_tokens:
        data_dir = str(DATA_ROOT)
    if not data_dir:
        data_dir = _data_dirs_from_message(user_message)
    if not data_dir:
        data_dir = str(ui_payload.get("data_dir") or "").strip()
    if not data_dir:
        m = re.search(r"(?:[A-Za-z]:[\\/][^\s，。；;,]+|(?:\.?[\\/])?data[\\/][A-Za-z0-9_.-]+)", user_message)
        if m:
            data_dir = m.group(0)
    output_root = _output_root_from_message(user_message)
    azimuth_params = _azimuth_params_from_message(user_message)
    if _looks_like_metric_analysis_request(user_message):
        metric_path = _metric_result_path_from_message(user_message)
        args = {
            "result_path": metric_path,
            "data_dir": data_dir,
            "output_root": output_root,
            "include_per_view": True,
        }
        data = _tool_result("analyze_quantitative_results", args, ui_payload)
        if data.get("analysis_text"):
            return {"message": data["analysis_text"]}
        if data.get("error"):
            tried = data.get("tried") or []
            suffix = "\n\n已尝试：\n" + "\n".join(f"- {x}" for x in tried) if tried else ""
            return {"message": str(data["error"]) + suffix}

    wants_pipeline = any(
        token in lowered
        for token in ["新视角", "生成", "训练", "处理", "run", "dry-run", "dry run", "预演", "执行", "重跑"]
    )
    wants_pipeline = wants_pipeline or bool(data_dir) or any(token in lowered for token in cn_run)
    if wants_pipeline and not data_dir and missing_dataset_tokens:
        missing = ", ".join(f"data\\{name}" for name in missing_dataset_tokens)
        return {"message": f"没有找到对应数据：{missing}。没有可运行的数据集。"}
    if wants_pipeline and data_dir:
        real_run = any(token in lowered for token in ["正式运行", "真正运行", "取消dry", "取消 dry", "real run", "run for real"])
        real_run = real_run or any(token in lowered for token in cn_real_run)
        dry_run = not real_run
        if "dry" in lowered or "预演" in lowered:
            dry_run = True
        if bool(ui_payload.get("dry_run")) or "\u9884\u6f14" in lowered:
            dry_run = True
        explicit_dry_run = (
            "dry-run" in lowered
            or "dry run" in lowered
            or "preview" in lowered
            or "check command" in lowered
            or any(token in lowered for token in cn_dry_run)
        )
        semantic_run = any(
            token in lowered
            for token in ["run", "generate", "process", "train", "execute", "start"]
        ) or any(token in lowered for token in cn_run if token != "\u9884\u6f14")
        dry_run = bool(explicit_dry_run or ui_payload.get("dry_run"))
        if not dry_run and (real_run or semantic_run or data_dir):
            dry_run = False
        start_at = ui_payload.get("start_at") or "sfm"
        stop_after = ui_payload.get("stop_after") or "refiner"
        sfm_only = str(start_at).lower() == "sfm" and str(stop_after).lower() == "sfm"
        args = {
            "request": user_message,
            "data_dir": data_dir,
            "dry_run": dry_run,
            "start_at": start_at,
            "stop_after": stop_after,
            "conda_env": ui_payload.get("conda_env") or DEFAULT_CONDA_ENV,
            "device": ui_payload.get("device") or "cuda",
            "raysar_target_only": (not sfm_only)
            and ("raysar" in data_dir.lower())
            and bool(ui_payload.get("raysar_target_only", False)),
            "export_classification_labels": ui_payload.get("export_classification_labels", True),
        }
        if output_root:
            args["output_root"] = output_root
        args.update(azimuth_params)
        for key in (
            "gt_dir",
            "eval_gt_dir",
            "classification_label_output_dir",
            "classification_root",
            "background_filtered_eval",
            "background_filtered_eval_gt_dir",
            "background_filtered_eval_output_dir",
            "background_filtered_eval_percentile",
            "fast_io",
            "refiner_azimuth_shadow",
            "matched_real_background",
            "matched_background_strength",
            "matched_background_shadow_alpha_source",
            "matched_background_hard_shadow_copy",
            "matched_background_patch_size",
            "matched_background_patch_overlap",
            "matched_background_patch_smooth",
            "matched_background_patch_smooth_mix",
            "matched_background_reference_exclude_dilate",
            "matched_background_nearest_refs",
            "matched_background_reference_clean_blend_refs",
            "matched_background_reference_clean_blend_mix",
            "matched_background_reference_clean_angle_sigma",
            "matched_background_reference_clean_patch_mix",
            "matched_background_min_background_fraction",
            "matched_background_shadow_from_render_percentile",
            "matched_background_target_mask_dilate",
            "matched_background_blend_dilate",
            "matched_background_target_mask_blur",
            "matched_background_target_gap_dark_threshold",
            "matched_background_target_gap_edge_px",
            "matched_background_target_gap_shadow_protect_threshold",
            "matched_background_hard_target_copy",
            "target_percentile",
            "target_mask_min_component_area_px",
            "target_edge_outer_px",
            "shadow_percentile",
            "shadow_min_area_fraction",
            "shadow_min_target_area_fraction",
            "azimuth_shadow_geometry_extent_gate",
            "azimuth_shadow_geometry_extent_apply_to_recognition",
            "azimuth_shadow_geometry_extent_require_dataset_direction",
            "azimuth_shadow_geometry_extent_forward_scale",
            "azimuth_shadow_geometry_extent_lateral_scale",
            "azimuth_shadow_geometry_extent_margin_px",
            "azimuth_shadow_geometry_extent_min_forward_px",
            "azimuth_shadow_intensity_strength",
            "azimuth_shadow_intensity_min_attenuation",
            "azimuth_shadow_intensity_max_attenuation",
            "azimuth_shadow_intensity_gamma",
            "azimuth_shadow_intensity_context_radius",
            "azimuth_shadow_intensity_block_radius",
            "azimuth_shadow_intensity_exclude_dilate",
            "extra_agent_args",
        ):
            if ui_payload.get(key) not in (None, ""):
                args[key] = ui_payload.get(key)
        if output_root and not args.get("classification_label_output_dir"):
            args["classification_label_output_dir"] = output_root
        result = _tool_result("run_pipeline", args, ui_payload)
        mode = "dry-run" if dry_run else "正式运行"
        missing_note = ""
        if missing_dataset_tokens:
            missing = ", ".join(f"data\\{name}" for name in missing_dataset_tokens)
            missing_note = f"未找到并已跳过：{missing}\n"
        return {
            "message": f"{missing_note}已启动 {mode}：{data_dir}\n任务 ID：{result['job_id']}\n右侧终端会显示命令和日志。",
            "job_id": result["job_id"],
            "terminal": True,
        }

    try:
        return _chat_with_responses(user_message, ui_payload)
    except Exception as first_exc:
        try:
            result = _chat_with_completions(user_message, ui_payload)
            result.setdefault("fallback", "chat.completions")
            return result
        except Exception as second_exc:
            return {
                "message": (
                    "远端 LLM 暂时不可用，但本地 agent 仍可直接运行。\n"
                    "请在 Data folder 填入例如：data/360-1，或输入："
                    "对data内不同种类的数据都分别进行训练，结果输出在output\\step中。\n\n"
                    f"LLM 错误：Responses: {first_exc}; Chat fallback: {second_exc}"
                )
            }


HTML = r"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Novel View Agent</title>
  <style>
    :root {
      color-scheme: light;
      --bg: #f4f6f8;
      --panel: #ffffff;
      --ink: #1f2328;
      --muted: #6b7280;
      --line: #d8dee6;
      --field: #f8fafc;
      --accent: #0f766e;
      --blue: #1d4ed8;
      --good: #166534;
      --bad: #b91c1c;
      --term: #111827;
      --term-ink: #d1d5db;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      font-family: "Segoe UI", Arial, sans-serif;
      color: var(--ink);
      background: var(--bg);
    }
    .app {
      height: 100vh;
      display: grid;
      grid-template-columns: 230px minmax(420px, 1fr) minmax(420px, 42vw);
      grid-template-rows: 56px minmax(0, 1fr);
    }
    header {
      grid-column: 1 / -1;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 18px;
      background: var(--panel);
      border-bottom: 1px solid var(--line);
    }
    h1 {
      margin: 0;
      font-size: 18px;
      letter-spacing: 0;
    }
    .top-status {
      display: flex;
      align-items: center;
      gap: 12px;
      min-width: 0;
      color: var(--muted);
      font-size: 13px;
    }
    .status {
      font-weight: 700;
      color: var(--muted);
    }
    .status.running { color: var(--blue); }
    .status.ok { color: var(--good); }
    .status.failed, .status.stopped { color: var(--bad); }
    aside {
      min-height: 0;
      padding: 14px;
      background: var(--panel);
      border-right: 1px solid var(--line);
      overflow: auto;
    }
    .side-title {
      margin: 4px 0 10px;
      font-size: 12px;
      color: var(--muted);
      font-weight: 700;
      text-transform: uppercase;
    }
    .conversation {
      border: 1px solid var(--line);
      border-radius: 7px;
      padding: 10px;
      margin-bottom: 14px;
      background: var(--field);
      font-size: 13px;
      cursor: default;
    }
    label {
      display: block;
      margin: 12px 0 6px;
      color: #374151;
      font-size: 12px;
      font-weight: 700;
    }
    input, select, textarea {
      width: 100%;
      min-height: 36px;
      border: 1px solid var(--line);
      border-radius: 6px;
      padding: 8px 9px;
      background: var(--field);
      font: inherit;
      font-size: 13px;
      outline: none;
    }
    textarea { resize: vertical; }
    input:focus, select:focus, textarea:focus {
      border-color: var(--accent);
      background: #fff;
      box-shadow: 0 0 0 3px rgba(15, 118, 110, .12);
    }
    .check {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 10px 0;
      color: #374151;
      font-size: 13px;
    }
    .check input { width: 16px; min-height: 16px; }
    .chat {
      min-width: 0;
      min-height: 0;
      display: grid;
      grid-template-rows: minmax(0, 1fr) auto;
      background: #fbfcfd;
    }
    .messages {
      min-height: 0;
      overflow: auto;
      padding: 22px;
    }
    .msg {
      max-width: 760px;
      margin: 0 0 14px;
      display: flex;
    }
    .msg.user { margin-left: auto; justify-content: flex-end; }
    .bubble {
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 10px 12px;
      background: var(--panel);
      font-size: 14px;
      line-height: 1.45;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .msg.user .bubble {
      background: #e7f4f1;
      border-color: #b7d9d2;
    }
    .composer {
      padding: 14px;
      border-top: 1px solid var(--line);
      background: var(--panel);
    }
    .compose-row {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto auto;
      gap: 10px;
      align-items: end;
    }
    #prompt {
      min-height: 52px;
      max-height: 160px;
    }
    button {
      border: 1px solid transparent;
      border-radius: 6px;
      min-height: 40px;
      padding: 9px 13px;
      font-weight: 700;
      cursor: pointer;
      background: var(--accent);
      color: white;
    }
    button.secondary {
      color: var(--ink);
      background: #fff;
      border-color: var(--line);
    }
    button.danger {
      color: var(--bad);
      background: #fff;
      border-color: #efb8b8;
    }
    button:disabled {
      opacity: .55;
      cursor: default;
    }
    .terminal {
      min-width: 0;
      min-height: 0;
      display: grid;
      grid-template-rows: 42px minmax(0, 1fr);
      border-left: 1px solid var(--line);
      background: var(--term);
    }
    .terminal-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 0 12px;
      color: #e5e7eb;
      border-bottom: 1px solid #263244;
      font-size: 13px;
      min-width: 0;
    }
    .cmd {
      color: #9ca3af;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      min-width: 0;
    }
    pre {
      min-height: 0;
      margin: 0;
      padding: 14px;
      overflow: auto;
      color: var(--term-ink);
      font: 12px/1.5 Consolas, "Cascadia Mono", monospace;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .tiny {
      margin-top: 8px;
      color: var(--muted);
      font-size: 12px;
      line-height: 1.35;
    }
    @media (max-width: 1100px) {
      .app {
        height: auto;
        min-height: 100vh;
        grid-template-columns: 210px minmax(0, 1fr);
        grid-template-rows: 56px minmax(520px, 1fr) 420px;
      }
      header { grid-column: 1 / -1; }
      aside { grid-row: 2 / 3; }
      .chat { grid-row: 2 / 3; }
      .terminal { grid-column: 1 / -1; grid-row: 3 / 4; border-left: 0; border-top: 1px solid var(--line); }
    }
    @media (max-width: 720px) {
      .app { grid-template-columns: 1fr; grid-template-rows: 56px auto minmax(520px, 1fr) 380px; }
      aside { grid-row: 2 / 3; border-right: 0; border-bottom: 1px solid var(--line); }
      .chat { grid-row: 3 / 4; }
      .terminal { grid-row: 4 / 5; }
      .compose-row { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <div class="app">
    <header>
      <h1>Novel View Agent</h1>
      <div class="top-status">
        <span id="status" class="status">idle</span>
        <span id="jobid">No job</span>
      </div>
    </header>

    <aside>
      <div class="side-title">History</div>
      <div id="history" class="conversation">New conversation</div>

      <div class="side-title">Settings</div>
      <label for="data_dir">Data folder</label>
      <input id="data_dir" list="datasets" placeholder="data/360-1">
      <datalist id="datasets"></datalist>
      <button id="preview_masks" class="secondary" type="button">Preview semantic masks</button>
      <label for="output_root">Output root</label>
      <input id="output_root" placeholder="output or output\\step4">

      <label for="stage_mode">Run range</label>
      <select id="stage_mode">
        <option value="full">SfM -> Gaussian -> Refiner</option>
        <option value="sfm">SfM only</option>
        <option value="gs_only">Gaussian only</option>
        <option value="sfm_gs">SfM -> Gaussian</option>
        <option value="gs_refiner">Gaussian -> Refiner</option>
        <option value="render">Render only</option>
        <option value="refiner">Refiner only</option>
      </select>
      <label for="target_percentile">Target percentile</label>
      <input id="target_percentile" type="number" value="95" min="0" max="100" step="0.1">

      <label class="check"><input id="dry_run" type="checkbox">Dry run</label>

      <label for="conda_env">Conda env</label>
      <input id="conda_env" value="3dgs" placeholder="3dgs, current, or 3dgs_new">

      <label for="device">Device</label>
      <select id="device">
        <option value="cuda">cuda</option>
        <option value="cpu">cpu</option>
      </select>
      <label class="check"><input id="fast_io" type="checkbox">Fast I/O</label>
      <label class="check"><input id="raysar_target_only" type="checkbox">RaySAR target-only preset</label>

      <details>
        <summary class="side-title">Advanced</summary>
        <label for="gs_iterations">3DGS iterations</label>
        <input id="gs_iterations" type="number" value="5000" min="1">
        <label for="novel_azimuth_step">Novel azimuth step</label>
        <input id="novel_azimuth_step" type="number" value="5" min="1">
        <label for="novel_depression_angle">Novel depression angle</label>
        <input id="novel_depression_angle" type="number" value="15" step="0.1">
        <label for="target_mask_min_component_area_px">Target min component area</label>
        <input id="target_mask_min_component_area_px" type="number" value="15" min="0" step="1">
        <label for="target_edge_outer_px">Target outer edge px</label>
        <input id="target_edge_outer_px" type="number" value="1" min="0" step="1">
        <label for="shadow_percentile">Shadow percentile</label>
        <input id="shadow_percentile" type="number" value="25" min="0" max="100" step="0.1">
        <label for="shadow_min_area_fraction">Shadow min area fraction</label>
        <input id="shadow_min_area_fraction" type="number" value="0.006" min="0" max="1" step="0.001">
        <label for="shadow_min_target_area_fraction">Shadow min target area fraction</label>
        <input id="shadow_min_target_area_fraction" type="number" value="0.2" min="0" max="10" step="0.01">
        <label class="check"><input id="refiner_azimuth_shadow" type="checkbox" checked>Azimuth shadow refiner</label>
        <label class="check"><input id="azimuth_shadow_geometry_extent_gate" type="checkbox">Shadow direction extent gate</label>
        <label class="check"><input id="azimuth_shadow_geometry_extent_apply_to_recognition" type="checkbox">Gate recognition shadow</label>
        <label class="check"><input id="azimuth_shadow_geometry_extent_require_dataset_direction" type="checkbox">Require dataset shadow direction</label>
        <label for="azimuth_shadow_geometry_extent_forward_scale">Shadow forward scale</label>
        <input id="azimuth_shadow_geometry_extent_forward_scale" type="number" value="1.0" min="0" max="4" step="0.05">
        <label for="azimuth_shadow_geometry_extent_lateral_scale">Shadow lateral scale</label>
        <input id="azimuth_shadow_geometry_extent_lateral_scale" type="number" value="1.0" min="0" max="4" step="0.05">
        <label for="azimuth_shadow_geometry_extent_margin_px">Shadow gate margin px</label>
        <input id="azimuth_shadow_geometry_extent_margin_px" type="number" value="1.5" min="0" max="20" step="0.5">
        <label for="azimuth_shadow_geometry_extent_min_forward_px">Shadow min forward px</label>
        <input id="azimuth_shadow_geometry_extent_min_forward_px" type="number" value="0.0" min="0" max="20" step="0.5">
        <label for="azimuth_shadow_intensity_strength">Shadow intensity strength</label>
        <input id="azimuth_shadow_intensity_strength" type="number" value="1.22" min="0" max="3" step="0.01">
        <label for="azimuth_shadow_intensity_min_attenuation">Shadow min attenuation</label>
        <input id="azimuth_shadow_intensity_min_attenuation" type="number" value="0.38" min="0" max="1" step="0.01">
        <label for="azimuth_shadow_intensity_max_attenuation">Shadow max attenuation</label>
        <input id="azimuth_shadow_intensity_max_attenuation" type="number" value="0.93" min="0" max="1" step="0.01">
        <label for="azimuth_shadow_intensity_gamma">Shadow intensity gamma</label>
        <input id="azimuth_shadow_intensity_gamma" type="number" value="0.80" min="0.05" max="3" step="0.01">
        <label for="azimuth_shadow_intensity_context_radius">Shadow context radius</label>
        <input id="azimuth_shadow_intensity_context_radius" type="number" value="13" min="1" max="64" step="1">
        <label for="azimuth_shadow_intensity_block_radius">Shadow block radius</label>
        <input id="azimuth_shadow_intensity_block_radius" type="number" value="7" min="0" max="64" step="1">
        <label for="azimuth_shadow_intensity_exclude_dilate">Shadow exclude dilate</label>
        <input id="azimuth_shadow_intensity_exclude_dilate" type="number" value="2" min="0" max="16" step="1">
        <label class="check"><input id="matched_real_background" type="checkbox" checked>Matched real background</label>
        <label for="matched_background_strength">Background strength</label>
        <input id="matched_background_strength" type="number" value="1.0" min="0" max="1" step="0.01">
        <label for="matched_background_shadow_alpha_source">Shadow alpha source</label>
        <select id="matched_background_shadow_alpha_source">
          <option value="apply_alpha">apply_alpha</option>
          <option value="opacity">opacity</option>
          <option value="compose_alpha" selected>compose_alpha</option>
          <option value="max">max</option>
        </select>
        <label class="check"><input id="matched_background_hard_shadow_copy" type="checkbox">Hard shadow copy</label>
        <label class="check"><input id="matched_background_hard_target_copy" type="checkbox">Hard target copy</label>
        <label for="matched_background_target_mask_dilate">Target mask dilate</label>
        <input id="matched_background_target_mask_dilate" type="number" value="1" min="0" max="16" step="1">
        <label for="matched_background_blend_dilate">Blend dilate</label>
        <input id="matched_background_blend_dilate" type="number" value="0" min="0" max="16" step="1">
        <label for="matched_background_target_mask_blur">Target edge blur</label>
        <input id="matched_background_target_mask_blur" type="number" value="1" min="0" max="8" step="1">
        <label for="matched_background_target_gap_dark_threshold">Target gap dark threshold</label>
        <input id="matched_background_target_gap_dark_threshold" type="number" value="0.012" min="0" max="0.2" step="0.001">
        <label for="matched_background_target_gap_edge_px">Target gap edge px</label>
        <input id="matched_background_target_gap_edge_px" type="number" value="2" min="0" max="8" step="1">
        <label for="matched_background_target_gap_shadow_protect_threshold">Gap shadow protect</label>
        <input id="matched_background_target_gap_shadow_protect_threshold" type="number" value="0.02" min="0" max="0.2" step="0.001">
        <label for="matched_background_patch_size">Background patch size</label>
        <input id="matched_background_patch_size" type="number" value="24" min="4">
        <label for="matched_background_reference_clean_blend_mix">Reference blend mix</label>
        <input id="matched_background_reference_clean_blend_mix" type="number" value="0.45" min="0" max="1" step="0.01">
        <label for="matched_background_reference_clean_patch_mix">Patch fill mix</label>
        <input id="matched_background_reference_clean_patch_mix" type="number" value="0.20" min="0" max="1" step="0.01">
        <label for="extra_agent_args">Extra agent args</label>
        <textarea id="extra_agent_args" rows="4" placeholder="--novel_azimuths 0,30,60 --matched_background_strength 0.8"></textarea>
        <label class="check"><input id="export_classification_labels" type="checkbox" checked>Export mask labels</label>
      </details>
      <div class="tiny">取消 Dry run 后会真正运行长任务。右侧终端会实时显示输出。</div>
    </aside>

    <section class="chat">
      <div id="messages" class="messages">
        <div class="msg ai"><div class="bubble">把数据目录或需求发给我，例如：对 data/360-1 进行新视角生成。我会按 SfM、3DGS、refiner 的顺序处理。</div></div>
      </div>
      <div class="composer">
        <div class="compose-row">
          <textarea id="prompt" placeholder="输入问题或任务，例如：我想对 F:\3dgs\SSGR\data\360-1 内的数据进行新视角生成"></textarea>
          <button id="send">Send</button>
          <button id="stop" class="danger" disabled>Stop</button>
        </div>
      </div>
    </section>

    <section class="terminal">
      <div class="terminal-head">
        <strong>Terminal</strong>
        <span id="cmd" class="cmd">No command yet</span>
        <button id="copy" class="secondary">Copy</button>
      </div>
      <pre id="log"></pre>
    </section>
  </div>

  <script>
    let currentJob = null;
    let timer = null;
    const $ = (id) => document.getElementById(id);
    const messages = $("messages");
    const log = $("log");
    const statusEl = $("status");
    const jobidEl = $("jobid");
    const cmdEl = $("cmd");

    function addMessage(role, text) {
      const wrap = document.createElement("div");
      wrap.className = "msg " + (role === "user" ? "user" : "ai");
      const bubble = document.createElement("div");
      bubble.className = "bubble";
      bubble.textContent = text;
      wrap.appendChild(bubble);
      messages.appendChild(wrap);
      messages.scrollTop = messages.scrollHeight;
    }

    function setStatus(text, cls) {
      statusEl.textContent = text;
      statusEl.className = "status " + (cls || "");
    }

    function stagePayload() {
      const mode = $("stage_mode").value;
      if (mode === "sfm") return {start_at: "sfm", stop_after: "sfm"};
      if (mode === "gs_only") return {start_at: "gs", stop_after: "gs"};
      if (mode === "sfm_gs") return {start_at: "sfm", stop_after: "gs"};
      if (mode === "gs_refiner") return {start_at: "gs", stop_after: "refiner"};
      if (mode === "render") return {start_at: "render", stop_after: "render"};
      if (mode === "refiner") return {start_at: "refiner", stop_after: "refiner"};
      return {start_at: "sfm", stop_after: "refiner"};
    }

    function looksLikeRaySar(value) {
      return String(value || "").toLowerCase().includes("raysar");
    }

    function applyRaySarPreset() {
      if ($("raysar_target_only").checked) {
        $("refiner_azimuth_shadow").checked = false;
        $("matched_real_background").checked = false;
        $("export_classification_labels").checked = false;
      } else {
        $("refiner_azimuth_shadow").checked = true;
        $("matched_real_background").checked = true;
        $("export_classification_labels").checked = true;
      }
    }

    function updateRaySarPresetFromData() {
      if (!looksLikeRaySar($("data_dir").value) && $("data_dir").value.trim()) {
        $("raysar_target_only").checked = false;
      }
    }

    function payload() {
      const stages = stagePayload();
      const dataDir = $("data_dir").value.trim();
      const raySarMode = looksLikeRaySar(dataDir) && $("raysar_target_only").checked && stages.stop_after !== "sfm";
      return {
        request: $("prompt").value.trim(),
        data_dir: dataDir,
        output_root: $("output_root").value.trim(),
        dry_run: $("dry_run").checked,
        conda_env: $("conda_env").value.trim(),
        device: $("device").value,
        fast_io: $("fast_io").checked,
        raysar_target_only: raySarMode,
        gs_iterations: $("gs_iterations").value,
        novel_azimuth_step: $("novel_azimuth_step").value,
        novel_depression_angle: $("novel_depression_angle").value,
        target_percentile: $("target_percentile").value,
        target_mask_min_component_area_px: $("target_mask_min_component_area_px").value,
        target_edge_outer_px: $("target_edge_outer_px").value,
        shadow_percentile: $("shadow_percentile").value,
        shadow_min_area_fraction: $("shadow_min_area_fraction").value,
        shadow_min_target_area_fraction: $("shadow_min_target_area_fraction").value,
        refiner_azimuth_shadow: $("refiner_azimuth_shadow").checked,
        azimuth_shadow_geometry_extent_gate: $("azimuth_shadow_geometry_extent_gate").checked,
        azimuth_shadow_geometry_extent_apply_to_recognition: $("azimuth_shadow_geometry_extent_apply_to_recognition").checked,
        azimuth_shadow_geometry_extent_require_dataset_direction: $("azimuth_shadow_geometry_extent_require_dataset_direction").checked,
        azimuth_shadow_geometry_extent_forward_scale: $("azimuth_shadow_geometry_extent_forward_scale").value,
        azimuth_shadow_geometry_extent_lateral_scale: $("azimuth_shadow_geometry_extent_lateral_scale").value,
        azimuth_shadow_geometry_extent_margin_px: $("azimuth_shadow_geometry_extent_margin_px").value,
        azimuth_shadow_geometry_extent_min_forward_px: $("azimuth_shadow_geometry_extent_min_forward_px").value,
        azimuth_shadow_intensity_strength: $("azimuth_shadow_intensity_strength").value,
        azimuth_shadow_intensity_min_attenuation: $("azimuth_shadow_intensity_min_attenuation").value,
        azimuth_shadow_intensity_max_attenuation: $("azimuth_shadow_intensity_max_attenuation").value,
        azimuth_shadow_intensity_gamma: $("azimuth_shadow_intensity_gamma").value,
        azimuth_shadow_intensity_context_radius: $("azimuth_shadow_intensity_context_radius").value,
        azimuth_shadow_intensity_block_radius: $("azimuth_shadow_intensity_block_radius").value,
        azimuth_shadow_intensity_exclude_dilate: $("azimuth_shadow_intensity_exclude_dilate").value,
        matched_real_background: $("matched_real_background").checked,
        matched_background_strength: $("matched_background_strength").value,
        matched_background_shadow_alpha_source: $("matched_background_shadow_alpha_source").value,
        matched_background_hard_shadow_copy: $("matched_background_hard_shadow_copy").checked,
        matched_background_hard_target_copy: $("matched_background_hard_target_copy").checked,
        matched_background_target_mask_dilate: $("matched_background_target_mask_dilate").value,
        matched_background_blend_dilate: $("matched_background_blend_dilate").value,
        matched_background_target_mask_blur: $("matched_background_target_mask_blur").value,
        matched_background_target_gap_dark_threshold: $("matched_background_target_gap_dark_threshold").value,
        matched_background_target_gap_edge_px: $("matched_background_target_gap_edge_px").value,
        matched_background_target_gap_shadow_protect_threshold: $("matched_background_target_gap_shadow_protect_threshold").value,
        matched_background_patch_size: $("matched_background_patch_size").value,
        matched_background_reference_clean_blend_mix: $("matched_background_reference_clean_blend_mix").value,
        matched_background_reference_clean_patch_mix: $("matched_background_reference_clean_patch_mix").value,
        extra_agent_args: $("extra_agent_args").value.trim(),
        export_classification_labels: $("export_classification_labels").checked,
        start_at: stages.start_at,
        stop_after: stages.stop_after
      };
    }

    async function loadDatasets() {
      const res = await fetch("/api/datasets");
      const data = await res.json();
      $("datasets").innerHTML = data.datasets.map(x => `<option value="${x}"></option>`).join("");
    }

    $("preview_masks").onclick = () => {
      const dataDir = $("data_dir").value.trim();
      if (!dataDir) {
        addMessage("ai", "Select a data folder first, for example data/2S1.");
        return;
      }
      window.open(`/semantic_preview?data_dir=${encodeURIComponent(dataDir)}`, "_blank");
    };

    $("data_dir").addEventListener("input", updateRaySarPresetFromData);
    $("raysar_target_only").addEventListener("change", applyRaySarPreset);

    async function poll() {
      if (!currentJob) return;
      const res = await fetch(`/api/jobs/${currentJob}`);
      const data = await res.json();
      setStatus(data.status, data.status);
      jobidEl.textContent = data.id ? `Job ${data.id}` : "No job";
      cmdEl.textContent = data.command || "";
      const nearBottom = log.scrollTop + log.clientHeight > log.scrollHeight - 80;
      log.textContent = data.logs || "";
      if (nearBottom) log.scrollTop = log.scrollHeight;
      if (["ok", "failed", "stopped"].includes(data.status)) {
        clearInterval(timer);
        timer = null;
        $("send").disabled = false;
        $("stop").disabled = true;
        const final = data.status === "ok" ? "任务完成。结果路径和记录已在终端输出里列出。" : `任务状态：${data.status}。请看右侧终端最后的错误信息。`;
        addMessage("ai", final);
      }
    }

    $("send").onclick = async () => {
      const text = $("prompt").value.trim();
      const dataDir = $("data_dir").value.trim();
      if (!text && !dataDir) {
        addMessage("ai", "请输入任务，或者在左侧填写 data folder。");
        return;
      }
      const requestPayload = payload();
      addMessage("user", text || `Run novel view generation for ${dataDir}`);
      $("prompt").value = "";
      $("send").disabled = true;
      $("stop").disabled = false;
      setStatus("starting", "running");
      log.textContent = "";

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(requestPayload)
      });
      const data = await res.json();
      if (!res.ok) {
        setStatus("failed", "failed");
        addMessage("ai", data.error || "任务启动失败。");
        $("send").disabled = false;
        $("stop").disabled = true;
        return;
      }
      addMessage("ai", data.message || "已处理。");
      if (data.job_id) {
        currentJob = data.job_id;
        await poll();
        timer = setInterval(poll, 250);
      } else {
        $("send").disabled = false;
        $("stop").disabled = true;
        setStatus("idle", "");
      }
    };

    $("prompt").addEventListener("keydown", (event) => {
      if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        $("send").click();
      }
    });

    $("stop").onclick = async () => {
      if (!currentJob) return;
      await fetch(`/api/jobs/${currentJob}/stop`, {method: "POST"});
      addMessage("ai", "已请求停止当前任务。");
      await poll();
    };

    $("copy").onclick = async () => {
      await navigator.clipboard.writeText(log.textContent);
    };

    loadDatasets();
  </script>
</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):
    server_version = "NovelViewAgentUI/0.1"

    def _send_json(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self) -> None:
        body = HTML.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length") or "0")
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def log_message(self, fmt: str, *args) -> None:
        print(f"[ui] {self.address_string()} - {fmt % args}")

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        query = parse_qs(parsed.query)
        if path == "/":
            self._send_html()
            return
        if path == "/semantic_preview":
            data_dir = (query.get("data_dir") or [""])[0]
            _send_semantic_preview_html(self, data_dir)
            return
        if path == "/semantic_preview/file":
            file_path = (query.get("path") or [""])[0]
            try:
                _send_file_response(self, _resolve_repo_path(file_path))
            except Exception as exc:
                self.send_error(HTTPStatus.BAD_REQUEST, str(exc))
            return
        if path == "/api/datasets":
            self._send_json({"datasets": _list_datasets()})
            return
        if path == "/api/semantic_preview":
            try:
                data_dir = (query.get("data_dir") or [""])[0]
                self._send_json(_semantic_preview_files(_resolve_data_dir(data_dir)))
            except Exception as exc:
                self._send_json({"error": str(exc)}, 400)
            return
        if path.startswith("/api/jobs/"):
            job_id = path.split("/")[-1]
            job = JOBS.get(job_id)
            if not job:
                self._send_json({"error": "job not found"}, 404)
                return
            self._send_json(job.snapshot())
            return
        self._send_json({"error": "not found"}, 404)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        if path == "/api/chat":
            try:
                payload = self._read_json()
                user_message = str(payload.get("request") or payload.get("message") or "").strip()
                if not user_message and str(payload.get("data_dir") or "").strip():
                    user_message = f"对 {payload.get('data_dir')} 进行新视角生成"
                if not user_message:
                    raise ValueError("Enter a message or data folder.")
                result = _chat(user_message, payload)
            except Exception as exc:
                self._send_json({"error": str(exc)}, 500)
                return
            self._send_json(result)
            return
        if path == "/api/run":
            try:
                job = _start_job(self._read_json())
            except Exception as exc:
                self._send_json({"error": str(exc)}, 400)
                return
            self._send_json({"id": job.id, "status": job.status})
            return
        if path.startswith("/api/jobs/") and path.endswith("/stop"):
            job_id = path.split("/")[-2]
            job = JOBS.get(job_id)
            if not job:
                self._send_json({"error": "job not found"}, 404)
                return
            if job.process is not None and job.process.poll() is None:
                job.process.terminate()
                job.status = "stopped"
                job.append("\n[agent ui] stop requested\n")
                time.sleep(0.5)
                if job.process.poll() is None:
                    job.process.kill()
            self._send_json(job.snapshot())
            return
        self._send_json({"error": "not found"}, 404)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Tiny local UI for novel_view_agent.py")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--open", action=argparse.BooleanOptionalAction, default=False)
    args = parser.parse_args(argv)

    server = ThreadingHTTPServer((args.host, int(args.port)), Handler)
    url = f"http://{args.host}:{args.port}/"
    print(f"[novel view agent ui] {url}")
    if args.open:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[novel view agent ui] stopped")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
