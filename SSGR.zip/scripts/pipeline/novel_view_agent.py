#!/usr/bin/env python3
"""One-command SAR novel-view generation agent.

The agent turns a data folder request into the existing three-stage workflow:

1. convert.py SfM / geometry prior preparation, archived into data/<name>/sfm/<timestamp>
   and mirrored lightly into output/<name>/SFM.
2. train_locked_target_optical.py target-only 3DGS, writing into output/<name>/gaussian
   unless --model_dir is provided.
3. sar_novel_view_refiner_pipeline.py full_train, writing refiner work files into
   output/<name>/refiner unless --refiner_work_dir is provided.

Examples:
    python scripts/pipeline/novel_view_agent.py --data_dir data/360-1 --dry_run
    python scripts/pipeline/novel_view_agent.py --data_dirs data/360-1 data/360-3 --dry_run
    python scripts/pipeline/novel_view_agent.py --data_dir "data/360-1;data/360-3" --dry_run
    python scripts/pipeline/novel_view_agent.py --data_dir data/360-1 --output_root output/step --novel_azimuth_step 1
    python scripts/pipeline/novel_view_agent.py "generate novel views for F:\\3dgs\\SSGR\\data\\360-1"
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
from sar.semantic_mask_config import mask_default

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}
SFM_LIGHT_MIRROR_DIRS = (
    "sparse",
    "sfm_results",
    "geometry_prior",
)
SFM_FULL_MIRROR_DIRS = SFM_LIGHT_MIRROR_DIRS + (
    "scattering_masks",
    "adaptive_threshold_visualization",
    "feature_matches",
    "feature_visualization",
    "error_logs",
    "convert_logs",
)
SFM_MIRROR_FILES = ("sar_scale_params.json",)


def _configure_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


def _safe_print(text: object = "", *, flush: bool = False) -> None:
    try:
        print(text, flush=flush)
    except UnicodeEncodeError:
        encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
        data = (str(text) + "\n").encode(encoding, errors="replace")
        buffer = getattr(sys.stdout, "buffer", None)
        if buffer is not None:
            buffer.write(data)
            if flush:
                buffer.flush()
        else:
            sys.stdout.write(data.decode(encoding, errors="replace"))
            if flush:
                sys.stdout.flush()


_configure_stdio()


_ERROR_SUMMARY_RE = re.compile(
    r"(Traceback|ERROR|Error|Exception|ValueError|RuntimeError|FileNotFound|"
    r"CalledProcessError|failed|失败|错误)",
    re.IGNORECASE,
)


def _log_error_summary(log_path: Path | None, *, max_lines: int = 8) -> list[str]:
    if log_path is None or not log_path.is_file():
        return []
    try:
        lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    matches: list[str] = []
    for line in lines:
        clean = line.strip()
        if clean and _ERROR_SUMMARY_RE.search(clean):
            matches.append(clean)
    deduped: list[str] = []
    for line in matches[-max_lines:]:
        if not deduped or deduped[-1] != line:
            deduped.append(line)
    return deduped


@dataclass
class StepRecord:
    stage: str
    command: str
    cwd: str
    started_at: str
    ended_at: str | None = None
    duration_sec: float | None = None
    status: str = "pending"


def _format_cmd(cmd: list[str]) -> str:
    if os.name == "nt":
        return subprocess.list2cmdline([str(x) for x in cmd])
    import shlex

    return shlex.join([str(x) for x in cmd])


def _resolve_path(path: str | Path | None, base: Path = REPO_ROOT) -> Path | None:
    if path is None:
        return None
    p = Path(path).expanduser()
    if p.is_absolute():
        return p.resolve()
    return (base / p).resolve()


def _strip_prompt_path(path: str) -> str:
    return path.strip().strip("\"'`").rstrip("，。；;,.")


def _normalize_data_dir(path: Path) -> Path:
    if path.name.lower() in {"input", "images", "images_target_black"}:
        return path.parent
    return path


_ALL_CHILDREN_MARKERS = (
    "所有子文件夹",
    "全部子文件夹",
    "所有子目录",
    "全部子目录",
    "all subfolders",
    "all subdirectories",
    "all child folders",
)
_ALL_CHILDREN_MARKERS += (
    "\u6240\u6709\u5b50\u6587\u4ef6\u5939",
    "\u5168\u90e8\u5b50\u6587\u4ef6\u5939",
    "\u6240\u6709\u5b50\u76ee\u5f55",
    "\u5168\u90e8\u5b50\u76ee\u5f55",
    "\u4e0d\u540c\u79cd\u7c7b",
    "\u5404\u4e2a\u79cd\u7c7b",
    "\u6bcf\u4e2a\u79cd\u7c7b",
    "\u90fd\u5206\u522b",
    "\u5206\u522b\u8fdb\u884c\u8bad\u7ec3",
)

_EXCLUSION_MARKERS = (
    "except",
    "exclude",
    "excluding",
    "without",
    "other than",
    "\u9664\u4e86",
    "\u6392\u9664",
    "\u5254\u9664",
    "\u4e0d\u5305\u62ec",
    "\u9664\u53bb",
)


def _looks_like_all_children_request(text: str) -> bool:
    normalized = str(text or "").lower()
    return any(marker in normalized for marker in _ALL_CHILDREN_MARKERS)


def _looks_like_exclusion_request(text: str) -> bool:
    normalized = str(text or "").lower()
    return any(marker in normalized for marker in _EXCLUSION_MARKERS)


def _mentions_data_root(text: str, data_root: Path) -> bool:
    normalized = str(text or "").lower().replace("/", "\\")
    root = str(data_root).lower().replace("/", "\\")
    return (
        root in normalized
        or re.search(r"(^|[\\])data($|[\\]|\u4e2d)", normalized) is not None
        or re.search(r"data\s*(?:\u5185|\u4e0b|\u91cc|\u4e2d)", normalized) is not None
        or re.search(r"\bdata\b", normalized) is not None
    )


def _split_path_list(text: str) -> list[str]:
    """Split a user-entered path list without treating Windows drive colons as separators."""
    parts = [p.strip() for p in re.split(r"[\n,，;；]+", str(text or "")) if p.strip()]
    return parts or ([text.strip()] if str(text or "").strip() else [])


def _dataset_child_dirs(data_root: Path) -> list[Path]:
    if not data_root.is_dir():
        return []
    return [p.resolve() for p in sorted(data_root.iterdir()) if p.is_dir() and _count_dataset_images(p) > 0]


def _dataset_dirs_mentioned_by_name(text: str, data_root: Path) -> list[Path]:
    message = str(text or "")
    if not message or not data_root.is_dir():
        return []
    out: list[Path] = []
    seen: set[str] = set()
    for path in sorted(_dataset_child_dirs(data_root), key=lambda p: len(p.name), reverse=True):
        pattern = rf"(?<![A-Za-z0-9_.-]){re.escape(path.name)}(?![A-Za-z0-9_.-])"
        if re.search(pattern, message, flags=re.IGNORECASE):
            key = str(path.resolve()).lower()
            if key not in seen:
                seen.add(key)
                out.append(path)
    return out


def _excluded_data_dirs_from_request(text: str, data_root: Path) -> list[Path]:
    if not (_looks_like_exclusion_request(text) and _mentions_data_root(text, data_root)):
        return []
    excluded: list[Path] = []
    excluded.extend(_dataset_dirs_mentioned_by_name(text, data_root))
    for raw in re.findall(r"(?:\.?[\\/])?data[\\/][A-Za-z0-9_.-]+", str(text or ""), flags=re.IGNORECASE):
        expanded = _expand_data_dir_token(raw, data_root)
        excluded.extend(p for p in expanded if p.exists() and _count_dataset_images(p) > 0)
    return _dedupe_paths(excluded)


def _expand_data_dir_token(raw: str, data_root: Path) -> list[Path]:
    clean = _strip_prompt_path(raw)
    if _looks_like_all_children_request(clean) and _mentions_data_root(clean, data_root):
        return _dataset_child_dirs(data_root)

    p = _resolve_path(clean)
    if p is None:
        return []
    p = _normalize_data_dir(p)
    if p.exists() and p.resolve() == data_root.resolve() and _count_dataset_images(p) == 0:
        return _dataset_child_dirs(data_root)
    return [p]


def _candidate_data_dirs_from_prompt(prompt: str, data_root: Path) -> list[Path]:
    text = prompt.strip()
    if not text:
        return []
    if _looks_like_all_children_request(text) and _mentions_data_root(text, data_root):
        return _dataset_child_dirs(data_root)

    quoted = re.findall(r"""["'`](.+?)["'`]""", text)
    drive_paths = re.findall(r"[A-Za-z]:[\\/][^\s，。；;,]+", text)
    rel_paths = re.findall(r"(?:\.?[\\/])?data[\\/][A-Za-z0-9_.-]+", text)
    bare_datasets = re.findall(r"(?<![A-Za-z0-9_.-])([A-Za-z]*\d{2,4}-\d+[A-Za-z0-9_.-]*)(?![A-Za-z0-9_.-])", text)

    candidates: list[str] = []
    candidates.extend(quoted)
    candidates.extend(drive_paths)
    candidates.extend(rel_paths)
    candidates.extend(str(data_root / name) for name in bare_datasets)

    out: list[Path] = []
    for raw in candidates:
        for item in _split_path_list(raw):
            out.extend(_expand_data_dir_token(item, data_root))
    return out


def _extract_data_dir_from_prompt(prompt: str, data_root: Path) -> Path | None:
    for p in _candidate_data_dirs_from_prompt(prompt, data_root):
        if p.exists():
            return p
    return None


def _dedupe_paths(paths: list[Path]) -> list[Path]:
    seen: set[str] = set()
    out: list[Path] = []
    for path in paths:
        key = str(path.resolve()).lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(path)
    return out


def _resolve_data_dirs(args: argparse.Namespace, data_root: Path) -> list[Path]:
    candidates: list[Path] = []
    raw_values: list[str] = []
    prompt = " ".join(getattr(args, "request", []) or [])
    excluded_from_prompt = _excluded_data_dirs_from_request(prompt, data_root)
    if excluded_from_prompt:
        excluded_keys = {str(path.resolve()).lower() for path in excluded_from_prompt}
        selected = [path for path in _dataset_child_dirs(data_root) if str(path.resolve()).lower() not in excluded_keys]
        excluded_names = ", ".join(path.name for path in excluded_from_prompt)
        selected_names = ", ".join(path.name for path in selected) or "(none)"
        print(f"[agent] exclusion request: skipped {excluded_names}; selected {selected_names}")
        return _dedupe_paths(selected)

    if getattr(args, "data_dir", None):
        raw_values.extend(_split_path_list(str(args.data_dir)))
    for raw in getattr(args, "data_dirs", []) or []:
        raw_values.extend(_split_path_list(str(raw)))

    missing_explicit: list[str] = []
    for raw in raw_values:
        expanded = _expand_data_dir_token(raw, data_root)
        valid = [p for p in expanded if p.exists() and _count_dataset_images(p) > 0]
        if valid:
            candidates.extend(valid)
        else:
            missing_explicit.append(raw)

    if raw_values and candidates:
        if missing_explicit:
            missing = ", ".join(missing_explicit)
            print(f"[agent warning] skipped missing data_dir entries: {missing}")
        return _dedupe_paths(candidates)
    if raw_values and missing_explicit:
        missing = ", ".join(missing_explicit)
        raise FileNotFoundError(f"Requested data_dir entries were not found or contain no images: {missing}")

    candidates.extend(_candidate_data_dirs_from_prompt(prompt, data_root))
    candidates = [p for p in candidates if p.exists() and _count_dataset_images(p) > 0]
    return _dedupe_paths(candidates)


def _resolve_output_root(args: argparse.Namespace, data_root: Path) -> Path:
    default_output = str(REPO_ROOT / "output")
    if str(args.output_root) != default_output:
        return _resolve_path(args.output_root) or (REPO_ROOT / "output")

    raw_values: list[str] = []
    if getattr(args, "data_dir", None):
        raw_values.extend(_split_path_list(str(args.data_dir)))
    for raw in getattr(args, "data_dirs", []) or []:
        raw_values.extend(_split_path_list(str(raw)))

    for raw in raw_values:
        if _looks_like_all_children_request(raw) and _mentions_data_root(raw, data_root):
            continue
        p = _resolve_path(_strip_prompt_path(raw))
        if p is None:
            continue
        p = _normalize_data_dir(p)
        if not p.exists() or _count_dataset_images(p) == 0:
            return p
    prompt_output = _extract_output_root_from_prompt(" ".join(getattr(args, "request", []) or []))
    if prompt_output is not None:
        return prompt_output
    return _resolve_path(args.output_root) or (REPO_ROOT / "output")


def _extract_output_root_from_prompt(prompt: str) -> Path | None:
    text = str(prompt or "").strip()
    if not text:
        return None
    candidates: list[str] = []
    candidates.extend(re.findall(r"[A-Za-z]:[\\/][^\s\u4e00-\u9fff,;]+", text))
    candidates.extend(re.findall(r"(?:\.?[\\/])?output[\\/][A-Za-z0-9_.-]+", text, flags=re.IGNORECASE))
    for raw in candidates:
        clean = _strip_prompt_path(raw).rstrip("\u4e2d\u5185\u4e0b\u91cc")
        normalized = clean.lower().replace("/", "\\")
        if "\\output\\" in normalized or normalized.startswith("output\\") or normalized.startswith(".\\output\\"):
            return _resolve_path(clean)
    return None


def _format_number(value: float) -> str:
    return str(int(value)) if float(value).is_integer() else f"{value:g}"


def _parse_float_list(raw: str) -> list[float]:
    values: list[float] = []
    for token in re.split(r"[\s,;\u3001\uff0c\uff1b]+", str(raw or "")):
        token = token.strip()
        if not token:
            continue
        try:
            values.append(float(token))
        except ValueError:
            continue
    return values


def _format_angle_list(values: list[float]) -> str:
    return ",".join(_format_number(v) for v in values)


def _dedupe_numbers(values: list[float]) -> list[float]:
    out: list[float] = []
    seen: set[str] = set()
    for value in values:
        key = _format_number(value)
        if key in seen:
            continue
        seen.add(key)
        out.append(value)
    return out


def _novel_azimuth_values(args: argparse.Namespace) -> list[float]:
    explicit = str(getattr(args, "novel_azimuths", "") or "").strip()
    if explicit:
        values = _dedupe_numbers(_parse_float_list(explicit))
        if not values:
            raise ValueError("--novel_azimuths did not contain any numeric azimuths")
        return values
    step = int(args.novel_azimuth_step)
    if step <= 0:
        raise ValueError("--novel_azimuth_step must be positive")
    values = [float(v) for v in range(int(args.novel_azimuth_start), int(args.novel_azimuth_end), step)]
    if not values:
        raise ValueError(
            "novel azimuth range is empty; check --novel_azimuth_start, "
            "--novel_azimuth_end, and --novel_azimuth_step"
        )
    return values


def _novel_azimuth_summary(args: argparse.Namespace) -> dict:
    values = _novel_azimuth_values(args)
    return {
        "start": _format_number(values[0]),
        "end": _format_number(values[-1]),
        "step": None if getattr(args, "novel_azimuths", None) else int(args.novel_azimuth_step),
        "count": len(values),
        "mode": "explicit" if getattr(args, "novel_azimuths", None) else "range",
    }


def _expected_novel_render_names(args: argparse.Namespace) -> set[str]:
    names: set[str] = set()
    for value in _novel_azimuth_values(args):
        rounded = int(round(value))
        if abs(float(value) - float(rounded)) > 1e-6:
            raise ValueError(f"novel azimuth filenames require integer degrees, got {value:g}")
        names.add(f"azimuth_{rounded:03d}.png")
    return names


def _parse_novel_azimuth_request(prompt: str) -> dict[str, object]:
    text = str(prompt or "")
    if not text:
        return {}
    data_root = REPO_ROOT / "data"
    if data_root.is_dir():
        for path in sorted(data_root.iterdir(), key=lambda p: len(p.name), reverse=True):
            if path.is_dir():
                text = re.sub(
                    rf"(?<![A-Za-z0-9_.-]){re.escape(path.name)}(?![A-Za-z0-9_.-])",
                    " ",
                    text,
                    flags=re.IGNORECASE,
                )
    text = re.sub(r"(?:\.?[\\/])?output[\\/][A-Za-z0-9_.-]+", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"[A-Za-z]:[\\/][^\s\u4e00-\u9fff,;]+", " ", text)
    degree = r"(?:\s*(?:deg|degree|degrees|\u00b0|\u5ea6))?"
    sep = r"(?:-|~|\uff5e|\u301c|\uff0d|\.\.|\u2013|\u2014|\u5230|\u81f3)"
    step_words = r"(?:\u95f4\u9694|\u6bcf\u9694|\u6b65\u957f|step)"
    range_re = re.compile(
        r"(?P<start>-?\d+)"
        + degree
        + r"\s*"
        + sep
        + r"\s*(?P<end>-?\d+)"
        + degree
        + r"[^,;\n\u3002\uff1b]{0,80}?"
        + step_words
        + r"\s*(?:\u4e3a|\u662f|=|:)?\s*(?P<step>\d+)"
        + degree,
        re.IGNORECASE,
    )
    match = range_re.search(text)
    if match:
        step = int(match.group("step"))
        if step <= 0:
            raise ValueError("novel azimuth step must be positive")
        return {
            "novel_azimuth_start": int(match.group("start")),
            "novel_azimuth_end": int(match.group("end")),
            "novel_azimuth_step": step,
            "novel_azimuths": None,
        }

    list_re = re.compile(
        r"(?:azimuths?|azimuth|\u65b9\u4f4d\u89d2)"
        + r"[^0-9\-\n]{0,12}"
        + r"(?P<angles>-?\d+(?:\.\d+)?(?:\s*(?:,|;|\u3001|\uff0c|\uff1b|\s)\s*-?\d+(?:\.\d+)?)+)",
        re.IGNORECASE,
    )
    list_match = list_re.search(text)
    if list_match and not re.search(sep, list_match.group("angles")):
        values = _parse_float_list(list_match.group("angles"))
        if values:
            return {"novel_azimuths": _format_angle_list(values)}
    return {}


def _apply_prompt_overrides(args: argparse.Namespace) -> None:
    prompt = " ".join(getattr(args, "request", []) or [])
    parsed = _parse_novel_azimuth_request(prompt)
    for key, value in parsed.items():
        setattr(args, key, value)


def _validate_prompt_azimuth_consistency(args: argparse.Namespace) -> None:
    prompt = " ".join(getattr(args, "request", []) or [])
    parsed = _parse_novel_azimuth_request(prompt)
    if not parsed:
        return
    for key, expected in parsed.items():
        actual = getattr(args, key, None)
        if str(actual) != str(expected):
            raise SystemExit(
                f"Parsed request requires {key}={expected}, but final agent args have {key}={actual}. "
                "Refusing to start a mismatched run."
            )


def _count_images(path: Path) -> int:
    if not path.is_dir():
        return 0
    return sum(1 for p in path.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS)


def _count_dataset_images(data_dir: Path) -> int:
    for name in ("input", "images", "images_target_black"):
        count = _count_images(data_dir / name)
        if count > 0:
            return count
    return _count_images(data_dir)


def _image_files(path: Path) -> list[Path]:
    if not path.is_dir():
        return []
    return sorted((p for p in path.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS), key=lambda p: p.name.lower())


def _name_key(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(text or "").lower())


def _dataset_gt_keys(dataset_name: str) -> set[str]:
    key = _name_key(dataset_name)
    keys = {key}
    aliases = {
        "brdm2": "brdm",
        "zsu234": "zsu",
    }
    if re.fullmatch(r"360\d*", key) or re.fullmatch(r"360\d+", key):
        keys.add("t72")
    if key.startswith("360"):
        keys.add("t72")
    if key in aliases:
        keys.add(aliases[key])
    return keys


def _dataset_image_dir(path: Path) -> Path:
    for name in ("input", "images", "images_target_black"):
        candidate = path / name
        if _count_images(candidate) > 0:
            return candidate
    return path


def _gt_class_key(path: Path) -> str:
    stem = path.stem
    if "-" in stem:
        stem = stem.split("-", 1)[0]
    return _name_key(stem)


def _resolve_dataset_gt_dir(root: Path, dataset_name: str, scratch_parent: Path, label: str) -> Path:
    """Narrow a shared GT root to the current dataset when batch training."""
    if not root.is_dir():
        return root

    dataset_keys = _dataset_gt_keys(dataset_name)
    for child in sorted((p for p in root.iterdir() if p.is_dir()), key=lambda p: p.name.lower()):
        if _name_key(child.name) in dataset_keys and _count_dataset_images(child) > 0:
            return _dataset_image_dir(child)

    direct_images = _image_files(root)
    if not direct_images:
        return root

    selected = [p for p in direct_images if _gt_class_key(p) in dataset_keys]
    if not selected:
        direct_classes = {_gt_class_key(p) for p in direct_images if _gt_class_key(p)}
        if len(direct_classes) <= 1:
            return root
        print(
            f"[agent] warning: shared {label} has {len(direct_classes)} classes but no "
            f"files matched dataset '{dataset_name}'; using {root} unchanged."
        )
        return root

    if len(selected) == len(direct_images):
        return root

    out_dir = scratch_parent / f"{label}_{dataset_name}"
    out_dir.mkdir(parents=True, exist_ok=True)
    for src in selected:
        shutil.copy2(src, out_dir / src.name)
    print(f"[agent] scoped {label} for {dataset_name}: {len(selected)}/{len(direct_images)} images -> {out_dir}")
    return out_dir


def _image_dir_for_arg(data_dir: Path, images_arg: str) -> Path:
    image_dir = Path(images_arg).expanduser()
    if image_dir.is_absolute():
        return image_dir
    return data_dir / image_dir


def _validate_data_dir(data_dir: Path) -> None:
    if not data_dir.is_dir():
        raise FileNotFoundError(f"data_dir does not exist: {data_dir}")
    image_count = (
        _count_images(data_dir / "input")
        + _count_images(data_dir / "images")
        + _count_images(data_dir / "images_target_black")
        + _count_images(data_dir)
    )
    if image_count <= 0:
        raise FileNotFoundError(
            "No input images found. Expected images under "
            f"{data_dir / 'input'}, {data_dir / 'images'}, "
            f"{data_dir / 'images_target_black'}, or directly under {data_dir}."
        )


def _colmap_image_names(data_dir: Path) -> set[str]:
    images_txt = data_dir / "sparse" / "0" / "images.txt"
    if not images_txt.is_file():
        return set()
    names: set[str] = set()
    with images_txt.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 10 and Path(parts[9]).suffix.lower() in IMAGE_EXTS:
                names.add(parts[9])
    return names


def _missing_colmap_images(data_dir: Path, image_dir: Path) -> list[str]:
    names = _colmap_image_names(data_dir)
    if not names:
        return []
    return sorted(name for name in names if not (image_dir / name).is_file())


def _source_images_dir(data_dir: Path) -> Path:
    for name in ("images", "input"):
        candidate = data_dir / name
        if _count_images(candidate) > 0:
            return candidate
    return data_dir


def _ensure_target_black_images(data_dir: Path) -> Path | None:
    """Create images_target_black from convert semantic masks for GS training."""
    source_dir = _source_images_dir(data_dir)
    out_dir = data_dir / "images_target_black"
    source_count = _count_images(source_dir)
    if source_count <= 0:
        return None
    if _count_images(out_dir) >= source_count and not _missing_colmap_images(data_dir, out_dir):
        return out_dir

    try:
        import numpy as np
        from PIL import Image
        from sar.semantic_mask_config import load_convert_scattering_masks
    except Exception as exc:
        print(f"[agent] cannot prepare images_target_black: {exc}")
        return None

    loaded = load_convert_scattering_masks(str(data_dir), str(source_dir), run_id="latest")
    if loaded is None:
        print(f"[agent] no complete convert masks found; images_target_black not generated for {data_dir.name}.")
        return None
    masks, mask_dir = loaded
    out_dir.mkdir(parents=True, exist_ok=True)
    written = 0
    for src in sorted(p for p in source_dir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS):
        mask = masks.get(src.name)
        if mask is None:
            continue
        arr = np.asarray(Image.open(src).convert("RGB"), dtype=np.uint8)
        target = ((np.asarray(mask) == 1) | (np.asarray(mask) == 2)).astype(np.uint8)
        if target.shape != arr.shape[:2]:
            target_img = Image.fromarray((target * 255).astype(np.uint8), mode="L")
            target_img = target_img.resize((arr.shape[1], arr.shape[0]), Image.Resampling.NEAREST)
            target = (np.asarray(target_img) > 0).astype(np.uint8)
        masked = arr * target[:, :, None]
        Image.fromarray(masked).save(out_dir / src.name)
        written += 1
    print(f"[agent] images_target_black: wrote {written}/{source_count} images from masks {mask_dir}")
    return out_dir if written > 0 else None


def _resolve_gs_images_arg(args: argparse.Namespace, data_dir: Path) -> str:
    requested = str(args.images)
    requested_dir = _image_dir_for_arg(data_dir, requested)
    requested_count = _count_images(requested_dir)
    requested_missing = _missing_colmap_images(data_dir, requested_dir) if requested_count > 0 else []
    if requested_count > 0 and not requested_missing:
        return requested

    fallback_names = ["images", "input"]
    for name in fallback_names:
        if name == requested:
            continue
        fallback_dir = data_dir / name
        if _count_images(fallback_dir) > 0 and not _missing_colmap_images(data_dir, fallback_dir):
            reason = "has no images" if requested_count <= 0 else f"is missing {len(requested_missing)} COLMAP images"
            print(
                "[agent] GS image directory "
                f"'{requested_dir}' {reason}; using '{name}' instead."
            )
            return name

    detail = "has no images" if requested_count <= 0 else f"is missing COLMAP images: {', '.join(requested_missing[:5])}"
    raise FileNotFoundError(
        "GS image directory "
        f"{detail}: {requested_dir}. Available fallbacks checked: "
        + ", ".join(str(data_dir / name) for name in fallback_names)
    )


def _stage_enabled(stage: str, stages: list[str], args: argparse.Namespace) -> bool:
    if stage not in stages:
        return False
    return not bool(getattr(args, f"skip_{stage}", False))


def _selected_stages(args: argparse.Namespace) -> list[str]:
    stages = ["sfm", "gs", "render", "refiner"]
    start = stages.index(args.start_at)
    end = stages.index(args.stop_after)
    if start > end:
        raise ValueError("--start_at must be before or equal to --stop_after")
    return stages[start : end + 1]


def _apply_raysar_target_only_defaults(args: argparse.Namespace) -> None:
    if not bool(getattr(args, "raysar_target_only", False)):
        return
    if args.start_at == "sfm" and args.stop_after == "sfm":
        args.raysar_target_only = False
        return

    # RaySAR renders have no MSTAR-like clutter/shadow background. Use the
    # analytic SAR camera loader and image brightness masks instead of SfM and
    # shadow/refiner assumptions.
    if args.start_at == "sfm":
        args.start_at = "gs"
    if args.stop_after in {"sfm", "refiner"}:
        args.stop_after = "render"
    stage_order = ["sfm", "gs", "render", "refiner"]
    if stage_order.index(args.start_at) > stage_order.index(args.stop_after):
        args.start_at = "gs"
        args.stop_after = "render"
    if str(getattr(args, "images", "") or "").strip() in {"", "images_target_black"}:
        args.images = "input"

    args.skip_sfm = True
    args.skip_refiner = True
    args.matched_real_background = False
    args.refiner_azimuth_shadow = False
    args.export_classification_labels = False
    args.background_filtered_eval = False


def _progress_line(stage: str, done: int, total: int, start: float, label: str = "") -> str:
    width = 30
    elapsed = time.perf_counter() - start
    if total > 0:
        done = min(max(done, 0), total)
        filled = int(width * done / max(total, 1))
        bar = "#" * filled + "-" * (width - filled)
        pct = 100.0 * done / max(total, 1)
        return f"\r[{stage}] [{bar}] {done}/{total} {pct:5.1f}% elapsed {elapsed:6.1f}s {label[:46]}"
    pos = int(elapsed * 5) % width
    bar = "-" * pos + "#" + "-" * (width - pos - 1)
    return f"\r[{stage}] [{bar}] elapsed {elapsed:6.1f}s {label[:46]}"


def _run_quiet_step(
    stage: str,
    cmd: list[str],
    cwd: Path,
    *,
    total_items: int = 0,
    log_path: Path | None = None,
    dry_run: bool = False,
) -> None:
    if dry_run:
        return
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PYTHONUTF8", "1")
    env.setdefault("PYTHONUNBUFFERED", "1")
    if log_path is not None:
        log_path.parent.mkdir(parents=True, exist_ok=True)

    start = time.perf_counter()
    done = 0
    seen_images: set[str] = set()
    last_label = ""
    print(_progress_line(stage, done, total_items, start, "starting"), end="", flush=True)
    log_file = log_path.open("w", encoding="utf-8", errors="replace") if log_path is not None else None
    try:
        if log_file is not None:
            log_file.write(f"[command] {_format_cmd(cmd)}\n")
            log_file.write(f"[cwd] {cwd}\n\n")
            log_file.flush()
        if total_items <= 0:
            proc = subprocess.Popen(
                cmd,
                cwd=str(cwd),
                stdout=log_file if log_file is not None else subprocess.DEVNULL,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=env,
            )
            last_tick = 0.0
            while proc.poll() is None:
                now = time.perf_counter()
                if now - last_tick >= 2.0:
                    print(_progress_line(stage, 0, 0, start, "running"), end="", flush=True)
                    last_tick = now
                time.sleep(0.2)
            returncode = proc.returncode
            if returncode != 0:
                if log_file is not None:
                    log_file.flush()
                _safe_print()
                if log_path is not None:
                    _safe_print(f"[{stage}] failed. Full log: {log_path}")
                    summary = _log_error_summary(log_path)
                    if summary:
                        _safe_print(f"[{stage}] error summary:")
                        for item in summary:
                            _safe_print(f"  {item}")
                    else:
                        _safe_print(f"[{stage}] no concise error line found; see the full log.")
                raise subprocess.CalledProcessError(returncode, cmd)
            print(_progress_line(stage, 0, 0, start, "done"), end="", flush=True)
            print()
            if log_path is not None:
                print(f"[{stage}] quiet log: {log_path}")
            return
        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            env=env,
        )
        assert proc.stdout is not None
        last_tick = 0.0
        for line in proc.stdout:
            if log_file is not None:
                log_file.write(line)
            image_match = re.search("处理图像\\s+([^:\\s]+)", line)
            if image_match is None:
                image_match = re.search("图像\\s+([^\\s]+).*?(?:特征点|features|Feature)", line)
            if image_match:
                last_label = image_match.group(1).strip(":：")
                if total_items > 0 and last_label not in seen_images:
                    seen_images.add(last_label)
                    done = min(len(seen_images), total_items)
            elif "开始特征匹配" in line:
                last_label = "matching features"
            elif "使用自定义sfm.py" in line or "SAR SfM" in line:
                last_label = "reconstructing geometry"
            elif "所有流程完成" in line or "SAR重建完成" in line:
                done = total_items if total_items > 0 else done
                last_label = "complete"

            now = time.perf_counter()
            if now - last_tick >= 0.15:
                print(_progress_line(stage, done, total_items, start, last_label), end="", flush=True)
                last_tick = now

        returncode = proc.wait()
        if returncode != 0:
            if log_file is not None:
                log_file.flush()
            _safe_print()
            if log_path is not None:
                _safe_print(f"[{stage}] failed. Full log: {log_path}")
                summary = _log_error_summary(log_path)
                if summary:
                    _safe_print(f"[{stage}] error summary:")
                    for item in summary:
                        _safe_print(f"  {item}")
                else:
                    _safe_print(f"[{stage}] no concise error line found; see the full log.")
            raise subprocess.CalledProcessError(returncode, cmd)
        if total_items > 0:
            done = total_items
        print(_progress_line(stage, done, total_items, start, "done"), end="", flush=True)
        print()
        if log_path is not None:
            print(f"[{stage}] quiet log: {log_path}")
    finally:
        if log_file is not None:
            log_file.close()


def _run_step(
    stage: str,
    cmd: list[str],
    cwd: Path,
    records: list[StepRecord],
    dry_run: bool,
    *,
    quiet: bool = False,
    total_items: int = 0,
    log_path: Path | None = None,
) -> None:
    record = StepRecord(
        stage=stage,
        command=_format_cmd(cmd),
        cwd=str(cwd),
        started_at=datetime.now().isoformat(timespec="seconds"),
        status="dry_run" if dry_run else "running",
    )
    records.append(record)
    print("\n" + "=" * 96)
    if quiet and not dry_run:
        log_label = str(log_path) if log_path is not None else "(no log path)"
        print(f"[{stage}] running quietly; full output: {log_label}")
    else:
        print(f"[{stage}] {record.command}")
    print("=" * 96)
    start = time.perf_counter()
    try:
        if not dry_run:
            if quiet:
                _run_quiet_step(stage, cmd, cwd, total_items=total_items, log_path=log_path)
            else:
                env = os.environ.copy()
                env.setdefault("PYTHONIOENCODING", "utf-8")
                env.setdefault("PYTHONUTF8", "1")
                subprocess.run(cmd, cwd=str(cwd), check=True, env=env)
    except Exception:
        record.status = "failed"
        raise
    else:
        record.status = "dry_run" if dry_run else "ok"
    finally:
        record.duration_sec = round(time.perf_counter() - start, 3)
        record.ended_at = datetime.now().isoformat(timespec="seconds")
        print(f"[agent timing] {stage}: {record.duration_sec:.3f}s")


def _mirror_sfm_outputs(data_dir: Path, sfm_dir: Path, dry_run: bool, *, full: bool = False) -> None:
    mode = "full" if full else "light"
    print(f"[agent] SfM outputs mirror ({mode}): {sfm_dir}", flush=True)
    if dry_run:
        return
    sfm_dir.mkdir(parents=True, exist_ok=True)
    copied: list[str] = []
    mirror_dirs = SFM_FULL_MIRROR_DIRS if full else SFM_LIGHT_MIRROR_DIRS
    for name in mirror_dirs:
        src = data_dir / name
        if src.is_dir():
            shutil.copytree(src, sfm_dir / name, dirs_exist_ok=True)
            copied.append(name + "/")
    skipped = sorted(set(SFM_FULL_MIRROR_DIRS) - set(mirror_dirs))
    for name in SFM_MIRROR_FILES:
        src = data_dir / name
        if src.is_file():
            shutil.copy2(src, sfm_dir / name)
            copied.append(name)
    if copied:
        print("[agent] mirrored SfM artifacts: " + ", ".join(copied))
    else:
        print("[agent] no SfM artifacts found to mirror yet.")
    if skipped:
        print("[agent] skipped bulky SfM artifacts: " + ", ".join(name + "/" for name in skipped))


def _sfm_archive_artifacts(*, full: bool = True) -> tuple[tuple[str, ...], tuple[str, ...]]:
    dirs = SFM_FULL_MIRROR_DIRS if full else SFM_LIGHT_MIRROR_DIRS
    return dirs, SFM_MIRROR_FILES


def _copy_sfm_artifacts(src_root: Path, dst_root: Path, *, full: bool = True) -> list[str]:
    copied: list[str] = []
    dirs, files = _sfm_archive_artifacts(full=full)
    for name in dirs:
        src = src_root / name
        if src.is_dir():
            shutil.copytree(src, dst_root / name, dirs_exist_ok=True)
            copied.append(name + "/")
    for name in files:
        src = src_root / name
        if src.is_file():
            dst_root.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst_root / name)
            copied.append(name)
    return copied


def _archive_sfm_outputs(data_dir: Path, dry_run: bool, *, run_id: str, full: bool = True) -> Path | None:
    archive_root = data_dir / "sfm"
    archive_dir = archive_root / run_id
    print(f"[agent] SfM outputs archive: {archive_dir}", flush=True)
    if dry_run:
        return archive_dir

    archive_dir.mkdir(parents=True, exist_ok=True)
    copied = _copy_sfm_artifacts(data_dir, archive_dir, full=full)
    latest = {
        "timestamp": run_id,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "archive_dir": str(archive_dir),
        "artifacts": copied,
        "full": bool(full),
    }
    with (archive_root / "latest.json").open("w", encoding="utf-8") as f:
        json.dump(latest, f, indent=2, ensure_ascii=False)

    if copied:
        print("[agent] archived SfM artifacts: " + ", ".join(copied))
        print(f"[agent] latest SfM pointer: {archive_root / 'latest.json'}")
    else:
        print("[agent] no SfM artifacts found to archive yet.")
    return archive_dir


def _restore_latest_sfm_outputs(data_dir: Path, dry_run: bool) -> Path | None:
    latest_path = data_dir / "sfm" / "latest.json"
    if not latest_path.is_file():
        has_root_artifacts = any((data_dir / name).exists() for name in SFM_LIGHT_MIRROR_DIRS + SFM_MIRROR_FILES)
        if has_root_artifacts:
            bootstrap_id = "bootstrap_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            print("[agent] no latest SfM pointer; archiving current data-root SfM artifacts first.")
            return _archive_sfm_outputs(data_dir, dry_run, run_id=bootstrap_id, full=True)
        return None
    try:
        with latest_path.open("r", encoding="utf-8") as f:
            latest = json.load(f)
    except Exception as exc:
        print(f"[agent] warning: cannot read latest SfM pointer {latest_path}: {exc}")
        return None

    archive_dir = Path(str(latest.get("archive_dir") or "")).expanduser()
    if not archive_dir.is_absolute():
        archive_dir = latest_path.parent / archive_dir
    if not archive_dir.is_dir():
        print(f"[agent] warning: latest SfM archive does not exist: {archive_dir}")
        return None

    print(f"[agent] using latest SfM archive: {archive_dir}", flush=True)
    if dry_run:
        return archive_dir

    copied: list[str] = []
    dirs, files = _sfm_archive_artifacts(full=True)
    for name in dirs:
        src = archive_dir / name
        dst = data_dir / name
        if src.is_dir():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
            copied.append(name + "/")
    for name in files:
        src = archive_dir / name
        if src.is_file():
            shutil.copy2(src, data_dir / name)
            copied.append(name)
    if copied:
        print("[agent] restored latest SfM artifacts for Gaussian: " + ", ".join(copied))
    else:
        print("[agent] latest SfM archive has no restorable artifacts.")
    return archive_dir


def _build_sfm_cmd(args: argparse.Namespace, data_dir: Path) -> list[str]:
    cmd = [
        args.python,
        str(REPO_ROOT / "convert.py"),
        "-s",
        str(data_dir),
        "--geometry_prior_gs_model",
        "--sfm_gs_optical_depression_horizon_deg",
        str(args.sfm_gs_optical_depression_horizon_deg),
        "--target_percentile",
        str(args.target_percentile),
        "--target_dimension_filter_percentile",
        str(args.target_dimension_filter_percentile),
        "--target_mask_dilate_px",
        str(args.target_mask_dilate_px),
        "--target_mask_min_component_area_px",
        str(args.target_mask_min_component_area_px),
        "--shadow_percentile",
        str(args.shadow_percentile),
        "--shadow_min_area_fraction",
        str(args.shadow_min_area_fraction),
        "--shadow_min_target_area_fraction",
        str(args.shadow_min_target_area_fraction),
        "--target_edge_outer_px",
        str(args.target_edge_outer_px),
        "--shadow_geometry_azimuth_mode",
        str(args.shadow_geometry_azimuth_mode),
        "--target_dimension_summary_azimuth_mode",
        str(args.target_dimension_summary_azimuth_mode),
        "--post_sfm_scheme_a_planform_scale",
        str(args.post_sfm_scheme_a_planform_scale),
    ]
    if bool(args.convert_use_standalone_shadow_target_dimensions):
        cmd.append("--convert_use_standalone_shadow_target_dimensions")
    else:
        cmd.append("--no_convert_use_standalone_shadow_target_dimensions")
    if bool(args.convert_auto_verify_optical) and not bool(getattr(args, "fast_io", False)):
        cmd.append("--convert_auto_verify_optical")
    else:
        cmd.append("--no_convert_auto_verify_optical")
    return cmd


def _build_gs_cmd(args: argparse.Namespace, data_dir: Path, model_dir: Path) -> list[str]:
    raysar_target_only = bool(getattr(args, "raysar_target_only", False))
    fallback_target_threshold = 0.0 if raysar_target_only else 0.04
    geometry_anchor_weight = 0.0 if raysar_target_only else 0.08
    geometry_extent_weight = 0.0 if raysar_target_only else 0.05
    cmd = [
        args.python,
        str(REPO_ROOT / "scripts" / "pipeline" / "train_locked_target_optical.py"),
        "-s",
        str(data_dir),
        "-m",
        str(model_dir),
        "--images",
        args.images,
        "--iterations",
        str(args.gs_iterations),
        "--position_lr_init",
        "0.00012",
        "--position_lr_final",
        "0.0000016",
        "--densify_from_iter",
        "100",
        "--densify_until_iter",
        "800",
        "--densification_interval",
        "100",
        "--densify_grad_threshold",
        "0.0003",
        "--max_gaussian_scale",
        "0.01",
        "--scale_cap_weight",
        "0.1",
        "--geometry_anchor_weight",
        str(geometry_anchor_weight),
        "--geometry_extent_weight",
        str(geometry_extent_weight),
        "--silhouette_weight",
        "0.15",
        "--silhouette_outside_scale",
        "1.5",
        "--outside_black_weight",
        "0.05",
        "--fallback_target_threshold",
        str(fallback_target_threshold),
        "--post_prune_min_inside_ratio",
        "0.10",
        "--post_prune_mask_dilate",
        "4",
        "--novel_azimuth_start",
        str(args.novel_azimuth_start),
        "--novel_azimuth_end",
        str(args.novel_azimuth_end),
        "--novel_azimuth_step",
        str(args.novel_azimuth_step),
        "--novel_depression_angle",
        str(args.novel_depression_angle),
        "--novel_pose_mode",
        args.novel_pose_mode,
        "--no-novel_sar_like",
        "--quiet",
    ]
    if raysar_target_only:
        cmd += [
            "--mstar_nosfm",
            "--mstar_nosfm_init_points",
            str(args.raysar_nosfm_init_points),
            "--no_convert_target_masks",
        ]
    if getattr(args, "novel_azimuths", None):
        cmd += ["--novel_azimuths", str(args.novel_azimuths)]
    return cmd


def _missing_novel_azimuths(args: argparse.Namespace, model_dir: Path) -> list[float]:
    values = _novel_azimuth_values(args)
    if not bool(getattr(args, "skip_existing_novel_views", True)):
        return values
    roots = [
        model_dir / "novel_target_only" / "renders",
        model_dir / "novel_target_only" / "target_renders",
    ]
    missing: list[float] = []
    for value in values:
        rounded = int(round(value))
        if abs(float(value) - float(rounded)) > 1e-6:
            raise ValueError(f"novel azimuth filenames require integer degrees, got {value:g}")
        name = f"azimuth_{rounded:03d}.png"
        if not all((root / name).is_file() for root in roots):
            missing.append(value)
    return missing


def _build_render_cmd(args: argparse.Namespace, model_dir: Path) -> list[str] | None:
    azimuths = _missing_novel_azimuths(args, model_dir)
    if not azimuths:
        print(f"[render] all requested novel views already exist under {model_dir / 'novel_target_only'}")
        return None
    cmd = [
        args.python,
        str(REPO_ROOT / "scripts" / "rendering" / "render_novel_optical_sar_like.py"),
        "-m",
        str(model_dir),
        "--iteration",
        "-1",
        "--output_dir",
        str(model_dir / "novel_target_only"),
        "--azimuths",
        _format_angle_list(azimuths),
        "--depression_angle",
        str(args.novel_depression_angle),
        "--novel_pose_mode",
        args.novel_pose_mode,
        "--target_only",
        "--quiet",
    ]
    return cmd


def _cmd_value(cmd: list[str], flag: str) -> str | None:
    try:
        index = cmd.index(flag)
    except ValueError:
        return None
    if index + 1 >= len(cmd):
        return None
    return str(cmd[index + 1])


def _validate_gs_cmd_matches_plan(args: argparse.Namespace, cmd: list[str]) -> None:
    checks = {
        "--novel_azimuth_start": str(args.novel_azimuth_start),
        "--novel_azimuth_end": str(args.novel_azimuth_end),
        "--novel_azimuth_step": str(args.novel_azimuth_step),
    }
    if getattr(args, "novel_azimuths", None):
        checks["--novel_azimuths"] = str(args.novel_azimuths)
    for flag, expected in checks.items():
        actual = _cmd_value(cmd, flag)
        if actual != expected:
            raise SystemExit(
                f"Agent plan mismatch before GS: expected {flag} {expected}, "
                f"but command has {actual!r}. Refusing to launch."
            )


def _verify_novel_view_outputs(model_dir: Path, args: argparse.Namespace, dataset_name: str) -> None:
    expected = _expected_novel_render_names(args)
    roots = [
        model_dir / "novel_target_only" / "renders",
        model_dir / "novel_target_only" / "target_renders",
    ]
    for root in roots:
        if not root.is_dir():
            raise RuntimeError(f"[{dataset_name}] missing novel-view output directory: {root}")
        actual = {p.name for p in root.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS}
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        if missing or extra:
            summary = _novel_azimuth_summary(args)
            raise RuntimeError(
                f"[{dataset_name}] novel-view verification failed for {root}: "
                f"expected {summary['count']} files ({summary['start']}..{summary['end']} "
                f"step={summary['step']}), got {len(actual)}. "
                f"missing={missing[:8]} extra={extra[:8]}"
            )
    print(f"[agent verify] {dataset_name}: novel views OK ({len(expected)} renders + target_renders)")


def _build_refiner_cmd(
    args: argparse.Namespace,
    data_dir: Path,
    model_dir: Path,
    refiner_work_dir: Path,
    gt_dir: Path,
    eval_gt_dir: Path,
    classification_label_output_dir: Path | None = None,
    classification_root: Path | None = None,
) -> list[str]:
    cmd = [
        args.python,
        str(REPO_ROOT / "scripts" / "pipeline" / "sar_novel_view_refiner_pipeline.py"),
        "--python",
        args.python,
        "--stage",
        "full_train",
        "-m",
        str(model_dir),
        "--work_dir",
        str(refiner_work_dir),
        "--train_target_dir",
        str(model_dir / "train_renders"),
        "--train_gt_dir",
        str(gt_dir),
        "--azimuth_shadow_train_gt_dir",
        str(gt_dir),
        "--gt_dir",
        str(eval_gt_dir),
        "--refiner_mode",
        "target_layover_clean",
        "--shadow_carrier_background",
        "none",
        "--no-azimuth_shadow_train_on_refined",
        "--azimuth_shadow_refine_mode",
        "image",
        "--azimuth_shadow_candidate_mode",
        "fixed_direction_prior",
        "--azimuth_shadow_gt_use_global_direction",
        "--azimuth_shadow_apply_mask_source",
        "target",
        "--azimuth_shadow_target_mask_mode",
        "semantic_binary",
        "--azimuth_shadow_target_mask_filter_percentile",
        "95",
        "--azimuth_shadow_shape_prior_mode",
        "semantic",
        "--azimuth_shadow_shape_prior_weight",
        "1.0",
        "--azimuth_shadow_shape_prior_threshold",
        "0.05",
        "--azimuth_shadow_shape_prior_mix_mode",
        "weighted_mean",
        "--azimuth_shadow_semantic_mask_dir",
        str(data_dir),
        "--azimuth_shadow_supervision_source",
        "semantic_gt",
        "--azimuth_shadow_semantic_target_labels",
        "1,2",
        "--azimuth_shadow_semantic_shadow_label",
        "3",
        "--azimuth_shadow_recognition_source",
        "shape_prior",
        "--azimuth_shadow_recognition_threshold",
        "0.20",
        "--azimuth_shadow_recognition_gate_threshold",
        "0.20",
        "--azimuth_shadow_apply_recognition_mask",
        "--azimuth_shadow_semantic_dilate",
        "1",
        "--azimuth_shadow_semantic_blur",
        "1",
        "--azimuth_shadow_train_min_candidate_pixels",
        "1",
        "--azimuth_shadow_gt_component_filter",
        "--no-azimuth_shadow_pred_component_filter",
        "--azimuth_shadow_learned_intensity_prior",
        "--azimuth_shadow_intensity_strength",
        str(args.azimuth_shadow_intensity_strength),
        "--azimuth_shadow_intensity_min_attenuation",
        str(args.azimuth_shadow_intensity_min_attenuation),
        "--azimuth_shadow_intensity_max_attenuation",
        str(args.azimuth_shadow_intensity_max_attenuation),
        "--azimuth_shadow_intensity_gamma",
        str(args.azimuth_shadow_intensity_gamma),
        "--azimuth_shadow_intensity_context_radius",
        str(args.azimuth_shadow_intensity_context_radius),
        "--azimuth_shadow_intensity_block_radius",
        str(args.azimuth_shadow_intensity_block_radius),
        "--azimuth_shadow_intensity_exclude_dilate",
        str(args.azimuth_shadow_intensity_exclude_dilate),
        "--azimuth_shadow_candidate_supervision_mix",
        "1.0",
        "--azimuth_shadow_candidate_length",
        "40",
        "--azimuth_shadow_candidate_decay",
        "32",
        "--azimuth_shadow_candidate_lateral_blur",
        "7",
        "--azimuth_shadow_geometry_extent_forward_scale",
        str(args.azimuth_shadow_geometry_extent_forward_scale),
        "--azimuth_shadow_geometry_extent_lateral_scale",
        str(args.azimuth_shadow_geometry_extent_lateral_scale),
        "--azimuth_shadow_geometry_extent_margin_px",
        str(args.azimuth_shadow_geometry_extent_margin_px),
        "--azimuth_shadow_geometry_extent_min_forward_px",
        str(args.azimuth_shadow_geometry_extent_min_forward_px),
        "--azimuth_match_tolerance",
        str(args.azimuth_match_tolerance),
        "--sar_tolerant_radius",
        "1",
        "--view_split_train_angle_step",
        "0",
        "--no-save_maps",
        "--no-target_shadow_eval",
        "--no-visual_diagnosis",
        "--no-refiner_delta_eval",
        "--record_results",
        "--device",
        args.device,
    ]
    if bool(getattr(args, "fast_io", False)):
        cmd += ["--no-visual_diagnosis"]
    if bool(args.export_classification_labels):
        cmd += ["--export_classification_labels"]
        if classification_label_output_dir is not None:
            cmd += ["--classification_label_output_dir", str(classification_label_output_dir)]
        if classification_root is not None:
            cmd += ["--classification_root", str(classification_root)]
        cmd += ["--classification_source", str(args.classification_source)]
    else:
        cmd += ["--no-export_classification_labels"]
    if getattr(args, "background_filtered_eval", False) and not bool(getattr(args, "fast_io", False)):
        cmd += ["--background_filtered_eval"]
    else:
        cmd += ["--no-background_filtered_eval"]
    if getattr(args, "background_filtered_eval_gt_dir", None):
        cmd += ["--background_filtered_eval_gt_dir", str(_resolve_path(args.background_filtered_eval_gt_dir))]
    if getattr(args, "background_filtered_eval_output_dir", None):
        cmd += ["--background_filtered_eval_output_dir", str(_resolve_path(args.background_filtered_eval_output_dir))]
    cmd += [
        "--background_filtered_eval_percentile",
        str(args.background_filtered_eval_percentile),
    ]
    if bool(args.refiner_azimuth_shadow):
        cmd += ["--enable_azimuth_shadow_refiner"]
    else:
        cmd += ["--no-enable_azimuth_shadow_refiner"]
    if bool(args.azimuth_shadow_geometry_extent_gate):
        cmd += ["--azimuth_shadow_geometry_extent_gate"]
    else:
        cmd += ["--no-azimuth_shadow_geometry_extent_gate"]
    if bool(args.azimuth_shadow_geometry_extent_apply_to_recognition):
        cmd += ["--azimuth_shadow_geometry_extent_apply_to_recognition"]
    else:
        cmd += ["--no-azimuth_shadow_geometry_extent_apply_to_recognition"]
    if bool(args.azimuth_shadow_geometry_extent_require_dataset_direction):
        cmd += ["--azimuth_shadow_geometry_extent_require_dataset_direction"]
    else:
        cmd += ["--no-azimuth_shadow_geometry_extent_require_dataset_direction"]
    if bool(getattr(args, "matched_real_background", True)):
        background_reference_dir = data_dir / "input"
        if not background_reference_dir.is_dir():
            background_reference_dir = data_dir / "images"
        cmd += [
            "--background_after_shadow",
            "--background_after_shadow_data_dir",
            str(data_dir),
            "--background_after_shadow_reference_dir",
            str(background_reference_dir),
            "--background_after_shadow_strength",
            str(args.matched_background_strength),
            "--background_after_shadow_shadow_alpha_source",
            str(args.matched_background_shadow_alpha_source),
            "--no-background_after_shadow_hard_shadow_copy"
            if not bool(args.matched_background_hard_shadow_copy)
            else "--background_after_shadow_hard_shadow_copy",
            "--background_after_shadow_nearest_refs",
            str(args.matched_background_nearest_refs),
            "--background_after_shadow_stat_match",
            str(args.matched_background_stat_match),
            "--background_after_shadow_shadow_from_render_percentile",
            str(args.matched_background_shadow_from_render_percentile),
            "--background_after_shadow_target_mask_dilate",
            str(args.matched_background_target_mask_dilate),
            "--background_after_shadow_blend_dilate",
            str(args.matched_background_blend_dilate),
            "--background_after_shadow_target_mask_blur",
            str(args.matched_background_target_mask_blur),
            "--background_after_shadow_target_gap_dark_threshold",
            str(args.matched_background_target_gap_dark_threshold),
            "--background_after_shadow_target_gap_edge_px",
            str(args.matched_background_target_gap_edge_px),
            "--background_after_shadow_target_gap_shadow_protect_threshold",
            str(args.matched_background_target_gap_shadow_protect_threshold),
            "--background_after_shadow_hard_target_copy"
            if bool(args.matched_background_hard_target_copy)
            else "--no-background_after_shadow_hard_target_copy",
            "--background_after_shadow_min_background_fraction",
            str(args.matched_background_min_background_fraction),
            "--background_after_shadow_reference_exclude_dilate",
            str(args.matched_background_reference_exclude_dilate),
            "--background_after_shadow_reference_clean_blend_refs",
            str(args.matched_background_reference_clean_blend_refs),
            "--background_after_shadow_reference_clean_blend_mix",
            str(args.matched_background_reference_clean_blend_mix),
            "--background_after_shadow_reference_clean_angle_sigma",
            str(args.matched_background_reference_clean_angle_sigma),
            "--background_after_shadow_reference_clean_patch_mix",
            str(args.matched_background_reference_clean_patch_mix),
            "--empirical_background_mode",
            "patch",
            "--empirical_background_patch_size",
            str(args.matched_background_patch_size),
            "--empirical_background_patch_overlap",
            str(args.matched_background_patch_overlap),
            "--empirical_background_patch_smooth",
            str(args.matched_background_patch_smooth),
            "--empirical_background_patch_smooth_mix",
            str(args.matched_background_patch_smooth_mix),
            "--empirical_background_clean_reference",
        ]
    else:
        cmd += ["--no-background_after_shadow"]
    cmd += [
        "--no-intermediate_debug_eval",
        "--no-adjacent_similarity_eval",
        "--no-record_debug_artifacts",
    ]
    if args.azimuth_shadow_fixed_direction_deg is not None:
        cmd += ["--azimuth_shadow_fixed_direction_deg", str(args.azimuth_shadow_fixed_direction_deg)]
    return cmd


def _write_record(
    record_dir: Path,
    args: argparse.Namespace,
    *,
    data_dir: Path,
    run_root: Path,
    sfm_dir: Path,
    sfm_archive_dir: Path | None,
    model_dir: Path,
    refiner_work_dir: Path,
    gt_dir: Path,
    eval_gt_dir: Path,
    refiner_enabled: bool,
    records: list[StepRecord],
    status: str,
) -> Path:
    record_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "status": status,
        "repo_root": str(REPO_ROOT),
        "data_dir": str(data_dir),
        "run_root": str(run_root),
        "sfm_dir": str(sfm_dir),
        "sfm_archive_dir": str(sfm_archive_dir) if sfm_archive_dir is not None else None,
        "model_dir": str(model_dir),
        "refiner_enabled": bool(refiner_enabled),
        "refiner_work_dir": str(refiner_work_dir),
        "gt_dir": str(gt_dir),
        "eval_gt_dir": str(eval_gt_dir),
        "args": {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
        "steps": [asdict(r) for r in records],
    }
    out = record_dir / "agent_run.json"
    with out.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    return out


def _format_template_path(value: str | None, dataset_name: str) -> str | None:
    if value is None:
        return None
    return str(value).replace("{name}", dataset_name).replace("{dataset}", dataset_name)


def _has_dataset_placeholder(value: str | None) -> bool:
    return value is not None and ("{name}" in str(value) or "{dataset}" in str(value))


def _validate_batch_paths(args: argparse.Namespace, data_dirs: list[Path]) -> None:
    if len(data_dirs) <= 1:
        return
    for attr, flag in (
        ("model_dir", "--model_dir"),
        ("refiner_work_dir", "--refiner_work_dir"),
    ):
        value = getattr(args, attr, None)
        if value and not _has_dataset_placeholder(value):
            raise SystemExit(
                f"{flag} is shared by all datasets in a batch. "
                f"Use a template such as {flag} \"F:\\\\runs\\\\{{name}}\" "
                "or omit it so the agent uses output/<dataset>/..."
            )


def _run_one_dataset(
    args: argparse.Namespace,
    *,
    data_dir: Path,
    output_root: Path,
    stages: list[str],
) -> dict:
    _validate_data_dir(data_dir)
    dataset_name = data_dir.name
    run_root = output_root / dataset_name
    sfm_dir = run_root / "SFM"
    model_template = _format_template_path(args.model_dir, dataset_name)
    refiner_template = _format_template_path(args.refiner_work_dir, dataset_name)
    gt_template = _format_template_path(args.gt_dir, dataset_name)
    eval_template = _format_template_path(args.eval_gt_dir, dataset_name)
    class_label_template = _format_template_path(args.classification_label_output_dir, dataset_name)

    model_dir = _resolve_path(model_template) if model_template else run_root / "gaussian"
    refiner_work_dir = _resolve_path(refiner_template) if refiner_template else run_root / "refiner"
    gt_dir = _resolve_path(gt_template) if gt_template else data_dir / "input"
    eval_gt_dir = _resolve_path(eval_template) if eval_template else gt_dir
    scratch_dir = run_root / "agent_scoped_inputs"
    refiner_enabled = _stage_enabled("refiner", stages, args)
    if refiner_enabled and gt_dir is not None:
        gt_dir = _resolve_dataset_gt_dir(gt_dir, dataset_name, scratch_dir, "train_gt")
    if refiner_enabled and eval_gt_dir is not None:
        eval_gt_dir = _resolve_dataset_gt_dir(eval_gt_dir, dataset_name, scratch_dir, "eval_gt")
    if class_label_template:
        classification_label_output_dir = _resolve_path(class_label_template)
    elif bool(args.export_classification_labels):
        classification_label_output_dir = output_root
    else:
        classification_label_output_dir = refiner_work_dir
    classification_root = _resolve_path(args.classification_root) if args.classification_root else None
    if refiner_enabled and (gt_dir is None or not gt_dir.is_dir()):
        raise SystemExit(f"Refiner GT directory does not exist for {dataset_name}: {gt_dir}")
    if refiner_enabled and (eval_gt_dir is None or not eval_gt_dir.is_dir()):
        raise SystemExit(f"Refiner eval GT directory does not exist for {dataset_name}: {eval_gt_dir}")

    records: list[StepRecord] = []
    record_dir = run_root / "agent_runs" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    run_id = record_dir.name
    sfm_archive_dir: Path | None = None
    status = "ok"
    original_images_arg = str(args.images)
    try:
        print("\n" + "#" * 96)
        print(f"[agent dataset] {dataset_name}: {data_dir}")
        print("#" * 96)
        if _stage_enabled("sfm", stages, args):
            _run_step(
                "sfm",
                _build_sfm_cmd(args, data_dir),
                REPO_ROOT,
                records,
                args.dry_run,
                quiet=bool(args.sfm_quiet),
                total_items=_count_dataset_images(data_dir),
                log_path=record_dir / "sfm_stdout.txt",
            )
            sfm_archive_dir = _archive_sfm_outputs(
                data_dir,
                args.dry_run,
                run_id=run_id,
                full=True,
            )
            _mirror_sfm_outputs(data_dir, sfm_dir, args.dry_run, full=bool(args.full_sfm_mirror))
            if not args.dry_run:
                _ensure_target_black_images(data_dir)
        if _stage_enabled("gs", stages, args):
            if (
                not _stage_enabled("sfm", stages, args)
                and not bool(getattr(args, "raysar_target_only", False))
            ):
                sfm_archive_dir = _restore_latest_sfm_outputs(data_dir, args.dry_run)
            if not args.dry_run and str(args.images).strip() == "images_target_black":
                _ensure_target_black_images(data_dir)
            args.images = _resolve_gs_images_arg(args, data_dir)
            gs_cmd = _build_gs_cmd(args, data_dir, model_dir)
            _validate_gs_cmd_matches_plan(args, gs_cmd)
            _run_step(
                "gs",
                gs_cmd,
                REPO_ROOT,
                records,
                args.dry_run,
                quiet=True,
                log_path=record_dir / "gs_stdout.txt",
            )
            if not args.dry_run:
                _verify_novel_view_outputs(model_dir, args, dataset_name)
        if _stage_enabled("render", stages, args):
            render_cmd = _build_render_cmd(args, model_dir)
            if render_cmd is not None:
                _run_step(
                    "render",
                    render_cmd,
                    REPO_ROOT,
                    records,
                    args.dry_run,
                    quiet=True,
                    log_path=record_dir / "render_stdout.txt",
                )
                if not args.dry_run:
                    _verify_novel_view_outputs(model_dir, args, dataset_name)
        if refiner_enabled:
            _run_step(
                "refiner",
                _build_refiner_cmd(
                    args,
                    data_dir,
                    model_dir,
                    refiner_work_dir,
                    gt_dir,
                    eval_gt_dir,
                    classification_label_output_dir,
                    classification_root,
                ),
                REPO_ROOT,
                records,
                args.dry_run,
                quiet=True,
                log_path=record_dir / "refiner_stdout.txt",
            )
    except Exception:
        status = "failed"
        raise
    finally:
        args.images = original_images_arg
        record_path = _write_record(
            record_dir,
            args,
            data_dir=data_dir,
            run_root=run_root,
            sfm_dir=sfm_dir,
            sfm_archive_dir=sfm_archive_dir,
            model_dir=model_dir,
            refiner_work_dir=refiner_work_dir,
            gt_dir=gt_dir,
            eval_gt_dir=eval_gt_dir,
            refiner_enabled=refiner_enabled,
            records=records,
            status=status,
        )
        print(f"\n[agent record] {record_path}")

    return {
        "dataset": dataset_name,
        "status": status,
        "data_dir": str(data_dir),
        "run_root": str(run_root),
        "sfm_dir": str(sfm_dir),
        "sfm_archive_dir": str(sfm_archive_dir) if sfm_archive_dir is not None else None,
        "model_dir": str(model_dir),
        "refiner_work_dir": str(refiner_work_dir),
        "classification_label_output_dir": str(classification_label_output_dir),
        "refiner_enabled": bool(refiner_enabled),
        "final_renders": str(
            (refiner_work_dir / "03.apply_postprocess" / "apply" / "renders")
            if refiner_enabled
            else (model_dir / "novel_target_only" / "renders")
        ),
        "record_dir": str(record_dir),
    }


def _write_batch_record(output_root: Path, args: argparse.Namespace, results: list[dict], status: str) -> Path:
    batch_dir = output_root / "agent_batches" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    batch_dir.mkdir(parents=True, exist_ok=True)
    out = batch_dir / "batch_run.json"
    payload = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "status": status,
        "repo_root": str(REPO_ROOT),
        "args": {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
        "datasets": results,
    }
    with out.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    return out


def _dataset_plan(args: argparse.Namespace, data_dir: Path, output_root: Path) -> dict:
    dataset_name = data_dir.name
    run_root = output_root / dataset_name
    model_template = _format_template_path(args.model_dir, dataset_name)
    refiner_template = _format_template_path(args.refiner_work_dir, dataset_name)
    class_label_template = _format_template_path(args.classification_label_output_dir, dataset_name)
    model_dir = _resolve_path(model_template) if model_template else run_root / "gaussian"
    refiner_work_dir = _resolve_path(refiner_template) if refiner_template else run_root / "refiner"
    if class_label_template:
        classification_label_output_dir = _resolve_path(class_label_template)
    elif bool(args.export_classification_labels):
        classification_label_output_dir = output_root
    else:
        classification_label_output_dir = refiner_work_dir
    return {
        "dataset": dataset_name,
        "data_dir": str(data_dir),
        "run_root": str(run_root),
        "sfm_dir": str(run_root / "SFM"),
        "sfm_archive_root": str(data_dir / "sfm"),
        "model_dir": str(model_dir),
        "refiner_work_dir": str(refiner_work_dir),
        "novel_renders": str(model_dir / "novel_target_only" / "renders"),
        "novel_target_renders": str(model_dir / "novel_target_only" / "target_renders"),
        "final_renders": str(
            (model_dir / "novel_target_only" / "renders")
            if bool(getattr(args, "raysar_target_only", False)) or bool(getattr(args, "skip_refiner", False))
            else (refiner_work_dir / "03.apply_postprocess" / "apply" / "renders")
        ),
        "classification_label_output_dir": str(classification_label_output_dir),
        "classification_voc_labels": str(classification_label_output_dir / "label" / str(args.classification_source) / dataset_name),
        "classification_pictures": str(classification_label_output_dir / "picture" / str(args.classification_source) / dataset_name),
    }


def _build_agent_plan(args: argparse.Namespace, data_dirs: list[Path], output_root: Path, stages: list[str]) -> dict:
    az = _novel_azimuth_summary(args)
    return {
        "repo_root": str(REPO_ROOT),
        "data_root": str(_resolve_path(args.data_root) or (REPO_ROOT / "data")),
        "output_root": str(output_root),
        "stages": stages,
        "dry_run": bool(args.dry_run),
        "raysar_target_only": bool(getattr(args, "raysar_target_only", False)),
        "datasets_count": len(data_dirs),
        "novel_azimuth": {
            "mode": az["mode"],
            "start": az["start"],
            "end": az["end"],
            "step": az["step"],
            "count": az["count"],
            "expected_files": sorted(_expected_novel_render_names(args))[:5]
            + (["..."] if az["count"] > 5 else []),
        },
        "classification": {
            "enabled": bool(args.export_classification_labels),
            "source": str(args.classification_source),
            "voc_layout": "label/<source>/<dataset>/*.xml",
            "picture_layout": "picture/<source>/<dataset>/*.png",
            "mask_layout": "mask_label/<source>/<dataset>/*.png",
        },
        "matched_real_background": {
            "enabled": bool(getattr(args, "matched_real_background", False)),
            "strength": float(getattr(args, "matched_background_strength", 0.82)),
            "patch_size": int(getattr(args, "matched_background_patch_size", 24)),
            "patch_overlap": int(getattr(args, "matched_background_patch_overlap", 6)),
            "shadow_alpha_source": str(getattr(args, "matched_background_shadow_alpha_source", "apply_alpha")),
            "hard_shadow_copy": bool(getattr(args, "matched_background_hard_shadow_copy", False)),
            "reference_clean_blend_refs": int(getattr(args, "matched_background_reference_clean_blend_refs", 4)),
            "reference_clean_blend_mix": float(getattr(args, "matched_background_reference_clean_blend_mix", 0.45)),
            "reference_clean_patch_mix": float(getattr(args, "matched_background_reference_clean_patch_mix", 0.20)),
        },
        "datasets": [_dataset_plan(args, data_dir, output_root) for data_dir in data_dirs],
    }


def _print_agent_plan(plan: dict) -> None:
    az = plan["novel_azimuth"]
    print("[agent plan]")
    print(f"  datasets       : {plan['datasets_count']}")
    print(f"  output_root    : {plan['output_root']}")
    if bool(plan.get("raysar_target_only")):
        print("  preset         : RaySAR target-only (no SfM, no refiner)")
    print(
        "  novel azimuths : "
        f"{az['start']}..{az['end']} step={az['step']} count={az['count']}"
    )
    print(
        "  class export   : "
        f"{plan['classification']['voc_layout']}, {plan['classification']['picture_layout']}"
    )
    bg = plan["matched_real_background"]
    print(
        "  real background: "
        f"{'on' if bg['enabled'] else 'off'} "
        f"strength={bg['strength']} patch={bg['patch_size']}"
    )
    print("\n[agent plan json]")
    print(json.dumps(plan, indent=2, ensure_ascii=False))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run SfM -> target 3DGS -> SAR refiner for one or more data folders.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("request", nargs="*", help="Optional natural-language request containing the data folder path.")
    parser.add_argument(
        "--data_dir",
        "-s",
        type=str,
        default=None,
        help="Dataset folder, or a comma/semicolon/newline-separated list. Images are expected in input/.",
    )
    parser.add_argument("--data_dirs", nargs="+", default=[], help="Multiple dataset folders to process sequentially.")
    parser.add_argument("--data_root", type=str, default=str(REPO_ROOT / "data"))
    parser.add_argument("--output_root", type=str, default=str(REPO_ROOT / "output"))
    parser.add_argument("--model_dir", "-m", type=str, default=None, help="May contain {name} or {dataset} in batch mode.")
    parser.add_argument("--refiner_work_dir", type=str, default=None, help="May contain {name} or {dataset} in batch mode.")
    parser.add_argument("--gt_dir", type=str, default=None, help="Training GT directory for the refiner.")
    parser.add_argument("--eval_gt_dir", type=str, default=None, help="Evaluation GT directory for the refiner.")
    parser.add_argument(
        "--export_classification_labels",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Export classification picture/, mask label/, VOC class_label/, and mstar-exp/ files after refiner. "
            "VOC boxes are computed directly from novel_target_only/target_renders."
        ),
    )
    parser.add_argument(
        "--classification_label_output_dir",
        type=str,
        default=None,
        help="Output root for mask-drawn labels. May contain {name} or {dataset} in batch mode.",
    )
    parser.add_argument("--classification_root", type=str, default=None, help="Classification repo root for relative CSV paths.")
    parser.add_argument("--classification_source", type=str, default="extra")
    parser.add_argument("--background_filtered_eval", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--background_filtered_eval_gt_dir", type=str, default=None)
    parser.add_argument("--background_filtered_eval_output_dir", type=str, default=None)
    parser.add_argument("--background_filtered_eval_percentile", type=float, default=90.0)
    parser.add_argument(
        "--fast_io",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Reduce small-file writes during large batch runs by disabling optional filtered/visual eval outputs.",
    )
    parser.add_argument(
        "--full_sfm_mirror",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Copy bulky SfM visual/debug folders such as feature_matches into output/<dataset>/SFM.",
    )
    parser.add_argument(
        "--matched_real_background",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="After azimuth shadow refinement, compose matched real MSTAR-like background patches from GT images.",
    )
    parser.add_argument("--matched_background_strength", type=float, default=1.0)
    parser.add_argument("--matched_background_shadow_alpha_source", choices=["apply_alpha", "opacity", "compose_alpha", "max"], default="compose_alpha")
    parser.add_argument("--matched_background_hard_shadow_copy", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--matched_background_patch_size", type=int, default=24)
    parser.add_argument("--matched_background_patch_overlap", type=int, default=6)
    parser.add_argument("--matched_background_patch_smooth", type=int, default=1)
    parser.add_argument("--matched_background_patch_smooth_mix", type=float, default=0.30)
    parser.add_argument("--matched_background_reference_exclude_dilate", type=int, default=2)
    parser.add_argument("--matched_background_nearest_refs", type=int, default=6)
    parser.add_argument("--matched_background_reference_clean_blend_refs", type=int, default=4)
    parser.add_argument("--matched_background_reference_clean_blend_mix", type=float, default=0.45)
    parser.add_argument("--matched_background_reference_clean_angle_sigma", type=float, default=12.0)
    parser.add_argument("--matched_background_reference_clean_patch_mix", type=float, default=0.20)
    parser.add_argument("--matched_background_min_background_fraction", type=float, default=0.96)
    parser.add_argument("--matched_background_stat_match", choices=["none", "mean_std", "quantile"], default="mean_std")
    parser.add_argument("--matched_background_shadow_from_render_percentile", type=float, default=20.0)
    parser.add_argument("--matched_background_target_mask_dilate", type=int, default=1)
    parser.add_argument("--matched_background_blend_dilate", type=int, default=0)
    parser.add_argument("--matched_background_target_mask_blur", type=int, default=1)
    parser.add_argument("--matched_background_target_gap_dark_threshold", type=float, default=0.012)
    parser.add_argument("--matched_background_target_gap_edge_px", type=int, default=2)
    parser.add_argument("--matched_background_target_gap_shadow_protect_threshold", type=float, default=0.02)
    parser.add_argument("--matched_background_hard_target_copy", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument(
        "--raysar_target_only",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "RaySAR comparison preset: skip SfM/refiner, train with analytic SAR poses "
            "and use non-black image intensity as the target mask."
        ),
    )
    parser.add_argument(
        "--raysar_nosfm_init_points",
        type=int,
        default=100_000,
        help="Initial random point count passed to --mstar_nosfm in RaySAR target-only mode.",
    )
    parser.add_argument("--python", type=str, default=sys.executable)
    parser.add_argument("--images", type=str, default="images_target_black")
    parser.add_argument(
        "--sfm_quiet",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Hide verbose convert/SfM output and show a compact progress bar. Full logs are shown by default.",
    )
    parser.add_argument("--sfm_gs_optical_depression_horizon_deg", type=float, default=75.0)
    parser.add_argument("--target_percentile", type=float, default=float(mask_default("target_percentile")))
    parser.add_argument("--target_dimension_filter_percentile", type=float, default=99.0)
    parser.add_argument("--target_mask_dilate_px", type=int, default=int(mask_default("target_mask_dilate_px")))
    parser.add_argument(
        "--target_mask_min_component_area_px",
        type=int,
        default=int(mask_default("target_mask_min_component_area_px")),
    )
    parser.add_argument("--target_edge_outer_px", type=int, default=int(mask_default("target_edge_outer_px")))
    parser.add_argument("--shadow_percentile", type=float, default=float(mask_default("shadow_percentile")))
    parser.add_argument(
        "--shadow_min_area_fraction",
        type=float,
        default=float(mask_default("shadow_min_area_fraction")),
    )
    parser.add_argument(
        "--shadow_min_target_area_fraction",
        type=float,
        default=float(mask_default("shadow_min_target_area_fraction")),
    )
    parser.add_argument(
        "--convert_use_standalone_shadow_target_dimensions",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Use filtered standalone shadow/target dimension probing before geometry prior.",
    )
    parser.add_argument(
        "--convert_auto_verify_optical",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Run optical sar_imaging_verify after convert; verify now keeps optical_mirror_u false by default.",
    )
    parser.add_argument(
        "--shadow_geometry_azimuth_mode",
        choices=["near_zero", "cardinal", "mstar_axis_split", "diagonal", "oblique"],
        default="mstar_axis_split",
    )
    parser.add_argument(
        "--target_dimension_summary_azimuth_mode",
        choices=["oblique", "cardinal", "mstar_axis_split", "any"],
        default="mstar_axis_split",
    )
    parser.add_argument(
        "--post_sfm_scheme_a_planform_scale",
        type=float,
        default=1.0,
        help="Planform scale for Scheme-A geometry prior; 1.0 avoids extra target enlargement.",
    )
    parser.add_argument("--gs_iterations", type=int, default=5000)
    parser.add_argument("--novel_azimuth_start", type=int, default=0)
    parser.add_argument("--novel_azimuth_end", type=int, default=360)
    parser.add_argument("--novel_azimuth_step", type=int, default=5)
    parser.add_argument(
        "--novel_azimuths",
        type=str,
        default=None,
        help="Explicit comma/space-separated novel-view azimuths. Overrides start/end/step when provided.",
    )
    parser.add_argument(
        "--skip_existing_novel_views",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="In render-only mode, do not re-render azimuth PNGs that already exist.",
    )
    parser.add_argument("--novel_depression_angle", type=float, default=15.0)
    parser.add_argument("--novel_pose_mode", choices=["colmap_track", "orbit"], default="colmap_track")
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--azimuth_shadow_fixed_direction_deg", type=float, default=None)
    parser.add_argument("--azimuth_shadow_geometry_extent_gate", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_geometry_extent_apply_to_recognition", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_geometry_extent_require_dataset_direction", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--azimuth_shadow_geometry_extent_forward_scale", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_geometry_extent_lateral_scale", type=float, default=1.0)
    parser.add_argument("--azimuth_shadow_geometry_extent_margin_px", type=float, default=1.5)
    parser.add_argument("--azimuth_shadow_geometry_extent_min_forward_px", type=float, default=0.0)
    parser.add_argument("--azimuth_shadow_intensity_strength", type=float, default=1.22)
    parser.add_argument("--azimuth_shadow_intensity_min_attenuation", type=float, default=0.38)
    parser.add_argument("--azimuth_shadow_intensity_max_attenuation", type=float, default=0.93)
    parser.add_argument("--azimuth_shadow_intensity_gamma", type=float, default=0.80)
    parser.add_argument("--azimuth_shadow_intensity_context_radius", type=int, default=13)
    parser.add_argument("--azimuth_shadow_intensity_block_radius", type=int, default=7)
    parser.add_argument("--azimuth_shadow_intensity_exclude_dilate", type=int, default=2)
    parser.add_argument("--azimuth_match_tolerance", type=int, default=5)
    parser.add_argument(
        "--refiner_azimuth_shadow",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Train/apply the azimuth-shadow refiner after the base target refiner.",
    )
    parser.add_argument(
        "--refiner_intermediate_debug_eval",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Run the five extra intermediate refiner metric/eval passes.",
    )
    parser.add_argument(
        "--refiner_adjacent_similarity_eval",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Run adjacent-view similarity diagnostics after final renders.",
    )
    parser.add_argument(
        "--refiner_record_debug_artifacts",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Copy large refiner debug artifacts into the result archive.",
    )
    parser.add_argument("--start_at", choices=["sfm", "gs", "render", "refiner"], default="sfm")
    parser.add_argument("--stop_after", choices=["sfm", "gs", "render", "refiner"], default="refiner")
    parser.add_argument("--skip_sfm", action="store_true")
    parser.add_argument("--skip_gs", action="store_true")
    parser.add_argument("--skip_refiner", action="store_true")
    parser.add_argument("--dry_run", action="store_true")
    parser.add_argument("--plan_only", action="store_true", help="Parse and print the structured execution plan, then exit.")
    args = parser.parse_args(argv)
    _apply_prompt_overrides(args)
    _validate_prompt_azimuth_consistency(args)
    if int(args.novel_azimuth_step) <= 0:
        raise SystemExit("--novel_azimuth_step must be positive")

    data_root = _resolve_path(args.data_root) or (REPO_ROOT / "data")
    output_root = _resolve_output_root(args, data_root)
    data_dirs = _resolve_data_dirs(args, data_root)
    if not data_dirs:
        raise SystemExit(
            "Could not infer data folder. Pass --data_dir data/360-1, "
            "--data_dirs data/360-1 data/360-3, or a semicolon-separated list."
        )
    _validate_batch_paths(args, data_dirs)
    _apply_raysar_target_only_defaults(args)
    stages = _selected_stages(args)
    plan = _build_agent_plan(args, data_dirs, output_root, stages)
    if args.plan_only:
        _print_agent_plan(plan)
        return 0

    results: list[dict] = []
    status = "ok"
    try:
        if len(data_dirs) > 1:
            print(f"[agent batch] queued {len(data_dirs)} datasets sequentially")
        for index, data_dir in enumerate(data_dirs, start=1):
            print(f"[agent batch] dataset {index}/{len(data_dirs)}")
            results.append(_run_one_dataset(args, data_dir=data_dir, output_root=output_root, stages=stages))
    except Exception:
        status = "failed"
        raise
    finally:
        if len(data_dirs) > 1 or results:
            batch_record = _write_batch_record(output_root, args, results, status)
            print(f"\n[agent batch record] {batch_record}")

    print("\n[agent outputs]")
    for item in results:
        print(f"  [{item['dataset']}] run root      : {item['run_root']}")
        print(f"  [{item['dataset']}] SfM           : {item['sfm_dir']}")
        print(f"  [{item['dataset']}] SfM archive   : {item['sfm_archive_dir'] or 'not run'}")
        print(f"  [{item['dataset']}] gaussian      : {item['model_dir']}")
        if bool(item.get("refiner_enabled")):
            print(f"  [{item['dataset']}] refiner       : {item['refiner_work_dir']}")
            print(f"  [{item['dataset']}] class export  : {item['classification_label_output_dir']}")
        else:
            print(f"  [{item['dataset']}] refiner       : skipped")
            print(f"  [{item['dataset']}] class export  : skipped")
        print(f"  [{item['dataset']}] final renders : {item['final_renders']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
