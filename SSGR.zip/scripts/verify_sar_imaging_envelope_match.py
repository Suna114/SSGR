#!/usr/bin/env python3
"""
SAR 鎴愬儚鍖呯粶 vs 璁粌鍥惧姣斿伐鍏?
鐢ㄤ笌 mesh_prior / GS SAR rasterizer 涓€鑷寸殑鏂滆窛鎴愬儚锛屽皢 3D 鐩爣锛堢偣浜?AABB 鎴栨瘮渚嬬洅锛?浠庣浉鏈轰綅濮挎姇褰卞埌鍍忕礌骞抽潰锛屼笌璁粌鍥鹃槾褰辨眹鎬荤殑 L/W/H 鎴栧浘鍍忎笂浼拌鐨勭洰鏍囧寘缁滃姣斻€?
鐢ㄦ硶锛堝湪椤圭洰鏍圭洰褰曪級:
  # SAR 鏂滆锛氭枃浠跺悕 蠁_sar=15掳 + 鏂滆窛鎶曞奖锛堜笌璁粌 SAR 鍥惧姣旓紝榛樿锛?  python scripts/verify_sar_imaging_envelope_match.py -s data/360-1 --use_nominal_box

  # 鍏夊閫忚锛欳OLMAP 75掳 澶栧弬 + 閽堝瓟鎶曞奖锛堜笌 geometry_prior_gs_model / 3DGS 璁粌涓€鑷达級
  python scripts/verify_sar_imaging_envelope_match.py -s data/360-1 --use_nominal_box --projection_mode optical

  # SAR 鏂滆锛坮ough_model / SO-RCG 璺緞锛屽嬁涓?gs 鍏夊娣风敤锛夛細
  python scripts/verify_sar_imaging_envelope_match.py -s data/360-1 --use_nominal_box --projection_mode sar

  python scripts/verify_sar_imaging_envelope_match.py -s data/360-1 --side_views_only

榛樿澶勭悊**鍏ㄩ儴鏂逛綅瑙?*璁粌鍥撅紱姣忓紶鍥捐鍙?shadow_diagnostic 涓殑鐩爣瀹介珮涓庝腑蹇冿紝
涓庢ā鎷熸姇褰卞寘缁滃姣斻€俙`sar`` 妯″紡鐢?MSTAR 淇 + 鏂滆窛鎴愬儚锛沗`optical`` 妯″紡鐢?COLMAP 閽堝瓟銆?
杈撳嚭:
  <source>/sar_imaging_verify/
    index.html          娴忚鍏ㄩ儴瀵规瘮鍥?    report.txt          鏁板€兼姤鍛?    compare_*.png       涓夎仈鍥撅細璁粌 | 浣嶅Э妯℃嫙SAR | 鍙犲姞鍖呯粶
    sim_*.png           浠呮ā鎷?SAR 鐩爣鍥撅紙鐢辩浉鏈轰綅濮库€滄媿鎽勨€濓級
    mosaic_sim_all.png  鍏ㄨ搴︽ā鎷熷浘缃戞牸锛堟寜鏂逛綅瑙掓帓搴忥級
    mosaic_train_sim.png 鍏ㄨ搴?璁粌|妯℃嫙 瀵圭収缃戞牸
"""

from __future__ import annotations

import argparse
import html
import json
import math
import os
import re
import sys
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
_DATA_PREP = os.path.join(_ROOT, "scripts", "data_prep")
for _p in (_ROOT, _DATA_PREP):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from post_sfm.colmap_points import read_points3d_binary_full
from post_sfm.mesh_obj_prior_core import _sar_project_world_to_pixels_xy
from post_sfm.summary_parser import mstar_side_view_pixel_targets, parse_target_dimension_summary
from sar.geometry import DEFAULT_SAR_PARAMS
from sar.imaging_mode import (
    dataset_convention_debug_summary,
    load_dataset_convention_probe,
    resolve_dataset_world_yaw_deg,
    resolve_gs_optical_ring_azimuth_sign,
)
from sar.utils import parse_mstar_filename


@dataclass
class PerViewTrainTarget:
    """Per-image target bbox parsed from shadow diagnostics."""

    width_px: float
    height_px: float
    center_u: float
    center_v: float
    u_min: float
    u_max: float
    v_min: float
    v_max: float


ProjectionMode = str  # "sar" | "optical"


@dataclass
class ViewEnvelope:
    name: str
    azimuth_deg: float
    depression_deg: float
    depression_sar_deg: float
    projection_mode: str
    span_u: float
    span_v: float
    u_min: float
    u_max: float
    v_min: float
    v_max: float
    target_u_px: float
    target_v_px: float
    train_cx: float
    train_cy: float
    sim_cx: float
    sim_cy: float
    center_err_px: float
    ratio_u: float
    ratio_v: float
    is_side_view: bool
    has_train_bbox: bool


def _aabb_corners(xyz: np.ndarray) -> np.ndarray:
    xyz = np.asarray(xyz, dtype=np.float64).reshape(-1, 3)
    lo = xyz.min(axis=0)
    hi = xyz.max(axis=0)
    corners = []
    for x in (lo[0], hi[0]):
        for y in (lo[1], hi[1]):
            for z in (lo[2], hi[2]):
                corners.append([x, y, z])
    return np.asarray(corners, dtype=np.float64)


def _envelope_from_uv(
    pix: np.ndarray,
    lo_pct: float = 5.0,
    hi_pct: float = 95.0,
    *,
    use_minmax: bool = False,
) -> Tuple[float, float, float, float, float, float]:
    xy = np.asarray(pix, dtype=np.float64).reshape(-1, 2)
    if xy.shape[0] == 0:
        return 0.0, 0.0, 0.0, 0.0, 1e-6, 1e-6
    if use_minmax or xy.shape[0] < 4 or xy.shape[0] >= 64:
        u0, u1 = float(xy[:, 0].min()), float(xy[:, 0].max())
        v0, v1 = float(xy[:, 1].min()), float(xy[:, 1].max())
    else:
        u0 = float(np.percentile(xy[:, 0], lo_pct))
        u1 = float(np.percentile(xy[:, 0], hi_pct))
        v0 = float(np.percentile(xy[:, 1], lo_pct))
        v1 = float(np.percentile(xy[:, 1], hi_pct))
    su = max(u1 - u0, 1e-6)
    sv = max(v1 - v0, 1e-6)
    return u0, u1, v0, v1, su, sv


def _is_side_view_azimuth(az_deg: float, tol: float = 5.0) -> bool:
    a = float(az_deg) % 360.0
    for ref in (90.0, 270.0):
        d = min(abs(a - ref), abs(a - ref + 360.0), abs(a - ref - 360.0))
        if d <= tol:
            return True
    return False


_DIAG_CENTER_RE = re.compile(r"鐩爣涓績浣嶇疆:\s*\(([\d.]+),\s*([\d.]+)\)")
_DIAG_BOUNDS_RE = re.compile(
    r"鐩爣杈圭晫:\s*X=\[([\d.]+),\s*([\d.]+)\],\s*Y=\[([\d.]+),\s*([\d.]+)\]"
)
_DIAG_WIDTH_RE = re.compile(r"鐩爣瀹藉害:\s*([\d.]+)\s*鍍忕礌")
_DIAG_HEIGHT_RE = re.compile(r"鐩爣楂樺害:\s*([\d.]+)\s*鍍忕礌")


def _parse_shadow_diagnostic_target(path: str) -> Optional[PerViewTrainTarget]:
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
    except OSError:
        return None
    mw = _DIAG_WIDTH_RE.search(text)
    mh = _DIAG_HEIGHT_RE.search(text)
    if not mw or not mh:
        return None
    w_px = float(mw.group(1))
    h_px = float(mh.group(1))
    cx, cy = w_px / 2.0 + 64.0, h_px / 2.0 + 64.0
    u0, u1, v0, v1 = 0.0, w_px, 0.0, h_px
    mc = _DIAG_CENTER_RE.search(text)
    if mc:
        cx = float(mc.group(1))
        cy = float(mc.group(2))
    mb = _DIAG_BOUNDS_RE.search(text)
    if mb:
        u0, u1 = float(mb.group(1)), float(mb.group(2))
        v0, v1 = float(mb.group(3)), float(mb.group(4))
        w_px = max(u1 - u0, 1.0)
        h_px = max(v1 - v0, 1.0)
    return PerViewTrainTarget(
        width_px=w_px,
        height_px=h_px,
        center_u=cx,
        center_v=cy,
        u_min=u0,
        u_max=u1,
        v_min=v0,
        v_max=v1,
    )


def _load_shadow_diagnostic_map(source_path: str) -> Dict[str, PerViewTrainTarget]:
    viz = os.path.join(source_path, "adaptive_threshold_visualization")
    if not os.path.isdir(viz):
        return {}
    out: Dict[str, PerViewTrainTarget] = {}
    for fn in os.listdir(viz):
        if not fn.startswith("shadow_diagnostic_") or not fn.endswith(".txt"):
            continue
        stem = fn[len("shadow_diagnostic_") : -4]
        tgt = _parse_shadow_diagnostic_target(os.path.join(viz, fn))
        if tgt is not None:
            out[stem] = tgt
    return out


def _load_points3d_world(sparse_dir: str) -> np.ndarray:
    bin_path = os.path.join(sparse_dir, "points3D.bin")
    txt_path = os.path.join(sparse_dir, "points3D.txt")
    if os.path.isfile(bin_path):
        recs = read_points3d_binary_full(bin_path)
        if recs:
            return np.stack([r.xyz for r in recs], axis=0)
    if os.path.isfile(txt_path):
        pts: List[List[float]] = []
        with open(txt_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.startswith("#") or not line.strip():
                    continue
                parts = line.split()
                if len(parts) >= 4:
                    pts.append([float(parts[1]), float(parts[2]), float(parts[3])])
        if pts:
            return np.asarray(pts, dtype=np.float64)
    return np.zeros((0, 3), dtype=np.float64)


def _load_sar_params_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def _dataset_convention_from_source(source_path: str, scale: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    conv = load_dataset_convention_probe(source_path)
    if conv is None and isinstance(scale, dict):
        cached = scale.get("dataset_convention")
        if isinstance(cached, dict):
            conv = cached
    return conv


def _resolve_convention_sign(source_path: str, scale: Dict[str, Any]) -> int:
    class _Args:
        pass

    args = _Args()
    args.source_path = source_path
    return int(resolve_gs_optical_ring_azimuth_sign(args, scale))


def _resolve_convention_world_yaw_deg(
    source_path: str,
    scale: Dict[str, Any],
    *,
    default_yaw_deg: float = -90.0,
) -> float:
    try:
        class _Args:
            pass

        args = _Args()
        args.source_path = source_path
        return float(resolve_dataset_world_yaw_deg(args, scale, default_yaw_deg=default_yaw_deg))
    except Exception:
        try:
            return float(scale.get("sfm_mesh_prior_extra_world_yaw_deg", default_yaw_deg))
        except (TypeError, ValueError):
            return float(default_yaw_deg)


def _side_view_pixel_targets_for_convention(
    l_med_px: float,
    w_med_px: float,
    *,
    side_view: bool,
    convention: Optional[Dict[str, Any]],
) -> Tuple[float, float]:
    if not side_view:
        return float(l_med_px), float(w_med_px)
    mapping = str((convention or {}).get("side_view_lw_mapping") or "").replace(" ", "").lower()
    if "l=image_x" in mapping and "w=image_y" in mapping:
        return float(l_med_px), float(w_med_px)
    if "l=image_y" in mapping and "w=image_x" in mapping:
        return float(w_med_px), float(l_med_px)
    return mstar_side_view_pixel_targets(l_med_px, w_med_px, side_view=True)


def _resolve_base_camera_height_m(scale: Dict[str, Any]) -> float:
    ch = float(scale.get("camera_height", 0.0) or 0.0)
    h0 = float(scale.get("mstar_init_camera_height_m", 0.0) or 0.0)

    if scale.get("mstar_init_from_pixel_resolution"):
        if h0 > 0.5:
            return h0
        if ch > 0.5:
            return ch
        r0 = float(scale.get("mstar_init_slant_range_m", 0.0) or 0.0)
        if r0 > 1.0:
            return r0 * math.sin(math.radians(15.0))

    if ch > 0.5:
        return ch
    if h0 > 0.5:
        return h0
    return 4.97


def _resolve_mesh_uniform_scale(scale: Dict[str, Any], override: Optional[float]) -> float:
    if override is not None:
        return float(override)
    ms = float(scale.get("mstar_computed_mesh_uniform_scale", 1.0) or 1.0)
    if not math.isfinite(ms) or ms < 0.25 or ms > 2.5:
        return 1.0
    return ms


def build_sar_params_for_projection(
    scale: Dict[str, Any],
    *,
    camera_height_scale: float = 1.0,
    camera_height_m: Optional[float] = None,
    mesh_uniform_scale: float = 1.0,
) -> Dict[str, Any]:
    ref = scale.get("reference_image_size", [128, 128])
    na, nr = int(ref[0]), int(ref[1])
    base_h = _resolve_base_camera_height_m(scale)
    if camera_height_m is not None:
        h = float(camera_height_m)
    else:
        h = base_h * float(camera_height_scale)

    scene_scale = float(scale.get("scene_scale", 0.15))
    if base_h > 1e-6 and abs(h - base_h) / base_h > 1e-6:
        scene_scale *= h / base_h

    sp: Dict[str, Any] = dict(DEFAULT_SAR_PARAMS)
    sp.update(
        {
            "camera_height": h,
            "Na": na,
            "Nr": nr,
            "scene_scale": scene_scale,
            "radius_scale": float(
                scale.get("unified_radius_scale", scale.get("radius_scale", 1.0))
            ),
            "camera_distribution_mode": str(
                scale.get("camera_distribution_mode", "ring")
            ),
            "range_pixel_spacing": float(scale.get("mstar_range_resolution_m", 0.3) or 0.3),
            "azimuth_pixel_spacing": float(scale.get("mstar_azimuth_resolution_m", 0.3) or 0.3),
            "mstar_filename_depression_convention": "horizon",
        }
    )
    if mesh_uniform_scale != 1.0:
        sp["_mesh_uniform_scale"] = float(mesh_uniform_scale)
    return sp


def _scale_corners_about_pivot(corners: np.ndarray, scale: float, pivot: np.ndarray) -> np.ndarray:
    s = float(scale)
    c = np.asarray(pivot, dtype=np.float64).reshape(3)
    return (corners - c) * s + c


def _list_training_images(source_path: str) -> List[str]:
    for sub in ("input", "images"):
        d = os.path.join(source_path, sub)
        if not os.path.isdir(d):
            continue
        out = []
        for fn in sorted(os.listdir(d)):
            if fn.lower().endswith((".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp")):
                out.append(os.path.join(d, fn))
        if out:
            return out
    return []


def _read_gray(path: str) -> Optional[np.ndarray]:
    im = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    return im


def _draw_overlay(
    gray: np.ndarray,
    sim_uv: np.ndarray,
    target_u: float,
    target_v: float,
    train_cx: float,
    train_cy: float,
    sim_cx: float,
    sim_cy: float,
    title: str,
) -> np.ndarray:
    h, w = gray.shape[:2]
    rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

    half_u = float(target_u) / 2.0
    half_v = float(target_v) / 2.0
    tl = int(round(train_cx - half_u))
    tr = int(round(train_cx + half_u))
    tb = int(round(train_cy - half_v))
    tt = int(round(train_cy + half_v))
    cv2.rectangle(rgb, (tl, tb), (tr, tt), (0, 200, 255), 1, cv2.LINE_AA)
    cv2.drawMarker(
        rgb,
        (int(round(train_cx)), int(round(train_cy))),
        (0, 200, 255),
        cv2.MARKER_CROSS,
        8,
        1,
        cv2.LINE_AA,
    )

    xy = np.asarray(sim_uv, dtype=np.float64).reshape(-1, 2)
    u0, u1, v0, v1, _, _ = _envelope_from_uv(xy)
    p1 = (int(round(u0)), int(round(v0)))
    p2 = (int(round(u1)), int(round(v1)))
    cv2.rectangle(rgb, p1, p2, (0, 255, 0), 2, cv2.LINE_AA)
    cv2.drawMarker(
        rgb,
        (int(round(sim_cx)), int(round(sim_cy))),
        (0, 255, 0),
        cv2.MARKER_CROSS,
        8,
        1,
        cv2.LINE_AA,
    )

    for pt in xy[:: max(1, len(xy) // 12)]:
        cv2.circle(rgb, (int(round(pt[0])), int(round(pt[1]))), 2, (0, 255, 0), -1)

    cv2.putText(
        rgb,
        title,
        (4, 14),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.38,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )
    cv2.putText(
        rgb,
        "cyan=train bbox  green=sim envelope  cross=centers",
        (4, h - 6),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.32,
        (200, 200, 200),
        1,
        cv2.LINE_AA,
    )
    return rgb


def _aabb_surface_grid(corners: np.ndarray, grid: int = 36) -> np.ndarray:
    """Sample an AABB surface grid for simulated projection."""
    lo = np.min(corners, axis=0)
    hi = np.max(corners, axis=0)
    g = int(max(grid, 4))
    lin = np.linspace(0.0, 1.0, g, dtype=np.float64)
    pts: list[list[float]] = []

    def _face(u_axis: int, v_axis: int, fixed_axis: int, fixed_val: float) -> None:
        for a in lin:
            for b in lin:
                p = [0.0, 0.0, 0.0]
                p[fixed_axis] = fixed_val
                p[u_axis] = lo[u_axis] + a * (hi[u_axis] - lo[u_axis])
                p[v_axis] = lo[v_axis] + b * (hi[v_axis] - lo[v_axis])
                pts.append(p)

    for ax in range(3):
        _face((ax + 1) % 3, (ax + 2) % 3, ax, float(lo[ax]))
        _face((ax + 1) % 3, (ax + 2) % 3, ax, float(hi[ax]))
    return np.asarray(pts, dtype=np.float64)


def _load_sim_geometry_points(
    source_path: str,
    sparse_dir: str,
    corners: np.ndarray,
    *,
    prefer_pointcloud: bool = True,
    max_pts: int = 30_000,
    surface_grid: int = 36,
) -> np.ndarray:
    """Internal helper."""
    if prefer_pointcloud:
        pts = _load_points3d_world(sparse_dir)
        if pts.shape[0] >= 64:
            if pts.shape[0] > max_pts:
                rng = np.random.default_rng(42)
                idx = rng.choice(pts.shape[0], size=int(max_pts), replace=False)
                pts = pts[idx]
            return pts
    return _aabb_surface_grid(corners, grid=surface_grid)


def _render_simulated_sar_image(
    pix_uv: np.ndarray,
    height: int,
    width: int,
    *,
    blur_sigma: float = 1.2,
) -> np.ndarray:
    """Rasterize projected points into a simulated target image."""
    h, w = int(height), int(width)
    out = np.zeros((h, w), dtype=np.float32)
    xy = np.asarray(pix_uv, dtype=np.float64).reshape(-1, 2)
    if xy.shape[0] >= 3:
        hull = cv2.convexHull(xy.astype(np.float32).reshape(-1, 1, 2))
        hull_i = np.round(hull).astype(np.int32)
        mask = np.zeros((h, w), dtype=np.uint8)
        if hull_i.shape[0] >= 3:
            cv2.fillConvexPoly(mask, hull_i, 255)
            out = mask.astype(np.float32) / 255.0
    for u, v in xy:
        ui, vi = int(round(u)), int(round(v))
        if 0 <= ui < w and 0 <= vi < h:
            out[vi, ui] = 1.0
    if blur_sigma > 0:
        k = int(max(3, round(blur_sigma * 4)) | 1)
        out = cv2.GaussianBlur(out, (k, k), blur_sigma)
    mx = float(out.max())
    if mx > 1e-6:
        out = out / mx
    return (out * 255.0).clip(0, 255).astype(np.uint8)


def _label_panel(bgr: np.ndarray, text: str) -> np.ndarray:
    out = bgr.copy()
    cv2.putText(
        out,
        text,
        (4, 14),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.42,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )
    return out


def _side_by_side_panels(
    train_gray: np.ndarray,
    sim_gray: np.ndarray,
    overlay_bgr: np.ndarray,
    *,
    sim_label: str = "SIM (SAR slant-range)",
) -> np.ndarray:
    """Build the train/sim/overlay comparison panel."""
    t = cv2.cvtColor(train_gray, cv2.COLOR_GRAY2BGR)
    s = cv2.cvtColor(sim_gray, cv2.COLOR_GRAY2BGR)
    t = _label_panel(t, "TRAIN")
    s = _label_panel(s, sim_label)
    o = _label_panel(overlay_bgr, "OVERLAY")
    return np.hstack([t, s, o])


def _annotate_tile(gray: np.ndarray, label: str) -> np.ndarray:
    if gray.ndim == 2:
        bgr = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    else:
        bgr = gray.copy()
    cv2.putText(
        bgr,
        label,
        (2, 11),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.28,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )
    return bgr


def _build_azimuth_mosaic(
    tiles: Sequence[Tuple[float, str, np.ndarray]],
    *,
    cols: int = 6,
    tile_size: int = 128,
    tile_w: Optional[int] = None,
    tile_h: Optional[int] = None,
    pad: int = 2,
) -> np.ndarray:
    """Build a mosaic sorted by azimuth."""
    ordered = sorted(tiles, key=lambda x: float(x[0]))
    n = len(ordered)
    tw = int(tile_w if tile_w is not None else tile_size)
    th = int(tile_h if tile_h is not None else tile_size)
    if n == 0:
        return np.zeros((th, tw, 3), dtype=np.uint8)
    cols = int(max(1, min(cols, n)))
    rows = int(math.ceil(n / cols))
    ph = int(pad)
    canvas = np.zeros((rows * (th + ph) + ph, cols * (tw + ph) + ph, 3), dtype=np.uint8)
    for i, (azi, label, img) in enumerate(ordered):
        r, c = divmod(i, cols)
        y0 = ph + r * (th + ph)
        x0 = ph + c * (tw + ph)
        if img.ndim == 2:
            cell = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        else:
            cell = img.copy()
        cell = cv2.resize(cell, (tw, th), interpolation=cv2.INTER_NEAREST)
        cell = _annotate_tile(cell, f"{int(round(azi)):03d} {label}")
        canvas[y0 : y0 + th, x0 : x0 + tw] = cell
    return canvas


def _rotate_world_yaw_y(xyz: np.ndarray, yaw_deg: float) -> np.ndarray:
    """Rotate points around the world Y axis."""
    th = math.radians(float(yaw_deg))
    c, s = float(math.cos(th)), float(math.sin(th))
    R = np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]], dtype=np.float64)
    return np.asarray(xyz, dtype=np.float64) @ R.T


def _nominal_box_corners(
    source_path: str,
    *,
    world_yaw_deg: Optional[float] = None,
    scale: Optional[Dict[str, Any]] = None,
    prefer_sparse: bool = True,
) -> np.ndarray:
    from sar.scene_scale_closure import (
        MSTAR_DEFAULT_AZIMUTH_RES_M,
        MSTAR_DEFAULT_RANGE_RES_M,
        _box_corners_ground_contact,
        aabb_corners_from_lo_hi,
        fixed_physical_args_from_scale_json,
        load_sparse_points3d_xyz,
        mstar_physical_semiaxes_xyz,
        resolve_mstar_fixed_physical_semiaxes,
        sparse_target_envelope_usable,
        world_aabb_from_points,
    )

    sparse_dir = os.path.join(source_path, "sparse", "0")
    scale = scale or {}
    prefer_sparse = bool(prefer_sparse and scale.get("gs_target_envelope_from_sparse", True))
    if prefer_sparse and sparse_target_envelope_usable(sparse_dir):
        xyz = load_sparse_points3d_xyz(sparse_dir)
        lo, hi = world_aabb_from_points(xyz)
        return aabb_corners_from_lo_hi(lo, hi)

    from post_sfm.summary_parser import parse_target_dimension_summary

    summary_path = os.path.join(
        source_path,
        "adaptive_threshold_visualization",
        "target_dimension_constraints_summary.txt",
    )
    stats = parse_target_dimension_summary(summary_path)
    if stats is None:
        raise RuntimeError("缂哄皯 target_dimension_constraints_summary.txt")

    use_fixed = bool(scale.get("mstar_fixed_physical_target_dims"))
    if use_fixed:
        sem = resolve_mstar_fixed_physical_semiaxes(
            fixed_physical_args_from_scale_json(scale), stats
        )
    else:
        sem = mstar_physical_semiaxes_xyz(
            stats,
            rho_azimuth_m=MSTAR_DEFAULT_AZIMUTH_RES_M,
            rho_range_m=MSTAR_DEFAULT_RANGE_RES_M,
            planform_scale=float(scale.get("post_sfm_scheme_a_planform_scale", 1.0) or 1.0),
        )
    if sem is None:
        raise RuntimeError("鏃犳硶浠?summary 鎺ㄥ鍚嶄箟鍗婅酱")
    corners = _box_corners_ground_contact(*sem)
    if abs(float(world_yaw_deg)) > 1e-9:
        corners = _rotate_world_yaw_y(corners, world_yaw_deg)
    return corners


def _project_sar_numpy(
    xyz_w: np.ndarray,
    R_world_to_radar: np.ndarray,
    camera_center_world: np.ndarray,
    *,
    na: int,
    nr: int,
    delta_az: float,
    delta_rng: float,
) -> np.ndarray:
    """Project points with the SAR rasterizer geometry."""
    R = np.asarray(R_world_to_radar, dtype=np.float64).reshape(3, 3)
    cam = np.asarray(camera_center_world, dtype=np.float64).reshape(3)
    xyz = np.asarray(xyz_w, dtype=np.float64).reshape(-1, 3)
    mr = xyz @ R.T
    plat = (R @ cam.reshape(3, 1)).ravel()
    sl = np.linalg.norm(mr - plat.reshape(1, 3), axis=1)
    hd = plat[2] - mr[:, 2]
    gr = np.sqrt(np.maximum(sl ** 2 - hd ** 2, 0.0))
    ref_gr = float(np.median(gr))
    az = mr[:, 0] / max(delta_az, 1e-18) + na / 2.0
    rng = (gr - ref_gr) / max(delta_rng, 1e-18) + nr / 2.0
    return np.stack([az, rng], axis=1)


def _mirror_pixels_u(uv: np.ndarray, image_width: float) -> np.ndarray:
    """Mirror pixel coordinates around the image center when explicitly requested."""
    out = np.asarray(uv, dtype=np.float64).reshape(-1, 2).copy()
    cx = float(image_width) * 0.5
    out[:, 0] = 2.0 * cx - out[:, 0]
    return out


def _resolve_optical_mirror_u(
    scale: Dict[str, Any],
    *,
    override: Optional[bool] = None,
) -> bool:
    if override is not None:
        return bool(override)
    # gs_satellite_poses already applies gs_optical_ring_azimuth_sign to poses;
    # keep verification projection unmirrored unless the CLI override is set.
    return False


def _project_pinhole_numpy(
    xyz_w: np.ndarray,
    colmap_view: Any,
    *,
    ring_radius_scale: float = 1.0,
    mirror_u: bool = False,
) -> Optional[np.ndarray]:
    """Internal helper."""
    from post_sfm.sar_colmap_geom import camera_center_world, world_to_pixel

    xyz = np.asarray(xyz_w, dtype=np.float64).reshape(-1, 3)
    if xyz.shape[0] == 0:
        return np.zeros((0, 2), dtype=np.float64)

    rs = float(ring_radius_scale)
    if abs(rs - 1.0) > 1e-9:
        cam = camera_center_world(colmap_view)
        xyz = (xyz - cam.reshape(1, 3)) * rs + cam.reshape(1, 3)

    u, v, valid = world_to_pixel(xyz, colmap_view)
    if not np.any(valid):
        return None
    uv = np.stack([u[valid], v[valid]], axis=1)
    if mirror_u:
        uv = _mirror_pixels_u(uv, float(colmap_view.width))
    return uv


def _normalize_projection_mode(mode: Optional[str]) -> str:
    m = (mode or "sar").strip().lower()
    if m in ("sar", "slant_range", "side_looking", "mstar"):
        return "sar"
    if m in ("optical", "pinhole", "colmap", "perspective", "gs"):
        return "optical"
    raise ValueError(f"Unknown projection_mode={mode!r}; expected 'sar' or 'optical'")


def _project_view(
    corners: np.ndarray,
    sar_sp: Dict[str, Any],
    dep_sar: float,
    azi: float,
    *,
    projection_mode: str = "sar",
    colmap_view: Optional[Any] = None,
    ring_radius_scale: float = 1.0,
    optical_mirror_u: bool = False,
) -> Optional[np.ndarray]:
    """Project geometry for one view."""
    mode = _normalize_projection_mode(projection_mode)

    if mode == "optical":
        if colmap_view is None:
            return None
        return _project_pinhole_numpy(
            corners,
            colmap_view,
            ring_radius_scale=ring_radius_scale,
            mirror_u=optical_mirror_u,
        )

    return _sar_project_world_to_pixels_xy(
        corners,
        sar_params=sar_sp,
        depression_deg=float(dep_sar),
        azimuth_deg=float(azi),
    )


def _resolve_render_depression_horizon_deg(
    dep_sar: float,
    sar_sp: Dict[str, Any],
    scale: Dict[str, Any],
    *,
    override_deg: Optional[float] = None,
) -> Tuple[float, float, str]:
    """Resolve render depression used by optical verification."""
    if override_deg is not None and float(override_deg) > 0:
        rd = float(override_deg)
        return rd, float(dep_sar), f"CLI override render={rd:.2f} deg"

    cached = scale.get("gs_optical_render_depression_horizon_deg")
    if cached is not None:
        try:
            rd = float(cached)
            if math.isfinite(rd) and rd > 0:
                sar_cached = float(scale.get("gs_sar_filename_depression_horizon_deg", dep_sar) or dep_sar)
                note = str(scale.get("gs_optical_render_depression_note", "sar_scale_params"))
                return rd, sar_cached, note
        except (TypeError, ValueError):
            pass

    from sar.optical_equivalent_depression import resolve_gs_render_depression_horizon_deg

    rd, sar, note = resolve_gs_render_depression_horizon_deg(
        float(dep_sar),
        sar_params=sar_sp,
        use_optical_equiv=bool(
            scale.get("gs_satellite_poses_applied")
            or scale.get("sfm_use_optical_equivalent_depression")
        ),
        method=str(
            scale.get(
                "sfm_optical_equivalent_depression_method",
                "complement_overhead",
            )
        ),
        fixed_horizon_deg=scale.get("sfm_gs_optical_depression_horizon_deg"),
    )
    return float(rd), float(sar), str(note)


def evaluate_views(
    source_path: str,
    *,
    camera_height_scale: float = 1.0,
    camera_height_m: Optional[float] = None,
    mesh_uniform_scale: Optional[float] = None,
    side_views_only: bool = False,
    side_tol_deg: float = 5.0,
    use_nominal_box: bool = False,
    projection_mode: str = "sar",
    ring_radius_scale: float = 1.0,
    world_yaw_deg: Optional[float] = None,
    gs_render_depression_horizon_deg: Optional[float] = None,
    optical_mirror_u: Optional[bool] = None,
) -> Tuple[List[ViewEnvelope], Dict[str, Any], np.ndarray, Dict[str, Any]]:
    sparse_dir = os.path.join(source_path, "sparse", "0")
    scale_path = os.path.join(source_path, "sar_scale_params.json")
    summary_path = os.path.join(
        source_path,
        "adaptive_threshold_visualization",
        "target_dimension_constraints_summary.txt",
    )

    mode = _normalize_projection_mode(projection_mode)

    scale = _load_sar_params_json(scale_path) if os.path.isfile(scale_path) else {}
    dataset_convention = _dataset_convention_from_source(source_path, scale)
    convention_sign = _resolve_convention_sign(source_path, scale)
    scale["gs_optical_ring_azimuth_sign"] = int(convention_sign)
    if dataset_convention is not None:
        scale["dataset_convention"] = dataset_convention
    mirror_u = (
        _resolve_optical_mirror_u(scale, override=optical_mirror_u)
        if mode == "optical"
        else False
    )
    stats = parse_target_dimension_summary(summary_path)
    l_med = float(stats.length_median_px) if stats and stats.length_median_px else 43.5
    w_med = float(stats.width_median_px) if stats and stats.width_median_px else 16.5
    h_med = float(stats.height_median_px) if stats and stats.height_median_px else w_med

    ms = _resolve_mesh_uniform_scale(scale, mesh_uniform_scale)

    sar_sp = build_sar_params_for_projection(
        scale,
        camera_height_scale=camera_height_scale,
        camera_height_m=camera_height_m,
        mesh_uniform_scale=ms,
    )

    pts = _load_points3d_world(sparse_dir)
    if world_yaw_deg is None:
        world_yaw_deg = _resolve_convention_world_yaw_deg(source_path, scale)
    else:
        world_yaw_deg = float(world_yaw_deg)
    print(f"[verify] {dataset_convention_debug_summary(source_path, scale)}; world_yaw={world_yaw_deg:.1f} deg")
    if use_nominal_box:
        corners = _nominal_box_corners(
            source_path,
            world_yaw_deg=world_yaw_deg,
            scale=scale,
            prefer_sparse=False,
        )
        sim_geom = corners
    elif scale.get("gs_target_envelope_from_sparse") and pts.shape[0] >= 64:
        corners = _aabb_corners(pts)
        sim_geom = pts
    elif pts.shape[0] >= 8:
        # sparse points3D 宸插湪 mesh_prior 涓惈 extra_world_yaw锛屽嬁鍐嶆棆杞?AABB
        corners = _aabb_corners(pts)
        sim_geom = corners
    else:
        corners = _nominal_box_corners(
            source_path,
            world_yaw_deg=world_yaw_deg,
            scale=scale,
            prefer_sparse=True,
        )
        sim_geom = corners
    pivot = np.array([0.0, 0.0, 0.0], dtype=np.float64)
    if abs(ms - 1.0) > 1e-9:
        sim_geom = _scale_corners_about_pivot(sim_geom, ms, pivot)
        corners = _scale_corners_about_pivot(corners, ms, pivot)

    img_paths = _list_training_images(source_path)
    if not img_paths:
        raise RuntimeError(f"鏈壘鍒拌缁冨浘: {source_path}/input 鎴?images")

    train_targets = _load_shadow_diagnostic_map(source_path)
    img_w = int(sar_sp.get("Na", 128))
    img_h = int(sar_sp.get("Nr", 128))

    colmap_views: Dict[str, Any] = {}
    if mode == "optical":
        from post_sfm.sar_colmap_geom import load_colmap_views

        for v in load_colmap_views(sparse_dir):
            stem = os.path.splitext(os.path.basename(v.name))[0]
            colmap_views[stem] = v
        if not colmap_views:
            raise RuntimeError(
                f"optical 妯″紡闇€瑕?sparse/0 COLMAP 澶栧弬锛屼絾鏈壘鍒? {sparse_dir}"
            )

    views: List[ViewEnvelope] = []
    render_dep_meta: Optional[float] = None
    sar_dep_meta: Optional[float] = None
    render_dep_note_meta = ""
    for ip in img_paths:
        fn = os.path.basename(ip)
        stem = os.path.splitext(fn)[0]
        try:
            dep_sar, azi = parse_mstar_filename(stem)
        except Exception:
            continue
        dep_render, dep_sar, _dep_note = _resolve_render_depression_horizon_deg(
            float(dep_sar),
            sar_sp,
            scale,
            override_deg=gs_render_depression_horizon_deg,
        )
        if render_dep_meta is None:
            render_dep_meta = float(dep_render)
            sar_dep_meta = float(dep_sar)
            render_dep_note_meta = str(_dep_note)
        side = _is_side_view_azimuth(azi, side_tol_deg)
        if side_views_only and not side:
            continue

        colmap_view = colmap_views.get(stem) if mode == "optical" else None
        if mode == "optical" and colmap_view is None:
            continue

        pix = _project_view(
            sim_geom,
            sar_sp,
            float(dep_sar),
            azi,
            projection_mode=mode,
            colmap_view=colmap_view,
            ring_radius_scale=ring_radius_scale,
            optical_mirror_u=mirror_u,
        )
        if pix is None:
            continue
        u0, u1, v0, v1, su, sv = _envelope_from_uv(
            pix, use_minmax=(sim_geom.shape[0] >= 64)
        )
        sim_cx = 0.5 * (u0 + u1)
        sim_cy = 0.5 * (v0 + v1)

        diag = train_targets.get(stem)
        if diag is not None:
            tgt_u = float(diag.width_px)
            tgt_v = float(diag.height_px)
            train_cx = float(diag.center_u)
            train_cy = float(diag.center_v)
            has_bbox = True
        else:
            tgt_u, tgt_v = _side_view_pixel_targets_for_convention(
                l_med,
                w_med,
                side_view=side,
                convention=dataset_convention,
            )
            train_cx = float(img_w) * 0.5
            train_cy = float(img_h) * 0.5
            has_bbox = False

        center_err = float(
            math.hypot(sim_cx - train_cx, sim_cy - train_cy)
        )
        views.append(
            ViewEnvelope(
                name=stem,
                azimuth_deg=azi,
                depression_deg=float(dep_render if mode == "optical" else dep_sar),
                depression_sar_deg=float(dep_sar),
                projection_mode=mode,
                span_u=su,
                span_v=sv,
                u_min=u0,
                u_max=u1,
                v_min=v0,
                v_max=v1,
                target_u_px=tgt_u,
                target_v_px=tgt_v,
                train_cx=train_cx,
                train_cy=train_cy,
                sim_cx=sim_cx,
                sim_cy=sim_cy,
                center_err_px=center_err,
                ratio_u=su / max(tgt_u, 1e-6),
                ratio_v=sv / max(tgt_v, 1e-6),
                is_side_view=side,
                has_train_bbox=has_bbox,
            )
        )

    meta = {
        "camera_height_m": float(sar_sp["camera_height"]),
        "camera_height_scale": float(camera_height_scale),
        "mesh_uniform_scale": float(ms),
        "n_views": len(views),
        "n_train_bbox": sum(1 for v in views if v.has_train_bbox),
        "l_med_px": l_med,
        "w_med_px": w_med,
        "projection_mode": mode,
        "ring_radius_scale": float(ring_radius_scale),
        "gs_render_depression_horizon_deg": render_dep_meta,
        "gs_sar_filename_depression_horizon_deg": sar_dep_meta,
        "gs_render_depression_note": render_dep_note_meta,
        "optical_mirror_u": bool(mirror_u) if mode == "optical" else False,
        "gs_optical_ring_azimuth_sign": int(convention_sign),
        "world_yaw_deg": float(world_yaw_deg),
        "dataset_convention": dataset_convention,
    }
    return views, sar_sp, corners, meta


def recommend_camera_height_scale(
    source_path: str,
    *,
    mesh_uniform_scale: Optional[float] = None,
    h_min: float = 0.55,
    h_max: float = 2.5,
    steps: int = 40,
    side_tol_deg: float = 5.0,
) -> Tuple[float, List[Tuple[float, float]]]:
    curve: List[Tuple[float, float]] = []
    best_s = 1.0
    best_cost = 1e18

    for s in np.linspace(h_min, h_max, int(steps)):
        views, _, _, _ = evaluate_views(
            source_path,
            camera_height_scale=float(s),
            mesh_uniform_scale=mesh_uniform_scale,
            side_views_only=True,
            side_tol_deg=side_tol_deg,
        )
        if not views:
            continue
        cost = 0.0
        for v in views:
            # 妯℃嫙鍋忓ぇ 鈫?ratio>1 鈫?搴斿澶?H 鈫?鎯╃綒 log(ratio)
            cost += abs(math.log(max(v.ratio_u, 1e-6)))
            cost += 0.35 * abs(math.log(max(v.ratio_v, 1e-6)))
        cost /= max(len(views), 1)
        curve.append((float(s), float(cost)))
        if cost < best_cost:
            best_cost = cost
            best_s = float(s)

    return best_s, curve


def _auto_nominal_box_fit_scale(views: Sequence[ViewEnvelope]) -> Optional[float]:
    ref = [v for v in views if v.is_side_view and v.has_train_bbox]
    if len(ref) < 1:
        ref = [v for v in views if v.has_train_bbox]
    vals: List[float] = []
    for v in ref:
        if v.ratio_u > 1e-6 and math.isfinite(v.ratio_u):
            vals.append(1.0 / float(v.ratio_u))
        if v.ratio_v > 1e-6 and math.isfinite(v.ratio_v):
            vals.append(1.0 / float(v.ratio_v))
    if not vals:
        return None
    s = float(np.median(np.asarray(vals, dtype=np.float64)))
    if not math.isfinite(s):
        return None
    return float(np.clip(s, 0.35, 2.5))


def _write_html_index(
    out_dir: str,
    view_cards: Sequence[Tuple[float, str, str]],
    report_lines: Sequence[str],
    *,
    mosaic_names: Sequence[str],
) -> None:
    mosaic_rows = []
    for fn in mosaic_names:
        mosaic_rows.append(
            f'<div class="mosaic"><img src="{html.escape(fn)}" /><div>{html.escape(fn)}</div></div>'
        )
    cards = []
    for azi, fn, caption in sorted(view_cards, key=lambda x: float(x[0])):
        cards.append(
            f'<div class="card" data-azi="{azi:.0f}">'
            f'<img src="{html.escape(fn)}" />'
            f'<div>{html.escape(caption)}</div></div>'
        )
    rep = "<br/>".join(html.escape(ln) for ln in report_lines[:55])
    body = "\n".join([
        "<!doctype html>",
        "<html>",
        "<head>",
        '<meta charset="utf-8" />',
        "<title>SAR imaging verification</title>",
        "<style>",
        "body { font-family: Arial, sans-serif; margin: 20px; background: #111; color: #eee; }",
        "pre { background: #1b1b1b; padding: 12px; white-space: pre-wrap; }",
        ".grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 12px; }",
        ".card, .mosaic { background: #222; padding: 8px; border: 1px solid #444; }",
        ".card img, .mosaic img { width: 100%; height: auto; image-rendering: pixelated; }",
        "</style>",
        "</head>",
        "<body>",
        "<h2>SAR imaging verification</h2>",
        f"<pre>{rep}</pre>",
        "<h3>Mosaics</h3>",
        "".join(mosaic_rows),
        f"<h3>Per-view comparisons ({len(cards)})</h3>",
        f'<div class="grid">{"".join(cards)}</div>',
        "</body>",
        "</html>",
    ])
    with open(os.path.join(out_dir, "index.html"), "w", encoding="utf-8") as f:
        f.write(body)


def main() -> int:
    ap = argparse.ArgumentParser(description="Verify SAR/optical simulated target envelope against training images")
    ap.add_argument("-s", "--source_path", required=True, help="Dataset path, e.g. data/360-1")
    ap.add_argument("--camera_height_scale", type=float, default=1.0, help="Scale camera height for testing")
    ap.add_argument("--camera_height_m", type=float, default=None, help="Override camera height in meters")
    ap.add_argument("--mesh_uniform_scale", type=float, default=None, help="Override mesh/box uniform scale")
    ap.add_argument("--side_views_only", action="store_true", help="Evaluate only side views near 90/270 deg")
    ap.add_argument("--side_tol_deg", type=float, default=5.0, help="Side-view azimuth tolerance in degrees")
    ap.add_argument("--sweep_height_scale", action="store_true", help="Sweep camera_height_scale and report a recommendation")
    ap.add_argument("--use_nominal_box", action="store_true", help="Use summary-derived nominal box instead of points3D AABB")
    ap.add_argument("--projection_mode", choices=("sar", "optical"), default="sar", help="Projection mode")
    ap.add_argument("--use_colmap_poses", action="store_true", help="Alias for --projection_mode optical")
    ap.add_argument("--gs_render_depression_horizon_deg", type=float, default=None, help="Override optical render depression from horizon")
    ap.add_argument("--ring_radius_scale", type=float, default=1.0, help="Scale optical projection around camera center")
    ap.add_argument("--world_yaw_deg", type=float, default=None, help="Override world yaw before projection")
    ap.add_argument(
        "--optical_mirror_u",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Manually mirror optical U coordinates. Default is no mirror because pose azimuth sign is already applied.",
    )
    ap.add_argument("--output_dir", default="", help="Output directory; default <source>/sar_imaging_verify")
    ap.add_argument("--mosaic_cols", type=int, default=6, help="Mosaic columns")
    args = ap.parse_args()

    projection_mode = _normalize_projection_mode(args.projection_mode)
    if args.use_colmap_poses:
        if projection_mode != "optical":
            print("--use_colmap_poses implies --projection_mode optical")
        projection_mode = "optical"

    source_path = os.path.abspath(args.source_path)
    out_dir = args.output_dir.strip() or os.path.join(source_path, "sar_imaging_verify")
    os.makedirs(out_dir, exist_ok=True)

    report: List[str] = []
    report.append(f"source_path: {source_path}")

    if args.sweep_height_scale:
        best_s, curve = recommend_camera_height_scale(
            source_path,
            mesh_uniform_scale=args.mesh_uniform_scale,
            side_tol_deg=args.side_tol_deg,
        )
        report.append(f"recommended camera_height_scale: {best_s:.4f}")
        report.append("height sweep samples (scale, cost):")
        for s_val, c_val in curve[:: max(1, len(curve) // 12)]:
            report.append(f"  {s_val:.3f} -> cost={c_val:.4f}")
        args.camera_height_scale = best_s

    views, sar_sp, corners, meta = evaluate_views(
        source_path,
        camera_height_scale=args.camera_height_scale,
        camera_height_m=args.camera_height_m,
        mesh_uniform_scale=args.mesh_uniform_scale,
        side_views_only=args.side_views_only,
        side_tol_deg=args.side_tol_deg,
        use_nominal_box=args.use_nominal_box,
        projection_mode=projection_mode,
        ring_radius_scale=args.ring_radius_scale,
        world_yaw_deg=args.world_yaw_deg,
        gs_render_depression_horizon_deg=args.gs_render_depression_horizon_deg,
        optical_mirror_u=args.optical_mirror_u,
    )
    if args.mesh_uniform_scale is None and args.use_nominal_box:
        auto_scale = _auto_nominal_box_fit_scale(views)
        if auto_scale is not None and abs(auto_scale - 1.0) > 0.05:
            args.mesh_uniform_scale = auto_scale
            report.append(f"auto nominal box fit scale: {auto_scale:.4f}")
            views, sar_sp, corners, meta = evaluate_views(
                source_path,
                camera_height_scale=args.camera_height_scale,
                camera_height_m=args.camera_height_m,
                mesh_uniform_scale=args.mesh_uniform_scale,
                side_views_only=args.side_views_only,
                side_tol_deg=args.side_tol_deg,
                use_nominal_box=args.use_nominal_box,
                projection_mode=projection_mode,
                ring_radius_scale=args.ring_radius_scale,
                world_yaw_deg=args.world_yaw_deg,
                gs_render_depression_horizon_deg=args.gs_render_depression_horizon_deg,
                optical_mirror_u=args.optical_mirror_u,
            )

    colmap_views: Dict[str, Any] = {}
    if projection_mode == "optical":
        from post_sfm.sar_colmap_geom import load_colmap_views

        sparse_dir = os.path.join(source_path, "sparse", "0")
        for v in load_colmap_views(sparse_dir):
            stem = os.path.splitext(os.path.basename(v.name))[0]
            colmap_views[stem] = v

    sim_label = (
        f"SIM (pinhole dep={meta['gs_render_depression_horizon_deg']:.0f}deg)"
        if projection_mode == "optical" and meta.get("gs_render_depression_horizon_deg") is not None
        else ("SIM (pinhole COLMAP)" if projection_mode == "optical" else f"SIM (SAR slant dep={meta.get('gs_sar_filename_depression_horizon_deg', 15):.0f}deg)")
    )

    report.append(f"projection_mode: {projection_mode}")
    if projection_mode == "optical":
        report.append(
            f"gs_optical_ring_azimuth_sign: {meta.get('gs_optical_ring_azimuth_sign', 1)}  "
            f"optical_mirror_u: {meta.get('optical_mirror_u', False)}"
        )

    report.append(f"camera_height_m: {meta['camera_height_m']:.4f}")
    report.append(f"camera_height_scale: {meta['camera_height_scale']:.4f}")
    report.append(f"mesh_uniform_scale: {meta['mesh_uniform_scale']:.4f}")
    report.append(f"world_yaw_deg: {meta.get('world_yaw_deg', 0.0):.1f}")
    conv = meta.get("dataset_convention")
    if isinstance(conv, dict):
        report.append(
            "dataset_convention: "
            f"shadow={conv.get('shadow_side', 'unknown')}  "
            f"az0={conv.get('zero_azimuth_axis_mapping', 'unknown')}  "
            f"side_LW={conv.get('side_view_lw_mapping', 'unknown')}  "
            f"rotation={conv.get('rotation_direction', 'unknown')}"
        )
    if meta.get("gs_render_depression_horizon_deg") is not None:
        report.append(
            f"gs_render_depression: {meta['gs_render_depression_horizon_deg']:.1f} deg "
            f"(SAR filename dep={meta.get('gs_sar_filename_depression_horizon_deg', '?')})"
        )
        if projection_mode == "sar":
            report.append(
                f"  sar projection uses filename dep={meta.get('gs_sar_filename_depression_horizon_deg', '?')}; "
                f"optical render dep={meta['gs_render_depression_horizon_deg']:.1f}"
            )
        if meta.get("gs_render_depression_note"):
            report.append(f"  note: {meta['gs_render_depression_note']}")
    report.append(f"train L/W median (summary): {meta['l_med_px']:.1f} / {meta['w_med_px']:.1f} px")
    report.append(f"views: {meta['n_views']}  with per-image bbox: {meta['n_train_bbox']}")
    report.append("")
    report.append(
        f"{'view':<22} {'azi':>5} {'sim_u':>6} {'tr_u':>6} {'ru':>5} "
        f"{'sim_v':>6} {'tr_v':>6} {'rv':>5} {'ctr':>5} side"
    )
    report.append("-" * 88)

    view_cards: List[Tuple[float, str, str]] = []
    sim_png_names: List[str] = []
    sim_tiles: List[Tuple[float, str, np.ndarray]] = []
    train_sim_tiles: List[Tuple[float, str, np.ndarray]] = []
    img_map = {os.path.splitext(os.path.basename(p))[0]: p for p in _list_training_images(source_path)}
    sparse_dir = os.path.join(source_path, "sparse", "0")
    sim_pts = _load_sim_geometry_points(
        source_path,
        sparse_dir,
        corners,
        prefer_pointcloud=bool(not args.use_nominal_box),
    )

    for v in views:
        report.append(
            f"{v.name:<22} {v.azimuth_deg:5.1f} {v.span_u:6.2f} {v.target_u_px:6.2f} {v.ratio_u:5.2f} "
            f"{v.span_v:6.2f} {v.target_v_px:6.2f} {v.ratio_v:5.2f} {v.center_err_px:5.1f} "
            f"{'Y' if v.is_side_view else 'n'}"
        )
        ip = img_map.get(v.name)
        if ip is None:
            continue
        gray = _read_gray(ip)
        if gray is None:
            continue
        pix = _project_view(
            sim_pts,
            sar_sp,
            v.depression_sar_deg,
            v.azimuth_deg,
            projection_mode=projection_mode,
            colmap_view=colmap_views.get(v.name) if projection_mode == "optical" else None,
            ring_radius_scale=args.ring_radius_scale,
            optical_mirror_u=bool(meta.get("optical_mirror_u", False)),
        )
        if pix is None:
            continue
        h, w = gray.shape[:2]
        sim_gray = _render_simulated_sar_image(pix, h, w)
        sim_only_path = f"sim_{v.name}.png"
        cv2.imwrite(os.path.join(out_dir, sim_only_path), sim_gray)
        sim_png_names.append(sim_only_path)
        sim_tiles.append((v.azimuth_deg, v.name, sim_gray))

        pair = np.hstack([_annotate_tile(gray, "TR"), _annotate_tile(sim_gray, "SIM")])
        train_sim_tiles.append((v.azimuth_deg, v.name, pair))

        pix_env = _project_view(
            corners,
            sar_sp,
            v.depression_sar_deg,
            v.azimuth_deg,
            projection_mode=projection_mode,
            colmap_view=colmap_views.get(v.name) if projection_mode == "optical" else None,
            ring_radius_scale=args.ring_radius_scale,
            optical_mirror_u=bool(meta.get("optical_mirror_u", False)),
        )
        title = f"{v.name} azi={v.azimuth_deg:.0f} ru={v.ratio_u:.2f} rv={v.ratio_v:.2f} ctr={v.center_err_px:.1f}px"
        overlay = _draw_overlay(
            gray,
            pix_env if pix_env is not None else pix,
            v.target_u_px,
            v.target_v_px,
            v.train_cx,
            v.train_cy,
            v.sim_cx,
            v.sim_cy,
            title,
        )
        panel = _side_by_side_panels(gray, sim_gray, overlay, sim_label=sim_label)
        out_png = f"compare_{v.name}.png"
        cv2.imwrite(os.path.join(out_dir, out_png), panel)
        cap = f"{v.name}  azi={v.azimuth_deg:.0f}deg  ru={v.ratio_u:.2f} rv={v.ratio_v:.2f}  center_err={v.center_err_px:.1f}px"
        view_cards.append((v.azimuth_deg, out_png, cap))

    mosaic_names: List[str] = []
    if sim_tiles:
        mosaic_sim = _build_azimuth_mosaic([(a, "SIM", im) for a, _, im in sim_tiles], cols=args.mosaic_cols)
        cv2.imwrite(os.path.join(out_dir, "mosaic_sim_all.png"), mosaic_sim)
        mosaic_names.append("mosaic_sim_all.png")
    if train_sim_tiles:
        mosaic_pair = _build_azimuth_mosaic(
            [(a, "TR|SIM", im) for a, _, im in train_sim_tiles],
            cols=max(3, args.mosaic_cols // 2),
            tile_w=256,
            tile_h=128,
        )
        cv2.imwrite(os.path.join(out_dir, "mosaic_train_sim.png"), mosaic_pair)
        mosaic_names.append("mosaic_train_sim.png")

    if views:
        ru_all = float(np.median([v.ratio_u for v in views]))
        rv_all = float(np.median([v.ratio_v for v in views]))
        ce_all = float(np.median([v.center_err_px for v in views]))
        ce_p95 = float(np.percentile([v.center_err_px for v in views], 95))
        report.append("")
        report.append(f"all-view median ratio_u(sim/train_u): {ru_all:.3f}")
        report.append(f"all-view median ratio_v(sim/train_v): {rv_all:.3f}")
        report.append(f"all-view median center_err: {ce_all:.1f} px  (p95={ce_p95:.1f})")
        bad = sorted(
            [v for v in views if v.ratio_u < 0.75 or v.ratio_u > 1.35 or v.ratio_v < 0.75 or v.ratio_v > 1.35],
            key=lambda x: max(abs(math.log(max(x.ratio_u, 1e-6))), abs(math.log(max(x.ratio_v, 1e-6)))),
            reverse=True,
        )[:8]
        if bad:
            report.append("largest ratio mismatches:")
            for v in bad:
                report.append(f"  {v.name} azi={v.azimuth_deg:.0f} ru={v.ratio_u:.2f} rv={v.ratio_v:.2f}")

    side = [v for v in views if v.is_side_view]
    if side:
        ru = float(np.median([v.ratio_u for v in side]))
        rv = float(np.median([v.ratio_v for v in side]))
        report.append("")
        report.append(f"side-view median ratio_u(sim/train): {ru:.3f}")
        report.append(f"side-view median ratio_v(sim/train): {rv:.3f}")
        if ru > 1.05:
            mesh_rec = float(meta["mesh_uniform_scale"]) / max(ru, rv, 1e-6)
            mesh_rec = float(np.clip(mesh_rec, 0.35, 2.2))
            report.append(f"recommended --sfm_mesh_prior_final_uniform_scale {mesh_rec:.3f}")
        if rv > 1.05:
            mesh_rec = float(meta["mesh_uniform_scale"]) / rv
            mesh_rec = float(np.clip(mesh_rec, 0.35, 2.2))
            report.append(f"recommended --sfm_mesh_prior_final_uniform_scale {mesh_rec:.3f}")
        if rv < 0.85:
            mesh_rec = float(meta["mesh_uniform_scale"]) / max(rv, 1e-6)
            mesh_rec = float(np.clip(mesh_rec, 0.35, 2.2))
            report.append(f"recommended --sfm_mesh_prior_final_uniform_scale {mesh_rec:.3f}")

    report_path = os.path.join(out_dir, "report.txt")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(report) + "\n")

    _write_html_index(out_dir, view_cards, report, mosaic_names=mosaic_names)

    print("\n".join(report))
    print(f"\nOutput: {out_dir}")
    print(f"  index: {os.path.join(out_dir, 'index.html')}")
    print("  mosaics: mosaic_sim_all.png / mosaic_train_sim.png")
    print(f"  per-view: compare_*.png={len(view_cards)} sim_*.png={len(sim_png_names)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
