#!/usr/bin/env python3
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

import torch
from random import choice
from argparse import ArgumentParser
from arguments import ModelParams, OptimizationParams, PipelineParams
from scene import Scene, GaussianModel
from gaussian_renderer import render
from train import _build_azimuth_strata
import train_sar_complete as tsc
from sar.sar_seed_refine_bg_shadow import maybe_seed_sar_refine_bg_shadow_at_init
from sar.cuda_preprocess import project_gaussians_sdgr_cuda
from sar.rasterizer import _sanitize_sar_raster_inputs, _conics_for_raster
from diff_sar_rasterization import _C

sys.argv = ["x", "-s", "data/360-1", "-m", "output/debug-crash", "--no_sar_fast_mode", "--sar_sdgr_cuda"]
args = tsc.parse_sar_arguments()
lp = ModelParams(ArgumentParser()); op = OptimizationParams(ArgumentParser()); pp = PipelineParams(ArgumentParser())
dataset = lp.extract(args); opt = op.extract(args); pipe = pp.extract(args)
g = GaussianModel(dataset.sh_degree)
scene = Scene(dataset, g, shuffle=False)
g.training_setup(opt)
maybe_seed_sar_refine_bg_shadow_at_init(g, opt, dataset_sar_mode=True, checkpoint_was_loaded=False, scene=scene)
bg = torch.zeros(3, device="cuda")
cams = scene.getTrainCameras().copy()
bins, _ = _build_azimuth_strata(cams, len(cams))
for it in range(1, 16):
    g.update_learning_rate(it)
    bi = choice([i for i, b in enumerate(bins) if b])
    cam = cams[choice(bins[bi])]
    pkg = render(cam, g, pipe, bg, sar_mode=True)
    loss = (pkg["render"] - cam.original_image.cuda()).abs().mean()
    loss.backward()
    g.optimizer.step(); g.optimizer.zero_grad(set_to_none=True)
    torch.cuda.synchronize()
    print(f"iter {it} ok")

cam = next(c for c in cams if "041" in c.image_name)
R = torch.as_tensor(cam.R_world_to_radar, device="cuda", dtype=torch.float32)
cc = torch.as_tensor(cam.camera_center, device="cuda", dtype=torch.float32)
H, W = cam.image_height, cam.image_width
out = project_gaussians_sdgr_cuda(g.get_xyz, g.get_scaling, g.get_rotation, R, cc, W, H, 0.2031, 0.2021)
m2d, cov2D, depths = out["means2D"], out["cov2D"], out["depths"]
op = g.get_opacity
m2d, cov2D, op = _sanitize_sar_raster_inputs(m2d, cov2D, op, H, W)
conics = _conics_for_raster(cov2D, None, H, W)
col = torch.rand(g.get_xyz.shape[0], 3, device="cuda")
print("stats: conic max", conics.abs().max().item(), "means2D", m2d.min().item(), m2d.max().item())
for n in [50000, 50100, 50200, 50244]:
    sl = slice(0, n)
    try:
        nr, oc, rad, *_ = _C.rasterize_sar_forward(
            m2d[sl].contiguous(), conics[sl].contiguous(), op[sl].contiguous(),
            col[sl], (-depths[sl]).contiguous(), torch.zeros(3, device="cuda"), W, H, True)
        print(f"  n={n} OK nr={nr} rad_max={int(rad.max())} rad>0={(rad>0).sum().item()}")
        torch.cuda.synchronize()
    except Exception as e:
        print(f"  n={n} FAIL {e}")
        break

# single gaussian scan in plate range
for i in range(50000, 50244):
    sl = slice(i, i + 1)
    try:
        _C.rasterize_sar_forward(
            m2d[sl].contiguous(), conics[sl].contiguous(), op[sl].contiguous(),
            col[sl], (-depths[sl]).contiguous(), torch.zeros(3, device="cuda"), W, H, False)
    except Exception as e:
        print(f"bad gaussian {i}: {e}")
        print("  m2d", m2d[i].tolist(), "conic", conics[i].tolist())
        break
else:
    print("all single gaussians OK")
