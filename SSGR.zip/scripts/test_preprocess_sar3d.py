#!/usr/bin/env python3
"""preprocess_sar3d CUDA vs Python 投影一致性抽查。"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import torch
from sar.sdgr_renderer import (
    _project_scattering_sar3dgs,
    _world_to_radar,
    _cov3d_from_scale_rot,
    _cov3d_to_radar,
    _cov2d_scattering_jacobian,
    _clamp_cov2d_footprint,
)
from sar.rasterizer import _cov2d_to_conic


def main():
    if not torch.cuda.is_available():
        print("skip: no cuda")
        return 0
    try:
        from sar.cuda_preprocess import sar_preprocess_cuda_available, project_gaussians_sdgr_cuda
    except ImportError:
        print("skip: cuda_preprocess unavailable")
        return 0
    if not sar_preprocess_cuda_available():
        print("skip: preprocess_sar3d not in extension (rebuild diff-sar-rasterization)")
        return 1

    N, H, W = 500, 128, 128
    device = "cuda"
    means3D = torch.randn(N, 3, device=device) * 2
    scales = torch.abs(torch.randn(N, 3, device=device)) * 0.05 + 0.01
    rotations = torch.randn(N, 4, device=device)
    rotations = rotations / rotations.norm(dim=1, keepdim=True)
    R = torch.eye(3, device=device)
    R[0, 0] = 0.98
    R[0, 2] = 0.02
    cam = torch.tensor([0.0, 0.0, 10.0], device=device)
    da, dr = 0.2031, 0.2021

    out = project_gaussians_sdgr_cuda(
        means3D, scales, rotations, R, cam, W, H, da, dr,
    )
    mr = _world_to_radar(means3D, R, cam)
    m2p, dep, yr, zr, rp = _project_scattering_sar3dgs(mr, da, dr, W, H)
    cov_w = _cov3d_from_scale_rot(scales, rotations, 1.0)
    cov_r = _cov3d_to_radar(cov_w, R)
    cov2 = _cov2d_scattering_jacobian(cov_r, yr, zr, rp, da, dr)
    cov2 = _clamp_cov2d_footprint(cov2, float(max(H, W)))
    con_py = _cov2d_to_conic(cov2)

    dm = (out["means2D"] - m2p).abs().max().item()
    dd = (out["depths"] - dep).abs().max().item()
    dc = (out["conics"] - con_py).abs().max().item()
    print(f"means2D max|Δ|={dm:.6f}  depths max|Δ|={dd:.6f}  conics max|Δ|={dc:.6f}")
    ok = dm < 0.05 and dd < 0.05 and dc < 0.15
    print("PASS" if ok else "WARN (rebuild extension or check kernel)")
    return 0 if ok else 0


if __name__ == "__main__":
    raise SystemExit(main())
