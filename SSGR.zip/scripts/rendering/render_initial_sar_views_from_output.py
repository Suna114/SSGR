#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从训练输出目录读取 cameras.json + 初始点云，高斯化后按各 SAR 视角渲染（替代 COLMAP GUI 目检）。

设计要点：
- 相机外参与焦距以输出目录 cameras.json 为准（与训练保存一致）。
- SAR 专有字段（散射掩码、R_world_to_radar、sar_params 等）从 cfg_args 所指数据目录，
  用与训练相同的 sceneLoadTypeCallbacks 再次加载 SceneInfo；按图像名对齐。
- 初始几何使用 output/input.ply（或 --ply）。

依赖：CUDA、与原训练一致的 Python 环境与数据路径（cfg_args 内 source_path 仍可读）。

示例（在仓库根目录）::

    python scripts/rendering/render_initial_sar_views_from_output.py -m ./output/your_run

可选::

    python scripts/rendering/render_initial_sar_views_from_output.py -m ./output/your_run \\
        --ply ./output/your_run/input.ply --out ./output/your_run/init_gaussian_renders
"""

from __future__ import annotations

# --- repo root on sys.path ---
import pathlib as _plib
import sys

for _repo in _plib.Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_plib.Path(__file__)))
del _plib, _repo, _s

import argparse
import json
import os
from argparse import Namespace
from pathlib import Path

import numpy as np
import torch
import torchvision
from tqdm import tqdm

from arguments.__init__ import _reload_scattering_masks_from_source
from arguments.__init__ import _strip_scattering_masks_blob_from_cfg_str
from gaussian_renderer import render
from scene.dataset_readers import (
    CameraInfo,
    SceneInfo,
    getNerfppNorm,
    readColmapSceneInfo,
    readMstarNoSfMSceneInfo,
)
from scene.gaussian_model import BasicPointCloud, GaussianModel
from utils.camera_utils import loadCam
from utils.general_utils import safe_state
from utils.graphics_utils import focal2fov


def load_training_cfg(model_path: str) -> Namespace:
    cfg_file = os.path.join(model_path, "cfg_args")
    if not os.path.isfile(cfg_file):
        raise FileNotFoundError(
            f"未找到 {cfg_file}。请先完成一次训练写入 cfg_args，或通过 -m 指向正确输出目录。"
        )
    with open(cfg_file, encoding="utf-8") as f:
        txt = _strip_scattering_masks_blob_from_cfg_str(f.read())
    cfg = eval(txt, {"__builtins__": __builtins__, "Namespace": Namespace})
    merged = Namespace(**vars(cfg))
    merged.model_path = os.path.abspath(model_path)
    sm = getattr(merged, "scattering_masks", None)
    if sm is None:
        sp = getattr(merged, "source_path", None)
        if sp:
            img_rel = getattr(merged, "images", None)
            if not img_rel:
                img_rel = "images"
            loaded = _reload_scattering_masks_from_source(sp, img_rel)
            if loaded:
                merged.scattering_masks = loaded
                print(f"[init_render] 已从数据目录加载 scattering_masks: {len(loaded)} 张")
    return merged


def load_scene_info(cfg: Namespace) -> SceneInfo:
    sp = os.path.abspath(getattr(cfg, "source_path", "") or "")
    if not os.path.isdir(sp):
        raise FileNotFoundError(f"cfg_args 中的 source_path 无效: {sp}")
    images = getattr(cfg, "images", None) or "images"
    depths = getattr(cfg, "depths", "") or ""
    train_test_exp = bool(getattr(cfg, "train_test_exp", False))
    llff = int(getattr(cfg, "llffhold", 8) or 8)
    sm = getattr(cfg, "scattering_masks", None)

    # 与 scene.Scene 一致：禁用几何重算时 sar_params=None
    sar_params_for_colmap = None

    if getattr(cfg, "mstar_nosfm", False):
        return readMstarNoSfMSceneInfo(
            sp, images, eval=False, train_test_exp=train_test_exp, llffhold=llff, args=cfg
        )
    sparse = os.path.join(sp, "sparse")
    if not os.path.isdir(sparse):
        raise FileNotFoundError(
            f"未找到稀疏重建目录 {sparse}，且未设置 mstar_nosfm。\n"
            "  请使用 train_sar_complete_nosfm 生成数据，或在 cfg_args 中加 --mstar_nosfm，"
            "  或改用带 sparse/ 的数据源。"
        )
    return readColmapSceneInfo(
        sp,
        images,
        depths,
        False,
        train_test_exp,
        llffhold=llff,
        sar_params=sar_params_for_colmap,
        use_sar_geometry=False,
        scattering_masks=sm,
    )


def cameras_json_ordered_paths(model_path: str) -> list[str]:
    jpath = os.path.join(model_path, "cameras.json")
    with open(jpath, encoding="utf-8") as f:
        cams = json.load(f)
    return [str(c["img_name"]) for c in cams]


def json_entry_to_gs_rt(cam_entry: dict) -> tuple[np.ndarray, np.ndarray]:
    """与 scene.camera_to_JSON 互逆（忽略训练时的 translate/scale，与原保存一致）。"""
    C2W = np.eye(4, dtype=np.float64)
    C2W[:3, :3] = np.array(cam_entry["rotation"], dtype=np.float64)
    C2W[:3, 3] = np.array(cam_entry["position"], dtype=np.float64)
    W2C = np.linalg.inv(C2W)
    R_cam_to_world = W2C[:3, :3].T.astype(np.float32)
    t_world_to_cam = W2C[:3, 3].astype(np.float32)
    return R_cam_to_world, t_world_to_cam


def build_caminfo_lookup(si: SceneInfo) -> dict[str, CameraInfo]:
    out: dict[str, CameraInfo] = {}
    dup_note = []
    for c in list(si.train_cameras) + list(si.test_cameras):
        key = str(c.image_name)
        if key in out:
            dup_note.append(key)
        out[key] = c
    if dup_note:
        print("[init_render] 警告: 以下图像名在 train/test 中出现多次，后以最后一次为准:")
        print("  " + ", ".join(sorted(set(dup_note))))
    return out


def load_initial_pointcloud(path: str) -> BasicPointCloud:
    from plyfile import PlyData

    ply = PlyData.read(path)
    v = ply["vertex"]
    pos = np.column_stack([v["x"], v["y"], v["z"]]).astype(np.float32)
    colors = np.zeros((pos.shape[0], 3), dtype=np.float32)
    try:
        colors = (
            np.column_stack([v["red"], v["green"], v["blue"]]).astype(np.float32) / 255.0
        )
    except ValueError:
        print("[init_render] PLY 无 RGB，使用中性灰初始化颜色。")
        colors[:] = 0.5

    normals = np.zeros_like(pos)
    try:
        normals = np.column_stack([v["nx"], v["ny"], v["nz"]]).astype(np.float32)
    except ValueError:
        pass

    return BasicPointCloud(points=pos, colors=colors, normals=normals)


def merge_pipe(cfg: Namespace, force_sar_fast: bool | None, force_sar_sig3dgs: bool | None):
    pipe = Namespace()
    pipe.convert_SHs_python = getattr(cfg, "convert_SHs_python", False)
    pipe.compute_cov3D_python = getattr(cfg, "compute_cov3D_python", False)
    pipe.debug = getattr(cfg, "debug", False)
    pipe.antialiasing = getattr(cfg, "antialiasing", False)
    pipe.sar_rendering = getattr(cfg, "sar_rendering", True)
    if force_sar_fast is not None:
        pipe.sar_fast_mode = bool(force_sar_fast)
    else:
        pipe.sar_fast_mode = bool(getattr(cfg, "sar_fast_mode", True))
    if force_sar_sig3dgs is not None:
        pipe.sar_sig3dgs_visibility = bool(force_sar_sig3dgs)
    else:
        pipe.sar_sig3dgs_visibility = bool(getattr(cfg, "sar_sig3dgs_visibility", True))
    return pipe


def main():
    ap = argparse.ArgumentParser(
        description="用 output/cameras.json + input.ply 做初始高斯，渲染各 SAR 视角"
    )
    ap.add_argument(
        "-m",
        "--model_path",
        type=str,
        required=True,
        help="训练输出目录（内含 cfg_args、cameras.json、input.ply）",
    )
    ap.add_argument(
        "--ply",
        type=str,
        default=None,
        help="初始点云 ply（默认: <model_path>/input.ply）",
    )
    ap.add_argument(
        "--out",
        type=str,
        default=None,
        help="渲染输出目录（默认: <model_path>/initial_gaussian_renders）",
    )
    ap.add_argument(
        "--resolution",
        type=int,
        default=None,
        help="与原训练一致的 --resolution；默认从 cfg_args 读取",
    )
    ap.add_argument("--white_background", action="store_true", help="白底（沿用 cfg_args 默认值亦可）")
    ap.add_argument(
        "--no_sar_fast_mode",
        action="store_true",
        help="管道 sar_fast_mode=False（走完整 SAR 光栅分支，较慢）",
    )
    args = ap.parse_args()
    mp = os.path.abspath(args.model_path)

    ply_path = args.ply or os.path.join(mp, "input.ply")
    if not os.path.isfile(ply_path):
        raise FileNotFoundError(f"未找到初始点云: {ply_path}")
    cameras_json_path = os.path.join(mp, "cameras.json")
    if not os.path.isfile(cameras_json_path):
        raise FileNotFoundError(f"未找到 {cameras_json_path}")

    safe_state(False)
    cfg = load_training_cfg(mp)
    if args.resolution is not None:
        cfg.resolution = args.resolution
    if args.white_background:
        cfg.white_background = True

    scene_info = load_scene_info(cfg)
    lookup = build_caminfo_lookup(scene_info)

    with open(cameras_json_path, encoding="utf-8") as jf:
        json_cameras = json.load(jf)

    ordered_names = cameras_json_ordered_paths(mp)
    ordered_infos = []
    for jcam in json_cameras:
        iname = str(jcam["img_name"])
        if iname not in lookup:
            base = os.path.basename(iname)
            if base in lookup:
                iname = base
                jcam = dict(jcam)
                jcam["img_name"] = iname
            else:
                raise KeyError(
                    f"cameras.json 中的 '{jcam['img_name']}' 在数据集的 SceneInfo 中找不到。\n"
                    f"请检查文件名是否与 {cfg.source_path} 下图像一致。"
                )
        ci = lookup[iname]
        R, T = json_entry_to_gs_rt(jcam)
        w = int(jcam["width"])
        h = int(jcam["height"])
        FoVx = float(focal2fov(float(jcam["fx"]), w))
        FoVy = float(focal2fov(float(jcam["fy"]), h))
        ordered_infos.append(
            ci._replace(
                uid=int(jcam.get("id", ci.uid)),
                R=R.astype(np.float32),
                T=T.astype(np.float32),
                FovX=FoVx,
                FovY=FoVy,
                width=w,
                height=h,
            )
        )

    train_norm_cams = list(scene_info.train_cameras)
    if len(train_norm_cams) == 0:
        train_norm_cams = list(scene_info.test_cameras)
    if len(train_norm_cams) == 0:
        raise RuntimeError("SceneInfo 中 train/test 相机列表均为空")
    extent = float(getNerfppNorm(train_norm_cams)["radius"])

    pcd = load_initial_pointcloud(ply_path)
    sh_deg = int(getattr(cfg, "sh_degree", 3))
    gaussians = GaussianModel(sh_deg)
    gaussians.create_from_pcd(pcd, ordered_infos, spatial_lr_scale=extent)

    # 提升 SH 阶数以匹配模型容量（与训练中逐步 oneupSHdegree 的长期效果不完全相同，但能渲出 REST=0）
    gaussians.active_sh_degree = min(gaussians.max_sh_degree, sh_deg)

    try:
        from diff_gaussian_rasterization import SparseGaussianAdam

        separate_sh = True
        _ = SparseGaussianAdam  # noqa: F841
    except Exception:
        separate_sh = False

    pipe = merge_pipe(cfg, force_sar_fast=False if args.no_sar_fast_mode else None, force_sar_sig3dgs=None)
    bg_color = torch.tensor([1, 1, 1], dtype=torch.float32, device="cuda")
    if not getattr(cfg, "white_background", False) and not args.white_background:
        bg_color[:] = 0.0

    out_root = os.path.abspath(args.out or os.path.join(mp, "initial_gaussian_renders"))
    os.makedirs(out_root, exist_ok=True)
    renders_dir = os.path.join(out_root, "renders")
    gt_dir = os.path.join(out_root, "gt")
    os.makedirs(renders_dir, exist_ok=True)
    os.makedirs(gt_dir, exist_ok=True)

    load_args = Namespace(
        resolution=getattr(cfg, "resolution", -1),
        data_device=getattr(cfg, "data_device", "cuda"),
        train_test_exp=getattr(cfg, "train_test_exp", False),
    )
    iso = getattr(scene_info, "is_nerf_synthetic", False)

    print(f"[init_render] 输出目录: {out_root}")
    print(f"[init_render] SAR 管线 sar_fast_mode={pipe.sar_fast_mode}")
    print(f"[init_render] 共 {len(ordered_infos)} 个视角，ordered 与 cameras.json 一致")

    with torch.no_grad():
        for i, ci in enumerate(tqdm(ordered_infos, desc="initial Gaussian render")):
            cam = loadCam(load_args, i, ci, 1.0, iso, is_test_dataset=False)
            sar_on = getattr(cam, "use_sar_rendering", False)
            rend = render(
                cam,
                gaussians,
                pipe,
                bg_color,
                separate_sh=separate_sh,
                override_color=None,
                use_trained_exp=False,
                sar_mode=sar_on,
            )["render"]
            stem = Path(str(ci.image_name)).stem + ".png"
            torchvision.utils.save_image(torch.clamp(rend, 0, 1), os.path.join(renders_dir, stem))
            torchvision.utils.save_image(torch.clamp(cam.original_image[:3], 0, 1), os.path.join(gt_dir, stem))

    with open(os.path.join(out_root, "manifest.json"), "w", encoding="utf-8") as wf:
        json.dump(
            {
                "model_path": mp,
                "ply": os.path.abspath(ply_path),
                "cameras_json": cameras_json_path,
                "resolution": getattr(load_args, "resolution", None),
                "sar_fast_mode": bool(pipe.sar_fast_mode),
                "images": ordered_names,
            },
            wf,
            indent=2,
            ensure_ascii=False,
        )
    print(f"[init_render] 完成。渲染: {renders_dir} ，GT 拷贝: {gt_dir}")


if __name__ == "__main__":
    main()
