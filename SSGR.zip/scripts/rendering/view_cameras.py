#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
查看高斯泼溅模型的相机信息
用法: python view_cameras.py <模型路径>
例如: python view_cameras.py ./output/sar_reconstruction1
"""

import json
import os
import sys

def view_cameras(model_path):
    """查看模型中的相机信息"""
    
    # 相机文件路径
    camera_file = os.path.join(model_path, "cameras.json")
    
    if not os.path.exists(camera_file):
        print(f"❌ 错误: 找不到相机文件: {camera_file}")
        print(f"   请确保模型路径正确，并且已经完成训练")
        return
    
    # 读取相机数据
    try:
        with open(camera_file, 'r', encoding='utf-8') as f:
            cameras = json.load(f)
    except Exception as e:
        print(f"❌ 错误: 无法读取相机文件: {e}")
        return
    
    if len(cameras) == 0:
        print("⚠️ 警告: 相机列表为空")
        return
    
    # 显示默认相机（第一个相机）的详细信息
    print("=" * 70)
    print("默认相机信息（ID=0）")
    print("=" * 70)
    cam = cameras[0]
    print(f"图像名称: {cam['img_name']}")
    print(f"图像尺寸: {cam['width']} x {cam['height']}")
    print(f"相机位置: [{cam['position'][0]:.4f}, {cam['position'][1]:.4f}, {cam['position'][2]:.4f}]")
    print(f"焦距: fx={cam['fx']:.2f}, fy={cam['fy']:.2f}")
    print(f"\n旋转矩阵:")
    for i, row in enumerate(cam['rotation']):
        print(f"  [{row[0]:10.6f}, {row[1]:10.6f}, {row[2]:10.6f}]")
    
    # 显示所有相机列表
    print("\n" + "=" * 70)
    print(f"所有相机列表 (共 {len(cameras)} 个)")
    print("=" * 70)
    print(f"{'ID':<4} {'图像名称':<25} {'位置 (x, y, z)':<35} {'焦距':<10}")
    print("-" * 70)
    
    for i, cam in enumerate(cameras):
        pos_str = f"[{cam['position'][0]:7.2f}, {cam['position'][1]:7.2f}, {cam['position'][2]:7.2f}]"
        focal_str = f"fx={cam['fx']:.1f}, fy={cam['fy']:.1f}"
        print(f"{i:<4} {cam['img_name']:<25} {pos_str:<35} {focal_str:<10}")
    
    # 统计信息
    print("\n" + "=" * 70)
    print("统计信息")
    print("=" * 70)
    
    # 计算位置范围
    positions = [cam['position'] for cam in cameras]
    x_coords = [p[0] for p in positions]
    y_coords = [p[1] for p in positions]
    z_coords = [p[2] for p in positions]
    
    print(f"位置范围:")
    print(f"  X: [{min(x_coords):.2f}, {max(x_coords):.2f}]")
    print(f"  Y: [{min(y_coords):.2f}, {max(y_coords):.2f}]")
    print(f"  Z: [{min(z_coords):.2f}, {max(z_coords):.2f}]")
    
    # 计算平均位置
    avg_x = sum(x_coords) / len(x_coords)
    avg_y = sum(y_coords) / len(y_coords)
    avg_z = sum(z_coords) / len(z_coords)
    print(f"平均位置: [{avg_x:.2f}, {avg_y:.2f}, {avg_z:.2f}]")
    
    # 焦距信息
    fx_values = [cam['fx'] for cam in cameras]
    fy_values = [cam['fy'] for cam in cameras]
    print(f"\n焦距信息:")
    print(f"  fx: 范围 [{min(fx_values):.2f}, {max(fx_values):.2f}], 平均 {sum(fx_values)/len(fx_values):.2f}")
    print(f"  fy: 范围 [{min(fy_values):.2f}, {max(fy_values):.2f}], 平均 {sum(fy_values)/len(fy_values):.2f}")
    
    print("\n" + "=" * 70)
    print("提示: 在SIBR查看器中，输入相机ID并点击 'SnapTo' 可以跳转到该相机")
    print("=" * 70)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python view_cameras.py <模型路径>")
        print("例如: python view_cameras.py ./output/sar_reconstruction1")
        sys.exit(1)
    
    model_path = sys.argv[1]
    if not os.path.isdir(model_path):
        print(f"❌ 错误: 路径不存在或不是目录: {model_path}")
        sys.exit(1)
    
    view_cameras(model_path)

