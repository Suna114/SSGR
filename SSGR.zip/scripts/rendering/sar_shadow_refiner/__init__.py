"""Helpers for SAR azimuth-shadow refinement."""

