from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Callable


def angle_dist_deg(a: float, b: float) -> float:
    d = abs(float(a) - float(b)) % 360.0
    return min(d, 360.0 - d)


def azimuth_prefix(path: Path) -> str:
    stem = path.stem
    m = re.search(r"(?i)azimuth[_-]?(\d+(?:\.\d+)?)", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    m = re.search(r"(\d+(?:\.\d+)?)$", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    return stem


def image_candidates(path: Path, image_files: Callable[[Path], list[Path]], parse_azimuth: Callable[[Path], float]) -> list[dict]:
    return [{"path": p, "azimuth": parse_azimuth(p), "prefix": azimuth_prefix(p)} for p in image_files(path)]


def nearest_candidate(cands: list[dict], azimuth: float) -> dict:
    if not cands:
        raise RuntimeError("No azimuth candidates")
    return min(cands, key=lambda c: (angle_dist_deg(float(c["azimuth"]), azimuth), c["path"].name))


def bracketing_candidates(cands: list[dict], azimuth: float) -> tuple[dict, dict, float, float]:
    ordered = sorted(cands, key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    if not ordered:
        raise RuntimeError("No GT candidates")
    if len(ordered) == 1:
        return ordered[0], ordered[0], 1.0, 0.0
    target = float(azimuth) % 360.0
    exact = [c for c in ordered if angle_dist_deg(float(c["azimuth"]), target) <= 1e-6]
    if exact:
        return exact[0], exact[0], 1.0, 0.0
    back = [((target - float(c["azimuth"])) % 360.0, c) for c in ordered]
    fwd = [((float(c["azimuth"]) - target) % 360.0, c) for c in ordered]
    prev_gap, prev = min((x for x in back if x[0] > 1e-6), key=lambda x: (x[0], x[1]["path"].name))
    next_gap, nxt = min((x for x in fwd if x[0] > 1e-6), key=lambda x: (x[0], x[1]["path"].name))
    total = max(prev_gap + next_gap, 1e-6)
    return prev, nxt, next_gap / total, prev_gap / total


def select_training_pairs(target_dir: Path, gt_dir: Path, args, image_files: Callable[[Path], list[Path]], parse_azimuth: Callable[[Path], float]) -> list[dict]:
    targets = sorted(image_candidates(target_dir, image_files, parse_azimuth), key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    gts = image_candidates(gt_dir, image_files, parse_azimuth)
    if not targets or not gts:
        raise RuntimeError(f"No training images found: {target_dir} vs {gt_dir}")
    gt_by_prefix: dict[str, list[dict]] = {}
    for g in gts:
        gt_by_prefix.setdefault(g["prefix"], []).append(g)
    if not bool(getattr(args, "train_use_all_targets", False)):
        step = max(float(getattr(args, "train_azimuth_step", 10.0) or 10.0), 1e-6)
        slots = {round((i * step) % 360.0, 6) for i in range(int(math.ceil(360.0 / step)))}
        targets = [nearest_candidate(targets, s) for s in sorted(slots)]
    out = []
    for t in targets:
        az = float(t["azimuth"]) % 360.0
        pool = gt_by_prefix.get(t["prefix"], gts)
        lo, hi, wlo, whi = bracketing_candidates(pool, az)
        out.append({"target": t["path"], "azimuth": az, "lo": lo, "hi": hi, "wlo": wlo, "whi": whi})
    return out


def write_training_pair_report(pairs: list[dict], output_dir: Path, filename: str = "shadow_train_azimuth_pairs.txt") -> Path:
    path = output_dir / filename
    lines = ["target\tazimuth\tgt_lo\tlo_az\tlo_w\tgt_hi\thi_az\thi_w\ttarget_path\tgt_lo_path\tgt_hi_path"]
    for p in pairs:
        lo = p["lo"]
        hi = p["hi"]
        lines.append(
            f"{Path(p['target']).name}\t{float(p['azimuth']):.3f}\t"
            f"{Path(lo['path']).name}\t{float(lo['azimuth']):.3f}\t{float(p['wlo']):.6f}\t"
            f"{Path(hi['path']).name}\t{float(hi['azimuth']):.3f}\t{float(p['whi']):.6f}\t"
            f"{Path(p['target']).resolve()}\t{Path(lo['path']).resolve()}\t{Path(hi['path']).resolve()}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
