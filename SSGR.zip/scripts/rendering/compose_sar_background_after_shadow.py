#!/usr/bin/env python3
"""Compose empirical SAR background after target/shadow refinement."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import torch
import torchvision
from tqdm import tqdm

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from scripts.rendering.learn_sar_image_refiner import (  # noqa: E402
    _blur01,
    _dilate01_batch,
    _force_grayscale_chw,
    _image_files,
    _load_image,
    _load_style_refs,
    _nearest_style_ref,
    _parse_azimuth,
    _resize_chw,
)
from scripts.rendering.learn_sar_target_layover_refiner_clean import _make_empirical_background  # noqa: E402


def _angle_dist(a: float, b: float) -> float:
    d = abs(float(a) - float(b)) % 360.0
    return min(d, 360.0 - d)


def _candidates(path: Path) -> list[dict]:
    return [{"path": p, "azimuth": _parse_azimuth(p)} for p in _image_files(path)]


def _nearest(cands: list[dict], az: float) -> dict:
    if not cands:
        raise RuntimeError("No image candidates")
    return min(cands, key=lambda c: (_angle_dist(float(c["azimuth"]), az), c["path"].name))


def _load_shadow_alpha(map_dir: Path, stem: str, azimuth: float, size_hw: tuple[int, int], args) -> torch.Tensor:
    source = str(getattr(args, "shadow_alpha_source", "opacity") or "opacity").lower().strip()
    if source == "max":
        vals = []
        for suffix in ["azimuth_shadow_opacity", "compose_alpha"]:
            direct = map_dir / f"{stem}_{suffix}.png"
            if direct.is_file():
                vals.append(_resize_chw(_load_image(direct, args), size_hw).mean(dim=0).clamp(0.0, 1.0))
        if vals:
            return torch.stack(vals, dim=0).max(dim=0).values.clamp(0.0, 1.0)
    if source == "compose_alpha":
        suffixes = ["compose_alpha", "azimuth_shadow_opacity"]
    else:
        suffixes = ["azimuth_shadow_opacity", "compose_alpha"]
    for suffix in suffixes:
        direct = map_dir / f"{stem}_{suffix}.png"
        if direct.is_file():
            return _resize_chw(_load_image(direct, args), size_hw).mean(dim=0).clamp(0.0, 1.0)
    maps = []
    for suffix in suffixes:
        maps.extend(map_dir.glob(f"*_{suffix}.png"))
    if not maps:
        return torch.zeros(size_hw, dtype=torch.float32)
    nearest = min(maps, key=lambda p: (_angle_dist(_parse_azimuth(p), azimuth), p.name))
    return _resize_chw(_load_image(nearest, args), size_hw).mean(dim=0).clamp(0.0, 1.0)


def _parse_rgb_triplet(text: str | None, default: tuple[float, float, float]) -> tuple[float, float, float]:
    if text is None or not str(text).strip():
        return default
    parts = [p for p in re.split(r"[\s,;]+", str(text).strip()) if p]
    if len(parts) != 3:
        raise ValueError(f"Expected RGB triplet such as '1.0,0.85,0.05', got: {text!r}")
    vals = tuple(min(max(float(p), 0.0), 1.0) for p in parts)
    return vals  # type: ignore[return-value]


def _load_rgb_image(path: Path) -> torch.Tensor:
    class _Args:
        grayscale_sar = False

    return _load_image(path, _Args())


def _carrier_replace_mask(rgb: torch.Tensor, args) -> torch.Tensor:
    if not bool(getattr(args, "carrier_replace_enabled", False)):
        return torch.zeros(rgb.shape[-2:], dtype=rgb.dtype, device=rgb.device)
    if rgb.shape[0] == 1:
        return torch.zeros(rgb.shape[-2:], dtype=rgb.dtype, device=rgb.device)
    color = _parse_rgb_triplet(getattr(args, "carrier_replace_color", None), (1.0, 0.85, 0.05))
    ref = torch.tensor(color, dtype=rgb.dtype, device=rgb.device).view(3, 1, 1)
    dist = (rgb[:3].clamp(0.0, 1.0) - ref).pow(2).sum(dim=0).sqrt()
    tol = max(float(getattr(args, "carrier_replace_tolerance", 0.18) or 0.0), 0.0)
    mask = (dist <= tol).float()
    dilate = int(getattr(args, "carrier_replace_dilate", 1) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    blur = int(getattr(args, "carrier_replace_blur", 1) or 0)
    if blur > 0:
        mask = torch.maximum(mask, _blur01(mask, blur)).clamp(0.0, 1.0)
    return mask.clamp(0.0, 1.0)


def _target_mask(target: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    threshold = max(float(getattr(args, "target_mask_threshold", 0.02) or 0.0), 0.0)
    mask = (gray > threshold).float()
    dilate = int(getattr(args, "target_mask_dilate", 1) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    blur = int(getattr(args, "target_mask_blur", 1) or 0)
    if blur > 0:
        mask = torch.maximum(mask, _blur01(mask, blur)).clamp(0.0, 1.0)
    return mask.clamp(0.0, 1.0)


def _keep_alpha(target_mask: torch.Tensor, shadow_alpha: torch.Tensor, args) -> torch.Tensor:
    shadow_threshold = max(float(getattr(args, "shadow_alpha_threshold", 0.20) or 0.0), 0.0)
    shadow = torch.where(shadow_alpha >= shadow_threshold, shadow_alpha, torch.zeros_like(shadow_alpha))
    keep = torch.maximum(target_mask, shadow).clamp(0.0, 1.0)
    dilate = int(getattr(args, "union_mask_dilate", 2) or 0)
    if dilate > 0:
        hard = torch.maximum(target_mask, (shadow >= shadow_threshold).float()).clamp(0.0, 1.0)
        keep = torch.maximum(keep, _dilate01_batch(hard[None], dilate)[0]).clamp(0.0, 1.0)
    blur = int(getattr(args, "union_mask_blur", 4) or 0)
    if blur > 0:
        keep = torch.maximum(keep, _blur01(keep, blur)).clamp(0.0, 1.0)
    gamma = max(float(getattr(args, "union_mask_gamma", 1.0) or 1.0), 0.05)
    return keep.clamp(0.0, 1.0).pow(gamma)


def main() -> int:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--shadow_render_dir", type=Path, required=True)
    parser.add_argument("--target_mask_dir", type=Path, required=True)
    parser.add_argument("--shadow_map_dir", type=Path, required=True)
    parser.add_argument("--background_reference_dir", type=Path, required=True)
    parser.add_argument("--output_dir", type=Path, required=True)
    parser.add_argument("--map_output_dir", type=Path, default=None)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--grayscale_sar", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--target_mask_threshold", type=float, default=0.02)
    parser.add_argument("--target_mask_dilate", type=int, default=1)
    parser.add_argument("--target_mask_blur", type=int, default=1)
    parser.add_argument("--shadow_alpha_source", choices=["opacity", "compose_alpha", "max"], default="opacity")
    parser.add_argument("--shadow_alpha_threshold", type=float, default=0.20)
    parser.add_argument("--carrier_replace_enabled", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--carrier_replace_color", type=str, default="1.0,0.85,0.05")
    parser.add_argument("--carrier_replace_tolerance", type=float, default=0.18)
    parser.add_argument("--carrier_replace_dilate", type=int, default=1)
    parser.add_argument("--carrier_replace_blur", type=int, default=1)
    parser.add_argument("--union_mask_dilate", type=int, default=2)
    parser.add_argument("--union_mask_blur", type=int, default=4)
    parser.add_argument("--union_mask_gamma", type=float, default=1.0)
    parser.add_argument("--empirical_background_strength", type=float, default=1.0)
    parser.add_argument("--empirical_background_mode", choices=["patch", "reference", "pixel"], default="patch")
    parser.add_argument("--empirical_background_patch_size", type=int, default=24)
    parser.add_argument("--empirical_background_patch_overlap", type=int, default=6)
    parser.add_argument("--empirical_background_patch_smooth", type=int, default=1)
    parser.add_argument("--empirical_background_patch_smooth_mix", type=float, default=0.30)
    parser.add_argument("--empirical_background_patch_fallback_weight", type=float, default=1.0)
    parser.add_argument("--empirical_background_patch_min_valid", type=float, default=0.70)
    parser.add_argument("--empirical_background_clean_reference", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--empirical_background_fallback_blur", type=int, default=9)
    parser.add_argument("--empirical_background_reference_exclude_dilate", type=int, default=24)
    parser.add_argument("--empirical_background_scale", type=float, default=1.0)
    parser.add_argument("--empirical_background_bias", type=float, default=0.0)
    parser.add_argument("--noise_seed", type=int, default=1234)
    parser.add_argument("--save_maps", action=argparse.BooleanOptionalAction, default=False)
    args = parser.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() or str(args.device) == "cpu" else "cpu")
    args.background_reference_dir = str(args.background_reference_dir)
    args.train_gt_dir = str(args.background_reference_dir)
    refs = _load_style_refs(args, device)
    targets = _candidates(args.target_mask_dir)
    if not refs:
        raise RuntimeError(f"No background references found: {args.background_reference_dir}")
    if not targets:
        raise RuntimeError(f"No target masks found: {args.target_mask_dir}")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    map_dir = args.map_output_dir or (args.output_dir.parent / "maps")
    if bool(args.save_maps):
        map_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    for path in tqdm(_image_files(args.shadow_render_dir), desc="compose final background", unit="img"):
        az = _parse_azimuth(path)
        shadow_render = _load_image(path, args).to(device)
        shadow_rgb = _load_rgb_image(path).to(device)
        size_hw = tuple(shadow_render.shape[-2:])
        titem = _nearest(targets, az)
        target = _resize_chw(_load_image(titem["path"], args).to(device), size_hw)
        target_alpha = _target_mask(target, args).to(device)
        shadow_alpha = _load_shadow_alpha(args.shadow_map_dir, path.stem, az, size_hw, args).to(device)
        keep = _keep_alpha(target_alpha, shadow_alpha, args)
        carrier_replace = _carrier_replace_mask(_resize_chw(shadow_rgb, size_hw), args).to(device)
        keep = (keep * (1.0 - carrier_replace)).clamp(0.0, 1.0)
        style_item = _nearest_style_ref(refs, az)
        style_ref = style_item[1] if style_item is not None else None
        bg = _make_empirical_background(shadow_render, keep, style_ref, az, args)
        if bg is None:
            bg = shadow_render
        strength = min(max(float(getattr(args, "empirical_background_strength", 1.0) or 0.0), 0.0), 1.0)
        bg_layer = (shadow_render * (1.0 - strength) + bg * strength).clamp(0.0, 1.0)
        out = (shadow_render * keep.unsqueeze(0) + bg_layer * (1.0 - keep).unsqueeze(0)).clamp(0.0, 1.0)
        out = _force_grayscale_chw(out, args)
        torchvision.utils.save_image(out, str(args.output_dir / path.name))
        if bool(args.save_maps):
            stem = path.stem
            torchvision.utils.save_image(target_alpha[None].clamp(0.0, 1.0), str(map_dir / f"{stem}_final_target_mask.png"))
            torchvision.utils.save_image(shadow_alpha[None].clamp(0.0, 1.0), str(map_dir / f"{stem}_final_shadow_alpha.png"))
            torchvision.utils.save_image(carrier_replace[None].clamp(0.0, 1.0), str(map_dir / f"{stem}_final_carrier_replace_mask.png"))
            torchvision.utils.save_image(keep[None].clamp(0.0, 1.0), str(map_dir / f"{stem}_final_keep_alpha.png"))
            torchvision.utils.save_image(bg.clamp(0.0, 1.0), str(map_dir / f"{stem}_final_empirical_background.png"))
        count += 1
    print(f"[background after shadow] composed {count} images -> {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
