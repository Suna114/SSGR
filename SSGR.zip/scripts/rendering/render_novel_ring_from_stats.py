#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
仅根据「当前训练相机位姿」统计水平环半径 r_xz 与高度 Y，在完整方位角上生成新视角。
不使用训练帧间插值（适用于训练相机只占一段圆弧、colmap_track 无意义的情形）。

与 render_novel_sar_views.py 中 novel_pose_mode=colmap_ring 的数学一致，但本脚本：
  - 只走「统计环」这一条路径，无 geom / colmap_track；
  - 支持 median / mean 统计；
  - 可选打印训练相机在水平面上的方位角覆盖范围。

用法示例：
    python render_novel_ring_from_stats.py -m ./output/5 --iteration 50000 \\
        --output_dir ./output/5/novel_ring_stats

    # 使用均值半径/高度；只渲一个俯角 15°；方位每 2° 一张
    python render_novel_ring_from_stats.py -m ./output/5 --iteration 50000 \\
        --ring_stat mean --depression_angles 15 --azimuth_step 2
"""

from __future__ import annotations

import os
import sys
from argparse import ArgumentParser
from pathlib import Path

import numpy as np
import torch
import torchvision
from tqdm import tqdm

from arguments import ModelParams, PipelineParams, get_combined_args
from gaussian_renderer import render
from scene import GaussianModel, Scene
from utils.general_utils import safe_state

try:
    from diff_gaussian_rasterization import SparseGaussianAdam

    SPARSE_ADAM_AVAILABLE = True
except Exception:
    SPARSE_ADAM_AVAILABLE = False

from render_novel_sar_views import (
    SAR_GEOMETRY_AVAILABLE,
    create_novel_camera_colmap_ring,
    _get_sar_params_from_camera,
)


def estimate_ring_params_from_train_cameras(
    train_cameras, stat: str = "median"
) -> tuple[float, float, np.ndarray]:
    """
    从训练相机世界中心统计水平半径 sqrt(x^2+z^2) 与 Y（COLMAP Y 向下，目标上方时常为负）。

    stat:
      - median: 与中位数环一致，抗离群点
      - mean:   算术平均，弧段较短时可能与视觉「平均距离」更接近
    """
    if not train_cameras:
        raise ValueError("无训练相机")
    centers = []
    for cam in train_cameras:
        c = cam.camera_center.detach().cpu().numpy().reshape(3)
        centers.append(c)
    C = np.stack(centers, axis=0)
    r_xz = np.sqrt(C[:, 0] ** 2 + C[:, 2] ** 2)
    yv = C[:, 1]
    stat = (stat or "median").lower().strip()
    if stat == "mean":
        r_out = float(np.mean(r_xz))
        y_out = float(np.mean(yv))
    elif stat == "median":
        r_out = float(np.median(r_xz))
        y_out = float(np.median(yv))
    else:
        raise ValueError("ring_stat 应为 median 或 mean")
    return r_out, y_out, C


def training_azimuth_coverage_deg(train_cameras) -> tuple[float, float, np.ndarray]:
    """训练相机中心在 XZ 平面上的方位角（度）[0,360)，用于观察是否仅为一段弧。"""
    angles = []
    for cam in train_cameras:
        c = cam.camera_center.detach().cpu().numpy().reshape(3)
        a = float((np.degrees(np.arctan2(c[2], c[0])) + 360.0) % 360.0)
        angles.append(a)
    a = np.array(angles, dtype=np.float64)
    return float(np.min(a)), float(np.max(a)), a


def render_ring_from_stats(
    gaussians,
    pipeline,
    background,
    output_dir: Path,
    depression_angles: list[float],
    azimuth_angles: list[float],
    ref_camera,
    r_xz: float,
    y_world: float,
    use_sar_mode: bool = True,
    azimuth_offset_deg: float = 0.0,
):
    sar_params = _get_sar_params_from_camera(ref_camera)
    if not getattr(ref_camera, "use_sar_rendering", False):
        print(
            "   ℹ️  训练相机未启用 SAR 投影矩阵，新视角将使用与训练相同的透视 FoV 投影。"
        )
    print(
        f"   统计环（无插值）: r_xz={r_xz:.6g}, Y_world={y_world:.6g}；"
        f"在 [0°,360°) 上按方位角列表生成相机。"
    )

    novel_base = Path(output_dir) / "novel_views"
    total = 0
    outer = tqdm(
        [(d, a) for d in depression_angles for a in azimuth_angles],
        desc="统计环渲染",
        unit="img",
    )
    for dep, azi in outer:
        dep_name = (
            f"depression_{int(dep)}"
            if dep == int(dep)
            else f"depression_{str(dep).replace('.', '_')}"
        )
        dep_dir = novel_base / dep_name
        renders_dir = dep_dir / "renders"
        renders_dir.mkdir(parents=True, exist_ok=True)
        fname = f"azimuth_{int(azi):03d}.png"
        out_path = renders_dir / fname
        if out_path.exists():
            total += 1
            continue
        try:
            azi_pose = float(azi) + float(azimuth_offset_deg)
            cam = create_novel_camera_colmap_ring(
                dep,
                float(azi),
                ref_camera,
                sar_params,
                r_xz=float(r_xz),
                y_world=float(y_world),
                uid=total,
                azimuth_pose_deg=azi_pose,
            )
        except Exception as e:
            print(f"⚠️ 创建相机 dep={dep} azi={azi} 失败: {e}")
            continue
        with torch.inference_mode():
            use_sar_rendering = use_sar_mode and getattr(cam, "use_sar_rendering", False)
            render_result = render(
                cam,
                gaussians,
                pipeline,
                background,
                use_trained_exp=False,
                separate_sh=SPARSE_ADAM_AVAILABLE,
                sar_mode=use_sar_rendering,
            )
        rendering = torch.clamp(render_result["render"], 0.0, 1.0)
        torchvision.utils.save_image(rendering, str(out_path))
        total += 1

    print(f"\n✅ 统计环渲染完成，累计写入/跳过 {total} 次，根目录: {novel_base}")
    for dep in depression_angles:
        dep_name = (
            f"depression_{int(dep)}"
            if dep == int(dep)
            else f"depression_{str(dep).replace('.', '_')}"
        )
        dep_dir = novel_base / dep_name / "renders"
        if dep_dir.exists():
            count = len(list(dep_dir.glob("*.png")))
            print(f"   俯视角 {dep}° -> {dep_dir} ({count} 张)")


def main():
    parser = ArgumentParser(
        description="从训练相机统计 r_xz/Y，完整方位角圆轨迹渲染（无插值）"
    )
    model = ModelParams(parser, sentinel=True)
    pipeline = PipelineParams(parser)
    parser.add_argument("--iteration", type=int, default=-1, help="加载的迭代（-1=最新）")
    parser.add_argument(
        "--output_dir",
        type=str,
        default=None,
        help="输出根目录（默认: model_path/novel_ring_from_stats）",
    )
    parser.add_argument(
        "--depression_angles",
        type=str,
        default="15",
        help="俯视角列表（度），空格分隔；多俯角时共用同一统计环（与 render_novel_sar_views 的 colmap_ring 行为一致）",
    )
    parser.add_argument("--azimuth_start", type=int, default=0, help="方位角起始（度，含）")
    parser.add_argument(
        "--azimuth_end",
        type=int,
        default=360,
        help="方位角结束（度，不含），range(start, end, step)。默认 360 即 0..359",
    )
    parser.add_argument("--azimuth_step", type=int, default=1, help="方位角步长（度）")
    parser.add_argument(
        "--ring_stat",
        type=str,
        default="median",
        choices=["median", "mean"],
        help="水平半径与 Y 的统计量：median（默认）或 mean",
    )
    parser.add_argument(
        "--override_r_xz",
        type=float,
        default=None,
        help="手动覆盖统计得到的水平半径 sqrt(x^2+z^2)",
    )
    parser.add_argument(
        "--override_y",
        type=float,
        default=None,
        help="手动覆盖世界坐标 Y（COLMAP Y 向下，相机在目标上方时多为负）",
    )
    parser.add_argument(
        "--azimuth_offset_deg",
        type=float,
        default=0.0,
        help="目标方位角 += offset（度），用于与数据集方位零位对齐",
    )
    parser.add_argument(
        "--no_arc_report",
        action="store_true",
        default=False,
        help="不打印训练相机水平方位角 min/max（默认会打印，便于确认是否仅为一段弧）",
    )
    parser.add_argument("--quiet", action="store_true")

    args = get_combined_args(parser)
    # cfg_args 与命令行合并后，可能缺少本脚本新增字段（旧训练目录保存的配置更短）
    _ring_script_defaults = {
        "iteration": -1,
        "output_dir": None,
        "depression_angles": "15",
        "azimuth_start": 0,
        "azimuth_end": 360,
        "azimuth_step": 1,
        "ring_stat": "median",
        "override_r_xz": None,
        "override_y": None,
        "azimuth_offset_deg": 0.0,
        "no_arc_report": False,
        "quiet": False,
    }
    for _k, _v in _ring_script_defaults.items():
        if not hasattr(args, _k):
            setattr(args, _k, _v)

    safe_state(getattr(args, "quiet", False))

    model_params = model.extract(args)
    pipeline_params = pipeline.extract(args)

    use_sar_mode = getattr(model_params, "sar_mode", False)
    if not use_sar_mode:
        print("❌ 模型未启用 SAR 模式（sar_mode）。请使用 SAR 训练得到的 output 目录。")
        sys.exit(1)
    if not SAR_GEOMETRY_AVAILABLE:
        print("❌ 无法导入 sar_geometry（create_novel_camera_colmap_ring 需要）")
        sys.exit(1)

    out = args.output_dir
    if out is None:
        out = os.path.join(model_params.model_path, "novel_ring_from_stats")
    output_dir = Path(out)

    dep_list = [float(x.strip()) for x in args.depression_angles.split() if x.strip()]
    azimuth_angles = list(
        range(int(args.azimuth_start), int(args.azimuth_end), int(args.azimuth_step))
    )
    if len(azimuth_angles) == 0:
        print("❌ 方位角列表为空")
        sys.exit(1)

    print("=" * 80)
    print("SAR 新视角：统计环（无插值）")
    print("=" * 80)
    print(f"模型: {model_params.model_path}")
    print(f"迭代: {args.iteration if args.iteration >= 0 else '最新'}")
    print(f"ring_stat: {args.ring_stat}")
    print(f"俯视角: {dep_list}")
    print(
        f"方位角: {azimuth_angles[0]}° .. {azimuth_angles[-1]}° "
        f"(步长 {args.azimuth_step}°), 共 {len(azimuth_angles)} 张/俯角"
    )
    print(f"总计约 {len(dep_list) * len(azimuth_angles)} 张 -> {output_dir / 'novel_views'}")
    print("=" * 80)

    gaussians = GaussianModel(model_params.sh_degree)
    scene = Scene(model_params, gaussians, load_iteration=args.iteration, shuffle=False)

    bg_color = [1, 1, 1] if model_params.white_background else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device="cuda")

    train_cameras_list = list(scene.getTrainCameras() or [])
    ref_cameras = train_cameras_list or scene.getTestCameras()
    ref_camera = ref_cameras[0] if ref_cameras else None
    if ref_camera is None:
        print("❌ 场景无训练/测试相机")
        sys.exit(1)
    if not train_cameras_list:
        print("❌ 无训练相机，无法统计环参数")
        sys.exit(1)

    r_xz, y_med, C_all = estimate_ring_params_from_train_cameras(
        train_cameras_list, stat=args.ring_stat
    )
    if args.override_r_xz is not None:
        r_xz = float(args.override_r_xz)
        print(f"   覆盖: r_xz = {r_xz:.6g}")
    if args.override_y is not None:
        y_med = float(args.override_y)
        print(f"   覆盖: Y_world = {y_med:.6g}")

    d_mean = float(np.mean(np.linalg.norm(C_all, axis=1)))
    print(
        f"   从 {len(train_cameras_list)} 个训练相机估计: "
        f"{args.ring_stat}(r_xz)={r_xz:.6g}, {args.ring_stat}(Y)={y_med:.6g}, mean||C||={d_mean:.6g}"
    )

    if not args.no_arc_report:
        amin, amax, _ = training_azimuth_coverage_deg(train_cameras_list)
        print(
            f"   训练相机水平方位角 [0,360): min={amin:.1f}°, max={amax:.1f}° "
            f"（仅作覆盖诊断；非全圆时仍用上述 r_xz、Y 生成完整 360° 圆）"
        )

    render_ring_from_stats(
        gaussians,
        pipeline_params,
        background,
        output_dir,
        depression_angles=dep_list,
        azimuth_angles=[float(a) for a in azimuth_angles],
        ref_camera=ref_camera,
        r_xz=r_xz,
        y_world=y_med,
        use_sar_mode=use_sar_mode,
        azimuth_offset_deg=float(getattr(args, "azimuth_offset_deg", 0.0) or 0.0),
    )


if __name__ == "__main__":
    main()
