#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
相机位姿可视化脚本

此脚本用于可视化SAR相机位姿，包括：
1. 相机位置在3D空间中的分布
2. 相机坐标系（X、Y、Z轴）
3. 相机指向场景中心的方向
4. 比较不同分布模式（水平圆环 vs 球面）
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys
import os
import json

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sar_geometry import compute_sar_camera_pose, DEFAULT_SAR_PARAMS


def plot_camera_coordinate_system(ax, R, t, scale=1000, label=""):
    """
    在3D图中绘制相机坐标系
    
    Args:
        ax: matplotlib 3D轴
        R: 旋转矩阵（从世界到相机）
        t: 平移向量
        scale: 坐标轴长度缩放
        label: 标签
    """
    # 计算相机位置
    camera_position = -R.T @ t
    cx, cy, cz = camera_position.flatten()
    
    # 相机坐标系的三个轴（在世界坐标系中的表示）
    # R.T是从相机到世界的旋转
    x_axis = R.T[:, 0] * scale  # X轴（右，红色）
    y_axis = R.T[:, 1] * scale  # Y轴（下，绿色）
    z_axis = R.T[:, 2] * scale  # Z轴（前，蓝色）
    
    # 绘制坐标轴
    ax.quiver(cx, cy, cz, x_axis[0], x_axis[1], x_axis[2], 
             color='red', arrow_length_ratio=0.2, linewidth=2, alpha=0.7)
    ax.quiver(cx, cy, cz, y_axis[0], y_axis[1], y_axis[2], 
             color='green', arrow_length_ratio=0.2, linewidth=2, alpha=0.7)
    ax.quiver(cx, cy, cz, z_axis[0], z_axis[1], z_axis[2], 
             color='blue', arrow_length_ratio=0.2, linewidth=2, alpha=0.7)
    
    return camera_position


def visualize_single_camera(depression_angle, azimuth_angle, sar_params, save_path=None):
    """
    可视化单个相机的位姿
    
    Args:
        depression_angle: 俯视角（度）
        azimuth_angle: 方位角（度）
        sar_params: SAR参数字典
        save_path: 保存路径（可选）
    """
    # 计算相机位姿
    R, t, K = compute_sar_camera_pose(depression_angle, azimuth_angle, sar_params)
    camera_position = -R.T @ t
    
    # 创建3D图
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # 绘制场景中心
    ax.scatter([0], [0], [0], c='orange', marker='*', s=500, label='场景中心')
    
    # 绘制相机位置
    cx, cy, cz = camera_position.flatten()
    ax.scatter([cx], [cy], [cz], c='purple', marker='o', s=200, label='相机位置')
    
    # 绘制相机坐标系
    plot_camera_coordinate_system(ax, R, t, scale=2000)
    
    # 绘制从相机到场景中心的连线
    ax.plot([cx, 0], [cy, 0], [cz, 0], 'k--', linewidth=1, alpha=0.5, label='视线')
    
    # 设置标题和标签
    distribution_mode = sar_params.get('camera_distribution_mode', 'sphere')
    ax.set_title(f'SAR相机位姿可视化\n'
                f'俯视角={depression_angle}°, 方位角={azimuth_angle}°\n'
                f'分布模式: {distribution_mode}',
                fontsize=14, fontweight='bold')
    ax.set_xlabel('X (m)', fontsize=12)
    ax.set_ylabel('Y (m)', fontsize=12)
    ax.set_zlabel('Z (m)', fontsize=12)
    
    # 添加图例
    ax.legend(loc='upper right', fontsize=10)
    
    # 设置相等的坐标轴比例
    max_range = np.max(np.abs(camera_position)) * 1.2
    ax.set_xlim([-max_range, max_range])
    ax.set_ylim([-max_range, max_range])
    ax.set_zlim([0, max_range * 2])
    
    # 添加网格
    ax.grid(True, alpha=0.3)
    
    # 调整视角
    ax.view_init(elev=20, azim=45)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✅ 图像已保存到: {save_path}")
    
    plt.show()


def visualize_multiple_cameras(depression_angles, azimuth_angles, sar_params, save_path=None):
    """
    可视化多个相机的位姿
    
    Args:
        depression_angles: 俯视角列表（度）
        azimuth_angles: 方位角列表（度）
        sar_params: SAR参数字典
        save_path: 保存路径（可选）
    """
    if len(depression_angles) != len(azimuth_angles):
        raise ValueError("俯视角和方位角列表长度必须相同")
    
    # 创建3D图
    fig = plt.figure(figsize=(16, 12))
    ax = fig.add_subplot(111, projection='3d')
    
    # 绘制场景中心
    ax.scatter([0], [0], [0], c='orange', marker='*', s=500, label='场景中心', zorder=10)
    
    # 存储所有相机位置用于设置坐标轴范围
    camera_positions = []
    
    # 绘制每个相机
    for i, (dep, azi) in enumerate(zip(depression_angles, azimuth_angles)):
        R, t, K = compute_sar_camera_pose(dep, azi, sar_params)
        camera_position = plot_camera_coordinate_system(
            ax, R, t, scale=1500, label=f"相机{i+1}"
        )
        camera_positions.append(camera_position)
        
        # 绘制相机位置
        cx, cy, cz = camera_position.flatten()
        ax.scatter([cx], [cy], [cz], c='purple', marker='o', s=100, alpha=0.6)
        
        # 绘制从相机到场景中心的连线
        ax.plot([cx, 0], [cy, 0], [cz, 0], 'k--', linewidth=0.5, alpha=0.3)
        
        # 添加标签
        ax.text(cx, cy, cz, f"  C{i+1}\n  ({dep}°,{azi}°)", 
               fontsize=8, alpha=0.7)
    
    # 设置标题和标签
    distribution_mode = sar_params.get('camera_distribution_mode', 'sphere')
    ax.set_title(f'SAR相机位姿可视化（{len(depression_angles)}个相机）\n'
                f'分布模式: {distribution_mode}',
                fontsize=16, fontweight='bold')
    ax.set_xlabel('X (m)', fontsize=12)
    ax.set_ylabel('Y (m)', fontsize=12)
    ax.set_zlabel('Z (m)', fontsize=12)
    
    # 添加自定义图例
    from matplotlib.patches import Patch
    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], marker='*', color='w', markerfacecolor='orange', markersize=15, label='场景中心'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor='purple', markersize=10, label='相机位置'),
        Line2D([0], [0], color='red', linewidth=2, label='X轴（右）'),
        Line2D([0], [0], color='green', linewidth=2, label='Y轴（下）'),
        Line2D([0], [0], color='blue', linewidth=2, label='Z轴（前）'),
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=10)
    
    # 设置相等的坐标轴比例
    camera_positions = np.hstack(camera_positions)
    max_range = np.max(np.abs(camera_positions)) * 1.2
    ax.set_xlim([-max_range, max_range])
    ax.set_ylim([-max_range, max_range])
    ax.set_zlim([0, max_range * 1.5])
    
    # 添加网格
    ax.grid(True, alpha=0.3)
    
    # 调整视角
    ax.view_init(elev=20, azim=45)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✅ 图像已保存到: {save_path}")
    
    plt.show()


def compare_distribution_modes(depression_angles, azimuth_angles, sar_params, save_path=None):
    """
    比较水平圆环和球面分布模式
    
    Args:
        depression_angles: 俯视角列表（度）
        azimuth_angles: 方位角列表（度）
        sar_params: SAR参数字典
        save_path: 保存路径（可选）
    """
    # 创建并排的两个3D子图
    fig = plt.figure(figsize=(20, 9))
    
    modes = ['horizontal', 'sphere']
    mode_names = ['水平圆环分布', '球面分布']
    
    for idx, (mode, mode_name) in enumerate(zip(modes, mode_names)):
        ax = fig.add_subplot(1, 2, idx+1, projection='3d')
        
        # 设置当前分布模式
        current_params = sar_params.copy()
        current_params['camera_distribution_mode'] = mode
        
        # 绘制场景中心
        ax.scatter([0], [0], [0], c='orange', marker='*', s=500, zorder=10)
        
        camera_positions = []
        
        # 绘制每个相机
        for i, (dep, azi) in enumerate(zip(depression_angles, azimuth_angles)):
            R, t, K = compute_sar_camera_pose(dep, azi, current_params)
            camera_position = -R.T @ t
            camera_positions.append(camera_position)
            
            # 绘制相机位置
            cx, cy, cz = camera_position.flatten()
            
            # 根据俯视角使用不同颜色
            color = plt.cm.viridis(dep / 45.0)
            ax.scatter([cx], [cy], [cz], c=[color], marker='o', s=150, alpha=0.8)
            
            # 绘制相机坐标系（缩小比例以避免重叠）
            plot_camera_coordinate_system(ax, R, t, scale=800)
            
            # 绘制从相机到场景中心的连线
            ax.plot([cx, 0], [cy, 0], [cz, 0], 'k--', linewidth=0.5, alpha=0.2)
        
        # 设置标题和标签
        ax.set_title(f'{mode_name}\n({len(depression_angles)}个相机)',
                    fontsize=14, fontweight='bold')
        ax.set_xlabel('X (m)', fontsize=11)
        ax.set_ylabel('Y (m)', fontsize=11)
        ax.set_zlabel('Z (m)', fontsize=11)
        
        # 设置相等的坐标轴比例
        camera_positions = np.hstack(camera_positions)
        max_range = np.max(np.abs(camera_positions)) * 1.2
        ax.set_xlim([-max_range, max_range])
        ax.set_ylim([-max_range, max_range])
        ax.set_zlim([0, max_range * 1.5])
        
        # 添加网格
        ax.grid(True, alpha=0.3)
        
        # 调整视角
        ax.view_init(elev=20, azim=45)
    
    # 添加总标题
    fig.suptitle('SAR相机分布模式对比', fontsize=18, fontweight='bold', y=0.98)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✅ 图像已保存到: {save_path}")
    
    plt.show()


def visualize_from_sfm_results(sfm_results_path, max_cameras=None, save_path=None):
    """
    从SfM结果中加载并可视化相机位姿
    
    Args:
        sfm_results_path: SfM结果目录（包含camera_poses.json）
        max_cameras: 最多显示的相机数量
        save_path: 保存路径（可选）
    """
    # 加载相机位姿
    poses_file = os.path.join(sfm_results_path, 'camera_poses.json')
    
    if not os.path.exists(poses_file):
        print(f"❌ 错误: 未找到相机位姿文件 {poses_file}")
        return
    
    with open(poses_file, 'r', encoding='utf-8') as f:
        poses_dict = json.load(f)
    
    print(f"✅ 加载了 {len(poses_dict)} 个相机位姿")
    
    # 限制相机数量
    if max_cameras and len(poses_dict) > max_cameras:
        print(f"⚠️ 只显示前 {max_cameras} 个相机")
        poses_dict = dict(list(poses_dict.items())[:max_cameras])
    
    # 创建3D图
    fig = plt.figure(figsize=(16, 12))
    ax = fig.add_subplot(111, projection='3d')
    
    # 绘制场景中心
    ax.scatter([0], [0], [0], c='orange', marker='*', s=500, label='场景中心', zorder=10)
    
    # 绘制每个相机
    for i, (img_name, pose) in enumerate(poses_dict.items()):
        # 提取位姿
        qw, qx, qy, qz = pose['qw'], pose['qx'], pose['qy'], pose['qz']
        tx, ty, tz = pose['tx'], pose['ty'], pose['tz']
        
        # 从四元数恢复旋转矩阵
        from scipy.spatial.transform import Rotation as Rot
        rotation = Rot.from_quat([qx, qy, qz, qw])
        R_cam_to_world = rotation.as_matrix()
        
        # COLMAP格式中，(tx, ty, tz)是相机在世界坐标系中的位置
        camera_position = np.array([[tx], [ty], [tz]])
        
        # 计算R（从世界到相机）
        R = R_cam_to_world.T
        
        # 计算t
        t = -R @ camera_position
        
        # 绘制相机坐标系
        plot_camera_coordinate_system(ax, R, t, scale=500)
        
        # 绘制相机位置
        ax.scatter([tx], [ty], [tz], c='purple', marker='o', s=50, alpha=0.6)
        
        # 绘制从相机到场景中心的连线
        ax.plot([tx, 0], [ty, 0], [tz, 0], 'k--', linewidth=0.3, alpha=0.2)
        
        # 每10个相机显示一个标签
        if i % 10 == 0:
            ax.text(tx, ty, tz, f"  {img_name[:10]}...", fontsize=6, alpha=0.5)
    
    # 设置标题和标签
    ax.set_title(f'SfM重建相机位姿可视化（{len(poses_dict)}个相机）',
                fontsize=16, fontweight='bold')
    ax.set_xlabel('X (m)', fontsize=12)
    ax.set_ylabel('Y (m)', fontsize=12)
    ax.set_zlabel('Z (m)', fontsize=12)
    
    # 添加图例
    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], marker='*', color='w', markerfacecolor='orange', markersize=15, label='场景中心'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor='purple', markersize=10, label='相机位置'),
        Line2D([0], [0], color='red', linewidth=2, label='X轴（右）'),
        Line2D([0], [0], color='green', linewidth=2, label='Y轴（下）'),
        Line2D([0], [0], color='blue', linewidth=2, label='Z轴（前）'),
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=10)
    
    # 设置坐标轴范围
    all_positions = np.array([[pose['tx'], pose['ty'], pose['tz']] for pose in poses_dict.values()])
    max_range = np.max(np.abs(all_positions)) * 1.2
    ax.set_xlim([-max_range, max_range])
    ax.set_ylim([-max_range, max_range])
    ax.set_zlim([0, max_range * 1.5])
    
    # 添加网格
    ax.grid(True, alpha=0.3)
    
    # 调整视角
    ax.view_init(elev=20, azim=45)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✅ 图像已保存到: {save_path}")
    
    plt.show()


def main():
    """主函数：演示各种可视化功能"""
    
    print("="*70)
    print("SAR相机位姿可视化工具")
    print("="*70)
    
    # 使用默认的SAR参数
    sar_params = DEFAULT_SAR_PARAMS.copy()
    
    # 示例1：可视化单个相机
    print("\n1. 可视化单个相机（俯视角30°，方位角45°）")
    visualize_single_camera(30, 45, sar_params, save_path="camera_pose_single.png")
    
    # 示例2：可视化多个相机（MSTAR典型配置）
    print("\n2. 可视化多个相机（模拟MSTAR数据集）")
    depression_angles = [15, 15, 30, 30, 45, 45]
    azimuth_angles = [0, 90, 180, 270, 45, 225]
    visualize_multiple_cameras(depression_angles, azimuth_angles, sar_params, 
                              save_path="camera_poses_multiple.png")
    
    # 示例3：比较不同分布模式
    print("\n3. 比较水平圆环和球面分布模式")
    depression_angles = [15, 17, 30, 32, 45, 47]
    azimuth_angles = [0, 60, 120, 180, 240, 300]
    compare_distribution_modes(depression_angles, azimuth_angles, sar_params,
                              save_path="camera_poses_comparison.png")
    
    # 示例4：从SfM结果加载并可视化
    print("\n4. 从SfM结果加载相机位姿（如果存在）")
    sfm_results_path = "data/24/sfm_results"
    if os.path.exists(sfm_results_path):
        visualize_from_sfm_results(sfm_results_path, max_cameras=50,
                                  save_path="camera_poses_from_sfm.png")
    else:
        print(f"⚠️ SfM结果目录不存在: {sfm_results_path}")
    
    print("\n✅ 所有可视化完成！")


if __name__ == "__main__":
    # 设置中文字体（可选，如果需要显示中文）
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    
    main()

