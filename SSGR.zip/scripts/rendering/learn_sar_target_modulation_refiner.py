#!/usr/bin/env python3
"""
Learn a SAR refiner from clean 3DGS target renders to paired real SAR images.

The default mode is now image-to-image refinement: the network is conditioned on
the geometry-accurate target render, target masks, azimuth, and noise channels,
then predicts the real SAR-like image directly.  The previous target-local
modulation map behavior is still available with ``--refiner_mode target_modulation``
and is used automatically for old checkpoints.
"""

from __future__ import annotations

import math
import re
import sys
from argparse import ArgumentParser, BooleanOptionalAction, Namespace
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from tqdm import tqdm

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from scripts.rendering.learn_sar_image_refiner import (  # noqa: E402
    _blur01,
    _build_input,
    _dilate01_batch,
    _erode01,
    _force_grayscale_batch,
    _gradient_mag_map,
    _image_files,
    _load_image,
    _load_style_refs,
    _local_std_map,
    _masked_l1,
    _masked_quantile_loss,
    _match_pairs,
    _model_input_channels,
    _nearest_style_ref,
    _parse_azimuth,
    _parse_quantiles,
    _resize_chw,
    _target_mask,
    _to_loss_domain,
)


class TargetConvBlock(nn.Module):
    def __init__(self, cin: int, cout: int, padding_mode: str = "zeros"):
        super().__init__()
        if padding_mode not in {"zeros", "reflect", "replicate", "circular"}:
            raise RuntimeError(f"Unsupported conv padding mode: {padding_mode}")
        self.net = nn.Sequential(
            nn.Conv2d(cin, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
            nn.Conv2d(cout, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
        )

    def forward(self, x):
        return self.net(x)


class LocalFeatureEnhancer(nn.Module):
    """DHFR-style local spatial enhancement with neutral initialization."""

    def __init__(self, channels: int, strength: float = 0.25, padding_mode: str = "zeros"):
        super().__init__()
        hidden = max(8, int(channels) // 4)
        self.strength = float(strength)
        self.mask = nn.Sequential(
            nn.Conv2d(channels, hidden, 3, padding=1, padding_mode=padding_mode),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, 1, 1),
        )
        nn.init.zeros_(self.mask[-1].weight)
        nn.init.zeros_(self.mask[-1].bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        mask = torch.sigmoid(self.mask(x))
        gain = 1.0 + self.strength * (mask - 0.5) * 2.0
        return x * gain


class DynamicHierarchicalFusion(nn.Module):
    """Fuse decoder and skip features with input-adaptive branch weights."""

    def __init__(self, decoder_ch: int, skip_ch: int, padding_mode: str = "zeros"):
        super().__init__()
        self.skip_enhance = LocalFeatureEnhancer(skip_ch, padding_mode=padding_mode)
        hidden = max(8, (int(decoder_ch) + int(skip_ch)) // 8)
        self.global_gate = nn.Sequential(
            nn.Linear(int(decoder_ch) + int(skip_ch), hidden),
            nn.SiLU(inplace=True),
            nn.Linear(hidden, 2),
        )
        nn.init.zeros_(self.global_gate[-1].weight)
        nn.init.zeros_(self.global_gate[-1].bias)

    def forward(self, decoder: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        skip = self.skip_enhance(skip)
        gd = F.adaptive_avg_pool2d(decoder, 1).flatten(1)
        gs = F.adaptive_avg_pool2d(skip, 1).flatten(1)
        weights = torch.softmax(self.global_gate(torch.cat([gd, gs], dim=1)), dim=1)
        decoder = decoder * (2.0 * weights[:, 0].view(-1, 1, 1, 1))
        skip = skip * (2.0 * weights[:, 1].view(-1, 1, 1, 1))
        return torch.cat([decoder, skip], dim=1)


class TargetModulationUNet(nn.Module):
    def __init__(self, in_ch: int, base: int = 32, padding_mode: str = "zeros", out_ch: int = 3):
        super().__init__()
        self.e1 = TargetConvBlock(in_ch, base, padding_mode=padding_mode)
        self.e2 = TargetConvBlock(base, base * 2, padding_mode=padding_mode)
        self.e3 = TargetConvBlock(base * 2, base * 4, padding_mode=padding_mode)
        self.mid = TargetConvBlock(base * 4, base * 4, padding_mode=padding_mode)
        self.fuse2 = DynamicHierarchicalFusion(base * 4, base * 2, padding_mode=padding_mode)
        self.fuse1 = DynamicHierarchicalFusion(base * 2, base, padding_mode=padding_mode)
        self.d2 = TargetConvBlock(base * 6, base * 2, padding_mode=padding_mode)
        self.d1 = TargetConvBlock(base * 3, base, padding_mode=padding_mode)
        self.out = nn.Conv2d(base, int(out_ch), 1)

    def forward(self, x):
        e1 = self.e1(x)
        e2 = self.e2(F.avg_pool2d(e1, 2))
        e3 = self.e3(F.avg_pool2d(e2, 2))
        y = self.mid(e3)
        y = F.interpolate(y, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d2(self.fuse2(y, e2))
        y = F.interpolate(y, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d1(self.fuse1(y, e1))
        return torch.sigmoid(self.out(y))


class PatchDiscriminator(nn.Module):
    def __init__(self, in_ch: int = 4, base: int = 32):
        super().__init__()

        def conv(cin: int, cout: int, stride: int = 2):
            return nn.Sequential(
                nn.utils.spectral_norm(nn.Conv2d(cin, cout, 4, stride=stride, padding=1)),
                nn.LeakyReLU(0.2, inplace=True),
            )

        self.net = nn.Sequential(
            conv(in_ch, base, stride=2),
            conv(base, base * 2, stride=2),
            conv(base * 2, base * 4, stride=2),
            conv(base * 4, base * 4, stride=1),
            nn.utils.spectral_norm(nn.Conv2d(base * 4, 1, 3, padding=1)),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def _refiner_mode(args) -> str:
    mode = str(getattr(args, "refiner_mode", "image") or "image").lower().strip()
    aliases = {
        "modulation": "target_modulation",
        "target": "target_modulation",
        "layover": "target_layover",
        "target-layover": "target_layover",
        "direct": "image",
        "full": "image",
    }
    mode = aliases.get(mode, mode)
    if mode not in {"image", "residual", "target_modulation", "target_layover"}:
        raise RuntimeError(f"Unsupported --refiner_mode: {mode}")
    return mode


def _is_modulation_mode(args) -> bool:
    return _refiner_mode(args) in {"target_modulation", "target_layover"}


def _target_only_refiner(args) -> bool:
    return bool(getattr(args, "target_only_refiner", False))


def _default_output_channels(args) -> int:
    return 4 if _is_modulation_mode(args) else 3


def _is_target_layover_mode(args) -> bool:
    return _refiner_mode(args) == "target_layover"


def _checkpoint_output_channels(ckpt: dict, fallback: int = 3) -> int:
    if "out_ch" in ckpt:
        return int(ckpt["out_ch"])
    model_state = ckpt.get("model", {})
    out_weight = model_state.get("out.weight") if isinstance(model_state, dict) else None
    if isinstance(out_weight, torch.Tensor) and out_weight.dim() >= 1:
        return int(out_weight.shape[0])
    return int(fallback)


def _load_state_dict_compatible(model: nn.Module, state_dict: dict, label: str) -> None:
    try:
        model.load_state_dict(state_dict, strict=True)
        return
    except RuntimeError:
        pass

    current = model.state_dict()
    filtered = {}
    skipped = []
    for key, value in state_dict.items():
        if key in current and tuple(current[key].shape) == tuple(value.shape):
            filtered[key] = value
        elif key in {"out.weight", "out.bias"} and key in current:
            adapted = current[key].clone()
            if value.dim() == adapted.dim():
                n = min(int(value.shape[0]), int(adapted.shape[0]))
                adapted[:n] = value[:n]
                filtered[key] = adapted
            else:
                skipped.append(key)
        else:
            skipped.append(key)
    missing, unexpected = model.load_state_dict(filtered, strict=False)
    print(
        f"[target modulation] compatible load for {label}: "
        f"loaded={len(filtered)}, skipped={len(skipped)}, "
        f"missing={len(missing)}, unexpected={len(unexpected)}"
    )


def _derive_paths(args) -> None:
    model_path = Path(args.model_path) if args.model_path else None
    if model_path is not None:
        args.train_target_dir = args.train_target_dir or str(model_path / "train_renders")
        args.train_gt_dir = args.train_gt_dir or str(model_path / "train_gt")
        args.apply_target_dir = args.apply_target_dir or str(model_path / "novel_target_only" / "target_renders")
        if bool(getattr(args, "apply_only", False)):
            args.output_dir = args.output_dir or str(model_path / "novel_sar_target_sarsim")
            args.checkpoint = args.checkpoint or str(model_path / "sar_target_modulation_refiner_target_sarsim.pth")
        elif bool(getattr(args, "init_checkpoint", None)) and not bool(getattr(args, "background_finetune", False)):
            args.output_dir = args.output_dir or str(model_path / "novel_sar_target_sarsim")
            args.checkpoint = args.checkpoint or str(model_path / "sar_target_modulation_refiner_target_sarsim.pth")
        else:
            args.output_dir = args.output_dir or str(model_path / "novel_sar_target_modulated")
            args.checkpoint = args.checkpoint or str(model_path / "sar_target_modulation_refiner.pth")
        args.background_reference_dir = args.background_reference_dir or args.train_gt_dir
    if not args.checkpoint:
        args.checkpoint = str(Path(args.output_dir or ".") / "sar_target_modulation_refiner.pth")


def _configure_torch_runtime(args, device: torch.device) -> None:
    if device.type != "cuda":
        return
    allow_tf32 = bool(getattr(args, "allow_tf32", True))
    if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
        torch.backends.cuda.matmul.allow_tf32 = allow_tf32
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.allow_tf32 = allow_tf32
        torch.backends.cudnn.benchmark = bool(getattr(args, "cudnn_benchmark", True))
    try:
        torch.set_float32_matmul_precision("high" if allow_tf32 else "highest")
    except Exception:
        pass
    print(
        "[torch runtime] "
        f"device={device}, allow_tf32={allow_tf32}, "
        f"cudnn_benchmark={bool(getattr(args, 'cudnn_benchmark', True))}, "
        f"amp={bool(getattr(args, 'amp', False))}"
    )


def _target_alpha(target: torch.Tensor, hard_mask: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    threshold = float(args.target_alpha_threshold)
    high = float(args.target_alpha_high)
    alpha = ((gray - threshold) / max(high - threshold, 1e-6)).clamp(0.0, 1.0)
    alpha = alpha.pow(max(float(args.target_alpha_gamma), 0.05))
    if bool(args.target_alpha_use_mask_floor):
        alpha = torch.maximum(alpha, hard_mask.float().clamp(0.0, 1.0) * float(args.target_alpha_mask_floor))
    if int(args.target_alpha_dilate) > 0:
        alpha = _dilate01_batch(alpha[None], int(args.target_alpha_dilate))[0]
    elif int(args.target_alpha_dilate) < 0:
        alpha = _erode01(alpha, -int(args.target_alpha_dilate))
    if int(args.target_alpha_blur) > 0:
        alpha = _blur01(alpha, int(args.target_alpha_blur))
    return alpha.clamp(0.0, 1.0)


def _decode_maps(raw: torch.Tensor, args):
    mult = float(args.multiplier_min) + raw[:, 0:1] * (float(args.multiplier_max) - float(args.multiplier_min))
    vis = float(args.visibility_min) + raw[:, 1:2] * (float(args.visibility_max) - float(args.visibility_min))
    dark = raw[:, 2:3].clamp(0.0, 1.0)
    if raw.shape[1] >= 4:
        extinction = raw[:, 3:4].clamp(0.0, 1.0)
    else:
        extinction = torch.zeros_like(dark)
    return mult.clamp(0.0, 4.0), vis.clamp(0.0, 1.0), dark, extinction


def _unit_tensor(x: torch.Tensor) -> torch.Tensor:
    return torch.nan_to_num(x.float(), nan=0.0, posinf=1.0, neginf=0.0).clamp(0.0, 1.0)


def _prob_tensor(x: torch.Tensor, eps: float = 1e-4) -> torch.Tensor:
    return _unit_tensor(x).clamp(eps, 1.0 - eps)


def _nonnegative_tensor(x: torch.Tensor) -> torch.Tensor:
    return torch.nan_to_num(x.float(), nan=0.0, posinf=1.0e4, neginf=0.0).clamp_min(0.0)


def _model_has_nonfinite(model: nn.Module) -> bool:
    return any(not bool(torch.isfinite(p).all().detach().cpu()) for p in model.parameters())


def _grad_has_nonfinite(model: nn.Module) -> bool:
    for p in model.parameters():
        if p.grad is not None and not bool(torch.isfinite(p.grad).all().detach().cpu()):
            return True
    return False


def _spatial_layover_gate(x: torch.Tensor, mask: torch.Tensor, args, name: str) -> torch.Tensor:
    """Remove uniform dark/extinction bias so only spatial structure gates target energy."""
    if not bool(getattr(args, "layover_spatial_only", False)):
        return _unit_tensor(x)
    m = _unit_tensor(mask)
    if m.dim() == 3:
        m = m[:, None]
    x = _unit_tensor(x)
    mode = str(getattr(args, "layover_spatial_baseline", "masked_mean") or "masked_mean").lower().strip()
    if mode == "blur":
        radius = max(1, int(getattr(args, "layover_spatial_blur_radius", 9) or 9))
        k = 2 * radius + 1
        pad = (radius, radius, radius, radius)
        x_pad = F.pad(x, pad, mode="reflect")
        m_pad = F.pad(m, pad, mode="reflect")
        num = F.avg_pool2d(x_pad * m_pad, kernel_size=k, stride=1, padding=0)
        den = F.avg_pool2d(m_pad, kernel_size=k, stride=1, padding=0).clamp_min(1e-4)
        baseline = num / den
    else:
        baseline = (x * m).sum(dim=(2, 3), keepdim=True) / m.sum(dim=(2, 3), keepdim=True).clamp_min(1.0)
    gain = max(float(getattr(args, "layover_spatial_gain", 4.0) or 0.0), 0.0)
    bias = float(getattr(args, "layover_spatial_bias", 0.0) or 0.0)
    gate = ((x - baseline + bias).clamp_min(0.0) * gain).clamp(0.0, 1.0)
    floor = min(max(float(getattr(args, f"{name}_spatial_floor", 0.0) or 0.0), 0.0), 1.0)
    if floor > 0.0:
        gate = torch.maximum(gate, x * floor).clamp(0.0, 1.0)
    return _unit_tensor(gate)


def _compose_modulated_target(
    target: torch.Tensor,
    hard_mask: torch.Tensor,
    raw: torch.Tensor,
    args,
    preserve: torch.Tensor | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    if target.dim() == 3:
        target_b = target[None]
        hard_b = hard_mask[None]
        raw_b = raw[None] if raw.dim() == 3 else raw
        preserve_b = preserve[None] if preserve is not None and preserve.dim() == 2 else preserve
        squeeze = True
    else:
        target_b = target
        hard_b = hard_mask
        raw_b = raw
        preserve_b = preserve
        squeeze = False

    mult, vis, dark, extinction = _decode_maps(raw_b, args)
    alpha = torch.stack([_target_alpha(target_b[i], hard_b[i], args) for i in range(target_b.shape[0])], dim=0)[:, None]
    mask = hard_b[:, None].float().clamp(0.0, 1.0)
    dark = _spatial_layover_gate(dark, mask, args, "dark_patch")
    extinction = _spatial_layover_gate(extinction, mask, args, "target_extinction")
    target_gray = target_b.mean(dim=1, keepdim=True).clamp(0.0, 1.0)

    mod = (target_gray * mult * vis).clamp(0.0, 1.0)
    dark_mix = (dark * float(args.dark_patch_strength) * mask).clamp(0.0, 1.0)
    floor = float(args.dark_patch_floor)
    mod = (mod * (1.0 - dark_mix) + floor * dark_mix).clamp(0.0, 1.0)

    extinction_gamma = max(float(getattr(args, "target_extinction_apply_gamma", 1.0) or 1.0), 0.05)
    extinction_power = extinction.clamp(0.0, 1.0).pow(extinction_gamma)
    extinction_apply_mode = str(getattr(args, "target_extinction_apply_mode", "power") or "power").lower().strip()
    if extinction_apply_mode in {"sigmoid", "threshold"}:
        threshold = min(max(float(getattr(args, "target_extinction_apply_threshold", 0.0) or 0.0), 0.0), 1.0)
        softness = max(float(getattr(args, "target_extinction_apply_softness", 0.08) or 0.08), 1e-4)
        extinction_gate = torch.sigmoid((extinction.clamp(0.0, 1.0) - threshold) / softness)
    elif extinction_apply_mode in {"power_sigmoid", "sigmoid_power"}:
        threshold = min(max(float(getattr(args, "target_extinction_apply_threshold", 0.0) or 0.0), 0.0), 1.0)
        softness = max(float(getattr(args, "target_extinction_apply_softness", 0.08) or 0.08), 1e-4)
        threshold_gate = torch.sigmoid((extinction.clamp(0.0, 1.0) - threshold) / softness)
        blend = min(max(float(getattr(args, "target_extinction_apply_sigmoid_mix", 0.5) or 0.0), 0.0), 1.0)
        extinction_gate = extinction_power * (1.0 - blend) + threshold_gate * blend
    else:
        extinction_gate = extinction_power
    extinction_mix = (extinction_gate * float(getattr(args, "target_extinction_strength", 1.0)) * mask).clamp(0.0, 1.0)
    extinction_floor = float(getattr(args, "target_extinction_floor", 0.0))
    mod = (mod * (1.0 - extinction_mix) + extinction_floor * extinction_mix).clamp(0.0, 1.0)

    # Keep support by default, but let the learned extinction gate override
    # weak target-alpha where real SAR has no return.
    effective_alpha = torch.maximum(alpha, extinction_mix).clamp(0.0, 1.0)
    out_gray = target_gray * (1.0 - effective_alpha) + mod * effective_alpha

    if preserve_b is not None:
        if preserve_b.dim() == 3:
            preserve_b = preserve_b[:, None]
        preserve_b = preserve_b.to(device=out_gray.device, dtype=out_gray.dtype).clamp(0.0, 1.0)
        if preserve_b.shape[-2:] != out_gray.shape[-2:]:
            preserve_b = F.interpolate(preserve_b, size=out_gray.shape[-2:], mode="nearest")

        # Preserve bright target scatterers from the input target render, but let
        # learned dark/extinction maps cut through where the refiner predicts SAR
        # layover/occlusion.  This prevents the target-only refiner from becoming
        # a global dimmer while still allowing local shadow-like suppression.
        occlusion_strength = torch.maximum(dark_mix, extinction_mix).clamp(0.0, 1.0)
        preserve_cut = float(getattr(args, "target_preserve_occlusion_cut", 0.85) or 0.0)
        preserve_alpha = (preserve_b * (1.0 - preserve_cut * occlusion_strength)).clamp(0.0, 1.0)
        out_gray = (out_gray * (1.0 - preserve_alpha) + target_gray * preserve_alpha).clamp(0.0, 1.0)

    out = out_gray.expand(-1, 3, -1, -1).contiguous()

    if squeeze:
        return out[0], mult[0], vis[0], dark[0], extinction[0], alpha[0]
    return out, mult, vis, dark, extinction, alpha


def _compose_image_refinement(
    raw: torch.Tensor,
    target: torch.Tensor,
    hard_mask: torch.Tensor,
    preserve: torch.Tensor,
    args,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    if target.dim() == 3:
        raw_b = raw[None] if raw.dim() == 3 else raw
        target_b = target[None]
        hard_b = hard_mask[None]
        preserve_b = preserve[None]
        squeeze = True
    else:
        raw_b = raw
        target_b = target
        hard_b = hard_mask
        preserve_b = preserve
        squeeze = False

    mode = _refiner_mode(args)
    if mode == "image":
        pred = raw_b.clamp(0.0, 1.0)
    elif mode == "residual":
        scale = float(getattr(args, "residual_scale", 0.65))
        pred = (target_b + (raw_b - 0.5) * (2.0 * scale)).clamp(0.0, 1.0)
    else:
        raise RuntimeError("_compose_image_refinement called in target_modulation mode")

    if preserve_b.dim() == 3:
        preserve_b = preserve_b[:, None]
    pred = (pred * (1.0 - preserve_b) + target_b * preserve_b).clamp(0.0, 1.0)
    if _target_only_refiner(args):
        target_alpha = _dilate01_batch(
            hard_b.float().clamp(0.0, 1.0),
            int(getattr(args, "target_compose_mask_dilate", 0) or 0),
        )[:, None].clamp(0.0, 1.0)
        pred = (pred * target_alpha + target_b * (1.0 - target_alpha)).clamp(0.0, 1.0)
    maps = {"preserve": preserve_b}
    if squeeze:
        return pred[0], {k: v[0] for k, v in maps.items()}
    return pred, maps


def _compose_refiner_output(
    raw: torch.Tensor,
    target: torch.Tensor,
    hard_mask: torch.Tensor,
    preserve: torch.Tensor,
    args,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    if _is_modulation_mode(args):
        pred, mult, vis, dark, extinction, alpha = _compose_modulated_target(target, hard_mask, raw, args, preserve)
        raw_b = raw[None] if raw.dim() == 3 else raw
        _, _, raw_dark, raw_extinction = _decode_maps(raw_b, args)
        if raw.dim() == 3:
            raw_dark = raw_dark[0]
            raw_extinction = raw_extinction[0]
        return pred, {
            "multiplier": mult,
            "visibility": vis,
            "raw_dark_patch": raw_dark,
            "dark_patch": dark,
            "raw_extinction": raw_extinction,
            "extinction": extinction,
            "alpha": alpha,
        }
    return _compose_image_refinement(raw, target, hard_mask, preserve, args)


def _map_regularizer(
    mult: torch.Tensor,
    vis: torch.Tensor,
    dark: torch.Tensor,
    hard_mask: torch.Tensor,
    args,
    extinction: torch.Tensor | None = None,
) -> torch.Tensor:
    mask = hard_mask[:, None].float().clamp(0.0, 1.0)
    ident = ((mult - 1.0).abs() * mask).sum() / (mask.sum().clamp_min(1.0))
    visible = ((1.0 - vis).abs() * mask).sum() / (mask.sum().clamp_min(1.0))
    dark_l1 = (dark.abs() * mask).sum() / (mask.sum().clamp_min(1.0))
    loss = (
        float(args.multiplier_identity_weight) * ident
        + float(args.visibility_identity_weight) * visible
        + float(args.dark_patch_sparsity_weight) * dark_l1
    )
    if extinction is not None:
        ext_l1 = (extinction.abs() * mask).sum() / (mask.sum().clamp_min(1.0))
        loss = loss + float(getattr(args, "target_extinction_sparsity_weight", 0.002)) * ext_l1
    return loss


def _ssim_index(x: torch.Tensor, y: torch.Tensor, radius: int = 5) -> torch.Tensor:
    radius = max(1, int(radius))
    k = 2 * radius + 1
    c1 = 0.01 ** 2
    c2 = 0.03 ** 2
    mu_x = F.avg_pool2d(x, k, stride=1, padding=radius)
    mu_y = F.avg_pool2d(y, k, stride=1, padding=radius)
    sigma_x = F.avg_pool2d(x * x, k, stride=1, padding=radius) - mu_x * mu_x
    sigma_y = F.avg_pool2d(y * y, k, stride=1, padding=radius) - mu_y * mu_y
    sigma_xy = F.avg_pool2d(x * y, k, stride=1, padding=radius) - mu_x * mu_y
    num = (2.0 * mu_x * mu_y + c1) * (2.0 * sigma_xy + c2)
    den = (mu_x * mu_x + mu_y * mu_y + c1) * (sigma_x + sigma_y + c2)
    return (num / den.clamp_min(1e-8)).clamp(-1.0, 1.0)


def _ssim_loss(pred: torch.Tensor, gt: torch.Tensor, args, mask: torch.Tensor | None = None) -> torch.Tensor:
    pred_g = pred.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    gt_g = gt.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    domain = str(getattr(args, "ssim_domain", "sar_intensity") or "sar_intensity").lower().strip()
    if domain == "sar_intensity":
        scale = max(float(getattr(args, "sar_ssim_log_scale", getattr(args, "log_intensity_scale", 20.0)) or 20.0), 1e-6)
        norm = math.log1p(scale)
        pred_g = (torch.log1p(scale * pred_g.clamp_min(0.0)) / norm).clamp(0.0, 1.0)
        gt_g = (torch.log1p(scale * gt_g.clamp_min(0.0)) / norm).clamp(0.0, 1.0)
    ssim_map = _ssim_index(pred_g, gt_g, int(getattr(args, "ssim_radius", 5)))
    loss_map = 1.0 - ssim_map
    if mask is None:
        return loss_map.mean()
    while mask.dim() < loss_map.dim():
        mask = mask.unsqueeze(1)
    return (loss_map * mask).sum() / mask.sum().clamp_min(1.0)


def _highfreq_map(x: torch.Tensor, radius: int) -> torch.Tensor:
    radius = max(1, int(radius))
    k = 2 * radius + 1
    if min(x.shape[-2:]) > radius:
        padded = F.pad(x, (radius, radius, radius, radius), mode="reflect")
        low = F.avg_pool2d(padded, kernel_size=k, stride=1, padding=0)
    else:
        low = F.avg_pool2d(x, kernel_size=k, stride=1, padding=radius)
    return x - low


def _masked_blur_fill_chw(x: torch.Tensor, valid_mask: torch.Tensor, radius: int) -> torch.Tensor:
    if radius <= 0:
        return x.clamp(0.0, 1.0)
    if x.dim() == 2:
        x_b = x[None]
        squeeze = True
    else:
        x_b = x
        squeeze = False
    valid = valid_mask.float().clamp(0.0, 1.0)
    valid_bool = valid > 0.5
    denom = _blur01(valid, radius)
    filled = []
    for c in range(x_b.shape[0]):
        vals = x_b[c][valid_bool]
        mean = vals.mean() if int(vals.numel()) > 0 else x_b[c].mean()
        num = _blur01((x_b[c] * valid).clamp(0.0, 1.0), radius)
        ch = torch.where(denom > 1e-4, num / denom.clamp_min(1e-4), torch.full_like(num, mean))
        filled.append(ch)
    out = torch.stack(filled, dim=0).clamp(0.0, 1.0)
    return out[0] if squeeze else out


def _clean_background_reference(
    ref: torch.Tensor,
    exclude_mask: torch.Tensor,
    radius: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    valid = (exclude_mask < 0.5).float().clamp(0.0, 1.0)
    fill = _masked_blur_fill_chw(ref, valid, radius)
    clean = (ref * valid.unsqueeze(0) + fill * (1.0 - valid).unsqueeze(0)).clamp(0.0, 1.0)
    return clean, fill


def _background_mask_from_target(hard_mask: torch.Tensor, args) -> torch.Tensor:
    bg = 1.0 - hard_mask.float().clamp(0.0, 1.0)
    dilate = int(getattr(args, "background_loss_exclude_dilate", 8) or 0)
    if dilate > 0:
        bg = 1.0 - _dilate01_batch(hard_mask[None] if hard_mask.dim() == 2 else hard_mask, dilate)
        if hard_mask.dim() == 2:
            bg = bg[0]
    return bg.clamp(0.0, 1.0)


def _target_background_ring_mask(hard_mask: torch.Tensor, args) -> torch.Tensor:
    width = int(getattr(args, "target_ring_width", 0) or 0)
    if width <= 0:
        return torch.zeros_like(hard_mask.float())

    if hard_mask.dim() == 2:
        mask_b = hard_mask[None]
        squeeze = True
    else:
        mask_b = hard_mask
        squeeze = False

    inner_dilate = max(0, int(getattr(args, "target_ring_inner_dilate", 1) or 0))
    outer_dilate = inner_dilate + width
    base = mask_b.float().clamp(0.0, 1.0)
    inner = _dilate01_batch(base, inner_dilate) if inner_dilate > 0 else base
    outer = _dilate01_batch(base, outer_dilate)
    ring = (outer - inner).clamp(0.0, 1.0)
    if squeeze:
        return ring[0]
    return ring


def _target_shadow_mask(hard_mask: torch.Tensor, gt: torch.Tensor, args) -> torch.Tensor:
    width = int(getattr(args, "target_shadow_width", 0) or 0)
    if width <= 0:
        return torch.zeros_like(hard_mask.float())

    if hard_mask.dim() == 2:
        mask_b = hard_mask[None]
        gt_b = gt[None] if gt.dim() == 3 else gt
        squeeze = True
    else:
        mask_b = hard_mask
        gt_b = gt
        squeeze = False

    inner_dilate = max(0, int(getattr(args, "target_shadow_inner_dilate", 1) or 0))
    outer_dilate = inner_dilate + width
    base = mask_b.float().clamp(0.0, 1.0)
    inner = _dilate01_batch(base, inner_dilate) if inner_dilate > 0 else base
    outer = _dilate01_batch(base, outer_dilate)
    near = (outer - inner).clamp(0.0, 1.0)

    gray = gt_b.mean(dim=1).clamp(0.0, 1.0)
    threshold = max(float(getattr(args, "target_shadow_dark_threshold", 0.18) or 0.18), 1e-6)
    absolute_dark = ((threshold - gray) / threshold).clamp(0.0, 1.0)

    context_radius = int(getattr(args, "target_shadow_context_blur", 17) or 0)
    if context_radius > 0:
        k = 2 * context_radius + 1
        padded = F.pad(gray[:, None], (context_radius, context_radius, context_radius, context_radius), mode="reflect")
        context = F.avg_pool2d(padded, kernel_size=k, stride=1, padding=0)[:, 0].clamp(0.0, 1.0)
    else:
        context = gray
    ratio = max(float(getattr(args, "target_shadow_ratio_threshold", 0.18) or 0.18), 1e-6)
    relative_dark = ((context - gray) / ratio).clamp(0.0, 1.0)

    shadow = (near * torch.maximum(absolute_dark, relative_dark) * (1.0 - base)).clamp(0.0, 1.0)
    blur = int(getattr(args, "target_shadow_soft_blur", 1) or 0)
    if blur > 0:
        blurred = []
        for i in range(shadow.shape[0]):
            blurred.append(_blur01(shadow[i], blur))
        shadow = torch.stack(blurred, dim=0).clamp(0.0, 1.0)
    if squeeze:
        return shadow[0]
    return shadow


def _target_occlusion_mask(
    hard_mask: torch.Tensor,
    target: torch.Tensor,
    gt: torch.Tensor,
    args,
) -> torch.Tensor:
    """Target-interior regions that are bright in the render but dark in GT SAR."""
    strength = float(getattr(args, "target_occlusion_extinction_weight", 0.0) or 0.0)
    strength += float(getattr(args, "target_occlusion_l1_weight", 0.0) or 0.0)
    strength += float(getattr(args, "target_occlusion_linear_l1_weight", 0.0) or 0.0)
    strength += float(getattr(args, "target_occlusion_mse_weight", 0.0) or 0.0)
    strength += float(getattr(args, "target_occlusion_texture_loss_weight", 0.0) or 0.0)
    strength += float(getattr(args, "target_occlusion_gradient_loss_weight", 0.0) or 0.0)
    strength += float(getattr(args, "target_occlusion_quantile_loss_weight", 0.0) or 0.0)
    if strength <= 0.0:
        return torch.zeros_like(hard_mask.float())

    if hard_mask.dim() == 2:
        mask_b = hard_mask[None]
        target_b = target[None] if target.dim() == 3 else target
        gt_b = gt[None] if gt.dim() == 3 else gt
        squeeze = True
    else:
        mask_b = hard_mask
        target_b = target
        gt_b = gt
        squeeze = False

    base = mask_b.float().clamp(0.0, 1.0)
    target_gray = target_b.mean(dim=1).clamp(0.0, 1.0)
    gt_gray = gt_b.mean(dim=1).clamp(0.0, 1.0)

    target_threshold = max(float(getattr(args, "target_occlusion_target_threshold", 0.08) or 0.08), 1e-6)
    target_high = max(float(getattr(args, "target_occlusion_target_high", 0.28) or 0.28), target_threshold + 1e-6)
    bright_render = ((target_gray - target_threshold) / (target_high - target_threshold)).clamp(0.0, 1.0)

    dark_threshold = max(float(getattr(args, "target_occlusion_dark_threshold", 0.16) or 0.16), 1e-6)
    absolute_dark = ((dark_threshold - gt_gray) / dark_threshold).clamp(0.0, 1.0)

    context_radius = int(getattr(args, "target_occlusion_context_blur", 9) or 0)
    if context_radius > 0:
        k = 2 * context_radius + 1
        padded = F.pad(gt_gray[:, None], (context_radius, context_radius, context_radius, context_radius), mode="reflect")
        context = F.avg_pool2d(padded, kernel_size=k, stride=1, padding=0)[:, 0].clamp(0.0, 1.0)
    else:
        context = gt_gray
    ratio = max(float(getattr(args, "target_occlusion_ratio_threshold", 0.12) or 0.12), 1e-6)
    relative_dark = ((context - gt_gray) / ratio).clamp(0.0, 1.0)

    mask = (base * bright_render * torch.maximum(absolute_dark, relative_dark)).clamp(0.0, 1.0)
    gamma = max(float(getattr(args, "target_occlusion_gamma", 1.0) or 1.0), 0.05)
    mask = mask.pow(gamma)
    blur = int(getattr(args, "target_occlusion_soft_blur", 1) or 0)
    if blur > 0:
        mask = torch.stack([_blur01(mask[i], blur) for i in range(mask.shape[0])], dim=0).clamp(0.0, 1.0)
    if squeeze:
        return mask[0]
    return mask


def _masked_mse_local(a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """MSE normalized by the active mask area instead of the full image."""
    if mask.dim() == 3:
        mask = mask[:, None]
    mask = mask.float().clamp(0.0, 1.0)
    while mask.dim() < a.dim():
        mask = mask.unsqueeze(1)
    channels = max(1, int(a.shape[1]))
    return (((a - b) ** 2) * mask).sum() / (mask.sum().clamp_min(1.0) * channels)


def _target_loss_mask_batch(
    hard_mask: torch.Tensor,
    target: torch.Tensor,
    args,
) -> torch.Tensor:
    """Strict target-support mask for target losses, separate from any context mask."""
    if hard_mask.dim() == 2:
        hard_b = hard_mask[None]
        target_b = target[None] if target.dim() == 3 else target
        squeeze = True
    else:
        hard_b = hard_mask
        target_b = target
        squeeze = False

    threshold = float(getattr(args, "target_loss_mask_threshold", getattr(args, "mask_threshold", 0.08)) or 0.0)
    quantile = float(getattr(args, "target_loss_mask_quantile", 0.0) or 0.0)
    dilate = int(getattr(args, "target_loss_mask_dilate", 0) or 0)
    min_pixels = max(float(getattr(args, "target_loss_mask_min_pixels", 16.0) or 0.0), 0.0)
    fallback_to_hard = bool(getattr(args, "target_loss_mask_fallback_to_hard", True))

    masks = []
    for i in range(target_b.shape[0]):
        gray = target_b[i].mean(dim=0).clamp(0.0, 1.0)
        nonzero = gray[gray > 1e-5]
        th = threshold
        if quantile > 0.0 and int(nonzero.numel()) > 16:
            q = torch.quantile(nonzero, min(max(quantile, 0.0), 1.0)).detach()
            th = max(th, float(q.item()))
        if th > 0.0:
            core = (gray >= th).float()
        else:
            core = (gray > 1e-5).float()
        if dilate > 0:
            core = _dilate01_batch(core[None], dilate)[0]
        elif dilate < 0:
            core = _erode01(core, -dilate)
        mask = (core * hard_b[i].float().clamp(0.0, 1.0)).clamp(0.0, 1.0)
        if float(mask.sum().detach().item()) < min_pixels:
            fallback = core if float(core.sum().detach().item()) >= min_pixels else hard_b[i].float().clamp(0.0, 1.0)
            mask = fallback if fallback_to_hard else core
        masks.append(mask.clamp(0.0, 1.0))
    out = torch.stack(masks, dim=0)
    return out[0] if squeeze else out


def _target_shadow_extinction_loss(pred: torch.Tensor, gt: torch.Tensor, shadow_mask: torch.Tensor, args) -> torch.Tensor:
    """Penalize residual scattering inside GT shadow-like target-near regions."""
    if shadow_mask.dim() == 3:
        mask = shadow_mask[:, None]
    else:
        mask = shadow_mask
    mask = mask.float().clamp(0.0, 1.0)
    pred_gray = pred.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    gt_gray = gt.mean(dim=1, keepdim=True).clamp(0.0, 1.0)

    margin = max(float(getattr(args, "target_shadow_dark_margin", 0.01) or 0.0), 0.0)
    max_intensity = min(max(float(getattr(args, "target_shadow_max_intensity", 0.10) or 0.10), 0.0), 1.0)
    ratio = min(max(float(getattr(args, "target_shadow_context_ratio", 0.45) or 0.45), 0.0), 1.0)
    context_radius = int(getattr(args, "target_shadow_context_blur", 17) or 0)
    if context_radius > 0:
        context = torch.stack([_blur01(gt_gray[i, 0], context_radius) for i in range(gt_gray.shape[0])], dim=0)[:, None]
    else:
        context = gt_gray

    ceiling = torch.minimum(gt_gray + margin, torch.full_like(gt_gray, max_intensity))
    ceiling = torch.minimum(ceiling, context * ratio + margin)
    excess = (pred_gray - ceiling).clamp_min(0.0)
    return (excess * excess * mask).sum() / mask.sum().clamp_min(1.0)


def _target_extinction_supervision_mask(
    hard_mask: torch.Tensor,
    target: torch.Tensor,
    gt: torch.Tensor,
    args,
) -> torch.Tensor:
    if hard_mask.dim() == 2:
        mask_b = hard_mask[None]
        target_b = target[None] if target.dim() == 3 else target
        gt_b = gt[None] if gt.dim() == 3 else gt
        squeeze = True
    else:
        mask_b = hard_mask
        target_b = target
        gt_b = gt
        squeeze = False

    base = mask_b.float().clamp(0.0, 1.0)
    target_gray = target_b.mean(dim=1).clamp(0.0, 1.0)
    gt_gray = gt_b.mean(dim=1).clamp(0.0, 1.0)

    target_low = max(float(getattr(args, "target_extinction_target_threshold", 0.08) or 0.08), 1e-6)
    target_high = max(float(getattr(args, "target_extinction_target_high", 0.28) or 0.28), target_low + 1e-6)
    bright_render = ((target_gray - target_low) / (target_high - target_low)).clamp(0.0, 1.0)
    render_floor = min(max(float(getattr(args, "target_extinction_render_gate_floor", 0.0) or 0.0), 0.0), 1.0)
    render_gate = torch.maximum(bright_render, base * render_floor)

    dark_threshold = max(float(getattr(args, "target_extinction_dark_threshold", 0.16) or 0.16), 1e-6)
    absolute_dark = ((dark_threshold - gt_gray) / dark_threshold).clamp(0.0, 1.0)

    context_radius = int(getattr(args, "target_extinction_context_blur", 9) or 0)
    if context_radius > 0:
        k = 2 * context_radius + 1
        padded = F.pad(gt_gray[:, None], (context_radius, context_radius, context_radius, context_radius), mode="reflect")
        context = F.avg_pool2d(padded, kernel_size=k, stride=1, padding=0)[:, 0].clamp(0.0, 1.0)
    else:
        context = gt_gray
    ratio = max(float(getattr(args, "target_extinction_ratio_threshold", 0.12) or 0.12), 1e-6)
    relative_dark = ((context - gt_gray) / ratio).clamp(0.0, 1.0)

    sup = (base * render_gate * torch.maximum(absolute_dark, relative_dark)).clamp(0.0, 1.0)
    gamma = max(float(getattr(args, "target_extinction_gamma", 1.0) or 1.0), 0.05)
    sup = sup.pow(gamma)
    blur = int(getattr(args, "target_extinction_soft_blur", 1) or 0)
    if blur > 0:
        sup = torch.stack([_blur01(sup[i], blur) for i in range(sup.shape[0])], dim=0).clamp(0.0, 1.0)
    if squeeze:
        return sup[0]
    return sup


def _gt_item_image(item) -> torch.Tensor:
    return item[0]


def _gt_item_weight(item) -> float:
    return float(item[1]) if len(item) >= 2 else 1.0


def _gt_item_azimuth(item) -> float | None:
    if len(item) >= 3 and item[2] is not None:
        return float(item[2]) % 360.0
    return None


def _signed_angle_delta_deg(dst: float, src: float) -> float:
    return ((float(dst) - float(src) + 180.0) % 360.0) - 180.0


def _rotate_chw_about_center(image: torch.Tensor, angle_deg: float, args) -> torch.Tensor:
    if abs(float(angle_deg)) <= 1e-6:
        return image
    if image.dim() != 3:
        raise RuntimeError(f"Expected CHW image for rotation, got shape={tuple(image.shape)}")
    # affine_grid maps output coordinates to input coordinates; this matrix
    # rotates image content around the normalized image center.
    angle = math.radians(float(angle_deg))
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    theta = image.new_tensor([[cos_a, sin_a, 0.0], [-sin_a, cos_a, 0.0]])[None]
    x = image[None]
    grid = F.affine_grid(theta, x.shape, align_corners=False)
    padding = str(getattr(args, "rotated_structure_prior_padding_mode", "border") or "border")
    if padding not in {"zeros", "border", "reflection"}:
        padding = "border"
    return F.grid_sample(
        x,
        grid,
        mode="bilinear",
        padding_mode=padding,
        align_corners=False,
    )[0].clamp(0.0, 1.0)


def _reduce_prior_maps(maps: list[torch.Tensor], weights: list[float], args) -> torch.Tensor:
    stack = torch.stack(maps, dim=0).clamp(0.0, 1.0)
    mode = str(getattr(args, "rotated_structure_prior_reduce", "weighted_max") or "weighted_max").lower().strip()
    if mode == "weighted_mean":
        w = torch.tensor(weights, device=stack.device, dtype=stack.dtype)
        w = w / w.sum().clamp_min(1e-6)
        return (stack * w[:, None, None]).sum(dim=0).clamp(0.0, 1.0)
    if mode == "mean":
        return stack.mean(dim=0).clamp(0.0, 1.0)
    if mode == "weighted_max":
        w = torch.tensor(weights, device=stack.device, dtype=stack.dtype)
        w = w / w.max().clamp_min(1e-6)
        return (stack * w[:, None, None]).max(dim=0).values.clamp(0.0, 1.0)
    return stack.max(dim=0).values.clamp(0.0, 1.0)


def _rotated_structure_prior_from_items(
    hard_mask: torch.Tensor,
    target: torch.Tensor,
    gt_items: list[tuple],
    target_azimuth: float,
    args,
) -> torch.Tensor:
    if float(getattr(args, "rotated_structure_prior_weight", 0.0) or 0.0) <= 0.0:
        return torch.zeros_like(hard_mask, dtype=target.dtype)
    if not gt_items:
        return torch.zeros_like(hard_mask, dtype=target.dtype)

    maps = []
    weights = []
    angle_sign = float(getattr(args, "rotated_structure_prior_angle_sign", 1.0) or 1.0)
    max_delta = max(float(getattr(args, "rotated_structure_prior_max_delta", 15.0) or 0.0), 0.0)
    for item in gt_items:
        gt = _gt_item_image(item)
        weight = max(_gt_item_weight(item), 0.0)
        if weight <= 0.0:
            continue
        src_az = _gt_item_azimuth(item)
        if src_az is None:
            rotated_gt = gt
        else:
            delta = _signed_angle_delta_deg(float(target_azimuth), src_az)
            if max_delta > 0.0 and abs(delta) > max_delta:
                continue
            rotated_gt = _rotate_chw_about_center(gt, angle_sign * delta, args)
        maps.append(_target_extinction_supervision_mask(hard_mask, target, rotated_gt, args))
        weights.append(weight)

    if not maps:
        return torch.zeros_like(hard_mask, dtype=target.dtype)
    prior = _reduce_prior_maps(maps, weights, args)
    strength = min(max(float(getattr(args, "rotated_structure_prior_strength", 1.0) or 1.0), 0.0), 1.0)
    prior = (prior * strength).clamp(0.0, 1.0)
    dilate = int(getattr(args, "rotated_structure_prior_dilate", 0) or 0)
    if dilate > 0:
        prior = _dilate01_batch(prior[None], dilate)[0]
    elif dilate < 0:
        prior = _erode01(prior, -dilate)
    blur = int(getattr(args, "rotated_structure_prior_blur", 1) or 0)
    if blur > 0:
        prior = _blur01(prior, blur)
    return (prior * hard_mask.float().clamp(0.0, 1.0)).clamp(0.0, 1.0)


def _rotated_structure_prior_batch(
    hard_mask: torch.Tensor,
    target: torch.Tensor,
    gt_item_batches: list[list[tuple]],
    target_azimuths: list[float],
    args,
) -> torch.Tensor:
    if float(getattr(args, "rotated_structure_prior_weight", 0.0) or 0.0) <= 0.0:
        return torch.zeros_like(hard_mask, dtype=target.dtype)
    return torch.stack(
        [
            _rotated_structure_prior_from_items(
                hard_mask[i],
                target[i],
                gt_item_batches[i],
                float(target_azimuths[i]),
                args,
            )
            for i in range(target.shape[0])
        ],
        dim=0,
    )


def _target_extinction_supervision_from_items(
    hard_mask: torch.Tensor,
    target: torch.Tensor,
    gt_items: list[tuple],
    args,
) -> torch.Tensor:
    if not gt_items:
        raise RuntimeError("No GT supervision items for target extinction")
    reduce_mode = str(getattr(args, "target_extinction_neighbor_reduce", "max") or "max").lower().strip()
    if reduce_mode == "mix":
        return _target_extinction_supervision_mask(
            hard_mask,
            target,
            _mix_supervision_gt_items(gt_items, args),
            args,
        )

    maps = []
    weights = []
    for item in gt_items:
        gt = _gt_item_image(item)
        weight = max(_gt_item_weight(item), 0.0)
        if weight <= 0.0:
            continue
        maps.append(_target_extinction_supervision_mask(hard_mask, target, gt, args))
        weights.append(weight)
    if not maps:
        maps.append(_target_extinction_supervision_mask(hard_mask, target, _gt_item_image(gt_items[0]), args))
        weights.append(1.0)
    stack = torch.stack(maps, dim=0).clamp(0.0, 1.0)

    if reduce_mode == "weighted_mean":
        w = torch.tensor(weights, device=stack.device, dtype=stack.dtype)
        w = w / w.sum().clamp_min(1e-6)
        return (stack * w[:, None, None]).sum(dim=0).clamp(0.0, 1.0)
    if reduce_mode == "weighted_max":
        w = torch.tensor(weights, device=stack.device, dtype=stack.dtype)
        w = w / w.max().clamp_min(1e-6)
        return (stack * w[:, None, None]).max(dim=0).values.clamp(0.0, 1.0)
    return stack.max(dim=0).values


def _target_extinction_supervision_batch(
    hard_mask: torch.Tensor,
    target: torch.Tensor,
    gt_item_batches: list[list[tuple]],
    args,
) -> torch.Tensor:
    return torch.stack(
        [
            _target_extinction_supervision_from_items(hard_mask[i], target[i], gt_item_batches[i], args)
            for i in range(target.shape[0])
        ],
        dim=0,
    )


def _target_extinction_gate_loss(
    extinction: torch.Tensor | None,
    supervision: torch.Tensor,
    hard_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    bce_weight = float(getattr(args, "target_extinction_gate_loss_weight", 0.0) or 0.0)
    dice_weight = float(getattr(args, "target_extinction_dice_loss_weight", 0.0) or 0.0)
    focal_weight = float(getattr(args, "target_extinction_focal_loss_weight", 0.0) or 0.0)
    if (bce_weight + dice_weight + focal_weight) <= 0.0 or extinction is None:
        return torch.zeros((), device=supervision.device, dtype=supervision.dtype)
    if supervision.dim() == 3:
        target = supervision[:, None]
    else:
        target = supervision
    if hard_mask.dim() == 3:
        mask = hard_mask[:, None].float().clamp(0.0, 1.0)
    else:
        mask = hard_mask.float().clamp(0.0, 1.0)
    target = _unit_tensor(target)
    mask = _unit_tensor(mask)
    pred = _prob_tensor(extinction)
    pos_gain = max(float(getattr(args, "target_extinction_positive_gain", 2.0) or 0.0), 0.0)
    weights = _nonnegative_tensor(mask * (1.0 + pos_gain * target))
    with torch.amp.autocast(device_type=pred.device.type, enabled=False):
        pred_bce = _prob_tensor(pred)
        target_bce = _unit_tensor(target)
        weights_bce = _nonnegative_tensor(weights)
        bce = F.binary_cross_entropy(pred_bce, target_bce, reduction="none")
        loss = bce_weight * (bce * weights_bce).sum() / weights_bce.sum().clamp_min(1.0)

    if focal_weight > 0.0:
        gamma = max(float(getattr(args, "target_extinction_focal_gamma", 2.0) or 2.0), 0.0)
        with torch.amp.autocast(device_type=pred.device.type, enabled=False):
            pt = (pred_bce * target_bce + (1.0 - pred_bce) * (1.0 - target_bce)).clamp(1e-4, 1.0 - 1e-4)
            focal = ((1.0 - pt) ** gamma) * bce
            loss = loss + focal_weight * (focal * weights_bce).sum() / weights_bce.sum().clamp_min(1.0)

    if dice_weight > 0.0:
        pred_m = pred * mask
        target_m = target * mask
        inter = (pred_m * target_m).sum()
        den = pred_m.sum() + target_m.sum()
        dice = 1.0 - (2.0 * inter + 1.0) / (den + 1.0)
        loss = loss + dice_weight * dice
    return loss


def _target_extinction_residual_loss(
    pred: torch.Tensor,
    supervision: torch.Tensor,
    args,
) -> torch.Tensor:
    weight = float(getattr(args, "target_extinction_residual_loss_weight", 0.0) or 0.0)
    if weight <= 0.0:
        return torch.zeros((), device=pred.device, dtype=pred.dtype)
    if supervision.dim() == 3:
        mask = supervision[:, None].float().clamp(0.0, 1.0)
    else:
        mask = supervision.float().clamp(0.0, 1.0)
    pred_gray = pred.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    power = max(float(getattr(args, "target_extinction_residual_power", 2.0) or 2.0), 1.0)
    leak = pred_gray.pow(power)
    return weight * (leak * mask).sum() / mask.sum().clamp_min(1.0)


def _target_extinction_ceiling_loss(
    pred: torch.Tensor,
    gt: torch.Tensor,
    supervision: torch.Tensor,
    args,
) -> torch.Tensor:
    """Penalize residual scattering above a low ceiling in learned dark target regions."""
    weight = float(getattr(args, "target_extinction_ceiling_loss_weight", 0.0) or 0.0)
    if weight <= 0.0:
        return torch.zeros((), device=pred.device, dtype=pred.dtype)
    if supervision.dim() == 3:
        mask = supervision[:, None].float().clamp(0.0, 1.0)
    else:
        mask = supervision.float().clamp(0.0, 1.0)
    pred_gray = pred.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    gt_gray = gt.mean(dim=1, keepdim=True).clamp(0.0, 1.0)

    margin = max(float(getattr(args, "target_extinction_ceiling_margin", 0.01) or 0.0), 0.0)
    max_intensity = min(max(float(getattr(args, "target_extinction_ceiling_max_intensity", 0.07) or 0.07), 0.0), 1.0)
    context_ratio = min(max(float(getattr(args, "target_extinction_ceiling_context_ratio", 0.40) or 0.40), 0.0), 1.0)
    context_blur = int(getattr(args, "target_extinction_ceiling_context_blur", 9) or 0)
    if context_blur > 0:
        context = torch.stack([_blur01(gt_gray[i, 0], context_blur) for i in range(gt_gray.shape[0])], dim=0)[:, None]
    else:
        context = gt_gray

    ceiling = torch.minimum(gt_gray + margin, torch.full_like(gt_gray, max_intensity))
    ceiling = torch.minimum(ceiling, context * context_ratio + margin)
    excess = (pred_gray - ceiling).clamp_min(0.0)
    power = max(float(getattr(args, "target_extinction_ceiling_power", 2.0) or 2.0), 1.0)
    loss = excess.pow(power)
    return weight * (loss * mask).sum() / mask.sum().clamp_min(1.0)


def _target_geometry_preserve_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    hard_mask: torch.Tensor,
    extinction_supervision: torch.Tensor,
    args,
) -> torch.Tensor:
    """Weakly keep current-view target geometry in visible target regions without GT copying."""
    weight = float(getattr(args, "target_geometry_loss_weight", 0.0) or 0.0)
    if weight <= 0.0:
        return torch.zeros((), device=pred.device, dtype=pred.dtype)
    if hard_mask.dim() == 3:
        mask = hard_mask[:, None].float().clamp(0.0, 1.0)
    else:
        mask = hard_mask.float().clamp(0.0, 1.0)
    if extinction_supervision.dim() == 3:
        ext = extinction_supervision[:, None].float().clamp(0.0, 1.0)
    else:
        ext = extinction_supervision.float().clamp(0.0, 1.0)
    visible = (mask * (1.0 - ext).clamp(0.0, 1.0)).clamp(0.0, 1.0)
    min_visible = float(getattr(args, "target_geometry_min_visible", 8.0) or 8.0)
    if float(visible.sum().detach().item()) < min_visible:
        return torch.zeros((), device=pred.device, dtype=pred.dtype)

    pred_gray = pred.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    target_gray = target.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    pred_grad = _gradient_mag_map(pred_gray)
    target_grad = _gradient_mag_map(target_gray)
    grad_loss = ((pred_grad - target_grad).abs() * visible).sum() / visible.sum().clamp_min(1.0)

    pred_mass = (pred_gray * visible).sum(dim=(2, 3)) / visible.sum(dim=(2, 3)).clamp_min(1.0)
    target_mass = (target_gray * visible).sum(dim=(2, 3)) / visible.sum(dim=(2, 3)).clamp_min(1.0)
    mass_loss = F.smooth_l1_loss(pred_mass, target_mass)
    return weight * (grad_loss + 0.35 * mass_loss)


def _rotated_structure_prior_loss(
    pred: torch.Tensor,
    extinction: torch.Tensor | None,
    structure_prior: torch.Tensor,
    hard_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    """Use rotated neighbor GT only as dark/edge/statistical structure, never as pixels."""
    weight = float(getattr(args, "rotated_structure_prior_weight", 0.0) or 0.0)
    if weight <= 0.0:
        return torch.zeros((), device=pred.device, dtype=pred.dtype)
    if structure_prior.dim() == 3:
        prior = structure_prior[:, None].float().clamp(0.0, 1.0)
    else:
        prior = structure_prior.float().clamp(0.0, 1.0)
    if hard_mask.dim() == 3:
        mask = hard_mask[:, None].float().clamp(0.0, 1.0)
    else:
        mask = hard_mask.float().clamp(0.0, 1.0)
    if float(prior.sum().detach().item()) < 1.0:
        return torch.zeros((), device=pred.device, dtype=pred.dtype)

    pred_gray = pred.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    total = torch.zeros((), device=pred.device, dtype=pred.dtype)

    gate_weight = float(getattr(args, "rotated_structure_prior_gate_loss_weight", 0.0) or 0.0)
    dice_weight = float(getattr(args, "rotated_structure_prior_dice_loss_weight", 0.0) or 0.0)
    if extinction is not None and (gate_weight + dice_weight) > 0.0:
        pred_ext = _prob_tensor(extinction)
        prior = _unit_tensor(prior)
        mask = _unit_tensor(mask)
        pos_gain = max(float(getattr(args, "rotated_structure_prior_positive_gain", 2.5) or 0.0), 0.0)
        weights = _nonnegative_tensor(mask * (1.0 + pos_gain * prior))
        with torch.amp.autocast(device_type=pred_ext.device.type, enabled=False):
            pred_bce = _prob_tensor(pred_ext)
            prior_bce = _unit_tensor(prior)
            weights_bce = weights.float()
            bce = F.binary_cross_entropy(pred_bce, prior_bce, reduction="none")
            total = total + gate_weight * (bce * weights_bce).sum() / weights_bce.sum().clamp_min(1.0)
        if dice_weight > 0.0:
            pred_m = pred_ext * mask
            prior_m = prior * mask
            inter = (pred_m * prior_m).sum()
            den = pred_m.sum() + prior_m.sum()
            total = total + dice_weight * (1.0 - (2.0 * inter + 1.0) / (den + 1.0))

    residual_weight = float(getattr(args, "rotated_structure_prior_residual_loss_weight", 0.0) or 0.0)
    if residual_weight > 0.0:
        ceiling = min(max(float(getattr(args, "rotated_structure_prior_max_intensity", 0.055) or 0.055), 0.0), 1.0)
        margin = max(float(getattr(args, "rotated_structure_prior_margin", 0.005) or 0.0), 0.0)
        power = max(float(getattr(args, "rotated_structure_prior_residual_power", 2.0) or 2.0), 1.0)
        excess = (pred_gray - (ceiling + margin)).clamp_min(0.0).pow(power)
        total = total + residual_weight * (excess * prior).sum() / prior.sum().clamp_min(1.0)

    edge_weight = float(getattr(args, "rotated_structure_prior_edge_loss_weight", 0.0) or 0.0)
    if edge_weight > 0.0:
        pred_edge_src = extinction.clamp(0.0, 1.0) if extinction is not None else (1.0 - pred_gray).clamp(0.0, 1.0)
        pred_edge = _gradient_mag_map(pred_edge_src)
        prior_edge = _gradient_mag_map(prior)
        edge_dilate = int(getattr(args, "rotated_structure_prior_edge_dilate", 2) or 0)
        edge_mask = _dilate01_batch(hard_mask.float().clamp(0.0, 1.0), edge_dilate)[:, None]
        edge_norm = prior_edge.detach().amax(dim=(2, 3), keepdim=True).clamp_min(1e-3)
        edge_target = (prior_edge / edge_norm).clamp(0.0, 1.0)
        edge_pred_norm = pred_edge.detach().amax(dim=(2, 3), keepdim=True).clamp_min(1e-3)
        edge_pred = (pred_edge / edge_pred_norm).clamp(0.0, 1.0)
        total = total + edge_weight * ((edge_pred - edge_target).abs() * edge_mask).sum() / edge_mask.sum().clamp_min(1.0)

    ratio_weight = float(getattr(args, "rotated_structure_prior_local_ratio_weight", 0.0) or 0.0)
    if ratio_weight > 0.0:
        pool = max(3, int(getattr(args, "rotated_structure_prior_local_ratio_pool", 9) or 9))
        if pool % 2 == 0:
            pool += 1
        pad = pool // 2
        dark_threshold = min(max(float(getattr(args, "rotated_structure_prior_dark_threshold", 0.14) or 0.14), 0.0), 1.0)
        softness = max(float(getattr(args, "rotated_structure_prior_dark_softness", 0.035) or 0.035), 1e-4)
        pred_dark = ((dark_threshold - pred_gray) / softness).clamp(0.0, 1.0) * mask
        prior_dark = prior * mask
        mask_pool = F.avg_pool2d(mask, pool, stride=1, padding=pad).clamp_min(1e-4)
        pred_ratio = F.avg_pool2d(pred_dark, pool, stride=1, padding=pad) / mask_pool
        prior_ratio = F.avg_pool2d(prior_dark, pool, stride=1, padding=pad) / mask_pool
        ratio_mask = (mask_pool > 0.05).float()
        total = total + ratio_weight * F.smooth_l1_loss(
            pred_ratio * ratio_mask,
            prior_ratio.detach() * ratio_mask,
            reduction="sum",
        ) / ratio_mask.sum().clamp_min(1.0)

    return weight * total


def _target_occlusion_extinction_loss(
    pred: torch.Tensor,
    gt: torch.Tensor,
    occlusion_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    """Penalize bright residuals where target geometry should be hidden in SAR."""
    if occlusion_mask.dim() == 3:
        mask = occlusion_mask[:, None]
    else:
        mask = occlusion_mask
    mask = mask.float().clamp(0.0, 1.0)
    pred_gray = pred.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    gt_gray = gt.mean(dim=1, keepdim=True).clamp(0.0, 1.0)

    margin = max(float(getattr(args, "target_occlusion_dark_margin", 0.005) or 0.0), 0.0)
    max_intensity = min(max(float(getattr(args, "target_occlusion_max_intensity", 0.08) or 0.08), 0.0), 1.0)
    ratio = min(max(float(getattr(args, "target_occlusion_context_ratio", 0.40) or 0.40), 0.0), 1.0)
    context_radius = int(getattr(args, "target_occlusion_context_blur", 9) or 0)
    if context_radius > 0:
        context = torch.stack([_blur01(gt_gray[i, 0], context_radius) for i in range(gt_gray.shape[0])], dim=0)[:, None]
    else:
        context = gt_gray

    ceiling = torch.minimum(gt_gray + margin, torch.full_like(gt_gray, max_intensity))
    ceiling = torch.minimum(ceiling, context * ratio + margin)
    excess = (pred_gray - ceiling).clamp_min(0.0)
    return (excess * excess * mask).sum() / mask.sum().clamp_min(1.0)


def _patchgan_enabled(args) -> bool:
    return (
        float(getattr(args, "background_patchgan_weight", 0.0) or 0.0) > 0.0
        or float(getattr(args, "target_ring_patchgan_weight", 0.0) or 0.0) > 0.0
        or float(getattr(args, "target_shadow_patchgan_weight", 0.0) or 0.0) > 0.0
    )


def _patchgan_input(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    ring_mask: torch.Tensor,
    background_mask: torch.Tensor,
) -> torch.Tensor:
    gray = image.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    return torch.cat(
        [
            gray,
            hard_mask[:, None].float().clamp(0.0, 1.0),
            ring_mask[:, None].float().clamp(0.0, 1.0),
            background_mask[:, None].float().clamp(0.0, 1.0),
        ],
        dim=1,
    )


def _patchgan_mask(mask: torch.Tensor, logits: torch.Tensor, min_coverage: float) -> torch.Tensor:
    if mask.dim() == 3:
        mask = mask[:, None]
    mask = mask.float().clamp(0.0, 1.0)
    pooled = F.interpolate(mask, size=logits.shape[-2:], mode="area")
    keep = (pooled >= float(min_coverage)).float()
    if float(keep.sum().detach().item()) < 1.0:
        keep = pooled
    return keep.clamp(0.0, 1.0)


def _masked_lsgan_loss(logits: torch.Tensor, target_value: float, mask: torch.Tensor) -> torch.Tensor:
    return (((logits - float(target_value)) ** 2) * mask).sum() / mask.sum().clamp_min(1.0)


def _masked_mean(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    while mask.dim() < x.dim():
        mask = mask.unsqueeze(1)
    mask = mask.float().clamp(0.0, 1.0)
    return (x * mask).sum() / (mask.sum().clamp_min(1.0) * float(x.shape[1]))


def _target_speckle_stat_loss(
    pred_ld: torch.Tensor,
    gt_ld: torch.Tensor,
    pred_std: torch.Tensor,
    gt_std: torch.Tensor,
    pred_hf: torch.Tensor,
    gt_hf: torch.Tensor,
    target_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    weight = float(getattr(args, "target_speckle_loss_weight", 0.0) or 0.0)
    if weight <= 0.0:
        return torch.zeros((), device=pred_ld.device, dtype=pred_ld.dtype)

    if target_mask.dim() == 4:
        mask = target_mask[:, 0]
    else:
        mask = target_mask
    quantiles = _parse_quantiles(getattr(args, "target_speckle_stat_quantiles", "0.05,0.10,0.25,0.50,0.75,0.90,0.97"))
    loss = torch.zeros((), device=pred_ld.device, dtype=pred_ld.dtype)

    std_w = float(getattr(args, "target_speckle_std_quantile_weight", 1.0) or 0.0)
    if std_w > 0.0:
        loss = loss + std_w * _masked_quantile_loss(pred_std, gt_std, mask, quantiles)

    hf_w = float(getattr(args, "target_speckle_highfreq_quantile_weight", 0.8) or 0.0)
    if hf_w > 0.0:
        loss = loss + hf_w * _masked_quantile_loss(pred_hf.abs(), gt_hf.abs(), mask, quantiles)

    int_w = float(getattr(args, "target_speckle_intensity_quantile_weight", 0.6) or 0.0)
    if int_w > 0.0:
        loss = loss + int_w * _masked_quantile_loss(pred_ld, gt_ld, mask, quantiles)

    dark_w = float(getattr(args, "target_speckle_dark_ratio_weight", 0.6) or 0.0)
    if dark_w > 0.0:
        pred_g = pred_ld.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
        gt_g = gt_ld.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
        threshold = float(getattr(args, "target_speckle_dark_threshold", 0.22) or 0.22)
        softness = max(float(getattr(args, "target_speckle_dark_softness", 0.035) or 0.035), 1e-4)
        pred_dark = torch.sigmoid((threshold - pred_g) / softness)
        gt_dark = torch.sigmoid((threshold - gt_g) / softness)
        loss = loss + dark_w * (_masked_mean(pred_dark, mask) - _masked_mean(gt_dark, mask)).abs()

    return weight * loss


def _border_background_mask(hard_mask: torch.Tensor, args) -> torch.Tensor:
    width = int(getattr(args, "border_loss_width", 0) or 0)
    if width <= 0:
        return torch.zeros_like(hard_mask.float())

    if hard_mask.dim() == 2:
        mask_b = hard_mask[None]
        squeeze = True
    else:
        mask_b = hard_mask
        squeeze = False

    b, h, w = mask_b.shape
    width = min(width, max(1, min(h, w) // 2))
    edge = torch.zeros((b, h, w), device=mask_b.device, dtype=mask_b.dtype)
    edge[:, :width, :] = 1.0
    edge[:, -width:, :] = 1.0
    edge[:, :, :width] = 1.0
    edge[:, :, -width:] = 1.0

    dilate = int(getattr(args, "border_loss_target_exclude_dilate", 10) or 0)
    target_block = _dilate01_batch(mask_b, dilate) if dilate > 0 else mask_b.float().clamp(0.0, 1.0)
    border = (edge * (1.0 - target_block)).clamp(0.0, 1.0)
    if squeeze:
        return border[0]
    return border


def _apply_empirical_background(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "empirical_background_strength", 0.0) or 0.0)
    if strength <= 0.0 or style_ref is None:
        return image.clamp(0.0, 1.0)

    bg = _make_empirical_background(image, hard_mask, style_ref, azimuth_deg, args)
    if bg is None:
        return image.clamp(0.0, 1.0)

    hmask = hard_mask.float().clamp(0.0, 1.0)
    keep = _dilate01_batch(hmask[None], int(getattr(args, "empirical_background_target_dilate", 6) or 0))[0]
    blur = int(getattr(args, "empirical_background_blend_blur", 3) or 0)
    if blur > 0:
        keep = _blur01(keep, blur)

    shadow_keep_strength = float(getattr(args, "empirical_background_shadow_keep_strength", 0.0) or 0.0)
    if shadow_keep_strength > 0.0:
        gray = image.mean(dim=0).clamp(0.0, 1.0)
        threshold = max(float(getattr(args, "empirical_background_shadow_threshold", 0.12) or 0.12), 1e-6)
        dark = ((threshold - gray) / threshold).clamp(0.0, 1.0)
        near = _dilate01_batch(
            hmask[None],
            int(getattr(args, "empirical_background_shadow_target_dilate", 80) or 0),
        )[0]
        shadow_keep = (dark * near * (1.0 - hmask)).clamp(0.0, 1.0)
        shadow_blur = int(getattr(args, "empirical_background_shadow_blur", 4) or 0)
        if shadow_blur > 0:
            shadow_keep = _blur01(shadow_keep, shadow_blur)
        keep = torch.maximum(keep, shadow_keep * min(max(shadow_keep_strength, 0.0), 1.0)).clamp(0.0, 1.0)

    alpha = ((1.0 - keep) * min(max(strength, 0.0), 1.0)).unsqueeze(0)
    return (image * (1.0 - alpha) + bg * alpha).clamp(0.0, 1.0)


def _make_empirical_background(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
) -> torch.Tensor | None:
    strength = float(getattr(args, "empirical_background_strength", 0.0) or 0.0)
    if strength <= 0.0 or style_ref is None:
        return None

    style_ref = _resize_chw(style_ref, tuple(image.shape[-2:]))
    hmask = hard_mask.float().clamp(0.0, 1.0)
    exclude = _dilate01_batch(hmask[None], int(getattr(args, "empirical_background_reference_exclude_dilate", 18) or 0))[0]
    bg = _sample_structured_background(style_ref, exclude, azimuth_deg, args)
    scale = float(getattr(args, "empirical_background_scale", 1.0) or 1.0)
    bias = float(getattr(args, "empirical_background_bias", 0.0) or 0.0)
    return (bg * scale + bias).clamp(0.0, 1.0)


def _compose_background_then_target(
    mod_target: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
    preserve_alpha: torch.Tensor | None = None,
) -> tuple[torch.Tensor, torch.Tensor | None]:
    bg = _make_empirical_background(mod_target, hard_mask, style_ref, azimuth_deg, args)
    if bg is None:
        return mod_target.clamp(0.0, 1.0), None

    strength = min(max(float(getattr(args, "empirical_background_strength", 0.0) or 0.0), 0.0), 1.0)
    base = (mod_target * (1.0 - strength) + bg * strength).clamp(0.0, 1.0)

    if bool(getattr(args, "layer_target_use_preserve", True)) and preserve_alpha is not None:
        alpha = preserve_alpha.squeeze().float().clamp(0.0, 1.0)
    else:
        hmask = hard_mask.float().clamp(0.0, 1.0)
        target_dilate = int(getattr(args, "layer_target_dilate", 1) or 0)
        if target_dilate > 0:
            alpha = _dilate01_batch(hmask[None], target_dilate)[0]
        elif target_dilate < 0:
            alpha = _erode01(hmask, -target_dilate)
        else:
            alpha = hmask
        blur = int(getattr(args, "layer_target_blur", 1) or 0)
        if blur > 0:
            alpha = _blur01(alpha, blur)
        alpha = (alpha * min(max(float(getattr(args, "layer_target_strength", 1.0) or 1.0), 0.0), 1.0)).clamp(0.0, 1.0)

    out = (base * (1.0 - alpha.unsqueeze(0)) + mod_target * alpha.unsqueeze(0)).clamp(0.0, 1.0)
    return out, alpha


def _sample_structured_background(
    ref: torch.Tensor,
    exclude_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    mode = str(getattr(args, "empirical_background_mode", "patch") or "patch").lower().strip()
    if mode == "reference":
        return ref.clamp(0.0, 1.0)
    if mode == "pixel":
        return _sample_pixel_background(ref, exclude_mask, azimuth_deg, args)
    return _sample_patch_background(ref, exclude_mask, azimuth_deg, args)


def _sample_pixel_background(
    ref: torch.Tensor,
    exclude_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    if bool(getattr(args, "empirical_background_clean_reference", True)):
        fallback_radius = max(1, int(getattr(args, "empirical_background_fallback_blur", 9) or 9))
        clean_ref, _fill = _clean_background_reference(ref, exclude_mask, fallback_radius)
        gray = clean_ref.mean(dim=0)
    else:
        gray = ref.mean(dim=0)
    valid = exclude_mask < 0.5
    vals = gray[valid]
    if int(vals.numel()) < 64:
        vals = gray.reshape(-1)
    h, w = gray.shape
    gen = torch.Generator(device=ref.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 3301)
    idx = torch.randint(0, int(vals.numel()), (h * w,), device=ref.device, generator=gen)
    bg = vals[idx].view(h, w)
    return bg.unsqueeze(0).expand_as(ref).contiguous()


def _sample_patch_background(
    ref: torch.Tensor,
    exclude_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    h, w = ref.shape[-2:]
    tile = max(4, int(getattr(args, "empirical_background_patch_size", 24) or 24))
    overlap = min(max(0, int(getattr(args, "empirical_background_patch_overlap", 6) or 0)), tile - 1)
    stride = max(1, tile - overlap)
    valid = (exclude_mask < 0.5).float()
    if bool(getattr(args, "empirical_background_clean_reference", True)):
        fallback_radius = max(1, int(getattr(args, "empirical_background_fallback_blur", 9) or 9))
        clean_ref, fallback_rgb = _clean_background_reference(ref, exclude_mask, fallback_radius)
    else:
        clean_ref = ref
        gray = ref.mean(dim=0)
        fallback = _blur01(gray, max(1, int(getattr(args, "empirical_background_fallback_blur", 9) or 9)))
        fallback_rgb = fallback.unsqueeze(0).expand_as(ref)
    out = torch.zeros_like(ref)
    weight = torch.zeros((1, h, w), device=ref.device, dtype=ref.dtype)

    gen = torch.Generator(device=ref.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 7411)

    ys = list(range(0, h, stride))
    xs = list(range(0, w, stride))
    min_valid = float(getattr(args, "empirical_background_patch_min_valid", 0.70) or 0.70)
    candidates: dict[tuple[int, int], list[tuple[int, int]]] = {}

    for y in ys:
        ph = min(tile, h - y)
        for x in xs:
            pw = min(tile, w - x)
            key = (ph, pw)
            if key not in candidates:
                cur = []
                for sy in range(0, h - ph + 1, max(1, ph // 3)):
                    for sx in range(0, w - pw + 1, max(1, pw // 3)):
                        if float(valid[sy : sy + ph, sx : sx + pw].mean().item()) >= min_valid:
                            cur.append((sy, sx))
                if not cur:
                    cur = [(max(0, (h - ph) // 2), max(0, (w - pw) // 2))]
                candidates[key] = cur

            cur = candidates[key]
            pick = int(torch.randint(0, len(cur), (1,), device=ref.device, generator=gen).item())
            sy, sx = cur[pick]
            patch = clean_ref[:, sy : sy + ph, sx : sx + pw]
            out[:, y : y + ph, x : x + pw] += patch
            weight[:, y : y + ph, x : x + pw] += 1.0

    fallback_weight = max(float(getattr(args, "empirical_background_patch_fallback_weight", 1.0) or 0.0), 0.0)
    if fallback_weight > 0.0:
        out = (out + fallback_rgb * fallback_weight) / (weight + fallback_weight).clamp_min(1e-6)
    else:
        out = torch.where(weight > 0.0, out / weight.clamp_min(1.0), fallback_rgb)
    smooth = int(getattr(args, "empirical_background_patch_smooth", 1) or 0)
    if smooth > 0:
        low = torch.stack([_blur01(out[c], smooth) for c in range(out.shape[0])], dim=0)
        mix = min(max(float(getattr(args, "empirical_background_patch_smooth_mix", 0.35) or 0.0), 0.0), 1.0)
        out = out * (1.0 - mix) + low * mix
    return out.clamp(0.0, 1.0)


def _repair_background_border(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> torch.Tensor:
    strength = float(getattr(args, "border_repair_strength", 0.0) or 0.0)
    if strength <= 0.0 or _is_modulation_mode(args):
        return image.clamp(0.0, 1.0)

    h, w = image.shape[-2:]
    width = int(getattr(args, "border_repair_width", 10) or 0)
    if width <= 0 or width * 2 >= min(h, w):
        return image.clamp(0.0, 1.0)

    edge = torch.zeros((h, w), device=image.device, dtype=image.dtype)
    edge[:width, :] = 1.0
    edge[-width:, :] = 1.0
    edge[:, :width] = 1.0
    edge[:, -width:] = 1.0

    hmask = hard_mask.float().clamp(0.0, 1.0)
    target_block = _dilate01_batch(hmask[None], int(getattr(args, "border_repair_target_dilate", 8) or 0))[0]
    alpha = (edge * (1.0 - target_block)).clamp(0.0, 1.0)
    blur = int(getattr(args, "border_repair_blur", 4) or 0)
    if blur > 0:
        alpha = (_blur01(alpha, blur) * (1.0 - target_block)).clamp(0.0, 1.0)
    if float(alpha.max().item()) <= 0.0:
        return image.clamp(0.0, 1.0)

    exclude = torch.maximum(edge, target_block).clamp(0.0, 1.0)
    fill = _sample_patch_background(image.detach(), exclude, azimuth_deg + 17.0, args)
    amount = (alpha * min(max(strength, 0.0), 1.0)).unsqueeze(0)
    return (image * (1.0 - amount) + fill * amount).clamp(0.0, 1.0)


def _restore_reference_shadow(
    image: torch.Tensor,
    reference: torch.Tensor | None,
    hard_mask: torch.Tensor,
    args,
) -> tuple[torch.Tensor, torch.Tensor | None]:
    strength = float(getattr(args, "shadow_restore_strength", 0.0) or 0.0)
    if strength <= 0.0 or reference is None:
        return image.clamp(0.0, 1.0), None

    reference = _resize_chw(reference, tuple(image.shape[-2:]))
    hmask = hard_mask.float().clamp(0.0, 1.0)
    if bool(getattr(args, "shadow_restore_clean_reference", False)):
        target_exclude = _dilate01_batch(
            hmask[None],
            int(getattr(args, "shadow_restore_target_protect_dilate", 2) or 0),
        )[0]
        fallback_radius = max(
            int(getattr(args, "shadow_restore_reference_blur", 0) or 0),
            int(getattr(args, "empirical_background_fallback_blur", 9) or 9),
            1,
        )
        reference_clean, _reference_fill = _clean_background_reference(reference, target_exclude, fallback_radius)
    else:
        reference_clean = reference
    ref_gray = reference_clean.mean(dim=0).clamp(0.0, 1.0)
    ref_blur = int(getattr(args, "shadow_restore_reference_blur", 0) or 0)
    ref_shadow = _blur01(ref_gray, ref_blur) if ref_blur > 0 else ref_gray
    context_blur = int(getattr(args, "shadow_restore_context_blur", 21) or 0)
    if context_blur > 0:
        ref_context = _blur01(ref_shadow, context_blur).clamp_min(1e-4)
    else:
        ref_context = ref_shadow.mean().clamp_min(1e-4)
    attenuation = (ref_shadow / ref_context).clamp(0.0, 1.0)
    threshold = max(float(getattr(args, "shadow_restore_threshold", 0.18) or 0.18), 1e-6)
    dark_by_value = ((threshold - ref_shadow) / threshold).clamp(0.0, 1.0)
    dark_by_ratio = (1.0 - attenuation).clamp(0.0, 1.0)
    ratio_mix = min(max(float(getattr(args, "shadow_restore_ratio_mix", 0.65) or 0.65), 0.0), 1.0)
    shadow = (dark_by_value * (1.0 - ratio_mix) + dark_by_ratio * ratio_mix).clamp(0.0, 1.0)
    gamma = max(float(getattr(args, "shadow_restore_gamma", 1.0) or 1.0), 0.05)
    shadow = shadow.pow(gamma)

    near = _dilate01_batch(
        hmask[None],
        int(getattr(args, "shadow_restore_target_dilate", 100) or 0),
    )[0]
    shadow = (shadow * near * (1.0 - hmask)).clamp(0.0, 1.0)
    blur = int(getattr(args, "shadow_restore_blur", 5) or 0)
    if blur > 0:
        shadow = _blur01(shadow, blur)
    protect_dilate = int(getattr(args, "shadow_restore_target_protect_dilate", 2) or 0)
    target_protect = _dilate01_batch(hmask[None], protect_dilate)[0] if protect_dilate > 0 else hmask
    shadow = (shadow * (1.0 - target_protect)).clamp(0.0, 1.0)
    shadow = shadow.clamp(0.0, 1.0)
    max_coverage = min(max(float(getattr(args, "shadow_restore_max_coverage", 0.22) or 0.0), 0.0), 1.0)
    if 0.0 < max_coverage < 1.0:
        valid = (near * (1.0 - target_protect)).clamp(0.0, 1.0)
        vals = shadow[valid > 0.05]
        if int(vals.numel()) >= 8:
            q = torch.quantile(vals, 1.0 - max_coverage).detach()
            softness = max(float(getattr(args, "shadow_restore_coverage_softness", 0.08) or 0.08), 1e-4)
            shadow = ((shadow - q) / softness).clamp(0.0, 1.0) * valid
            coverage_blur = int(getattr(args, "shadow_restore_coverage_blur", 0) or 0)
            if coverage_blur > 0:
                shadow = (_blur01(shadow, coverage_blur) * valid).clamp(0.0, 1.0)

    amount = (shadow * min(max(strength, 0.0), 1.0)).unsqueeze(0)
    mode = str(getattr(args, "shadow_restore_mode", "darken") or "darken").lower().strip()
    if mode == "blend":
        restored = image * (1.0 - amount) + reference * amount
    elif mode == "extinguish":
        min_attenuation = min(max(float(getattr(args, "shadow_restore_min_attenuation", 0.04) or 0.04), 0.0), 1.0)
        power = max(float(getattr(args, "shadow_restore_attenuation_power", 1.6) or 1.6), 0.05)
        floor = min(max(float(getattr(args, "shadow_restore_floor", 0.0) or 0.0), 0.0), 1.0)
        attenuation = attenuation.clamp(min_attenuation, 1.0).pow(power).unsqueeze(0)
        shadowed = (image * attenuation + floor * (1.0 - attenuation)).clamp(0.0, 1.0)
        restored = image * (1.0 - amount) + shadowed * amount
    elif mode == "attenuate":
        min_attenuation = min(max(float(getattr(args, "shadow_restore_min_attenuation", 0.20) or 0.20), 0.0), 1.0)
        attenuation = attenuation.clamp(min_attenuation, 1.0).unsqueeze(0)
        restored = image * (1.0 - amount) + (image * attenuation) * amount
    else:
        max_darken = min(max(float(getattr(args, "shadow_restore_max_darken", 0.70) or 0.70), 0.0), 1.0)
        restored = image * (1.0 - amount * max_darken)
    return restored.clamp(0.0, 1.0), shadow


def _save_training_masks(loaded: list[tuple[torch.Tensor, torch.Tensor, float, str]], args) -> None:
    if not bool(getattr(args, "save_training_masks", False)):
        return

    out_arg = getattr(args, "training_mask_output_dir", None)
    if out_arg:
        out_dir = Path(out_arg)
    elif getattr(args, "model_path", None):
        out_dir = Path(args.model_path) / "training_masks"
    else:
        out_dir = Path(args.checkpoint).parent / "training_masks"
    out_dir.mkdir(parents=True, exist_ok=True)

    limit = int(getattr(args, "training_mask_limit", 0) or 0)
    items = loaded if limit <= 0 else loaded[:limit]
    for target, gt, az, name in items:
        _x, hard, preserve = _build_input(target, az, args, training=False)
        target_loss = _target_loss_mask_batch(hard, target, args)
        background = _background_mask_from_target(hard, args)
        ring = _target_background_ring_mask(hard, args)
        shadow = _target_shadow_mask(hard, gt, args)
        border = _border_background_mask(hard, args)
        lock = _dilate01_batch(hard[None], int(args.target_lock_dilate))[0]
        active = torch.maximum(torch.maximum(torch.maximum(background, ring), shadow), border).clamp(0.0, 1.0)

        stem = Path(name).stem
        masks = {
            "00_target_hard": hard,
            "01_target_preserve": preserve,
            "02_target_loss": target_loss,
            "03_target_lock": lock,
            "04_background_loss": background,
            "05_target_ring": ring,
            "06_target_shadow": shadow,
            "07_image_border": border,
            "08_generator_train_area": active,
        }
        for key, value in masks.items():
            torchvision.utils.save_image(value[None].clamp(0.0, 1.0), str(out_dir / f"{stem}_{key}.png"))

        gray = gt.mean(dim=0, keepdim=True).clamp(0.0, 1.0).expand(3, -1, -1).clone()
        overlay = gray * 0.55
        overlay[0] = torch.maximum(overlay[0], target_loss * 0.95)
        overlay[1] = torch.maximum(overlay[1], background * 0.80)
        overlay[2] = torch.maximum(overlay[2], torch.maximum(ring * 0.95, shadow * 0.80))
        torchvision.utils.save_image(overlay.clamp(0.0, 1.0), str(out_dir / f"{stem}_09_overlay_targetloss_bg_ring_shadow.png"))

    print(f"[target modulation] saved training masks: {out_dir} ({len(items)} samples)")


def _angle_dist_deg(a: float, b: float) -> float:
    d = abs(float(a) - float(b)) % 360.0
    return min(d, 360.0 - d)


def _azimuth_prefix(path: Path) -> str:
    stem = path.stem
    m = re.search(r"(?i)azimuth[_-]?(\d+(?:\.\d+)?)", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    m = re.search(r"(\d+(?:\.\d+)?)$", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    return stem


def _azimuth_candidates(path: Path) -> list[dict]:
    return [
        {
            "path": p,
            "azimuth": _parse_azimuth(p),
            "prefix": _azimuth_prefix(p),
        }
        for p in _image_files(path)
    ]


def _nearest_candidate(candidates: list[dict], target_az: float, used: set[Path] | None = None) -> dict:
    if not candidates:
        raise RuntimeError("No candidates available for azimuth selection")
    ordered = sorted(
        candidates,
        key=lambda c: (_angle_dist_deg(c["azimuth"], target_az), c["path"].name),
    )
    if used is not None:
        for cand in ordered:
            if cand["path"] not in used:
                return cand
    return ordered[0]


def _bracketing_candidates(candidates: list[dict], target_az: float) -> tuple[dict, dict, float, float]:
    if not candidates:
        raise RuntimeError("No candidates available for azimuth bracketing")
    ordered = sorted(candidates, key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    if len(ordered) == 1:
        return ordered[0], ordered[0], 1.0, 0.0

    target = float(target_az) % 360.0
    exact = [
        cand
        for cand in ordered
        if _angle_dist_deg(float(cand["azimuth"]), target) <= 1e-6
    ]
    if exact:
        return exact[0], exact[0], 1.0, 0.0

    backward = [
        ((target - float(c["azimuth"])) % 360.0, c)
        for c in ordered
    ]
    forward = [
        ((float(c["azimuth"]) - target) % 360.0, c)
        for c in ordered
    ]
    prev_gap, prev = min((item for item in backward if item[0] > 1e-6), key=lambda item: (item[0], item[1]["path"].name))
    next_gap, next_ = min((item for item in forward if item[0] > 1e-6), key=lambda item: (item[0], item[1]["path"].name))
    total = max(prev_gap + next_gap, 1e-6)
    prev_weight = next_gap / total
    next_weight = prev_gap / total
    return prev, next_, float(prev_weight), float(next_weight)


def _select_all_target_pairs(target_dir: Path, gt_dir: Path, args) -> list[tuple[Path, Path, float, dict]]:
    target_all = sorted(_azimuth_candidates(target_dir), key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    gt_all = _azimuth_candidates(gt_dir)
    if not target_all or not gt_all:
        raise RuntimeError(f"No training images found: {target_dir} vs {gt_dir}")

    gt_by_prefix: dict[str, list[dict]] = {}
    for cand in gt_all:
        gt_by_prefix.setdefault(cand["prefix"], []).append(cand)

    selected: list[tuple[Path, Path, float, dict]] = []
    for tp in target_all:
        target_az = float(tp["azimuth"]) % 360.0
        gt_pool = gt_by_prefix.get(tp["prefix"], gt_all)
        gp = _nearest_candidate(gt_pool, target_az)
        selected.append(
            (
                tp["path"],
                gp["path"],
                target_az,
                {
                    "slot": target_az,
                    "prefix": tp["prefix"],
                    "target_azimuth": target_az,
                    "gt_azimuth": float(gp["azimuth"]),
                    "target_error": 0.0,
                    "gt_error": _angle_dist_deg(float(gp["azimuth"]), target_az),
                },
            )
        )
    return selected


def _attach_neighbor_gt_supervision(
    pairs: list[tuple[Path, Path, float, dict]],
    gt_dir: Path,
    args,
) -> list[tuple[Path, Path, float, dict]]:
    mode = str(getattr(args, "train_gt_neighbor_mode", "nearest") or "nearest").lower().strip()
    if mode == "nearest":
        return pairs

    gt_all = _azimuth_candidates(gt_dir)
    if not gt_all:
        raise RuntimeError(f"No GT images found for adjacent supervision: {gt_dir}")
    gt_by_prefix: dict[str, list[dict]] = {}
    for cand in gt_all:
        gt_by_prefix.setdefault(cand["prefix"], []).append(cand)

    use = str(getattr(args, "train_gt_neighbor_angle_source", "target") or "target").lower().strip()
    updated: list[tuple[Path, Path, float, dict]] = []
    for tp, gp, az, meta in pairs:
        if use == "slot":
            supervise_az = float(meta.get("slot", az)) % 360.0
        else:
            supervise_az = float(meta.get("target_azimuth", az)) % 360.0
        gt_pool = gt_by_prefix.get(str(meta.get("prefix", "")), gt_all)
        lo, hi, w_lo, w_hi = _bracketing_candidates(gt_pool, supervise_az)
        meta = dict(meta)
        meta["gt_neighbor_mode"] = mode
        meta["gt_supervision_azimuth"] = supervise_az
        meta["gt_neighbors"] = [
            {
                "path": lo["path"],
                "azimuth": float(lo["azimuth"]),
                "weight": float(w_lo),
            },
            {
                "path": hi["path"],
                "azimuth": float(hi["azimuth"]),
                "weight": float(w_hi),
            },
        ]
        # Keep the highest-weight neighbor as the primary path for legacy reports/tools.
        primary = lo if w_lo >= w_hi else hi
        updated.append((tp, primary["path"], az, meta))
    return updated


def _make_azimuth_slots(args) -> list[float]:
    step = float(getattr(args, "train_azimuth_step", 0.0) or 0.0)
    if step <= 0.0:
        return []
    start = float(getattr(args, "train_azimuth_start", 0.0) or 0.0)
    end = float(getattr(args, "train_azimuth_end", 360.0) or 360.0)
    slots = []
    i = 0
    az = start
    while az < end - 1e-6 and i < 10000:
        slots.append(float(az) % 360.0)
        i += 1
        az = start + i * step
    if not slots:
        raise RuntimeError("--train_azimuth_step produced no azimuth slots")
    return slots


def _select_train_pairs(target_dir: Path, gt_dir: Path, args) -> list[tuple[Path, Path, float, dict]]:
    if bool(getattr(args, "train_use_all_targets", False)):
        pairs = _select_all_target_pairs(target_dir, gt_dir, args)
        return _attach_neighbor_gt_supervision(pairs, gt_dir, args)

    slots = _make_azimuth_slots(args)
    if not slots:
        pairs = [(tp, gp, az, {"slot": az}) for tp, gp, az in _match_pairs(target_dir, gt_dir)]
        return _attach_neighbor_gt_supervision(pairs, gt_dir, args)

    target_all = _azimuth_candidates(target_dir)
    gt_all = _azimuth_candidates(gt_dir)
    if not target_all or not gt_all:
        raise RuntimeError(f"No training images found: {target_dir} vs {gt_dir}")

    target_by_prefix: dict[str, list[dict]] = {}
    gt_by_prefix: dict[str, list[dict]] = {}
    for cand in target_all:
        target_by_prefix.setdefault(cand["prefix"], []).append(cand)
    for cand in gt_all:
        gt_by_prefix.setdefault(cand["prefix"], []).append(cand)

    common_prefixes = sorted(set(target_by_prefix) & set(gt_by_prefix))
    use_prefixes = common_prefixes or [""]
    enforce_unique = bool(getattr(args, "train_azimuth_unique", False))
    used_targets: set[Path] = set()
    used_gts: set[Path] = set()
    selected: list[tuple[Path, Path, float, dict]] = []

    for slot in slots:
        best = None
        for prefix in use_prefixes:
            target_pool = target_by_prefix.get(prefix, target_all)
            gt_pool = gt_by_prefix.get(prefix, gt_all)
            tp = _nearest_candidate(target_pool, slot, used_targets if enforce_unique else None)
            gp = _nearest_candidate(gt_pool, slot, used_gts if enforce_unique else None)
            score = (
                _angle_dist_deg(tp["azimuth"], slot) + _angle_dist_deg(gp["azimuth"], slot),
                max(_angle_dist_deg(tp["azimuth"], slot), _angle_dist_deg(gp["azimuth"], slot)),
                prefix,
            )
            if best is None or score < best[0]:
                best = (score, prefix, tp, gp)
        assert best is not None
        _score, prefix, tp, gp = best
        if enforce_unique:
            used_targets.add(tp["path"])
            used_gts.add(gp["path"])
        selected.append(
            (
                tp["path"],
                gp["path"],
                float(slot),
                {
                    "slot": float(slot),
                    "prefix": prefix,
                    "target_azimuth": float(tp["azimuth"]),
                    "gt_azimuth": float(gp["azimuth"]),
                    "target_error": _angle_dist_deg(tp["azimuth"], slot),
                    "gt_error": _angle_dist_deg(gp["azimuth"], slot),
                },
            )
        )
    return _attach_neighbor_gt_supervision(selected, gt_dir, args)


def _write_train_pair_report(pairs: list[tuple[Path, Path, float, dict]], args) -> None:
    report_arg = getattr(args, "train_azimuth_report", None)
    if report_arg:
        report_path = Path(report_arg)
    else:
        report_path = Path(args.checkpoint).parent / "train_azimuth_pairs.txt"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# slot_deg\ttarget_file\ttarget_az\ttarget_err\tgt_file\tgt_az\tgt_err\tprefix"
        "\tgt_a_file\tgt_a_az\tgt_a_weight\tgt_b_file\tgt_b_az\tgt_b_weight",
    ]
    for tp, gp, _az, meta in pairs:
        slot = float(meta.get("slot", _az))
        target_az = float(meta.get("target_azimuth", _parse_azimuth(tp)))
        gt_az = float(meta.get("gt_azimuth", _parse_azimuth(gp)))
        neighbors = list(meta.get("gt_neighbors", []))
        if len(neighbors) >= 2:
            gt_a = neighbors[0]
            gt_b = neighbors[1]
            gt_a_path = Path(gt_a["path"])
            gt_b_path = Path(gt_b["path"])
            extra = (
                f"\t{gt_a_path.name}\t{float(gt_a['azimuth']):07.3f}\t{float(gt_a['weight']):.6f}"
                f"\t{gt_b_path.name}\t{float(gt_b['azimuth']):07.3f}\t{float(gt_b['weight']):.6f}"
            )
        else:
            extra = "\t\t\t\t\t\t"
        lines.append(
            f"{slot:07.3f}\t{tp.name}\t{target_az:07.3f}\t"
            f"{_angle_dist_deg(target_az, slot):06.3f}\t{gp.name}\t"
            f"{gt_az:07.3f}\t{_angle_dist_deg(gt_az, slot):06.3f}\t{meta.get('prefix', '')}"
            f"{extra}"
        )
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[target modulation] train azimuth report: {report_path}")


def _mix_supervision_gt_items(gt_items: list[tuple], args) -> torch.Tensor:
    if not gt_items:
        raise RuntimeError("No GT supervision items to mix")
    if len(gt_items) == 1:
        return _gt_item_image(gt_items[0])
    mix_domain = str(getattr(args, "train_gt_neighbor_mix_domain", "pixel") or "pixel").lower().strip()
    mixed = None
    weight_sum = 0.0
    for item in gt_items:
        image = _gt_item_image(item)
        weight = _gt_item_weight(item)
        if weight <= 0.0:
            continue
        value = image
        if mix_domain == "log":
            value = torch.log1p(value.clamp(0.0, 1.0) * float(args.log_intensity_scale))
        mixed = value * weight if mixed is None else mixed + value * weight
        weight_sum += weight
    if mixed is None or weight_sum <= 1e-6:
        return _gt_item_image(gt_items[0])
    mixed = mixed / weight_sum
    if mix_domain == "log":
        mixed = torch.expm1(mixed).div(float(args.log_intensity_scale)).clamp(0.0, 1.0)
    return mixed.clamp(0.0, 1.0)


def _sample_supervision_gt(gt_items: list[tuple], args, device: torch.device) -> torch.Tensor:
    if not gt_items:
        raise RuntimeError("No GT supervision items to sample")
    if len(gt_items) == 1:
        return _gt_item_image(gt_items[0])
    supervision = str(getattr(args, "train_gt_neighbor_supervision", "sample") or "sample").lower().strip()
    if supervision == "mix":
        return _mix_supervision_gt_items(gt_items, args)

    total = sum(max(_gt_item_weight(item), 0.0) for item in gt_items)
    if total <= 1e-6:
        return _gt_item_image(gt_items[0])
    pick = float(torch.rand((), device=device).item()) * total
    acc = 0.0
    for item in gt_items:
        image = _gt_item_image(item)
        acc += max(_gt_item_weight(item), 0.0)
        if pick <= acc:
            return image
    return _gt_item_image(gt_items[-1])


def _load_supervision_gt_items(
    primary_gt_path: Path,
    meta: dict,
    target_shape: tuple[int, int],
    args,
    device: torch.device,
) -> list[tuple]:
    neighbors = list(meta.get("gt_neighbors", []))
    mode = str(getattr(args, "train_gt_neighbor_mode", "nearest") or "nearest").lower().strip()
    if mode != "linear" or len(neighbors) < 2:
        image = _resize_chw(_load_image(primary_gt_path, args).to(device), target_shape)
        return [(image, 1.0, float(meta.get("gt_azimuth", _parse_azimuth(primary_gt_path))) % 360.0)]

    gt_items: list[tuple] = []
    for item in neighbors[:2]:
        weight = float(item.get("weight", 0.0) or 0.0)
        if weight <= 0.0:
            continue
        image = _resize_chw(_load_image(Path(item["path"]), args).to(device), target_shape)
        gt_items.append((image, weight, float(item.get("azimuth", _parse_azimuth(Path(item["path"])))) % 360.0))

    if not gt_items:
        image = _resize_chw(_load_image(primary_gt_path, args).to(device), target_shape)
        return [(image, 1.0, float(meta.get("gt_azimuth", _parse_azimuth(primary_gt_path))) % 360.0)]
    return gt_items


def _expand_focus_azimuth_pairs(pairs: list[tuple[Path, Path, float, dict]], args) -> list[tuple[Path, Path, float, dict]]:
    raw = str(getattr(args, "focus_azimuths", "") or "").strip()
    repeat = max(1, int(getattr(args, "focus_azimuth_repeat", 1) or 1))
    if not raw or repeat <= 1:
        return pairs

    focus = [float(x) % 360.0 for x in re.split(r"[\s,]+", raw) if x.strip()]
    if not focus:
        return pairs
    tolerance = max(0.0, float(getattr(args, "focus_azimuth_tolerance", 2.5) or 0.0))

    expanded: list[tuple[Path, Path, float, dict]] = []
    added = 0
    for pair in pairs:
        expanded.append(pair)
        _tp, _gp, az, meta = pair
        slot = float(meta.get("slot", az)) % 360.0
        if any(_angle_dist_deg(slot, f) <= tolerance for f in focus):
            expanded.extend([pair] * (repeat - 1))
            added += repeat - 1
    if added > 0:
        focus_text = ",".join(f"{x:g}" for x in focus)
        print(
            "[target modulation] focus azimuth oversampling: "
            f"focus={focus_text}, repeat={repeat}, tolerance={tolerance:g}deg, "
            f"pairs {len(pairs)} -> {len(expanded)}"
        )
    return expanded


def _forward_angle_gap_deg(a: float, b: float) -> float:
    return (float(b) - float(a)) % 360.0


def _load_azimuth_consistency_items(args, device: torch.device) -> tuple[list[dict], list[tuple[int, int, float]]]:
    weight = float(getattr(args, "azimuth_consistency_weight", 0.0) or 0.0)
    if weight <= 0.0:
        return [], []

    target_dir = Path(args.apply_target_dir) if getattr(args, "apply_target_dir", None) else None
    if target_dir is None or not target_dir.exists():
        print("[target modulation] azimuth consistency disabled: no apply target dir")
        return [], []

    candidates = sorted(_azimuth_candidates(target_dir), key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    if len(candidates) < 2:
        print("[target modulation] azimuth consistency disabled: need at least two apply target renders")
        return [], []

    items: list[dict] = []
    for cand in candidates:
        target = _load_image(cand["path"], args).to(device)
        az = float(cand["azimuth"]) % 360.0
        x, hard, preserve = _build_input(target, az, args, training=False)
        items.append(
            {
                "target": target,
                "x": x,
                "hard": hard,
                "preserve": preserve,
                "azimuth": az,
                "name": cand["path"].name,
            }
        )

    max_gap = max(float(getattr(args, "azimuth_consistency_max_gap", 12.0) or 0.0), 0.0)
    pairs: list[tuple[int, int, float]] = []
    for i in range(len(items)):
        j = (i + 1) % len(items)
        gap = _forward_angle_gap_deg(items[i]["azimuth"], items[j]["azimuth"])
        if 1e-6 < gap <= max_gap:
            pairs.append((i, j, gap))

    if not pairs:
        print(
            "[target modulation] azimuth consistency disabled: "
            f"no adjacent apply targets within {max_gap:g} deg"
        )
        return [], []

    gaps = [gap for _i, _j, gap in pairs]
    print(
        "[target modulation] azimuth consistency enabled: "
        f"{len(items)} targets, {len(pairs)} adjacent pairs, "
        f"gap range=[{min(gaps):.3g}, {max(gaps):.3g}] deg, weight={weight:g}"
    )
    return items, pairs


def _masked_stat_vector(x: torch.Tensor, mask: torch.Tensor, quantiles: list[float]) -> torch.Tensor:
    if x.dim() == 3:
        x = x[:, None]
    if mask.dim() == 3:
        mask = mask[:, None]
    x = x.mean(dim=1, keepdim=True)
    mask = mask.float().clamp(0.0, 1.0)
    denom = mask.sum(dim=(2, 3), keepdim=True).clamp_min(1.0)
    mean = (x * mask).sum(dim=(2, 3), keepdim=True) / denom
    centered = (x - mean) * mask
    std = ((centered * centered).sum(dim=(2, 3), keepdim=True) / denom).sqrt()

    parts = [mean.flatten(1), std.flatten(1)]
    if quantiles:
        qs = []
        for bi in range(x.shape[0]):
            vals = x[bi, 0][mask[bi, 0] > 0.05]
            if int(vals.numel()) < 16:
                vals = x[bi, 0].reshape(-1)
            q = torch.tensor(quantiles, device=x.device, dtype=x.dtype)
            qs.append(torch.quantile(vals, q).to(dtype=x.dtype))
        parts.append(torch.stack(qs, dim=0))
    return torch.cat(parts, dim=1)


def _azimuth_consistency_loss(
    model: TargetModulationUNet,
    items: list[dict],
    pairs: list[tuple[int, int, float]],
    args,
    quantiles: list[float],
) -> torch.Tensor:
    if not items or not pairs:
        device = next(model.parameters()).device
        return torch.zeros((), device=device)

    samples = max(1, int(getattr(args, "azimuth_consistency_samples", 1) or 1))
    samples = min(samples, len(pairs))
    pick = torch.randint(0, len(pairs), (samples,), device="cpu").tolist()

    chosen = [pairs[i] for i in pick]
    flat_indices = []
    gap_weights = []
    max_gap = max(float(getattr(args, "azimuth_consistency_max_gap", 12.0) or 12.0), 1e-6)
    for i, j, gap in chosen:
        flat_indices.extend([i, j])
        gap_weights.append(max(0.25, min(1.0, 1.0 - (gap / max_gap) * 0.5)))

    x_b = torch.stack([items[i]["x"] for i in flat_indices], dim=0)
    target_b = torch.stack([items[i]["target"] for i in flat_indices], dim=0)
    hard_b = torch.stack([items[i]["hard"] for i in flat_indices], dim=0)
    preserve_b = torch.stack([items[i]["preserve"] for i in flat_indices], dim=0)

    raw = model(x_b)
    pred, _maps = _compose_refiner_output(raw, target_b, hard_b, preserve_b, args)
    pred = _force_grayscale_batch(pred, args)
    pred_ld = _to_loss_domain(pred, args).mean(dim=1, keepdim=True)

    mask = hard_b.float().clamp(0.0, 1.0)
    dilate = int(getattr(args, "azimuth_consistency_mask_dilate", 0) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask, dilate)
    mask = mask[:, None]

    stats = _masked_stat_vector(pred_ld, mask, quantiles)
    texture_radius = int(getattr(args, "azimuth_consistency_texture_radius", 2) or 0)
    texture_weight = float(getattr(args, "azimuth_consistency_texture_weight", 0.25) or 0.0)
    if texture_radius > 0 and texture_weight > 0.0:
        texture = _local_std_map(pred_ld, texture_radius)
        texture_stats = _masked_stat_vector(texture, mask, quantiles)
    else:
        texture_stats = None

    pair_weights = torch.tensor(gap_weights, device=pred.device, dtype=pred.dtype)
    stat_a = stats[0::2]
    stat_b = stats[1::2]
    stat_loss = F.smooth_l1_loss(stat_a, stat_b, reduction="none").mean(dim=1)
    loss = (stat_loss * pair_weights).sum() / pair_weights.sum().clamp_min(1e-6)
    if texture_stats is not None:
        tex_a = texture_stats[0::2]
        tex_b = texture_stats[1::2]
        tex_loss = F.smooth_l1_loss(tex_a, tex_b, reduction="none").mean(dim=1)
        tex_loss = (tex_loss * pair_weights).sum() / pair_weights.sum().clamp_min(1e-6)
        loss = loss + texture_weight * tex_loss
    return loss


def _train(args, device: torch.device) -> TargetModulationUNet:
    pairs = _select_train_pairs(Path(args.train_target_dir), Path(args.train_gt_dir), args)
    if float(getattr(args, "train_azimuth_step", 0.0) or 0.0) > 0.0:
        slots = _make_azimuth_slots(args)
        max_target_err = max(float(meta.get("target_error", 0.0)) for *_rest, meta in pairs)
        max_gt_err = max(float(meta.get("gt_error", 0.0)) for *_rest, meta in pairs)
        print(
            "[target modulation] train pairs by azimuth slots: "
            f"{len(pairs)} slots, step={float(args.train_azimuth_step):.3g} deg, "
            f"max target error={max_target_err:.3f} deg, max gt error={max_gt_err:.3f} deg"
        )
        _write_train_pair_report(pairs, args)
    else:
        print(f"[target modulation] train pairs: {len(pairs)}")
    pairs = _expand_focus_azimuth_pairs(pairs, args)
    print(f"[target modulation] mode: {_refiner_mode(args)}")
    in_ch = _model_input_channels(args)
    out_ch = _default_output_channels(args)
    model = TargetModulationUNet(
        in_ch=in_ch,
        base=int(args.model_base),
        padding_mode=str(getattr(args, "conv_padding_mode", "zeros")),
        out_ch=out_ch,
    ).to(device)
    init_ckpt = None
    if args.init_checkpoint:
        init_ckpt = torch.load(args.init_checkpoint, map_location=device)
        if int(init_ckpt.get("in_ch", in_ch)) != in_ch:
            raise RuntimeError(f"--init_checkpoint input channels mismatch: checkpoint={init_ckpt.get('in_ch')} current={in_ch}")
        _load_state_dict_compatible(model, init_ckpt["model"], "init checkpoint")
        print(f"[target modulation] initialized from: {args.init_checkpoint}")

    teacher_model = None
    if bool(args.background_finetune):
        if init_ckpt is None:
            raise RuntimeError("--background_finetune requires --init_checkpoint so the target can be locked")
        teacher_model = TargetModulationUNet(
            in_ch=in_ch,
            base=int(args.model_base),
            padding_mode=str(getattr(args, "conv_padding_mode", "zeros")),
            out_ch=_checkpoint_output_channels(init_ckpt, out_ch),
        ).to(device)
        _load_state_dict_compatible(teacher_model, init_ckpt["model"], "teacher checkpoint")
        teacher_model.eval()
        for p in teacher_model.parameters():
            p.requires_grad_(False)
        print(
            "[target modulation] background fine-tune enabled: "
            "background losses active, target locked to init checkpoint"
        )

    patch_d = None
    opt_d = None
    scaler_d = None
    if _patchgan_enabled(args):
        if _is_modulation_mode(args):
            raise RuntimeError("PatchGAN losses require --refiner_mode image or residual")
        patch_d = PatchDiscriminator(
            in_ch=4,
            base=int(getattr(args, "patchgan_base", 32)),
        ).to(device)
        opt_d = torch.optim.AdamW(
            patch_d.parameters(),
            lr=float(getattr(args, "patchgan_lr", 1e-4)),
            betas=(0.5, 0.999),
            weight_decay=float(getattr(args, "patchgan_weight_decay", 0.0)),
        )
        scaler_d = torch.amp.GradScaler("cuda", enabled=bool(args.amp) and device.type == "cuda")
        print(
            "[target modulation] PatchGAN enabled: "
            f"background={float(args.background_patchgan_weight):.4g}, "
            f"ring={float(args.target_ring_patchgan_weight):.4g}, "
            f"shadow={float(args.target_shadow_patchgan_weight):.4g}"
        )

    opt = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
    scaler = torch.amp.GradScaler("cuda", enabled=bool(args.amp) and device.type == "cuda")
    quantiles = _parse_quantiles(args.stat_quantiles)

    neighbor_mode = str(getattr(args, "train_gt_neighbor_mode", "nearest") or "nearest").lower().strip()
    if neighbor_mode != "nearest":
        print(
            "[target modulation] adjacent GT supervision enabled: "
            f"mode={neighbor_mode}, angle_source={getattr(args, 'train_gt_neighbor_angle_source', 'target')}, "
            f"supervision={getattr(args, 'train_gt_neighbor_supervision', 'sample')}, "
            f"mix_domain={getattr(args, 'train_gt_neighbor_mix_domain', 'pixel')}"
        )
    if float(getattr(args, "rotated_structure_prior_weight", 0.0) or 0.0) > 0.0:
        print(
            "[target modulation] rotated neighbor structure prior enabled: "
            f"weight={float(args.rotated_structure_prior_weight):.4g}, "
            f"reduce={getattr(args, 'rotated_structure_prior_reduce', 'weighted_max')}, "
            f"merge_extinction={bool(getattr(args, 'rotated_structure_prior_merge_extinction', True))}, "
            f"max_delta={float(getattr(args, 'rotated_structure_prior_max_delta', 15.0)):.3g} deg"
        )

    loaded = []
    mask_preview = []
    for tp, gp, az, meta in pairs:
        t = _load_image(tp, args).to(device)
        gt_items = _load_supervision_gt_items(gp, meta, tuple(t.shape[-2:]), args, device)
        target_az = float(meta.get("target_azimuth", az)) % 360.0
        loaded.append((t, gt_items, az, target_az, tp.name))
        mask_preview.append((t, _mix_supervision_gt_items(gt_items, args), az, tp.name))
    _save_training_masks(mask_preview, args)
    azimuth_consistency_quantiles = _parse_quantiles(getattr(args, "azimuth_consistency_quantiles", "0.25,0.50,0.75,0.90"))
    azimuth_consistency_items, azimuth_consistency_pairs = _load_azimuth_consistency_items(args, device)

    progress_metrics = str(getattr(args, "progress_metrics", "compact") or "compact").lower().strip()
    progress_interval = max(1, int(getattr(args, "progress_interval", 20) or 20))
    pbar = tqdm(
        range(1, int(args.iterations) + 1),
        desc="train target modulation",
        dynamic_ncols=True,
        mininterval=max(0.1, float(getattr(args, "progress_refresh_seconds", 0.5) or 0.5)),
    )
    ema = None
    for it in pbar:
        idx = torch.randint(0, len(loaded), (int(args.batch_size),), device="cpu").tolist()
        xs, targets, gts, masks, preserves, gt_item_batches, target_azimuths = [], [], [], [], [], [], []
        for i in idx:
            target, gt_items, az, target_az, _name = loaded[i]
            gt = _sample_supervision_gt(gt_items, args, device)
            x, hard, preserve = _build_input(
                target,
                az,
                args,
                training=not bool(getattr(args, "deterministic_train_noise", False)),
            )
            xs.append(x)
            targets.append(target)
            gts.append(gt)
            masks.append(hard)
            preserves.append(preserve)
            gt_item_batches.append(gt_items)
            target_azimuths.append(float(target_az))
        x = torch.stack(xs, dim=0)
        target_b = torch.stack(targets, dim=0)
        gt_b = torch.stack(gts, dim=0)
        hard_b = torch.stack(masks, dim=0)
        preserve_b = torch.stack(preserves, dim=0)

        opt.zero_grad(set_to_none=True)
        with torch.amp.autocast("cuda", enabled=bool(args.amp) and device.type == "cuda"):
            raw = model(x)
            pred, maps = _compose_refiner_output(raw, target_b, hard_b, preserve_b, args)
            pred = _force_grayscale_batch(pred, args)

            pred_ld = _to_loss_domain(pred, args)
            gt_ld = _to_loss_domain(gt_b, args)
            target_loss_mask = _target_loss_mask_batch(hard_b, target_b, args)
            target_area = target_loss_mask[:, None]
            target_l1 = ((pred_ld - gt_ld).abs() * target_area).sum() / (
                target_area.sum().clamp_min(1.0) * 3.0
            )
            target_mse = _masked_mse_local(pred, gt_b, target_area)

            gt_gray = gt_ld.mean(dim=1, keepdim=True)
            bright_weight = 1.0 + float(args.bright_loss_gain) * gt_gray.pow(float(args.bright_loss_gamma))
            bright_l1 = ((pred_ld - gt_ld).abs() * target_area * bright_weight).sum() / (
                (target_area * bright_weight).sum().clamp_min(1.0) * 3.0
            )

            quant = _masked_quantile_loss(pred_ld, gt_ld, target_area[:, 0], quantiles)
            pred_std = _local_std_map(pred_ld, int(args.local_texture_radius))
            gt_std = _local_std_map(gt_ld, int(args.local_texture_radius))
            texture = _masked_l1(pred_std, gt_std, target_area[:, 0])
            pred_grad = _gradient_mag_map(pred_ld)
            gt_grad = _gradient_mag_map(gt_ld)
            grad = _masked_l1(pred_grad, gt_grad, target_area[:, 0])
            pred_hf = _highfreq_map(pred_ld, int(args.highfreq_radius))
            gt_hf = _highfreq_map(gt_ld, int(args.highfreq_radius))
            target_speckle = _target_speckle_stat_loss(
                pred_ld,
                gt_ld,
                pred_std,
                gt_std,
                pred_hf,
                gt_hf,
                target_area,
                args,
            )
            target_extinction_sup = _target_extinction_supervision_batch(target_loss_mask, target_b, gt_item_batches, args)
            rotated_structure_prior = _rotated_structure_prior_batch(
                target_loss_mask,
                target_b,
                gt_item_batches,
                target_azimuths,
                args,
            )
            if bool(getattr(args, "rotated_structure_prior_merge_extinction", True)):
                target_extinction_sup = torch.maximum(target_extinction_sup, rotated_structure_prior).clamp(0.0, 1.0)
            target_extinction_gate = _target_extinction_gate_loss(
                maps.get("extinction") if isinstance(maps.get("extinction"), torch.Tensor) else None,
                target_extinction_sup,
                target_loss_mask,
                args,
            )
            target_extinction_residual = _target_extinction_residual_loss(pred, target_extinction_sup, args)
            target_extinction_ceiling = _target_extinction_ceiling_loss(pred, gt_b, target_extinction_sup, args)
            target_geometry = _target_geometry_preserve_loss(pred, target_b, target_loss_mask, target_extinction_sup, args)
            rotated_structure = _rotated_structure_prior_loss(
                pred,
                maps.get("extinction") if isinstance(maps.get("extinction"), torch.Tensor) else None,
                rotated_structure_prior,
                target_loss_mask,
                args,
            )
            mse = F.mse_loss(pred * target_area, gt_b * target_area)
            full_l1 = (pred_ld - gt_ld).abs().mean()
            full_ssim = _ssim_loss(pred, gt_b, args)
            target_ssim = _ssim_loss(pred, gt_b, args, target_area[:, 0])
            background_area = _background_mask_from_target(hard_b, args)
            background_l1 = _masked_l1(pred_ld, gt_ld, background_area)
            background_texture = _masked_l1(pred_std, gt_std, background_area)
            background_grad = _masked_l1(pred_grad, gt_grad, background_area)
            background_highfreq = _masked_l1(pred_hf, gt_hf, background_area)
            background_ssim = _ssim_loss(pred, gt_b, args, background_area)
            background_quant = _masked_quantile_loss(pred_ld, gt_ld, background_area, quantiles)
            ring_area = _target_background_ring_mask(hard_b, args)
            ring_l1 = _masked_l1(pred_ld, gt_ld, ring_area)
            ring_texture = _masked_l1(pred_std, gt_std, ring_area)
            ring_grad = _masked_l1(pred_grad, gt_grad, ring_area)
            ring_highfreq = _masked_l1(pred_hf, gt_hf, ring_area)
            ring_ssim = _ssim_loss(pred, gt_b, args, ring_area)
            ring_quant = _masked_quantile_loss(pred_ld, gt_ld, ring_area, quantiles)
            shadow_area = _target_shadow_mask(hard_b, gt_b, args)
            shadow_l1 = _masked_l1(pred_ld, gt_ld, shadow_area)
            shadow_linear_l1 = _masked_l1(pred, gt_b, shadow_area)
            shadow_mse = _masked_mse_local(pred, gt_b, shadow_area)
            shadow_extinction = _target_shadow_extinction_loss(pred, gt_b, shadow_area, args)
            shadow_texture = _masked_l1(pred_std, gt_std, shadow_area)
            shadow_grad = _masked_l1(pred_grad, gt_grad, shadow_area)
            shadow_highfreq = _masked_l1(pred_hf, gt_hf, shadow_area)
            shadow_ssim = _ssim_loss(pred, gt_b, args, shadow_area)
            shadow_quant = _masked_quantile_loss(pred_ld, gt_ld, shadow_area, quantiles)
            occlusion_area = _target_occlusion_mask(hard_b, target_b, gt_b, args)
            occlusion_l1 = _masked_l1(pred_ld, gt_ld, occlusion_area)
            occlusion_linear_l1 = _masked_l1(pred, gt_b, occlusion_area)
            occlusion_mse = _masked_mse_local(pred, gt_b, occlusion_area)
            occlusion_extinction = _target_occlusion_extinction_loss(pred, gt_b, occlusion_area, args)
            occlusion_texture = _masked_l1(pred_std, gt_std, occlusion_area)
            occlusion_grad = _masked_l1(pred_grad, gt_grad, occlusion_area)
            occlusion_quant = _masked_quantile_loss(pred_ld, gt_ld, occlusion_area, quantiles)
            border_area = _border_background_mask(hard_b, args)
            border_l1 = _masked_l1(pred_ld, gt_ld, border_area)
            border_texture = _masked_l1(pred_std, gt_std, border_area)
            border_grad = _masked_l1(pred_grad, gt_grad, border_area)
            border_ssim = _ssim_loss(pred, gt_b, args, border_area)
            border_quant = _masked_quantile_loss(pred_ld, gt_ld, border_area, quantiles)
            target_lock_l1 = torch.zeros((), device=device, dtype=pred.dtype)
            target_lock_ssim = torch.zeros((), device=device, dtype=pred.dtype)
            if teacher_model is not None:
                with torch.no_grad():
                    teacher_raw = teacher_model(x)
                    teacher_pred, _teacher_maps = _compose_refiner_output(teacher_raw, target_b, hard_b, preserve_b, args)
                    teacher_pred = _force_grayscale_batch(teacher_pred, args)
                    teacher_ld = _to_loss_domain(teacher_pred, args)
                lock_area = _dilate01_batch(hard_b, int(args.target_lock_dilate))[:, None]
                target_lock_l1 = ((pred_ld - teacher_ld).abs() * lock_area).sum() / (
                    lock_area.sum().clamp_min(1.0) * 3.0
                )
                target_lock_ssim = _ssim_loss(pred, teacher_pred, args, lock_area[:, 0])
            if _is_modulation_mode(args):
                reg = _map_regularizer(
                    maps["multiplier"],
                    maps["visibility"],
                    maps["dark_patch"],
                    hard_b,
                    args,
                    maps.get("extinction") if isinstance(maps.get("extinction"), torch.Tensor) else None,
                )
            else:
                reg = torch.zeros((), device=device, dtype=pred.dtype)

            if bool(args.background_finetune):
                loss = (
                    float(args.background_l1_weight) * background_l1
                    + float(args.background_texture_loss_weight) * background_texture
                    + float(args.background_gradient_loss_weight) * background_grad
                    + float(args.background_highfreq_loss_weight) * background_highfreq
                    + float(args.background_ssim_loss_weight) * background_ssim
                    + float(args.background_quantile_loss_weight) * background_quant
                    + float(args.target_ring_l1_weight) * ring_l1
                    + float(args.target_ring_texture_loss_weight) * ring_texture
                    + float(args.target_ring_gradient_loss_weight) * ring_grad
                    + float(args.target_ring_highfreq_loss_weight) * ring_highfreq
                    + float(args.target_ring_ssim_loss_weight) * ring_ssim
                    + float(args.target_ring_quantile_loss_weight) * ring_quant
                    + float(args.target_mse_weight) * target_mse
                    + float(args.target_shadow_l1_weight) * shadow_l1
                    + float(args.target_shadow_linear_l1_weight) * shadow_linear_l1
                    + float(args.target_shadow_mse_weight) * shadow_mse
                    + float(args.target_shadow_extinction_weight) * shadow_extinction
                    + float(args.target_shadow_texture_loss_weight) * shadow_texture
                    + float(args.target_shadow_gradient_loss_weight) * shadow_grad
                    + float(args.target_shadow_highfreq_loss_weight) * shadow_highfreq
                    + float(args.target_shadow_ssim_loss_weight) * shadow_ssim
                    + float(args.target_shadow_quantile_loss_weight) * shadow_quant
                    + float(args.target_occlusion_l1_weight) * occlusion_l1
                    + float(args.target_occlusion_linear_l1_weight) * occlusion_linear_l1
                    + float(args.target_occlusion_mse_weight) * occlusion_mse
                    + float(args.target_occlusion_extinction_weight) * occlusion_extinction
                    + float(args.target_occlusion_texture_loss_weight) * occlusion_texture
                    + float(args.target_occlusion_gradient_loss_weight) * occlusion_grad
                    + float(args.target_occlusion_quantile_loss_weight) * occlusion_quant
                    + float(args.border_l1_weight) * border_l1
                    + float(args.border_texture_loss_weight) * border_texture
                    + float(args.border_gradient_loss_weight) * border_grad
                    + float(args.border_ssim_loss_weight) * border_ssim
                    + float(args.border_quantile_loss_weight) * border_quant
                    + float(args.target_lock_weight) * target_lock_l1
                    + float(args.target_lock_ssim_weight) * target_lock_ssim
                    + target_extinction_ceiling
                    + target_geometry
                    + rotated_structure
                    + reg
                )
            else:
                loss = (
                    float(args.target_l1_weight) * target_l1
                    + float(args.full_image_l1_weight) * full_l1
                    + float(args.bright_loss_weight) * bright_l1
                    + float(args.quantile_loss_weight) * quant
                    + float(args.texture_loss_weight) * texture
                    + float(args.gradient_loss_weight) * grad
                    + target_speckle
                    + target_extinction_gate
                    + target_extinction_residual
                    + target_extinction_ceiling
                    + target_geometry
                    + rotated_structure
                    + float(args.intensity_mse_weight) * mse
                    + float(args.ssim_loss_weight) * full_ssim
                    + float(args.target_ssim_loss_weight) * target_ssim
                    + float(args.background_l1_weight) * background_l1
                    + float(args.background_texture_loss_weight) * background_texture
                    + float(args.background_gradient_loss_weight) * background_grad
                    + float(args.background_highfreq_loss_weight) * background_highfreq
                    + float(args.background_ssim_loss_weight) * background_ssim
                    + float(args.background_quantile_loss_weight) * background_quant
                    + float(args.target_ring_l1_weight) * ring_l1
                    + float(args.target_ring_texture_loss_weight) * ring_texture
                    + float(args.target_ring_gradient_loss_weight) * ring_grad
                    + float(args.target_ring_highfreq_loss_weight) * ring_highfreq
                    + float(args.target_ring_ssim_loss_weight) * ring_ssim
                    + float(args.target_ring_quantile_loss_weight) * ring_quant
                    + float(args.target_mse_weight) * target_mse
                    + float(args.target_shadow_l1_weight) * shadow_l1
                    + float(args.target_shadow_linear_l1_weight) * shadow_linear_l1
                    + float(args.target_shadow_mse_weight) * shadow_mse
                    + float(args.target_shadow_extinction_weight) * shadow_extinction
                    + float(args.target_shadow_texture_loss_weight) * shadow_texture
                    + float(args.target_shadow_gradient_loss_weight) * shadow_grad
                    + float(args.target_shadow_highfreq_loss_weight) * shadow_highfreq
                    + float(args.target_shadow_ssim_loss_weight) * shadow_ssim
                    + float(args.target_shadow_quantile_loss_weight) * shadow_quant
                    + float(args.target_occlusion_l1_weight) * occlusion_l1
                    + float(args.target_occlusion_linear_l1_weight) * occlusion_linear_l1
                    + float(args.target_occlusion_mse_weight) * occlusion_mse
                    + float(args.target_occlusion_extinction_weight) * occlusion_extinction
                    + float(args.target_occlusion_texture_loss_weight) * occlusion_texture
                    + float(args.target_occlusion_gradient_loss_weight) * occlusion_grad
                    + float(args.target_occlusion_quantile_loss_weight) * occlusion_quant
                    + float(args.border_l1_weight) * border_l1
                    + float(args.border_texture_loss_weight) * border_texture
                    + float(args.border_gradient_loss_weight) * border_grad
                    + float(args.border_ssim_loss_weight) * border_ssim
                    + float(args.border_quantile_loss_weight) * border_quant
                    + reg
                )

            azimuth_consistency = torch.zeros((), device=device, dtype=pred.dtype)
            if azimuth_consistency_pairs and float(getattr(args, "azimuth_consistency_weight", 0.0) or 0.0) > 0.0:
                azimuth_consistency = _azimuth_consistency_loss(
                    model,
                    azimuth_consistency_items,
                    azimuth_consistency_pairs,
                    args,
                    azimuth_consistency_quantiles,
                )
                loss = loss + float(args.azimuth_consistency_weight) * azimuth_consistency

            patchgan_d_loss = torch.zeros((), device=device, dtype=pred.dtype)
            patchgan_g_loss = torch.zeros((), device=device, dtype=pred.dtype)
            if patch_d is not None and opt_d is not None and scaler_d is not None:
                bg_adv_weight = float(getattr(args, "background_patchgan_weight", 0.0) or 0.0)
                ring_adv_weight = float(getattr(args, "target_ring_patchgan_weight", 0.0) or 0.0)
                shadow_adv_weight = float(getattr(args, "target_shadow_patchgan_weight", 0.0) or 0.0)
                min_cov = float(getattr(args, "patchgan_min_region_coverage", 0.10) or 0.0)

                for p in patch_d.parameters():
                    p.requires_grad_(True)
                patch_d.train()
                opt_d.zero_grad(set_to_none=True)
                real_in = _patchgan_input(gt_b.detach(), hard_b, ring_area, background_area)
                fake_in = _patchgan_input(pred.detach(), hard_b, ring_area, background_area)
                real_logits = patch_d(real_in)
                fake_logits = patch_d(fake_in)
                bg_patch_mask = _patchgan_mask(background_area, real_logits, min_cov)
                ring_patch_mask = _patchgan_mask(ring_area, real_logits, min_cov)
                norm = max(bg_adv_weight + ring_adv_weight + shadow_adv_weight, 1e-6)
                if bg_adv_weight > 0.0:
                    d_bg = 0.5 * (
                        _masked_lsgan_loss(real_logits, 1.0, bg_patch_mask)
                        + _masked_lsgan_loss(fake_logits, 0.0, bg_patch_mask)
                    )
                    patchgan_d_loss = patchgan_d_loss + (bg_adv_weight / norm) * d_bg
                if ring_adv_weight > 0.0:
                    d_ring = 0.5 * (
                        _masked_lsgan_loss(real_logits, 1.0, ring_patch_mask)
                        + _masked_lsgan_loss(fake_logits, 0.0, ring_patch_mask)
                    )
                    patchgan_d_loss = patchgan_d_loss + (ring_adv_weight / norm) * d_ring
                if shadow_adv_weight > 0.0:
                    real_shadow_in = _patchgan_input(gt_b.detach(), hard_b, shadow_area, background_area)
                    fake_shadow_in = _patchgan_input(pred.detach(), hard_b, shadow_area, background_area)
                    real_shadow_logits = patch_d(real_shadow_in)
                    fake_shadow_logits = patch_d(fake_shadow_in)
                    shadow_patch_mask = _patchgan_mask(shadow_area, real_shadow_logits, min_cov)
                    d_shadow = 0.5 * (
                        _masked_lsgan_loss(real_shadow_logits, 1.0, shadow_patch_mask)
                        + _masked_lsgan_loss(fake_shadow_logits, 0.0, shadow_patch_mask)
                    )
                    patchgan_d_loss = patchgan_d_loss + (shadow_adv_weight / norm) * d_shadow
                scaler_d.scale(patchgan_d_loss).backward()
                scaler_d.step(opt_d)
                scaler_d.update()

                for p in patch_d.parameters():
                    p.requires_grad_(False)
                patch_d.eval()
                fake_g_in = _patchgan_input(pred, hard_b, ring_area, background_area)
                fake_g_logits = patch_d(fake_g_in)
                if bg_adv_weight > 0.0:
                    bg_g_mask = _patchgan_mask(background_area, fake_g_logits, min_cov)
                    patchgan_g_loss = patchgan_g_loss + bg_adv_weight * _masked_lsgan_loss(
                        fake_g_logits,
                        1.0,
                        bg_g_mask,
                    )
                if ring_adv_weight > 0.0:
                    ring_g_mask = _patchgan_mask(ring_area, fake_g_logits, min_cov)
                    patchgan_g_loss = patchgan_g_loss + ring_adv_weight * _masked_lsgan_loss(
                        fake_g_logits,
                        1.0,
                        ring_g_mask,
                    )
                if shadow_adv_weight > 0.0:
                    fake_shadow_g_in = _patchgan_input(pred, hard_b, shadow_area, background_area)
                    fake_shadow_g_logits = patch_d(fake_shadow_g_in)
                    shadow_g_mask = _patchgan_mask(shadow_area, fake_shadow_g_logits, min_cov)
                    patchgan_g_loss = patchgan_g_loss + shadow_adv_weight * _masked_lsgan_loss(
                        fake_shadow_g_logits,
                        1.0,
                        shadow_g_mask,
                    )
                loss = loss + patchgan_g_loss
                patch_d.train()
                for p in patch_d.parameters():
                    p.requires_grad_(True)

        if not bool(torch.isfinite(loss).detach().cpu()):
            opt.zero_grad(set_to_none=True)
            if progress_metrics != "none" and it % progress_interval == 0:
                pbar.set_postfix(loss="nonfinite_skip")
            continue

        scaler.scale(loss).backward()
        if bool(args.amp) and device.type == "cuda":
            scaler.unscale_(opt)
        max_grad_norm = float(getattr(args, "max_grad_norm", 0.0) or 0.0)
        if max_grad_norm > 0.0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
        if _grad_has_nonfinite(model):
            opt.zero_grad(set_to_none=True)
            scaler.update()
            if progress_metrics != "none" and it % progress_interval == 0:
                pbar.set_postfix(loss="bad_grad_skip")
            continue
        scaler.step(opt)
        scaler.update()
        if _model_has_nonfinite(model):
            raise RuntimeError(
                "Non-finite model weights detected after optimizer step; "
                "reduce --base_lr or extinction/occlusion weights and restart from a clean checkpoint."
            )

        lv = float(loss.detach().item())
        ema = lv if ema is None else 0.9 * ema + 0.1 * lv
        if progress_metrics != "none" and it % progress_interval == 0:
            compact_postfix = {
                "loss": f"{ema:.5f}",
                "l1": f"{float(target_l1.detach()):.5f}",
                "ssim": f"{float(full_ssim.detach()):.4f}",
                "ext": f"{float(target_extinction_gate.detach()):.4f}",
                "edge": f"{float(border_l1.detach()):.4f}",
                "spk": f"{float(target_speckle.detach()):.4f}",
            }
            if progress_metrics == "compact":
                pbar.set_postfix(compact_postfix)
            else:
                pbar.set_postfix(
                    loss=f"{ema:.5f}",
                    l1=f"{float(target_l1.detach()):.5f}",
                    tmse=f"{float(target_mse.detach()):.5f}",
                    ssim=f"{float(full_ssim.detach()):.4f}",
                    bg=f"{float(background_l1.detach()):.5f}",
                    bhf=f"{float(background_highfreq.detach()):.5f}",
                    ring=f"{float(ring_l1.detach()):.5f}",
                    rhf=f"{float(ring_highfreq.detach()):.5f}",
                    sh=f"{float(shadow_l1.detach()):.5f}",
                    shex=f"{float(shadow_extinction.detach()):.5f}",
                    shhf=f"{float(shadow_highfreq.detach()):.5f}",
                    occ=f"{float(occlusion_extinction.detach()):.5f}",
                    ext=f"{float(target_extinction_gate.detach()):.5f}",
                    exr=f"{float(target_extinction_residual.detach()):.5f}",
                    exc=f"{float(target_extinction_ceiling.detach()):.5f}",
                    geo=f"{float(target_geometry.detach()):.5f}",
                    rsp=f"{float(rotated_structure.detach()):.5f}",
                    pd=f"{float(patchgan_d_loss.detach()):.5f}",
                    pg=f"{float(patchgan_g_loss.detach()):.5f}",
                    edge=f"{float(border_l1.detach()):.5f}",
                    lock=f"{float(target_lock_l1.detach()):.5f}",
                    tex=f"{float(texture.detach()):.5f}",
                    grad=f"{float(grad.detach()):.5f}",
                    spk=f"{float(target_speckle.detach()):.5f}",
                    azc=f"{float(azimuth_consistency.detach()):.5f}",
                )

    if _model_has_nonfinite(model):
        raise RuntimeError("Refusing to save checkpoint because model weights contain NaN/Inf.")

    ckpt = {
        "model": model.state_dict(),
        "args": vars(args),
        "in_ch": in_ch,
        "out_ch": out_ch,
        "refiner_mode": _refiner_mode(args),
        "train_pairs": [name for *_rest, name in loaded],
    }
    if patch_d is not None:
        ckpt["patch_discriminator"] = patch_d.state_dict()
    Path(args.checkpoint).parent.mkdir(parents=True, exist_ok=True)
    torch.save(ckpt, args.checkpoint)
    print(f"[target modulation] saved checkpoint: {args.checkpoint}")
    model.eval()
    return model


def _load_model(args, device: torch.device) -> TargetModulationUNet:
    ckpt = torch.load(args.checkpoint, map_location=device)
    ckpt_args = ckpt.get("args", {})
    if "refiner_mode" in ckpt:
        args.refiner_mode = str(ckpt["refiner_mode"])
    elif "refiner_mode" in ckpt_args:
        args.refiner_mode = str(ckpt_args["refiner_mode"])
    else:
        # Backward compatibility: old target checkpoints always emitted three
        # modulation maps, not full-image predictions.
        args.refiner_mode = "target_modulation"
    if "model_base" in ckpt_args and not getattr(args, "_model_base_explicit", False):
        args.model_base = int(ckpt_args["model_base"])
    if "noise_channels" in ckpt_args and not getattr(args, "_noise_channels_explicit", False):
        args.noise_channels = int(ckpt_args["noise_channels"])
    in_ch = int(ckpt.get("in_ch", _model_input_channels(args)))
    out_ch = _checkpoint_output_channels(ckpt, _default_output_channels(args))
    model = TargetModulationUNet(
        in_ch=in_ch,
        base=int(args.model_base),
        padding_mode=str(getattr(args, "conv_padding_mode", "zeros")),
        out_ch=out_ch,
    ).to(device)
    _load_state_dict_compatible(model, ckpt["model"], "checkpoint")
    if _model_has_nonfinite(model):
        raise RuntimeError(
            f"Checkpoint contains NaN/Inf weights and cannot be used safely: {args.checkpoint}. "
            "Retrain from a clean run directory."
        )
    model.eval()
    print(f"[target modulation] loaded checkpoint: {args.checkpoint} (mode={_refiner_mode(args)})")
    return model


def _load_aux_model(checkpoint_path: str, args, device: torch.device, label: str) -> TargetModulationUNet:
    ckpt = torch.load(checkpoint_path, map_location=device)
    ckpt_args = ckpt.get("args", {})
    in_ch = int(ckpt.get("in_ch", _model_input_channels(args)))
    base = int(ckpt_args.get("model_base", getattr(args, "model_base", 32)))
    out_ch = _checkpoint_output_channels(ckpt, _default_output_channels(args))
    model = TargetModulationUNet(
        in_ch=in_ch,
        base=base,
        padding_mode=str(getattr(args, "conv_padding_mode", "zeros")),
        out_ch=out_ch,
    ).to(device)
    _load_state_dict_compatible(model, ckpt["model"], label)
    model.eval()
    print(f"[target modulation] loaded {label}: {checkpoint_path}")
    return model


def _run_model_on_target(
    model: TargetModulationUNet,
    target: torch.Tensor,
    azimuth_deg: float,
    args,
) -> tuple[torch.Tensor, torch.Tensor, dict[str, torch.Tensor]]:
    pad = int(getattr(args, "inference_pad", 0) or 0)
    if pad <= 0 or _is_modulation_mode(args):
        x, hard, preserve = _build_input(target, azimuth_deg, args, training=False)
        raw = model(x[None])
        pred, maps = _compose_refiner_output(raw, target, hard, preserve, args)
        pred = _force_grayscale_batch(pred[None], args)[0]
        return pred, hard, maps

    h, w = target.shape[-2:]
    max_pad = max(0, min(h, w) // 2 - 1)
    pad = min(pad, max_pad)
    if pad <= 0:
        x, hard, preserve = _build_input(target, azimuth_deg, args, training=False)
        raw = model(x[None])
        pred, maps = _compose_refiner_output(raw, target, hard, preserve, args)
        pred = _force_grayscale_batch(pred[None], args)[0]
        return pred, hard, maps

    target_pad = F.pad(target[None], (pad, pad, pad, pad), mode="reflect")[0]
    x_pad, hard_pad, preserve_pad = _build_input(target_pad, azimuth_deg, args, training=False)
    raw_pad = model(x_pad[None])
    pred_pad, maps_pad = _compose_refiner_output(raw_pad, target_pad, hard_pad, preserve_pad, args)
    pred_pad = _force_grayscale_batch(pred_pad[None], args)[0]
    pred = pred_pad[:, pad : pad + h, pad : pad + w].contiguous()
    hard = hard_pad[pad : pad + h, pad : pad + w].contiguous()
    maps = {
        k: v[..., pad : pad + h, pad : pad + w].contiguous()
        for k, v in maps_pad.items()
        if isinstance(v, torch.Tensor) and v.dim() >= 2
    }
    return pred, hard, maps


def _apply(args, model: TargetModulationUNet, device: torch.device) -> None:
    target_dir = Path(args.apply_target_dir)
    out_root = Path(args.output_dir)
    renders_dir = out_root / "renders"
    target_dir_out = out_root / "target_modulated_renders"
    maps_dir = out_root / "maps"
    renders_dir.mkdir(parents=True, exist_ok=True)
    target_dir_out.mkdir(parents=True, exist_ok=True)
    if bool(args.save_maps):
        maps_dir.mkdir(parents=True, exist_ok=True)

    base_dir = Path(args.base_render_dir) if args.base_render_dir else None
    files = _image_files(target_dir)
    if not files:
        raise RuntimeError(f"No target renders found: {target_dir}")
    style_refs = _load_style_refs(args, device)
    need_style_refs = float(getattr(args, "empirical_background_strength", 0.0) or 0.0) > 0.0
    if need_style_refs:
        if style_refs:
            print(
                f"[target modulation] background refs: {len(style_refs)} from "
                f"{getattr(args, 'background_reference_dir', None) or getattr(args, 'train_gt_dir', None)}"
            )
        else:
            print("[target modulation] warning: background refs requested but no reference images were found")
    shadow_model = None
    shadow_source = str(getattr(args, "shadow_restore_source", "checkpoint") or "checkpoint").lower().strip()
    if getattr(args, "shadow_restore_checkpoint", None) and shadow_source == "checkpoint":
        shadow_model = _load_aux_model(args.shadow_restore_checkpoint, args, device, "shadow restore checkpoint")

    with torch.inference_mode():
        for path in tqdm(files, desc="apply target modulation", unit="img"):
            target = _load_image(path, args).to(device)
            az = _parse_azimuth(path)
            mod_target, hard, maps = _run_model_on_target(model, target, az, args)
            style_item = _nearest_style_ref(style_refs, az)
            shadow_ref = None
            if shadow_source == "mod_target":
                shadow_ref = mod_target
            elif shadow_source in {"reference", "style_ref", "background"} and style_item is not None:
                shadow_ref = style_item[1]
            elif shadow_model is not None:
                shadow_ref, _shadow_hard, _shadow_maps = _run_model_on_target(shadow_model, target, az, args)

            if _is_modulation_mode(args) and base_dir is not None and (base_dir / path.name).is_file():
                base = _resize_chw(_load_image(base_dir / path.name, args).to(device), tuple(target.shape[-2:]))
                blend = (maps["alpha"] * float(args.compose_strength)).clamp(0.0, 1.0)
                pred = (base * (1.0 - blend) + mod_target * blend).clamp(0.0, 1.0)
            else:
                pred = mod_target
            layer_alpha = None
            compose_order = str(getattr(args, "compose_order", "refiner_then_background") or "refiner_then_background").lower().strip()
            if compose_order == "background_then_target_shadow":
                pred, layer_alpha = _compose_background_then_target(
                    mod_target,
                    hard,
                    style_item[1] if style_item is not None else None,
                    az,
                    args,
                    maps.get("preserve") if isinstance(maps.get("preserve"), torch.Tensor) else None,
                )
            else:
                pred = _apply_empirical_background(
                    pred,
                    hard,
                    style_item[1] if style_item is not None else None,
                    az,
                    args,
                )
            pred = _repair_background_border(pred, hard, az, args)
            pred, shadow_mask = _restore_reference_shadow(pred, shadow_ref, hard, args)

            torchvision.utils.save_image(pred, str(renders_dir / path.name))
            torchvision.utils.save_image(mod_target, str(target_dir_out / path.name))
            if bool(args.save_maps):
                empirical_bg = None
                if style_item is not None and float(getattr(args, "empirical_background_strength", 0.0) or 0.0) > 0.0:
                    empirical_bg = _make_empirical_background(mod_target, hard, style_item[1], az, args)
                stem = path.stem
                for map_name, map_value in maps.items():
                    torchvision.utils.save_image(map_value.clamp(0.0, 1.0), str(maps_dir / f"{stem}_{map_name}.png"))
                if empirical_bg is not None:
                    torchvision.utils.save_image(empirical_bg.clamp(0.0, 1.0), str(maps_dir / f"{stem}_empirical_background.png"))
                if layer_alpha is not None:
                    torchvision.utils.save_image(layer_alpha[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_layer_target_alpha.png"))
                if shadow_mask is not None:
                    torchvision.utils.save_image(shadow_mask[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_shadow_restore_mask.png"))
    print(f"[target modulation] done: {renders_dir}")


def _postprocess_after_apply(args) -> None:
    from scripts.rendering.postprocess_sar_target_shadow import _image_files as _post_image_files
    from scripts.rendering.postprocess_sar_target_shadow import process_one as _post_process_one

    out_root = Path(args.output_dir)
    render_dir = Path(args.postprocess_render_dir) if args.postprocess_render_dir else out_root / "renders"
    target_source_dir = (
        Path(args.postprocess_target_source_dir)
        if args.postprocess_target_source_dir
        else out_root / "target_modulated_renders"
    )
    shadow_source_dir = (
        Path(args.postprocess_shadow_source_dir)
        if args.postprocess_shadow_source_dir
        else out_root / "target_modulated_renders"
    )
    target_mask_dir = (
        Path(args.postprocess_target_mask_dir)
        if args.postprocess_target_mask_dir
        else Path(args.apply_target_dir)
    )
    post_output_dir = (
        Path(args.postprocess_output_dir)
        if args.postprocess_output_dir
        else out_root.parent / f"{out_root.name}_post" / "renders"
    )

    post_args = Namespace(
        render_dir=render_dir,
        output_dir=post_output_dir,
        target_mask_dir=target_mask_dir,
        target_source_dir=target_source_dir,
        shadow_source_dir=shadow_source_dir,
        target_mask_threshold=args.postprocess_target_mask_threshold,
        target_mask_quantile=args.postprocess_target_mask_quantile,
        target_mask_dilate=args.postprocess_target_mask_dilate,
        target_strength=args.postprocess_target_strength,
        target_alpha_dilate=args.postprocess_target_alpha_dilate,
        target_alpha_blur=args.postprocess_target_alpha_blur,
        target_alpha_gamma=args.postprocess_target_alpha_gamma,
        shadow_strength=args.postprocess_shadow_strength,
        shadow_mode=args.postprocess_shadow_mode,
        shadow_search_dilate=args.postprocess_shadow_search_dilate,
        shadow_target_exclude_dilate=args.postprocess_shadow_target_exclude_dilate,
        shadow_dark_threshold=args.postprocess_shadow_dark_threshold,
        shadow_ratio_threshold=args.postprocess_shadow_ratio_threshold,
        shadow_context_blur=args.postprocess_shadow_context_blur,
        shadow_soft_blur=args.postprocess_shadow_soft_blur,
        shadow_gamma=args.postprocess_shadow_gamma,
        shadow_min_attenuation=args.postprocess_shadow_min_attenuation,
        shadow_attenuation_power=args.postprocess_shadow_attenuation_power,
        shadow_floor=args.postprocess_shadow_floor,
        save_maps=args.postprocess_save_maps,
    )

    if not post_args.render_dir.is_dir():
        raise RuntimeError(f"--postprocess_after_apply render_dir not found: {post_args.render_dir}")
    if not post_args.target_mask_dir.is_dir():
        raise RuntimeError(f"--postprocess_after_apply target_mask_dir not found: {post_args.target_mask_dir}")
    if post_args.target_source_dir is not None and not post_args.target_source_dir.is_dir():
        raise RuntimeError(f"--postprocess_after_apply target_source_dir not found: {post_args.target_source_dir}")
    if post_args.shadow_source_dir is not None and not post_args.shadow_source_dir.is_dir():
        raise RuntimeError(f"--postprocess_after_apply shadow_source_dir not found: {post_args.shadow_source_dir}")

    post_args.output_dir.mkdir(parents=True, exist_ok=True)
    files = _post_image_files(post_args.render_dir)
    if not files:
        raise RuntimeError(f"--postprocess_after_apply no images found in render_dir: {post_args.render_dir}")

    ok = 0
    for path in tqdm(files, desc="postprocess target/shadow", unit="img"):
        ok += int(_post_process_one(path, post_args))
    print(f"[target modulation] postprocess saved {ok}/{len(files)} images to {post_args.output_dir}")


def _cli_has_option(name: str) -> bool:
    flag = "--" + name
    no_flag = "--no-" + name
    return any(
        a == flag
        or str(a).startswith(flag + "=")
        or a == no_flag
        or str(a).startswith(no_flag + "=")
        for a in sys.argv[1:]
    )


def _cli_has_any_option(*names: str) -> bool:
    return any(_cli_has_option(name) for name in names)


def _set_default_if_implicit(args, name: str, value) -> None:
    if not _cli_has_option(name):
        setattr(args, name, value)


def _apply_target_sarsim_finetune_defaults(args) -> None:
    """Use target SAR-SSIM fine-tune defaults when continuing from a checkpoint."""
    if bool(getattr(args, "apply_only", False)):
        return
    if not bool(getattr(args, "init_checkpoint", None)):
        return
    if bool(getattr(args, "background_finetune", False)):
        return

    defaults = {
        "iterations": 2000,
        "batch_size": 4,
        "lr": 8e-6,
        "conv_padding_mode": "reflect",
        "deterministic_train_noise": True,
        "intensity_loss_domain": "log",
        "loss_mask_dilate": 0,
        "full_image_l1_weight": 0.0,
        "background_l1_weight": 0.0,
        "background_texture_loss_weight": 0.0,
        "background_gradient_loss_weight": 0.0,
        "background_highfreq_loss_weight": 0.0,
        "background_quantile_loss_weight": 0.0,
        "background_ssim_loss_weight": 0.0,
        "border_l1_weight": 0.0,
        "border_texture_loss_weight": 0.0,
        "border_gradient_loss_weight": 0.0,
        "border_ssim_loss_weight": 0.0,
        "target_ring_width": 0,
        "target_mse_weight": 1.0,
        "target_ssim_loss_weight": 1.2,
        "intensity_mse_weight": 0.4,
        "texture_loss_weight": 0.4,
        "gradient_loss_weight": 0.3,
        "ssim_loss_weight": 0.6,
    }
    for name, value in defaults.items():
        _set_default_if_implicit(args, name, value)
    print("[target modulation] using target_sarsim fine-tune defaults")


def _apply_target_only_refiner_defaults(args) -> None:
    if not _target_only_refiner(args):
        return
    _set_default_if_implicit(args, "mask_dilate", 1)
    _set_default_if_implicit(args, "loss_mask_dilate", 0)
    _set_default_if_implicit(args, "target_loss_mask_dilate", 1)
    _set_default_if_implicit(args, "target_compose_mask_dilate", 0)
    defaults = {
        "full_image_l1_weight": 0.0,
        "ssim_loss_weight": 0.0,
        "background_l1_weight": 0.0,
        "background_texture_loss_weight": 0.0,
        "background_gradient_loss_weight": 0.0,
        "background_highfreq_loss_weight": 0.0,
        "background_quantile_loss_weight": 0.0,
        "background_ssim_loss_weight": 0.0,
        "border_l1_weight": 0.0,
        "border_texture_loss_weight": 0.0,
        "border_gradient_loss_weight": 0.0,
        "border_ssim_loss_weight": 0.0,
        "border_quantile_loss_weight": 0.0,
        "target_ring_width": 0,
        "target_ring_l1_weight": 0.0,
        "target_ring_texture_loss_weight": 0.0,
        "target_ring_gradient_loss_weight": 0.0,
        "target_ring_highfreq_loss_weight": 0.0,
        "target_ring_ssim_loss_weight": 0.0,
        "target_ring_quantile_loss_weight": 0.0,
        "target_ring_patchgan_weight": 0.0,
        "background_patchgan_weight": 0.0,
        "azimuth_consistency_weight": 0.0,
        "empirical_background_strength": 0.0,
        "shadow_restore_strength": 0.0,
        "border_repair_strength": 0.0,
    }
    for name, value in defaults.items():
        if name in {"empirical_background_strength", "shadow_restore_strength", "border_repair_strength"}:
            _set_default_if_implicit(args, name, value)
        else:
            setattr(args, name, value)

    shadow_loss_flags = (
        "target_shadow_l1_weight",
        "target_shadow_linear_l1_weight",
        "target_shadow_mse_weight",
        "target_shadow_extinction_weight",
        "target_shadow_texture_loss_weight",
        "target_shadow_gradient_loss_weight",
        "target_shadow_highfreq_loss_weight",
        "target_shadow_ssim_loss_weight",
        "target_shadow_quantile_loss_weight",
        "target_shadow_patchgan_weight",
    )
    if _cli_has_any_option(*shadow_loss_flags):
        _set_default_if_implicit(args, "target_shadow_width", 18)
    else:
        args.target_shadow_width = 0
        for name in shadow_loss_flags:
            setattr(args, name, 0.0)

    occlusion_loss_flags = (
        "target_occlusion_l1_weight",
        "target_occlusion_linear_l1_weight",
        "target_occlusion_mse_weight",
        "target_occlusion_extinction_weight",
        "target_occlusion_texture_loss_weight",
        "target_occlusion_gradient_loss_weight",
        "target_occlusion_quantile_loss_weight",
    )
    if not _cli_has_any_option(*occlusion_loss_flags):
        for name in occlusion_loss_flags:
            setattr(args, name, 0.0)

    # The target-only path is intended to learn target layover/extinction.
    # Preserve, empirical shadow restore, and post-apply shadow painting are
    # compatibility tools and should be explicitly enabled when needed.
    _set_default_if_implicit(args, "target_preserve_strength", 0.0)
    _set_default_if_implicit(args, "layer_target_use_preserve", False)
    _set_default_if_implicit(args, "postprocess_after_apply", False)

    print(
        "[target modulation] target-only refiner enabled: "
        "background/ring/patchgan losses disabled; shadow/occlusion losses are opt-in"
    )


def _normalize_target_layover_mode(args) -> None:
    if not _is_target_layover_mode(args):
        return
    args.refiner_mode = "target_layover"
    args.target_only_refiner = True


def _apply_target_layover_refiner_defaults(args) -> None:
    if not _is_target_layover_mode(args):
        return

    defaults = {
        # Target-layover is a local modulation model, not an image/background refiner.
        "target_only_refiner": True,
        "target_preserve_strength": 0.0,
        "layer_target_use_preserve": False,
        "postprocess_after_apply": False,
        "shadow_restore_strength": 0.0,
        "empirical_background_strength": 0.0,
        "border_repair_strength": 0.0,
        "compose_order": "refiner_then_background",
        "target_compose_mask_dilate": 0,
        "target_loss_mask_dilate": 1,
        "loss_mask_dilate": 0,
        "mask_dilate": 1,
        # Adjacent real SAR views supervise the in-between azimuth continuously.
        "train_gt_neighbor_mode": "linear",
        "train_gt_neighbor_angle_source": "target",
        "train_gt_neighbor_supervision": "mix",
        "train_gt_neighbor_mix_domain": "log",
        # Keep modulation bounded so the model cannot solve the task by global dimming.
        "multiplier_min": 0.55,
        "multiplier_max": 1.20,
        "visibility_min": 0.28,
        "visibility_max": 1.0,
        "dark_patch_strength": 0.40,
        "dark_patch_floor": 0.0,
        "target_extinction_strength": 0.60,
        "target_extinction_floor": 0.0,
        "target_extinction_apply_gamma": 0.85,
        "target_extinction_apply_mode": "power",
        "target_extinction_apply_threshold": 0.0,
        "target_extinction_apply_softness": 0.08,
        "target_extinction_apply_sigmoid_mix": 0.35,
        "layover_spatial_only": True,
        "layover_spatial_baseline": "masked_mean",
        "layover_spatial_gain": 4.0,
        "layover_spatial_bias": 0.0,
        "layover_spatial_blur_radius": 9,
        "dark_patch_spatial_floor": 0.0,
        "target_extinction_spatial_floor": 0.0,
        # Supervise layover/occlusion without letting a hard gate erase the target.
        "target_extinction_gate_loss_weight": 0.22,
        "target_extinction_dice_loss_weight": 0.14,
        "target_extinction_focal_loss_weight": 0.08,
        "target_extinction_residual_loss_weight": 0.08,
        "target_extinction_ceiling_loss_weight": 0.0,
        "target_extinction_positive_gain": 2.0,
        "target_extinction_sparsity_weight": 0.008,
        "target_extinction_neighbor_reduce": "weighted_max",
        "target_extinction_render_gate_floor": 0.32,
        "target_occlusion_l1_weight": 0.05,
        "target_occlusion_extinction_weight": 0.08,
        "target_occlusion_texture_loss_weight": 0.02,
        "target_occlusion_gradient_loss_weight": 0.02,
        "target_speckle_loss_weight": 0.10,
        "target_speckle_std_quantile_weight": 0.9,
        "target_speckle_highfreq_quantile_weight": 0.7,
        "target_speckle_intensity_quantile_weight": 0.45,
        "target_speckle_dark_ratio_weight": 0.30,
        # Let bright scatterers move statistically, but do not reward exact bright hallucinations.
        "bright_loss_weight": 0.30,
        "bright_loss_gain": 5.0,
        "target_l1_weight": 0.55,
        "target_ssim_loss_weight": 0.18,
        "intensity_mse_weight": 0.10,
        "quantile_loss_weight": 0.12,
        "texture_loss_weight": 1.25,
        "gradient_loss_weight": 0.35,
        "ssim_loss_weight": 0.0,
        "full_image_l1_weight": 0.0,
        "background_patchgan_weight": 0.0,
        "target_ring_width": 0,
        "target_shadow_width": 0,
        "rotated_structure_prior_weight": 0.0,
        "target_geometry_loss_weight": 0.03,
        "multiplier_identity_weight": 0.020,
        "visibility_identity_weight": 0.012,
        "dark_patch_sparsity_weight": 0.010,
    }
    for name, value in defaults.items():
        _set_default_if_implicit(args, name, value)

    print(
        "[target modulation] target_layover mode: adjacent-GT log mixing, spatial layover gates, "
        "preserve/postprocess/shadow-restore disabled"
    )


def _apply_refiner_ablation_defaults(args) -> None:
    mode = str(getattr(args, "refiner_ablation", "none") or "none").lower().strip()
    if mode in {"", "none"}:
        return

    args.target_only_refiner = True
    args.background_finetune = False
    args.empirical_background_strength = 0.0
    args.shadow_restore_strength = 0.0
    args.postprocess_after_apply = False

    if mode == "no_spatial_gate":
        args.layover_spatial_only = False
        args.dark_patch_spatial_floor = 0.0
        args.target_extinction_spatial_floor = 0.0
        print("[refiner ablation] no_spatial_gate: disabled spatial-only dark/extinction gate.")
        return

    if mode == "wide_maps":
        args.multiplier_min = 0.35
        args.multiplier_max = 1.85
        args.visibility_min = 0.12
        args.visibility_max = 1.0
        args.dark_patch_strength = 0.85
        args.target_extinction_strength = 1.0
        print("[refiner ablation] wide_maps: restored v11-style modulation ranges.")
        return

    if mode == "no_extinction_losses":
        for name in (
            "target_extinction_gate_loss_weight",
            "target_extinction_dice_loss_weight",
            "target_extinction_focal_loss_weight",
            "target_extinction_residual_loss_weight",
            "target_extinction_ceiling_loss_weight",
            "target_occlusion_extinction_weight",
        ):
            setattr(args, name, 0.0)
        print("[refiner ablation] no_extinction_losses: disabled explicit extinction/occlusion gate losses.")
        return

    if mode == "nearest_gt":
        args.train_gt_neighbor_mode = "nearest"
        args.train_gt_neighbor_supervision = "sample"
        args.train_gt_neighbor_mix_domain = "pixel"
        args.target_extinction_neighbor_reduce = "max"
        print("[refiner ablation] nearest_gt: using old nearest/sample GT supervision.")
        return

    if mode == "old_structure_stat":
        args.refiner_mode = "target_modulation"
        args.layover_spatial_only = False
        args.multiplier_min = 0.35
        args.multiplier_max = 1.85
        args.visibility_min = 0.12
        args.visibility_max = 1.0
        args.dark_patch_strength = 0.85
        args.dark_patch_floor = 0.02
        args.dark_patch_sparsity_weight = 0.006
        args.target_extinction_strength = 1.0
        args.target_extinction_apply_gamma = 0.70
        args.target_extinction_gate_loss_weight = 0.80
        args.target_extinction_dice_loss_weight = 0.55
        args.target_extinction_focal_loss_weight = 0.30
        args.target_extinction_residual_loss_weight = 0.45
        args.target_extinction_ceiling_loss_weight = 0.0
        args.target_extinction_positive_gain = 3.0
        args.target_extinction_sparsity_weight = 0.001
        args.target_extinction_neighbor_reduce = "max"
        args.target_extinction_render_gate_floor = 0.30
        args.target_extinction_dark_threshold = 0.17
        args.target_extinction_ratio_threshold = 0.10
        args.target_l1_weight = 0.35
        args.target_ssim_loss_weight = 0.24
        args.bright_loss_weight = 0.42
        args.bright_loss_gain = 7.0
        args.quantile_loss_weight = 0.45
        args.texture_loss_weight = 1.65
        args.gradient_loss_weight = 0.45
        args.target_speckle_loss_weight = 0.22
        args.target_speckle_std_quantile_weight = 1.0
        args.target_speckle_highfreq_quantile_weight = 0.8
        args.target_speckle_intensity_quantile_weight = 0.55
        args.target_speckle_dark_ratio_weight = 0.65
        args.target_speckle_dark_threshold = 0.22
        args.target_speckle_dark_softness = 0.03
        args.target_geometry_loss_weight = 0.0
        args.rotated_structure_prior_weight = 0.0
        for name in (
            "target_occlusion_l1_weight",
            "target_occlusion_linear_l1_weight",
            "target_occlusion_mse_weight",
            "target_occlusion_extinction_weight",
            "target_occlusion_texture_loss_weight",
            "target_occlusion_gradient_loss_weight",
            "target_occlusion_quantile_loss_weight",
        ):
            setattr(args, name, 0.0)
        print("[refiner ablation] old_structure_stat: using v11-style target_modulation structure/stat settings.")
        return

    raise ValueError(f"Unknown --refiner_ablation: {mode}")


def main() -> None:
    parser = ArgumentParser(description="Learn target residual / texture modulation for SAR-like target renders")
    parser.add_argument("-m", "--model_path", type=str, default=None)
    parser.add_argument("--train_target_dir", type=str, default=None)
    parser.add_argument("--train_gt_dir", type=str, default=None)
    parser.add_argument("--apply_target_dir", type=str, default=None)
    parser.add_argument("--base_render_dir", type=str, default=None)
    parser.add_argument("--output_dir", type=str, default=None)
    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--init_checkpoint", type=str, default=None)
    parser.add_argument(
        "--train_azimuth_step",
        type=float,
        default=10.0,
        help="Select training pairs at fixed azimuth slots. Use 10 for 0,10,...,350; use 0 for old exact-name pairing.",
    )
    parser.add_argument("--train_azimuth_start", type=float, default=0.0)
    parser.add_argument("--train_azimuth_end", type=float, default=360.0)
    parser.add_argument(
        "--train_azimuth_unique",
        action=BooleanOptionalAction,
        default=False,
        help="Force each source image to be used at most once when selecting fixed azimuth slots.",
    )
    parser.add_argument(
        "--train_use_all_targets",
        action=BooleanOptionalAction,
        default=False,
        help="Use every image in --train_target_dir as a training target instead of selecting fixed azimuth slots.",
    )
    parser.add_argument(
        "--train_gt_neighbor_mode",
        choices=["nearest", "linear"],
        default="nearest",
        help="nearest uses one GT image; linear blends the two adjacent GT azimuths by angular distance.",
    )
    parser.add_argument(
        "--train_gt_neighbor_angle_source",
        choices=["target", "slot"],
        default="target",
        help="Azimuth used to choose adjacent GTs for --train_gt_neighbor_mode linear.",
    )
    parser.add_argument(
        "--train_gt_neighbor_mix_domain",
        choices=["pixel", "log"],
        default="pixel",
        help="Blend adjacent GT images in pixel intensity or log SAR intensity domain.",
    )
    parser.add_argument(
        "--train_gt_neighbor_supervision",
        choices=["sample", "mix"],
        default="sample",
        help="sample randomly chooses one adjacent GT by angular weight each iteration; mix blends the adjacent GTs.",
    )
    parser.add_argument(
        "--train_azimuth_report",
        type=str,
        default=None,
        help="Optional path for the selected target/GT azimuth-pair report.",
    )
    parser.add_argument(
        "--focus_azimuths",
        type=str,
        default="",
        help="Comma/space separated azimuth slots to oversample during training, e.g. 175,180,340,355.",
    )
    parser.add_argument("--focus_azimuth_repeat", type=int, default=1)
    parser.add_argument("--focus_azimuth_tolerance", type=float, default=2.5)
    parser.add_argument(
        "--refiner_mode",
        choices=[
            "image",
            "residual",
            "target_modulation",
            "target_layover",
            "modulation",
            "target",
            "layover",
            "target-layover",
            "direct",
            "full",
        ],
        default="image",
        help=(
            "image/residual learn the full SAR image; target_modulation predicts target "
            "multiplier/visibility/dark/extinction maps; target_layover is the clean SAR target "
            "layover/occlusion/scatter style mode with spatial dark gates and adjacent-GT supervision."
        ),
    )
    parser.add_argument(
        "--refiner_ablation",
        choices=[
            "none",
            "no_spatial_gate",
            "wide_maps",
            "no_extinction_losses",
            "nearest_gt",
            "old_structure_stat",
        ],
        default="none",
        help="One-change-at-a-time debug preset for refiner regression checks.",
    )
    parser.add_argument("--train_only", action="store_true", default=False)
    parser.add_argument("--apply_only", action="store_true", default=False)
    parser.add_argument(
        "--target_only_refiner",
        action=BooleanOptionalAction,
        default=False,
        help="Train/apply only inside the target mask; keep background and shadow handling out of the refiner.",
    )
    parser.add_argument(
        "--background_finetune",
        action="store_true",
        default=False,
        help="Fine-tune background from --init_checkpoint while locking target appearance to that checkpoint.",
    )
    parser.add_argument("--iterations", type=int, default=5000)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--lr", type=float, default=6e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument(
        "--max_grad_norm",
        type=float,
        default=1.0,
        help="Clip refiner gradients to this norm. Use 0 to disable; enabled by default to avoid NaN checkpoints.",
    )
    parser.add_argument("--model_base", type=int, default=32)
    parser.add_argument("--conv_padding_mode", choices=["zeros", "reflect", "replicate", "circular"], default="reflect")
    parser.add_argument("--amp", action="store_true", default=False)
    parser.add_argument("--allow_tf32", action=BooleanOptionalAction, default=True)
    parser.add_argument("--cudnn_benchmark", action=BooleanOptionalAction, default=True)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument(
        "--progress_metrics",
        choices=["compact", "full", "none"],
        default="compact",
        help="Training progress postfix verbosity. compact keeps tqdm on one terminal line; full shows every loss term.",
    )
    parser.add_argument("--progress_interval", type=int, default=20, help="Iterations between progress metric updates.")
    parser.add_argument(
        "--progress_refresh_seconds",
        type=float,
        default=0.5,
        help="Minimum seconds between tqdm refreshes.",
    )
    parser.add_argument("--grayscale_sar", action=BooleanOptionalAction, default=True)
    parser.add_argument("--force_grayscale_output", action=BooleanOptionalAction, default=True)
    parser.add_argument("--intensity_loss_domain", choices=["log", "linear"], default="log")
    parser.add_argument("--log_intensity_scale", type=float, default=20.0)
    parser.add_argument("--noise_channels", type=int, default=2)
    parser.add_argument("--noise_seed", type=int, default=1234)
    parser.add_argument("--noise_lowfreq_radius", type=int, default=5)
    parser.add_argument(
        "--deterministic_train_noise",
        action="store_true",
        default=False,
        help="Use the same azimuth-seeded noise during training and inference so speckle losses are learnable.",
    )
    parser.add_argument("--mask_threshold", type=float, default=0.08)
    parser.add_argument("--mask_quantile", type=float, default=0.35)
    parser.add_argument("--mask_dilate", type=int, default=1)
    parser.add_argument("--mask_blur_radius", type=int, default=1)
    parser.add_argument("--target_preserve_strength", type=float, default=0.0)
    parser.add_argument("--target_preserve_threshold", type=float, default=0.45)
    parser.add_argument("--target_preserve_blur_radius", type=int, default=1)
    parser.add_argument(
        "--target_preserve_occlusion_cut",
        type=float,
        default=0.85,
        help="How strongly learned dark/extinction maps reduce target-preserve protection in target_modulation mode.",
    )
    parser.add_argument(
        "--compose_order",
        choices=["refiner_then_background", "background_then_target_shadow"],
        default="background_then_target_shadow",
        help="Apply order for inference. background_then_target_shadow builds empirical background first, then overlays target and restores shadow.",
    )
    parser.add_argument("--layer_target_use_preserve", action=BooleanOptionalAction, default=True)
    parser.add_argument("--layer_target_dilate", type=int, default=0)
    parser.add_argument("--layer_target_blur", type=int, default=1)
    parser.add_argument("--layer_target_strength", type=float, default=1.0)

    parser.add_argument("--multiplier_min", type=float, default=0.35)
    parser.add_argument("--multiplier_max", type=float, default=1.85)
    parser.add_argument("--visibility_min", type=float, default=0.12)
    parser.add_argument("--visibility_max", type=float, default=1.0)
    parser.add_argument("--dark_patch_strength", type=float, default=0.85)
    parser.add_argument("--dark_patch_floor", type=float, default=0.02)
    parser.add_argument(
        "--layover_spatial_only",
        action=BooleanOptionalAction,
        default=False,
        help="Use only spatially-local dark/extinction peaks for layover gating, removing uniform dimming bias.",
    )
    parser.add_argument(
        "--layover_spatial_baseline",
        choices=["masked_mean", "blur"],
        default="masked_mean",
        help="Baseline removed from dark/extinction maps when --layover_spatial_only is enabled.",
    )
    parser.add_argument("--layover_spatial_gain", type=float, default=4.0)
    parser.add_argument("--layover_spatial_bias", type=float, default=0.0)
    parser.add_argument("--layover_spatial_blur_radius", type=int, default=9)
    parser.add_argument("--dark_patch_spatial_floor", type=float, default=0.0)
    parser.add_argument("--target_extinction_spatial_floor", type=float, default=0.0)
    parser.add_argument("--compose_strength", type=float, default=0.82)
    parser.add_argument("--residual_scale", type=float, default=0.65)

    parser.add_argument("--target_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--target_alpha_high", type=float, default=0.20)
    parser.add_argument("--target_alpha_gamma", type=float, default=0.80)
    parser.add_argument("--target_alpha_dilate", type=int, default=0)
    parser.add_argument("--target_alpha_blur", type=int, default=0)
    parser.add_argument("--target_alpha_use_mask_floor", action=BooleanOptionalAction, default=False)
    parser.add_argument("--target_alpha_mask_floor", type=float, default=0.25)

    parser.add_argument("--loss_mask_dilate", type=int, default=2)
    parser.add_argument(
        "--target_loss_mask_threshold",
        type=float,
        default=0.08,
        help="Target-loss support threshold in the clean target render; keeps target losses out of background/shadow.",
    )
    parser.add_argument(
        "--target_loss_mask_quantile",
        type=float,
        default=0.0,
        help="Optional nonzero-target quantile threshold for target-loss support. 0 disables quantile tightening.",
    )
    parser.add_argument(
        "--target_loss_mask_dilate",
        type=int,
        default=0,
        help="Dilation for the target-loss support. Keep 0 for target-only training to avoid background leakage.",
    )
    parser.add_argument("--target_loss_mask_min_pixels", type=float, default=16.0)
    parser.add_argument("--target_loss_mask_fallback_to_hard", action=BooleanOptionalAction, default=True)
    parser.add_argument(
        "--target_compose_mask_dilate",
        type=int,
        default=0,
        help="Dilation only for target-only image composition, independent from target losses.",
    )
    parser.add_argument("--full_image_l1_weight", type=float, default=0.55)
    parser.add_argument("--background_loss_exclude_dilate", type=int, default=8)
    parser.add_argument("--background_l1_weight", type=float, default=0.45)
    parser.add_argument("--background_texture_loss_weight", type=float, default=0.45)
    parser.add_argument("--background_gradient_loss_weight", type=float, default=0.20)
    parser.add_argument("--background_highfreq_loss_weight", type=float, default=0.0)
    parser.add_argument("--background_ssim_loss_weight", type=float, default=0.35)
    parser.add_argument("--background_quantile_loss_weight", type=float, default=0.25)
    parser.add_argument("--target_lock_weight", type=float, default=2.0)
    parser.add_argument("--target_lock_ssim_weight", type=float, default=0.8)
    parser.add_argument("--target_lock_dilate", type=int, default=2)
    parser.add_argument("--target_l1_weight", type=float, default=1.0)
    parser.add_argument("--target_extinction_strength", type=float, default=1.0)
    parser.add_argument("--target_extinction_floor", type=float, default=0.0)
    parser.add_argument("--target_extinction_gate_loss_weight", type=float, default=0.65)
    parser.add_argument(
        "--target_extinction_neighbor_reduce",
        choices=["max", "weighted_max", "weighted_mean", "mix"],
        default="max",
        help="How adjacent GT extinction masks are combined. max keeps layover shape sharp instead of averaging it.",
    )
    parser.add_argument("--target_extinction_dice_loss_weight", type=float, default=0.45)
    parser.add_argument("--target_extinction_focal_loss_weight", type=float, default=0.25)
    parser.add_argument("--target_extinction_focal_gamma", type=float, default=2.0)
    parser.add_argument("--target_extinction_render_gate_floor", type=float, default=0.35)
    parser.add_argument("--target_extinction_apply_gamma", type=float, default=0.70)
    parser.add_argument(
        "--target_extinction_apply_mode",
        choices=["power", "sigmoid", "threshold", "power_sigmoid", "sigmoid_power"],
        default="power",
    )
    parser.add_argument("--target_extinction_apply_threshold", type=float, default=0.0)
    parser.add_argument("--target_extinction_apply_softness", type=float, default=0.08)
    parser.add_argument("--target_extinction_apply_sigmoid_mix", type=float, default=0.5)
    parser.add_argument("--target_extinction_residual_loss_weight", type=float, default=0.35)
    parser.add_argument("--target_extinction_residual_power", type=float, default=2.0)
    parser.add_argument("--target_extinction_ceiling_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_extinction_ceiling_max_intensity", type=float, default=0.07)
    parser.add_argument("--target_extinction_ceiling_margin", type=float, default=0.01)
    parser.add_argument("--target_extinction_ceiling_context_ratio", type=float, default=0.40)
    parser.add_argument("--target_extinction_ceiling_context_blur", type=int, default=9)
    parser.add_argument("--target_extinction_ceiling_power", type=float, default=2.0)
    parser.add_argument("--target_extinction_positive_gain", type=float, default=2.0)
    parser.add_argument("--target_extinction_sparsity_weight", type=float, default=0.002)
    parser.add_argument("--target_extinction_target_threshold", type=float, default=0.08)
    parser.add_argument("--target_extinction_target_high", type=float, default=0.28)
    parser.add_argument("--target_extinction_dark_threshold", type=float, default=0.16)
    parser.add_argument("--target_extinction_ratio_threshold", type=float, default=0.12)
    parser.add_argument("--target_extinction_context_blur", type=int, default=9)
    parser.add_argument("--target_extinction_soft_blur", type=int, default=1)
    parser.add_argument("--target_extinction_gamma", type=float, default=1.0)
    parser.add_argument("--target_geometry_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_geometry_min_visible", type=float, default=8.0)
    parser.add_argument("--rotated_structure_prior_weight", type=float, default=0.0)
    parser.add_argument("--rotated_structure_prior_strength", type=float, default=1.0)
    parser.add_argument("--rotated_structure_prior_reduce", choices=["max", "mean", "weighted_max", "weighted_mean"], default="weighted_max")
    parser.add_argument("--rotated_structure_prior_angle_sign", type=float, default=1.0)
    parser.add_argument("--rotated_structure_prior_max_delta", type=float, default=15.0)
    parser.add_argument("--rotated_structure_prior_dilate", type=int, default=0)
    parser.add_argument("--rotated_structure_prior_blur", type=int, default=1)
    parser.add_argument("--rotated_structure_prior_padding_mode", choices=["zeros", "border", "reflection"], default="border")
    parser.add_argument("--rotated_structure_prior_merge_extinction", action=BooleanOptionalAction, default=True)
    parser.add_argument("--rotated_structure_prior_gate_loss_weight", type=float, default=0.45)
    parser.add_argument("--rotated_structure_prior_dice_loss_weight", type=float, default=0.30)
    parser.add_argument("--rotated_structure_prior_positive_gain", type=float, default=2.5)
    parser.add_argument("--rotated_structure_prior_residual_loss_weight", type=float, default=0.35)
    parser.add_argument("--rotated_structure_prior_residual_power", type=float, default=2.0)
    parser.add_argument("--rotated_structure_prior_max_intensity", type=float, default=0.055)
    parser.add_argument("--rotated_structure_prior_margin", type=float, default=0.005)
    parser.add_argument("--rotated_structure_prior_edge_loss_weight", type=float, default=0.18)
    parser.add_argument("--rotated_structure_prior_edge_dilate", type=int, default=2)
    parser.add_argument("--rotated_structure_prior_local_ratio_weight", type=float, default=0.20)
    parser.add_argument("--rotated_structure_prior_local_ratio_pool", type=int, default=9)
    parser.add_argument("--rotated_structure_prior_dark_threshold", type=float, default=0.14)
    parser.add_argument("--rotated_structure_prior_dark_softness", type=float, default=0.035)
    parser.add_argument("--target_mse_weight", type=float, default=0.0)
    parser.add_argument(
        "--azimuth_consistency_weight",
        type=float,
        default=0.0,
        help="Unlabeled adjacent-azimuth regularizer over apply target renders. 0 disables it.",
    )
    parser.add_argument(
        "--azimuth_consistency_max_gap",
        type=float,
        default=12.0,
        help="Only adjacent apply target renders with this azimuth gap or smaller are used.",
    )
    parser.add_argument("--azimuth_consistency_samples", type=int, default=1)
    parser.add_argument("--azimuth_consistency_mask_dilate", type=int, default=0)
    parser.add_argument("--azimuth_consistency_texture_weight", type=float, default=0.25)
    parser.add_argument("--azimuth_consistency_texture_radius", type=int, default=2)
    parser.add_argument("--azimuth_consistency_quantiles", type=str, default="0.25,0.50,0.75,0.90")
    parser.add_argument("--target_ring_width", type=int, default=0)
    parser.add_argument("--target_ring_inner_dilate", type=int, default=1)
    parser.add_argument("--target_ring_l1_weight", type=float, default=0.0)
    parser.add_argument("--target_ring_texture_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_ring_gradient_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_ring_highfreq_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_ring_ssim_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_ring_quantile_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_width", type=int, default=0)
    parser.add_argument("--target_shadow_inner_dilate", type=int, default=1)
    parser.add_argument("--target_shadow_dark_threshold", type=float, default=0.18)
    parser.add_argument("--target_shadow_ratio_threshold", type=float, default=0.18)
    parser.add_argument("--target_shadow_context_blur", type=int, default=17)
    parser.add_argument("--target_shadow_soft_blur", type=int, default=1)
    parser.add_argument("--target_shadow_l1_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_linear_l1_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_mse_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_extinction_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_max_intensity", type=float, default=0.10)
    parser.add_argument("--target_shadow_dark_margin", type=float, default=0.01)
    parser.add_argument("--target_shadow_context_ratio", type=float, default=0.45)
    parser.add_argument("--target_shadow_texture_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_gradient_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_highfreq_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_ssim_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_quantile_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_l1_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_linear_l1_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_mse_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_extinction_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_texture_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_gradient_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_quantile_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_occlusion_target_threshold", type=float, default=0.08)
    parser.add_argument("--target_occlusion_target_high", type=float, default=0.28)
    parser.add_argument("--target_occlusion_dark_threshold", type=float, default=0.16)
    parser.add_argument("--target_occlusion_ratio_threshold", type=float, default=0.12)
    parser.add_argument("--target_occlusion_context_blur", type=int, default=9)
    parser.add_argument("--target_occlusion_soft_blur", type=int, default=1)
    parser.add_argument("--target_occlusion_gamma", type=float, default=1.0)
    parser.add_argument("--target_occlusion_max_intensity", type=float, default=0.08)
    parser.add_argument("--target_occlusion_dark_margin", type=float, default=0.005)
    parser.add_argument("--target_occlusion_context_ratio", type=float, default=0.40)
    parser.add_argument("--background_patchgan_weight", type=float, default=0.0)
    parser.add_argument("--target_ring_patchgan_weight", type=float, default=0.0)
    parser.add_argument("--target_shadow_patchgan_weight", type=float, default=0.0)
    parser.add_argument("--patchgan_lr", type=float, default=1e-4)
    parser.add_argument("--patchgan_weight_decay", type=float, default=0.0)
    parser.add_argument("--patchgan_base", type=int, default=32)
    parser.add_argument("--patchgan_min_region_coverage", type=float, default=0.10)
    parser.add_argument("--border_loss_width", type=int, default=18)
    parser.add_argument("--border_loss_target_exclude_dilate", type=int, default=10)
    parser.add_argument("--border_l1_weight", type=float, default=0.8)
    parser.add_argument("--border_texture_loss_weight", type=float, default=0.8)
    parser.add_argument("--border_gradient_loss_weight", type=float, default=0.30)
    parser.add_argument("--border_ssim_loss_weight", type=float, default=0.60)
    parser.add_argument("--border_quantile_loss_weight", type=float, default=0.30)
    parser.add_argument("--bright_loss_weight", type=float, default=0.35)
    parser.add_argument("--bright_loss_gain", type=float, default=5.0)
    parser.add_argument("--bright_loss_gamma", type=float, default=1.5)
    parser.add_argument("--quantile_loss_weight", type=float, default=0.45)
    parser.add_argument("--texture_loss_weight", type=float, default=1.6)
    parser.add_argument("--gradient_loss_weight", type=float, default=0.45)
    parser.add_argument("--target_speckle_loss_weight", type=float, default=0.0)
    parser.add_argument("--target_speckle_stat_quantiles", type=str, default="0.05,0.10,0.25,0.50,0.75,0.90,0.97")
    parser.add_argument("--target_speckle_std_quantile_weight", type=float, default=1.0)
    parser.add_argument("--target_speckle_highfreq_quantile_weight", type=float, default=0.8)
    parser.add_argument("--target_speckle_intensity_quantile_weight", type=float, default=0.6)
    parser.add_argument("--target_speckle_dark_ratio_weight", type=float, default=0.6)
    parser.add_argument("--target_speckle_dark_threshold", type=float, default=0.22)
    parser.add_argument("--target_speckle_dark_softness", type=float, default=0.035)
    parser.add_argument("--intensity_mse_weight", type=float, default=0.20)
    parser.add_argument("--ssim_loss_weight", type=float, default=0.65)
    parser.add_argument("--target_ssim_loss_weight", type=float, default=0.35)
    parser.add_argument("--ssim_domain", choices=["sar_intensity", "pixel"], default="sar_intensity")
    parser.add_argument("--sar_ssim_log_scale", type=float, default=20.0)
    parser.add_argument("--ssim_radius", type=int, default=5)
    parser.add_argument("--local_texture_radius", type=int, default=2)
    parser.add_argument("--highfreq_radius", type=int, default=1)
    parser.add_argument("--stat_quantiles", type=str, default="0.25,0.50,0.75,0.90,0.97")
    parser.add_argument("--multiplier_identity_weight", type=float, default=0.015)
    parser.add_argument("--visibility_identity_weight", type=float, default=0.010)
    parser.add_argument("--dark_patch_sparsity_weight", type=float, default=0.006)
    parser.add_argument("--background_reference_dir", type=str, default=None)
    parser.add_argument("--empirical_background_strength", type=float, default=0.75)
    parser.add_argument("--empirical_background_target_dilate", type=int, default=2)
    parser.add_argument("--empirical_background_blend_blur", type=int, default=2)
    parser.add_argument("--empirical_background_reference_exclude_dilate", type=int, default=20)
    parser.add_argument("--empirical_background_scale", type=float, default=1.0)
    parser.add_argument("--empirical_background_bias", type=float, default=0.0)
    parser.add_argument("--empirical_background_mode", choices=["patch", "reference", "pixel"], default="patch")
    parser.add_argument("--empirical_background_patch_size", type=int, default=24)
    parser.add_argument("--empirical_background_patch_overlap", type=int, default=6)
    parser.add_argument("--empirical_background_patch_min_valid", type=float, default=0.70)
    parser.add_argument("--empirical_background_patch_smooth", type=int, default=0)
    parser.add_argument("--empirical_background_patch_smooth_mix", type=float, default=0.45)
    parser.add_argument("--empirical_background_patch_fallback_weight", type=float, default=1.0)
    parser.add_argument("--empirical_background_clean_reference", action=BooleanOptionalAction, default=True)
    parser.add_argument("--empirical_background_fallback_blur", type=int, default=9)
    parser.add_argument("--empirical_background_shadow_keep_strength", type=float, default=0.0)
    parser.add_argument("--empirical_background_shadow_threshold", type=float, default=0.12)
    parser.add_argument("--empirical_background_shadow_target_dilate", type=int, default=80)
    parser.add_argument("--empirical_background_shadow_blur", type=int, default=4)
    parser.add_argument("--shadow_restore_source", choices=["checkpoint", "mod_target", "reference", "style_ref", "background"], default="reference")
    parser.add_argument("--shadow_restore_checkpoint", type=str, default=None)
    parser.add_argument("--shadow_restore_strength", type=float, default=0.0)
    parser.add_argument("--shadow_restore_mode", choices=["darken", "blend", "attenuate", "extinguish"], default="extinguish")
    parser.add_argument("--shadow_restore_threshold", type=float, default=0.22)
    parser.add_argument("--shadow_restore_target_dilate", type=int, default=80)
    parser.add_argument("--shadow_restore_target_protect_dilate", type=int, default=2)
    parser.add_argument("--shadow_restore_clean_reference", action=BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_restore_reference_blur", type=int, default=0)
    parser.add_argument("--shadow_restore_blur", type=int, default=2)
    parser.add_argument("--shadow_restore_gamma", type=float, default=1.0)
    parser.add_argument("--shadow_restore_max_coverage", type=float, default=0.22)
    parser.add_argument("--shadow_restore_coverage_softness", type=float, default=0.08)
    parser.add_argument("--shadow_restore_coverage_blur", type=int, default=0)
    parser.add_argument("--shadow_restore_max_darken", type=float, default=0.70)
    parser.add_argument("--shadow_restore_context_blur", type=int, default=15)
    parser.add_argument("--shadow_restore_ratio_mix", type=float, default=0.9)
    parser.add_argument("--shadow_restore_min_attenuation", type=float, default=0.01)
    parser.add_argument("--shadow_restore_attenuation_power", type=float, default=2.5)
    parser.add_argument("--shadow_restore_floor", type=float, default=0.0)
    parser.add_argument("--border_repair_strength", type=float, default=0.0)
    parser.add_argument("--border_repair_width", type=int, default=12)
    parser.add_argument("--border_repair_blur", type=int, default=4)
    parser.add_argument("--border_repair_target_dilate", type=int, default=8)
    parser.add_argument("--inference_pad", type=int, default=0)
    parser.add_argument("--background_style_blur_radius", type=int, default=0)
    parser.add_argument("--background_style_lowfreq_mix", type=float, default=0.0)
    parser.add_argument("--save_maps", action=BooleanOptionalAction, default=True)
    parser.add_argument("--save_training_masks", action="store_true", default=False)
    parser.add_argument("--training_mask_output_dir", type=str, default=None)
    parser.add_argument("--training_mask_limit", type=int, default=0)
    parser.add_argument(
        "--postprocess_after_apply",
        action=BooleanOptionalAction,
        default=True,
        help="After apply, run local target/shadow postprocess using the generated renders and target_modulated_renders.",
    )
    parser.add_argument("--postprocess_output_dir", type=str, default=None)
    parser.add_argument("--postprocess_render_dir", type=str, default=None)
    parser.add_argument("--postprocess_target_mask_dir", type=str, default=None)
    parser.add_argument("--postprocess_target_source_dir", type=str, default=None)
    parser.add_argument("--postprocess_shadow_source_dir", type=str, default=None)
    parser.add_argument("--postprocess_target_mask_threshold", type=float, default=0.08)
    parser.add_argument("--postprocess_target_mask_quantile", type=float, default=0.35)
    parser.add_argument("--postprocess_target_mask_dilate", type=int, default=0)
    parser.add_argument("--postprocess_target_strength", type=float, default=0.6)
    parser.add_argument("--postprocess_target_alpha_dilate", type=int, default=0)
    parser.add_argument("--postprocess_target_alpha_blur", type=int, default=0)
    parser.add_argument("--postprocess_target_alpha_gamma", type=float, default=1.0)
    parser.add_argument("--postprocess_shadow_strength", type=float, default=0.9)
    parser.add_argument("--postprocess_shadow_mode", choices=["blend_reference", "min_reference", "extinguish"], default="min_reference")
    parser.add_argument("--postprocess_shadow_search_dilate", type=int, default=45)
    parser.add_argument("--postprocess_shadow_target_exclude_dilate", type=int, default=1)
    parser.add_argument("--postprocess_shadow_dark_threshold", type=float, default=0.18)
    parser.add_argument("--postprocess_shadow_ratio_threshold", type=float, default=0.16)
    parser.add_argument("--postprocess_shadow_context_blur", type=int, default=17)
    parser.add_argument("--postprocess_shadow_soft_blur", type=int, default=1)
    parser.add_argument("--postprocess_shadow_gamma", type=float, default=1.0)
    parser.add_argument("--postprocess_shadow_min_attenuation", type=float, default=0.03)
    parser.add_argument("--postprocess_shadow_attenuation_power", type=float, default=2.0)
    parser.add_argument("--postprocess_shadow_floor", type=float, default=0.0)
    parser.add_argument("--postprocess_save_maps", action=BooleanOptionalAction, default=True)

    args = parser.parse_args()
    args._model_base_explicit = any(a == "--model_base" or str(a).startswith("--model_base=") for a in sys.argv[1:])
    args._noise_channels_explicit = any(a == "--noise_channels" or str(a).startswith("--noise_channels=") for a in sys.argv[1:])
    _apply_target_sarsim_finetune_defaults(args)
    _normalize_target_layover_mode(args)
    _apply_target_only_refiner_defaults(args)
    _apply_target_layover_refiner_defaults(args)
    _apply_refiner_ablation_defaults(args)
    _derive_paths(args)
    if int(getattr(args, "inference_pad", 0) or 0) > 0:
        print(
            "[target modulation] warning: --inference_pad changes coordinate conditioning and can blank the outer image; "
            "prefer --conv_padding_mode reflect for border artifacts."
        )

    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    if device.type == "cpu":
        print("[target modulation] using CPU")
    else:
        _configure_torch_runtime(args, device)

    if args.apply_only:
        if not Path(args.checkpoint).is_file():
            raise RuntimeError(f"--apply_only requires an existing checkpoint: {args.checkpoint}")
        model = _load_model(args, device)
    else:
        if not args.train_target_dir or not args.train_gt_dir:
            raise RuntimeError("Training requires --train_target_dir and --train_gt_dir, or -m with train_renders/train_gt")
        model = _train(args, device)

    if not args.train_only:
        if not args.apply_target_dir:
            raise RuntimeError("Apply requires --apply_target_dir, or -m with novel_target_only/target_renders")
        _apply(args, model, device)
        if bool(args.postprocess_after_apply):
            _postprocess_after_apply(args)


if __name__ == "__main__":
    main()
