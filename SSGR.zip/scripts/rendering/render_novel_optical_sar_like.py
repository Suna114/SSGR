#!/usr/bin/env python3
"""
Render novel optical-style 3DGS views and add SAR-like background, shadow, and
layover in image space.

This is intended for the "SAR as top-down optical images" workflow:
3DGS renders the target, while azimuth-conditioned postprocessing produces
controllable SAR-like artifacts without training background/shadow Gaussians.
"""

from __future__ import annotations

import math
import os
import sys
from argparse import ArgumentParser, BooleanOptionalAction
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import torchvision
from PIL import Image
from tqdm import tqdm


for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from arguments import ModelParams, PipelineParams, get_combined_args
from gaussian_renderer import render
from scene import GaussianModel, Scene
from scene.cameras import Camera
from utils.general_utils import safe_state

try:
    from diff_gaussian_rasterization import SparseGaussianAdam

    SPARSE_ADAM_AVAILABLE = True
except Exception:
    SPARSE_ADAM_AVAILABLE = False

try:
    from scripts.rendering.render_novel_sar_views import (
        _get_sar_params_from_camera,
        _parse_filename_dep_azi,
        create_novel_camera_colmap_track,
        filter_train_cameras_by_nearest_depression,
    )

    COLMAP_TRACK_AVAILABLE = True
except Exception:
    COLMAP_TRACK_AVAILABLE = False
    _get_sar_params_from_camera = None
    _parse_filename_dep_azi = None
    create_novel_camera_colmap_track = None
    filter_train_cameras_by_nearest_depression = None


def _parse_float_list(raw: str) -> list[float]:
    return [float(x.strip()) for x in str(raw).replace(",", " ").split() if x.strip()]


def _parse_azimuth_list(raw: str) -> list[int]:
    values: list[int] = []
    seen: set[int] = set()
    for value in _parse_float_list(raw):
        rounded = int(round(value))
        if abs(float(value) - float(rounded)) > 1e-6:
            raise ValueError(f"azimuth list currently expects integer degrees, got {value:g}")
        if rounded in seen:
            continue
        seen.add(rounded)
        values.append(rounded)
    return values


def _depression_from_training_cameras(train_cameras, fallback: float) -> float:
    for cam in train_cameras or []:
        dep = getattr(cam, "depression_angle", None)
        if dep is not None:
            return float(dep)
        if _parse_filename_dep_azi is not None:
            parsed = _parse_filename_dep_azi(getattr(cam, "image_name", "") or "")
            if parsed is not None:
                return float(parsed[0])
    return float(fallback)


def _estimate_target_center(gaussians: GaussianModel) -> np.ndarray:
    xyz = gaussians.get_xyz.detach().cpu().numpy()
    if xyz.shape[0] == 0:
        return np.zeros(3, dtype=np.float64)
    return np.median(xyz, axis=0).astype(np.float64)


def _fit_camera_orbit(train_cameras, target_center: np.ndarray, stat: str = "median"):
    centers = []
    for cam in train_cameras:
        c = cam.camera_center.detach().cpu().numpy().reshape(3).astype(np.float64)
        centers.append(c)
    if not centers:
        raise ValueError("No train cameras available to fit an orbit")
    C = np.stack(centers, axis=0)
    rel = C - target_center.reshape(1, 3)
    if C.shape[0] >= 3:
        _, _, vh = np.linalg.svd(rel - rel.mean(axis=0, keepdims=True), full_matrices=False)
        u = vh[0]
        v = vh[1]
        n = vh[2]
    else:
        u = rel[0] / (np.linalg.norm(rel[0]) + 1e-12)
        world_up = np.array([0.0, 0.0, 1.0], dtype=np.float64)
        if abs(float(np.dot(u, world_up))) > 0.95:
            world_up = np.array([0.0, 1.0, 0.0], dtype=np.float64)
        v = np.cross(world_up, u)
        v = v / (np.linalg.norm(v) + 1e-12)
        n = np.cross(u, v)
    u = u / (np.linalg.norm(u) + 1e-12)
    v = v - u * np.dot(v, u)
    v = v / (np.linalg.norm(v) + 1e-12)
    n = np.cross(u, v)
    n = n / (np.linalg.norm(n) + 1e-12)

    ru = rel @ u
    rv = rel @ v
    rn = rel @ n
    radii = np.sqrt(ru * ru + rv * rv)
    stat = (stat or "median").lower().strip()
    if stat == "mean":
        radius = float(np.mean(radii))
        height = float(np.mean(rn))
    else:
        radius = float(np.median(radii))
        height = float(np.median(rn))
    return {
        "target": target_center.astype(np.float64),
        "u": u.astype(np.float64),
        "v": v.astype(np.float64),
        "n": n.astype(np.float64),
        "radius": radius,
        "height": height,
        "centers": C,
    }


def _look_at_camera(center: np.ndarray, target: np.ndarray, ref_camera, uid: int, name: str) -> Camera:
    center = np.asarray(center, dtype=np.float64).reshape(3)
    target = np.asarray(target, dtype=np.float64).reshape(3)
    forward = target - center
    forward = forward / (np.linalg.norm(forward) + 1e-12)

    # Camera convention in this repo follows COLMAP: X right, Y down, Z forward.
    world_up = np.array([0.0, 0.0, 1.0], dtype=np.float64)
    if abs(float(np.dot(forward, world_up))) > 0.95:
        world_up = np.array([0.0, 1.0, 0.0], dtype=np.float64)
    right = np.cross(forward, world_up)
    right = right / (np.linalg.norm(right) + 1e-12)
    down = np.cross(forward, right)
    down = down / (np.linalg.norm(down) + 1e-12)

    R_cam_to_world = np.stack([right, down, forward], axis=1)
    R_world_to_cam = R_cam_to_world.T
    T = (-R_world_to_cam @ center).astype(np.float32)
    resolution = (int(ref_camera.image_width), int(ref_camera.image_height))
    dummy = Image.fromarray(np.zeros((resolution[1], resolution[0], 3), dtype=np.uint8))
    return Camera(
        resolution=resolution,
        colmap_id=uid,
        R=R_cam_to_world.astype(np.float32),
        T=T,
        FoVx=ref_camera.FoVx,
        FoVy=ref_camera.FoVy,
        depth_params=None,
        image=dummy,
        invdepthmap=None,
        image_name=name,
        uid=uid,
        trans=getattr(ref_camera, "trans", np.array([0.0, 0.0, 0.0])),
        scale=getattr(ref_camera, "scale", 1.0),
        data_device="cuda",
        R_world_to_radar=None,
        use_sar_rendering=False,
        sar_params=None,
        azimuth_angle=None,
        depression_angle=None,
    )


def _orbit_camera(orbit: dict, azimuth_deg: float, ref_camera, uid: int, azimuth_offset_deg: float):
    a = math.radians(float(azimuth_deg) + float(azimuth_offset_deg))
    target = orbit["target"]
    center = (
        target
        + orbit["radius"] * math.cos(a) * orbit["u"]
        + orbit["radius"] * math.sin(a) * orbit["v"]
        + orbit["height"] * orbit["n"]
    )
    return _look_at_camera(
        center=center,
        target=target,
        ref_camera=ref_camera,
        uid=uid,
        name=f"optical_sarlike_azi{float(azimuth_deg):.1f}",
    )


def _shift_zero(x: torch.Tensor, dx: int, dy: int) -> torch.Tensor:
    out = torch.zeros_like(x)
    h, w = x.shape[-2], x.shape[-1]
    if abs(dx) >= w or abs(dy) >= h:
        return out
    src_x0 = max(0, -dx)
    src_x1 = min(w, w - dx)
    dst_x0 = max(0, dx)
    dst_x1 = min(w, w + dx)
    src_y0 = max(0, -dy)
    src_y1 = min(h, h - dy)
    dst_y0 = max(0, dy)
    dst_y1 = min(h, h + dy)
    out[..., dst_y0:dst_y1, dst_x0:dst_x1] = x[..., src_y0:src_y1, src_x0:src_x1]
    return out


def _gaussian_kernel(radius: int, sigma: float, device, dtype) -> torch.Tensor:
    radius = max(1, int(radius))
    xs = torch.arange(-radius, radius + 1, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(xs, xs, indexing="ij")
    k = torch.exp(-(xx * xx + yy * yy) / (2.0 * float(sigma) * float(sigma) + 1e-8))
    return (k / (k.sum() + 1e-8)).view(1, 1, 2 * radius + 1, 2 * radius + 1)


def _blur01(x: torch.Tensor, radius: int, sigma: float) -> torch.Tensor:
    if radius <= 0:
        return x.clamp(0.0, 1.0)
    k = _gaussian_kernel(radius, sigma, x.device, x.dtype)
    y = F.conv2d(x.view(1, 1, x.shape[-2], x.shape[-1]), k, padding=radius)
    return y.view_as(x).clamp(0.0, 1.0)


def _dilate01(x: torch.Tensor, iterations: int) -> torch.Tensor:
    if iterations <= 0:
        return x.clamp(0.0, 1.0)
    y = x.view(1, 1, x.shape[-2], x.shape[-1])
    for _ in range(int(iterations)):
        y = F.max_pool2d(y, kernel_size=3, stride=1, padding=1)
    return y.view_as(x).clamp(0.0, 1.0)


def suppress_target_halo(rendered: torch.Tensor, args) -> torch.Tensor:
    strength = float(getattr(args, "target_halo_suppress_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return rendered.clamp(0.0, 1.0)

    rendered = rendered.clamp(0.0, 1.0)
    gray = rendered.mean(dim=0)
    nz = gray[gray > 1e-4]
    if int(nz.numel()) < 16:
        return rendered

    threshold = float(getattr(args, "target_halo_threshold", 0.0) or 0.0)
    if threshold <= 0.0:
        q = float(getattr(args, "target_halo_quantile", 0.35) or 0.35)
        threshold = float(torch.quantile(nz, min(max(q, 0.0), 1.0)).detach().item())

    support = (gray >= threshold).to(rendered.dtype)
    if int(support.sum().item()) < 16:
        support = (gray >= torch.quantile(nz, 0.50)).to(rendered.dtype)
    support = _dilate01(support, int(getattr(args, "target_halo_dilate", 0) or 0))
    soft_radius = int(getattr(args, "target_halo_soft_radius", 1) or 0)
    if soft_radius > 0:
        support = _blur01(support, soft_radius, max(1.0, soft_radius / 2.0))

    keep = (1.0 - strength) + strength * support.unsqueeze(0)
    floor = float(getattr(args, "target_halo_black_floor", 0.0) or 0.0)
    out = rendered * keep
    if floor > 0.0:
        out = torch.where(out < floor, torch.zeros_like(out), out)
    return out.clamp(0.0, 1.0)


def _make_target_mask(rendered: torch.Tensor, threshold: float, blur_radius: int) -> torch.Tensor:
    gray = rendered.mean(dim=0)
    hard = (gray > float(threshold)).to(rendered.dtype)
    if float(hard.sum().item()) < 16:
        q = torch.quantile(gray.reshape(-1), 0.90)
        hard = (gray >= q).to(rendered.dtype)
    return _blur01(hard, blur_radius, max(1.0, blur_radius / 2.0))


def _make_target_support(rendered: torch.Tensor, args) -> tuple[torch.Tensor, torch.Tensor]:
    """Return (soft composition mask, hard compact support) for SAR-like effects."""
    gray = rendered.mean(dim=0)
    nz = gray[gray > 1e-5]
    threshold = float(args.mask_threshold)
    if threshold <= 0.0 and int(nz.numel()) > 16:
        q = min(max(float(getattr(args, "mask_quantile", 0.35)), 0.0), 1.0)
        threshold = float(torch.quantile(nz, q).detach().item())
    hard = (gray > threshold).to(rendered.dtype)
    if float(hard.sum().item()) < 16:
        q = torch.quantile(gray.reshape(-1), 0.90)
        hard = (gray >= q).to(rendered.dtype)

    compose_hard = _dilate01(hard, int(getattr(args, "mask_dilate", 0) or 0))
    soft = _blur01(compose_hard, int(args.mask_blur_radius), max(1.0, float(args.mask_blur_radius) / 2.0))

    support = _dilate01(hard, int(getattr(args, "shadow_source_dilate", 1) or 0))
    return soft.clamp(0.0, 1.0), support.clamp(0.0, 1.0)


def _make_directional_trail(
    source: torch.Tensor,
    angle_deg: float,
    length_px: int,
    decay: float,
    blur_radius: int,
) -> torch.Tensor:
    length_px = max(0, int(length_px))
    if length_px <= 0:
        return torch.zeros_like(source)
    a = math.radians(float(angle_deg))
    ux = math.cos(a)
    uy = math.sin(a)
    trail = torch.zeros_like(source)
    norm = 0.0
    for i in range(1, length_px + 1):
        dx = int(round(ux * i))
        dy = int(round(uy * i))
        w = math.exp(-float(i) / max(float(decay), 1e-6))
        trail = trail + w * _shift_zero(source, dx, dy)
        norm += w
    trail = trail / max(norm, 1e-6)
    if blur_radius > 0:
        trail = _blur01(trail, blur_radius, max(1.0, blur_radius / 2.0))
    return trail.clamp(0.0, 1.0)


def _camera_mask_from_name(masks: dict | None, cam, image: torch.Tensor, fallback_threshold: float) -> torch.Tensor:
    h, w = image.shape[-2], image.shape[-1]
    mask = None
    if masks:
        name = os.path.basename(getattr(cam, "image_name", "") or "")
        stem = os.path.splitext(name)[0]
        if name in masks:
            mask = masks[name]
        elif stem in masks:
            mask = masks[stem]
        else:
            for k, v in masks.items():
                if os.path.splitext(os.path.basename(str(k)))[0] == stem:
                    mask = v
                    break
    if mask is not None:
        m = torch.as_tensor(mask, dtype=torch.float32, device=image.device)
        if m.shape != (h, w):
            m = F.interpolate(m[None, None], size=(h, w), mode="nearest").squeeze()
        return ((m == 1) | (m == 2)).float()

    gray = image[:3].mean(dim=0)
    m = (gray > float(fallback_threshold)).float()
    if int(m.sum().item()) < 16:
        q = torch.quantile(gray.reshape(-1), 0.90)
        m = (gray >= q).float()
    return m


def _load_convert_masks(source_path: str, images_subdir: str | None):
    try:
        from sar.semantic_mask_config import load_convert_scattering_masks
    except Exception:
        return None
    images_folder = os.path.join(source_path, images_subdir or "images")
    loaded = load_convert_scattering_masks(source_path, images_folder)
    if loaded is None:
        return None
    masks, _cache_dir = loaded
    return masks


def _estimate_background_from_train(train_cameras, model_params, args) -> None:
    if not bool(getattr(args, "auto_background_from_train", True)):
        return
    masks = _load_convert_masks(
        getattr(model_params, "source_path", ""),
        getattr(model_params, "images", "images"),
    )
    samples = []
    max_samples = int(getattr(args, "auto_background_max_samples", 250000) or 250000)
    exclude_dilate = int(getattr(args, "auto_background_exclude_dilate", 5) or 0)
    threshold = float(getattr(args, "auto_background_fallback_target_threshold", 0.08) or 0.08)
    for cam in train_cameras or []:
        image = cam.original_image[:3].cuda().clamp(0.0, 1.0)
        gray = image.mean(dim=0)
        target = _camera_mask_from_name(masks, cam, image, threshold)
        target = _dilate01(target, exclude_dilate)
        bg = gray[target < 0.5]
        if int(bg.numel()) > 0:
            samples.append(bg.detach())
    if not samples:
        return
    vals = torch.cat(samples, dim=0)
    if int(vals.numel()) > max_samples:
        step = max(1, int(vals.numel()) // max_samples)
        vals = vals[::step]
    level_q = min(max(float(getattr(args, "auto_background_level_quantile", 0.50)), 0.0), 1.0)
    level = float(torch.quantile(vals, level_q).detach().item())
    std = float(vals.std(unbiased=False).detach().item())
    texture = max(0.0, min(0.35, std * float(getattr(args, "auto_background_texture_scale", 1.4))))
    if bool(getattr(args, "auto_background_print", True)):
        print(
            "[auto background] "
            f"level={level:.4f}, texture={texture:.4f}, samples={int(vals.numel())}, "
            f"convert_masks={'yes' if masks else 'no'}"
        )
    args.background_level = level
    args.background_texture = texture


def sar_like_postprocess(rendered: torch.Tensor, azimuth_deg: float, args) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    rendered = rendered.clamp(0.0, 1.0)
    h, w = rendered.shape[-2], rendered.shape[-1]
    device, dtype = rendered.device, rendered.dtype
    mask, support = _make_target_support(rendered, args)
    core_mask = (mask >= float(args.target_preserve_threshold)).to(dtype)
    preserve_blur = int(args.target_preserve_blur_radius)
    if preserve_blur > 0:
        core_mask = _blur01(core_mask, preserve_blur, max(1.0, preserve_blur / 2.0))

    gen = torch.Generator(device=device)
    seed = int(args.seed) + int(round(float(azimuth_deg) * 1000.0))
    gen.manual_seed(seed)
    bg = torch.full((1, h, w), float(args.background_level), device=device, dtype=dtype)
    looks = max(1, int(args.speckle_looks))
    speckle = torch.zeros((1, h, w), device=device, dtype=dtype)
    for _ in range(looks):
        u = torch.rand((1, h, w), device=device, dtype=dtype, generator=gen).clamp_min(1e-6)
        speckle = speckle + (-torch.log(u))
    speckle = speckle / float(looks)
    speckle = speckle / speckle.mean().clamp_min(1e-6)
    low = _blur01(torch.randn((h, w), device=device, dtype=dtype, generator=gen), 10, 5.0)
    low = (low - low.min()) / (low.max() - low.min() + 1e-8)
    bg = bg + float(args.background_texture) * (low.unsqueeze(0) - 0.5)
    bg = bg * (1.0 + float(args.speckle_strength) * (speckle - 1.0))
    bg = bg.clamp(0.0, 1.0).expand(3, -1, -1)

    gray = rendered.mean(dim=0)
    shadow_len = int(round(float(args.shadow_length_frac) * max(h, w)))
    shadow_angle = float(azimuth_deg) + float(args.shadow_angle_offset)
    shadow = _make_directional_trail(
        support,
        shadow_angle,
        shadow_len,
        decay=max(1.0, shadow_len * float(args.shadow_decay_frac)),
        blur_radius=int(args.shadow_blur_radius),
    )
    no_target = (1.0 - _dilate01(core_mask, int(getattr(args, "target_shadow_gap", 1) or 0))).clamp(0.0, 1.0)
    shadow = (shadow * no_target).clamp(0.0, 1.0)

    bright = torch.relu(gray - float(args.layover_threshold)) / max(1e-6, 1.0 - float(args.layover_threshold))
    bright = (bright * support).clamp(0.0, 1.0)
    lay_len = int(round(float(args.layover_length_frac) * max(h, w)))
    layover = _make_directional_trail(
        bright,
        shadow_angle + 180.0,
        lay_len,
        decay=max(1.0, lay_len * 0.7),
        blur_radius=int(args.layover_blur_radius),
    )
    layover = (layover * no_target).clamp(0.0, 1.0)

    out = bg * (1.0 - mask.unsqueeze(0)) + rendered * mask.unsqueeze(0)
    out = out + float(args.layover_strength) * layover.unsqueeze(0)
    out = torch.pow(out.clamp(0.0, 1.0), torch.tensor(float(args.gamma), device=device, dtype=dtype))
    preserve = (float(args.target_preserve_strength) * core_mask).clamp(0.0, 1.0).unsqueeze(0)
    out = out * (1.0 - preserve) + rendered * preserve
    # Apply shadow last so later tone/preserve passes cannot wash it out.
    out = out * (1.0 - float(args.shadow_strength) * shadow.unsqueeze(0))
    return out.clamp(0.0, 1.0), mask, shadow


def render_novel_views(args, model_params, pipeline_params):
    gaussians = GaussianModel(model_params.sh_degree)
    scene = Scene(model_params, gaussians, load_iteration=int(args.iteration), shuffle=False)
    train_cameras = list(scene.getTrainCameras() or [])
    ref_cameras = train_cameras or list(scene.getTestCameras() or [])
    if not ref_cameras:
        raise RuntimeError("Scene has no cameras")
    ref_camera = ref_cameras[0]
    if not train_cameras:
        raise RuntimeError("At least one train camera is required to fit the orbit")

    pose_mode = str(getattr(args, "novel_pose_mode", "colmap_track")).lower().strip()
    target_center = _estimate_target_center(gaussians)
    orbit = None
    if pose_mode == "orbit":
        orbit = _fit_camera_orbit(train_cameras, target_center, stat=str(args.orbit_stat))
        if args.override_radius is not None:
            orbit["radius"] = float(args.override_radius)
        if args.override_height is not None:
            orbit["height"] = float(args.override_height)
    elif pose_mode == "colmap_track":
        if not COLMAP_TRACK_AVAILABLE:
            raise RuntimeError(
                "novel_pose_mode=colmap_track requires helpers from render_novel_sar_views.py"
            )
    else:
        raise RuntimeError(f"Unsupported novel_pose_mode: {pose_mode}")

    depression_angle = _depression_from_training_cameras(
        train_cameras,
        fallback=float(getattr(args, "depression_angle", 15.0)),
    )
    train_cameras_for_pose = train_cameras
    if pose_mode == "colmap_track":
        train_cameras_for_pose = filter_train_cameras_by_nearest_depression(
            train_cameras,
            depression_angle,
            model_params.source_path,
        )
        if not train_cameras_for_pose:
            train_cameras_for_pose = train_cameras
    _estimate_background_from_train(train_cameras, model_params, args)

    out_root = Path(args.output_dir or os.path.join(model_params.model_path, "novel_optical_sar_like"))
    renders_dir = out_root / "renders"
    targets_dir = out_root / "target_renders"
    masks_dir = out_root / "masks"
    shadows_dir = out_root / "shadows"
    for d in (renders_dir, targets_dir):
        d.mkdir(parents=True, exist_ok=True)
    if bool(args.save_masks):
        masks_dir.mkdir(parents=True, exist_ok=True)
        shadows_dir.mkdir(parents=True, exist_ok=True)

    if getattr(args, "azimuths", None):
        azimuths = _parse_azimuth_list(str(args.azimuths))
    else:
        if int(args.azimuth_step) <= 0:
            raise ValueError("--azimuth_step must be positive")
        azimuths = list(range(int(args.azimuth_start), int(args.azimuth_end), int(args.azimuth_step)))
    if not azimuths:
        raise RuntimeError("Empty azimuth list")
    background = torch.tensor([0.0, 0.0, 0.0], dtype=torch.float32, device="cuda")

    print("=" * 80)
    print("Novel optical 3DGS + SAR-like image postprocess")
    print("=" * 80)
    print(f"model: {model_params.model_path}")
    print(f"iteration: {args.iteration if int(args.iteration) >= 0 else 'latest'}")
    print(f"output: {out_root}")
    if getattr(args, "azimuths", None):
        print(f"azimuths: {azimuths}, count={len(azimuths)}")
    else:
        print(f"azimuths: {azimuths[0]}..{azimuths[-1]} step={args.azimuth_step}, count={len(azimuths)}")
    print(f"novel_pose_mode: {pose_mode}")
    if orbit is not None:
        print(
            "orbit: "
            f"radius={orbit['radius']:.6g}, height={orbit['height']:.6g}, "
            f"target=[{orbit['target'][0]:.4g},{orbit['target'][1]:.4g},{orbit['target'][2]:.4g}]"
        )
    else:
        print(
            "colmap_track: "
            f"depression={depression_angle:g}, "
            f"pose_cameras={len(train_cameras_for_pose)}/{len(train_cameras)}, "
            f"azimuth_space={args.colmap_track_azimuth_space}, "
            f"interp={not bool(args.colmap_track_nearest_only)}"
        )
    print(
        "postprocess: "
        f"shadow_len={args.shadow_length_frac}*max(H,W), shadow_offset={args.shadow_angle_offset}deg, "
        f"speckle={args.speckle_strength}"
    )
    print("=" * 80)

    with torch.inference_mode():
        for idx, azi in enumerate(tqdm(azimuths, desc="render + SAR-like compose", unit="img")):
            if pose_mode == "orbit":
                cam = _orbit_camera(
                    orbit,
                    float(azi),
                    ref_camera=ref_camera,
                    uid=idx,
                    azimuth_offset_deg=float(args.azimuth_offset_deg),
                )
            else:
                sar_params = _get_sar_params_from_camera(ref_camera)
                cam = create_novel_camera_colmap_track(
                    depression_angle=depression_angle,
                    azimuth_angle=float(azi),
                    ref_camera=ref_camera,
                    sar_params=sar_params,
                    train_cameras_filtered=train_cameras_for_pose,
                    use_interp=not bool(args.colmap_track_nearest_only),
                    uid=idx,
                    azimuth_pose_deg=float(azi) + float(args.azimuth_offset_deg),
                    azimuth_space=str(args.colmap_track_azimuth_space),
                    source_path=model_params.source_path,
                )
            pkg = render(
                cam,
                gaussians,
                pipeline_params,
                background,
                use_trained_exp=getattr(model_params, "train_test_exp", False),
                separate_sh=SPARSE_ADAM_AVAILABLE,
                sar_mode=False,
            )
            target_raw = pkg["render"].clamp(0.0, 1.0)
            target = suppress_target_halo(target_raw, args)
            if bool(args.target_only):
                composed = target
                mask = torch.zeros_like(target[0])
                shadow = torch.zeros_like(target[0])
            else:
                composed, mask, shadow = sar_like_postprocess(target, float(azi), args)
            name = f"azimuth_{int(azi):03d}.png"
            torchvision.utils.save_image(composed, str(renders_dir / name))
            torchvision.utils.save_image(target, str(targets_dir / name))
            if bool(args.save_masks):
                torchvision.utils.save_image(mask.unsqueeze(0), str(masks_dir / name))
                torchvision.utils.save_image(shadow.unsqueeze(0), str(shadows_dir / name))

    print(f"done: {renders_dir}")


def main():
    parser = ArgumentParser(description="Render optical 3DGS novel views with SAR-like shadow/background postprocess")
    model = ModelParams(parser, sentinel=True)
    pipeline = PipelineParams(parser)
    parser.add_argument("--iteration", type=int, default=-1)
    parser.add_argument("--output_dir", type=str, default=None)
    parser.add_argument("--azimuth_start", type=int, default=0)
    parser.add_argument("--azimuth_end", type=int, default=360)
    parser.add_argument("--azimuth_step", type=int, default=5)
    parser.add_argument("--azimuths", type=str, default=None)
    parser.add_argument("--azimuth_offset_deg", type=float, default=0.0, help="Camera orbit angle offset")
    parser.add_argument("--depression_angle", type=float, default=15.0)
    parser.add_argument(
        "--novel_pose_mode",
        choices=["colmap_track", "orbit"],
        default="colmap_track",
        help="colmap_track reuses/interpolates training camera poses by filename azimuth; orbit is the old fitted look-at orbit.",
    )
    parser.add_argument(
        "--colmap_track_nearest_only",
        action="store_true",
        default=False,
        help="Use nearest training camera pose instead of interpolating adjacent azimuth poses.",
    )
    parser.add_argument(
        "--colmap_track_azimuth_space",
        choices=["filename", "geom"],
        default="filename",
        help="Azimuth key for colmap_track pose lookup.",
    )
    parser.add_argument("--orbit_stat", choices=["median", "mean"], default="median")
    parser.add_argument("--override_radius", type=float, default=None)
    parser.add_argument("--override_height", type=float, default=None)

    parser.add_argument("--mask_threshold", type=float, default=0.08)
    parser.add_argument("--mask_quantile", type=float, default=0.35)
    parser.add_argument("--mask_dilate", type=int, default=0)
    parser.add_argument("--mask_blur_radius", type=int, default=2)
    parser.add_argument("--shadow_source_dilate", type=int, default=1)
    parser.add_argument("--target_shadow_gap", type=int, default=1)
    parser.add_argument("--target_preserve_strength", type=float, default=0.90)
    parser.add_argument("--target_preserve_threshold", type=float, default=0.45)
    parser.add_argument("--target_preserve_blur_radius", type=int, default=1)
    parser.add_argument("--background_level", type=float, default=0.06)
    parser.add_argument("--background_texture", type=float, default=0.08)
    parser.add_argument("--auto_background_from_train", action=BooleanOptionalAction, default=True)
    parser.add_argument("--auto_background_level_quantile", type=float, default=0.50)
    parser.add_argument("--auto_background_texture_scale", type=float, default=1.4)
    parser.add_argument("--auto_background_exclude_dilate", type=int, default=5)
    parser.add_argument("--auto_background_max_samples", type=int, default=250000)
    parser.add_argument("--auto_background_fallback_target_threshold", type=float, default=0.08)
    parser.add_argument("--speckle_strength", type=float, default=0.65)
    parser.add_argument("--speckle_looks", type=int, default=2)
    parser.add_argument("--shadow_length_frac", type=float, default=0.34)
    parser.add_argument("--shadow_decay_frac", type=float, default=0.55)
    parser.add_argument("--shadow_blur_radius", type=int, default=5)
    parser.add_argument("--shadow_strength", type=float, default=0.72)
    parser.add_argument("--shadow_angle_offset", type=float, default=0.0)
    parser.add_argument("--layover_threshold", type=float, default=0.35)
    parser.add_argument("--layover_length_frac", type=float, default=0.06)
    parser.add_argument("--layover_blur_radius", type=int, default=2)
    parser.add_argument("--layover_strength", type=float, default=0.22)
    parser.add_argument("--gamma", type=float, default=0.95)
    parser.add_argument("--seed", type=int, default=1234)
    parser.add_argument("--target_halo_suppress_strength", type=float, default=0.0)
    parser.add_argument("--target_halo_threshold", type=float, default=0.12)
    parser.add_argument("--target_halo_quantile", type=float, default=0.35)
    parser.add_argument("--target_halo_dilate", type=int, default=0)
    parser.add_argument("--target_halo_soft_radius", type=int, default=0)
    parser.add_argument("--target_halo_black_floor", type=float, default=0.0)
    parser.add_argument("--target_only", action="store_true", default=False)
    parser.add_argument("--save_masks", action="store_true", default=False)
    parser.add_argument("--quiet", action="store_true", default=False)

    args = get_combined_args(parser)
    defaults = {
        "iteration": -1,
        "output_dir": None,
        "azimuth_start": 0,
        "azimuth_end": 360,
        "azimuth_step": 5,
        "azimuths": None,
        "azimuth_offset_deg": 0.0,
        "depression_angle": 15.0,
        "novel_pose_mode": "colmap_track",
        "colmap_track_nearest_only": False,
        "colmap_track_azimuth_space": "filename",
        "orbit_stat": "median",
        "override_radius": None,
        "override_height": None,
        "mask_threshold": 0.08,
        "mask_quantile": 0.35,
        "mask_dilate": 0,
        "mask_blur_radius": 2,
        "shadow_source_dilate": 1,
        "target_shadow_gap": 1,
        "target_preserve_strength": 0.90,
        "target_preserve_threshold": 0.45,
        "target_preserve_blur_radius": 1,
        "background_level": 0.06,
        "background_texture": 0.08,
        "auto_background_from_train": True,
        "auto_background_level_quantile": 0.50,
        "auto_background_texture_scale": 1.4,
        "auto_background_exclude_dilate": 5,
        "auto_background_max_samples": 250000,
        "auto_background_fallback_target_threshold": 0.08,
        "auto_background_print": True,
        "speckle_strength": 0.65,
        "speckle_looks": 2,
        "shadow_length_frac": 0.34,
        "shadow_decay_frac": 0.55,
        "shadow_blur_radius": 5,
        "shadow_strength": 0.72,
        "shadow_angle_offset": 0.0,
        "layover_threshold": 0.35,
        "layover_length_frac": 0.06,
        "layover_blur_radius": 2,
        "layover_strength": 0.22,
        "gamma": 0.95,
        "seed": 1234,
        "target_halo_suppress_strength": 0.0,
        "target_halo_threshold": 0.12,
        "target_halo_quantile": 0.35,
        "target_halo_dilate": 0,
        "target_halo_soft_radius": 0,
        "target_halo_black_floor": 0.0,
        "target_only": False,
        "save_masks": False,
        "quiet": False,
    }
    for k, v in defaults.items():
        if not hasattr(args, k):
            setattr(args, k, v)

    safe_state(bool(args.quiet))
    model_params = model.extract(args)
    pipeline_params = pipeline.extract(args)
    render_novel_views(args, model_params, pipeline_params)


if __name__ == "__main__":
    main()
