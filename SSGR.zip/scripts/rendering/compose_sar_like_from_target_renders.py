#!/usr/bin/env python3
"""
Compose SAR-like background, shadow, and layover from existing target renders.

Use this when target-only novel renders are already available and you only want
to tune image-domain background/shadow without retraining or re-rendering 3DGS.
"""

from __future__ import annotations

import os
import re
import sys
from argparse import ArgumentParser, BooleanOptionalAction, Namespace
from pathlib import Path

import numpy as np
import torch
import torchvision
import torch.nn.functional as F
from PIL import Image
from tqdm import tqdm

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from scripts.rendering.render_novel_optical_sar_like import sar_like_postprocess, suppress_target_halo


def _image_files(path: Path) -> list[Path]:
    exts = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
    return sorted([p for p in path.iterdir() if p.suffix.lower() in exts])


def _load_rgb_tensor(path: Path) -> torch.Tensor:
    img = Image.open(path).convert("RGB")
    arr = np.asarray(img, dtype=np.float32) / 255.0
    return torch.from_numpy(arr).permute(2, 0, 1).contiguous()


def _parse_azimuth(path: Path, fallback_index: int, fallback_step: float) -> float:
    stem = path.stem
    m = re.search(r"(?i)azimuth[_-]?(\d+(?:\.\d+)?)", stem)
    if m:
        return float(m.group(1))
    nums = re.findall(r"(?<!\d)(\d{1,3})(?!\d)", stem)
    if nums:
        return float(nums[-1]) % 360.0
    return float(fallback_index) * float(fallback_step)


def _dilate01(x: torch.Tensor, iterations: int) -> torch.Tensor:
    if iterations <= 0:
        return x.float()
    y = x.float()[None, None]
    for _ in range(int(iterations)):
        y = F.max_pool2d(y, kernel_size=3, stride=1, padding=1)
    return y[0, 0].clamp(0.0, 1.0)


def _load_convert_masks(source: Path, images_dir: Path):
    try:
        from sar.semantic_mask_config import load_convert_scattering_masks
    except Exception:
        return None
    loaded = load_convert_scattering_masks(str(source), str(images_dir))
    if loaded is None:
        return None
    masks, _cache_dir = loaded
    return masks


def _estimate_background(source: Path | None, args: Namespace) -> tuple[float, float]:
    if source is None or not bool(args.auto_background_from_source):
        return float(args.background_level), float(args.background_texture)
    images_dir = source / args.images
    if not images_dir.is_dir():
        return float(args.background_level), float(args.background_texture)

    masks = _load_convert_masks(source, images_dir)
    vals = []
    for image_path in _image_files(images_dir):
        img = _load_rgb_tensor(image_path)
        gray = img.mean(dim=0)
        mask = None
        if masks:
            name = image_path.name
            stem = image_path.stem
            mask = masks.get(name, masks.get(stem))
            if mask is None:
                for k, v in masks.items():
                    if Path(str(k)).stem == stem:
                        mask = v
                        break
        if mask is not None:
            m = torch.as_tensor(mask, dtype=torch.float32)
            if tuple(m.shape) != tuple(gray.shape):
                m = F.interpolate(m[None, None], size=gray.shape, mode="nearest").squeeze()
            target = ((m == 1) | (m == 2)).float()
        else:
            target = (gray > float(args.auto_background_fallback_target_threshold)).float()
            if int(target.sum().item()) < 16:
                target = (gray >= torch.quantile(gray.reshape(-1), 0.90)).float()
        target = _dilate01(target, int(args.auto_background_exclude_dilate))
        bg = gray[target < 0.5]
        if int(bg.numel()) > 0:
            vals.append(bg)
    if not vals:
        return float(args.background_level), float(args.background_texture)
    x = torch.cat(vals, dim=0)
    max_samples = int(args.auto_background_max_samples)
    if int(x.numel()) > max_samples:
        x = x[:: max(1, int(x.numel()) // max_samples)]
    level = float(torch.quantile(x, min(max(float(args.auto_background_level_quantile), 0.0), 1.0)).item())
    texture = max(0.0, min(0.35, float(x.std(unbiased=False).item()) * float(args.auto_background_texture_scale)))
    print(
        "[auto background] "
        f"level={level:.4f}, texture={texture:.4f}, samples={int(x.numel())}, "
        f"convert_masks={'yes' if masks else 'no'}"
    )
    return level, texture


def main() -> None:
    parser = ArgumentParser(description="Compose SAR-like images from target-only renders")
    parser.add_argument("--target_dir", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("-s", "--source", type=str, default=None)
    parser.add_argument("--images", type=str, default="images")
    parser.add_argument("--azimuth_step_fallback", type=float, default=5.0)
    parser.add_argument("--mask_threshold", type=float, default=0.08)
    parser.add_argument("--mask_quantile", type=float, default=0.35)
    parser.add_argument("--mask_dilate", type=int, default=0)
    parser.add_argument("--mask_blur_radius", type=int, default=2)
    parser.add_argument("--shadow_source_dilate", type=int, default=1)
    parser.add_argument("--target_shadow_gap", type=int, default=1)
    parser.add_argument("--target_preserve_strength", type=float, default=0.92)
    parser.add_argument("--target_preserve_threshold", type=float, default=0.45)
    parser.add_argument("--target_preserve_blur_radius", type=int, default=1)
    parser.add_argument("--background_level", type=float, default=0.06)
    parser.add_argument("--background_texture", type=float, default=0.08)
    parser.add_argument("--auto_background_from_source", action=BooleanOptionalAction, default=True)
    parser.add_argument("--auto_background_level_quantile", type=float, default=0.50)
    parser.add_argument("--auto_background_texture_scale", type=float, default=1.4)
    parser.add_argument("--auto_background_exclude_dilate", type=int, default=5)
    parser.add_argument("--auto_background_max_samples", type=int, default=250000)
    parser.add_argument("--auto_background_fallback_target_threshold", type=float, default=0.08)
    parser.add_argument("--speckle_strength", type=float, default=0.65)
    parser.add_argument("--speckle_looks", type=int, default=2)
    parser.add_argument("--shadow_length_frac", type=float, default=0.34)
    parser.add_argument("--shadow_decay_frac", type=float, default=0.55)
    parser.add_argument("--shadow_blur_radius", type=int, default=5)
    parser.add_argument("--shadow_strength", type=float, default=0.72)
    parser.add_argument("--shadow_angle_offset", type=float, default=0.0)
    parser.add_argument("--layover_threshold", type=float, default=0.35)
    parser.add_argument("--layover_length_frac", type=float, default=0.06)
    parser.add_argument("--layover_blur_radius", type=int, default=2)
    parser.add_argument("--layover_strength", type=float, default=0.22)
    parser.add_argument("--gamma", type=float, default=0.95)
    parser.add_argument("--seed", type=int, default=1234)
    parser.add_argument("--target_halo_suppress_strength", type=float, default=0.0)
    parser.add_argument("--target_halo_threshold", type=float, default=0.12)
    parser.add_argument("--target_halo_quantile", type=float, default=0.35)
    parser.add_argument("--target_halo_dilate", type=int, default=0)
    parser.add_argument("--target_halo_soft_radius", type=int, default=0)
    parser.add_argument("--target_halo_black_floor", type=float, default=0.0)
    parser.add_argument("--save_masks", action="store_true", default=False)
    args = parser.parse_args()

    target_dir = Path(args.target_dir)
    out_root = Path(args.output_dir)
    renders_dir = out_root / "renders"
    masks_dir = out_root / "masks"
    shadows_dir = out_root / "shadows"
    target_copy_dir = out_root / "target_renders"
    for d in (renders_dir, target_copy_dir):
        d.mkdir(parents=True, exist_ok=True)
    if bool(args.save_masks):
        masks_dir.mkdir(parents=True, exist_ok=True)
        shadows_dir.mkdir(parents=True, exist_ok=True)

    source = Path(args.source) if args.source else None
    args.background_level, args.background_texture = _estimate_background(source, args)
    files = _image_files(target_dir)
    if not files:
        raise RuntimeError(f"No images found in target_dir: {target_dir}")

    halo_args = Namespace(**vars(args))
    with torch.inference_mode():
        for idx, path in enumerate(tqdm(files, desc="compose SAR-like", unit="img")):
            target = suppress_target_halo(_load_rgb_tensor(path), halo_args)
            azi = _parse_azimuth(path, idx, float(args.azimuth_step_fallback))
            composed, mask, shadow = sar_like_postprocess(target, azi, args)
            torchvision.utils.save_image(composed, str(renders_dir / path.name))
            torchvision.utils.save_image(target, str(target_copy_dir / path.name))
            if bool(args.save_masks):
                torchvision.utils.save_image(mask.unsqueeze(0), str(masks_dir / path.name))
                torchvision.utils.save_image(shadow.unsqueeze(0), str(shadows_dir / path.name))

    print(f"done: {renders_dir}")


if __name__ == "__main__":
    main()
