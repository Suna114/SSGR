"""
Local SAR target/shadow post-process.

This keeps the existing render untouched outside target/shadow masks.  It is
intended for cases where the background style is already good, but the target
or target-near shadow needs local correction.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import cv2
import numpy as np
from PIL import Image
from tqdm import tqdm


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def _read_rgb(path: Path) -> np.ndarray:
    img = Image.open(path).convert("RGB")
    return np.asarray(img, dtype=np.float32) / 255.0


def _write_rgb(path: Path, img: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    arr = np.clip(img * 255.0 + 0.5, 0, 255).astype(np.uint8)
    Image.fromarray(arr, mode="RGB").save(path)


def _write_gray(path: Path, img: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    arr = np.clip(img * 255.0 + 0.5, 0, 255).astype(np.uint8)
    Image.fromarray(arr, mode="L").save(path)


def _gray(img: np.ndarray) -> np.ndarray:
    return img.mean(axis=2).astype(np.float32)


def _resize_like(img: np.ndarray, ref: np.ndarray) -> np.ndarray:
    if img.shape[:2] == ref.shape[:2]:
        return img
    h, w = ref.shape[:2]
    return cv2.resize(img, (w, h), interpolation=cv2.INTER_LINEAR)


def _morph(mask: np.ndarray, pixels: int) -> np.ndarray:
    pixels = int(pixels)
    if pixels == 0:
        return mask.astype(np.float32)
    kernel = np.ones((3, 3), np.uint8)
    out = mask.astype(np.float32)
    if pixels > 0:
        for _ in range(pixels):
            out = cv2.dilate(out, kernel)
    else:
        for _ in range(-pixels):
            out = cv2.erode(out, kernel)
    return np.clip(out, 0.0, 1.0).astype(np.float32)


def _blur(mask: np.ndarray, radius: int) -> np.ndarray:
    radius = int(radius)
    if radius <= 0:
        return mask.astype(np.float32)
    k = 2 * radius + 1
    return cv2.GaussianBlur(mask.astype(np.float32), (k, k), sigmaX=radius / 2.0 + 1e-6)


def _mean_blur(img: np.ndarray, radius: int) -> np.ndarray:
    radius = int(radius)
    if radius <= 0:
        return img.astype(np.float32)
    k = 2 * radius + 1
    return cv2.blur(img.astype(np.float32), (k, k), borderType=cv2.BORDER_REFLECT)


def _target_mask(mask_img: np.ndarray, threshold: float, quantile: float, dilate: int) -> np.ndarray:
    g = _gray(mask_img)
    q = float(np.quantile(g.reshape(-1), float(quantile)))
    th = max(float(threshold), q)
    mask = (g >= th).astype(np.float32)
    return _morph(mask, dilate)


def _shadow_mask(
    shadow_ref: np.ndarray,
    target_hard: np.ndarray,
    search_dilate: int,
    target_exclude_dilate: int,
    dark_threshold: float,
    ratio_threshold: float,
    context_blur: int,
    soft_blur: int,
    gamma: float,
) -> np.ndarray:
    gray = _gray(shadow_ref)
    target_block = _morph(target_hard, target_exclude_dilate)
    search = (_morph(target_hard, search_dilate) * (1.0 - target_block)).clip(0.0, 1.0)

    dark_threshold = max(float(dark_threshold), 1e-6)
    absolute_dark = ((dark_threshold - gray) / dark_threshold).clip(0.0, 1.0)

    context = _mean_blur(gray, context_blur).clip(1e-4, 1.0)
    ratio_threshold = max(float(ratio_threshold), 1e-6)
    relative_dark = ((context - gray) / ratio_threshold).clip(0.0, 1.0)

    mask = np.maximum(absolute_dark, relative_dark) * search
    mask = _blur(mask, soft_blur).clip(0.0, 1.0)
    gamma = max(float(gamma), 0.05)
    return np.power(mask, gamma).clip(0.0, 1.0).astype(np.float32)


def _find_named(root: Path | None, name: str) -> Path | None:
    if root is None:
        return None
    direct = root / name
    if direct.is_file():
        return direct
    stem = Path(name).stem
    for ext in IMAGE_EXTS:
        cand = root / f"{stem}{ext}"
        if cand.is_file():
            return cand
    return None


def _image_files(root: Path) -> list[Path]:
    return sorted([p for p in root.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS])


def _ensure_dir(path: Path, label: str) -> None:
    if path.is_dir():
        return
    path.mkdir(parents=True, exist_ok=True)
    print(f"[warn] {label} did not exist; created empty directory: {path}")


def process_one(path: Path, args: argparse.Namespace) -> bool:
    render = _read_rgb(path)

    mask_path = _find_named(args.target_mask_dir, path.name)
    if mask_path is None:
        print(f"[skip] target mask not found: {path.name}")
        return False
    mask_img = _resize_like(_read_rgb(mask_path), render)
    target_hard = _target_mask(
        mask_img,
        threshold=args.target_mask_threshold,
        quantile=args.target_mask_quantile,
        dilate=args.target_mask_dilate,
    )

    out = render.copy()
    target_alpha = np.zeros(render.shape[:2], dtype=np.float32)
    if args.target_source_dir is not None and args.target_strength > 0.0:
        target_path = _find_named(args.target_source_dir, path.name)
        if target_path is None:
            print(f"[warn] target source not found, target unchanged: {path.name}")
        else:
            target_src = _resize_like(_read_rgb(target_path), render)
            target_alpha = _morph(target_hard, args.target_alpha_dilate)
            target_alpha = _blur(target_alpha, args.target_alpha_blur).clip(0.0, 1.0)
            target_alpha = np.power(target_alpha, max(float(args.target_alpha_gamma), 0.05))
            target_alpha = (target_alpha * np.clip(float(args.target_strength), 0.0, 1.0)).clip(0.0, 1.0)
            out = out * (1.0 - target_alpha[..., None]) + target_src * target_alpha[..., None]

    shadow_alpha = np.zeros(render.shape[:2], dtype=np.float32)
    if args.shadow_source_dir is not None and args.shadow_strength > 0.0:
        shadow_path = _find_named(args.shadow_source_dir, path.name)
        if shadow_path is None:
            print(f"[warn] shadow source not found, shadow unchanged: {path.name}")
        else:
            shadow_ref = _resize_like(_read_rgb(shadow_path), render)
            shadow_alpha = _shadow_mask(
                shadow_ref,
                target_hard,
                search_dilate=args.shadow_search_dilate,
                target_exclude_dilate=args.shadow_target_exclude_dilate,
                dark_threshold=args.shadow_dark_threshold,
                ratio_threshold=args.shadow_ratio_threshold,
                context_blur=args.shadow_context_blur,
                soft_blur=args.shadow_soft_blur,
                gamma=args.shadow_gamma,
            )
            amount = (shadow_alpha * np.clip(float(args.shadow_strength), 0.0, 1.0)).clip(0.0, 1.0)
            if args.shadow_mode == "blend_reference":
                out = out * (1.0 - amount[..., None]) + shadow_ref * amount[..., None]
            elif args.shadow_mode == "min_reference":
                shadowed = np.minimum(out, shadow_ref)
                out = out * (1.0 - amount[..., None]) + shadowed * amount[..., None]
            else:
                ref_gray = _gray(shadow_ref)
                context = _mean_blur(ref_gray, args.shadow_context_blur).clip(1e-4, 1.0)
                attenuation = (ref_gray / context).clip(float(args.shadow_min_attenuation), 1.0)
                attenuation = np.power(attenuation, max(float(args.shadow_attenuation_power), 0.05))
                shadowed = out * attenuation[..., None] + float(args.shadow_floor) * (1.0 - attenuation[..., None])
                out = out * (1.0 - amount[..., None]) + shadowed * amount[..., None]

    out_path = args.output_dir / path.name
    _write_rgb(out_path, out)
    if args.save_maps:
        stem = path.stem
        maps = args.output_dir / "maps"
        _write_gray(maps / f"{stem}_target_alpha.png", target_alpha)
        _write_gray(maps / f"{stem}_shadow_alpha.png", shadow_alpha)
        _write_gray(maps / f"{stem}_target_hard.png", target_hard)
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--render_dir", type=Path, required=True)
    parser.add_argument("--output_dir", type=Path, required=True)
    parser.add_argument("--target_mask_dir", type=Path, required=True)
    parser.add_argument("--target_source_dir", type=Path, default=None)
    parser.add_argument("--shadow_source_dir", type=Path, default=None)
    parser.add_argument("--target_mask_threshold", type=float, default=0.08)
    parser.add_argument("--target_mask_quantile", type=float, default=0.35)
    parser.add_argument("--target_mask_dilate", type=int, default=0)
    parser.add_argument("--target_strength", type=float, default=0.0)
    parser.add_argument("--target_alpha_dilate", type=int, default=0)
    parser.add_argument("--target_alpha_blur", type=int, default=1)
    parser.add_argument("--target_alpha_gamma", type=float, default=1.0)
    parser.add_argument("--shadow_strength", type=float, default=0.0)
    parser.add_argument("--shadow_mode", choices=["blend_reference", "min_reference", "extinguish"], default="blend_reference")
    parser.add_argument("--shadow_search_dilate", type=int, default=45)
    parser.add_argument("--shadow_target_exclude_dilate", type=int, default=1)
    parser.add_argument("--shadow_dark_threshold", type=float, default=0.18)
    parser.add_argument("--shadow_ratio_threshold", type=float, default=0.16)
    parser.add_argument("--shadow_context_blur", type=int, default=17)
    parser.add_argument("--shadow_soft_blur", type=int, default=1)
    parser.add_argument("--shadow_gamma", type=float, default=1.0)
    parser.add_argument("--shadow_min_attenuation", type=float, default=0.03)
    parser.add_argument("--shadow_attenuation_power", type=float, default=2.0)
    parser.add_argument("--shadow_floor", type=float, default=0.0)
    parser.add_argument("--save_maps", action="store_true", default=False)
    args = parser.parse_args()

    _ensure_dir(args.render_dir, "render_dir")
    _ensure_dir(args.target_mask_dir, "target_mask_dir")
    if args.target_source_dir is not None:
        _ensure_dir(args.target_source_dir, "target_source_dir")
    if args.shadow_source_dir is not None:
        _ensure_dir(args.shadow_source_dir, "shadow_source_dir")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    files = _image_files(args.render_dir)
    if not files:
        print(f"[warn] No images found in render_dir: {args.render_dir}")
        print("[done] saved 0/0 images. Check whether the input path points to the directory that contains render images.")
        return 0

    ok = 0
    for path in tqdm(files, desc="postprocess target/shadow", unit="img"):
        ok += int(process_one(path, args))
    print(f"[done] saved {ok}/{len(files)} images to {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
