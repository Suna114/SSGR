#!/usr/bin/env python3
"""
Clean SAR target layover refiner.

This script is intentionally narrow: it learns a target-only, azimuth-conditioned
log-domain correction from 3DGS target renders to adjacent real SAR target style.
It does not synthesize background, paste back the source target, or paint shadows
as a postprocess.
"""

from __future__ import annotations

import json
import math
import re
import sys
from argparse import ArgumentParser, BooleanOptionalAction
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from tqdm import tqdm

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from scripts.rendering.learn_sar_image_refiner import (  # noqa: E402
    _blur01,
    _dilate01_batch,
    _force_grayscale_batch,
    _gradient_mag_map,
    _image_files,
    _load_image,
    _load_style_refs,
    _local_std_map,
    _nearest_style_ref,
    _parse_azimuth,
    _parse_quantiles,
    _resize_chw,
)


def _chw1(mask: torch.Tensor) -> torch.Tensor:
    if mask.dim() == 2:
        return mask[None]
    if mask.dim() == 3:
        return mask[:1]
    raise ValueError(f"Expected 2D/3D mask, got shape {tuple(mask.shape)}")


def _region_classification_rgb(target_mask: torch.Tensor, shadow_mask: torch.Tensor | None = None) -> tuple[torch.Tensor, torch.Tensor]:
    """Return RGB classes: white=target, blue=shadow, black=background."""
    target = (_chw1(target_mask).float().clamp(0.0, 1.0) > 0.5).float()
    if shadow_mask is None:
        shadow = torch.zeros_like(target)
    else:
        shadow = _chw1(shadow_mask).float().clamp(0.0, 1.0) * (1.0 - target)
    background = (1.0 - torch.maximum(target, (shadow > 0.05).float())).clamp(0.0, 1.0)
    rgb = torch.cat([target, target, torch.maximum(target, shadow)], dim=0).clamp(0.0, 1.0)
    return rgb, background


class ConvBlock(nn.Module):
    def __init__(self, cin: int, cout: int, padding_mode: str = "reflect"):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(cin, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
            nn.Conv2d(cout, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class LocalFeatureEnhancer(nn.Module):
    """DHFR-style local spatial enhancement with neutral initialization."""

    def __init__(self, channels: int, strength: float = 0.25, padding_mode: str = "reflect"):
        super().__init__()
        hidden = max(8, int(channels) // 4)
        self.strength = float(strength)
        self.mask = nn.Sequential(
            nn.Conv2d(channels, hidden, 3, padding=1, padding_mode=padding_mode),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, 1, 1),
        )
        nn.init.zeros_(self.mask[-1].weight)
        nn.init.zeros_(self.mask[-1].bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        mask = torch.sigmoid(self.mask(x))
        gain = 1.0 + self.strength * (mask - 0.5) * 2.0
        return x * gain


class DynamicHierarchicalFusion(nn.Module):
    """Fuse decoder and skip features with input-adaptive branch weights."""

    def __init__(self, decoder_ch: int, skip_ch: int, padding_mode: str = "reflect"):
        super().__init__()
        self.skip_enhance = LocalFeatureEnhancer(skip_ch, padding_mode=padding_mode)
        hidden = max(8, (int(decoder_ch) + int(skip_ch)) // 8)
        self.global_gate = nn.Sequential(
            nn.Linear(int(decoder_ch) + int(skip_ch), hidden),
            nn.SiLU(inplace=True),
            nn.Linear(hidden, 2),
        )
        nn.init.zeros_(self.global_gate[-1].weight)
        nn.init.zeros_(self.global_gate[-1].bias)

    def forward(self, decoder: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        skip = self.skip_enhance(skip)
        gd = F.adaptive_avg_pool2d(decoder, 1).flatten(1)
        gs = F.adaptive_avg_pool2d(skip, 1).flatten(1)
        weights = torch.softmax(self.global_gate(torch.cat([gd, gs], dim=1)), dim=1)
        decoder = decoder * (2.0 * weights[:, 0].view(-1, 1, 1, 1))
        skip = skip * (2.0 * weights[:, 1].view(-1, 1, 1, 1))
        return torch.cat([decoder, skip], dim=1)


class CleanLayoverUNet(nn.Module):
    def __init__(self, in_ch: int = 5, base: int = 32, padding_mode: str = "reflect"):
        super().__init__()
        self.e1 = ConvBlock(in_ch, base, padding_mode)
        self.e2 = ConvBlock(base, base * 2, padding_mode)
        self.e3 = ConvBlock(base * 2, base * 4, padding_mode)
        self.mid = ConvBlock(base * 4, base * 4, padding_mode)
        self.fuse2 = DynamicHierarchicalFusion(base * 4, base * 2, padding_mode)
        self.fuse1 = DynamicHierarchicalFusion(base * 2, base, padding_mode)
        self.d2 = ConvBlock(base * 6, base * 2, padding_mode)
        self.d1 = ConvBlock(base * 3, base, padding_mode)
        self.out = nn.Conv2d(base, 3, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e1 = self.e1(x)
        e2 = self.e2(F.avg_pool2d(e1, 2))
        e3 = self.e3(F.avg_pool2d(e2, 2))
        y = self.mid(e3)
        y = F.interpolate(y, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d2(self.fuse2(y, e2))
        y = F.interpolate(y, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d1(self.fuse1(y, e1))
        return self.out(y)


def _load_state_dict_compatible(model: nn.Module, state_dict: dict, label: str) -> None:
    try:
        model.load_state_dict(state_dict, strict=True)
        return
    except RuntimeError:
        pass

    current = model.state_dict()
    filtered = {}
    skipped = []
    for key, value in state_dict.items():
        if key in current and tuple(current[key].shape) == tuple(value.shape):
            filtered[key] = value
        else:
            skipped.append(key)
    missing, unexpected = model.load_state_dict(filtered, strict=False)
    print(
        f"[clean layover] compatible load for {label}: "
        f"loaded={len(filtered)}, skipped={len(skipped)}, "
        f"missing={len(missing)}, unexpected={len(unexpected)}"
    )


def _configure_torch(args, device: torch.device) -> None:
    if device.type != "cuda":
        return
    allow_tf32 = bool(getattr(args, "allow_tf32", True))
    if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
        torch.backends.cuda.matmul.allow_tf32 = allow_tf32
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.allow_tf32 = allow_tf32
        torch.backends.cudnn.benchmark = bool(getattr(args, "cudnn_benchmark", True))
    try:
        torch.set_float32_matmul_precision("high" if allow_tf32 else "highest")
    except Exception:
        pass


def _derive_paths(args) -> None:
    model_path = Path(args.model_path) if args.model_path else None
    if model_path is not None:
        args.train_target_dir = args.train_target_dir or str(model_path / "train_renders")
        args.train_gt_dir = args.train_gt_dir or str(model_path / "train_gt")
        args.apply_target_dir = args.apply_target_dir or str(model_path / "novel_target_only" / "target_renders")
        args.output_dir = args.output_dir or str(model_path / "novel_sar_target_layover_clean")
        args.checkpoint = args.checkpoint or str(model_path / "sar_target_layover_refiner_clean.pth")
    if not args.checkpoint:
        args.checkpoint = str(Path(args.output_dir or ".") / "sar_target_layover_refiner_clean.pth")


def _ld(x: torch.Tensor, scale: float) -> torch.Tensor:
    return torch.log1p(x.clamp(0.0, 1.0) * scale) / math.log1p(scale)


def _from_ld(x: torch.Tensor, scale: float) -> torch.Tensor:
    return torch.expm1(x.clamp(0.0, 1.0) * math.log1p(scale)) / scale


def _angle_dist(a: float, b: float) -> float:
    d = abs(float(a) - float(b)) % 360.0
    return min(d, 360.0 - d)


def _azimuth_prefix(path: Path) -> str:
    stem = path.stem
    m = re.search(r"(?i)azimuth[_-]?(\d+(?:\.\d+)?)", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    m = re.search(r"(\d+(?:\.\d+)?)$", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    return stem


def _candidates(path: Path) -> list[dict]:
    return [{"path": p, "azimuth": _parse_azimuth(p), "prefix": _azimuth_prefix(p)} for p in _image_files(path)]


def _nearest(cands: list[dict], az: float) -> dict:
    if not cands:
        raise RuntimeError("No azimuth candidates")
    return min(cands, key=lambda c: (_angle_dist(float(c["azimuth"]), az), c["path"].name))


def _bracket(cands: list[dict], az: float) -> tuple[dict, dict, float, float]:
    ordered = sorted(cands, key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    if not ordered:
        raise RuntimeError("No GT candidates")
    if len(ordered) == 1:
        return ordered[0], ordered[0], 1.0, 0.0
    target = float(az) % 360.0
    exact = [c for c in ordered if _angle_dist(float(c["azimuth"]), target) <= 1e-6]
    if exact:
        return exact[0], exact[0], 1.0, 0.0
    back = [((target - float(c["azimuth"])) % 360.0, c) for c in ordered]
    fwd = [((float(c["azimuth"]) - target) % 360.0, c) for c in ordered]
    prev_gap, prev = min((x for x in back if x[0] > 1e-6), key=lambda x: (x[0], x[1]["path"].name))
    next_gap, nxt = min((x for x in fwd if x[0] > 1e-6), key=lambda x: (x[0], x[1]["path"].name))
    total = max(prev_gap + next_gap, 1e-6)
    return prev, nxt, next_gap / total, prev_gap / total


def _select_pairs(target_dir: Path, gt_dir: Path, args) -> list[dict]:
    targets = sorted(_candidates(target_dir), key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    gts = _candidates(gt_dir)
    if not targets or not gts:
        raise RuntimeError(f"No training images found: {target_dir} vs {gt_dir}")
    gt_by_prefix: dict[str, list[dict]] = {}
    for g in gts:
        gt_by_prefix.setdefault(g["prefix"], []).append(g)
    selected = []
    if not bool(getattr(args, "train_use_all_targets", False)):
        step = max(float(getattr(args, "train_azimuth_step", 10.0) or 10.0), 1e-6)
        slots = {round((i * step) % 360.0, 6) for i in range(int(math.ceil(360.0 / step)))}
        targets = [_nearest(targets, s) for s in sorted(slots)]
    for t in targets:
        az = float(t["azimuth"]) % 360.0
        pool = gt_by_prefix.get(t["prefix"], gts)
        lo, hi, wlo, whi = _bracket(pool, az)
        selected.append({"target": t["path"], "azimuth": az, "lo": lo, "hi": hi, "wlo": wlo, "whi": whi})
    return selected


def _mix_gt(gt_lo: torch.Tensor, gt_hi: torch.Tensor, wlo: float, whi: float, scale: float) -> torch.Tensor:
    lo = _ld(gt_lo, scale)
    hi = _ld(gt_hi, scale)
    return _from_ld(lo * float(wlo) + hi * float(whi), scale).clamp(0.0, 1.0)


def _target_mask(target: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    threshold = float(getattr(args, "target_loss_mask_threshold", 0.08) or 0.08)
    mask = (gray > threshold).float()
    if float(mask.sum()) < float(getattr(args, "target_loss_mask_min_pixels", 16.0) or 16.0):
        vals = gray[gray > 0]
        if int(vals.numel()) > 0:
            mask = (gray >= torch.quantile(vals, 0.35)).float()
    dilate = int(getattr(args, "target_loss_mask_dilate", 2) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    return mask.clamp(0.0, 1.0)


def _compose_alpha_one(target: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    low = max(float(getattr(args, "compose_alpha_threshold", 0.012) or 0.012), 0.0)
    high = max(float(getattr(args, "compose_alpha_high", 0.08) or 0.08), low + 1e-6)
    alpha = ((gray - low) / (high - low)).clamp(0.0, 1.0)
    alpha = alpha.pow(max(float(getattr(args, "compose_alpha_gamma", 0.8) or 0.8), 0.05))
    dilate = int(getattr(args, "compose_alpha_dilate", 0) or 0)
    if dilate > 0:
        alpha = _dilate01_batch(alpha[None], dilate)[0]
    blur = int(getattr(args, "compose_alpha_blur", 0) or 0)
    if blur > 0:
        alpha = _blur01(alpha, blur)
    return alpha.clamp(0.0, 1.0)


def _compose_alpha_batch(target: torch.Tensor, args) -> torch.Tensor:
    if target.dim() == 3:
        return _compose_alpha_one(target, args)
    return torch.stack([_compose_alpha_one(target[i], args) for i in range(target.shape[0])], dim=0)


def _azimuth_harmonic_channels(
    azimuth: float,
    h: int,
    w: int,
    device: torch.device,
    dtype: torch.dtype,
    harmonics: int,
) -> list[torch.Tensor]:
    rad = math.radians(float(azimuth) % 360.0)
    channels: list[torch.Tensor] = []
    for k in range(1, max(1, int(harmonics)) + 1):
        channels.append(torch.full((1, h, w), math.sin(k * rad), device=device, dtype=dtype))
        channels.append(torch.full((1, h, w), math.cos(k * rad), device=device, dtype=dtype))
    return channels


def _input_channel_count(args) -> int:
    return 3 + 2 * max(1, int(getattr(args, "azimuth_harmonics", 5) or 1))


def _make_input(target: torch.Tensor, mask: torch.Tensor, azimuth: float, scale: float, args) -> torch.Tensor:
    gray = target.mean(dim=0, keepdim=True).clamp(0.0, 1.0)
    ld = _ld(gray, scale)
    h, w = gray.shape[-2:]
    az = _azimuth_harmonic_channels(
        azimuth,
        h,
        w,
        target.device,
        target.dtype,
        int(getattr(args, "azimuth_harmonics", 5) or 1),
    )
    return torch.cat([gray, ld, mask[None], *az], dim=0)


def _dark_supervision(target: torch.Tensor, gt_mix: torch.Tensor, gt_lo: torch.Tensor, gt_hi: torch.Tensor, mask: torch.Tensor, args) -> torch.Tensor:
    scale = float(getattr(args, "log_intensity_scale", 20.0) or 20.0)
    src = _ld(target.mean(dim=0, keepdim=True), scale)[0]
    mix = _ld(gt_mix.mean(dim=0, keepdim=True), scale)[0]
    lo = _ld(gt_lo.mean(dim=0, keepdim=True), scale)[0]
    hi = _ld(gt_hi.mean(dim=0, keepdim=True), scale)[0]
    # A dark layover candidate is bright in the 3DGS target but dark in either
    # adjacent real view.  Using min(lo, hi) avoids averaging dark structures away.
    gt_dark = torch.minimum(lo, hi)
    bright_src = ((src - float(args.dark_src_threshold)) / max(1e-6, 1.0 - float(args.dark_src_threshold))).clamp(0.0, 1.0)
    dark_gap = ((src - gt_dark - float(args.dark_gap_threshold)) / max(float(args.dark_gap_softness), 1e-6)).clamp(0.0, 1.0)
    mix_gap = ((src - mix - float(args.dark_gap_threshold) * 0.5) / max(float(args.dark_gap_softness), 1e-6)).clamp(0.0, 1.0)
    dark = torch.maximum(dark_gap, mix_gap * 0.5) * bright_src * mask
    blur = int(getattr(args, "dark_supervision_blur", 1) or 0)
    if blur > 0:
        dark = _blur01(dark, blur) * mask
    return dark.clamp(0.0, 1.0)


def _content_support(gt: torch.Tensor, mask: torch.Tensor, args) -> torch.Tensor:
    gray = gt.mean(dim=0).clamp(0.0, 1.0)
    threshold = max(float(getattr(args, "content_gt_support_threshold", 0.015) or 0.015), 0.0)
    support = (gray > threshold).float() * mask
    dilate = int(getattr(args, "content_gt_support_dilate", 1) or 0)
    if dilate > 0:
        support = _dilate01_batch(support[None], dilate)[0] * mask
    blur = int(getattr(args, "content_gt_support_blur", 0) or 0)
    if blur > 0:
        support = _blur01(support, blur) * mask
    return support.clamp(0.0, 1.0)


def _erode01_one(mask: torch.Tensor, radius: int) -> torch.Tensor:
    if radius <= 0:
        return mask.clamp(0.0, 1.0)
    inv = (1.0 - mask).clamp(0.0, 1.0)
    return (1.0 - _dilate01_batch(inv[None], radius)[0]).clamp(0.0, 1.0)


def _shift_zero_2d(x: torch.Tensor, dx: int, dy: int) -> torch.Tensor:
    out = torch.zeros_like(x)
    h, w = x.shape[-2:]
    if abs(dx) >= w or abs(dy) >= h:
        return out
    src_x0 = max(0, -dx)
    src_x1 = min(w, w - dx)
    dst_x0 = max(0, dx)
    dst_x1 = min(w, w + dx)
    src_y0 = max(0, -dy)
    src_y1 = min(h, h - dy)
    dst_y0 = max(0, dy)
    dst_y1 = min(h, h + dy)
    out[dst_y0:dst_y1, dst_x0:dst_x1] = x[src_y0:src_y1, src_x0:src_x1]
    return out


def _masked_blur_fill_chw(x: torch.Tensor, valid_mask: torch.Tensor, radius: int) -> torch.Tensor:
    if radius <= 0:
        return x.clamp(0.0, 1.0)
    valid = valid_mask.float().clamp(0.0, 1.0)
    valid_bool = valid > 0.5
    denom = _blur01(valid, radius)
    filled = []
    for c in range(x.shape[0]):
        vals = x[c][valid_bool]
        mean = vals.mean() if int(vals.numel()) > 0 else x[c].mean()
        num = _blur01((x[c] * valid).clamp(0.0, 1.0), radius)
        ch = torch.where(denom > 1e-4, num / denom.clamp_min(1e-4), torch.full_like(num, mean))
        filled.append(ch)
    return torch.stack(filled, dim=0).clamp(0.0, 1.0)


def _clean_background_reference(ref: torch.Tensor, exclude_mask: torch.Tensor, radius: int) -> tuple[torch.Tensor, torch.Tensor]:
    valid = (exclude_mask < 0.5).float().clamp(0.0, 1.0)
    fill = _masked_blur_fill_chw(ref, valid, radius)
    clean = (ref * valid.unsqueeze(0) + fill * (1.0 - valid).unsqueeze(0)).clamp(0.0, 1.0)
    return clean, fill


def _sample_pixel_background(ref: torch.Tensor, exclude_mask: torch.Tensor, azimuth_deg: float, args) -> torch.Tensor:
    if bool(getattr(args, "empirical_background_clean_reference", True)):
        clean_ref, _fill = _clean_background_reference(
            ref,
            exclude_mask,
            max(1, int(getattr(args, "empirical_background_fallback_blur", 9) or 9)),
        )
        gray = clean_ref.mean(dim=0)
    else:
        gray = ref.mean(dim=0)
    valid = exclude_mask < 0.5
    vals = gray[valid]
    if int(vals.numel()) < 64:
        vals = gray.reshape(-1)
    h, w = gray.shape
    gen = torch.Generator(device=ref.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 3301)
    idx = torch.randint(0, int(vals.numel()), (h * w,), device=ref.device, generator=gen)
    bg = vals[idx].view(h, w)
    return bg.unsqueeze(0).expand_as(ref).contiguous()


def _sample_patch_background(ref: torch.Tensor, exclude_mask: torch.Tensor, azimuth_deg: float, args) -> torch.Tensor:
    h, w = ref.shape[-2:]
    tile = max(4, int(getattr(args, "empirical_background_patch_size", 24) or 24))
    overlap = min(max(0, int(getattr(args, "empirical_background_patch_overlap", 6) or 0)), tile - 1)
    stride = max(1, tile - overlap)
    valid = (exclude_mask < 0.5).float()
    if bool(getattr(args, "empirical_background_clean_reference", True)):
        clean_ref, fallback_rgb = _clean_background_reference(
            ref,
            exclude_mask,
            max(1, int(getattr(args, "empirical_background_fallback_blur", 9) or 9)),
        )
    else:
        clean_ref = ref
        fallback = _blur01(ref.mean(dim=0), max(1, int(getattr(args, "empirical_background_fallback_blur", 9) or 9)))
        fallback_rgb = fallback.unsqueeze(0).expand_as(ref)

    out = torch.zeros_like(ref)
    weight = torch.zeros((1, h, w), device=ref.device, dtype=ref.dtype)
    gen = torch.Generator(device=ref.device)
    gen.manual_seed(int(getattr(args, "noise_seed", 1234)) + int(round(float(azimuth_deg) * 1000.0)) + 7411)

    ys = list(range(0, h, stride))
    xs = list(range(0, w, stride))
    min_valid = float(getattr(args, "empirical_background_patch_min_valid", 0.70) or 0.70)
    candidates: dict[tuple[int, int], list[tuple[int, int]]] = {}
    for y in ys:
        ph = min(tile, h - y)
        for x in xs:
            pw = min(tile, w - x)
            key = (ph, pw)
            if key not in candidates:
                cur = []
                for sy in range(0, h - ph + 1, max(1, ph // 3)):
                    for sx in range(0, w - pw + 1, max(1, pw // 3)):
                        if float(valid[sy : sy + ph, sx : sx + pw].mean().item()) >= min_valid:
                            cur.append((sy, sx))
                if not cur:
                    cur = [(max(0, (h - ph) // 2), max(0, (w - pw) // 2))]
                candidates[key] = cur
            cur = candidates[key]
            sy, sx = cur[int(torch.randint(0, len(cur), (1,), device=ref.device, generator=gen).item())]
            out[:, y : y + ph, x : x + pw] += clean_ref[:, sy : sy + ph, sx : sx + pw]
            weight[:, y : y + ph, x : x + pw] += 1.0

    fallback_weight = max(float(getattr(args, "empirical_background_patch_fallback_weight", 1.0) or 0.0), 0.0)
    if fallback_weight > 0.0:
        out = (out + fallback_rgb * fallback_weight) / (weight + fallback_weight).clamp_min(1e-6)
    else:
        out = torch.where(weight > 0.0, out / weight.clamp_min(1.0), fallback_rgb)
    smooth = int(getattr(args, "empirical_background_patch_smooth", 1) or 0)
    if smooth > 0:
        low = torch.stack([_blur01(out[c], smooth) for c in range(out.shape[0])], dim=0)
        mix = min(max(float(getattr(args, "empirical_background_patch_smooth_mix", 0.35) or 0.0), 0.0), 1.0)
        out = out * (1.0 - mix) + low * mix
    return out.clamp(0.0, 1.0)


def _sample_structured_background(ref: torch.Tensor, exclude_mask: torch.Tensor, azimuth_deg: float, args) -> torch.Tensor:
    mode = str(getattr(args, "empirical_background_mode", "patch") or "patch").lower().strip()
    if mode == "reference":
        if bool(getattr(args, "empirical_background_clean_reference", True)):
            clean, _fill = _clean_background_reference(
                ref,
                exclude_mask,
                max(1, int(getattr(args, "empirical_background_fallback_blur", 9) or 9)),
            )
            return clean
        return ref.clamp(0.0, 1.0)
    if mode == "pixel":
        return _sample_pixel_background(ref, exclude_mask, azimuth_deg, args)
    return _sample_patch_background(ref, exclude_mask, azimuth_deg, args)


def _make_empirical_background(
    image: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
) -> torch.Tensor | None:
    strength = float(getattr(args, "empirical_background_strength", 0.0) or 0.0)
    if strength <= 0.0 or style_ref is None:
        return None
    style_ref = _resize_chw(style_ref, tuple(image.shape[-2:]))
    hmask = hard_mask.float().clamp(0.0, 1.0)
    exclude = _dilate01_batch(
        hmask[None],
        int(getattr(args, "empirical_background_reference_exclude_dilate", 24) or 0),
    )[0]
    bg = _sample_structured_background(style_ref, exclude, azimuth_deg, args)
    scale = float(getattr(args, "empirical_background_scale", 1.0) or 1.0)
    bias = float(getattr(args, "empirical_background_bias", 0.0) or 0.0)
    bg = (bg * scale + bias).clamp(0.0, 1.0)
    if bool(getattr(args, "empirical_background_match_target_peak", False)):
        target = hmask > 0.5
        bg_region = exclude < 0.5
        image_gray = image.mean(dim=0).clamp(0.0, 1.0)
        bg_gray = bg.mean(dim=0).clamp(0.0, 1.0)
        target_vals = image_gray[target & (image_gray > 1e-6)]
        bg_vals = bg_gray[bg_region & (bg_gray > 1e-6)]
        if int(target_vals.numel()) >= 4 and int(bg_vals.numel()) >= 16:
            tq = min(max(float(getattr(args, "empirical_background_target_peak_quantile", 0.95) or 0.95), 0.0), 1.0)
            bq = min(max(float(getattr(args, "empirical_background_peak_quantile", 0.995) or 0.995), 0.0), 1.0)
            target_peak = torch.quantile(target_vals, tq).clamp_min(1e-4)
            bg_peak = torch.quantile(bg_vals, bq).clamp_min(1e-4)
            max_scale = max(float(getattr(args, "empirical_background_peak_max_scale", 2.5) or 2.5), 1.0)
            peak_scale = (target_peak / bg_peak).clamp(1.0, max_scale)
            mix = min(max(float(getattr(args, "empirical_background_peak_mix", 1.0) or 1.0), 0.0), 1.0)
            bg = (bg * (1.0 - mix) + (bg * peak_scale).clamp(0.0, 1.0) * mix).clamp(0.0, 1.0)
    return bg


def _layer_target_alpha(mod_target: torch.Tensor, hard_mask: torch.Tensor, compose_alpha: torch.Tensor | None, args) -> torch.Tensor:
    gray = mod_target.mean(dim=0).clamp(0.0, 1.0)
    low = max(float(getattr(args, "layer_target_alpha_threshold", 0.035) or 0.035), 0.0)
    high = max(float(getattr(args, "layer_target_alpha_high", 0.12) or 0.12), low + 1e-6)
    alpha = ((gray - low) / (high - low)).clamp(0.0, 1.0)
    alpha = alpha.pow(max(float(getattr(args, "layer_target_alpha_gamma", 0.75) or 0.75), 0.05))
    if bool(getattr(args, "layer_target_use_compose_alpha", False)) and compose_alpha is not None:
        mix = min(max(float(getattr(args, "layer_target_compose_alpha_mix", 0.35) or 0.0), 0.0), 1.0)
        alpha = torch.maximum(alpha, compose_alpha.squeeze().float().clamp(0.0, 1.0) * mix)
    hmask = hard_mask.float().clamp(0.0, 1.0)
    target_dilate = int(getattr(args, "layer_target_dilate", 0) or 0)
    if target_dilate > 0:
        support = _dilate01_batch(hmask[None], target_dilate)[0]
    elif target_dilate < 0:
        support = _erode01_one(hmask, -target_dilate)
    else:
        support = hmask
    alpha = (alpha * support).clamp(0.0, 1.0)
    mask_floor = min(max(float(getattr(args, "layer_target_mask_floor", 0.35) or 0.0), 0.0), 1.0)
    if mask_floor > 0.0:
        alpha = torch.maximum(alpha, hmask * mask_floor).clamp(0.0, 1.0)
    contact_width = int(getattr(args, "layer_target_contact_width", 2) or 0)
    contact_strength = min(max(float(getattr(args, "layer_target_contact_strength", 0.45) or 0.0), 0.0), 1.0)
    if contact_width > 0 and contact_strength > 0.0:
        outer = _dilate01_batch(hmask[None], contact_width)[0]
        inner = _erode01_one(hmask, max(1, contact_width // 2))
        contact = (outer - inner).clamp(0.0, 1.0)
        contact_blur = int(getattr(args, "layer_target_contact_blur", 1) or 0)
        if contact_blur > 0:
            contact = _blur01(contact, contact_blur)
        alpha = torch.maximum(alpha, contact * contact_strength).clamp(0.0, 1.0)
    blur = int(getattr(args, "layer_target_blur", 1) or 0)
    if blur > 0:
        alpha = (_blur01(alpha, blur) * _dilate01_batch(support[None], max(1, blur))[0]).clamp(0.0, 1.0)
    strength = min(max(float(getattr(args, "layer_target_strength", 1.0) or 1.0), 0.0), 1.0)
    return (alpha * strength).clamp(0.0, 1.0)


def _directional_shadow_mask(hard_mask: torch.Tensor, azimuth_deg: float, args) -> tuple[torch.Tensor, torch.Tensor]:
    strength = float(getattr(args, "shadow_directional_strength", 1.0) or 0.0)
    length = int(getattr(args, "shadow_directional_length", 42) or 0)
    if strength <= 0.0 or length <= 0:
        z = torch.zeros_like(hard_mask.float())
        return z, z
    hmask = hard_mask.float().clamp(0.0, 1.0)
    offset = float(getattr(args, "shadow_direction_offset_deg", 180.0) or 0.0)
    sign = -1.0 if float(getattr(args, "shadow_direction_sign", 1.0) or 1.0) < 0.0 else 1.0
    rad = math.radians((float(azimuth_deg) + offset) % 360.0)
    dx = math.cos(rad) * sign
    dy = math.sin(rad) * sign
    decay = max(float(getattr(args, "shadow_directional_decay", 18.0) or 18.0), 1e-6)
    accum = torch.zeros_like(hmask)
    weight = torch.zeros_like(hmask)
    for step in range(1, length + 1):
        sx = int(round(dx * step))
        sy = int(round(dy * step))
        if sx == 0 and sy == 0:
            continue
        shifted = _shift_zero_2d(hmask, sx, sy)
        w = math.exp(-float(step) / decay)
        accum = torch.maximum(accum, shifted * w)
        weight = torch.maximum(weight, shifted)
    lateral_blur = int(getattr(args, "shadow_directional_lateral_blur", 5) or 0)
    if lateral_blur > 0:
        accum = _blur01(accum, lateral_blur)
        weight = _blur01(weight, lateral_blur)
    protect = int(getattr(args, "shadow_restore_target_protect_dilate", 1) or 0)
    protect_mask = _dilate01_batch(hmask[None], protect)[0] if protect > 0 else hmask
    candidate = (accum * (1.0 - protect_mask) * strength).clamp(0.0, 1.0)
    return candidate, weight.clamp(0.0, 1.0)


def _reference_connected_shadow_mask(
    ref_evidence: torch.Tensor,
    hard_mask: torch.Tensor,
    valid_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    hmask = hard_mask.float().clamp(0.0, 1.0)
    evidence = ref_evidence.float().clamp(0.0, 1.0)
    valid = valid_mask.float().clamp(0.0, 1.0)
    length = max(1, int(getattr(args, "shadow_restore_target_dilate", 40) or 40))
    decay = max(float(getattr(args, "shadow_connected_decay", 24.0) or 24.0), 1e-6)
    min_evidence = min(max(float(getattr(args, "shadow_reference_min_evidence", 0.05) or 0.05), 0.0), 1.0)
    protect = int(getattr(args, "shadow_restore_target_protect_dilate", 1) or 0)
    frontier = _dilate01_batch(hmask[None], protect)[0] if protect > 0 else hmask
    connected = torch.zeros_like(hmask)
    for step in range(1, length + 1):
        grown = _dilate01_batch(frontier[None], 1)[0]
        ring = (grown - frontier).clamp(0.0, 1.0) * valid
        if float(ring.max().item()) <= 0.0:
            frontier = grown.clamp(0.0, 1.0)
            continue
        step_decay = math.exp(-float(step) / decay)
        connected = torch.maximum(connected, ring * evidence * step_decay)
        passable = ring * (evidence >= min_evidence).float()
        frontier = torch.maximum(frontier, passable).clamp(0.0, 1.0)
    blur = int(getattr(args, "shadow_connected_blur", 2) or 0)
    if blur > 0:
        connected = (_blur01(connected, blur) * valid).clamp(0.0, 1.0)
    return connected.clamp(0.0, 1.0)


def _restore_reference_shadow(
    image: torch.Tensor,
    reference: torch.Tensor | None,
    hard_mask: torch.Tensor,
    azimuth_deg: float,
    args,
) -> tuple[torch.Tensor, torch.Tensor | None]:
    strength = float(getattr(args, "shadow_restore_strength", 0.0) or 0.0)
    if strength <= 0.0:
        return image.clamp(0.0, 1.0), None
    hmask = hard_mask.float().clamp(0.0, 1.0)
    directional, directional_support = _directional_shadow_mask(hmask, azimuth_deg, args)
    near = _dilate01_batch(hmask[None], int(getattr(args, "shadow_restore_target_dilate", 40) or 0))[0]
    valid = (near * (1.0 - hmask)).clamp(0.0, 1.0)

    ref_shadow = None
    ref_connected = None
    attenuation = torch.ones_like(hmask)
    if reference is not None:
        reference = _resize_chw(reference, tuple(image.shape[-2:]))
        if bool(getattr(args, "shadow_restore_clean_reference", False)):
            target_exclude = _dilate01_batch(
                hmask[None],
                int(getattr(args, "shadow_restore_target_protect_dilate", 2) or 0),
            )[0]
            reference, _fill = _clean_background_reference(
                reference,
                target_exclude,
                max(1, int(getattr(args, "shadow_restore_reference_blur", 0) or 0), int(getattr(args, "empirical_background_fallback_blur", 9) or 9)),
            )
        ref_gray = reference.mean(dim=0).clamp(0.0, 1.0)
        ref_blur = int(getattr(args, "shadow_restore_reference_blur", 0) or 0)
        ref_shadow = _blur01(ref_gray, ref_blur) if ref_blur > 0 else ref_gray
        context_blur = int(getattr(args, "shadow_restore_context_blur", 21) or 0)
        ref_context = _blur01(ref_shadow, context_blur).clamp_min(1e-4) if context_blur > 0 else ref_shadow.mean().clamp_min(1e-4)
        attenuation = (ref_shadow / ref_context).clamp(0.0, 1.0)
        threshold = max(float(getattr(args, "shadow_restore_threshold", 0.18) or 0.18), 1e-6)
        dark_by_value = ((threshold - ref_shadow) / threshold).clamp(0.0, 1.0)
        dark_by_ratio = (1.0 - attenuation).clamp(0.0, 1.0)
        ratio_mix = min(max(float(getattr(args, "shadow_restore_ratio_mix", 0.75) or 0.75), 0.0), 1.0)
        ref_evidence = (dark_by_value * (1.0 - ratio_mix) + dark_by_ratio * ratio_mix).clamp(0.0, 1.0)
        ref_connected = _reference_connected_shadow_mask(ref_evidence, hmask, valid, args)
    else:
        ref_evidence = directional

    geometry = str(getattr(args, "shadow_geometry", "reference_connected") or "reference_connected").lower().strip()
    if geometry == "directional":
        evidence_mix = min(max(float(getattr(args, "shadow_directional_reference_mix", 0.65) or 0.65), 0.0), 1.0)
        reference_floor = min(max(float(getattr(args, "shadow_reference_floor", 0.25) or 0.0), 0.0), 1.0)
        ref_gate = (ref_evidence * evidence_mix + max(1.0 - evidence_mix, reference_floor)).clamp(0.0, 1.0)
        shadow = directional * ref_gate if ref_shadow is not None else directional
    elif geometry == "hybrid":
        ref_part = ref_connected if ref_connected is not None else torch.zeros_like(hmask)
        reference_floor = min(max(float(getattr(args, "shadow_reference_floor", 0.25) or 0.0), 0.0), 1.0)
        dir_part = directional * torch.maximum(ref_evidence, torch.full_like(ref_evidence, reference_floor))
        shadow = torch.maximum(ref_part, dir_part).clamp(0.0, 1.0)
    else:
        shadow = ref_connected if ref_connected is not None else directional
    shadow = (shadow * valid).clamp(0.0, 1.0)
    contact_width = int(getattr(args, "shadow_contact_width", 6) or 0)
    contact_strength = min(max(float(getattr(args, "shadow_contact_strength", 0.25) or 0.0), 0.0), 1.0)
    if contact_width > 0 and contact_strength > 0.0:
        protect = int(getattr(args, "shadow_restore_target_protect_dilate", 1) or 0)
        protect_mask = _dilate01_batch(hmask[None], protect)[0] if protect > 0 else hmask
        contact = (_dilate01_batch(hmask[None], contact_width)[0] - protect_mask).clamp(0.0, 1.0) * valid
        direction_gate = torch.maximum(directional_support, directional).clamp(0.0, 1.0)
        if float(direction_gate.max().item()) > 0.0:
            contact = (contact * _blur01(direction_gate, max(1, min(contact_width, 3)))).clamp(0.0, 1.0)
        shadow = torch.maximum(shadow, contact * contact_strength).clamp(0.0, 1.0)
    blur = int(getattr(args, "shadow_restore_blur", 4) or 0)
    if blur > 0:
        shadow = (_blur01(shadow, blur) * valid).clamp(0.0, 1.0)

    amount = (shadow * min(max(strength, 0.0), 1.0)).unsqueeze(0)
    mode = str(getattr(args, "shadow_restore_mode", "darken") or "darken").lower().strip()
    if mode == "blend" and reference is not None:
        restored = image * (1.0 - amount) + reference * amount
    elif mode == "attenuate":
        min_att = min(max(float(getattr(args, "shadow_restore_min_attenuation", 0.18) or 0.18), 0.0), 1.0)
        restored = image * (1.0 - amount) + (image * attenuation.clamp(min_att, 1.0).unsqueeze(0)) * amount
    elif mode == "darken":
        max_darken = min(max(float(getattr(args, "shadow_restore_max_darken", 0.90) or 0.90), 0.0), 1.0)
        floor = min(max(float(getattr(args, "shadow_restore_floor", 0.0) or 0.0), 0.0), 1.0)
        att = (1.0 - amount * max_darken).clamp(0.0, 1.0)
        restored = (image * att + floor * (1.0 - att)).clamp(0.0, 1.0)
    else:
        min_att = min(max(float(getattr(args, "shadow_restore_min_attenuation", 0.04) or 0.04), 0.0), 1.0)
        power = max(float(getattr(args, "shadow_restore_attenuation_power", 1.7) or 1.7), 0.05)
        floor = min(max(float(getattr(args, "shadow_restore_floor", 0.0) or 0.0), 0.0), 1.0)
        att = attenuation.clamp(min_att, 1.0).pow(power)
        if ref_shadow is None:
            att = (1.0 - shadow).clamp(min_att, 1.0).pow(power)
        shadowed = (image * att.unsqueeze(0) + floor * (1.0 - att).unsqueeze(0)).clamp(0.0, 1.0)
        restored = image * (1.0 - amount) + shadowed * amount
    return restored.clamp(0.0, 1.0), shadow.clamp(0.0, 1.0)


def _compose_background_then_target_shadow(
    mod_target: torch.Tensor,
    hard_mask: torch.Tensor,
    style_ref: torch.Tensor | None,
    azimuth_deg: float,
    args,
    compose_alpha: torch.Tensor | None,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    bg = _make_empirical_background(mod_target, hard_mask, style_ref, azimuth_deg, args)
    if bg is None:
        bg = mod_target.clamp(0.0, 1.0)
    strength = min(max(float(getattr(args, "empirical_background_strength", 0.0) or 0.0), 0.0), 1.0)
    base = (mod_target * (1.0 - strength) + bg * strength).clamp(0.0, 1.0)
    alpha = _layer_target_alpha(mod_target, hard_mask, compose_alpha, args)
    out = (base * (1.0 - alpha.unsqueeze(0)) + mod_target * alpha.unsqueeze(0)).clamp(0.0, 1.0)
    out, shadow = _restore_reference_shadow(out, style_ref, hard_mask, azimuth_deg, args)
    maps = {"empirical_background": bg, "layer_target_alpha": alpha[None]}
    if shadow is not None:
        maps["shadow_mask"] = shadow[None]
    return out.clamp(0.0, 1.0), maps


def _compose_diff_stats(pred: torch.Tensor, target_pred: torch.Tensor, mask: torch.Tensor, style_ref: torch.Tensor | None) -> dict:
    diff = (pred.detach().clamp(0.0, 1.0) - target_pred.detach().clamp(0.0, 1.0)).abs()
    mask01 = mask.detach().float().clamp(0.0, 1.0)
    background = (1.0 - mask01).clamp(0.0, 1.0)
    bg_count = float(background.sum().item())
    if bg_count > 0.0:
        bg_diff = (diff.mean(dim=0) * background).sum() / max(bg_count, 1.0)
    else:
        bg_diff = diff.new_tensor(0.0)
    return {
        "mean_abs_diff": float(diff.mean().item()),
        "max_abs_diff": float(diff.max().item()),
        "background_mean_abs_diff": float(bg_diff.item()),
        "target_mask_ratio": float(mask01.mean().item()),
        "style_ref_loaded": style_ref is not None,
    }


def _bright_profile_maps(gt: torch.Tensor, mask: torch.Tensor, args) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    gray = gt.mean(dim=0).clamp(0.0, 1.0)
    m = mask.clamp(0.0, 1.0)
    valid = (m > 0.5) & (gray > 0)
    if int(valid.sum()) >= 8:
        q = min(max(float(getattr(args, "bright_profile_core_quantile", 0.82) or 0.82), 0.0), 1.0)
        thr_q = torch.quantile(gray[valid], q)
    else:
        thr_q = gray.new_tensor(float(getattr(args, "bright_profile_core_threshold", 0.12) or 0.12))
    thr_abs = gray.new_tensor(max(float(getattr(args, "bright_profile_core_threshold", 0.12) or 0.12), 0.0))
    thr = torch.minimum(thr_q, thr_abs) if int(valid.sum()) < 32 else torch.maximum(thr_q, thr_abs)
    core = ((gray >= thr) & (m > 0.5)).float()
    if float(core.sum()) < float(getattr(args, "bright_profile_min_core_pixels", 8.0) or 8.0) and int(valid.sum()) > 0:
        fallback_q = min(max(1.0 - float(getattr(args, "bright_profile_min_core_pixels", 8.0) or 8.0) / max(float(valid.sum()), 1.0), 0.0), 1.0)
        core = ((gray >= torch.quantile(gray[valid], fallback_q)) & (m > 0.5)).float()
    core_dilate = int(getattr(args, "bright_profile_core_dilate", 1) or 0)
    if core_dilate > 0:
        core = _dilate01_batch(core[None], core_dilate)[0] * m

    radius = max(int(getattr(args, "bright_profile_radius", 14) or 14), 1)
    covered = core.clamp(0.0, 1.0)
    dist = torch.ones_like(m)
    dist = torch.where(covered > 0.5, torch.zeros_like(dist), dist)
    for step in range(1, radius + 1):
        grown = _dilate01_batch(covered[None], 1)[0] * m
        new = (grown > 0.5) & (covered <= 0.5)
        dist = torch.where(new, dist.new_tensor(float(step) / float(radius)), dist)
        covered = grown
    dist = dist.clamp(0.0, 1.0) * m

    floor = max(float(getattr(args, "bright_profile_floor_log", 0.025) or 0.025), 0.0)
    near = max(float(getattr(args, "bright_profile_near_log", 0.24) or 0.24), 0.0)
    decay = max(float(getattr(args, "bright_profile_decay", 3.5) or 3.5), 0.0)
    ceiling = (floor + near * torch.exp(-dist * decay)).clamp(0.0, 1.0) * m

    power = max(float(getattr(args, "bright_profile_distance_power", 1.5) or 1.5), 0.05)
    profile_weight = dist.pow(power) * m * (1.0 - core).clamp(0.0, 1.0)
    min_dist = max(float(getattr(args, "bright_profile_min_distance", 0.05) or 0.05), 0.0)
    if min_dist > 0:
        profile_weight = profile_weight * (dist >= min_dist).float()

    ring_width = int(getattr(args, "boundary_ring_width", 2) or 0)
    inner = _erode01_one(m, ring_width)
    ring = (m - inner).clamp(0.0, 1.0)
    far = max(float(getattr(args, "boundary_far_distance", 0.35) or 0.35), 0.0)
    boundary_weight = ring * (dist >= far).float() * dist.pow(power)
    return ceiling, profile_weight.clamp(0.0, 1.0), boundary_weight.clamp(0.0, 1.0)


def _extinction_target(target: torch.Tensor, gt_mix: torch.Tensor, gt_lo: torch.Tensor, gt_hi: torch.Tensor, mask: torch.Tensor, args) -> torch.Tensor:
    scale = float(getattr(args, "log_intensity_scale", 20.0) or 20.0)
    src = _ld(target.mean(dim=0, keepdim=True), scale)[0]
    mix = _ld(gt_mix.mean(dim=0, keepdim=True), scale)[0]
    lo = _ld(gt_lo.mean(dim=0, keepdim=True), scale)[0]
    hi = _ld(gt_hi.mean(dim=0, keepdim=True), scale)[0]
    dark_ref = torch.minimum(lo, hi)
    ref_mode = str(getattr(args, "extinction_target_reference", "min_mix") or "min_mix").lower().strip()
    if ref_mode == "mix":
        ref = mix
    elif ref_mode == "dark":
        ref = dark_ref
    else:
        ref = torch.minimum(mix, dark_ref)
    margin = max(float(getattr(args, "extinction_target_margin", 0.0) or 0.0), 0.0)
    strength = max(float(getattr(args, "extinction_log_strength", 0.55) or 0.55), 1e-6)
    target_ext = ((src - ref - margin).clamp_min(0.0) / strength).clamp(0.0, 1.0) * mask
    gamma = max(float(getattr(args, "extinction_target_gamma", 1.0) or 1.0), 0.05)
    if abs(gamma - 1.0) > 1e-6:
        target_ext = target_ext.pow(gamma)
    blur = int(getattr(args, "extinction_target_blur", 0) or 0)
    if blur > 0:
        target_ext = _blur01(target_ext, blur) * mask
    return target_ext.clamp(0.0, 1.0)


def _compose(raw: torch.Tensor, target: torch.Tensor, mask: torch.Tensor, args) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    scale = float(getattr(args, "log_intensity_scale", 20.0) or 20.0)
    target_gray = target.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    src_ld = _ld(target_gray, scale)
    delta = torch.tanh(raw[:, 0:1]) * float(args.delta_log_scale)
    extinction = torch.sigmoid(raw[:, 1:2])
    gain = torch.tanh(raw[:, 2:3]) * float(args.bright_log_scale)
    m = mask[:, None].clamp(0.0, 1.0)
    pred_ld = src_ld + (delta + gain - extinction * float(args.extinction_log_strength)) * m
    pred = _from_ld(pred_ld, scale).clamp(0.0, 1.0)
    pred = pred.expand(-1, 3, -1, -1).contiguous()
    compose_alpha = _compose_alpha_batch(target, args)[:, None].clamp(0.0, 1.0)
    extinction_alpha_weight = max(float(getattr(args, "extinction_compose_alpha_weight", 0.0) or 0.0), 0.0)
    if extinction_alpha_weight > 0:
        extinction_alpha_gamma = max(float(getattr(args, "extinction_compose_alpha_gamma", 1.0) or 1.0), 0.05)
        extinction_alpha = (extinction.clamp(0.0, 1.0).pow(extinction_alpha_gamma) * m * extinction_alpha_weight).clamp(0.0, 1.0)
        compose_alpha = torch.maximum(compose_alpha, extinction_alpha)
    pred = (pred * compose_alpha + target_gray.expand_as(pred) * (1.0 - compose_alpha)).clamp(0.0, 1.0)
    return pred, {"delta_log": delta, "extinction": extinction, "gain_log": gain, "compose_alpha": compose_alpha}


def _masked_mean(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    if mask.dim() == 3:
        mask = mask[:, None]
    return (x * mask).sum() / (mask.sum().clamp_min(1.0) * x.shape[1])


def _masked_mse_loss(a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    return _masked_mean((a - b).pow(2), mask)


def _masked_sar_ssim_loss(pred_ld: torch.Tensor, gt_ld: torch.Tensor, mask: torch.Tensor, window_size: int = 7) -> torch.Tensor:
    x = pred_ld.mean(dim=1, keepdim=True)
    y = gt_ld.mean(dim=1, keepdim=True)
    if mask.dim() == 3:
        mask = mask[:, None]
    mask = mask.clamp(0.0, 1.0)
    radius = max(1, int(window_size) // 2)
    k = 2 * radius + 1
    weight = torch.ones((1, 1, k, k), dtype=x.dtype, device=x.device) / float(k * k)
    mu_x = F.conv2d(x, weight, padding=radius)
    mu_y = F.conv2d(y, weight, padding=radius)
    mu_x2 = mu_x * mu_x
    mu_y2 = mu_y * mu_y
    mu_xy = mu_x * mu_y
    sig_x2 = F.conv2d(x * x, weight, padding=radius) - mu_x2
    sig_y2 = F.conv2d(y * y, weight, padding=radius) - mu_y2
    sig_xy = F.conv2d(x * y, weight, padding=radius) - mu_xy
    c1 = 0.01 ** 2
    c2 = 0.03 ** 2
    ssim_map = ((2.0 * mu_xy + c1) * (2.0 * sig_xy + c2)) / (
        (mu_x2 + mu_y2 + c1) * (sig_x2 + sig_y2 + c2)
    ).clamp_min(1e-8)
    ssim_val = (ssim_map * mask).sum() / mask.sum().clamp_min(1.0)
    return (1.0 - ssim_val.clamp(-1.0, 1.0)) * 0.5


def _quantile_loss(pred_ld: torch.Tensor, gt_ld: torch.Tensor, mask: torch.Tensor, quantiles: list[float]) -> torch.Tensor:
    losses = []
    if mask.dim() == 3:
        mask = mask[:, None]
    valid = mask > 0.5
    for b in range(pred_ld.shape[0]):
        vals_p = pred_ld[b][valid[b].expand_as(pred_ld[b])]
        vals_g = gt_ld[b][valid[b].expand_as(gt_ld[b])]
        if int(vals_p.numel()) < 8 or int(vals_g.numel()) < 8:
            continue
        q = torch.tensor(quantiles, device=pred_ld.device, dtype=pred_ld.dtype)
        losses.append((torch.quantile(vals_p, q) - torch.quantile(vals_g, q)).abs().mean())
    if not losses:
        return torch.zeros((), device=pred_ld.device, dtype=pred_ld.dtype)
    return torch.stack(losses).mean()


def _train(args, device: torch.device) -> CleanLayoverUNet:
    pairs = _select_pairs(Path(args.train_target_dir), Path(args.train_gt_dir), args)
    dark_pairs = (
        _select_pairs(Path(args.train_target_dir), Path(args.dark_gt_dir), args)
        if getattr(args, "dark_gt_dir", None)
        else pairs
    )
    dark_by_target = {p["target"].name: p for p in dark_pairs}
    Path(args.checkpoint).parent.mkdir(parents=True, exist_ok=True)
    report = Path(args.checkpoint).parent / "train_azimuth_pairs.txt"
    with report.open("w", encoding="utf-8") as f:
        f.write("target\tazimuth\tgt_lo\tlo_az\tlo_w\tgt_hi\thi_az\thi_w\n")
        for p in pairs:
            f.write(
                f"{p['target'].name}\t{p['azimuth']:.3f}\t{p['lo']['path'].name}\t{float(p['lo']['azimuth']):.3f}\t{p['wlo']:.6f}"
                f"\t{p['hi']['path'].name}\t{float(p['hi']['azimuth']):.3f}\t{p['whi']:.6f}\n"
            )
    print(f"[clean layover] train pairs: {len(pairs)}; report: {report}")

    in_ch = _input_channel_count(args)
    model = CleanLayoverUNet(in_ch=in_ch, base=int(args.model_base), padding_mode=str(args.conv_padding_mode)).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
    scaler = torch.amp.GradScaler("cuda", enabled=bool(args.amp) and device.type == "cuda")
    quantiles = _parse_quantiles(str(args.stat_quantiles))
    scale = float(args.log_intensity_scale)

    loaded = []
    for p in pairs:
        dark_p = dark_by_target.get(p["target"].name, p)
        target = _load_image(p["target"], args).to(device)
        gt_lo = _resize_chw(_load_image(p["lo"]["path"], args).to(device), tuple(target.shape[-2:]))
        gt_hi = _resize_chw(_load_image(p["hi"]["path"], args).to(device), tuple(target.shape[-2:]))
        gt_mix = _mix_gt(gt_lo, gt_hi, float(p["wlo"]), float(p["whi"]), scale)
        dark_gt_lo = _resize_chw(_load_image(dark_p["lo"]["path"], args).to(device), tuple(target.shape[-2:]))
        dark_gt_hi = _resize_chw(_load_image(dark_p["hi"]["path"], args).to(device), tuple(target.shape[-2:]))
        dark_gt_mix = _mix_gt(dark_gt_lo, dark_gt_hi, float(dark_p["wlo"]), float(dark_p["whi"]), scale)
        mask = _target_mask(target, args)
        dark = _dark_supervision(target, dark_gt_mix, dark_gt_lo, dark_gt_hi, mask, args)
        ext_target = _extinction_target(target, dark_gt_mix, dark_gt_lo, dark_gt_hi, mask, args)
        content_support = (
            _content_support(dark_gt_mix, mask, args)
            if bool(getattr(args, "content_loss_use_dark_gt_support", False)) and getattr(args, "dark_gt_dir", None)
            else mask
        )
        profile_ceiling, profile_weight, boundary_weight = _bright_profile_maps(dark_gt_mix, mask, args)
        loaded.append(
            (
                target,
                gt_mix,
                dark_gt_mix,
                mask,
                content_support,
                dark,
                ext_target,
                profile_ceiling,
                profile_weight,
                boundary_weight,
                float(p["azimuth"]),
                p["target"].name,
            )
        )

    pbar = tqdm(range(int(args.iterations)), desc="train clean layover", dynamic_ncols=True, mininterval=float(args.progress_refresh_seconds))
    bad_steps = 0
    for it in pbar:
        idx = torch.randint(0, len(loaded), (int(args.batch_size),), device=device)
        targets, gts, dark_gts, masks, content_supports, darks, ext_targets = [], [], [], [], [], [], []
        profile_ceilings, profile_weights, boundary_weights, azs = [], [], [], []
        for i in idx.tolist():
            t, g, dg, m, cs, d, e, pc, pw, bw, az, _name = loaded[i]
            targets.append(t)
            gts.append(g)
            dark_gts.append(dg)
            masks.append(m)
            content_supports.append(cs)
            darks.append(d)
            ext_targets.append(e)
            profile_ceilings.append(pc)
            profile_weights.append(pw)
            boundary_weights.append(bw)
            azs.append(az)
        target_b = torch.stack(targets, dim=0)
        gt_b = torch.stack(gts, dim=0)
        dark_gt_b = torch.stack(dark_gts, dim=0)
        mask_b = torch.stack(masks, dim=0)
        content_support_b = torch.stack(content_supports, dim=0)
        dark_b = torch.stack(darks, dim=0)
        ext_target_b = torch.stack(ext_targets, dim=0)
        profile_ceiling_b = torch.stack(profile_ceilings, dim=0)
        profile_weight_b = torch.stack(profile_weights, dim=0)
        boundary_weight_b = torch.stack(boundary_weights, dim=0)
        x_b = torch.stack([_make_input(targets[i], masks[i], azs[i], scale, args) for i in range(len(targets))], dim=0)

        opt.zero_grad(set_to_none=True)
        with torch.amp.autocast(device_type=device.type, enabled=bool(args.amp) and device.type == "cuda"):
            raw = model(x_b)
            pred, maps = _compose(raw, target_b, mask_b, args)
            pred_ld = _ld(pred, scale)
            gt_ld = _ld(gt_b, scale)
            dark_gt_ld = _ld(dark_gt_b, scale)
            src_ld = _ld(target_b.mean(dim=1, keepdim=True).expand_as(pred), scale)
            content_mask = content_support_b.clamp(0.0, 1.0)
            target_l1 = _masked_mean((pred_ld - gt_ld).abs(), content_mask)
            log_mse = _masked_mse_loss(pred_ld, gt_ld, content_mask)
            sar_ssim_loss = _masked_sar_ssim_loss(
                pred_ld,
                gt_ld,
                content_mask,
                window_size=int(getattr(args, "sar_ssim_loss_window", 7) or 7),
            )
            dark_mask = dark_b[:, None]
            ext_target = ext_target_b[:, None]
            dark_ceiling = _masked_mean((pred_ld - dark_gt_ld.detach()).clamp_min(0.0).pow(2), dark_mask)
            dark_mse = _masked_mse_loss(pred_ld, dark_gt_ld.detach(), dark_mask)
            ext_bce = F.binary_cross_entropy(maps["extinction"].clamp(1e-4, 1.0 - 1e-4), dark_mask.clamp(0.0, 1.0))
            ext_reg = _masked_mean(F.smooth_l1_loss(maps["extinction"], ext_target, reduction="none"), mask_b)
            ext_structure = _masked_mean((_gradient_mag_map(maps["extinction"]) - _gradient_mag_map(ext_target)).abs(), mask_b)
            visible = (content_mask[:, None] * (1.0 - dark_mask)).clamp(0.0, 1.0)
            identity = _masked_mean((pred_ld - src_ld).abs(), visible)
            bright_gray = gt_ld.mean(dim=1, keepdim=True)
            bright_mask = (
                (bright_gray >= float(getattr(args, "bright_scatter_threshold_log", 0.45) or 0.45)).float()
                * content_mask[:, None]
                * (1.0 - dark_mask)
            ).clamp(0.0, 1.0)
            bright_scatter_mse = _masked_mse_loss(pred_ld, gt_ld, bright_mask)
            grad = _masked_mean((_gradient_mag_map(pred_ld) - _gradient_mag_map(gt_ld)).abs(), content_mask)
            pred_std = _local_std_map(pred_ld, int(args.local_texture_radius))
            gt_std = _local_std_map(gt_ld, int(args.local_texture_radius))
            texture = _masked_mean((pred_std - gt_std).abs(), content_mask)
            quant = _quantile_loss(pred_ld, gt_ld, content_mask, quantiles)
            profile_ceiling = profile_ceiling_b[:, None].clamp(0.0, 1.0)
            profile_weight = profile_weight_b[:, None].clamp(0.0, 1.0)
            boundary_weight = boundary_weight_b[:, None].clamp(0.0, 1.0)
            profile = _masked_mean((pred_ld - profile_ceiling).clamp_min(0.0).pow(2), profile_weight)
            boundary_ceiling = float(args.boundary_ceiling_log)
            boundary = _masked_mean((pred_ld - boundary_ceiling).clamp_min(0.0).pow(2), boundary_weight)
            sparsity = _masked_mean(maps["extinction"], mask_b)
            loss = (
                float(args.target_l1_weight) * target_l1
                + float(args.log_mse_weight) * log_mse
                + float(args.sar_ssim_loss_weight) * sar_ssim_loss
                + float(args.dark_ceiling_weight) * dark_ceiling
                + float(args.dark_mse_weight) * dark_mse
                + float(args.extinction_bce_weight) * ext_bce
                + float(args.extinction_regression_weight) * ext_reg
                + float(args.extinction_structure_weight) * ext_structure
                + float(args.bright_scatter_mse_weight) * bright_scatter_mse
                + float(args.bright_profile_loss_weight) * profile
                + float(args.boundary_suppression_weight) * boundary
                + float(args.visible_identity_weight) * identity
                + float(args.gradient_loss_weight) * grad
                + float(args.texture_loss_weight) * texture
                + float(args.quantile_loss_weight) * quant
                + float(args.extinction_sparsity_weight) * sparsity
            )

        if not torch.isfinite(loss):
            bad_steps += 1
            if bad_steps > 20:
                raise RuntimeError("Too many non-finite clean layover losses")
            continue
        scaler.scale(loss).backward()
        if float(args.max_grad_norm) > 0:
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(args.max_grad_norm))
        scaler.step(opt)
        scaler.update()

        if it % max(1, int(args.progress_interval)) == 0:
            pbar.set_postfix(
                l1=f"{float(target_l1.detach()):.4f}",
                mse=f"{float(log_mse.detach()):.4f}",
                ssim=f"{float(sar_ssim_loss.detach()):.4f}",
                dark=f"{float(dark_ceiling.detach()):.4f}",
                dmse=f"{float(dark_mse.detach()):.4f}",
                ext=f"{float(ext_bce.detach()):.4f}",
                ereg=f"{float(ext_reg.detach()):.4f}",
                bmse=f"{float(bright_scatter_mse.detach()):.4f}",
                prof=f"{float(profile.detach()):.4f}",
                tex=f"{float(texture.detach()):.4f}",
            )

    ckpt = {
        "model": model.state_dict(),
        "args": vars(args),
        "refiner_mode": "target_layover_clean",
        "in_ch": in_ch,
        "out_ch": 3,
        "train_pairs": [name for *_rest, name in loaded],
    }
    torch.save(ckpt, args.checkpoint)
    print(f"[clean layover] saved checkpoint: {args.checkpoint}")
    model.eval()
    return model


def _load_model(args, device: torch.device) -> CleanLayoverUNet:
    ckpt = torch.load(args.checkpoint, map_location=device)
    ckpt_args = ckpt.get("args", {})
    base = int(ckpt_args.get("model_base", args.model_base))
    in_ch = int(ckpt.get("in_ch", _input_channel_count(args)))
    if "azimuth_harmonics" in ckpt_args:
        args.azimuth_harmonics = int(ckpt_args.get("azimuth_harmonics") or 1)
    elif in_ch >= 5:
        args.azimuth_harmonics = max(1, int((in_ch - 3) // 2))
    model = CleanLayoverUNet(in_ch=in_ch, base=base, padding_mode=str(getattr(args, "conv_padding_mode", "reflect"))).to(device)
    _load_state_dict_compatible(model, ckpt["model"], "checkpoint")
    model.eval()
    print(f"[clean layover] loaded checkpoint: {args.checkpoint}")
    return model


@torch.no_grad()
def _run_one(model: CleanLayoverUNet, target: torch.Tensor, az: float, args) -> tuple[torch.Tensor, torch.Tensor, dict[str, torch.Tensor]]:
    scale = float(args.log_intensity_scale)
    mask = _target_mask(target, args)
    x = _make_input(target, mask, az, scale, args)[None]
    raw = model(x)
    pred, maps = _compose(raw, target[None], mask[None], args)
    pred = _force_grayscale_batch(pred, args)[0]
    return pred, mask, {k: v[0] for k, v in maps.items()}


def _apply(args, model: CleanLayoverUNet, device: torch.device) -> None:
    target_dir = Path(args.apply_target_dir)
    out_root = Path(args.output_dir)
    render_dir = out_root / "renders"
    target_dir_out = out_root / "target_modulated_renders"
    postprocess_dir = Path(args.postprocess_output_dir) if getattr(args, "postprocess_output_dir", None) else None
    map_dir = out_root / "maps"
    render_dir.mkdir(parents=True, exist_ok=True)
    target_dir_out.mkdir(parents=True, exist_ok=True)
    if postprocess_dir is not None:
        postprocess_dir.mkdir(parents=True, exist_ok=True)
    if bool(args.save_maps):
        map_dir.mkdir(parents=True, exist_ok=True)

    files = _image_files(target_dir)
    if not files:
        raise RuntimeError(f"No apply target renders found: {target_dir}")
    style_refs = _load_style_refs(args, device)
    compose_order = str(getattr(args, "compose_order", "refiner_then_background") or "refiner_then_background").lower().strip()
    compose_stats: list[dict] = []
    strict_compose_check = bool(getattr(args, "fail_on_degenerate_background_compose", True))
    background_strength = min(max(float(getattr(args, "empirical_background_strength", 0.0) or 0.0), 0.0), 1.0)
    if compose_order == "background_then_target_shadow" and background_strength > 0.0 and not style_refs:
        message = (
            "background_then_target_shadow requested with empirical background strength > 0, "
            "but no style references were loaded from --background_reference_dir/--train_gt_dir."
        )
        if strict_compose_check:
            raise RuntimeError(message)
        print(f"[clean layover] warning: {message}")
    for path in tqdm(files, desc="apply clean layover", dynamic_ncols=True):
        target = _load_image(path, args).to(device)
        az = _parse_azimuth(path)
        pred, mask, maps = _run_one(model, target, az, args)
        target_pred = pred
        style_item = None
        style_ref = None
        if compose_order == "background_then_target_shadow":
            style_item = _nearest_style_ref(style_refs, az)
            style_ref = style_item[1] if style_item is not None else None
            pred, layer_maps = _compose_background_then_target_shadow(
                target_pred,
                mask,
                style_ref,
                az,
                args,
                maps.get("compose_alpha"),
            )
            maps.update(layer_maps)
            stats = _compose_diff_stats(pred, target_pred, mask, style_ref)
            stats.update(
                {
                    "file": path.name,
                    "azimuth": float(az),
                    "style_ref": style_item[2] if style_item is not None else None,
                }
            )
            compose_stats.append(stats)
        torchvision.utils.save_image(target_pred.clamp(0.0, 1.0), str(target_dir_out / path.name))
        torchvision.utils.save_image(pred.clamp(0.0, 1.0), str(render_dir / path.name))
        if postprocess_dir is not None:
            torchvision.utils.save_image(pred.clamp(0.0, 1.0), str(postprocess_dir / path.name))
        if bool(args.save_maps):
            stem = path.stem
            torchvision.utils.save_image(mask[None], str(map_dir / f"{stem}_mask.png"))
            shadow_map = maps.get("shadow_mask")
            cls_rgb, bg_mask = _region_classification_rgb(mask, shadow_map)
            torchvision.utils.save_image(cls_rgb, str(map_dir / f"{stem}_region_classification.png"))
            torchvision.utils.save_image(bg_mask, str(map_dir / f"{stem}_background_mask.png"))
            for name, value in maps.items():
                img = value.detach().clamp(-1.0, 1.0)
                if name in {"delta_log", "gain_log"}:
                    img = img * 0.5 + 0.5
                torchvision.utils.save_image(img, str(map_dir / f"{stem}_{name}.png"))
    if compose_stats:
        stats_path = out_root / "compose_diagnostics.jsonl"
        with stats_path.open("w", encoding="utf-8") as f:
            for row in compose_stats:
                f.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        mean_diff = sum(float(x["mean_abs_diff"]) for x in compose_stats) / max(len(compose_stats), 1)
        bg_mean_diff = sum(float(x["background_mean_abs_diff"]) for x in compose_stats) / max(len(compose_stats), 1)
        mask_ratio = sum(float(x["target_mask_ratio"]) for x in compose_stats) / max(len(compose_stats), 1)
        print(
            "[clean layover] compose diagnostics: "
            f"mean_abs_diff={mean_diff:.8f}, background_mean_abs_diff={bg_mean_diff:.8f}, "
            f"target_mask_ratio={mask_ratio:.4f}; wrote {stats_path}"
        )
        min_required = max(float(getattr(args, "background_compose_min_mean_abs_diff", 5e-4) or 0.0), 0.0)
        if (
            compose_order == "background_then_target_shadow"
            and background_strength > 0.0
            and mean_diff <= min_required
            and bg_mean_diff <= min_required
        ):
            message = (
                "background_then_target_shadow produced a degenerate output: renders are effectively identical "
                "to target_modulated_renders. The shadow refiner would not learn GT-like background/shadow context."
            )
            if strict_compose_check:
                raise RuntimeError(message)
            print(f"[clean layover] warning: {message}")
    print(f"[clean layover] wrote: {out_root}")


def main() -> None:
    parser = ArgumentParser(description="Clean target-only SAR layover refiner")
    parser.add_argument("-m", "--model_path", type=str, default=None)
    parser.add_argument("--train_target_dir", type=str, default=None)
    parser.add_argument("--train_gt_dir", type=str, default=None)
    parser.add_argument("--dark_gt_dir", type=str, default=None)
    parser.add_argument("--apply_target_dir", type=str, default=None)
    parser.add_argument("--output_dir", type=str, default=None)
    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--postprocess_output_dir", type=str, default=None)
    parser.add_argument("--background_reference_dir", type=str, default=None)
    parser.add_argument("--refiner_mode", type=str, default="target_layover_clean")
    parser.add_argument("--compose_order", choices=["refiner_then_background", "background_then_target_shadow"], default="refiner_then_background")
    parser.add_argument("--train_only", action="store_true", default=False)
    parser.add_argument("--apply_only", action="store_true", default=False)
    parser.add_argument("--target_only_refiner", action=BooleanOptionalAction, default=True)
    parser.add_argument("--train_use_all_targets", action=BooleanOptionalAction, default=False)
    parser.add_argument("--train_azimuth_step", type=float, default=10.0)
    parser.add_argument("--azimuth_harmonics", type=int, default=5)
    parser.add_argument("--iterations", type=int, default=5000)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--model_base", type=int, default=32)
    parser.add_argument("--conv_padding_mode", choices=["zeros", "reflect", "replicate", "circular"], default="reflect")
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--amp", action="store_true", default=False)
    parser.add_argument("--allow_tf32", action=BooleanOptionalAction, default=True)
    parser.add_argument("--cudnn_benchmark", action=BooleanOptionalAction, default=True)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--progress_metrics", choices=["compact", "full", "none"], default="compact")
    parser.add_argument("--progress_interval", type=int, default=20)
    parser.add_argument("--progress_refresh_seconds", type=float, default=0.5)
    parser.add_argument("--grayscale_sar", action=BooleanOptionalAction, default=True)
    parser.add_argument("--force_grayscale_output", action=BooleanOptionalAction, default=True)
    parser.add_argument("--log_intensity_scale", type=float, default=20.0)
    parser.add_argument("--target_loss_mask_threshold", type=float, default=0.08)
    parser.add_argument("--target_loss_mask_dilate", type=int, default=2)
    parser.add_argument("--target_loss_mask_min_pixels", type=float, default=16.0)
    parser.add_argument("--compose_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--compose_alpha_high", type=float, default=0.08)
    parser.add_argument("--compose_alpha_gamma", type=float, default=0.8)
    parser.add_argument("--compose_alpha_dilate", type=int, default=0)
    parser.add_argument("--compose_alpha_blur", type=int, default=0)
    parser.add_argument("--extinction_compose_alpha_weight", type=float, default=0.0)
    parser.add_argument("--extinction_compose_alpha_gamma", type=float, default=1.0)
    parser.add_argument("--empirical_background_strength", type=float, default=0.0)
    parser.add_argument("--empirical_background_mode", choices=["patch", "reference", "pixel"], default="patch")
    parser.add_argument("--empirical_background_patch_size", type=int, default=24)
    parser.add_argument("--empirical_background_patch_overlap", type=int, default=6)
    parser.add_argument("--empirical_background_patch_smooth", type=int, default=1)
    parser.add_argument("--empirical_background_patch_smooth_mix", type=float, default=0.35)
    parser.add_argument("--empirical_background_patch_fallback_weight", type=float, default=1.0)
    parser.add_argument("--empirical_background_patch_min_valid", type=float, default=0.70)
    parser.add_argument("--empirical_background_clean_reference", action=BooleanOptionalAction, default=True)
    parser.add_argument("--empirical_background_fallback_blur", type=int, default=9)
    parser.add_argument("--empirical_background_reference_exclude_dilate", type=int, default=24)
    parser.add_argument("--empirical_background_scale", type=float, default=1.0)
    parser.add_argument("--empirical_background_bias", type=float, default=0.0)
    parser.add_argument("--empirical_background_match_target_peak", action=BooleanOptionalAction, default=False)
    parser.add_argument("--empirical_background_target_peak_quantile", type=float, default=0.95)
    parser.add_argument("--empirical_background_peak_quantile", type=float, default=0.995)
    parser.add_argument("--empirical_background_peak_mix", type=float, default=1.0)
    parser.add_argument("--empirical_background_peak_max_scale", type=float, default=2.5)
    parser.add_argument("--noise_seed", type=int, default=1234)
    parser.add_argument("--layer_target_alpha_threshold", type=float, default=0.035)
    parser.add_argument("--layer_target_alpha_high", type=float, default=0.12)
    parser.add_argument("--layer_target_alpha_gamma", type=float, default=0.75)
    parser.add_argument("--layer_target_use_compose_alpha", action=BooleanOptionalAction, default=False)
    parser.add_argument("--layer_target_compose_alpha_mix", type=float, default=0.35)
    parser.add_argument("--layer_target_dilate", type=int, default=0)
    parser.add_argument("--layer_target_blur", type=int, default=1)
    parser.add_argument("--layer_target_strength", type=float, default=1.0)
    parser.add_argument("--layer_target_mask_floor", type=float, default=0.35)
    parser.add_argument("--layer_target_contact_width", type=int, default=2)
    parser.add_argument("--layer_target_contact_strength", type=float, default=0.45)
    parser.add_argument("--layer_target_contact_blur", type=int, default=1)
    parser.add_argument("--shadow_restore_strength", type=float, default=0.0)
    parser.add_argument("--shadow_restore_mode", choices=["extinguish", "attenuate", "blend", "darken"], default="darken")
    parser.add_argument("--shadow_restore_threshold", type=float, default=0.18)
    parser.add_argument("--shadow_restore_target_dilate", type=int, default=40)
    parser.add_argument("--shadow_restore_target_protect_dilate", type=int, default=1)
    parser.add_argument("--shadow_restore_clean_reference", action=BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_restore_reference_blur", type=int, default=4)
    parser.add_argument("--shadow_restore_blur", type=int, default=4)
    parser.add_argument("--shadow_restore_context_blur", type=int, default=21)
    parser.add_argument("--shadow_restore_ratio_mix", type=float, default=0.75)
    parser.add_argument("--shadow_restore_min_attenuation", type=float, default=0.04)
    parser.add_argument("--shadow_restore_attenuation_power", type=float, default=1.7)
    parser.add_argument("--shadow_restore_floor", type=float, default=0.0)
    parser.add_argument("--shadow_restore_max_darken", type=float, default=0.90)
    parser.add_argument("--shadow_geometry", choices=["reference_connected", "directional", "hybrid"], default="reference_connected")
    parser.add_argument("--shadow_reference_min_evidence", type=float, default=0.05)
    parser.add_argument("--shadow_reference_floor", type=float, default=0.25)
    parser.add_argument("--shadow_contact_width", type=int, default=6)
    parser.add_argument("--shadow_contact_strength", type=float, default=0.25)
    parser.add_argument("--shadow_connected_decay", type=float, default=24.0)
    parser.add_argument("--shadow_connected_blur", type=int, default=2)
    parser.add_argument("--shadow_directional_strength", type=float, default=1.0)
    parser.add_argument("--shadow_directional_length", type=int, default=42)
    parser.add_argument("--shadow_directional_decay", type=float, default=18.0)
    parser.add_argument("--shadow_directional_lateral_blur", type=int, default=5)
    parser.add_argument("--shadow_directional_reference_mix", type=float, default=0.65)
    parser.add_argument("--shadow_direction_offset_deg", type=float, default=180.0)
    parser.add_argument("--shadow_direction_sign", type=float, default=1.0)
    parser.add_argument("--fail_on_degenerate_background_compose", action=BooleanOptionalAction, default=True)
    parser.add_argument("--background_compose_min_mean_abs_diff", type=float, default=5e-4)
    parser.add_argument("--delta_log_scale", type=float, default=0.35)
    parser.add_argument("--bright_log_scale", type=float, default=0.18)
    parser.add_argument("--extinction_log_strength", type=float, default=0.55)
    parser.add_argument("--dark_src_threshold", type=float, default=0.16)
    parser.add_argument("--dark_gap_threshold", type=float, default=0.12)
    parser.add_argument("--dark_gap_softness", type=float, default=0.18)
    parser.add_argument("--dark_supervision_blur", type=int, default=1)
    parser.add_argument("--content_loss_use_dark_gt_support", action=BooleanOptionalAction, default=False)
    parser.add_argument("--content_gt_support_threshold", type=float, default=0.015)
    parser.add_argument("--content_gt_support_dilate", type=int, default=1)
    parser.add_argument("--content_gt_support_blur", type=int, default=0)
    parser.add_argument("--extinction_target_reference", choices=["min_mix", "mix", "dark"], default="min_mix")
    parser.add_argument("--extinction_target_gamma", type=float, default=1.0)
    parser.add_argument("--extinction_target_margin", type=float, default=0.0)
    parser.add_argument("--extinction_target_blur", type=int, default=0)
    parser.add_argument("--target_l1_weight", type=float, default=0.55)
    parser.add_argument("--log_mse_weight", type=float, default=0.3)
    parser.add_argument("--sar_ssim_loss_weight", type=float, default=0.12)
    parser.add_argument("--sar_ssim_loss_window", type=int, default=7)
    parser.add_argument("--dark_ceiling_weight", type=float, default=1.6)
    parser.add_argument("--dark_mse_weight", type=float, default=0.25)
    parser.add_argument("--extinction_bce_weight", type=float, default=0.9)
    parser.add_argument("--extinction_regression_weight", type=float, default=0.0)
    parser.add_argument("--extinction_structure_weight", type=float, default=0.0)
    parser.add_argument("--bright_profile_loss_weight", type=float, default=0.0)
    parser.add_argument("--bright_profile_core_quantile", type=float, default=0.82)
    parser.add_argument("--bright_profile_core_threshold", type=float, default=0.12)
    parser.add_argument("--bright_profile_min_core_pixels", type=float, default=8.0)
    parser.add_argument("--bright_profile_core_dilate", type=int, default=1)
    parser.add_argument("--bright_profile_radius", type=int, default=14)
    parser.add_argument("--bright_profile_decay", type=float, default=3.5)
    parser.add_argument("--bright_profile_floor_log", type=float, default=0.025)
    parser.add_argument("--bright_profile_near_log", type=float, default=0.24)
    parser.add_argument("--bright_profile_distance_power", type=float, default=1.5)
    parser.add_argument("--bright_profile_min_distance", type=float, default=0.05)
    parser.add_argument("--boundary_suppression_weight", type=float, default=0.0)
    parser.add_argument("--boundary_ring_width", type=int, default=2)
    parser.add_argument("--boundary_far_distance", type=float, default=0.35)
    parser.add_argument("--boundary_ceiling_log", type=float, default=0.04)
    parser.add_argument("--visible_identity_weight", type=float, default=0.06)
    parser.add_argument("--gradient_loss_weight", type=float, default=0.30)
    parser.add_argument("--texture_loss_weight", type=float, default=0.45)
    parser.add_argument("--quantile_loss_weight", type=float, default=0.20)
    parser.add_argument("--bright_scatter_mse_weight", type=float, default=0.15)
    parser.add_argument("--bright_scatter_threshold_log", type=float, default=0.45)
    parser.add_argument("--extinction_sparsity_weight", type=float, default=0.004)
    parser.add_argument("--local_texture_radius", type=int, default=2)
    parser.add_argument("--stat_quantiles", type=str, default="0.05,0.10,0.25,0.50,0.75,0.90,0.97")
    parser.add_argument("--save_maps", action=BooleanOptionalAction, default=True)
    args, unknown = parser.parse_known_args()
    if unknown:
        unknown_opts = [x for x in unknown if str(x).startswith("-")]
        shown = ", ".join(unknown_opts[:16])
        suffix = "" if len(unknown_opts) <= 16 else f", ... (+{len(unknown_opts) - 16})"
        print(f"[clean layover] warning: ignoring unsupported CLI options: {shown}{suffix}", file=sys.stderr)
    _derive_paths(args)
    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    _configure_torch(args, device)
    if args.apply_only:
        model = _load_model(args, device)
    else:
        if not args.train_target_dir or not args.train_gt_dir:
            raise RuntimeError("Training requires --train_target_dir and --train_gt_dir")
        model = _train(args, device)
    if not args.train_only:
        if not args.apply_target_dir:
            raise RuntimeError("Apply requires --apply_target_dir")
        _apply(args, model, device)


if __name__ == "__main__":
    main()
