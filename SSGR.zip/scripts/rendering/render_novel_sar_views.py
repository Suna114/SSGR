"""
SAR 新视角批量渲染：按俯视角 × 方位角网格生成图像（无 GT）。

默认：俯视角 15°, 17°, 25°, 45°；方位角 0°–359°（步长 1°，--azimuth_end 360 表示 range 上界不含，即整周）。
若只需半周（与常见 0°–180° 训练一致），可指定：--azimuth_end 181。

重要：新视角相机必须与训练时使用同一套 SAR 几何（尤其是 camera_distribution_mode）。
训练默认多为 **ring**（水平圆环）。旧版脚本曾把多俯角强行改成 **sphere**，与训练不一致，
会导致渲染呈杂乱光点；现已默认 **继承参考相机 sar_params**（与训练一致）。

用法示例：
    python render_novel_sar_views.py -m ./output/125 --iteration 45000 \\
        --output_dir ./output/125/novel_views_grid

    # 自定义俯角；方位角默认已 0°–359°，仅半周时例如：
    python render_novel_sar_views.py -m ./output/125 --iteration 45000 \\
        --depression_angles "15 17 25 45" --azimuth_start 0 --azimuth_end 181 --azimuth_step 1

    # 不加载优化后的 checkpoint，仅用「数据集 COLMAP fused 点云」做与训练开始前相同的 Gaussian 初始化，
    # 在指定方位渲染（典型：检视目标几何初摆放是否与 0° 约定朝向一致）。仅渲染 0° 示例：
    python render_novel_sar_views.py -m ./output/125 --from_dataset_geometry \\
        --same_depression_only --azimuth_start 0 --azimuth_end 1 --azimuth_step 1 \\
        --output_dir ./output/125/novel_views_init_geom

说明：
    - 需训练时启用了 SAR 模式（cfg_args 中 sar_mode），否则会提示并退出。
    - 输出：output_dir/novel_views/depression_<dep>/renders/azimuth_XXX.png（默认）
    - 或 --output_filename_style mstar：目标名-俯视角-方位角.jpg（与 MSTAR 训练图命名一致）
    - --same_depression_only：为 True 时只渲染「训练俯角」、只扫方位角（用于快速验证）。
    - --force_sphere_distribution：强制使用 sphere（一般与 ring 训练不一致，仅作对比实验）。
    - SFM 尺度：默认读取数据目录下 sar_scale_params.json（scaled_camera_height、radius_scale 等），
      并与 COLMAP 参考相机做一次距离自校准，使新视角与训练点云同一尺度。
    - **默认** --novel_pose_mode colmap_track：在相邻训练帧间插值/最近邻外参（与训练 COLMAP 轨迹一致，利于内推方位）。
      方位键默认 filename（与 azimuth_XXX / MSTAR 文件名一致）。
    - **可选** --novel_pose_mode colmap_ring：用 median(r_xz)+median(Y) 理想水平环（与真实轨迹有偏差时不如 track）。
    - 尺度：默认读取 data 目录下 **sar_scale_params.json** 并入 sar_params（与 SfM+COLMAP 训练时一致）。
    - **mstar_nosfm / 无 SfM 训练**：若 `cfg_args` 中 `mstar_nosfm=True`，脚本将**自动不合并** `sar_scale_params.json`，
      保持训练相机上 `sar_params` 的 `camera_height` 等，避免与 SfM 场景尺度混用。也可手动加 `--no_sfm_scale_file`。
    - **mstar_nosfm 与 novel_pose_mode**：无 SfM 时训练外参本身为 `compute_sar_camera_pose`，默认的 **colmap_track 插值**
      会与 SAR 投影/GS 光栅化假设不一致，易出现整图错误。若未在命令行指定 `--novel_pose_mode`，
      将在检测到 `mstar_nosfm=True` 时**自动改为** `sar`（逐格重算 `compute_sar_camera_pose`）。需要沿离散训练帧
      插值时再显式写 `--novel_pose_mode colmap_track`。
    - **投影**：若训练时 scene 为 use_sar_geometry=False，训练相机使用透视 FoV；脚本会自动对齐，
      不再强行启用 SAR 投影矩阵（否则会出现「乱点」）。
    - **--from_dataset_geometry**：仅用数据集 fused 点云初始化高斯（不读 point_cloud 检查点）；与「训练完的 ply」画质无关，
      只用于比对几何初值在某个方位 SAR 视图下的俯视/朝向关系。
      使用该开关时默认写出 **尺度诊断 JSON**（见 `--no_init_geom_diag`）；用于判断 fused 几何相对训练环相机是否过小/过大。
"""


from __future__ import annotations

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path

for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

import json
import os
import re
import sys
from argparse import ArgumentParser, Namespace
from pathlib import Path

import numpy as np
import torch
import torchvision
from PIL import Image
from tqdm import tqdm

from scene import Scene, GaussianModel
from scene.cameras import Camera
from gaussian_renderer import render
from utils.general_utils import safe_state
from arguments import ModelParams, PipelineParams, get_combined_args
from utils.graphics_utils import focal2fov
from utils.system_utils import searchForMaxIteration

try:
    from diff_gaussian_rasterization import SparseGaussianAdam
    SPARSE_ADAM_AVAILABLE = True
except Exception:
    SPARSE_ADAM_AVAILABLE = False

try:
    from sar_geometry import (
        compute_sar_camera_pose,
        DEFAULT_SAR_PARAMS,
        pradar_to_world_to_camera_rt,
    )
    SAR_GEOMETRY_AVAILABLE = True
except ImportError:
    SAR_GEOMETRY_AVAILABLE = False
    pradar_to_world_to_camera_rt = None

try:
    from sar_utils import parse_mstar_filename, parse_mstar_filename_quiet
except ImportError:
    parse_mstar_filename = None
    parse_mstar_filename_quiet = None

_DEP_AZI_MAPPING_LOGGED = False


def _parse_filename_dep_azi(image_name: str) -> tuple[float, float] | None:
    """从 MSTAR 式文件名解析俯仰/方位（度），不打印日志。"""
    if parse_mstar_filename_quiet is not None:
        _tgt, dep, azi = parse_mstar_filename_quiet(image_name)
        if _tgt is None:
            return None
        return float(dep), float(azi)
    if parse_mstar_filename is None:
        return None
    dep, azi = parse_mstar_filename(image_name)
    return float(dep), float(azi)


def _list_point_cloud_iterations(model_path: str) -> list[int]:
    """列出 model_path/point_cloud 下已保存的迭代编号。"""
    root = os.path.join(model_path, "point_cloud")
    if not os.path.isdir(root):
        return []
    out: list[int] = []
    for name in os.listdir(root):
        if not name.startswith("iteration_"):
            continue
        sub = os.path.join(root, name)
        if not os.path.isdir(sub):
            continue
        try:
            out.append(int(name.split("_")[-1]))
        except ValueError:
            continue
    return sorted(out)


def _resolve_checkpoint_ply(model_path: str, iteration: int) -> tuple[int, str]:
    """
    得到将加载的迭代号与 point_cloud.ply 路径。
    iteration < 0 时与 Scene 一致：取 point_cloud 下最大迭代。
    """
    pc_root = os.path.join(model_path, "point_cloud")
    if not os.path.isdir(pc_root):
        raise FileNotFoundError(pc_root)
    if iteration < 0:
        it = searchForMaxIteration(pc_root)
    else:
        it = int(iteration)
    ply = os.path.join(pc_root, f"iteration_{it}", "point_cloud.ply")
    return it, ply


def _extract_target_name_from_train_cameras(train_cameras: list) -> str:
    """从训练图像名解析 MSTAR 风格「目标-俯角-方位」，返回目标名；失败返回 novel。"""
    for cam in train_cameras or []:
        name = getattr(cam, "image_name", None)
        if not name:
            continue
        stem = Path(str(name)).stem
        m = re.match(r"^([A-Za-z0-9]+)-(\d+)-(\d+)$", stem)
        if m:
            return m.group(1)
    return "novel"


def _novel_output_basename(
    style: str,
    target_name: str,
    dep: float,
    azi: float,
    ext: str | None = None,
) -> str:
    """legacy: azimuth_XXX.png；mstar: 目标-俯角-方位(三位).<ext>"""
    if style == "mstar":
        d = int(round(float(dep)))
        a = int(round(float(azi)))
        suffix = (ext or "jpg").lstrip(".").lower()
        return f"{target_name}-{d}-{a:03d}.{suffix}"
    return f"azimuth_{int(azi):03d}.png"


def _get_sar_params_from_camera(cam):
    params = getattr(cam, "sar_params", None)
    if params is not None and isinstance(params, dict):
        return params.copy()
    # 无 sar_params 时回退；训练默认多为 ring，与 DEFAULT_SAR_PARAMS 的 sphere 不同
    p = DEFAULT_SAR_PARAMS.copy()
    p["Na"] = getattr(cam, "image_width", 128)
    p["Nr"] = getattr(cam, "image_height", 128)
    p["camera_distribution_mode"] = "ring"
    return p


def _novel_radar_and_use_sar_projection_like_ref(
    ref_camera,
    R_world_to_radar_computed: np.ndarray,
) -> tuple[np.ndarray | None, bool]:
    """
    scene/__init__.py 在 use_sar_geometry=False 时，训练相机为 COLMAP 位姿 + 透视投影（非 SAR 投影矩阵）。
    若新视角仍设 use_sar_rendering=True 并填 R_world_to_radar，scene/cameras.py 会走 getSARProjectionMatrix，
    与训练时 full_proj_transform 不一致，渲染呈杂乱碎点。

    因此：仅当 ref_camera（训练相机）本身 use_sar_rendering=True 时，才传入计算得到的 R_world_to_radar。
    """
    if not bool(getattr(ref_camera, "use_sar_rendering", False)):
        return None, False
    R = np.asarray(R_world_to_radar_computed, dtype=np.float32).reshape(3, 3)
    return R, True


def merge_sfm_scale_params(
    sar_params: dict,
    source_path: str | None = None,
    scale_json_path: str | None = None,
    mstar_nosfm: bool = False,
) -> dict:
    """
    从 SFM 输出的 sar_scale_params.json 合并尺度（与 scene/__init__.py 加载 COLMAP+SfM 数据时一致）。
    解决：训练用 COLMAP 位姿时，sar_params 可能为空，解析几何若仍用物理 camera_height
    会导致相机过远/过近（例如整图一个亮点）。

    若 **mstar_nosfm** 训练（无 SfM、无 scaled_camera_height 场景单位），**禁止**用该文件里的
    scaled_camera_height 覆盖，否则会与 `compute_sar_camera_pose` 训练用的物理高度（如 12000）不一致，
    SAR 投影矩阵与插值外参失配，渲染呈错位/全亮点。
    """
    if mstar_nosfm:
        print(
            "   ℹ️  训练为 mstar_nosfm（无 SfM）：跳过 sar_scale_params.json 合并，"
            "使用训练相机/ cfg 中 sar_params 的 camera_height 与 radius_scale，避免与 SfM 尺度混用"
        )
        return sar_params.copy()
    out = sar_params.copy()
    path = scale_json_path
    if path is None and source_path:
        path = os.path.join(source_path, "sar_scale_params.json")
    if not path or not os.path.isfile(path):
        print(
            "   ⚠️ 未找到 sar_scale_params.json（请在数据目录 source_path 放置，或传 --sar_scale_json）"
        )
        print("      将仅用相机上的 sar_params / 默认值，距离可能与 SFM 尺度不一致。")
        return out
    try:
        with open(path, "r", encoding="utf-8") as f:
            sp = json.load(f)
    except Exception as e:
        print(f"   ⚠️ 读取尺度文件失败 {path}: {e}")
        return out

    # 与 scene/__init__.py 一致：优先 unified，否则 estimated
    if "unified_radius_scale" in sp:
        rs = float(sp["unified_radius_scale"])
        tag = "unified_radius_scale"
    elif "estimated_radius_scale" in sp:
        rs = float(sp["estimated_radius_scale"])
        tag = "estimated_radius_scale"
    else:
        rs = None
        tag = None
    if rs is not None:
        out["radius_scale"] = rs
        out["default_radius_scale"] = rs
        print(f"   ✅ SFM 尺度 [{path}]：{tag} = {rs:.6g}")

    if "scene_scale" in sp:
        out["scene_scale"] = float(sp["scene_scale"])
        print(f"   ✅ 已合并 scene_scale = {out['scene_scale']:.6g}")

    # 与 COLMAP/SFM 同一世界单位时使用 scaled 高度（典型 ~几十，而非 12000）
    if "scaled_camera_height" in sp:
        out["camera_height"] = float(sp["scaled_camera_height"])
        print(
            f"   ✅ 已使用 scaled_camera_height = {out['camera_height']:.4g}（与 SFM 点云/相机单位一致）"
        )
    elif "camera_height" in sp and "scaled_camera_height" not in sp:
        # 仅物理高度时保留原逻辑，不覆盖（避免误把 6100m 当世界单位）
        print(
            "   ℹ️  尺度文件中仅有 camera_height，未写 scaled_camera_height；未自动覆盖 camera_height"
        )

    for k in ("unified_focal_azimuth", "unified_focal_range", "unified_cx", "unified_cy"):
        if k in sp:
            out[k] = sp[k]
    if "camera_distribution_mode" in sp:
        mode = str(sp["camera_distribution_mode"]).strip().lower()
        if mode in ("ring", "sphere"):
            out["camera_distribution_mode"] = mode
            print(f"   ✅ 已合并 camera_distribution_mode = {mode}")
    return out


def apply_radar_world_distance_scale(R_world_to_radar, t, scale: float):
    """
    在保持朝向不变的情况下，将雷达世界坐标系下的位置按 scale 缩放。
    由 t = -R_w2r @ P 与 P' = scale * P 得 t' = -R_w2r @ P'。
    """
    if abs(scale - 1.0) < 1e-8:
        return R_world_to_radar, t
    R = np.asarray(R_world_to_radar, dtype=np.float64)
    tv = np.asarray(t, dtype=np.float64).reshape(3, 1)
    P = -R.T @ tv
    P *= float(scale)
    t_new = (-R @ P).reshape(-1)
    return R_world_to_radar, t_new.astype(np.float32)


def _dep_azi_for_view_name(image_name: str, source_path: str | None) -> tuple[float, float] | None:
    """俯角优先用 depression_angle_mapping.json（与 SfM 一致），否则用文件名解析。"""
    global _DEP_AZI_MAPPING_LOGGED
    if not image_name:
        return None
    stem = os.path.splitext(os.path.basename(image_name))[0]
    if source_path:
        map_path = os.path.join(source_path, "depression_angle_mapping.json")
        if os.path.isfile(map_path):
            try:
                with open(map_path, "r", encoding="utf-8") as f:
                    mp = json.load(f)
                dep = None
                if image_name in mp:
                    dep = float(mp[image_name])
                elif stem in mp:
                    dep = float(mp[stem])
                if dep is not None:
                    parsed = _parse_filename_dep_azi(image_name)
                    if parsed is None:
                        return None
                    _d0, azi = parsed
                    if not _DEP_AZI_MAPPING_LOGGED:
                        _DEP_AZI_MAPPING_LOGGED = True
                        print(
                            f"   ℹ️  使用俯视角映射（示例 {stem} → {dep}°；方位角仍来自文件名）"
                        )
                    return float(dep), float(azi)
            except Exception as e:
                print(f"   ⚠️ 读取 depression_angle_mapping.json 失败: {e}")
    parsed = _parse_filename_dep_azi(image_name)
    if parsed is None:
        return None
    return parsed


def _effective_depression_angles_after_load(
    dep_list_cli: list[float],
    same_depression_only: bool,
    ref_camera,
    source_path: str,
) -> list[float]:
    """
    与 render_novel_views 内 same_depression_only 逻辑一致，用于在 Scene 建好、有 ref_camera 之后
    向用户更正「CLI 给定多俯角但实际只会渲一个俯角」时的张数。
    """
    if not same_depression_only:
        return list(dep_list_cli)
    nm = getattr(ref_camera, "image_name", "") or ""
    da = _dep_azi_for_view_name(nm, source_path if source_path else None)
    if da is not None:
        return [float(da[0])]
    ref_dep = getattr(ref_camera, "depression_angle", None)
    if ref_dep is None and getattr(ref_camera, "sar_params", None):
        ref_dep = ref_camera.sar_params.get("depression_angle")
    if ref_dep is not None:
        return [float(ref_dep)]
    return list(dep_list_cli)


def calibrate_distance_scale_to_colmap(
    ref_camera,
    sar_params: dict,
    source_path: str | None = None,
) -> float:
    """
    用参考训练相机（COLMAP 位姿）与解析公式在同一 (俯角, 方位角) 下的距离比，校正全局尺度。
    """
    name = getattr(ref_camera, "image_name", "") or ""
    da = _dep_azi_for_view_name(name, source_path)
    if da is None:
        print(f"   ⚠️ 无法得到俯/方位角: {name}，跳过距离自校准")
        return 1.0
    dep, azi = da
    try:
        center_colmap = ref_camera.camera_center.detach().cpu().numpy().reshape(3)
        sp = sar_params.copy()
        R_w2r, t, _ = compute_sar_camera_pose(dep, azi, sp)
        P = (-np.asarray(R_w2r).T @ np.asarray(t).reshape(3, 1)).reshape(3)
        d_c = float(np.linalg.norm(center_colmap))
        d_s = float(np.linalg.norm(P))
        if d_s < 1e-12:
            print("   ⚠️ 解析相机距离过小，跳过距离自校准")
            return 1.0
        scale = d_c / d_s
        if not np.isfinite(scale) or scale < 1e-6 or scale > 1e6:
            print(f"   ⚠️ 自校准比例异常 scale={scale}，忽略")
            return 1.0
        print(
            f"   ✅ 距离自校准: ||C_colmap||={d_c:.4f}, ||P_sar||={d_s:.4f} → scale={scale:.6g}"
        )
        return float(scale)
    except Exception as e:
        print(f"   ⚠️ 距离自校准失败: {e}")
        return 1.0


def _cam_rt_numpy(cam):
    """Camera.R 为 cam→world，T 为 world→cam（COLMAP 约定）。"""
    R = cam.R
    if torch.is_tensor(R):
        R = R.detach().cpu().numpy()
    T = cam.T
    if torch.is_tensor(T):
        T = T.detach().cpu().numpy()
    R = np.asarray(R, dtype=np.float64).reshape(3, 3)
    T = np.asarray(T, dtype=np.float64).reshape(3)
    return R, T


def _cam_R_world_to_radar_numpy(cam):
    Rr = getattr(cam, "R_world_to_radar", None)
    if Rr is None:
        return np.eye(3, dtype=np.float64)
    if torch.is_tensor(Rr):
        Rr = Rr.detach().cpu().numpy()
    return np.asarray(Rr, dtype=np.float64).reshape(3, 3)


def _camera_center_numpy(cam):
    c = cam.camera_center
    if torch.is_tensor(c):
        c = c.detach().cpu().numpy()
    return np.asarray(c, dtype=np.float64).reshape(3)


def geom_azimuth_deg_from_center(cam) -> float:
    """水平面几何方位角（度）[0,360)，与文件名方位无关。"""
    C = _camera_center_numpy(cam)
    return float((np.degrees(np.arctan2(C[2], C[0])) + 360.0) % 360.0)


def _rotmat_to_quat_xyzw(R: np.ndarray) -> np.ndarray:
    """旋转矩阵 → 单位四元数 (x,y,z,w)，与 scipy.spatial.transform 约定一致。"""
    R = np.asarray(R, dtype=np.float64).reshape(3, 3)
    trace = np.trace(R)
    if trace > 0:
        s = 0.5 / np.sqrt(trace + 1.0)
        w = 0.25 / s
        x = (R[2, 1] - R[1, 2]) * s
        y = (R[0, 2] - R[2, 0]) * s
        z = (R[1, 0] - R[0, 1]) * s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = 2.0 * np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s
    q = np.array([x, y, z, w], dtype=np.float64)
    n = np.linalg.norm(q)
    if n < 1e-12:
        return np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float64)
    return q / n


def _quat_xyzw_to_rotmat(q: np.ndarray) -> np.ndarray:
    x, y, z, w = np.asarray(q, dtype=np.float64).reshape(4)
    n = np.linalg.norm(np.array([x, y, z, w]))
    if n < 1e-12:
        return np.eye(3, dtype=np.float64)
    x, y, z, w = x / n, y / n, z / n, w / n
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z
    return np.array(
        [
            [1 - 2 * (yy + zz), 2 * (xy - wz), 2 * (xz + wy)],
            [2 * (xy + wz), 1 - 2 * (xx + zz), 2 * (yz - wx)],
            [2 * (xz - wy), 2 * (yz + wx), 1 - 2 * (xx + yy)],
        ],
        dtype=np.float64,
    )


def _quat_xyzw_slerp(q0: np.ndarray, q1: np.ndarray, t: float) -> np.ndarray:
    q0 = np.asarray(q0, dtype=np.float64).reshape(4)
    q1 = np.asarray(q1, dtype=np.float64).reshape(4)
    q0 = q0 / (np.linalg.norm(q0) + 1e-15)
    q1 = q1 / (np.linalg.norm(q1) + 1e-15)
    dot = float(np.dot(q0, q1))
    if dot < 0.0:
        q1 = -q1
        dot = -dot
    if dot > 0.9995:
        q = q0 + t * (q1 - q0)
        return q / (np.linalg.norm(q) + 1e-15)
    theta_0 = np.arccos(np.clip(dot, -1.0, 1.0))
    sin_theta_0 = np.sin(theta_0)
    s0 = np.sin((1.0 - t) * theta_0) / sin_theta_0
    s1 = np.sin(t * theta_0) / sin_theta_0
    q = s0 * q0 + s1 * q1
    return q / (np.linalg.norm(q) + 1e-15)


def _slerp_rotmat(R0: np.ndarray, R1: np.ndarray, t: float) -> np.ndarray:
    q0 = _rotmat_to_quat_xyzw(R0)
    q1 = _rotmat_to_quat_xyzw(R1)
    return _quat_xyzw_to_rotmat(_quat_xyzw_slerp(q0, q1, t))


def _circular_dist_deg(a: float, b: float) -> float:
    d = abs(float(a) - float(b)) % 360.0
    return min(d, 360.0 - d)


def _find_azimuth_bracket(
    sorted_azis: list[float], theta_deg: float
) -> tuple[int, int, float] | None:
    """
    在按方位角升序排列的 [0,360) 角度上，找到 θ 所在弧段及插值系数 α∈[0,1]（沿短弧从 i_low 到 i_high）。
    返回 (idx_low, idx_high, alpha)；若仅 1 个角度则返回 None。
    """
    n = len(sorted_azis)
    if n == 0:
        return None
    if n == 1:
        return None
    theta = float(theta_deg) % 360.0
    # 非环绕段
    for i in range(n - 1):
        a, b = sorted_azis[i], sorted_azis[i + 1]
        if a <= theta <= b:
            denom = b - a
            alpha = 0.0 if denom < 1e-9 else (theta - a) / denom
            return i, i + 1, float(np.clip(alpha, 0.0, 1.0))
    # 环绕：最后一帧 → 第一帧 +360°
    a, b = sorted_azis[-1], sorted_azis[0] + 360.0
    theta_ext = theta if theta >= sorted_azis[-1] else theta + 360.0
    denom = b - a
    alpha = 0.0 if denom < 1e-9 else (theta_ext - a) / denom
    return n - 1, 0, float(np.clip(alpha, 0.0, 1.0))


def filter_train_cameras_by_nearest_depression(
    train_cameras: list,
    target_dep: float,
    source_path: str | None,
) -> list:
    """按俯视角与目标最接近的一批训练相机（用于多俯角数据）。"""
    scored = []
    for cam in train_cameras:
        da = _dep_azi_for_view_name(getattr(cam, "image_name", "") or "", source_path)
        if da is not None:
            dep_c = float(da[0])
        else:
            dep_c = getattr(cam, "depression_angle", None)
            if dep_c is None and getattr(cam, "sar_params", None):
                dep_c = cam.sar_params.get("depression_angle")
            if dep_c is None:
                continue
            dep_c = float(dep_c)
        scored.append((abs(dep_c - float(target_dep)), dep_c, cam))
    if not scored:
        return list(train_cameras)
    best = min(s[0] for s in scored)
    return [s[2] for s in scored if s[0] <= best + 1e-6]


def _filename_azimuth_deg_from_camera(cam, source_path: str | None) -> float | None:
    da = _dep_azi_for_view_name(getattr(cam, "image_name", "") or "", source_path)
    if da is None:
        return None
    return float(da[1]) % 360.0


def _print_colmap_track_azimuth_diagnostics(
    train_cameras: list,
    source_path: str | None,
    label: str = "",
) -> None:
    """打印训练相机「几何 atan2(z,x)」与「文件名方位」的分布，便于排查为何多视角像同一方位。"""
    geoms = [geom_azimuth_deg_from_center(c) for c in train_cameras]
    fn_az = []
    for c in train_cameras:
        a = _filename_azimuth_deg_from_camera(c, source_path)
        if a is not None:
            fn_az.append(a)
    if not geoms:
        return
    g = np.array(geoms, dtype=np.float64)
    pref = f"   [colmap_track 诊断{label}] "
    print(
        f"{pref}几何方位 atan2(z,x): min={g.min():.1f}° max={g.max():.1f}° "
        f"std={float(np.std(g)):.2f}° (N={len(g)})"
    )
    if len(fn_az) >= 2:
        f = np.array(fn_az, dtype=np.float64)
        print(
            f"{pref}文件名方位角: min={f.min():.1f}° max={f.max():.1f}° "
            f"std={float(np.std(f)):.2f}° (可解析 N={len(fn_az)}/{len(train_cameras)})"
        )
        abs_d = []
        for c in train_cameras:
            fa = _filename_azimuth_deg_from_camera(c, source_path)
            if fa is None:
                continue
            ga = geom_azimuth_deg_from_center(c)
            d = abs(ga - fa) % 360.0
            abs_d.append(min(d, 360.0 - d))
        if abs_d:
            print(
                f"{pref}|geom − filename| 圆周均值 ≈ {float(np.mean(abs_d)):.2f}° "
                f"(大则网格应用 --colmap_track_azimuth_space filename，默认已是 filename)"
            )
    elif len(fn_az) == 0:
        print(
            f"{pref}无文件名方位解析 → 只能用 geom；请检查 parse_mstar / 映射。"
        )


def colmap_track_pose_for_azimuth(
    train_cameras_filtered: list,
    theta_deg: float,
    use_interp: bool,
    azimuth_space: str = "filename",
    source_path: str | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    """
    从训练相机得到 (R_cam_to_world, T_w2c, R_world_to_radar)。

    azimuth_space:
      - **filename**（默认）：按文件名解析的方位角排序/插值，与输出网格 azimuth_000..359 一致。
      - **geom**：按相机中心几何 atan2(z,x)，与文件名可能差几度，易导致「扫网格却像同一视角」。
    """
    if not train_cameras_filtered:
        raise ValueError("colmap_track: 无训练相机")

    space = (azimuth_space or "filename").strip().lower()
    cams: list = []
    azis: list[float] = []
    tag = "geom_azi"

    if space == "filename":
        pairs: list[tuple[float, object]] = []
        for c in train_cameras_filtered:
            a = _filename_azimuth_deg_from_camera(c, source_path)
            if a is not None:
                pairs.append((float(a), c))
        if len(pairs) == 0:
            space = "geom"
            cams = list(train_cameras_filtered)
            print(
                "   ⚠️  colmap_track：无相机可解析文件名方位，已回退 azimuth_space=geom"
            )
        else:
            tag = "file_azi"
            pairs.sort(key=lambda p: (p[0], getattr(p[1], "image_name", "")))
            azis = [p[0] for p in pairs]
            cams = [p[1] for p in pairs]

    if space == "geom":
        cams = list(train_cameras_filtered)
        cams.sort(
            key=lambda c: (geom_azimuth_deg_from_center(c), getattr(c, "image_name", ""))
        )
        azis = [geom_azimuth_deg_from_center(c) for c in cams]
        tag = "geom_azi"

    theta = float(theta_deg) % 360.0

    if not use_interp or len(cams) == 1:
        best_i = min(
            range(len(cams)),
            key=lambda i: _circular_dist_deg(azis[i], theta),
        )
        best_cam = cams[best_i]
        R, T = _cam_rt_numpy(best_cam)
        Rwr = _cam_R_world_to_radar_numpy(best_cam)
        note = f"nearest {tag}={azis[best_i]:.2f}° ({getattr(best_cam, 'image_name', '')})"
        return R.astype(np.float32), T.astype(np.float32), Rwr.astype(np.float32), note

    br = _find_azimuth_bracket(azis, theta)
    if br is None:
        best_i = min(
            range(len(cams)),
            key=lambda i: _circular_dist_deg(azis[i], theta),
        )
        best_cam = cams[best_i]
        R, T = _cam_rt_numpy(best_cam)
        Rwr = _cam_R_world_to_radar_numpy(best_cam)
        note = (
            f"bracket-fallback→nearest {tag}={azis[best_i]:.2f}° "
            f"({getattr(best_cam, 'image_name', '')})"
        )
        return R.astype(np.float32), T.astype(np.float32), Rwr.astype(np.float32), note

    i0, i1, alpha = br
    cam0, cam1 = cams[i0], cams[i1]
    C0 = _camera_center_numpy(cam0)
    C1 = _camera_center_numpy(cam1)
    R0, _ = _cam_rt_numpy(cam0)
    R1, _ = _cam_rt_numpy(cam1)
    R_wc0 = R0.T
    R_wc1 = R1.T
    R_wc = _slerp_rotmat(R_wc0, R_wc1, alpha)
    C = (1.0 - alpha) * C0 + alpha * C1
    T_new = (-R_wc @ C.reshape(3, 1)).reshape(3)
    R_cw_new = R_wc.T

    Rwr0 = _cam_R_world_to_radar_numpy(cam0)
    Rwr1 = _cam_R_world_to_radar_numpy(cam1)
    R_wr_new = _slerp_rotmat(Rwr0, Rwr1, alpha)

    a0, a1 = azis[i0], azis[i1]
    note = f"interp α={alpha:.4f} between {tag} {a0:.2f}° & {a1:.2f}° ({getattr(cam0, 'image_name', '')} / {getattr(cam1, 'image_name', '')})"
    return R_cw_new.astype(np.float32), T_new.astype(np.float32), R_wr_new.astype(np.float32), note


def create_novel_camera_colmap_track(
    depression_angle: float,
    azimuth_angle: float,
    ref_camera,
    sar_params: dict,
    train_cameras_filtered: list,
    use_interp: bool,
    uid: int = 0,
    azimuth_pose_deg: float | None = None,
    azimuth_space: str = "filename",
    source_path: str | None = None,
):
    """完全由 COLMAP 训练轨迹插值/最近邻得到外参，不经过解析圆环。"""
    pose_azi = float(azimuth_pose_deg) if azimuth_pose_deg is not None else float(azimuth_angle)
    R_cw, T, R_wr, _note = colmap_track_pose_for_azimuth(
        train_cameras_filtered,
        pose_azi,
        use_interp=use_interp,
        azimuth_space=azimuth_space,
        source_path=source_path,
    )
    R_wr_out, use_sar_proj = _novel_radar_and_use_sar_projection_like_ref(ref_camera, R_wr)
    sar_params = sar_params.copy()
    sar_params["depression_angle"] = depression_angle
    sar_params["azimuth_angle"] = pose_azi
    resolution = (ref_camera.image_width, ref_camera.image_height)
    dummy_image = Image.fromarray(np.zeros((resolution[1], resolution[0], 3), dtype=np.uint8))
    image_name = f"dep{depression_angle:.1f}_azi{float(azimuth_angle):.1f}"
    trans = getattr(ref_camera, "trans", np.array([0.0, 0.0, 0.0]))
    scale = getattr(ref_camera, "scale", 1.0)
    return Camera(
        resolution=resolution,
        colmap_id=uid,
        R=R_cw,
        T=T,
        FoVx=ref_camera.FoVx,
        FoVy=ref_camera.FoVy,
        depth_params=None,
        image=dummy_image,
        invdepthmap=None,
        image_name=image_name,
        uid=uid,
        trans=trans,
        scale=scale,
        data_device="cuda",
        R_world_to_radar=R_wr_out,
        use_sar_rendering=use_sar_proj,
        sar_params=sar_params,
        azimuth_angle=pose_azi,
        depression_angle=depression_angle,
    )


def estimate_median_ring_from_colmap_train_cameras(train_cameras):
    """
    直接从 COLMAP 训练相机中心统计水平环参数（与数据一致，不经过 SAR 解析 sin(俯角) 公式）。
    适用于「训练集均为同一俯角（如 15°）绕目标环拍」的情形。

    Returns:
        r_xz_med: median(sqrt(x^2+z^2))
        y_med: median(Y)（COLMAP Y 向下，相机在目标上方时一般为负）
        centers: (N,3) 便于调试
    """
    if not train_cameras:
        raise ValueError("无训练相机")
    centers = []
    for cam in train_cameras:
        c = cam.camera_center.detach().cpu().numpy().reshape(3)
        centers.append(c)
    C = np.stack(centers, axis=0)
    r_xz = np.sqrt(C[:, 0] ** 2 + C[:, 2] ** 2)
    r_xz_med = float(np.median(r_xz))
    y_med = float(np.median(C[:, 1]))
    return r_xz_med, y_med, C


def ring_world_position_from_colmap_median_ring(
    r_xz: float, y_world: float, azimuth_deg: float
) -> np.ndarray:
    """
    在 XZ 平面以半径 r_xz、固定高度 y_world 上取方位角 azimuth 对应点。
    与训练 COLMAP 相机分布（单俯角环视）一致，不引入解析俯角斜距公式。
    """
    azi_rad = np.deg2rad(float(azimuth_deg))
    return np.array(
        [
            [r_xz * np.cos(azi_rad)],
            [y_world],
            [r_xz * np.sin(azi_rad)],
        ],
        dtype=np.float64,
    )


def create_novel_camera_colmap_ring(
    depression_angle: float,
    azimuth_angle: float,
    ref_camera,
    sar_params: dict,
    r_xz: float,
    y_world: float,
    uid: int = 0,
    azimuth_pose_deg: float | None = None,
):
    """
    使用 COLMAP 训练集统计的 (r_xz, Y) 构造环上 P，再用 pradar_to_world_to_camera_rt 得 R|t。
    若训练数据仅为某一俯角（如 15°），位姿应与训练分布一致；depression_angle 仅写入元数据/SAR 参数。
    azimuth_pose_deg：用于位姿的方位角（可与文件名网格角 azimuth_angle 不同，例如加了 offset）。
    """
    if pradar_to_world_to_camera_rt is None:
        raise RuntimeError("pradar_to_world_to_camera_rt 不可用")
    pose_azi = float(azimuth_pose_deg) if azimuth_pose_deg is not None else float(azimuth_angle)
    sar_params = sar_params.copy()
    sar_params["depression_angle"] = depression_angle
    sar_params["azimuth_angle"] = pose_azi
    P_radar = ring_world_position_from_colmap_median_ring(
        r_xz, y_world, pose_azi
    )
    azi_rad = np.deg2rad(pose_azi)
    R_world_to_radar, t = pradar_to_world_to_camera_rt(P_radar, azi_rad)
    R_wr_out, use_sar_proj = _novel_radar_and_use_sar_projection_like_ref(
        ref_camera, R_world_to_radar
    )
    R_cam_to_world = R_world_to_radar.T
    T = np.asarray(t, dtype=np.float32).reshape(-1)
    resolution = (ref_camera.image_width, ref_camera.image_height)
    dummy_image = Image.fromarray(np.zeros((resolution[1], resolution[0], 3), dtype=np.uint8))
    image_name = f"dep{depression_angle:.1f}_azi{float(azimuth_angle):.1f}"
    trans = getattr(ref_camera, "trans", np.array([0.0, 0.0, 0.0]))
    scale = getattr(ref_camera, "scale", 1.0)
    return Camera(
        resolution=resolution,
        colmap_id=uid,
        R=R_cam_to_world,
        T=T,
        FoVx=ref_camera.FoVx,
        FoVy=ref_camera.FoVy,
        depth_params=None,
        image=dummy_image,
        invdepthmap=None,
        image_name=image_name,
        uid=uid,
        trans=trans,
        scale=scale,
        data_device="cuda",
        R_world_to_radar=R_wr_out,
        use_sar_rendering=use_sar_proj,
        sar_params=sar_params,
        azimuth_angle=pose_azi,
        depression_angle=depression_angle,
    )


def create_novel_sar_camera(
    depression_angle,
    azimuth_angle,
    ref_camera,
    sar_params,
    uid=0,
    distance_scale: float = 1.0,
):
    if not SAR_GEOMETRY_AVAILABLE:
        raise RuntimeError("sar_geometry 未找到，无法创建 SAR 新视角相机")
    sar_params = sar_params.copy()
    sar_params["depression_angle"] = depression_angle
    sar_params["azimuth_angle"] = azimuth_angle
    ref_dep = getattr(ref_camera, "depression_angle", None)
    if ref_dep is None and getattr(ref_camera, "sar_params", None) is not None:
        ref_dep = ref_camera.sar_params.get("depression_angle")
    if ref_dep is not None:
        sar_params["unified_sita0_for_radius"] = np.deg2rad(float(ref_dep))
    # 不再在此处改 camera_distribution_mode；必须与训练时一致（通常 ring）
    R_world_to_radar, t, K_sar = compute_sar_camera_pose(depression_angle, azimuth_angle, sar_params)
    R_world_to_radar, t = apply_radar_world_distance_scale(
        R_world_to_radar, t, distance_scale
    )
    R_wr_out, use_sar_proj = _novel_radar_and_use_sar_projection_like_ref(
        ref_camera, R_world_to_radar
    )
    R_cam_to_world = R_world_to_radar.T
    T = t.flatten()
    resolution = (ref_camera.image_width, ref_camera.image_height)
    w, h = int(resolution[0]), int(resolution[1])
    # 与 readMstarNoSfMSceneInfo / 训练单视角一致：FoV 由 K 反推，避免多俯角网格误用 ref 的 FoV
    FoVx = focal2fov(float(K_sar[0, 0]), w)
    FoVy = focal2fov(float(K_sar[1, 1]), h)
    dummy_image = Image.fromarray(np.zeros((h, w, 3), dtype=np.uint8))
    image_name = f"dep{depression_angle:.1f}_azi{azimuth_angle:.1f}"
    trans = getattr(ref_camera, "trans", np.array([0.0, 0.0, 0.0]))
    scale = getattr(ref_camera, "scale", 1.0)
    return Camera(
        resolution=resolution,
        colmap_id=uid,
        R=R_cam_to_world,
        T=T,
        FoVx=FoVx,
        FoVy=FoVy,
        depth_params=None,
        image=dummy_image,
        invdepthmap=None,
        image_name=image_name,
        uid=uid,
        trans=trans,
        scale=scale,
        data_device="cuda",
        R_world_to_radar=R_wr_out,
        use_sar_rendering=use_sar_proj,
        sar_params=sar_params,
        azimuth_angle=azimuth_angle,
        depression_angle=depression_angle,
    )


def _camera_center_xyz_numpy(cam) -> np.ndarray:
    c = getattr(cam, "camera_center", None)
    if c is None:
        return np.zeros(3, dtype=np.float64)
    if isinstance(c, torch.Tensor):
        return np.asarray(c.detach().cpu(), dtype=np.float64).reshape(3)
    return np.asarray(c, dtype=np.float64).reshape(3)


def _run_dataset_geometry_scale_diagnostics(
    gaussians: GaussianModel,
    ref_camera,
    train_cameras: list,
    output_dir: Path,
    pipeline,
) -> None:
    """
    基于世界坐标统计 fused 初始化高尺度量级，相对训练相机到场景质心的距离做点云是否「偏大/偏小」启发式提示。
    """
    xyz = gaussians.get_xyz.detach().cpu().numpy().astype(np.float64)
    n = xyz.shape[0]
    if n == 0:
        print("⚠️ init_geom_diag: 高斯数量为 0，跳过诊断")
        return

    lo = xyz.min(axis=0)
    hi = xyz.max(axis=0)
    center = xyz.mean(axis=0)
    ext = hi - lo
    diagonal = float(np.linalg.norm(ext))
    dist_c = np.linalg.norm(xyz - center.reshape(1, 3), axis=1)
    r_mean = float(np.mean(dist_c))
    r_med = float(np.median(dist_c))
    r_p95 = float(np.percentile(dist_c, 95.0))

    scales = gaussians.get_scaling.detach().cpu().numpy()
    sig_max = np.max(scales, axis=1)
    med_sig_max = float(np.median(sig_max))

    cam_centers = np.stack([_camera_center_xyz_numpy(c) for c in train_cameras], axis=0) if train_cameras else None
    d_cam = None
    if cam_centers is not None and cam_centers.shape[0] > 0:
        d_to_scene = np.linalg.norm(cam_centers - center.reshape(1, 3), axis=1)
        d_cam = {
            "min_dist_cam_to_centroid": float(np.min(d_to_scene)),
            "median_dist_cam_to_centroid": float(np.median(d_to_scene)),
            "max_dist_cam_to_centroid": float(np.max(d_to_scene)),
            "mean_dist_cam_to_centroid": float(np.mean(d_to_scene)),
        }

    ratios: dict[str, float] = {}
    hints: list[str] = []
    if d_cam and d_cam["median_dist_cam_to_centroid"] > 1e-9:
        d_m = float(d_cam["median_dist_cam_to_centroid"])
        ratios["diag_over_median_cam_dist"] = float(diagonal / d_m)
        ratios["r95_over_median_cam_dist"] = float(r_p95 / d_m)
        rg = ratios["diag_over_median_cam_dist"]
        if rg > 0.85:
            hints.append(
                f"AABB对角线相对训练相机到中位距离很大（diag/cam_dist≈{rg:.3f}），"
                "世界系外延偏「胖」，画面上易铺得很满；可复查稀疏尺度、sar_scale_params。"
            )
        elif rg < 0.06:
            hints.append(
                f"AABB对角线相对训练相机到中位距离很小（diag/cam_dist≈{rg:.3f}），画面上目标可能偏小。"
            )
        else:
            hints.append(f"粗比 diag/cam_median_dist={rg:.3f}（仅为启发式，非严格屏占比）。")

    sar_fast = bool(getattr(pipeline, "sar_fast_mode", True))
    hints.append(
        f"sar_fast_mode={sar_fast}：True 时常为光学近似渲染，与 SAR 光栅的主观占画比例可能不一致；"
        "请与同名训练 SAR 视图对比。"
    )

    diag_rec = {
        "gaussian_count_init": int(n),
        "world_aabb_min": lo.tolist(),
        "world_aabb_max": hi.tolist(),
        "world_centroid_mean_xyz": center.tolist(),
        "bbox_extents_xyz": ext.tolist(),
        "bbox_diagonal": diagonal,
        "dist_to_centroid_mean_median_p95_world": {"mean": r_mean, "median": r_med, "p95": r_p95},
        "gaussian_median_max_scale_axis": med_sig_max,
        "training_camera_count": int(cam_centers.shape[0]) if cam_centers is not None else 0,
        "dist_cameras_to_centroid_stats": d_cam,
        "heuristic_dimensionless_ratios": ratios or None,
        "interpretation_hints_zh": hints,
        "reference_train_image_used_for_ref_camera": str(getattr(ref_camera, "image_name", "")),
        "notes_zh": (
            "仅诊断 create_from_pcd 的 fused 三维坐标；不包含 mesh prior 缩放。"
            "与 SAR 「目标剪影占比」须在相同相机条目下目视对照 GT。"
        ),
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    out_json = Path(output_dir) / "from_dataset_geometry_scale_diag.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(diag_rec, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 80)
    print("📊 数据集 fused 初始化几何尺度诊断（--from_dataset_geometry）")
    print("=" * 80)
    print(f"   点数(高斯数): {n}")
    print(f"   AABB 对角线(世界单位): {diagonal:.6g}")
    print(f"   点云均值中心: ({center[0]:.6g}, {center[1]:.6g}, {center[2]:.6g})")
    if d_cam:
        print(
            f"   训练相机到中心距: median={d_cam['median_dist_cam_to_centroid']:.6g}, "
            f"min={d_cam['min_dist_cam_to_centroid']:.6g}, max={d_cam['max_dist_cam_to_centroid']:.6g}"
        )
    if ratios:
        print(
            f"   启发比 diag/cam_median_dist ≈ {ratios['diag_over_median_cam_dist']:.4f} "
            "（偏大→易铺满画面的启发提示）"
        )
    print(f"   详情: {out_json}")
    print("=" * 80 + "\n")


def render_novel_views(
    gaussians,
    pipeline,
    background,
    output_dir: Path,
    depression_angles: list[float],
    azimuth_angles: list[float],
    ref_camera,
    use_sar_mode: bool = True,
    same_depression_only: bool = False,
    force_sphere_distribution: bool = False,
    source_path: str | None = None,
    sar_scale_json: str | None = None,
    use_sfm_scale_file: bool = True,
    distance_calibration: bool = True,
    novel_pose_mode: str = "colmap_track",
    train_cameras: list | None = None,
    colmap_platform_h: float | None = None,
    colmap_override_r_xz: float | None = None,
    colmap_override_y: float | None = None,
    azimuth_offset_deg: float = 0.0,
    colmap_track_nearest_only: bool = False,
    colmap_track_azimuth_space: str = "filename",
    output_filename_style: str = "legacy",
    output_image_ext: str | None = None,
    output_layout: str = "nested",
    novel_target_name: str | None = None,
    mstar_nosfm: bool = False,
    novel_pose_debug: bool = False,
):
    if not SAR_GEOMETRY_AVAILABLE:
        print("❌ sar_geometry 不可用，退出")
        return
    if ref_camera is None:
        print("❌ 无参考相机，退出")
        return
    if not use_sar_mode:
        print("❌ 当前未启用 SAR 模式，新视角脚本仅支持 SAR，退出")
        return

    style = (output_filename_style or "legacy").strip().lower()
    if style not in ("legacy", "mstar"):
        style = "legacy"
    target_nm = (novel_target_name or "").strip() or _extract_target_name_from_train_cameras(
        train_cameras or []
    )
    if style == "mstar":
        img_ext = (output_image_ext or "jpg").lstrip(".").lower()
        print(
            f"   输出文件名: MSTAR 风格（{target_nm}-<俯角>-<方位角>.{img_ext}，方位角三位补零）"
        )
    layout = (output_layout or "nested").strip().lower()
    if layout not in ("nested", "flat"):
        layout = "nested"

    if not getattr(ref_camera, "use_sar_rendering", False):
        print(
            "   ℹ️  训练相机未启用 SAR 投影矩阵（scene 加载 COLMAP 时常为 use_sar_geometry=False），"
            "新视角将使用与训练相同的透视 FoV 投影；若此前误用 SAR 投影矩阵会导致渲染呈碎点/乱点。"
        )

    if mstar_nosfm and (novel_pose_mode or "").strip().lower() == "colmap_track":
        print(
            "   ⚠️  mstar_nosfm + colmap_track：外参为邻帧/方位插值，与纯解析 compute_sar_camera_pose 可能失配，"
            "易出现错位或花斑。无特殊需求时建议用 novel_pose_mode=sar（默认在仅 cfg 有 mstar_nosfm 且未传参时自动启用）。"
        )

    use_colmap_ring = novel_pose_mode == "colmap_ring"
    use_colmap_track = novel_pose_mode == "colmap_track"
    tc = train_cameras if train_cameras is not None else []

    if use_colmap_ring:
        if len(tc) == 0:
            print("❌ colmap_ring 模式需要训练相机列表（train_cameras）")
            return
        r_xz_med, y_med, C_all = estimate_median_ring_from_colmap_train_cameras(tc)
        if colmap_override_r_xz is not None:
            r_xz_med = float(colmap_override_r_xz)
            print(f"   覆盖: r_xz = {r_xz_med:.6g}")
        if colmap_override_y is not None:
            y_med = float(colmap_override_y)
            print(f"   覆盖: Y_world = {y_med:.6g}")
        elif colmap_platform_h is not None:
            # 正数表示「平台高度」模长，COLMAP 世界系 Y 向下 → y = -h
            y_med = -float(colmap_platform_h)
            print(f"   覆盖: Y_world = -colmap_platform_h = {y_med:.6g}")
        d_mean = float(np.mean(np.linalg.norm(C_all, axis=1)))
        print(
            f"   新视角: COLMAP 中位数环 — N={len(tc)}, "
            f"median(r_xz)={r_xz_med:.6g}, median(Y)={y_med:.6g}, mean||C||={d_mean:.6g}"
        )
        print(
            "   ℹ️  位姿仅由训练相机中心统计得到（适合「单俯角如15°」环视）；"
            "多俯角子目录若未开几何缩放，则与同一环位姿相同。"
        )
        sar_params = _get_sar_params_from_camera(ref_camera)
        distance_scale = 1.0
        ref_dep = None
    elif use_colmap_track:
        if len(tc) == 0:
            print("❌ colmap_track 模式需要训练相机列表（train_cameras）")
            return
        sar_params = _get_sar_params_from_camera(ref_camera)
        if use_sfm_scale_file and source_path:
            sar_params = merge_sfm_scale_params(
                sar_params,
                source_path=source_path,
                scale_json_path=sar_scale_json,
                mstar_nosfm=mstar_nosfm,
            )
        distance_scale = 1.0
        ref_dep = None
        mode_s = "最近邻复制训练帧外参" if colmap_track_nearest_only else "相邻帧间 slerp(R_wc)+lerp(相机中心)，并 slerp(R_world_to_radar)"
        azi_key = (colmap_track_azimuth_space or "filename").strip().lower()
        print(
            f"   新视角: COLMAP 轨迹（{mode_s}）；方位键={azi_key} "
            f"（filename=按文件名解析方位，与 azimuth_000 网格一致；geom=atan2(z,x)）。"
        )
        if colmap_track_nearest_only:
            print(
                "\n   ⚠️  colmap_track_nearest_only=True：每个网格角都会用「与其最近的训练帧」的完整外参。"
                "相邻多个方位角常常对应**同一**训练帧 → 渲染会像**同一张图重复**，不是模型坏了。"
                "若需要随方位连续变化的新视角：不要加此开关（默认即插值），或改用 "
                "`--novel_pose_mode sar`（与 MSTAR 解析 compute_sar_camera_pose 一致）或 `colmap_ring`。\n"
            )
        if len(depression_angles) > 0:
            _fd = filter_train_cameras_by_nearest_depression(
                tc, float(depression_angles[0]), source_path
            )
            _print_colmap_track_azimuth_diagnostics(
                _fd, source_path, f" 俯角≈{depression_angles[0]}°"
            )
    else:
        sar_params = _get_sar_params_from_camera(ref_camera)
        if use_sfm_scale_file:
            sar_params = merge_sfm_scale_params(
                sar_params,
                source_path=source_path,
                scale_json_path=sar_scale_json,
                mstar_nosfm=mstar_nosfm,
            )
        ref_dep = getattr(ref_camera, "depression_angle", None) or (
            getattr(ref_camera, "sar_params") or {}
        ).get("depression_angle")
        if ref_dep is not None:
            sar_params["unified_sita0_for_radius"] = np.deg2rad(float(ref_dep))

        distance_scale = 1.0
        # 无 SfM：训练位姿与 sar_params 来自同一套解析式，用 COLMAP 比距自校准会引入错误 scale
        if mstar_nosfm:
            print("   ℹ️  mstar_nosfm：跳过 COLMAP 距离自校准（保持 distance_scale=1）")
        elif distance_calibration:
            distance_scale = calibrate_distance_scale_to_colmap(
                ref_camera, sar_params, source_path=source_path
            )

    if same_depression_only:
        da = _dep_azi_for_view_name(ref_camera.image_name, source_path)
        if da is not None:
            depression_angles = [float(da[0])]
            print(f"   仅训练俯角 {da[0]}°，仅变方位角")
        elif ref_dep is not None:
            depression_angles = [float(ref_dep)]
            print(f"   仅训练俯角 {ref_dep}°，仅变方位角")
        else:
            print(
                "   ⚠️ same_depression_only 但无法从文件名/映射得到俯角，保留原 --depression_angles"
            )

    if not use_colmap_ring and not use_colmap_track:
        if force_sphere_distribution:
            sar_params["camera_distribution_mode"] = "sphere"
            print("   ⚠️ 已强制 sphere 分布（若与训练不一致，易出现杂乱光点）")
        else:
            dist_mode = sar_params.get("camera_distribution_mode", "ring")
            print(
                f"   相机分布模式: {dist_mode}（继承训练相机 sar_params；应与训练时一致）"
            )

    img_ext = (output_image_ext or ("jpg" if style == "mstar" else "png")).lstrip(".").lower()

    novel_base = Path(output_dir) / "novel_views"
    flat_base = Path(output_dir)
    total = 0
    pose_debug_count = 0
    outer = tqdm(
        [(d, a) for d in depression_angles for a in azimuth_angles],
        desc="新视角渲染",
        unit="img",
    )
    for dep, azi in outer:
        dep_name = f"depression_{int(dep)}" if dep == int(dep) else f"depression_{str(dep).replace('.', '_')}"
        if layout == "flat":
            renders_dir = flat_base
        else:
            dep_dir = novel_base / dep_name
            renders_dir = dep_dir / "renders"
        renders_dir.mkdir(parents=True, exist_ok=True)
        fname = _novel_output_basename(style, target_nm, dep, float(azi), ext=img_ext)
        out_path = renders_dir / fname
        if out_path.exists():
            total += 1
            continue
        try:
            if use_colmap_ring:
                azi_pose = float(azi) + float(azimuth_offset_deg)
                cam = create_novel_camera_colmap_ring(
                    dep,
                    float(azi),
                    ref_camera,
                    sar_params,
                    r_xz=float(r_xz_med),
                    y_world=float(y_med),
                    uid=total,
                    azimuth_pose_deg=azi_pose,
                )
            elif use_colmap_track:
                filt = filter_train_cameras_by_nearest_depression(
                    tc, float(dep), source_path
                )
                azi_pose = float(azi) + float(azimuth_offset_deg)
                cam = create_novel_camera_colmap_track(
                    dep,
                    float(azi),
                    ref_camera,
                    sar_params,
                    filt,
                    use_interp=not colmap_track_nearest_only,
                    uid=total,
                    azimuth_pose_deg=azi_pose,
                    azimuth_space=colmap_track_azimuth_space,
                    source_path=source_path,
                )
            else:
                cam = create_novel_sar_camera(
                    dep,
                    azi,
                    ref_camera,
                    sar_params,
                    uid=total,
                    distance_scale=distance_scale,
                )
        except Exception as e:
            print(f"⚠️ 创建相机 dep={dep} azi={azi} 失败: {e}")
            continue
        if novel_pose_debug and pose_debug_count < 3:
            pose_debug_count += 1
            cc = cam.camera_center
            if hasattr(cc, "detach"):
                cc = cc.detach().cpu().numpy().reshape(3)
            else:
                cc = np.asarray(cc, dtype=np.float64).reshape(3)
            print(
                f"   [novel 位姿抽查 {pose_debug_count}/3] {cam.image_name} "
                f"dep={dep}° azi={azi}° 相机中心≈[{cc[0]:.4f},{cc[1]:.4f},{cc[2]:.4f}]"
            )
        with torch.inference_mode():
            # 与训练一致：仅当相机 use_sar_rendering=True 时才向 render 传 sar_mode=True（见 gaussian_renderer）
            use_sar_rendering = use_sar_mode and getattr(cam, "use_sar_rendering", False)
            render_result = render(
                cam,
                gaussians,
                pipeline,
                background,
                use_trained_exp=False,
                separate_sh=SPARSE_ADAM_AVAILABLE,
                sar_mode=use_sar_rendering,
            )
        rendering = torch.clamp(render_result["render"], 0.0, 1.0)
        op = str(out_path).lower()
        if op.endswith((".jpg", ".jpeg")):
            arr = (
                rendering.detach().cpu().permute(1, 2, 0).numpy().clip(0.0, 1.0) * 255.0
            ).astype(np.uint8)
            Image.fromarray(arr).save(str(out_path), quality=95)
        elif op.endswith(".bmp"):
            arr = (
                rendering.detach().cpu().permute(1, 2, 0).numpy().clip(0.0, 1.0) * 255.0
            ).astype(np.uint8)
            if arr.shape[-1] >= 3:
                gray = (
                    0.299 * arr[:, :, 0] + 0.587 * arr[:, :, 1] + 0.114 * arr[:, :, 2]
                ).astype(np.uint8)
                Image.fromarray(gray, mode="L").save(str(out_path))
            else:
                Image.fromarray(arr.squeeze(), mode="L").save(str(out_path))
        else:
            torchvision.utils.save_image(rendering, str(out_path))
        total += 1

    root_msg = flat_base if layout == "flat" else novel_base
    print(f"\n✅ 新视角渲染完成，累计写入/跳过 {total} 次，根目录: {root_msg}")
    if layout == "flat":
        count = sum(
            1 for p in flat_base.iterdir()
            if p.is_file() and p.suffix.lower() in (".png", ".jpg", ".jpeg", ".bmp")
        )
        print(f"   平铺输出: {flat_base} ({count} 张)")
    else:
        for dep in depression_angles:
            dep_name = f"depression_{int(dep)}" if dep == int(dep) else f"depression_{str(dep).replace('.', '_')}"
            dep_dir = novel_base / dep_name / "renders"
            if dep_dir.exists():
                count = len(list(dep_dir.glob("*.png"))) + len(list(dep_dir.glob("*.jpg")))
                count += len(list(dep_dir.glob("*.jpeg"))) + len(list(dep_dir.glob("*.bmp")))
                print(f"   俯视角 {dep}° -> {dep_dir} ({count} 张)")


def main():
    parser = ArgumentParser(description="SAR 新视角网格渲染（俯角 × 方位角）")
    model = ModelParams(parser, sentinel=True)
    pipeline = PipelineParams(parser)
    parser.add_argument("--iteration", type=int, default=-1, help="加载的迭代（-1=最新；-from_dataset_geometry 时忽略）")
    parser.add_argument(
        "--from_dataset_geometry",
        action="store_true",
        default=False,
        help="不从 point_cloud/iteration_* 加载；用 cfg 中 source_path 的 fused 初值点云等价于训练开始前 create_from_pcd，"
        "再按本脚本 SAR 网格渲染。用于检查「几何初摆放」与某一方位（如 0°）视图是否对齐；"
        "高斯 scale/不透明度等为默认初值，非训练优化结果。",
    )
    parser.add_argument(
        "--init_geom_diag",
        action="store_true",
        default=False,
        help="对当前加载的高斯点云做一次世界系尺度启发式诊断（不写图也运行）。",
    )
    parser.add_argument(
        "--no_init_geom_diag",
        action="store_true",
        default=False,
        help="与 --from_dataset_geometry 合用：不写 from_dataset_geometry_scale_diag.json / 控制台诊断块。",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=None,
        help="输出根目录（默认: model_path/novel_views_grid）",
    )
    parser.add_argument(
        "--depression_angles",
        type=str,
        default="15 17 25 45",
        help="俯视角列表（度），空格分隔",
    )
    parser.add_argument("--azimuth_start", type=int, default=0, help="方位角起始（度，含）")
    parser.add_argument(
        "--azimuth_end",
        type=int,
        default=360,
        help="方位角结束（度，不含），与 start、step 生成 range(start, end, step)。默认 360 即 0°..359°；半周可设为 181",
    )
    parser.add_argument("--azimuth_step", type=int, default=1, help="方位角步长（度）")
    parser.add_argument(
        "--same_depression_only",
        action="store_true",
        default=False,
        help="只渲染训练俯角、只扫方位角（用于快速检查）",
    )
    parser.add_argument(
        "--force_sphere_distribution",
        action="store_true",
        default=False,
        help="强制使用 sphere 相机分布（训练多为 ring，勿随意开启）",
    )
    parser.add_argument(
        "--sar_scale_json",
        type=str,
        default=None,
        help="显式指定 sar_scale_params.json 路径（默认: source_path/sar_scale_params.json）",
    )
    parser.add_argument(
        "--no_sfm_scale_file",
        action="store_true",
        default=False,
        help="不合并 SFM 尺度文件。无 SfM 训练时若 cfg 中 mstar_nosfm=True 会默认等效跳过；"
        "有 SfM 时一般不建议关（除非做对照实验）",
    )
    parser.add_argument(
        "--no_distance_calibration",
        action="store_true",
        default=False,
        help="不做 COLMAP 参考相机距离自校准（仅依赖尺度文件中的参数）",
    )
    parser.add_argument(
        "--novel_pose_mode",
        type=str,
        choices=["colmap_ring", "colmap_track", "sar"],
        default="colmap_track",
        help="默认 colmap_track：相邻训练帧间插值外参，与 COLMAP 轨迹一致（推荐内推）；"
        "colmap_ring：median(r_xz)+median(Y) 理想水平环；"
        "sar：解析 compute_sar_camera_pose + 尺度/自校准",
    )
    parser.add_argument(
        "--colmap_track_nearest_only",
        action="store_true",
        default=False,
        help="仅 colmap_track：禁用插值，每个网格角直接使用「方位键」最近邻训练帧外参。"
        "连续多格会与同一训练帧对齐，图像会像复制训练视角；需要连续新视角时不要开启。",
    )
    parser.add_argument(
        "--colmap_track_azimuth_space",
        type=str,
        choices=["filename", "geom"],
        default="filename",
        help="colmap_track 用哪种「方位角」排序/插值：filename=文件名解析（与 azimuth_XXX 网格一致，推荐）；"
        "geom=相机中心 atan2(z,x)（与文件名常有几度偏差，易导致多网格视角像同一方位）",
    )
    parser.add_argument(
        "--colmap_platform_h",
        type=float,
        default=None,
        help="colmap_ring：手动指定平台高度（正数），世界坐标 Y = -h；不填则用训练相机 median(Y)",
    )
    parser.add_argument(
        "--colmap_override_r_xz",
        type=float,
        default=None,
        help="colmap_ring：手动覆盖水平环半径 median(sqrt(x^2+z^2))",
    )
    parser.add_argument(
        "--colmap_override_y",
        type=float,
        default=None,
        help="colmap_ring：手动覆盖世界坐标 Y（COLMAP Y 向下，通常为负）",
    )
    parser.add_argument(
        "--azimuth_offset_deg",
        type=float,
        default=0.0,
        help="colmap_ring / colmap_track：目标几何方位角 θ += offset（度），用于对齐网格与 COLMAP 轨迹",
    )
    parser.add_argument(
        "--output_filename_style",
        type=str,
        choices=["legacy", "mstar"],
        default="legacy",
        help="legacy=azimuth_XXX.png（默认）；mstar=目标名-俯视角-方位角.<ext>，与 MSTAR 数据命名一致",
    )
    parser.add_argument(
        "--output_image_ext",
        type=str,
        default=None,
        help="mstar 风格扩展名（如 bmp、jpg）；默认 mstar→jpg，legacy→png",
    )
    parser.add_argument(
        "--output_layout",
        type=str,
        choices=["nested", "flat"],
        default="nested",
        help="nested=novel_views/depression_*/renders/；flat=全部写入 --output_dir 根目录",
    )
    parser.add_argument(
        "--novel_target_name",
        type=str,
        default=None,
        help="与 mstar 联用：手动指定目标名（如 T72）；不填则从训练图像文件名解析",
    )
    parser.add_argument(
        "--novel_pose_debug",
        action="store_true",
        default=False,
        help="打印前 3 张新视角相机的 image_name 与相机中心，用于确认外参是否随网格变化",
    )
    parser.add_argument("--quiet", action="store_true")
    args = get_combined_args(parser)
    # 无 SfM：默认 colmap_track 的插值外参与 SAR 光栅+投影强假设不一致，改为解析网格 sar
    if (
        bool(getattr(args, "mstar_nosfm", False))
        and "--novel_pose_mode" not in sys.argv
    ):
        args = Namespace(**{**vars(args), "novel_pose_mode": "sar"})
        print(
            "\nℹ️  mstar_nosfm=True 且未指定 --novel_pose_mode → 已自动使用 novel_pose_mode=sar"
            "（与训练时 compute_sar_camera_pose 一致）。\n"
            "   若必须沿训练帧插值，请显式: --novel_pose_mode colmap_track\n"
        )

    mp = getattr(args, "model_path", None)
    if mp is None or (isinstance(mp, str) and not mp.strip()):
        print("❌ 必须指定训练输出目录：-m / --model_path（需含 cfg_args，用于 source_path/sh_degree 等与训练对齐）。")
        print(
            "   若未使用 --from_dataset_geometry：还需内含 point_cloud/iteration_*。\n"
            "   --output_dir 只决定「渲染图保存到哪里」，不能代替 -m。\n"
            "   示例: python render_novel_sar_views.py -m ./output/51 --iteration 50000 "
            "--output_dir ./output/51/novel_views_grid"
        )
        sys.exit(1)

    safe_state(args.quiet)

    model_params = model.extract(args)
    pipeline_params = pipeline.extract(args)
    mstar_nosfm = bool(getattr(args, "mstar_nosfm", False))

    use_sar_mode = getattr(model_params, "sar_mode", False)
    if not use_sar_mode:
        print("❌ 模型未启用 SAR 模式（sar_mode）。请使用 SAR 训练得到的 output 目录。")
        sys.exit(1)
    if not SAR_GEOMETRY_AVAILABLE:
        print("❌ 无法导入 sar_geometry")
        sys.exit(1)

    out = args.output_dir
    if out is None:
        out = os.path.join(model_params.model_path, "novel_views_grid")
    output_dir = Path(out)

    dep_list = [float(x.strip()) for x in args.depression_angles.split() if x.strip()]
    azimuth_angles = list(
        range(int(args.azimuth_start), int(args.azimuth_end), int(args.azimuth_step))
    )
    if len(azimuth_angles) == 0:
        print("❌ 方位角列表为空，请检查 azimuth_start / azimuth_end / azimuth_step")
        sys.exit(1)

    print("=" * 80)
    print("SAR 新视角网格渲染")
    print("=" * 80)
    from_dataset_geom = bool(getattr(args, "from_dataset_geometry", False))
    print(f"模型: {model_params.model_path}")
    if from_dataset_geom:
        print(f"迭代: （--from_dataset_geometry：未加载 checkpoint，数据集 fused → create_from_pcd）")
    else:
        print(f"迭代: {args.iteration if args.iteration >= 0 else '最新'}")
    print(f"俯视角(CLI): {dep_list}")
    print(f"方位角: {azimuth_angles[0]}° .. {azimuth_angles[-1]}° (步长 {args.azimuth_step}°), 共 {len(azimuth_angles)} 个方位/俯角步")
    if getattr(args, "same_depression_only", False):
        print(
            "ℹ️  已启用 same_depression_only：下方「CLI 俯角列表」在进入 render 后会收窄为 "
            "**参考训练相机的单个俯角**；首屏张数若为 len(CLI)×方位，仅作预览，请以 Scene 加载后的更正行为准。"
        )
    print(f"至多（CLI 口径）≈ {len(dep_list) * len(azimuth_angles)} 张 -> {output_dir / 'novel_views'}")
    print(f"same_depression_only = {args.same_depression_only}")
    print(f"force_sphere_distribution = {args.force_sphere_distribution}")
    print(f"novel_pose_mode = {getattr(args, 'novel_pose_mode', 'colmap_track')}")
    if getattr(args, "novel_pose_mode", "") == "colmap_track":
        print(f"colmap_track_nearest_only = {getattr(args, 'colmap_track_nearest_only', False)}")
        print(
            f"colmap_track_azimuth_space = {getattr(args, 'colmap_track_azimuth_space', 'filename')}"
        )
    print(f"output_filename_style = {getattr(args, 'output_filename_style', 'legacy')}")
    if getattr(args, "output_filename_style", "legacy") == "mstar":
        n = getattr(args, "novel_target_name", None)
        print(f"novel_target_name = {n if n else '(从训练文件名自动解析)'}")
    if mstar_nosfm:
        ch = getattr(model_params, "sar_camera_height", None)
        print(
            f"mstar_nosfm = True（与 cfg 一致）: 不合并 data 下 sar_scale_params.json；"
            f"投影用 camera_height≈{ch} 等与训练相同逻辑"
        )
    print("=" * 80)

    load_it_final = getattr(args, "iteration", -1)

    # 预先检查点云检查点（仅当从 checkpoint 加载时）
    if not from_dataset_geom:
        try:
            load_it, ply_path = _resolve_checkpoint_ply(model_params.model_path, args.iteration)
        except FileNotFoundError:
            avail = _list_point_cloud_iterations(model_params.model_path)
            print(
                f"❌ 未找到目录: {os.path.join(model_params.model_path, 'point_cloud')}\n"
                "   请确认 -m 指向「训练输出目录」（内含 point_cloud/iteration_*），或先完成训练。\n"
                "   若只想用 fused 初值渲染、不看训练 checkpoint，请加 --from_dataset_geometry"
            )
            if avail:
                print(f"   若 point_cloud 存在其它机器上，当前仓库副本中已有迭代: {avail}")
            sys.exit(1)
        except ValueError:
            avail = _list_point_cloud_iterations(model_params.model_path)
            print(
                "❌ point_cloud 下没有可用的 iteration_* 子目录（无法解析「最新」迭代）。\n"
                "   请指定存在的 --iteration，或先训练并保存检查点。"
            )
            if avail:
                print(f"   已有迭代: {avail}")
            sys.exit(1)
        if not os.path.isfile(ply_path):
            avail = _list_point_cloud_iterations(model_params.model_path)
            print(f"❌ 缺少高斯模型文件:\n   {ply_path}")
            if avail:
                print(f"   当前 -m 下已有迭代: {avail}（例如 --iteration {avail[-1]}）")
            else:
                print("   未找到任何 point_cloud/iteration_*。")
            sys.exit(1)
        if args.iteration < 0:
            args.iteration = load_it
        load_it_final = args.iteration
    else:
        print(
            "\n⚠️  --from_dataset_geometry：高斯参数来自数据集初值（与训练第一步前一致），"
            "appearance 仅为默认 SH/尺度，仅用于核对几何摆放与 SAR 方位的相对关系。\n"
        )

    gaussians = GaussianModel(model_params.sh_degree)
    try:
        if from_dataset_geom:
            scene = Scene(model_params, gaussians, load_iteration=None, shuffle=False)
        else:
            scene = Scene(model_params, gaussians, load_iteration=load_it_final, shuffle=False)
    except AssertionError as e:
        if from_dataset_geom:
            print(
                f"❌ 从数据集构建场景/高斯失败（断言）: {e}\n"
                "   请检查 source_path 是否可读（sparse/）、与训练时一致；"
                "若为 MSTAR 无 SfM，需与训练相同的数据布局与 mstar_nosfm 配置。"
            )
        else:
            print(
                f"❌ 加载 checkpoint PLY 失败（断言）: {e}\n"
                "   常见于 PLY 中 f_rest_* 个数与 cfg 中 sh_degree 不一致。\n"
                "   请使用训练该模型时的同一 output 目录与 cfg_args，或核对 --iteration。"
            )
        sys.exit(1)

    bg_color = [1, 1, 1] if model_params.white_background else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device="cuda")

    ref_cameras = scene.getTrainCameras() or scene.getTestCameras()
    ref_camera = ref_cameras[0] if ref_cameras else None
    if ref_camera is None:
        print("❌ 场景无训练/测试相机")
        sys.exit(1)
    train_cameras_list = list(scene.getTrainCameras() or [])
    diag_cams_for_scale = train_cameras_list or list(scene.getTestCameras() or [])

    auto_diag = from_dataset_geom and not bool(getattr(args, "no_init_geom_diag", False))
    explicit_diag = bool(getattr(args, "init_geom_diag", False))
    if auto_diag or explicit_diag:
        _run_dataset_geometry_scale_diagnostics(
            gaussians,
            ref_camera,
            diag_cams_for_scale,
            output_dir,
            pipeline_params,
        )

    src = getattr(model_params, "source_path", None) or ""
    eff_dep = _effective_depression_angles_after_load(
        dep_list, getattr(args, "same_depression_only", False), ref_camera, src or ""
    )
    print(
        f"\n📌 本次实际渲染网格（已按 same_depression_only 等与训练一致折算）:"
        f" {len(eff_dep)} 个俯角 {eff_dep} × {len(azimuth_angles)} 个方位 "
        f"→ 至多 {len(eff_dep) * len(azimuth_angles)} 张"
    )
    if int(azimuth_angles[0]) == 0 and parse_mstar_filename is not None:
        try:
            _d_ref, az_ref = parse_mstar_filename(ref_camera.image_name)
            print(
                f"ℹ️  MSTAR 文件名语义：网格上的 0° 与训练图「最后一位数字」不是同一记号；参考相机 "
                f"{getattr(ref_camera, 'image_name', '')} 解析方位≈{az_ref}°（如 ...-001≈1°）。"
                f"需在真 0° 对比时请用最接近方位的训练帧或 --novel_pose_mode sar + 校准。"
            )
        except Exception:
            pass

    render_novel_views(
        gaussians,
        pipeline_params,
        background,
        output_dir,
        depression_angles=dep_list,
        azimuth_angles=[float(a) for a in azimuth_angles],
        ref_camera=ref_camera,
        use_sar_mode=use_sar_mode,
        same_depression_only=args.same_depression_only,
        force_sphere_distribution=args.force_sphere_distribution,
        source_path=src if src else None,
        sar_scale_json=getattr(args, "sar_scale_json", None),
        use_sfm_scale_file=not getattr(args, "no_sfm_scale_file", False),
        distance_calibration=not getattr(args, "no_distance_calibration", False),
        novel_pose_mode=getattr(args, "novel_pose_mode", "colmap_track"),
        train_cameras=train_cameras_list,
        colmap_platform_h=getattr(args, "colmap_platform_h", None),
        colmap_override_r_xz=getattr(args, "colmap_override_r_xz", None),
        colmap_override_y=getattr(args, "colmap_override_y", None),
        azimuth_offset_deg=float(getattr(args, "azimuth_offset_deg", 0.0) or 0.0),
        colmap_track_nearest_only=bool(getattr(args, "colmap_track_nearest_only", False)),
        colmap_track_azimuth_space=str(
            getattr(args, "colmap_track_azimuth_space", "filename") or "filename"
        ),
        output_filename_style=str(getattr(args, "output_filename_style", "legacy") or "legacy"),
        output_image_ext=getattr(args, "output_image_ext", None),
        output_layout=str(getattr(args, "output_layout", "nested") or "nested"),
        novel_target_name=getattr(args, "novel_target_name", None),
        mstar_nosfm=mstar_nosfm,
        novel_pose_debug=bool(getattr(args, "novel_pose_debug", False)),
    )


if __name__ == "__main__":
    main()
