#!/usr/bin/env python3
"""Learn an azimuth-conditioned SAR shadow / target-shadow refinement layer.

The legacy ``opacity`` mode predicts a single shadow opacity map and applies it
with a fixed darkening formula.  The default ``image`` mode instead predicts a
log-intensity residual over the target+shadow support and trains directly
against neighboring train-GT views, matching the clean target refiner's
appearance-learning behavior.
"""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from tqdm import tqdm

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from scripts.rendering.learn_sar_image_refiner import (  # noqa: E402
    _blur01,
    _dilate01_batch,
    _force_grayscale_chw,
    _image_files,
    _load_image,
    _parse_azimuth,
    _resize_chw,
)
from scripts.rendering.sar_shadow_refiner.azimuth import (  # noqa: E402
    angle_dist_deg,
    azimuth_prefix,
    bracketing_candidates,
    image_candidates,
    nearest_candidate,
    select_training_pairs,
    write_training_pair_report,
)


def _chw1(mask: torch.Tensor) -> torch.Tensor:
    if mask.dim() == 2:
        return mask[None]
    if mask.dim() == 3:
        return mask[:1]
    raise ValueError(f"Expected 2D/3D mask, got shape {tuple(mask.shape)}")


def _region_classification_rgb(
    target_mask: torch.Tensor,
    shadow_mask: torch.Tensor | None = None,
    shadow_threshold: float = 0.4,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return RGB classes: red=target, blue=shadow, black=background."""
    target = (_chw1(target_mask).float().clamp(0.0, 1.0) > 0.5).float()
    if shadow_mask is None:
        shadow = torch.zeros_like(target)
    else:
        threshold = min(max(float(shadow_threshold), 0.0), 1.0)
        shadow = (_chw1(shadow_mask).float().clamp(0.0, 1.0) >= threshold).float() * (1.0 - target)
    background = (1.0 - torch.maximum(target, shadow)).clamp(0.0, 1.0)
    rgb = torch.cat([target, torch.zeros_like(target), shadow], dim=0).clamp(0.0, 1.0)
    return rgb, background


def _shadow_carrier_alpha(target_mask: torch.Tensor, args) -> torch.Tensor:
    alpha = _chw1(target_mask).float().clamp(0.0, 1.0)[0]
    dilate = int(getattr(args, "shadow_carrier_target_dilate", 1) or 0)
    if dilate > 0:
        alpha = _dilate01_batch(alpha[None], dilate)[0]
    blur = int(getattr(args, "shadow_carrier_target_blur", 1) or 0)
    if blur > 0:
        alpha = torch.maximum(alpha, _blur01(alpha, blur)).clamp(0.0, 1.0)
    return alpha.clamp(0.0, 1.0)


def _parse_rgb_triplet(text: str | None, default: tuple[float, float, float]) -> tuple[float, float, float]:
    if text is None or not str(text).strip():
        return default
    parts = [p for p in re.split(r"[\s,;]+", str(text).strip()) if p]
    if len(parts) != 3:
        raise ValueError(f"Expected RGB triplet such as '1.0,0.85,0.05', got: {text!r}")
    vals = tuple(min(max(float(p), 0.0), 1.0) for p in parts)
    return vals  # type: ignore[return-value]


def _apply_shadow_carrier_background(image: torch.Tensor, target_mask: torch.Tensor, args) -> torch.Tensor:
    mode = str(getattr(args, "shadow_carrier_background", "none") or "none").lower().strip()
    if mode in {"", "none"}:
        return image
    if mode not in {"constant", "constant_rgb"}:
        raise ValueError(f"Unsupported shadow carrier background: {mode}")
    alpha = _shadow_carrier_alpha(target_mask, args).to(device=image.device, dtype=image.dtype)
    if mode == "constant_rgb":
        rgb = _parse_rgb_triplet(getattr(args, "shadow_carrier_color", None), (1.0, 0.85, 0.05))
        carrier = torch.empty_like(image)
        if carrier.shape[0] == 1:
            carrier[:] = sum(rgb) / 3.0
        else:
            for c, value in enumerate(rgb):
                carrier[c::3].fill_(value)
    else:
        value = min(max(float(getattr(args, "shadow_carrier_value", 0.85) or 0.85), 0.0), 1.0)
        carrier = torch.full_like(image, value)
    return (image * alpha.unsqueeze(0) + carrier * (1.0 - alpha).unsqueeze(0)).clamp(0.0, 1.0)


class ConvBlock(nn.Module):
    def __init__(self, cin: int, cout: int, padding_mode: str = "reflect"):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(cin, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
            nn.Conv2d(cout, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class LocalFeatureEnhancer(nn.Module):
    """DHFR-style local spatial enhancement with neutral initialization."""

    def __init__(self, channels: int, strength: float = 0.25, padding_mode: str = "reflect"):
        super().__init__()
        hidden = max(8, int(channels) // 4)
        self.strength = float(strength)
        self.mask = nn.Sequential(
            nn.Conv2d(channels, hidden, 3, padding=1, padding_mode=padding_mode),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, 1, 1),
        )
        nn.init.zeros_(self.mask[-1].weight)
        nn.init.zeros_(self.mask[-1].bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        mask = torch.sigmoid(self.mask(x))
        gain = 1.0 + self.strength * (mask - 0.5) * 2.0
        return x * gain


class DynamicHierarchicalFusion(nn.Module):
    """Fuse decoder and skip features with input-adaptive branch weights."""

    def __init__(self, decoder_ch: int, skip_ch: int, padding_mode: str = "reflect"):
        super().__init__()
        self.skip_enhance = LocalFeatureEnhancer(skip_ch, padding_mode=padding_mode)
        hidden = max(8, (int(decoder_ch) + int(skip_ch)) // 8)
        self.global_gate = nn.Sequential(
            nn.Linear(int(decoder_ch) + int(skip_ch), hidden),
            nn.SiLU(inplace=True),
            nn.Linear(hidden, 2),
        )
        nn.init.zeros_(self.global_gate[-1].weight)
        nn.init.zeros_(self.global_gate[-1].bias)

    def forward(self, decoder: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        skip = self.skip_enhance(skip)
        gd = F.adaptive_avg_pool2d(decoder, 1).flatten(1)
        gs = F.adaptive_avg_pool2d(skip, 1).flatten(1)
        weights = torch.softmax(self.global_gate(torch.cat([gd, gs], dim=1)), dim=1)
        decoder = decoder * (2.0 * weights[:, 0].view(-1, 1, 1, 1))
        skip = skip * (2.0 * weights[:, 1].view(-1, 1, 1, 1))
        return torch.cat([decoder, skip], dim=1)


class AzimuthShadowUNet(nn.Module):
    def __init__(self, in_ch: int = 10, base: int = 32, padding_mode: str = "reflect", out_ch: int = 1):
        super().__init__()
        self.e1 = ConvBlock(in_ch, base, padding_mode)
        self.e2 = ConvBlock(base, base * 2, padding_mode)
        self.e3 = ConvBlock(base * 2, base * 4, padding_mode)
        self.mid = ConvBlock(base * 4, base * 4, padding_mode)
        self.fuse2 = DynamicHierarchicalFusion(base * 4, base * 2, padding_mode)
        self.fuse1 = DynamicHierarchicalFusion(base * 2, base, padding_mode)
        self.d2 = ConvBlock(base * 6, base * 2, padding_mode)
        self.d1 = ConvBlock(base * 3, base, padding_mode)
        self.out = nn.Conv2d(base, out_ch, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e1 = self.e1(x)
        e2 = self.e2(F.avg_pool2d(e1, 2))
        e3 = self.e3(F.avg_pool2d(e2, 2))
        y = self.mid(e3)
        y = F.interpolate(y, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d2(self.fuse2(y, e2))
        y = F.interpolate(y, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d1(self.fuse1(y, e1))
        return self.out(y)


def _load_state_dict_compatible(model: nn.Module, state_dict: dict, label: str) -> None:
    try:
        model.load_state_dict(state_dict, strict=True)
        return
    except RuntimeError:
        pass

    current = model.state_dict()
    filtered = {}
    skipped = []
    for key, value in state_dict.items():
        if key in current and tuple(current[key].shape) == tuple(value.shape):
            filtered[key] = value
        else:
            skipped.append(key)
    missing, unexpected = model.load_state_dict(filtered, strict=False)
    print(
        f"[azimuth shadow] compatible load for {label}: "
        f"loaded={len(filtered)}, skipped={len(skipped)}, "
        f"missing={len(missing)}, unexpected={len(unexpected)}"
    )


def _configure_torch(args, device: torch.device) -> None:
    if device.type != "cuda":
        return
    allow_tf32 = bool(getattr(args, "allow_tf32", True))
    if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
        torch.backends.cuda.matmul.allow_tf32 = allow_tf32
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.allow_tf32 = allow_tf32
        torch.backends.cudnn.benchmark = bool(getattr(args, "cudnn_benchmark", True))
    try:
        torch.set_float32_matmul_precision("high" if allow_tf32 else "highest")
    except Exception:
        pass


def _ld(x: torch.Tensor, scale: float) -> torch.Tensor:
    return torch.log1p(x.clamp(0.0, 1.0) * scale) / math.log1p(scale)


def _from_ld(x: torch.Tensor, scale: float) -> torch.Tensor:
    return (torch.expm1(x.clamp(0.0, 1.0) * math.log1p(scale)) / scale).clamp(0.0, 1.0)


def _masked_mean(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    if mask.dim() == 3:
        mask = mask[:, None]
    return (x * mask).sum() / (mask.sum().clamp_min(1.0) * x.shape[1])


def _masked_mse(a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    return _masked_mean((a - b).pow(2), mask)


def _gradient_mag_map(x: torch.Tensor) -> torch.Tensor:
    if x.dim() == 3:
        x = x[None]
    dx = F.pad((x[..., :, 1:] - x[..., :, :-1]).abs(), (0, 1, 0, 0))
    dy = F.pad((x[..., 1:, :] - x[..., :-1, :]).abs(), (0, 0, 0, 1))
    return dx + dy


def _masked_sar_ssim_loss(pred_ld: torch.Tensor, gt_ld: torch.Tensor, mask: torch.Tensor, window_size: int = 7) -> torch.Tensor:
    x = pred_ld.mean(dim=1, keepdim=True)
    y = gt_ld.mean(dim=1, keepdim=True)
    if mask.dim() == 3:
        mask = mask[:, None]
    mask = mask.clamp(0.0, 1.0)
    radius = max(1, int(window_size) // 2)
    k = 2 * radius + 1
    weight = torch.ones((1, 1, k, k), dtype=x.dtype, device=x.device) / float(k * k)
    mu_x = F.conv2d(x, weight, padding=radius)
    mu_y = F.conv2d(y, weight, padding=radius)
    mu_x2 = mu_x * mu_x
    mu_y2 = mu_y * mu_y
    mu_xy = mu_x * mu_y
    sig_x2 = F.conv2d(x * x, weight, padding=radius) - mu_x2
    sig_y2 = F.conv2d(y * y, weight, padding=radius) - mu_y2
    sig_xy = F.conv2d(x * y, weight, padding=radius) - mu_xy
    c1 = 0.01 ** 2
    c2 = 0.03 ** 2
    ssim_map = ((2.0 * mu_xy + c1) * (2.0 * sig_xy + c2)) / (
        (mu_x2 + mu_y2 + c1) * (sig_x2 + sig_y2 + c2)
    ).clamp_min(1e-8)
    ssim_val = (ssim_map * mask).sum() / mask.sum().clamp_min(1.0)
    return (1.0 - ssim_val.clamp(-1.0, 1.0)) * 0.5


def _angle_dist(a: float, b: float) -> float:
    return angle_dist_deg(a, b)


def _azimuth_prefix(path: Path) -> str:
    return azimuth_prefix(path)


def _candidates(path: Path) -> list[dict]:
    return image_candidates(path, _image_files, _parse_azimuth)


def _nearest(cands: list[dict], az: float) -> dict:
    return nearest_candidate(cands, az)


def _bracket(cands: list[dict], az: float) -> tuple[dict, dict, float, float]:
    return bracketing_candidates(cands, az)


def _select_pairs(target_dir: Path, gt_dir: Path, args) -> list[dict]:
    return select_training_pairs(target_dir, gt_dir, args, _image_files, _parse_azimuth)


def _write_train_pair_report(pairs: list[dict], output_dir: Path) -> None:
    path = write_training_pair_report(pairs, output_dir)
    print(f"[azimuth shadow] train azimuth report: {path}")


def _mix_gt(gt_lo: torch.Tensor, gt_hi: torch.Tensor, wlo: float, whi: float, scale: float) -> torch.Tensor:
    lo = _ld(gt_lo, scale)
    hi = _ld(gt_hi, scale)
    mixed = lo * float(wlo) + hi * float(whi)
    return (torch.expm1(mixed.clamp(0.0, 1.0) * math.log1p(scale)) / scale).clamp(0.0, 1.0)


def _filter_background_target_mask(target: torch.Tensor, args, percentile_override: float | None = None) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    default_percentile = 95.0 if percentile_override is None else float(percentile_override)
    percentile = min(max(float(getattr(args, "target_mask_filter_percentile", default_percentile) if percentile_override is None else default_percentile), 0.0), 100.0)
    min_ratio = max(float(getattr(args, "target_mask_filter_min_target_ratio", 0.0005) or 0.0), 0.0)
    max_ratio = max(float(getattr(args, "target_mask_filter_max_target_ratio", 0.0) or 0.0), 0.0)
    max_percentile = min(
        max(float(getattr(args, "target_mask_filter_adaptive_max_percentile", 98.0) or 98.0), percentile),
        100.0,
    )
    use_largest = bool(getattr(args, "target_mask_filter_largest_cc", False))
    eps = 1e-6
    positive = gray[gray > eps]
    min_pixels = float(getattr(args, "target_mask_min_pixels", 16.0) or 16.0)
    if int(positive.numel()) < int(max(min_pixels, 1.0)):
        return _legacy_target_mask(target, args)

    def build_mask(pct: float) -> torch.Tensor:
        threshold = torch.quantile(positive, pct / 100.0).clamp_min(eps)
        candidate = ((gray >= threshold) & (gray > eps)).float()
        if float(candidate.mean()) < min_ratio:
            candidate = _legacy_target_mask(target, args)
        if use_largest:
            candidate = _largest_connected_component(candidate)
        return candidate

    mask = build_mask(percentile)
    if max_ratio > 0.0 and float(mask.mean()) > max_ratio and percentile < max_percentile:
        steps = max(int(math.ceil(max_percentile - percentile)), 1)
        for idx in range(1, steps + 1):
            pct = min(percentile + idx, max_percentile)
            candidate = build_mask(pct)
            mask = candidate
            if float(mask.mean()) <= max_ratio:
                break
    erode = max(int(getattr(args, "target_mask_filter_erode_px", 0) or 0), 0)
    if erode > 0:
        mask = _erode01(mask, erode)
    dilate = int(getattr(args, "target_mask_dilate", 0) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    return mask.clamp(0.0, 1.0)


def _scatter_percentile_largest_target_mask(target: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    eps = 1e-6
    positive = gray[gray > eps]
    min_pixels = float(getattr(args, "target_mask_min_pixels", 16.0) or 16.0)
    if int(positive.numel()) < int(max(min_pixels, 1.0)):
        return _legacy_target_mask(target, args)
    percentile = min(max(float(getattr(args, "target_mask_filter_percentile", 95.0) or 95.0), 0.0), 100.0)
    threshold = torch.quantile(positive, percentile / 100.0).clamp_min(eps)
    mask = ((gray >= threshold) & (gray > eps)).float()
    mask = _largest_connected_component(mask)
    if float(mask.sum().detach().cpu()) <= 0.0:
        return _legacy_target_mask(target, args)
    erode = max(int(getattr(args, "target_mask_filter_erode_px", 0) or 0), 0)
    if erode > 0:
        mask = _erode01(mask, erode)
    dilate = int(getattr(args, "target_mask_dilate", 0) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    return mask.clamp(0.0, 1.0)


def _target_mask(target: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    mode = str(getattr(args, "target_mask_mode", "legacy") or "legacy").lower().strip()
    if mode in {"binary", "semantic", "semantic_binary"}:
        threshold = float(getattr(args, "target_mask_threshold", 0.08) or 0.08)
        mask = (gray > max(1e-6, min(threshold, 0.5))).float()
        dilate = int(getattr(args, "target_mask_dilate", 0) or 0)
        if dilate > 0:
            mask = _dilate01_batch(mask[None], dilate)[0]
        return mask.clamp(0.0, 1.0)
    if mode in {"scatter95_largest", "scatter_percentile_largest"}:
        return _scatter_percentile_largest_target_mask(target, args)
    if mode in {"filter_background", "render_visibility"}:
        return _filter_background_target_mask(target, args)

    threshold = float(getattr(args, "target_mask_threshold", 0.08) or 0.08)
    quantile = float(getattr(args, "target_mask_quantile", 0.35) or 0.35)
    vals = gray[gray > 0]
    q = torch.quantile(vals, quantile) if int(vals.numel()) > 0 else gray.new_tensor(0.0)
    mask = (gray >= max(threshold, float(q.item()))).float()
    if float(mask.sum()) < float(getattr(args, "target_mask_min_pixels", 16.0) or 16.0) and int(vals.numel()) > 0:
        mask = (gray >= torch.quantile(vals, 0.15)).float()
    dilate = int(getattr(args, "target_mask_dilate", 0) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    return mask.clamp(0.0, 1.0)


def _legacy_target_mask(target: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    threshold = float(getattr(args, "target_mask_threshold", 0.08) or 0.08)
    quantile = float(getattr(args, "target_mask_quantile", 0.35) or 0.35)
    vals = gray[gray > 0]
    q = torch.quantile(vals, quantile) if int(vals.numel()) > 0 else gray.new_tensor(0.0)
    mask = (gray >= max(threshold, float(q.item()))).float()
    if float(mask.sum()) < float(getattr(args, "target_mask_min_pixels", 16.0) or 16.0) and int(vals.numel()) > 0:
        mask = (gray >= torch.quantile(vals, 0.15)).float()
    dilate = int(getattr(args, "target_mask_dilate", 0) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    return mask.clamp(0.0, 1.0)


def _repair_shadow_train_target_mask(mask_source: torch.Tensor, mask: torch.Tensor, args) -> torch.Tensor:
    if not bool(getattr(args, "shadow_train_repair_empty_candidate", True)):
        return mask.clamp(0.0, 1.0)
    mode = str(getattr(args, "target_mask_mode", "legacy") or "legacy").lower().strip()
    if mode in {"scatter95_largest", "scatter_percentile_largest"}:
        return mask.clamp(0.0, 1.0)
    ratio = float(mask.float().mean().detach().cpu())
    max_ratio = float(getattr(args, "shadow_train_target_mask_max_ratio", 0.35) or 0.35)
    min_pixels = float(getattr(args, "target_mask_min_pixels", 16.0) or 16.0)
    if ratio <= max_ratio and float(mask.sum()) >= min_pixels:
        return mask.clamp(0.0, 1.0)
    repaired = _legacy_target_mask(mask_source, args)
    repaired_ratio = float(repaired.float().mean().detach().cpu())
    if float(repaired.sum()) >= min_pixels and repaired_ratio < ratio:
        return repaired.clamp(0.0, 1.0)
    return mask.clamp(0.0, 1.0)


def _render_visibility_masks(render: torch.Tensor, target_source: torch.Tensor, args) -> dict[str, torch.Tensor]:
    core_mask = _filter_background_target_mask(render, args)
    ref_gray = target_source.mean(dim=0).clamp(0.0, 1.0)
    vals = ref_gray[ref_gray > 0]
    ref_percentile = getattr(args, "target_mask_visibility_refiner_percentile", 90.0)
    ref_percentile = 90.0 if ref_percentile is None else float(ref_percentile)
    ref_quantile = min(max(ref_percentile / 100.0, 0.0), 1.0)
    threshold = float(getattr(args, "target_mask_threshold", 0.08) or 0.08)
    if int(vals.numel()) > 0:
        threshold = max(threshold, float(torch.quantile(vals, ref_quantile).item()))
    refiner_mask = (ref_gray >= threshold).float()
    min_pixels = float(getattr(args, "target_mask_min_pixels", 16.0) or 16.0)
    if float(refiner_mask.sum()) < min_pixels and int(vals.numel()) > 0:
        refiner_mask = (ref_gray >= torch.quantile(vals, 0.15)).float()
    visible_dilate = max(int(getattr(args, "target_mask_visibility_dilate", 2) or 0), 0)
    visible_mask = _dilate01_batch(core_mask[None], visible_dilate)[0] if visible_dilate > 0 else core_mask
    residual = (refiner_mask * (1.0 - visible_mask)).clamp(0.0, 1.0)
    return {
        "core_mask": core_mask.clamp(0.0, 1.0),
        "refiner_mask": refiner_mask.clamp(0.0, 1.0),
        "visible_mask": visible_mask.clamp(0.0, 1.0),
        "residual_layover_mask": residual.clamp(0.0, 1.0),
    }


def _cleanup_residual_layover(image: torch.Tensor, residual_mask: torch.Tensor, args) -> torch.Tensor:
    strength = min(max(float(getattr(args, "residual_layover_cleanup_strength", 0.0) or 0.0), 0.0), 1.0)
    if strength <= 0.0 or float(residual_mask.sum()) <= 0.0:
        return image
    ceiling = min(max(float(getattr(args, "residual_layover_cleanup_ceiling", 0.045) or 0.045), 0.0), 1.0)
    blur = max(int(getattr(args, "residual_layover_cleanup_blur", 1) or 0), 0)
    mask = residual_mask.clamp(0.0, 1.0)
    if blur > 0:
        mask = (_blur01(mask, blur) * residual_mask.clamp(0.0, 1.0)).clamp(0.0, 1.0)
    mask3 = mask[None]
    ceiling_img = torch.minimum(image, image.new_tensor(ceiling))
    return (image * (1.0 - mask3 * strength) + ceiling_img * (mask3 * strength)).clamp(0.0, 1.0)


def _largest_connected_component(mask: torch.Tensor) -> torch.Tensor:
    try:
        from scipy import ndimage
    except Exception:
        return mask.float().clamp(0.0, 1.0)
    arr = mask.detach().float().cpu().numpy() > 0.5
    labeled, num = ndimage.label(arr, structure=np.ones((3, 3), dtype=np.uint8))
    if num <= 0:
        return torch.zeros_like(mask)
    sizes = ndimage.sum(arr, labeled, index=np.arange(1, num + 1))
    keep = int(np.argmax(sizes)) + 1
    out = (labeled == keep).astype(np.float32)
    return torch.from_numpy(out).to(device=mask.device, dtype=mask.dtype).clamp(0.0, 1.0)


def _erode01(mask: torch.Tensor, radius: int) -> torch.Tensor:
    if radius <= 0:
        return mask.float().clamp(0.0, 1.0)
    inv = (1.0 - mask.float().clamp(0.0, 1.0)).clamp(0.0, 1.0)
    return (1.0 - _dilate01_batch(inv[None], radius)[0]).clamp(0.0, 1.0)


def _target_shadow_overlap_candidate(target: torch.Tensor, mask: torch.Tensor, args) -> torch.Tensor:
    if not bool(getattr(args, "shadow_include_target", False)):
        return torch.zeros_like(mask)
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    target = mask.float().clamp(0.0, 1.0) > 0.5
    vals = gray[target]
    if int(vals.numel()) <= 0:
        return torch.zeros_like(mask)
    quantile = min(max(float(getattr(args, "shadow_target_overlap_quantile", 0.35) or 0.35), 0.0), 1.0)
    threshold = max(float(getattr(args, "shadow_target_overlap_dark_threshold", 0.12) or 0.12), 0.0)
    cutoff = max(threshold, float(torch.quantile(vals, quantile).item()))
    overlap = ((gray <= cutoff) & target).float()
    dilate = max(int(getattr(args, "shadow_target_overlap_dilate", 0) or 0), 0)
    if dilate > 0:
        overlap = _dilate01_batch(overlap[None], dilate)[0] * mask.float().clamp(0.0, 1.0)
    return overlap.clamp(0.0, 1.0)


def _integrated_black_region_mask(target_mask: torch.Tensor, shadow_mask: torch.Tensor, args) -> torch.Tensor:
    """Build one non-background mask from the black area of a background mask.

    The black area is target + shadow.  In joint-mask mode we close/fill it so
    fragmented black islands become one training/application region.
    """
    if not bool(getattr(args, "shadow_joint_mask_refiner", False)):
        return torch.zeros_like(target_mask)
    threshold = min(max(float(getattr(args, "shadow_joint_mask_threshold", 0.05) or 0.05), 0.0), 1.0)
    target = target_mask.float().clamp(0.0, 1.0) > 0.5
    shadow = shadow_mask.float().clamp(0.0, 1.0) > threshold
    black = target | shadow
    if not bool(black.any()):
        return torch.zeros_like(target_mask)

    try:
        from scipy import ndimage

        arr = black.detach().cpu().numpy().astype(bool)
        radius = max(int(getattr(args, "shadow_joint_mask_connect_radius", 12) or 0), 0)
        if radius > 0:
            structure = np.ones((2 * radius + 1, 2 * radius + 1), dtype=bool)
            arr = ndimage.binary_closing(arr, structure=structure, iterations=1)
        arr = ndimage.binary_fill_holes(arr)
        if bool(getattr(args, "shadow_joint_mask_bbox_fill", True)):
            ys, xs = np.where(arr)
            if ys.size > 0:
                arr[int(ys.min()) : int(ys.max()) + 1, int(xs.min()) : int(xs.max()) + 1] = True
        dilate = max(int(getattr(args, "shadow_joint_mask_dilate", 0) or 0), 0)
        if dilate > 0:
            arr = ndimage.binary_dilation(arr, structure=np.ones((3, 3), dtype=bool), iterations=dilate)
        return torch.from_numpy(arr.astype(np.float32)).to(device=target_mask.device, dtype=target_mask.dtype).clamp(0.0, 1.0)
    except Exception:
        out = black.float().clamp(0.0, 1.0)
        radius = max(int(getattr(args, "shadow_joint_mask_connect_radius", 12) or 0), 0)
        if radius > 0:
            out = _dilate01_batch(out[None], radius)[0]
            inv = _dilate01_batch((1.0 - out).clamp(0.0, 1.0)[None], radius)[0]
            out = (1.0 - inv).clamp(0.0, 1.0)
        if bool(getattr(args, "shadow_joint_mask_bbox_fill", True)):
            ys, xs = torch.where(out > 0.5)
            if int(xs.numel()) > 0:
                filled = torch.zeros_like(out)
                filled[int(ys.min()) : int(ys.max()) + 1, int(xs.min()) : int(xs.max()) + 1] = 1.0
                out = filled
        dilate = max(int(getattr(args, "shadow_joint_mask_dilate", 0) or 0), 0)
        if dilate > 0:
            out = _dilate01_batch(out[None], dilate)[0]
        return out.clamp(0.0, 1.0)


def _gt_anchor_mask(gt: torch.Tensor, fallback_mask: torch.Tensor, args) -> torch.Tensor:
    """Extract a real-GT bright target/layover anchor for shadow supervision."""
    gray = gt.mean(dim=0).clamp(0.0, 1.0)
    fallback_bool = (fallback_mask.float().clamp(0.0, 1.0) > 0.5).float()
    valid = fallback_bool > 0.5
    vals = gray[valid & (gray > 0)]
    quantile = min(max(float(getattr(args, "shadow_gt_anchor_quantile", 0.95) or 0.95), 0.0), 1.0)
    threshold = max(float(getattr(args, "shadow_gt_anchor_threshold", 0.12) or 0.12), 0.0)
    q = torch.quantile(vals, quantile) if int(vals.numel()) > 0 else gray.new_tensor(0.0)
    anchor = ((gray >= max(threshold, float(q.item()))) & valid).float()
    min_pixels = float(getattr(args, "shadow_gt_anchor_min_pixels", 12.0) or 12.0)
    if float(anchor.sum()) < min_pixels and int(vals.numel()) > 0:
        loose_q = min(max(float(getattr(args, "shadow_gt_anchor_fallback_quantile", 0.90) or 0.90), 0.0), 1.0)
        anchor = ((gray >= max(threshold * 0.5, float(torch.quantile(vals, loose_q).item()))) & valid).float()
    anchor = (anchor > 0.05).float()
    dilate = max(int(getattr(args, "shadow_gt_anchor_dilate", 2) or 0), 0)
    if dilate > 0:
        anchor = _dilate01_batch(anchor[None], dilate)[0] * fallback_bool
    return anchor.clamp(0.0, 1.0)


def _direction_maps(mask: torch.Tensor, azimuth_deg: float, args) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    length = max(int(getattr(args, "shadow_candidate_length", 48) or 48), 1)
    decay = max(float(getattr(args, "shadow_candidate_decay", 22.0) or 22.0), 1e-6)
    lateral_blur = max(int(getattr(args, "shadow_candidate_lateral_blur", 5) or 0), 0)
    offset = float(getattr(args, "shadow_direction_offset_deg", 180.0) or 0.0)
    sign = float(getattr(args, "shadow_direction_sign", 1.0) or 1.0)
    rad = math.radians((float(azimuth_deg) + offset) % 360.0)
    dx = int(round(math.cos(rad) * sign))
    dy = int(round(math.sin(rad) * sign))
    if dx == 0 and dy == 0:
        dx = 1
    hmask = mask.float().clamp(0.0, 1.0)
    protect = int(getattr(args, "shadow_target_protect_dilate", 1) or 0)
    block = _dilate01_batch(hmask[None], protect)[0] if protect > 0 else hmask
    accum = torch.zeros_like(hmask)
    dist = torch.zeros_like(hmask)
    weight = torch.zeros_like(hmask)
    for step in range(1, length + 1):
        shifted = torch.roll(hmask, shifts=(dy * step, dx * step), dims=(-2, -1))
        if dy > 0:
            shifted[: dy * step, :] = 0
        elif dy < 0:
            shifted[dy * step :, :] = 0
        if dx > 0:
            shifted[:, : dx * step] = 0
        elif dx < 0:
            shifted[:, dx * step :] = 0
        w = math.exp(-float(step) / decay)
        candidate_step = shifted * w
        better = candidate_step > accum
        accum = torch.maximum(accum, candidate_step)
        dist = torch.where(better, dist.new_tensor(float(step) / float(length)), dist)
        weight = torch.maximum(weight, shifted)
    if lateral_blur > 0:
        accum = _blur01(accum, lateral_blur)
        weight = _blur01(weight, lateral_blur)
    candidate = (accum * (1.0 - block)).clamp(0.0, 1.0)
    distance = (dist * (candidate > 0).float()).clamp(0.0, 1.0)
    support = (weight * (1.0 - block)).clamp(0.0, 1.0)
    return candidate, distance, support


def _fixed_shadow_direction_deg(azimuth_deg: float, args) -> float:
    direction = getattr(args, "_shadow_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "shadow_gt_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "shadow_pred_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "shadow_fixed_direction_deg", None)
    if direction is None:
        direction = float(azimuth_deg) + float(getattr(args, "shadow_direction_offset_deg", 180.0) or 0.0)
    return float(direction) % 360.0


def _dataset_shadow_direction_deg(azimuth_deg: float | None, args) -> tuple[float | None, bool]:
    for key in (
        "_shadow_global_direction_deg",
        "shadow_gt_global_direction_deg",
        "shadow_pred_global_direction_deg",
        "shadow_fixed_direction_deg",
    ):
        direction = getattr(args, key, None)
        if direction is not None:
            return float(direction) % 360.0, True
    if bool(getattr(args, "shadow_geometry_extent_require_dataset_direction", True)):
        return None, False
    if azimuth_deg is None:
        return None, False
    return _fixed_shadow_direction_deg(float(azimuth_deg), args), False


def _shadow_geometry_extent_gate(target_mask: torch.Tensor, azimuth_deg: float | None, args) -> torch.Tensor:
    if not bool(getattr(args, "shadow_geometry_extent_gate", True)):
        return torch.ones_like(target_mask).float()
    direction, _has_dataset_direction = _dataset_shadow_direction_deg(azimuth_deg, args)
    if direction is None:
        return torch.ones_like(target_mask).float()

    mask = target_mask.float().clamp(0.0, 1.0)
    ys, xs = torch.where(mask > 0.5)
    if int(xs.numel()) <= 0:
        return torch.ones_like(mask)

    h, w = mask.shape[-2:]
    yy = torch.arange(h, device=mask.device, dtype=mask.dtype)[:, None].expand(h, w)
    xx = torch.arange(w, device=mask.device, dtype=mask.dtype)[None, :].expand(h, w)
    rad = math.radians(float(direction) % 360.0)
    cos_v = math.cos(rad)
    sin_v = math.sin(rad)
    target_x = xs.to(device=mask.device, dtype=mask.dtype)
    target_y = ys.to(device=mask.device, dtype=mask.dtype)
    target_along = target_x * cos_v + target_y * sin_v
    target_perp = -target_x * sin_v + target_y * cos_v
    along_min = target_along.min()
    along_max = target_along.max()
    perp_min = target_perp.min()
    perp_max = target_perp.max()
    along_extent = (along_max - along_min).clamp_min(1.0)
    perp_extent = (perp_max - perp_min).clamp_min(1.0)

    along = xx * cos_v + yy * sin_v
    perp = -xx * sin_v + yy * cos_v
    forward_scale = max(float(getattr(args, "shadow_geometry_extent_forward_scale", 1.0) or 1.0), 0.0)
    lateral_scale = max(float(getattr(args, "shadow_geometry_extent_lateral_scale", 1.0) or 1.0), 0.0)
    margin = max(float(getattr(args, "shadow_geometry_extent_margin_px", 1.5) or 0.0), 0.0)
    min_forward = max(float(getattr(args, "shadow_geometry_extent_min_forward_px", 0.0) or 0.0), 0.0)
    max_along = along_max + along_extent * forward_scale + margin
    perp_center = (perp_min + perp_max) * 0.5
    half_perp = perp_extent * lateral_scale * 0.5 + margin
    gate = (
        (along >= along_max + min_forward)
        & (along <= max_along)
        & (torch.abs(perp - perp_center) <= half_perp)
    )
    gate = gate & ~(mask > 0.5)
    return gate.float().clamp(0.0, 1.0)


def _fixed_direction_maps(mask: torch.Tensor, azimuth_deg: float, args) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    fixed = _fixed_shadow_direction_deg(azimuth_deg, args)
    offset = float(getattr(args, "shadow_direction_offset_deg", 180.0) or 0.0)
    proxy_azimuth = (fixed - offset) % 360.0
    return _direction_maps(mask, proxy_azimuth, args)


def _omni_shadow_maps(mask: torch.Tensor, args) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    length = max(int(getattr(args, "shadow_candidate_length", 58) or 58), 1)
    decay = max(float(getattr(args, "shadow_candidate_decay", 24.0) or 24.0), 1e-6)
    protect = int(getattr(args, "shadow_target_protect_dilate", 1) or 0)
    hmask = mask.float().clamp(0.0, 1.0)
    block = _dilate01_batch(hmask[None], protect)[0] if protect > 0 else hmask
    frontier = block
    candidate = torch.zeros_like(hmask)
    distance = torch.zeros_like(hmask)
    support = torch.zeros_like(hmask)
    for step in range(1, length + 1):
        grown = _dilate01_batch(frontier[None], 1)[0]
        ring = (grown - frontier).clamp(0.0, 1.0)
        w = math.exp(-float(step) / decay)
        candidate = torch.maximum(candidate, ring * w)
        distance = torch.where(ring > 0.0, distance.new_tensor(float(step) / float(length)), distance)
        support = torch.maximum(support, ring)
        frontier = grown
    return candidate.clamp(0.0, 1.0), distance.clamp(0.0, 1.0), support.clamp(0.0, 1.0)


def _circular_angle_diff_deg(a: float, b: float) -> float:
    return abs((float(a) - float(b) + 180.0) % 360.0 - 180.0)


def _target_bbox_np(target: np.ndarray) -> dict | None:
    ys, xs = np.where(target)
    if ys.size == 0:
        return None
    return {
        "x_min": int(xs.min()),
        "x_max": int(xs.max()),
        "y_min": int(ys.min()),
        "y_max": int(ys.max()),
        "center_x": float(xs.mean()),
        "center_y": float(ys.mean()),
        "width": float(xs.max() - xs.min() + 1),
        "height": float(ys.max() - ys.min() + 1),
        "area": float(target.sum()),
    }


def _mask_direction_deg(mask: torch.Tensor, target_mask: torch.Tensor) -> tuple[float | None, float]:
    m = mask.detach().float().cpu().numpy() > 0.05
    t = target_mask.detach().float().cpu().numpy() > 0.5
    geom = _target_bbox_np(t)
    ys, xs = np.where(m)
    if geom is None or ys.size == 0:
        return None, 0.0
    dx = xs.astype(np.float32) - float(geom["center_x"])
    dy = ys.astype(np.float32) - float(geom["center_y"])
    direction = (math.degrees(math.atan2(float(dy.mean()), float(dx.mean()))) + 360.0) % 360.0
    return float(direction), float(ys.size)


def _weighted_circular_mean_deg(items: list[tuple[float | None, float]]) -> float | None:
    mean, _concentration, _total = _weighted_circular_stats_deg(items)
    return mean


def _weighted_circular_stats_deg(items: list[tuple[float | None, float]]) -> tuple[float | None, float, float]:
    sx = 0.0
    sy = 0.0
    total = 0.0
    for angle, weight in items:
        if angle is None or weight <= 0:
            continue
        rad = math.radians(float(angle))
        sx += math.cos(rad) * float(weight)
        sy += math.sin(rad) * float(weight)
        total += float(weight)
    if total <= 0.0:
        return None, 0.0, 0.0
    mean = (math.degrees(math.atan2(sy, sx)) + 360.0) % 360.0
    concentration = math.sqrt(sx * sx + sy * sy) / max(total, 1e-6)
    return mean, concentration, total


def _connected_shadow_component_mask(
    evidence: torch.Tensor,
    target_mask: torch.Tensor,
    search_mask: torch.Tensor,
    args,
    *,
    prefix: str = "shadow_gt",
    seed_mask: torch.Tensor | None = None,
) -> torch.Tensor:
    """Select SAR-shadow-like connected dark regions instead of a target ring."""
    if not bool(getattr(args, f"{prefix}_component_filter", True)):
        return search_mask.clamp(0.0, 1.0)
    try:
        from scipy import ndimage
    except Exception:
        return search_mask.clamp(0.0, 1.0)

    device = evidence.device
    ev = evidence.detach().float().clamp(0.0, 1.0).cpu().numpy()
    tgt = target_mask.detach().float().cpu().numpy() > 0.5
    search = search_mask.detach().float().cpu().numpy() > 0.05
    seed = None
    if seed_mask is not None:
        seed = seed_mask.detach().float().cpu().numpy() > 0.5
    geom = _target_bbox_np(tgt)
    if geom is None or not np.any(search):
        return torch.zeros_like(evidence)

    threshold = float(getattr(args, f"{prefix}_component_threshold", 0.22) or 0.22)
    threshold = min(max(threshold, 1e-4), 1.0)
    pool = ((seed if seed is not None else (ev >= threshold)) & search & ~tgt)
    density_radius = max(int(getattr(args, f"{prefix}_component_density_radius", 2) or 0), 0)
    min_density = min(max(float(getattr(args, f"{prefix}_component_min_density", 0.22) or 0.0), 0.0), 1.0)
    if seed is None and density_radius > 0 and min_density > 0.0:
        size = 2 * density_radius + 1
        density = ndimage.uniform_filter(pool.astype(np.float32), size=size, mode="constant", cval=0.0)
        pool = pool & (density >= min_density)
    open_iter = max(int(getattr(args, f"{prefix}_component_open", 0) or 0), 0)
    if seed is None and open_iter > 0:
        pool = ndimage.binary_opening(pool, structure=np.ones((3, 3), dtype=bool), iterations=open_iter)
    if not np.any(pool):
        return torch.zeros_like(evidence)

    labeled, num = ndimage.label(pool, structure=np.ones((3, 3), dtype=np.uint8))
    if num <= 0:
        return torch.zeros_like(evidence)

    target_area = max(float(geom["area"]), 1.0)
    min_ratio = max(float(getattr(args, f"{prefix}_min_component_area_ratio", 0.08) or 0.08), 0.0)
    max_ratio = max(float(getattr(args, f"{prefix}_max_component_area_ratio", 2.5) or 2.5), min_ratio + 1e-6)
    min_px = max(float(getattr(args, f"{prefix}_min_component_pixels", 8.0) or 8.0), min_ratio * target_area)
    score_min = float(getattr(args, f"{prefix}_component_score_min", 0.34) or 0.34)
    max_components = max(int(getattr(args, f"{prefix}_max_components", 1) or 1), 1)
    direction_tol = max(float(getattr(args, f"{prefix}_direction_tolerance_deg", 55.0) or 55.0), 1.0)
    global_direction = getattr(args, f"{prefix}_global_direction_deg", None)
    if global_direction is None:
        global_direction = getattr(args, "_shadow_global_direction_deg", None)
    global_direction_tol = max(
        float(getattr(args, f"{prefix}_global_direction_tolerance_deg", direction_tol) or direction_tol),
        1.0,
    )
    contact_iter = max(int(getattr(args, f"{prefix}_contact_dilate", 4) or 4), 1)
    min_bbox_density = min(max(float(getattr(args, f"{prefix}_component_min_bbox_density", 0.12) or 0.0), 0.0), 1.0)
    contact_band = ndimage.binary_dilation(tgt, structure=np.ones((3, 3), dtype=bool), iterations=contact_iter)
    dist_to_target = ndimage.distance_transform_edt(~tgt)
    tx_min, tx_max = int(geom["x_min"]), int(geom["x_max"])
    ty_min, ty_max = int(geom["y_min"]), int(geom["y_max"])
    target_w = max(float(geom["width"]), 1.0)
    target_h = max(float(geom["height"]), 1.0)

    comps: list[tuple[float, float, int, np.ndarray]] = []
    for label_id in range(1, num + 1):
        region = labeled == label_id
        area = float(region.sum())
        if area < min_px:
            continue
        area_ratio = area / target_area
        if area_ratio > max_ratio:
            continue
        ys, xs = np.where(region)
        if ys.size == 0:
            continue
        sx_min, sx_max = int(xs.min()), int(xs.max())
        sy_min, sy_max = int(ys.min()), int(ys.max())
        bbox_area = max(float((sx_max - sx_min + 1) * (sy_max - sy_min + 1)), 1.0)
        bbox_density = area / bbox_area
        if bbox_density < min_bbox_density:
            continue

        left = sx_max < tx_min
        right = sx_min > tx_max
        above = sy_max < ty_min
        below = sy_min > ty_max
        crosses_x = sx_min <= tx_min and sx_max >= tx_max
        crosses_y = sy_min <= ty_min and sy_max >= ty_max
        side_count = int(left) + int(right) + int(above) + int(below)
        if side_count >= 3 or (crosses_x and crosses_y):
            continue

        min_dist = float(dist_to_target[region].min())
        near_score = math.exp(-min_dist / max(3.0, 0.35 * max(target_w, target_h)))
        contact_score = min(1.0, float((region & contact_band).sum()) / max(3.0, 0.08 * math.sqrt(target_area)))
        overlap_x = max(0.0, float(min(sx_max, tx_max) - max(sx_min, tx_min) + 1)) / target_w
        overlap_y = max(0.0, float(min(sy_max, ty_max) - max(sy_min, ty_min) + 1)) / target_h
        axis_score = min(1.0, max(overlap_x, overlap_y))
        band_margin_x = 0.35 * target_w
        band_margin_y = 0.35 * target_h
        band_x = max(0.0, float(min(sx_max, tx_max + band_margin_x) - max(sx_min, tx_min - band_margin_x) + 1))
        band_y = max(0.0, float(min(sy_max, ty_max + band_margin_y) - max(sy_min, ty_min - band_margin_y) + 1))
        band_score = max(
            min(1.0, band_x / max(float(sx_max - sx_min + 1), 1.0)),
            min(1.0, band_y / max(float(sy_max - sy_min + 1), 1.0)),
        )
        if area_ratio <= 1.0:
            area_score = min(1.0, area_ratio / max(min_ratio, 1e-6))
        else:
            area_score = max(0.0, 1.0 - (area_ratio - 1.0) / max(max_ratio - 1.0, 1e-6))
        dark_score = float(ev[region].mean())
        dx = xs.astype(np.float32) - float(geom["center_x"])
        dy = ys.astype(np.float32) - float(geom["center_y"])
        ang = np.arctan2(dy, dx)
        concentration = float(np.hypot(np.cos(ang).mean(), np.sin(ang).mean()))
        direction_deg = (math.degrees(math.atan2(float(dy.mean()), float(dx.mean()))) + 360.0) % 360.0
        direction_score = 1.0
        if global_direction is not None:
            diff = _circular_angle_diff_deg(direction_deg, float(global_direction))
            if diff > global_direction_tol:
                continue
            direction_score = max(0.0, 1.0 - diff / max(global_direction_tol, 1e-6))

        score = (
            0.24 * near_score
            + 0.22 * contact_score
            + 0.14 * axis_score
            + 0.12 * band_score
            + 0.10 * area_score
            + 0.08 * dark_score
            + 0.08 * concentration
            + 0.02 * min(1.0, bbox_density / max(min_bbox_density, 1e-6))
            + 0.08 * direction_score
        )
        if (left and right) or (above and below):
            score *= 0.35
        if concentration < 0.25 and area_ratio > 0.4:
            score *= 0.35
        if near_score < 0.18 and contact_score <= 0.0:
            score *= 0.25
        comps.append((float(score), float(direction_deg), int(area), region))

    if not comps:
        return torch.zeros_like(evidence)

    comps.sort(key=lambda x: (x[0], x[2]), reverse=True)
    selected = np.zeros_like(pool, dtype=bool)
    best_score, best_dir, _best_area, _ = comps[0]
    selected_count = 0
    for score, direction, _area, region in comps:
        if score < score_min and selected.any():
            continue
        if score < score_min * 0.75 and not selected.any():
            continue
        if selected.any() and _circular_angle_diff_deg(direction, best_dir) > direction_tol:
            continue
        selected |= region
        selected_count += 1
        if selected_count >= max_components:
            break

    if not np.any(selected):
        return torch.zeros_like(evidence)
    grow_iter = max(int(getattr(args, f"{prefix}_component_grow", 0) or 0), 0)
    if grow_iter > 0:
        grow_threshold = float(getattr(args, f"{prefix}_component_grow_threshold", threshold * 0.70) or (threshold * 0.70))
        grown = ndimage.binary_dilation(selected, structure=np.ones((3, 3), dtype=bool), iterations=grow_iter)
        selected = grown & (ev >= max(1e-4, grow_threshold)) & search & ~tgt
        labeled_sel, num_sel = ndimage.label(selected, structure=np.ones((3, 3), dtype=np.uint8))
        if num_sel > 1:
            sizes = ndimage.sum(selected, labeled_sel, index=np.arange(1, num_sel + 1))
            keep_label = int(np.argmax(sizes)) + 1
            selected = labeled_sel == keep_label
    out = torch.from_numpy(selected.astype(np.float32)).to(device=device, dtype=evidence.dtype)
    return out.clamp(0.0, 1.0)


def _shadow_gt_from_gt(gt: torch.Tensor, target_mask: torch.Tensor, candidate: torch.Tensor, args) -> torch.Tensor:
    gray = gt.mean(dim=0).clamp(0.0, 1.0)
    context_blur = int(getattr(args, "shadow_gt_context_blur", 21) or 0)
    context = _blur01(gray, context_blur).clamp_min(1e-4) if context_blur > 0 else gray.mean().clamp_min(1e-4)
    dark_threshold = max(float(getattr(args, "shadow_gt_dark_threshold", 0.18) or 0.18), 1e-6)
    ratio_threshold = max(float(getattr(args, "shadow_gt_ratio_threshold", 0.16) or 0.16), 1e-6)
    absolute = ((dark_threshold - gray) / dark_threshold).clamp(0.0, 1.0)
    relative = ((context - gray) / ratio_threshold).clamp(0.0, 1.0)
    ratio_mix = min(max(float(getattr(args, "shadow_gt_ratio_mix", 0.70) or 0.70), 0.0), 1.0)
    evidence = (absolute * (1.0 - ratio_mix) + relative * ratio_mix).clamp(0.0, 1.0)
    search_dilate = max(int(getattr(args, "shadow_search_dilate", 55) or 55), 1)
    exclude = max(int(getattr(args, "shadow_target_exclude_dilate", 1) or 0), 0)
    search = _dilate01_batch(target_mask[None], search_dilate)[0]
    block = _dilate01_batch(target_mask[None], exclude)[0] if exclude > 0 else target_mask
    search = (search * (1.0 - block)).clamp(0.0, 1.0)
    fixed_gate = None
    if bool(getattr(args, "shadow_gt_use_fixed_direction_gate", False)):
        fixed_gate = _fixed_direction_gate_mask(target_mask, args)
        search = (search * fixed_gate).clamp(0.0, 1.0)
    gate_mix = min(max(float(getattr(args, "shadow_candidate_supervision_mix", 0.85) or 0.85), 0.0), 1.0)
    gate = (candidate.clamp(0.0, 1.0) * gate_mix + search * (1.0 - gate_mix)).clamp(0.0, 1.0)
    if fixed_gate is not None:
        gate = (gate * fixed_gate).clamp(0.0, 1.0)
    low_percentile = min(max(float(getattr(args, "shadow_gt_low_percentile", 5.0) or 5.0), 0.0), 100.0)
    valid_dark = (gate > 0.05) & (target_mask <= 0.5)
    vals = gray[valid_dark]
    if int(vals.numel()) > 0:
        cut = torch.quantile(vals, low_percentile / 100.0)
        low_seed = ((gray <= cut) & valid_dark).float()
        min_seed_evidence = float(getattr(args, "shadow_gt_low_seed_min_evidence", 0.0) or 0.0)
        if min_seed_evidence > 0.0:
            low_seed = low_seed * (evidence >= min_seed_evidence).float()
    else:
        low_seed = torch.zeros_like(gray)
    pre_component_gate = gate
    component_gate = _connected_shadow_component_mask(evidence, target_mask, gate, args, prefix="shadow_gt", seed_mask=low_seed)
    if bool(getattr(args, "shadow_gt_component_filter", True)):
        # Component filtering is a cleanup step, not a license to erase all
        # supervision.  If it fails to find a component, keep the soft candidate
        # gate so the refiner does not learn an all-empty shadow target.
        gate = component_gate if float(component_gate.sum()) > 0.0 else pre_component_gate
    soft = int(getattr(args, "shadow_gt_soft_blur", 1) or 0)
    out = evidence * gate
    if bool(getattr(args, "shadow_gt_fixed_direction_fallback", False)) and float(out.sum()) <= 1e-6:
        fallback_gate = _fixed_direction_shadow_fallback(evidence, target_mask, gray, args)
        if float(fallback_gate.sum()) > 0.0:
            out = evidence * fallback_gate
            gate = fallback_gate
    if soft > 0:
        out = _blur01(out, soft) * gate
    gamma = max(float(getattr(args, "shadow_gt_gamma", 1.0) or 1.0), 0.05)
    return out.clamp(0.0, 1.0).pow(gamma)


def _joint_shadow_target_from_gt(
    source: torch.Tensor,
    gt: torch.Tensor,
    shadow_target: torch.Tensor,
    joint_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    if not bool(getattr(args, "shadow_joint_mask_refiner", False)) or float(joint_mask.sum()) <= 0.0:
        return shadow_target.clamp(0.0, 1.0)
    scale = float(getattr(args, "log_scale", 20.0) or 20.0)
    src_ld = _ld(source.mean(dim=0, keepdim=True).clamp(0.0, 1.0), scale)[0]
    gt_ld = _ld(gt.mean(dim=0, keepdim=True).clamp(0.0, 1.0), scale)[0]
    min_gap = max(float(getattr(args, "shadow_joint_target_min_gap", 0.015) or 0.0), 0.0)
    softness = max(float(getattr(args, "shadow_joint_target_softness", 0.10) or 0.10), 1e-6)
    darken_need = ((src_ld - gt_ld - min_gap) / softness).clamp(0.0, 1.0)
    mix = min(max(float(getattr(args, "shadow_joint_target_mix", 1.0) or 1.0), 0.0), 1.0)
    joint_target = torch.maximum(shadow_target, darken_need * mix).clamp(0.0, 1.0)
    joint_target = joint_target * joint_mask.float().clamp(0.0, 1.0)
    blur = max(int(getattr(args, "shadow_joint_target_blur", 1) or 0), 0)
    if blur > 0:
        joint_target = _blur01(joint_target, blur) * joint_mask.float().clamp(0.0, 1.0)
    return joint_target.clamp(0.0, 1.0)


def _source_to_gt_shadow_target(
    source: torch.Tensor,
    gt: torch.Tensor,
    train_mask: torch.Tensor,
    args,
) -> torch.Tensor:
    scale = float(getattr(args, "log_scale", 20.0) or 20.0)
    src_ld = _ld(source.mean(dim=0, keepdim=True).clamp(0.0, 1.0), scale)[0]
    gt_ld = _ld(gt.mean(dim=0, keepdim=True).clamp(0.0, 1.0), scale)[0]
    min_gap = max(float(getattr(args, "shadow_source_gt_min_gap", 0.010) or 0.0), 0.0)
    softness = max(float(getattr(args, "shadow_source_gt_softness", 0.10) or 0.10), 1e-6)
    target = ((src_ld - gt_ld - min_gap) / softness).clamp(0.0, 1.0)
    target = target * train_mask.float().clamp(0.0, 1.0)
    blur = max(int(getattr(args, "shadow_source_gt_blur", 1) or 0), 0)
    if blur > 0:
        target = _blur01(target, blur) * train_mask.float().clamp(0.0, 1.0)
    gamma = max(float(getattr(args, "shadow_source_gt_gamma", 1.0) or 1.0), 0.05)
    return target.clamp(0.0, 1.0).pow(gamma)


def _training_mask_from_maps(
    target_mask: torch.Tensor,
    candidate: torch.Tensor,
    support: torch.Tensor,
    gt_anchor: torch.Tensor,
    gt_shadow: torch.Tensor,
    args,
) -> torch.Tensor:
    mode = str(getattr(args, "shadow_train_mask_mode", "support") or "support").lower().strip()
    threshold = min(max(float(getattr(args, "shadow_train_mask_threshold", 0.01) or 0.01), 0.0), 1.0)
    if mode == "candidate":
        mask = candidate.float().clamp(0.0, 1.0)
    elif mode == "candidate_hard":
        mask = (candidate.float().clamp(0.0, 1.0) > threshold).float()
    elif mode == "gt_background_black":
        _rgb, bg = _region_classification_rgb(gt_anchor, gt_shadow)
        mask = (1.0 - bg[0]).clamp(0.0, 1.0)
    elif mode == "candidate_gt_background_black":
        _rgb, bg = _region_classification_rgb(gt_anchor, gt_shadow)
        mask = torch.maximum(candidate.float().clamp(0.0, 1.0), (1.0 - bg[0]).clamp(0.0, 1.0))
    else:
        mask = torch.maximum((support > threshold).float(), (gt_shadow > 0.005).float())
    dilate = max(int(getattr(args, "shadow_train_mask_dilate", 0) or 0), 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    return mask.clamp(0.0, 1.0) * (1.0 - target_mask.float().clamp(0.0, 1.0) * 0.0)


def _fixed_direction_gate_mask(target_mask: torch.Tensor, args) -> torch.Tensor:
    direction = getattr(args, "shadow_gt_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "_shadow_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "shadow_fixed_direction_deg", None)
    if direction is None:
        return torch.ones_like(target_mask).float()

    mask = target_mask.float().clamp(0.0, 1.0)
    ys, xs = torch.where(mask > 0.5)
    if int(xs.numel()) == 0:
        return torch.ones_like(mask)

    cx = xs.float().mean()
    cy = ys.float().mean()
    h, w = mask.shape[-2:]
    yy = torch.arange(h, device=mask.device, dtype=mask.dtype)[:, None].expand(h, w)
    xx = torch.arange(w, device=mask.device, dtype=mask.dtype)[None, :].expand(h, w)
    dx = xx - cx
    dy = yy - cy
    rad = math.radians(float(direction) % 360.0)
    cos_v = math.cos(rad)
    sin_v = math.sin(rad)
    along = dx * cos_v + dy * sin_v
    perp = torch.abs(-dx * sin_v + dy * cos_v)
    dist = torch.sqrt(dx * dx + dy * dy).clamp_min(1e-6)
    angle_diff = torch.rad2deg(torch.atan2(perp, along.clamp_min(1e-6)))

    tol = max(float(getattr(args, "shadow_gt_fixed_direction_gate_tolerance_deg", 28.0) or 28.0), 1.0)
    max_dist = max(float(getattr(args, "shadow_search_dilate", 65) or 65), 1.0)
    min_dist = max(float(getattr(args, "shadow_gt_fixed_direction_gate_min_dist", 1.0) or 0.0), 0.0)
    max_width = float(getattr(args, "shadow_gt_fixed_direction_gate_max_width", 0.0) or 0.0)
    gate = (along > min_dist) & (dist <= max_dist) & (angle_diff <= tol)
    if max_width > 0.0:
        gate = gate & (perp <= max_width)
    return gate.float().clamp(0.0, 1.0)


def _fixed_direction_shadow_fallback(
    evidence: torch.Tensor,
    target_mask: torch.Tensor,
    gray: torch.Tensor,
    args,
) -> torch.Tensor:
    """Recover missed GT shadows using the dataset-level shadow side prior."""
    direction = getattr(args, "shadow_gt_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "_shadow_global_direction_deg", None)
    if direction is None:
        direction = getattr(args, "shadow_fixed_direction_deg", None)
    if direction is None:
        return torch.zeros_like(evidence)

    try:
        from scipy import ndimage
    except Exception:
        return torch.zeros_like(evidence)

    tgt = target_mask.detach().float().cpu().numpy() > 0.5
    geom = _target_bbox_np(tgt)
    if geom is None:
        return torch.zeros_like(evidence)

    h, w = tgt.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    dx = xx - float(geom["center_x"])
    dy = yy - float(geom["center_y"])
    dist = np.hypot(dx, dy)
    angles = (np.degrees(np.arctan2(dy, dx)) + 360.0) % 360.0
    diff = np.abs((angles - float(direction) + 180.0) % 360.0 - 180.0)
    tol = max(float(getattr(args, "shadow_gt_fixed_direction_fallback_tolerance_deg", 35.0) or 35.0), 1.0)
    max_dist = max(float(getattr(args, "shadow_search_dilate", 65) or 65), 1.0)
    exclude = max(int(getattr(args, "shadow_target_exclude_dilate", 1) or 0), 0)
    block = ndimage.binary_dilation(tgt, structure=np.ones((3, 3), dtype=bool), iterations=exclude) if exclude > 0 else tgt
    contact = ndimage.binary_dilation(tgt, structure=np.ones((3, 3), dtype=bool), iterations=max(int(getattr(args, "shadow_gt_contact_dilate", 4) or 4), 1))

    ev = evidence.detach().float().clamp(0.0, 1.0).cpu().numpy()
    gr = gray.detach().float().clamp(0.0, 1.0).cpu().numpy()
    band = (diff <= tol) & (dist <= max_dist) & ~block
    vals = gr[band]
    if vals.size == 0:
        return torch.zeros_like(evidence)

    low_percentile = min(max(float(getattr(args, "shadow_gt_low_percentile", 5.0) or 5.0), 0.0), 100.0)
    cut = float(np.percentile(vals, low_percentile))
    threshold = min(max(float(getattr(args, "shadow_gt_fixed_direction_fallback_threshold", 0.10) or 0.10), 1e-4), 1.0)
    pool = band & ((gr <= cut) | (ev >= threshold))
    if not np.any(pool):
        return torch.zeros_like(evidence)

    labeled, num = ndimage.label(pool, structure=np.ones((3, 3), dtype=np.uint8))
    if num <= 0:
        return torch.zeros_like(evidence)

    min_px = max(float(getattr(args, "shadow_gt_min_component_pixels", 8.0) or 8.0), 1.0)
    max_components = max(int(getattr(args, "shadow_gt_fixed_direction_fallback_components", 1) or 1), 1)
    comps: list[tuple[float, int, np.ndarray]] = []
    for label_id in range(1, num + 1):
        region = labeled == label_id
        area = int(region.sum())
        if area < min_px:
            continue
        near = float((region & contact).sum()) / max(float(area), 1.0)
        score = float(ev[region].mean()) + 0.5 * near + min(area / max(float(geom["area"]), 1.0), 1.0) * 0.15
        comps.append((score, area, region))
    if not comps:
        return torch.zeros_like(evidence)

    comps.sort(key=lambda x: (x[0], x[1]), reverse=True)
    selected = np.zeros_like(pool, dtype=bool)
    for _, _, region in comps[:max_components]:
        selected |= region
    grow = max(int(getattr(args, "shadow_gt_fixed_direction_fallback_grow", 1) or 0), 0)
    if grow > 0:
        grown = ndimage.binary_dilation(selected, structure=np.ones((3, 3), dtype=bool), iterations=grow)
        selected = grown & band & ~block & (ev >= max(1e-4, threshold * 0.5))
    return torch.from_numpy(selected.astype(np.float32)).to(device=evidence.device, dtype=evidence.dtype).clamp(0.0, 1.0)


def _shadow_shape_prior_enabled(args) -> bool:
    mode = str(getattr(args, "shadow_shape_prior_mode", "none") or "none").lower().strip()
    return mode not in {"", "none", "off", "disabled"}


def _reference_connected_recognition_enabled(args) -> bool:
    mode = str(getattr(args, "shadow_recognition_source", "candidate") or "candidate").lower().strip()
    return mode in {"reference_connected", "shape_prior"}


def _configure_shadow_shape_prior(args, fallback_gt_dir: str | Path | None) -> None:
    _configure_shadow_semantic_prior(args)
    if not _shadow_shape_prior_enabled(args) and not _reference_connected_recognition_enabled(args):
        setattr(args, "_shadow_shape_prior_candidates", [])
        return
    raw_dir = getattr(args, "shadow_shape_prior_gt_dir", None) or fallback_gt_dir
    if raw_dir is None:
        print("[azimuth shadow] shape prior disabled: missing --train_gt_dir/--shadow_shape_prior_gt_dir")
        setattr(args, "_shadow_shape_prior_candidates", [])
        return
    gt_dir = Path(raw_dir)
    if not gt_dir.exists():
        print(f"[azimuth shadow] shape prior disabled: missing GT dir {gt_dir}")
        setattr(args, "_shadow_shape_prior_candidates", [])
        return
    cands = _candidates(gt_dir)
    setattr(args, "_shadow_shape_prior_candidates", cands)
    print(f"[azimuth shadow] shape prior: {len(cands)} GT images from {gt_dir}")


def _mask_run_dir_from_root(root: Path, run_id: str | None = "latest") -> Path | None:
    if not root.exists():
        return None
    if list(root.glob("*_mask.npy")):
        return root
    if (root / "scattering_masks" / "from_convert").is_dir():
        return _mask_run_dir_from_root(root / "scattering_masks" / "from_convert", run_id)
    if (root / "from_convert").is_dir():
        return _mask_run_dir_from_root(root / "from_convert", run_id)
    if run_id and str(run_id).lower() not in {"", "latest", "none"}:
        candidate = root / str(run_id)
        if candidate.is_dir() and list(candidate.glob("*_mask.npy")):
            return candidate
    latest = root / "latest.json"
    if latest.is_file() and str(run_id or "latest").lower() in {"", "latest"}:
        try:
            meta = json.loads(latest.read_text(encoding="utf-8"))
            candidate = root / str(meta.get("run_id", ""))
            if candidate.is_dir() and list(candidate.glob("*_mask.npy")):
                return candidate
        except Exception:
            pass
    runs = [p for p in sorted(root.iterdir()) if p.is_dir() and list(p.glob("*_mask.npy"))]
    return runs[-1] if runs else None


def _semantic_mask_candidates(mask_dir: Path) -> list[dict]:
    out = []
    for path in sorted(mask_dir.glob("*_mask.npy")):
        stem = path.stem
        if stem.endswith("_mask"):
            stem = stem[: -len("_mask")]
        out.append({"path": path, "stem": stem, "azimuth": _parse_azimuth(Path(stem))})
    return sorted(out, key=lambda item: (float(item["azimuth"]), str(item["path"])))


def _parse_label_list(value: str | int | None, default: tuple[int, ...]) -> tuple[int, ...]:
    if value is None:
        return default
    if isinstance(value, int):
        return (int(value),)
    labels: list[int] = []
    for part in str(value).split(","):
        part = part.strip()
        if not part:
            continue
        labels.append(int(part))
    return tuple(labels) if labels else default


def _semantic_label_coverage_report(cands: list[dict], labels: tuple[int, ...]) -> dict:
    report = {
        "labels": [int(x) for x in labels],
        "masks": int(len(cands)),
        "nonempty_masks": 0,
        "empty_masks": 0,
        "label_pixels_total": 0,
        "label_pixels_mean": 0.0,
        "label_pixels_min": 0,
        "label_pixels_max": 0,
        "empty_samples": [],
    }
    counts: list[int] = []
    for item in cands:
        try:
            arr = np.load(item["path"])
        except Exception:
            count = 0
        else:
            count = int(np.isin(arr, labels).sum())
        counts.append(count)
        if count > 0:
            report["nonempty_masks"] += 1
        elif len(report["empty_samples"]) < 12:
            report["empty_samples"].append(str(item.get("stem", item.get("path", "?"))))
    if counts:
        report["empty_masks"] = int(len(counts) - report["nonempty_masks"])
        report["label_pixels_total"] = int(sum(counts))
        report["label_pixels_mean"] = float(np.mean(counts))
        report["label_pixels_min"] = int(np.min(counts))
        report["label_pixels_max"] = int(np.max(counts))
    return report


def _semantic_shadow_coverage_report(cands: list[dict], label: int) -> dict:
    report = _semantic_label_coverage_report(cands, (int(label),))
    report["label"] = int(label)
    return report


def _configure_shadow_semantic_prior(args) -> None:
    raw = getattr(args, "shadow_semantic_mask_dir", None)
    if not raw:
        setattr(args, "_shadow_semantic_candidates", [])
        setattr(args, "_shadow_semantic_coverage_report", {})
        return
    mask_dir = _mask_run_dir_from_root(Path(raw), getattr(args, "shadow_semantic_mask_run", "latest"))
    if mask_dir is None:
        print(f"[azimuth shadow] semantic masks disabled: no *_mask.npy under {raw}")
        setattr(args, "_shadow_semantic_candidates", [])
        setattr(args, "_shadow_semantic_coverage_report", {})
        return
    cands = _semantic_mask_candidates(mask_dir)
    setattr(args, "_shadow_semantic_candidates", cands)
    setattr(args, "_shadow_semantic_mask_dir_resolved", str(mask_dir))
    label = int(getattr(args, "shadow_semantic_shadow_label", 3) or 3)
    coverage = _semantic_shadow_coverage_report(cands, label)
    target_labels = _parse_label_list(getattr(args, "shadow_semantic_target_labels", "1,2"), (1, 2))
    target_coverage = _semantic_label_coverage_report(cands, target_labels)
    setattr(args, "_shadow_semantic_coverage_report", coverage)
    setattr(args, "_target_semantic_coverage_report", target_coverage)
    print(f"[azimuth shadow] semantic shadow masks: {len(cands)} masks from {mask_dir}")
    if coverage["masks"] > 0:
        ratio = coverage["nonempty_masks"] / max(float(coverage["masks"]), 1.0)
        print(
            "[azimuth shadow] semantic label coverage: "
            f"label={label}, nonempty={coverage['nonempty_masks']}/{coverage['masks']} "
            f"({ratio*100.0:.1f}%), pixels_mean={coverage['label_pixels_mean']:.1f}, "
            f"empty_samples={coverage['empty_samples'][:6]}"
        )
        target_ratio = target_coverage["nonempty_masks"] / max(float(target_coverage["masks"]), 1.0)
        print(
            "[azimuth shadow] semantic target coverage: "
            f"labels={list(target_labels)}, nonempty={target_coverage['nonempty_masks']}/{target_coverage['masks']} "
            f"({target_ratio*100.0:.1f}%), pixels_mean={target_coverage['label_pixels_mean']:.1f}, "
            f"empty_samples={target_coverage['empty_samples'][:6]}"
        )


def _load_semantic_label_mask(
    item: dict,
    size_hw: tuple[int, int],
    args,
    device: torch.device,
    *,
    labels: tuple[int, ...],
    dilate: int = 0,
    blur: int = 0,
) -> torch.Tensor:
    arr = np.load(item["path"])
    mask = torch.from_numpy(np.isin(arr, labels).astype(np.float32))[None, None].to(device=device)
    if tuple(mask.shape[-2:]) != tuple(size_hw):
        mask = F.interpolate(mask, size=size_hw, mode="nearest")
    out = mask[0, 0].clamp(0.0, 1.0)
    dilate = max(int(dilate or 0), 0)
    if dilate > 0:
        out = _dilate01_batch(out[None], dilate)[0]
    blur = max(int(blur or 0), 0)
    if blur > 0:
        out = _blur01(out, blur)
    return out.clamp(0.0, 1.0)


def _load_semantic_shadow_mask(item: dict, size_hw: tuple[int, int], args, device: torch.device) -> torch.Tensor:
    label = int(getattr(args, "shadow_semantic_shadow_label", 3) or 3)
    return _load_semantic_label_mask(
        item,
        size_hw,
        args,
        device,
        labels=(label,),
        dilate=max(int(getattr(args, "shadow_semantic_dilate", 0) or 0), 0),
        blur=max(int(getattr(args, "shadow_semantic_blur", 0) or 0), 0),
    )


def _semantic_gt_region_masks(
    azimuth: float,
    size_hw: tuple[int, int],
    args,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor]:
    cands = list(getattr(args, "_shadow_semantic_candidates", []) or [])
    empty = torch.zeros(size_hw, device=device, dtype=torch.float32)
    if not cands:
        return empty, empty
    lo, hi, wlo, whi = _bracket(cands, float(azimuth))
    items = [(lo, float(wlo))]
    if Path(hi["path"]) != Path(lo["path"]) and float(whi) > 0.0:
        items.append((hi, float(whi)))
    target_labels = _parse_label_list(getattr(args, "shadow_semantic_target_labels", "1,2"), (1, 2))
    shadow_label = int(getattr(args, "shadow_semantic_shadow_label", 3) or 3)
    mix_mode = str(getattr(args, "shadow_shape_prior_mix_mode", "weighted_mean") or "weighted_mean").lower().strip()
    target = torch.zeros(size_hw, device=device, dtype=torch.float32)
    shadow = torch.zeros(size_hw, device=device, dtype=torch.float32)
    weight_sum = 0.0
    for item, weight in items:
        if weight <= 0.0:
            continue
        cur_target = _load_semantic_label_mask(item, size_hw, args, device, labels=target_labels) * weight
        cur_shadow = _load_semantic_label_mask(
            item,
            size_hw,
            args,
            device,
            labels=(shadow_label,),
            dilate=max(int(getattr(args, "shadow_semantic_dilate", 0) or 0), 0),
            blur=max(int(getattr(args, "shadow_semantic_blur", 0) or 0), 0),
        ) * weight
        if mix_mode == "weighted_max":
            target = torch.maximum(target, cur_target)
            shadow = torch.maximum(shadow, cur_shadow)
        else:
            target = target + cur_target
            shadow = shadow + cur_shadow
            weight_sum += weight
    if mix_mode != "weighted_max" and weight_sum > 1e-6:
        target = target / weight_sum
        shadow = shadow / weight_sum
    target = target.clamp(0.0, 1.0)
    shadow = (shadow * (1.0 - (target > 0.5).to(dtype=shadow.dtype))).clamp(0.0, 1.0)
    return target, shadow


def _semantic_shadow_prior(
    azimuth: float,
    size_hw: tuple[int, int],
    args,
    device: torch.device,
    *,
    exclude_mask: torch.Tensor | None = None,
) -> torch.Tensor:
    cands = list(getattr(args, "_shadow_semantic_candidates", []) or [])
    if not cands:
        return torch.zeros(size_hw, device=device, dtype=torch.float32)
    lo, hi, wlo, whi = _bracket(cands, float(azimuth))
    items = [(lo, float(wlo))]
    if Path(hi["path"]) != Path(lo["path"]) and float(whi) > 0.0:
        items.append((hi, float(whi)))
    mix_mode = str(getattr(args, "shadow_shape_prior_mix_mode", "weighted_mean") or "weighted_mean").lower().strip()
    prior = torch.zeros(size_hw, device=device, dtype=torch.float32)
    weight_sum = 0.0
    for item, weight in items:
        if weight <= 0.0:
            continue
        cur = _load_semantic_shadow_mask(item, size_hw, args, device) * weight
        if mix_mode == "weighted_max":
            prior = torch.maximum(prior, cur)
        else:
            prior = prior + cur
            weight_sum += weight
    if mix_mode != "weighted_max" and weight_sum > 1e-6:
        prior = prior / weight_sum
    if exclude_mask is not None:
        prior = (prior * (1.0 - exclude_mask.float().clamp(0.0, 1.0))).clamp(0.0, 1.0)
    min_pixels = max(float(getattr(args, "shadow_shape_prior_min_pixels", 4.0) or 4.0), 0.0)
    if min_pixels > 0.0 and float((prior > 0.001).float().sum().detach().cpu()) < min_pixels:
        return torch.zeros(size_hw, device=device, dtype=torch.float32)
    return prior.clamp(0.0, 1.0)


def _reference_connected_shadow_mask(ref_evidence: torch.Tensor, target_mask: torch.Tensor, args) -> torch.Tensor:
    hmask = target_mask.float().clamp(0.0, 1.0)
    evidence = ref_evidence.float().clamp(0.0, 1.0)
    length = max(1, int(getattr(args, "shadow_recognition_connect_length", 40) or 40))
    decay = max(float(getattr(args, "shadow_recognition_connect_decay", 24.0) or 24.0), 1e-6)
    min_evidence = min(max(float(getattr(args, "shadow_recognition_min_evidence", 0.05) or 0.05), 0.0), 1.0)
    protect = max(int(getattr(args, "shadow_target_protect_dilate", 1) or 0), 0)
    near = _dilate01_batch(hmask[None], length)[0]
    valid = (near * (1.0 - hmask)).clamp(0.0, 1.0)
    frontier = _dilate01_batch(hmask[None], protect)[0] if protect > 0 else hmask
    connected = torch.zeros_like(hmask)
    for step in range(1, length + 1):
        grown = _dilate01_batch(frontier[None], 1)[0]
        ring = (grown - frontier).clamp(0.0, 1.0) * valid
        if float(ring.max().detach().cpu()) <= 0.0:
            frontier = grown.clamp(0.0, 1.0)
            continue
        step_decay = math.exp(-float(step) / decay)
        connected = torch.maximum(connected, ring * evidence * step_decay)
        passable = ring * (evidence >= min_evidence).to(dtype=hmask.dtype)
        frontier = torch.maximum(frontier, passable).clamp(0.0, 1.0)
    blur = max(int(getattr(args, "shadow_recognition_connect_blur", 2) or 0), 0)
    if blur > 0:
        connected = (_blur01(connected, blur) * valid).clamp(0.0, 1.0)
    return connected.clamp(0.0, 1.0)


def _reference_connected_shadow_recognition(target_mask: torch.Tensor, azimuth: float, args) -> torch.Tensor:
    cands = list(getattr(args, "_shadow_shape_prior_candidates", []) or [])
    if not cands:
        return torch.zeros_like(target_mask)
    lo, hi, wlo, whi = _bracket(cands, float(azimuth))
    items = [(lo, float(wlo))]
    if Path(hi["path"]) != Path(lo["path"]) and float(whi) > 0.0:
        items.append((hi, float(whi)))
    size_hw = tuple(target_mask.shape[-2:])
    evidence = torch.zeros_like(target_mask)
    weight_sum = 0.0
    for item, weight in items:
        if weight <= 0.0:
            continue
        ref = _resize_chw(_load_image(Path(item["path"]), args).to(device=target_mask.device), size_hw)
        ref_gray = ref.mean(dim=0).clamp(0.0, 1.0)
        ref_blur = max(int(getattr(args, "shadow_recognition_reference_blur", 4) or 0), 0)
        ref_shadow = _blur01(ref_gray, ref_blur) if ref_blur > 0 else ref_gray
        context_blur = max(int(getattr(args, "shadow_recognition_context_blur", 21) or 0), 0)
        ref_context = _blur01(ref_shadow, context_blur).clamp_min(1e-4) if context_blur > 0 else ref_shadow.mean().clamp_min(1e-4)
        attenuation = (ref_shadow / ref_context).clamp(0.0, 1.0)
        threshold = max(float(getattr(args, "shadow_recognition_reference_threshold", 0.18) or 0.18), 1e-6)
        dark_by_value = ((threshold - ref_shadow) / threshold).clamp(0.0, 1.0)
        dark_by_ratio = (1.0 - attenuation).clamp(0.0, 1.0)
        ratio_mix = min(max(float(getattr(args, "shadow_recognition_ratio_mix", 0.75) or 0.75), 0.0), 1.0)
        evidence = evidence + (dark_by_value * (1.0 - ratio_mix) + dark_by_ratio * ratio_mix).clamp(0.0, 1.0) * weight
        weight_sum += weight
    if weight_sum > 1e-6:
        evidence = evidence / weight_sum
    return _reference_connected_shadow_mask(evidence, target_mask, args)


def _neighbor_shadow_shape_prior(mask: torch.Tensor, azimuth: float, search_mask: torch.Tensor, args) -> torch.Tensor:
    if not _shadow_shape_prior_enabled(args):
        return torch.zeros_like(mask)
    mode = str(getattr(args, "shadow_shape_prior_mode", "neighbor_gt") or "neighbor_gt").lower().strip()
    semantic_prior = _semantic_shadow_prior(
        azimuth,
        tuple(mask.shape[-2:]),
        args,
        mask.device,
        exclude_mask=mask,
    )
    if mode in {"semantic", "semantic_mask"}:
        return semantic_prior
    cands = list(getattr(args, "_shadow_shape_prior_candidates", []) or [])
    if not cands:
        return semantic_prior if mode in {"hybrid", "semantic_neighbor"} else torch.zeros_like(mask)
    if mode not in {"neighbor_gt", "hybrid", "semantic_neighbor"}:
        return torch.zeros_like(mask)

    lo, hi, wlo, whi = _bracket(cands, float(azimuth))
    items = [(lo, float(wlo))]
    if Path(hi["path"]) != Path(lo["path"]) and float(whi) > 0.0:
        items.append((hi, float(whi)))
    mix_mode = str(getattr(args, "shadow_shape_prior_mix_mode", "weighted_mean") or "weighted_mean").lower().strip()
    size_hw = tuple(mask.shape[-2:])
    prior = torch.zeros_like(mask)
    weight_sum = 0.0
    for item, weight in items:
        if weight <= 0.0:
            continue
        gt = _resize_chw(_load_image(Path(item["path"]), args).to(device=mask.device), size_hw)
        shadow = _shadow_gt_from_gt(gt, mask, search_mask, args).clamp(0.0, 1.0)
        if mix_mode == "weighted_max":
            prior = torch.maximum(prior, shadow * weight)
        else:
            prior = prior + shadow * weight
            weight_sum += weight
    if mix_mode != "weighted_max" and weight_sum > 1e-6:
        prior = prior / weight_sum
    min_pixels = max(float(getattr(args, "shadow_shape_prior_min_pixels", 4.0) or 4.0), 0.0)
    if min_pixels > 0.0 and float((prior > 0.001).float().sum().detach().cpu()) < min_pixels:
        prior = torch.zeros_like(mask)
    if mode in {"hybrid", "semantic_neighbor"} and float(semantic_prior.sum().detach().cpu()) > 0.0:
        prior = torch.maximum(prior, semantic_prior).clamp(0.0, 1.0)
    return prior.clamp(0.0, 1.0)


def _input_tensor(
    target: torch.Tensor,
    mask: torch.Tensor,
    azimuth: float,
    args,
    in_ch: int = 10,
    joint_mask_override: torch.Tensor | None = None,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    directional, direction_distance, direction_support = _direction_maps(mask, azimuth, args)
    fixed_directional, fixed_distance, fixed_support = _fixed_direction_maps(mask, azimuth, args)
    mode = str(getattr(args, "shadow_candidate_mode", "directional_prior") or "directional_prior").lower().strip()
    if mode == "directional":
        candidate, distance, support = directional, direction_distance, direction_support
        direction_prior = directional
    elif mode == "fixed_direction":
        candidate, distance, support = fixed_directional, fixed_distance, fixed_support
        direction_prior = fixed_directional
    elif mode == "fixed_direction_prior":
        candidate, distance, support = _omni_shadow_maps(mask, args)
        direction_prior = fixed_directional
    else:
        candidate, distance, support = _omni_shadow_maps(mask, args)
        direction_prior = directional
    shape_prior = _neighbor_shadow_shape_prior(mask, azimuth, support, args)
    if float(shape_prior.sum().detach().cpu()) > 0.0:
        shape_weight = min(max(float(getattr(args, "shadow_shape_prior_weight", 0.65) or 0.65), 0.0), 1.0)
        shape_threshold = min(max(float(getattr(args, "shadow_shape_prior_threshold", 0.05) or 0.05), 0.0), 1.0)
        shape_support = (shape_prior >= shape_threshold).to(dtype=mask.dtype)
        candidate = torch.maximum(candidate, shape_prior * shape_weight).clamp(0.0, 1.0)
        support = torch.maximum(support, shape_support).clamp(0.0, 1.0)
        direction_prior = torch.maximum(direction_prior, shape_prior * shape_weight).clamp(0.0, 1.0)
    gray = target.mean(dim=0, keepdim=True).clamp(0.0, 1.0)
    target_overlap = _target_shadow_overlap_candidate(target, mask, args)
    if float(target_overlap.sum()) > 0.0:
        weight = min(max(float(getattr(args, "shadow_target_overlap_weight", 0.55) or 0.55), 0.0), 1.0)
        overlap = target_overlap * weight
        candidate = torch.maximum(candidate, overlap).clamp(0.0, 1.0)
        support = torch.maximum(support, target_overlap).clamp(0.0, 1.0)
        direction_prior = torch.maximum(direction_prior, overlap).clamp(0.0, 1.0)
    if joint_mask_override is not None:
        joint_mask = joint_mask_override.float().to(device=mask.device, dtype=mask.dtype).clamp(0.0, 1.0)
    else:
        joint_mask = _integrated_black_region_mask(mask, torch.maximum(candidate, support), args)
    if float(joint_mask.sum()) > 0.0:
        joint_weight = min(max(float(getattr(args, "shadow_joint_mask_weight", 1.0) or 1.0), 0.0), 1.0)
        candidate = torch.maximum(candidate, joint_mask * joint_weight).clamp(0.0, 1.0)
        support = torch.maximum(support, joint_mask).clamp(0.0, 1.0)
        direction_prior = torch.maximum(direction_prior, joint_mask * joint_weight).clamp(0.0, 1.0)
    geometry_gate = _shadow_geometry_extent_gate(mask, azimuth, args)
    candidate = (candidate * geometry_gate).clamp(0.0, 1.0)
    distance = (distance * geometry_gate).clamp(0.0, 1.0)
    support = (support * geometry_gate).clamp(0.0, 1.0)
    direction_prior = (direction_prior * geometry_gate).clamp(0.0, 1.0)
    shape_prior = (shape_prior * geometry_gate).clamp(0.0, 1.0)
    joint_mask = (joint_mask * geometry_gate).clamp(0.0, 1.0)
    log_gray = _ld(gray, float(getattr(args, "log_scale", 20.0) or 20.0))
    rad = math.radians(float(azimuth) % 360.0)
    sin_map = torch.full_like(gray, math.sin(rad))
    cos_map = torch.full_like(gray, math.cos(rad))
    inv_dist = (1.0 - distance).clamp(0.0, 1.0)[None]
    use_color = int(in_ch) >= 13
    if use_color:
        rgb = target.clamp(0.0, 1.0)
        if rgb.shape[0] == 1:
            rgb = rgb.expand(3, -1, -1)
        elif rgb.shape[0] > 3:
            rgb = rgb[:3]
        x = torch.cat(
            [
                log_gray,
                gray,
                rgb,
                mask[None],
                candidate[None],
                distance[None],
                inv_dist,
                direction_prior[None],
                support[None],
                sin_map,
                cos_map,
            ],
            dim=0,
        )
    elif int(in_ch) <= 9:
        x = torch.cat([log_gray, gray, mask[None], candidate[None], distance[None], inv_dist, support[None], sin_map, cos_map], dim=0)
    else:
        x = torch.cat(
            [log_gray, gray, mask[None], candidate[None], distance[None], inv_dist, direction_prior[None], support[None], sin_map, cos_map],
            dim=0,
        )
    maps = {
        "candidate": candidate,
        "distance": distance,
        "support": support,
        "direction_prior": direction_prior,
        "target_overlap": target_overlap,
        "joint_mask": joint_mask,
        "shape_prior": shape_prior,
        "geometry_extent_gate": geometry_gate,
    }
    return x, maps


def _dice_loss(pred: torch.Tensor, target: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    p = (pred * mask).reshape(pred.shape[0], -1)
    t = (target * mask).reshape(target.shape[0], -1)
    inter = (p * t).sum(dim=1)
    den = p.sum(dim=1) + t.sum(dim=1)
    return (1.0 - (2.0 * inter + 1e-6) / (den + 1e-6)).mean()


def _masked_l1(a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    return ((a - b).abs() * mask).sum() / mask.sum().clamp_min(1.0)


def _apply_shadow(image: torch.Tensor, opacity: torch.Tensor, args) -> torch.Tensor:
    strength = min(max(float(getattr(args, "shadow_apply_strength", 0.95) or 0.95), 0.0), 1.0)
    max_darken = min(max(float(getattr(args, "shadow_apply_max_darken", 0.92) or 0.92), 0.0), 1.0)
    floor = min(max(float(getattr(args, "shadow_apply_floor", 0.0) or 0.0), 0.0), 1.0)
    mode = str(getattr(args, "shadow_apply_mode", "multiply") or "multiply").lower().strip()
    amount = opacity.clamp(0.0, 1.0) * strength
    amount = amount[:, None] if amount.ndim == 3 else amount[None]
    att = (1.0 - amount * max_darken).clamp(0.0, 1.0)
    attenuated = (image * att + floor * (1.0 - att)).clamp(0.0, 1.0)
    if mode == "subtract":
        subtract = min(max(float(getattr(args, "shadow_apply_subtract", 0.08) or 0.08), 0.0), 1.0)
        return torch.minimum(attenuated, image - amount * subtract).clamp(0.0, 1.0)
    if mode == "ceiling":
        ceiling = min(max(float(getattr(args, "shadow_apply_ceiling", 0.025) or 0.025), 0.0), 1.0)
        ceiling_target = torch.minimum(image, image.new_tensor(ceiling))
        ceiling_blend = (image * (1.0 - amount) + ceiling_target * amount).clamp(0.0, 1.0)
        return torch.minimum(attenuated, ceiling_blend).clamp(0.0, 1.0)
    return attenuated


def _floor_shadow_mask_opacity(pred: torch.Tensor, args) -> torch.Tensor:
    floor = min(max(float(getattr(args, "shadow_output_mask_floor", 0.0) or 0.0), 0.0), 1.0)
    if floor <= 0.0:
        return pred
    threshold = min(max(float(getattr(args, "shadow_output_mask_threshold", 0.05) or 0.05), 0.0), 1.0)
    mask = pred > threshold
    if not bool(mask.any()):
        return pred
    return torch.where(mask, torch.maximum(pred, pred.new_tensor(floor)), pred).clamp(0.0, 1.0)


def _shadow_recognition_mask(
    target_mask: torch.Tensor,
    imaps: dict[str, torch.Tensor],
    pred_shadow: torch.Tensor | None,
    image_maps: dict[str, torch.Tensor] | None,
    args,
    azimuth: float | None = None,
) -> torch.Tensor:
    mode = str(getattr(args, "shadow_recognition_source", "candidate") or "candidate").lower().strip()
    if mode == "compose_alpha" and image_maps is not None:
        rec = image_maps["compose_alpha"][0, 0] if image_maps["compose_alpha"].dim() == 4 else image_maps["compose_alpha"][0]
    elif mode == "prediction" and pred_shadow is not None:
        rec = pred_shadow
    elif mode == "reference_connected":
        rec = _reference_connected_shadow_recognition(target_mask, float(azimuth or 0.0), args)
    elif mode in {"legacy_opacity", "opacity"}:
        if image_maps is not None and "compose_alpha" in image_maps:
            alpha = image_maps["compose_alpha"]
            rec = alpha[0, 0] if alpha.dim() == 4 else alpha[0]
        elif pred_shadow is not None:
            rec = pred_shadow.to(device=target_mask.device, dtype=target_mask.dtype).clamp(0.0, 1.0)
        else:
            rec = torch.zeros_like(target_mask)
    elif mode == "shape_prior":
        rec = imaps.get("shape_prior", torch.zeros_like(target_mask)).to(device=target_mask.device, dtype=target_mask.dtype)
    elif mode == "candidate":
        rec = imaps.get("candidate", torch.zeros_like(target_mask)).to(device=target_mask.device, dtype=target_mask.dtype)
    else:
        rec = torch.zeros_like(target_mask)
        for key in ("shape_prior", "candidate"):
            value = imaps.get(key)
            if value is not None:
                rec = torch.maximum(rec, value.to(device=target_mask.device, dtype=target_mask.dtype).clamp(0.0, 1.0))
    threshold = min(max(float(getattr(args, "shadow_recognition_threshold", 0.4) or 0.4), 0.0), 1.0)
    rec = torch.where(rec >= threshold, rec, torch.zeros_like(rec))
    rec = rec * (1.0 - (target_mask > 0.5).to(dtype=target_mask.dtype))
    if bool(getattr(args, "shadow_geometry_extent_apply_to_recognition", True)):
        rec = rec * _shadow_geometry_extent_gate(target_mask, azimuth, args).to(device=rec.device, dtype=rec.dtype)
    return rec.clamp(0.0, 1.0)


def _image_refine_support(mask: torch.Tensor, imaps: dict[str, torch.Tensor], args) -> torch.Tensor:
    support = torch.maximum(imaps.get("support", torch.zeros_like(mask)), imaps.get("candidate", torch.zeros_like(mask)))
    joint_mask = imaps.get("joint_mask", torch.zeros_like(mask))
    if (
        bool(getattr(args, "shadow_joint_mask_refiner", False))
        and bool(getattr(args, "shadow_image_use_joint_mask", False))
        and float(joint_mask.sum()) > 0.0
    ):
        support = torch.maximum(support, joint_mask)
    if bool(getattr(args, "shadow_include_target", True)):
        if bool(getattr(args, "shadow_image_include_full_target", False)):
            target_support = mask.float().clamp(0.0, 1.0)
        else:
            target_support = imaps.get("target_overlap", torch.zeros_like(mask)).float().clamp(0.0, 1.0)
        support = torch.maximum(support, target_support)
    dilate = max(int(getattr(args, "shadow_image_support_dilate", 0) or 0), 0)
    if dilate > 0:
        support = _dilate01_batch(support[None], dilate)[0]
    return support.clamp(0.0, 1.0)


def _blur_batch_1ch(x: torch.Tensor, radius: int) -> torch.Tensor:
    if radius <= 0:
        return x.clamp(0.0, 1.0)
    return torch.stack([_blur01(v[0], radius) for v in x], dim=0)[:, None].clamp(0.0, 1.0)


def _compose_image_refine(
    raw: torch.Tensor,
    image: torch.Tensor,
    support: torch.Tensor,
    args,
    target_mask: torch.Tensor | None = None,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    scale = float(getattr(args, "log_scale", 20.0) or 20.0)
    gray = image.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    src_ld = _ld(gray, scale)
    delta = torch.tanh(raw[:, 0:1]) * float(getattr(args, "shadow_image_delta_log_scale", 0.28) or 0.28)
    extinction = torch.sigmoid(raw[:, 1:2])
    gain = torch.tanh(raw[:, 2:3]) * float(getattr(args, "shadow_image_bright_log_scale", 0.20) or 0.20)
    m = support[:, None].clamp(0.0, 1.0)
    ext_strength = float(getattr(args, "shadow_image_extinction_log_strength", 0.42) or 0.42)
    pred_ld = src_ld + (delta + gain - extinction * ext_strength) * m
    pred_gray = _from_ld(pred_ld, scale).clamp(0.0, 1.0)
    detail_radius = max(int(getattr(args, "shadow_image_detail_radius", 2) or 0), 0)
    target_detail_weight = min(max(float(getattr(args, "shadow_image_target_detail_preserve_weight", 0.75) or 0.0), 0.0), 1.0)
    shadow_detail_weight = min(max(float(getattr(args, "shadow_image_shadow_detail_preserve_weight", 0.35) or 0.0), 0.0), 1.0)
    if detail_radius > 0 and max(target_detail_weight, shadow_detail_weight) > 0.0:
        pred_lf = _blur_batch_1ch(pred_gray, detail_radius)
        src_lf = _blur_batch_1ch(gray, detail_radius)
        pred_detail = pred_gray - pred_lf
        src_detail = gray - src_lf
        if target_mask is None:
            preserve = torch.full_like(m, shadow_detail_weight)
        else:
            if target_mask.dim() == 3:
                target_mask = target_mask[:, None]
            tgt = target_mask.to(device=m.device, dtype=m.dtype).clamp(0.0, 1.0)
            preserve = (shadow_detail_weight * (1.0 - tgt) + target_detail_weight * tgt).clamp(0.0, 1.0)
        preserve = (preserve * m).clamp(0.0, 1.0)
        detail = pred_detail * (1.0 - preserve) + src_detail * preserve
        pred_gray = (pred_lf + detail).clamp(0.0, 1.0)
    alpha_mode = str(getattr(args, "shadow_image_compose_alpha_mode", "prediction") or "prediction").lower().strip()
    if alpha_mode == "support":
        alpha = m
    else:
        delta_scale = max(float(getattr(args, "shadow_image_delta_log_scale", 0.28) or 0.28), 1e-6)
        gain_scale = max(float(getattr(args, "shadow_image_bright_log_scale", 0.20) or 0.20), 1e-6)
        ext_threshold = min(max(float(getattr(args, "shadow_image_compose_alpha_threshold", 0.50) or 0.50), 0.0), 1.0)
        ext_softness = max(float(getattr(args, "shadow_image_compose_alpha_softness", 0.15) or 0.15), 1e-6)
        residual_gate = torch.maximum((delta.abs() / delta_scale).clamp(0.0, 1.0), (gain.abs() / gain_scale).clamp(0.0, 1.0))
        extinction_gate = ((extinction - ext_threshold) / ext_softness).clamp(0.0, 1.0)
        alpha = torch.maximum(residual_gate, extinction_gate) * m
    alpha_floor = min(max(float(getattr(args, "shadow_image_compose_alpha_floor", 0.0) or 0.0), 0.0), 1.0)
    min_support_mean = max(float(getattr(args, "shadow_image_compose_alpha_min_support_mean", 0.0) or 0.0), 0.0)
    if alpha_floor > 0.0:
        support_area = m.sum(dim=(2, 3), keepdim=True).clamp_min(1.0)
        support_mean = (alpha * m).sum(dim=(2, 3), keepdim=True) / support_area
        if min_support_mean > 0.0:
            low_alpha = (support_mean < min_support_mean).to(dtype=alpha.dtype)
            floor_alpha = (m * alpha_floor).clamp(0.0, 1.0)
            alpha = torch.where(low_alpha.expand_as(alpha) > 0.5, torch.maximum(alpha, floor_alpha), alpha)
        else:
            alpha = torch.maximum(alpha, (m * alpha_floor).clamp(0.0, 1.0))
    component_gate = torch.ones_like(alpha)
    component_gate_raw = torch.ones_like(alpha)
    compose_alpha_pre_component = alpha
    if bool(getattr(args, "shadow_pred_component_filter", False)) and target_mask is not None:
        tgt = target_mask
        if tgt.dim() == 3:
            tgt = tgt[:, None]
        gates = []
        for bi in range(alpha.shape[0]):
            gate = _connected_shadow_component_mask(
                alpha[bi, 0].detach(),
                tgt[bi, 0].detach().to(device=alpha.device, dtype=alpha.dtype),
                (m[bi, 0].detach() > 0.001).to(device=alpha.device, dtype=alpha.dtype),
                args,
                prefix="shadow_pred",
            )
            gates.append(gate.to(device=alpha.device, dtype=alpha.dtype))
        component_gate_raw = torch.stack(gates, dim=0)[:, None].clamp(0.0, 1.0)
        applied_gates = []
        filtered_alpha = []
        for bi in range(alpha.shape[0]):
            gate = component_gate_raw[bi : bi + 1]
            filtered = (alpha[bi : bi + 1] * gate).clamp(0.0, 1.0)
            raw_sum = float(alpha[bi : bi + 1].sum().detach().cpu())
            filtered_sum = float(filtered.sum().detach().cpu())
            min_keep_ratio = max(float(getattr(args, "shadow_pred_component_min_keep_ratio", 0.0) or 0.0), 0.0)
            # The component filter is only a geometric cleanup pass.  If its
            # score thresholds reject every predicted component, keep the raw
            # prediction instead of erasing the learned shadow entirely.
            if filtered_sum <= 1e-6 or (raw_sum > 1e-6 and min_keep_ratio > 0.0 and filtered_sum < raw_sum * min_keep_ratio):
                applied_gates.append((alpha[bi : bi + 1] > 0.001).to(dtype=alpha.dtype))
                filtered_alpha.append(alpha[bi : bi + 1])
            else:
                applied_gates.append(gate)
                filtered_alpha.append(filtered)
        component_gate = torch.cat(applied_gates, dim=0).clamp(0.0, 1.0)
        alpha = torch.cat(filtered_alpha, dim=0).clamp(0.0, 1.0)
    blur = max(int(getattr(args, "shadow_image_compose_blur", 1) or 0), 0)
    if blur > 0:
        alpha = torch.stack([_blur01(a[0], blur) for a in alpha], dim=0)[:, None].clamp(0.0, 1.0)
    pred_gray = (pred_gray * alpha + gray * (1.0 - alpha)).clamp(0.0, 1.0)
    pred = pred_gray.expand(-1, 3, -1, -1).contiguous()
    return pred, {
        "delta_log": delta,
        "extinction": extinction,
        "gain_log": gain,
        "compose_alpha_pre_component": compose_alpha_pre_component,
        "compose_alpha": alpha,
        "component_gate": component_gate,
        "component_gate_raw": component_gate_raw,
        "support": support[:, None].clamp(0.0, 1.0),
    }


def _checkpoint_safe_value(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple)):
        return [_checkpoint_safe_value(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _checkpoint_safe_value(v) for k, v in value.items()}
    return str(value)


def _checkpoint_args(args) -> dict:
    skip = {"_shadow_shape_prior_candidates", "_shadow_semantic_candidates"}
    out = {}
    for key, value in vars(args).items():
        if key in skip:
            continue
        out[key] = _checkpoint_safe_value(value)
    return out


def _semantic_gt_supervision_enabled(args) -> bool:
    mode = str(getattr(args, "shadow_supervision_source", "semantic_gt") or "semantic_gt").lower().strip()
    return mode in {"semantic_gt", "semantic", "semantic_mask"}


def _train(args) -> None:
    device = torch.device(args.device if torch.cuda.is_available() or str(args.device) == "cpu" else "cpu")
    _configure_torch(args, device)
    pairs = _select_pairs(Path(args.train_target_dir), Path(args.train_gt_dir), args)
    if not pairs:
        raise RuntimeError("No shadow training pairs")
    _configure_shadow_shape_prior(args, args.train_gt_dir)
    if _semantic_gt_supervision_enabled(args) and not list(getattr(args, "_shadow_semantic_candidates", []) or []):
        raise RuntimeError(
            "--shadow_supervision_source semantic_gt requires real semantic masks "
            "with target labels 1/2 and shadow label 3. Pass --shadow_semantic_mask_dir "
            "pointing to the dataset root or use --shadow_supervision_source heuristic_gt explicitly."
        )
    mask_targets = _candidates(Path(args.train_mask_target_dir)) if getattr(args, "train_mask_target_dir", None) else []
    mask_by_stem = {m["path"].stem: m for m in mask_targets}
    in_ch = 13 if bool(getattr(args, "shadow_input_color_channels", False)) else 10
    refine_mode = str(getattr(args, "shadow_refine_mode", "opacity") or "opacity").lower().strip()
    out_ch = 3 if refine_mode == "image" else 1
    model = AzimuthShadowUNet(in_ch=in_ch, base=int(args.model_base), padding_mode=str(args.conv_padding_mode), out_ch=out_ch).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
    checkpoint = Path(args.checkpoint)
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    _write_train_pair_report(pairs, out_dir)
    maps_dir = out_dir / "training_maps"
    if bool(args.save_maps):
        maps_dir.mkdir(parents=True, exist_ok=True)
    scale = float(args.log_scale)

    def _make_training_item(p: dict) -> dict[str, torch.Tensor]:
        target = _load_image(p["target"], args).to(device)
        mask_item = mask_by_stem.get(p["target"].stem) if mask_targets else None
        if mask_item is None and mask_targets:
            mask_item = _nearest(mask_targets, float(p["azimuth"]))
        mask_source = (
            _resize_chw(_load_image(mask_item["path"], args).to(device), tuple(target.shape[-2:]))
            if mask_item is not None
            else target
        )
        gt_lo = _load_image(p["lo"]["path"], args).to(device)
        gt_hi = _load_image(p["hi"]["path"], args).to(device)
        gt = _mix_gt(gt_lo, gt_hi, float(p["wlo"]), float(p["whi"]), scale)
        semantic_target, semantic_shadow = _semantic_gt_region_masks(
            float(p["azimuth"]),
            tuple(target.shape[-2:]),
            args,
            device,
        )
        use_semantic_gt = _semantic_gt_supervision_enabled(args) and float(semantic_target.sum().detach().cpu()) > 0.0
        if _semantic_gt_supervision_enabled(args) and not use_semantic_gt:
            raise RuntimeError(
                "semantic_gt shadow supervision found no target labels for "
                f"{Path(p['target']).name} at azimuth {float(p['azimuth']):.3f}. "
                "Expected labels 1/2 in --shadow_semantic_mask_dir."
            )
        if use_semantic_gt:
            mask = semantic_target
            gt_anchor = semantic_target
        else:
            mask = _target_mask(mask_source, args)
            mask = _repair_shadow_train_target_mask(mask_source, mask, args)
            gt_anchor = _gt_anchor_mask(gt, mask, args)
        base = _apply_shadow_carrier_background(target, mask, args)
        x, imaps = _input_tensor(
            base,
            mask,
            float(p["azimuth"]),
            args,
            in_ch=in_ch,
            joint_mask_override=torch.zeros_like(mask),
        )
        min_candidate_pixels = float(getattr(args, "shadow_train_min_candidate_pixels", 8.0) or 8.0)
        if (
            not use_semantic_gt
            and
            bool(getattr(args, "shadow_train_repair_empty_candidate", True))
            and float(imaps["candidate"].sum()) < min_candidate_pixels
            and str(getattr(args, "target_mask_mode", "legacy") or "legacy").lower().strip()
            not in {"scatter95_largest", "scatter_percentile_largest"}
        ):
            repaired = _legacy_target_mask(mask_source, args)
            if float(repaired.sum()) >= float(getattr(args, "target_mask_min_pixels", 16.0) or 16.0):
                mask = repaired
                gt_anchor = _gt_anchor_mask(gt, mask, args)
                base = _apply_shadow_carrier_background(target, mask, args)
                x, imaps = _input_tensor(
                    base,
                    mask,
                    float(p["azimuth"]),
                    args,
                    in_ch=in_ch,
                    joint_mask_override=torch.zeros_like(mask),
                )
        if use_semantic_gt and float(semantic_shadow.sum().detach().cpu()) > 0.0:
            y_shadow = semantic_shadow
        else:
            y_shadow = _shadow_gt_from_gt(gt, gt_anchor, imaps["candidate"], args)
            semantic_shadow = _semantic_shadow_prior(
                float(p["azimuth"]),
                tuple(y_shadow.shape[-2:]),
                args,
                device,
                exclude_mask=gt_anchor,
            )
        if not use_semantic_gt and float(semantic_shadow.sum().detach().cpu()) > 0.0:
            semantic_mix = min(max(float(getattr(args, "shadow_semantic_supervision_mix", 1.0) or 1.0), 0.0), 1.0)
            y_shadow = (y_shadow * (1.0 - semantic_mix) + semantic_shadow * semantic_mix).clamp(0.0, 1.0)
        if use_semantic_gt:
            train_mask = torch.maximum(gt_anchor, y_shadow).clamp(0.0, 1.0)
        else:
            train_mask = _training_mask_from_maps(mask, imaps["candidate"], imaps["support"], gt_anchor, y_shadow, args)
        joint_mask = _integrated_black_region_mask(mask, y_shadow, args)
        if bool(getattr(args, "shadow_joint_mask_refiner", False)) and float(joint_mask.sum()) > 0.0:
            x, imaps = _input_tensor(
                base,
                mask,
                float(p["azimuth"]),
                args,
                in_ch=in_ch,
                joint_mask_override=joint_mask,
            )
        supervision_mode = str(getattr(args, "shadow_supervision_mode", "gt_shadow") or "gt_shadow").lower().strip()
        y_source = _source_to_gt_shadow_target(base, gt, train_mask, args)
        if use_semantic_gt:
            y = _joint_shadow_target_from_gt(base, gt, y_shadow, joint_mask, args)
        elif bool(getattr(args, "shadow_joint_mask_refiner", False)) and float(joint_mask.sum()) > 0.0:
            y = _joint_shadow_target_from_gt(base, gt, y_shadow, joint_mask, args)
        elif supervision_mode == "source_to_gt":
            y = y_source
        elif supervision_mode == "mixed":
            mix = min(max(float(getattr(args, "shadow_source_gt_mix", 0.65) or 0.65), 0.0), 1.0)
            y = torch.maximum(y_shadow, y_source * mix).clamp(0.0, 1.0)
        else:
            y = _joint_shadow_target_from_gt(base, gt, y_shadow, joint_mask, args)
        if use_semantic_gt:
            support = torch.maximum(gt_anchor, y_shadow).clamp(0.0, 1.0)
        elif bool(getattr(args, "shadow_joint_mask_refiner", False)) and float(joint_mask.sum()) > 0.0:
            support = joint_mask.float().clamp(0.0, 1.0)
        else:
            support = train_mask.float().clamp(0.0, 1.0)
        return {
            "x": x,
            "target": y[None],
            "shadow_target": y_shadow[None],
            "source_gt_target": y_source[None],
            "target_mask": mask[None],
            "gt_anchor_mask": gt_anchor[None],
            "candidate": imaps["candidate"][None],
            "shape_prior": imaps["shape_prior"][None],
            "target_overlap": imaps["target_overlap"][None],
            "joint_mask": joint_mask[None],
            "support": support[None],
            "image_support": (support if use_semantic_gt else _image_refine_support(mask, imaps, args))[None],
            "base": base,
            "gt": gt,
            "mask_source": mask_source,
            "mask_ratio": torch.tensor(float(mask.mean().detach().cpu()), device=device),
            "candidate_sum": torch.tensor(float(imaps["candidate"].sum().detach().cpu()), device=device),
            "target_sum": torch.tensor(float(y.sum().detach().cpu()), device=device),
            "support_sum": torch.tensor(float(support.sum().detach().cpu()), device=device),
            "semantic_gt": torch.tensor(1.0 if use_semantic_gt else 0.0, device=device),
        }

    def _estimate_global_direction_from_gt() -> tuple[float | None, float, float]:
        old_gate = bool(getattr(args, "shadow_gt_use_fixed_direction_gate", False))
        old_fallback = bool(getattr(args, "shadow_gt_fixed_direction_fallback", False))
        old_mix = float(getattr(args, "shadow_candidate_supervision_mix", 1.0) or 1.0)
        setattr(args, "shadow_gt_use_fixed_direction_gate", False)
        setattr(args, "shadow_gt_fixed_direction_fallback", False)
        setattr(args, "shadow_candidate_supervision_mix", 0.0)
        directions: list[tuple[float | None, float]] = []
        try:
            for p in tqdm(pairs, desc="estimate shadow direction", unit="img"):
                target = _load_image(p["target"], args).to(device)
                mask_item = mask_by_stem.get(p["target"].stem) if mask_targets else None
                if mask_item is None and mask_targets:
                    mask_item = _nearest(mask_targets, float(p["azimuth"]))
                mask_source = (
                    _resize_chw(_load_image(mask_item["path"], args).to(device), tuple(target.shape[-2:]))
                    if mask_item is not None
                    else target
                )
                gt_lo = _load_image(p["lo"]["path"], args).to(device)
                gt_hi = _load_image(p["hi"]["path"], args).to(device)
                gt = _mix_gt(gt_lo, gt_hi, float(p["wlo"]), float(p["whi"]), scale)
                semantic_target, semantic_shadow = _semantic_gt_region_masks(
                    float(p["azimuth"]),
                    tuple(target.shape[-2:]),
                    args,
                    device,
                )
                use_semantic_gt = _semantic_gt_supervision_enabled(args) and float(semantic_target.sum().detach().cpu()) > 0.0
                if use_semantic_gt:
                    mask = semantic_target
                    gt_anchor = semantic_target
                else:
                    mask = _target_mask(mask_source, args)
                    mask = _repair_shadow_train_target_mask(mask_source, mask, args)
                    gt_anchor = _gt_anchor_mask(gt, mask, args)
                omni_candidate, _omni_distance, _omni_support = _omni_shadow_maps(mask, args)
                shadow = semantic_shadow if use_semantic_gt and float(semantic_shadow.sum().detach().cpu()) > 0.0 else _shadow_gt_from_gt(gt, gt_anchor, omni_candidate, args)
                directions.append(_mask_direction_deg(shadow, gt_anchor))
        finally:
            setattr(args, "shadow_gt_use_fixed_direction_gate", old_gate)
            setattr(args, "shadow_gt_fixed_direction_fallback", old_fallback)
            setattr(args, "shadow_candidate_supervision_mix", old_mix)
        return _weighted_circular_stats_deg(directions)

    if bool(getattr(args, "shadow_gt_use_global_direction", True)) and getattr(args, "_shadow_global_direction_deg", None) is None:
        global_dir, concentration, total_weight = _estimate_global_direction_from_gt()
        if global_dir is not None:
            setattr(args, "_shadow_global_direction_deg", float(global_dir))
            setattr(args, "shadow_gt_global_direction_deg", float(global_dir))
            setattr(args, "shadow_pred_global_direction_deg", float(global_dir))
            setattr(args, "_shadow_global_direction_concentration", float(concentration))
            min_conc = float(getattr(args, "shadow_gt_fixed_direction_min_concentration", 0.90) or 0.90)
            if bool(getattr(args, "shadow_gt_auto_fixed_direction_gate", False)):
                setattr(args, "shadow_gt_use_fixed_direction_gate", float(concentration) >= min_conc)
            print(
                f"[azimuth shadow] estimated train-set shadow direction before cache: {global_dir:.1f} deg, "
                f"R={concentration:.3f}, weight={total_weight:.1f}, "
                f"fixed_gate={bool(getattr(args, 'shadow_gt_use_fixed_direction_gate', False))}"
            )

    cached_items: list[dict[str, torch.Tensor]] | None = None
    if bool(getattr(args, "cache_training_pairs", True)):
        cached_items = [_make_training_item(p) for p in tqdm(pairs, desc="cache shadow pairs", unit="img")]
        target_sums = [float(item["target_sum"].detach().cpu()) for item in cached_items]
        support_sums = [float(item["support_sum"].detach().cpu()) for item in cached_items]
        candidate_sums = [float(item["candidate_sum"].detach().cpu()) for item in cached_items]
        mask_ratios = [float(item["mask_ratio"].detach().cpu()) for item in cached_items]
        semantic_items = [float(item.get("semantic_gt", torch.tensor(0.0)).detach().cpu()) for item in cached_items]
        stats = {
            "items": len(cached_items),
            "target_sum_mean": float(np.mean(target_sums)) if target_sums else 0.0,
            "target_sum_min": float(np.min(target_sums)) if target_sums else 0.0,
            "support_sum_mean": float(np.mean(support_sums)) if support_sums else 0.0,
            "candidate_sum_mean": float(np.mean(candidate_sums)) if candidate_sums else 0.0,
            "mask_ratio_mean": float(np.mean(mask_ratios)) if mask_ratios else 0.0,
            "empty_target_items": int(sum(v <= 1e-6 for v in target_sums)),
            "empty_support_items": int(sum(v <= 1e-6 for v in support_sums)),
            "empty_candidate_items": int(sum(v <= 1e-6 for v in candidate_sums)),
            "semantic_shadow_coverage": getattr(args, "_shadow_semantic_coverage_report", {}),
            "semantic_target_coverage": getattr(args, "_target_semantic_coverage_report", {}),
            "semantic_gt_items": int(sum(v > 0.5 for v in semantic_items)),
        }
        with (out_dir / "shadow_training_supervision_summary.json").open("w", encoding="utf-8") as f:
            import json

            json.dump(stats, f, indent=2)
        print(
            "[azimuth shadow] supervision: "
            f"target_sum_mean={stats['target_sum_mean']:.3f}, "
            f"support_sum_mean={stats['support_sum_mean']:.3f}, "
            f"candidate_sum_mean={stats['candidate_sum_mean']:.3f}, "
            f"mask_ratio_mean={stats['mask_ratio_mean']:.4f}"
        )
        if bool(getattr(args, "shadow_fail_on_empty_supervision", True)):
            if stats["target_sum_mean"] <= 1e-6 or stats["support_sum_mean"] <= 1e-6 or stats["candidate_sum_mean"] <= 1e-6:
                raise RuntimeError(
                    "Azimuth shadow training has empty supervision/candidate masks; "
                    f"see {out_dir / 'shadow_training_supervision_summary.json'}"
                )
        if bool(getattr(args, "shadow_gt_use_global_direction", True)):
            directions = [_mask_direction_deg(item["shadow_target"][0], item["gt_anchor_mask"][0]) for item in cached_items]
            global_dir, concentration, total_weight = _weighted_circular_stats_deg(directions)
            if global_dir is not None:
                setattr(args, "_shadow_global_direction_deg", float(global_dir))
                setattr(args, "shadow_gt_global_direction_deg", float(global_dir))
                setattr(args, "shadow_pred_global_direction_deg", float(global_dir))
                setattr(args, "_shadow_global_direction_concentration", float(concentration))
                min_conc = float(getattr(args, "shadow_gt_fixed_direction_min_concentration", 0.90) or 0.90)
                if bool(getattr(args, "shadow_gt_auto_fixed_direction_gate", False)):
                    use_gate = float(concentration) >= min_conc
                    setattr(args, "shadow_gt_use_fixed_direction_gate", bool(use_gate))
                print(
                    f"[azimuth shadow] estimated train-set shadow direction: {global_dir:.1f} deg, "
                    f"R={concentration:.3f}, weight={total_weight:.1f}, "
                    f"fixed_gate={bool(getattr(args, 'shadow_gt_use_fixed_direction_gate', False))}"
                )
                cached_items = [_make_training_item(p) for p in tqdm(pairs, desc="recache shadow pairs with direction", unit="img")]

    rows = []
    pbar = tqdm(range(int(args.iterations)), desc="train azimuth shadow", unit="it")
    for it in pbar:
        batch_idx = [(it * int(args.batch_size) + j) % len(pairs) for j in range(int(args.batch_size))]
        xs, targets, shadow_targets, source_gt_targets, target_masks, gt_anchor_masks, masks, image_supports, candidates, shape_priors, target_overlaps, joint_masks, base_imgs, gt_imgs, mask_source_imgs = [], [], [], [], [], [], [], [], [], [], [], [], [], [], []
        for idx in batch_idx:
            item = cached_items[idx] if cached_items is not None else _make_training_item(pairs[idx])
            xs.append(item["x"])
            targets.append(item["target"])
            shadow_targets.append(item["shadow_target"])
            source_gt_targets.append(item["source_gt_target"])
            target_masks.append(item["target_mask"])
            gt_anchor_masks.append(item["gt_anchor_mask"])
            candidates.append(item["candidate"])
            shape_priors.append(item["shape_prior"])
            target_overlaps.append(item["target_overlap"])
            joint_masks.append(item["joint_mask"])
            masks.append(item["support"])
            image_supports.append(item["image_support"])
            base_imgs.append(item["base"])
            gt_imgs.append(item["gt"])
            mask_source_imgs.append(item["mask_source"])
        xb = torch.stack(xs, dim=0)
        yb = torch.stack(targets, dim=0)
        y_shadow_b = torch.stack(shadow_targets, dim=0)
        y_source_b = torch.stack(source_gt_targets, dim=0)
        target_mask_b = torch.stack(target_masks, dim=0)
        gt_anchor_b = torch.stack(gt_anchor_masks, dim=0)
        cb = torch.stack(candidates, dim=0)
        shape_prior_b = torch.stack(shape_priors, dim=0)
        target_overlap_b = torch.stack(target_overlaps, dim=0)
        joint_mask_b = torch.stack(joint_masks, dim=0)
        support = torch.stack(masks, dim=0)
        image_support = torch.stack(image_supports, dim=0)
        base = torch.stack(base_imgs, dim=0)
        gt = torch.stack(gt_imgs, dim=0)
        mask_source_b = torch.stack(mask_source_imgs, dim=0)
        raw = model(xb)
        if refine_mode == "image":
            pred_img, pred_maps = _compose_image_refine(raw, base, image_support[:, 0], args, target_mask=target_mask_b[:, 0])
            pred_ld = _ld(pred_img, scale)
            gt_ld = _ld(gt, scale)
            src_ld = _ld(base.mean(dim=1, keepdim=True).expand_as(pred_img), scale)
            img_mask = image_support.clamp(0.0, 1.0)
            target_mask3 = target_mask_b.clamp(0.0, 1.0)
            shadow_mask = (img_mask * (1.0 - target_mask3)).clamp(0.0, 1.0)
            log_l1 = _masked_mean((pred_ld - gt_ld).abs(), img_mask)
            log_mse = _masked_mse(pred_ld, gt_ld, img_mask)
            sar_ssim = _masked_sar_ssim_loss(pred_ld, gt_ld, img_mask[:, 0], window_size=int(args.shadow_image_sar_ssim_window))
            grad = _masked_mean((_gradient_mag_map(pred_ld) - _gradient_mag_map(gt_ld)).abs(), img_mask)
            dark_leak = _masked_mean((pred_ld - gt_ld).clamp_min(0.0).pow(2), shadow_mask)
            target_l1 = _masked_mean((pred_ld - gt_ld).abs(), target_mask3)
            base_target_ld = src_ld.mean(dim=1, keepdim=True)
            bright_thresh = max(float(getattr(args, "shadow_image_target_identity_threshold_log", 0.42) or 0.0), 0.0)
            bright_target = ((base_target_ld >= bright_thresh).float() * target_mask3).clamp(0.0, 1.0)
            target_identity = _masked_mean((pred_ld - src_ld).abs(), bright_target)
            outside_identity = _masked_mean((pred_ld - src_ld).abs(), (1.0 - img_mask).clamp(0.0, 1.0))
            ext_reg = _masked_mean(pred_maps["extinction"], img_mask)
            loss = (
                float(args.shadow_image_log_l1_weight) * log_l1
                + float(args.shadow_image_log_mse_weight) * log_mse
                + float(args.shadow_image_sar_ssim_weight) * sar_ssim
                + float(args.shadow_image_gradient_weight) * grad
                + float(args.shadow_image_dark_leak_weight) * dark_leak
                + float(args.shadow_image_target_l1_weight) * target_l1
                + float(args.shadow_image_target_identity_weight) * target_identity
                + float(args.shadow_image_outside_identity_weight) * outside_identity
                + float(args.shadow_image_extinction_reg_weight) * ext_reg
            )
            pred = pred_maps["extinction"].clamp(0.0, 1.0)
            rendered = pred_img
            bce = dice = l1 = area_loss = leak = torch.zeros((), device=device)
            render_l1 = log_l1
        else:
            pred = torch.sigmoid(raw) * cb
            loss_mask = ((support > 0.01) | (yb > 0.005)).float()
            bce = F.binary_cross_entropy(pred.clamp(1e-5, 1.0 - 1e-5), yb.clamp(0.0, 1.0), reduction="none")
            bce_weight = yb * float(args.shadow_positive_weight) + (1.0 - yb) * float(args.shadow_negative_weight)
            bce = (bce * bce_weight * loss_mask).sum() / (bce_weight * loss_mask).sum().clamp_min(1.0)
            dice = _dice_loss(pred, yb, support)
            l1 = _masked_l1(pred, yb, support)
            rendered = _apply_shadow(base, pred[:, 0], args)
            render_l1 = _masked_l1(_ld(rendered, scale), _ld(gt, scale), support)
            pred_area = (pred * support).sum(dim=(1, 2, 3)) / support.sum(dim=(1, 2, 3)).clamp_min(1.0)
            target_area = (yb * support).sum(dim=(1, 2, 3)) / support.sum(dim=(1, 2, 3)).clamp_min(1.0)
            area_loss = (pred_area - target_area).abs().mean()
            leak = _masked_l1(pred * (1.0 - cb), torch.zeros_like(pred), torch.ones_like(pred))
            loss = (
                float(args.shadow_bce_weight) * bce
                + float(args.shadow_dice_weight) * dice
                + float(args.shadow_l1_weight) * l1
                + float(args.shadow_render_l1_weight) * render_l1
                + float(args.shadow_area_weight) * area_loss
                + float(args.shadow_leak_weight) * leak
            )
        opt.zero_grad(set_to_none=True)
        loss.backward()
        if float(args.max_grad_norm) > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(args.max_grad_norm))
        opt.step()
        if it % max(int(args.progress_interval), 1) == 0 or it + 1 == int(args.iterations):
            postfix = {"loss": f"{float(loss.detach()):.4f}", "r": f"{float(render_l1.detach()):.4f}"}
            if refine_mode == "image":
                postfix["ssim"] = f"{float(sar_ssim.detach()):.4f}"
            else:
                postfix["dice"] = f"{float(dice.detach()):.4f}"
            pbar.set_postfix(**postfix)
            rows.append({
                "iteration": it + 1,
                "refine_mode": refine_mode,
                "loss": float(loss.detach().cpu()),
                "bce": float(bce.detach().cpu()),
                "dice": float(dice.detach().cpu()),
                "opacity_l1": float(l1.detach().cpu()),
                "render_l1": float(render_l1.detach().cpu()),
                "area_l1": float(area_loss.detach().cpu()),
                "image_log_l1": float(render_l1.detach().cpu()) if refine_mode == "image" else 0.0,
                "image_sar_ssim_loss": float(sar_ssim.detach().cpu()) if refine_mode == "image" else 0.0,
                "image_dark_leak": float(dark_leak.detach().cpu()) if refine_mode == "image" else 0.0,
                "image_target_l1": float(target_l1.detach().cpu()) if refine_mode == "image" else 0.0,
                "image_target_identity": float(target_identity.detach().cpu()) if refine_mode == "image" else 0.0,
            })
            if bool(args.save_maps):
                stem = f"iter_{it + 1:06d}"
                torchvision.utils.save_image(pred[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_pred_shadow.png"))
                torchvision.utils.save_image(yb[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_gt_shadow.png"))
                torchvision.utils.save_image(y_shadow_b[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_gt_shadow_only.png"))
                torchvision.utils.save_image(y_source_b[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_source_to_gt_shadow.png"))
                torchvision.utils.save_image(cb[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_candidate.png"))
                torchvision.utils.save_image(shape_prior_b[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_shape_prior.png"))
                torchvision.utils.save_image(support[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_train_mask.png"))
                torchvision.utils.save_image(joint_mask_b[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_joint_mask.png"))
                torchvision.utils.save_image(rendered[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_rendered.png"))
                torchvision.utils.save_image(mask_source_b[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_mask_source.png"))
                torchvision.utils.save_image(target_mask_b[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_mask.png"))
                if refine_mode == "image":
                    err = (pred_img[:1].mean(dim=1, keepdim=True) - gt[:1].mean(dim=1, keepdim=True)).abs()
                    torchvision.utils.save_image(image_support[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_image_support.png"))
                    torchvision.utils.save_image(gt[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_gt_mix.png"))
                    torchvision.utils.save_image(base[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_input_base.png"))
                    torchvision.utils.save_image(err.clamp(0.0, 1.0), str(maps_dir / f"{stem}_abs_error.png"))
                    torchvision.utils.save_image(pred_maps["delta_log"][:1].clamp(-1.0, 1.0).abs(), str(maps_dir / f"{stem}_delta_log_abs.png"))
                    torchvision.utils.save_image(pred_maps["gain_log"][:1].clamp(-1.0, 1.0).abs(), str(maps_dir / f"{stem}_gain_log_abs.png"))
                    torchvision.utils.save_image(pred_maps["compose_alpha_pre_component"][:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_compose_alpha_pre_component.png"))
                    torchvision.utils.save_image(pred_maps["compose_alpha"][:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_compose_alpha.png"))
                    torchvision.utils.save_image(pred_maps["component_gate_raw"][:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_component_gate_raw.png"))
                    torchvision.utils.save_image(pred_maps["component_gate"][:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_component_gate.png"))
                pred_class_shadow = pred_maps["compose_alpha"][0, 0] if refine_mode == "image" else pred[0, 0]
                pred_rgb, pred_bg = _region_classification_rgb(target_mask_b[0, 0], pred_class_shadow)
                gt_rgb, gt_bg = _region_classification_rgb(gt_anchor_b[0, 0], yb[0, 0])
                torchvision.utils.save_image(pred_rgb, str(maps_dir / f"{stem}_pred_region_classification.png"))
                torchvision.utils.save_image(gt_rgb, str(maps_dir / f"{stem}_gt_region_classification.png"))
                torchvision.utils.save_image(pred_bg, str(maps_dir / f"{stem}_pred_background_mask.png"))
                torchvision.utils.save_image(gt_bg, str(maps_dir / f"{stem}_gt_background_mask.png"))
                torchvision.utils.save_image(gt_anchor_b[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_gt_anchor_mask.png"))
                if bool(getattr(args, "shadow_include_target", False)):
                    torchvision.utils.save_image(target_overlap_b[:1].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_overlap_candidate.png"))
    torch.save({
        "model": model.state_dict(),
        "args": _checkpoint_args(args),
        "in_ch": in_ch,
        "out_ch": out_ch,
        "model_base": int(args.model_base),
        "shadow_refine_mode": refine_mode,
    }, checkpoint)
    if rows:
        with (out_dir / "shadow_training_metrics.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    print(f"[azimuth shadow] checkpoint: {checkpoint}")


def _load_model(args, device: torch.device) -> AzimuthShadowUNet:
    try:
        ckpt = torch.load(args.checkpoint, map_location=device, weights_only=False)
    except TypeError:
        ckpt = torch.load(args.checkpoint, map_location=device)
    ckpt_args = ckpt.get("args", {}) if isinstance(ckpt, dict) else {}
    if isinstance(ckpt_args, dict):
        for key in ("_shadow_global_direction_deg", "shadow_gt_global_direction_deg", "shadow_pred_global_direction_deg"):
            if key in ckpt_args and ckpt_args[key] is not None and getattr(args, key, None) is None:
                setattr(args, key, float(ckpt_args[key]))
    base = int(ckpt.get("model_base", getattr(args, "model_base", 32)))
    in_ch = int(ckpt.get("in_ch", 9))
    out_ch = int(ckpt.get("out_ch", 1))
    ckpt_mode = str(ckpt.get("shadow_refine_mode", "opacity" if out_ch == 1 else "image") or "opacity").lower().strip()
    setattr(args, "_model_in_ch", in_ch)
    setattr(args, "_model_out_ch", out_ch)
    setattr(args, "_checkpoint_shadow_refine_mode", ckpt_mode)
    model = AzimuthShadowUNet(in_ch=in_ch, base=base, padding_mode=str(getattr(args, "conv_padding_mode", "reflect")), out_ch=out_ch).to(device)
    _load_state_dict_compatible(model, ckpt["model"], "checkpoint")
    model.eval()
    return model


def _load_recognition_model(checkpoint: str | Path, args, device: torch.device) -> tuple[AzimuthShadowUNet, argparse.Namespace]:
    try:
        ckpt = torch.load(checkpoint, map_location=device, weights_only=False)
    except TypeError:
        ckpt = torch.load(checkpoint, map_location=device)
    ckpt_args = ckpt.get("args", {}) if isinstance(ckpt, dict) else {}
    rec_args = copy.copy(args)
    apply_overrides = {
        key: getattr(args, key)
        for key in (
            "apply_mask_source",
            "apply_target_dir",
            "target_mask_dir",
            "render_dir",
            "output_dir",
            "save_maps",
            "device",
        )
        if hasattr(args, key)
    }
    if isinstance(ckpt_args, dict):
        for key, value in ckpt_args.items():
            setattr(rec_args, key, value)
    for key, value in apply_overrides.items():
        setattr(rec_args, key, value)
    base = int(ckpt.get("model_base", getattr(rec_args, "model_base", 32)))
    in_ch = int(ckpt.get("in_ch", 9))
    out_ch = int(ckpt.get("out_ch", 1))
    if out_ch != 1:
        raise ValueError(f"Recognition checkpoint must be an opacity model with out_ch=1, got {out_ch}: {checkpoint}")
    setattr(rec_args, "_model_in_ch", in_ch)
    setattr(rec_args, "_model_out_ch", out_ch)
    setattr(rec_args, "_checkpoint_shadow_refine_mode", "opacity")
    model = AzimuthShadowUNet(
        in_ch=in_ch,
        base=base,
        padding_mode=str(getattr(rec_args, "conv_padding_mode", "reflect")),
        out_ch=out_ch,
    ).to(device)
    _load_state_dict_compatible(model, ckpt["model"], "recognition checkpoint")
    model.eval()
    return model, rec_args


def _postprocess_opacity_prediction(raw: torch.Tensor, imaps: dict[str, torch.Tensor], target_mask: torch.Tensor, args) -> torch.Tensor:
    pred = torch.sigmoid(raw)[0, 0] * imaps["candidate"]
    gain = max(float(getattr(args, "shadow_output_gain", 1.0) or 1.0), 0.0)
    if gain != 1.0:
        pred = pred * gain
    prior = min(max(float(getattr(args, "shadow_candidate_prior_strength", 0.0) or 0.0), 0.0), 1.0)
    if prior > 0.0:
        pred = torch.maximum(pred, imaps.get("direction_prior", imaps["candidate"]) * prior)
    dilate = int(getattr(args, "shadow_output_dilate", 0) or 0)
    if dilate > 0:
        pred = _dilate01_batch(pred[None], dilate)[0] * (imaps["support"] > 0.001).float()
    blur = int(getattr(args, "shadow_output_blur", 1) or 0)
    if blur > 0:
        pred = _blur01(pred, blur) * imaps["candidate"]
    gamma = max(float(getattr(args, "shadow_output_gamma", 1.0) or 1.0), 0.05)
    pred = pred.clamp(0.0, 1.0).pow(gamma)
    pred = _floor_shadow_mask_opacity(pred, args)
    if bool(getattr(args, "shadow_pred_component_filter", True)):
        pred_gate = _connected_shadow_component_mask(
            pred,
            target_mask,
            (imaps["support"] > 0.001).float(),
            args,
            prefix="shadow_pred",
        )
        filtered_pred = (pred * pred_gate).clamp(0.0, 1.0)
        if float(filtered_pred.sum().detach().cpu()) > 1e-6:
            pred = filtered_pred
    return pred.clamp(0.0, 1.0)


def _apply_mask_from_sources(render: torch.Tensor, target_source: torch.Tensor, args) -> tuple[torch.Tensor, torch.Tensor, dict[str, torch.Tensor] | None]:
    mask_source_mode = str(getattr(args, "apply_mask_source", "target") or "target").lower().strip()
    mask_source = render if mask_source_mode == "render" else target_source
    visibility_maps = None
    if str(getattr(args, "target_mask_mode", "legacy") or "legacy").lower().strip() == "render_visibility":
        visibility_maps = _render_visibility_masks(render, target_source, args)
        mask = visibility_maps["core_mask"]
    else:
        mask = _target_mask(mask_source, args)
    max_ratio = float(getattr(args, "shadow_train_target_mask_max_ratio", 0.35) or 0.35)
    if max_ratio > 0.0 and float(mask.float().mean().detach().cpu()) >= max_ratio:
        repaired = _repair_shadow_train_target_mask(target_source, _target_mask(target_source, args), args)
        if float(repaired.sum().detach().cpu()) >= float(getattr(args, "target_mask_min_pixels", 16.0) or 16.0):
            mask = repaired
    return mask.clamp(0.0, 1.0), mask_source, visibility_maps


def _load_saved_recognition_maps(
    map_dir: Path,
    stem: str,
    size_hw: tuple[int, int],
    args,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor] | None:
    target_path = map_dir / f"{stem}_target_mask.png"
    background_path = map_dir / f"{stem}_background_mask.png"
    opacity_path = map_dir / f"{stem}_azimuth_shadow_opacity.png"
    if not target_path.exists():
        return None

    target = _resize_chw(_load_image(target_path, args).to(device), size_hw)[0].float().clamp(0.0, 1.0)
    if background_path.exists():
        background = _resize_chw(_load_image(background_path, args).to(device), size_hw)[0].float().clamp(0.0, 1.0)
        non_background = (background < 0.5).to(dtype=target.dtype)
        shadow = (non_background * (1.0 - (target > 0.5).to(dtype=target.dtype))).clamp(0.0, 1.0)
        return target, shadow
    if opacity_path.exists():
        opacity = _resize_chw(_load_image(opacity_path, args).to(device), size_hw)[0].float().clamp(0.0, 1.0)
        threshold = min(max(float(getattr(args, "shadow_recognition_threshold", 0.4) or 0.4), 0.0), 1.0)
        shadow = ((opacity >= threshold).to(dtype=target.dtype) * (1.0 - (target > 0.5).to(dtype=target.dtype))).clamp(0.0, 1.0)
        return target, shadow
    return None


def _recognition_shadow_gate(
    shadow_mask: torch.Tensor,
    args,
    target_mask: torch.Tensor | None = None,
) -> torch.Tensor:
    default_threshold = float(getattr(args, "shadow_recognition_threshold", 0.4) or 0.4)
    threshold = min(max(float(getattr(args, "shadow_recognition_gate_threshold", default_threshold) or default_threshold), 0.0), 1.0)
    gate = shadow_mask.float().clamp(0.0, 1.0)
    if target_mask is not None:
        target = _chw1(target_mask).to(device=gate.device, dtype=gate.dtype)[0].clamp(0.0, 1.0)
        gate = gate * (1.0 - (target > 0.5).to(dtype=gate.dtype))
    return (gate >= threshold).to(dtype=shadow_mask.dtype)


def _shadow_apply_alpha_from_gate(gate: torch.Tensor, args) -> torch.Tensor:
    hard = gate.float().clamp(0.0, 1.0)
    alpha = hard
    blur = max(int(getattr(args, "shadow_apply_feather_blur", 2) or 0), 0)
    if blur <= 0 or float(alpha.sum().detach().cpu()) <= 0.0:
        return alpha
    alpha = (_blur01(alpha, blur) * hard).clamp(0.0, 1.0)
    core = min(max(float(getattr(args, "shadow_apply_feather_core", 0.85) or 0.0), 0.0), 1.0)
    if core > 0.0:
        alpha = torch.maximum(alpha, hard * core).clamp(0.0, 1.0)
    return alpha


def _apply(args) -> None:
    device = torch.device(args.device if torch.cuda.is_available() or str(args.device) == "cpu" else "cpu")
    _configure_torch(args, device)
    model = _load_model(args, device)
    _configure_shadow_shape_prior(args, getattr(args, "train_gt_dir", None))
    recognition_model = None
    recognition_args = None
    recognition_checkpoint = getattr(args, "shadow_recognition_checkpoint", None)
    if recognition_checkpoint:
        recognition_model, recognition_args = _load_recognition_model(recognition_checkpoint, args, device)
        print(f"[azimuth shadow] recognition checkpoint: {recognition_checkpoint}")
    recognition_map_dir = Path(args.shadow_recognition_map_dir) if getattr(args, "shadow_recognition_map_dir", None) else None
    if recognition_map_dir is not None:
        print(f"[azimuth shadow] recognition maps: {recognition_map_dir}")
    refine_mode = str(getattr(args, "_checkpoint_shadow_refine_mode", getattr(args, "shadow_refine_mode", "opacity")) or "opacity").lower().strip()
    render_dir = Path(args.render_dir)
    target_dir = Path(args.apply_target_dir or args.target_mask_dir or render_dir)
    output_dir = Path(args.output_dir)
    render_out = output_dir / "renders"
    maps_dir = output_dir / "maps"
    render_out.mkdir(parents=True, exist_ok=True)
    if bool(args.save_maps):
        maps_dir.mkdir(parents=True, exist_ok=True)
    targets = _candidates(target_dir)
    target_by_stem = {t["path"].stem: t for t in targets}
    target_by_az = targets
    count = 0
    for render_path in tqdm(_image_files(render_dir), desc="apply azimuth shadow", unit="img"):
        render = _load_image(render_path, args).to(device)
        az = _parse_azimuth(render_path)
        titem = target_by_stem.get(render_path.stem) or _nearest(target_by_az, az)
        target_source = _resize_chw(_load_image(titem["path"], args).to(device), tuple(render.shape[-2:]))
        mask, mask_source, visibility_maps = _apply_mask_from_sources(render, target_source, args)
        network_source = render if bool(getattr(args, "apply_use_render_input", True)) else target_source
        carrier_render = _apply_shadow_carrier_background(render, mask, args)
        carrier_source = _apply_shadow_carrier_background(network_source, mask, args)
        recognition_target = mask
        recognition_shadow = None
        with torch.no_grad():
            x, imaps = _input_tensor(carrier_source, mask, az, args, in_ch=int(getattr(args, "_model_in_ch", 10)))
            raw = model(x[None])
            if refine_mode == "image":
                image_support = _image_refine_support(mask, imaps, args)
                out, image_maps = _compose_image_refine(raw, carrier_render[None], image_support[None], args, target_mask=mask[None])
                out = out[0]
                pred = image_maps["extinction"][0, 0].clamp(0.0, 1.0)
            else:
                pred = _postprocess_opacity_prediction(raw, imaps, mask, args)
                out = _apply_shadow(carrier_render, pred, args)
            saved_recognition = (
                _load_saved_recognition_maps(recognition_map_dir, render_path.stem, tuple(render.shape[-2:]), args, device)
                if recognition_map_dir is not None
                else None
            )
            if saved_recognition is not None:
                recognition_target, recognition_shadow = saved_recognition
            elif recognition_model is not None and recognition_args is not None:
                rec_mask, _rec_mask_source, _rec_visibility_maps = _apply_mask_from_sources(render, target_source, recognition_args)
                rec_network_source = render if bool(getattr(recognition_args, "apply_use_render_input", True)) else target_source
                rec_carrier_source = _apply_shadow_carrier_background(rec_network_source, rec_mask, recognition_args)
                rec_x, rec_imaps = _input_tensor(
                    rec_carrier_source,
                    rec_mask,
                    az,
                    recognition_args,
                    in_ch=int(getattr(recognition_args, "_model_in_ch", 10)),
                )
                rec_raw = recognition_model(rec_x[None])
                recognition_target = rec_mask
                recognition_shadow = _postprocess_opacity_prediction(rec_raw, rec_imaps, rec_mask, recognition_args)
            if recognition_shadow is None:
                recognition_shadow = _shadow_recognition_mask(mask, imaps, pred.clamp(0.0, 1.0), image_maps if refine_mode == "image" else None, args, azimuth=az)
            final_shadow_mask = _recognition_shadow_gate(recognition_shadow, args, target_mask=recognition_target).to(device=out.device, dtype=out.dtype)
            if bool(getattr(args, "shadow_geometry_extent_apply_to_recognition", True)):
                final_geometry_gate = _shadow_geometry_extent_gate(recognition_target, az, args).to(device=out.device, dtype=out.dtype)
                final_shadow_mask = (final_shadow_mask * final_geometry_gate).clamp(0.0, 1.0)
            shadow_apply_alpha = _shadow_apply_alpha_from_gate(final_shadow_mask, args).to(device=out.device, dtype=out.dtype)
            apply_gate = None
            if bool(getattr(args, "shadow_apply_recognition_mask", True)):
                apply_gate = shadow_apply_alpha
                if refine_mode == "image":
                    gate3 = apply_gate.unsqueeze(0)
                    out = (carrier_render * (1.0 - gate3) + out * gate3).clamp(0.0, 1.0)
                    pred = final_shadow_mask.clamp(0.0, 1.0)
                    if image_maps is not None and "compose_alpha" in image_maps:
                        image_maps["compose_alpha"] = (image_maps["compose_alpha"] * gate3[None]).clamp(0.0, 1.0)
                else:
                    pred = (pred * apply_gate).clamp(0.0, 1.0)
                    out = _apply_shadow(carrier_render, pred, args)
            if visibility_maps is not None:
                out = _cleanup_residual_layover(out, visibility_maps["residual_layover_mask"], args)
            out = _force_grayscale_chw(out, args)
        torchvision.utils.save_image(out.clamp(0.0, 1.0), str(render_out / render_path.name))
        if bool(args.save_maps):
            stem = render_path.stem
            torchvision.utils.save_image(pred[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_azimuth_shadow_opacity.png"))
            torchvision.utils.save_image(imaps["candidate"][None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_azimuth_shadow_candidate.png"))
            torchvision.utils.save_image(imaps.get("direction_prior", imaps["candidate"])[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_azimuth_shadow_direction_prior.png"))
            torchvision.utils.save_image(imaps.get("geometry_extent_gate", torch.ones_like(mask))[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_geometry_extent_gate.png"))
            torchvision.utils.save_image(imaps.get("shape_prior", torch.zeros_like(mask))[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_shape_prior.png"))
            if bool(getattr(args, "shadow_joint_mask_refiner", False)):
                torchvision.utils.save_image(imaps.get("joint_mask", torch.zeros_like(mask))[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_joint_mask.png"))
            if bool(getattr(args, "shadow_include_target", False)):
                torchvision.utils.save_image(imaps.get("target_overlap", torch.zeros_like(mask))[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_overlap_candidate.png"))
            torchvision.utils.save_image(mask[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_mask.png"))
            if visibility_maps is not None:
                torchvision.utils.save_image(visibility_maps["core_mask"][None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_core_mask.png"))
                torchvision.utils.save_image(visibility_maps["refiner_mask"][None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_refiner_mask.png"))
                torchvision.utils.save_image(visibility_maps["visible_mask"][None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_target_visible_mask.png"))
                torchvision.utils.save_image(visibility_maps["residual_layover_mask"][None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_residual_layover_mask.png"))
            torchvision.utils.save_image(mask_source.clamp(0.0, 1.0), str(maps_dir / f"{stem}_mask_source.png"))
            torchvision.utils.save_image(render.clamp(0.0, 1.0), str(maps_dir / f"{stem}_pre_shadow_render.png"))
            if str(getattr(args, "shadow_carrier_background", "none") or "none").lower().strip() != "none":
                torchvision.utils.save_image(carrier_render.clamp(0.0, 1.0), str(maps_dir / f"{stem}_shadow_carrier_render.png"))
                torchvision.utils.save_image(_shadow_carrier_alpha(mask, args)[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_shadow_carrier_alpha.png"))
            if refine_mode == "image":
                torchvision.utils.save_image(image_support[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_image_support.png"))
                torchvision.utils.save_image(image_maps["delta_log"][0].abs().clamp(0.0, 1.0), str(maps_dir / f"{stem}_delta_log_abs.png"))
                torchvision.utils.save_image(image_maps["gain_log"][0].abs().clamp(0.0, 1.0), str(maps_dir / f"{stem}_gain_log_abs.png"))
                torchvision.utils.save_image(image_maps["compose_alpha_pre_component"][0].clamp(0.0, 1.0), str(maps_dir / f"{stem}_compose_alpha_pre_component.png"))
                torchvision.utils.save_image(image_maps["compose_alpha"][0].clamp(0.0, 1.0), str(maps_dir / f"{stem}_compose_alpha.png"))
                torchvision.utils.save_image(image_maps["component_gate_raw"][0].clamp(0.0, 1.0), str(maps_dir / f"{stem}_component_gate_raw.png"))
                torchvision.utils.save_image(image_maps["component_gate"][0].clamp(0.0, 1.0), str(maps_dir / f"{stem}_component_gate.png"))
            if apply_gate is not None:
                torchvision.utils.save_image(apply_gate[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_shadow_apply_recognition_gate.png"))
            torchvision.utils.save_image(final_shadow_mask[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_final_shadow_mask.png"))
            torchvision.utils.save_image(shadow_apply_alpha[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_shadow_apply_alpha.png"))
            cls_rgb, bg_mask = _region_classification_rgb(
                recognition_target,
                final_shadow_mask,
                shadow_threshold=float(getattr(args, "shadow_recognition_threshold", 0.4) or 0.4),
            )
            torchvision.utils.save_image(cls_rgb, str(maps_dir / f"{stem}_region_classification.png"))
            torchvision.utils.save_image(recognition_shadow[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_shadow_recognition_mask.png"))
            if recognition_model is not None or recognition_map_dir is not None:
                torchvision.utils.save_image(recognition_target[None].clamp(0.0, 1.0), str(maps_dir / f"{stem}_recognition_target_mask.png"))
            torchvision.utils.save_image(bg_mask, str(maps_dir / f"{stem}_background_mask.png"))
        count += 1
    print(f"[azimuth shadow] applied {count} images -> {render_out}")


def main() -> int:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("-m", "--model_path", type=str, default=None)
    parser.add_argument("--train_target_dir", type=str, default=None)
    parser.add_argument("--train_gt_dir", type=str, default=None)
    parser.add_argument("--train_mask_target_dir", type=str, default=None)
    parser.add_argument("--apply_target_dir", type=str, default=None)
    parser.add_argument("--target_mask_dir", type=str, default=None)
    parser.add_argument("--render_dir", type=str, default=None)
    parser.add_argument("--output_dir", type=str, default=None)
    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--apply_use_render_input", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--apply_mask_source", choices=["target", "render"], default="target")
    parser.add_argument("--apply_only", action="store_true", default=False)
    parser.add_argument("--train_only", action="store_true", default=False)
    parser.add_argument("--iterations", type=int, default=2500)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--model_base", type=int, default=32)
    parser.add_argument("--conv_padding_mode", choices=["reflect", "replicate", "zeros"], default="reflect")
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--allow_tf32", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--cudnn_benchmark", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--progress_interval", type=int, default=50)
    parser.add_argument("--train_azimuth_step", type=float, default=10.0)
    parser.add_argument("--train_use_all_targets", action="store_true", default=False)
    parser.add_argument("--cache_training_pairs", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--log_scale", type=float, default=20.0)
    parser.add_argument("--shadow_refine_mode", choices=["image", "opacity"], default="opacity")
    parser.add_argument("--target_mask_threshold", type=float, default=0.08)
    parser.add_argument("--target_mask_quantile", type=float, default=0.35)
    parser.add_argument("--target_mask_dilate", type=int, default=0)
    parser.add_argument("--target_mask_min_pixels", type=float, default=16.0)
    parser.add_argument(
        "--target_mask_mode",
        choices=[
            "legacy",
            "filter_background",
            "render_visibility",
            "scatter95_largest",
            "binary",
            "semantic",
            "semantic_binary",
        ],
        default="scatter95_largest",
    )
    parser.add_argument("--target_mask_filter_percentile", type=float, default=95.0)
    parser.add_argument("--target_mask_filter_largest_cc", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--target_mask_filter_min_target_ratio", type=float, default=0.0005)
    parser.add_argument("--target_mask_filter_max_target_ratio", type=float, default=0.0)
    parser.add_argument("--target_mask_filter_adaptive_max_percentile", type=float, default=98.0)
    parser.add_argument("--target_mask_filter_erode_px", type=int, default=0)
    parser.add_argument("--target_mask_visibility_refiner_percentile", type=float, default=0.0)
    parser.add_argument("--target_mask_visibility_dilate", type=int, default=1)
    parser.add_argument("--residual_layover_cleanup_strength", type=float, default=0.55)
    parser.add_argument("--residual_layover_cleanup_ceiling", type=float, default=0.04)
    parser.add_argument("--residual_layover_cleanup_blur", type=int, default=1)
    parser.add_argument("--shadow_candidate_length", type=int, default=40)
    parser.add_argument("--shadow_candidate_decay", type=float, default=18.0)
    parser.add_argument("--shadow_candidate_lateral_blur", type=int, default=5)
    parser.add_argument("--shadow_direction_offset_deg", type=float, default=180.0)
    parser.add_argument("--shadow_direction_sign", type=float, default=1.0)
    parser.add_argument("--shadow_shape_prior_mode", choices=["none", "neighbor_gt", "semantic", "hybrid", "semantic_neighbor"], default="none")
    parser.add_argument("--shadow_shape_prior_gt_dir", type=str, default=None)
    parser.add_argument("--shadow_shape_prior_weight", type=float, default=0.65)
    parser.add_argument("--shadow_shape_prior_threshold", type=float, default=0.05)
    parser.add_argument("--shadow_shape_prior_mix_mode", choices=["weighted_mean", "weighted_max"], default="weighted_mean")
    parser.add_argument("--shadow_shape_prior_min_pixels", type=float, default=4.0)
    parser.add_argument("--shadow_semantic_mask_dir", type=str, default=None)
    parser.add_argument("--shadow_semantic_mask_run", type=str, default="latest")
    parser.add_argument("--shadow_supervision_source", choices=["semantic_gt", "heuristic_gt"], default="semantic_gt")
    parser.add_argument("--shadow_semantic_target_labels", type=str, default="1,2")
    parser.add_argument("--shadow_semantic_shadow_label", type=int, default=3)
    parser.add_argument("--shadow_semantic_supervision_mix", type=float, default=1.0)
    parser.add_argument("--shadow_semantic_dilate", type=int, default=0)
    parser.add_argument("--shadow_semantic_blur", type=int, default=0)
    parser.add_argument("--shadow_target_protect_dilate", type=int, default=1)
    parser.add_argument("--shadow_search_dilate", type=int, default=65)
    parser.add_argument("--shadow_target_exclude_dilate", type=int, default=1)
    parser.add_argument("--shadow_include_target", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_target_overlap_weight", type=float, default=0.55)
    parser.add_argument("--shadow_target_overlap_dark_threshold", type=float, default=0.12)
    parser.add_argument("--shadow_target_overlap_quantile", type=float, default=0.35)
    parser.add_argument("--shadow_target_overlap_dilate", type=int, default=0)
    parser.add_argument(
        "--shadow_train_mask_mode",
        choices=["support", "candidate", "candidate_hard", "gt_background_black", "candidate_gt_background_black"],
        default="support",
    )
    parser.add_argument("--shadow_train_mask_threshold", type=float, default=0.01)
    parser.add_argument("--shadow_train_mask_dilate", type=int, default=0)
    parser.add_argument("--shadow_train_repair_empty_candidate", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--shadow_train_target_mask_max_ratio", type=float, default=0.35)
    parser.add_argument("--shadow_train_min_candidate_pixels", type=float, default=8.0)
    parser.add_argument("--shadow_fail_on_empty_supervision", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--shadow_supervision_mode", choices=["gt_shadow", "source_to_gt", "mixed"], default="gt_shadow")
    parser.add_argument("--shadow_source_gt_min_gap", type=float, default=0.010)
    parser.add_argument("--shadow_source_gt_softness", type=float, default=0.10)
    parser.add_argument("--shadow_source_gt_blur", type=int, default=1)
    parser.add_argument("--shadow_source_gt_gamma", type=float, default=1.0)
    parser.add_argument("--shadow_source_gt_mix", type=float, default=0.65)
    parser.add_argument("--shadow_joint_mask_refiner", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_joint_mask_threshold", type=float, default=0.05)
    parser.add_argument("--shadow_joint_mask_connect_radius", type=int, default=12)
    parser.add_argument("--shadow_joint_mask_bbox_fill", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_joint_mask_dilate", type=int, default=0)
    parser.add_argument("--shadow_joint_mask_weight", type=float, default=1.0)
    parser.add_argument("--shadow_joint_target_min_gap", type=float, default=0.015)
    parser.add_argument("--shadow_joint_target_softness", type=float, default=0.10)
    parser.add_argument("--shadow_joint_target_mix", type=float, default=1.0)
    parser.add_argument("--shadow_joint_target_blur", type=int, default=1)
    parser.add_argument("--shadow_gt_dark_threshold", type=float, default=0.18)
    parser.add_argument("--shadow_gt_ratio_threshold", type=float, default=0.16)
    parser.add_argument("--shadow_gt_low_percentile", type=float, default=5.0)
    parser.add_argument("--shadow_gt_use_global_direction", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--shadow_gt_global_direction_deg", type=float, default=None)
    parser.add_argument("--shadow_gt_global_direction_tolerance_deg", type=float, default=65.0)
    parser.add_argument("--shadow_gt_ratio_mix", type=float, default=0.70)
    parser.add_argument("--shadow_gt_context_blur", type=int, default=21)
    parser.add_argument("--shadow_gt_soft_blur", type=int, default=1)
    parser.add_argument("--shadow_gt_gamma", type=float, default=1.0)
    parser.add_argument("--shadow_gt_anchor_threshold", type=float, default=0.12)
    parser.add_argument("--shadow_gt_anchor_quantile", type=float, default=0.95)
    parser.add_argument("--shadow_gt_anchor_fallback_quantile", type=float, default=0.90)
    parser.add_argument("--shadow_gt_anchor_min_pixels", type=float, default=12.0)
    parser.add_argument("--shadow_gt_anchor_search_dilate", type=int, default=0)
    parser.add_argument("--shadow_gt_anchor_dilate", type=int, default=2)
    parser.add_argument("--shadow_gt_anchor_render_mask_mix", type=float, default=0.0)
    parser.add_argument("--shadow_gt_component_filter", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_gt_component_threshold", type=float, default=0.22)
    parser.add_argument("--shadow_gt_component_score_min", type=float, default=0.34)
    parser.add_argument("--shadow_gt_min_component_area_ratio", type=float, default=0.08)
    parser.add_argument("--shadow_gt_max_component_area_ratio", type=float, default=2.5)
    parser.add_argument("--shadow_gt_min_component_pixels", type=float, default=8.0)
    parser.add_argument("--shadow_gt_max_components", type=int, default=1)
    parser.add_argument("--shadow_gt_direction_tolerance_deg", type=float, default=55.0)
    parser.add_argument("--shadow_gt_contact_dilate", type=int, default=4)
    parser.add_argument("--shadow_gt_component_open", type=int, default=1)
    parser.add_argument("--shadow_gt_component_density_radius", type=int, default=2)
    parser.add_argument("--shadow_gt_component_min_density", type=float, default=0.22)
    parser.add_argument("--shadow_gt_component_min_bbox_density", type=float, default=0.12)
    parser.add_argument("--shadow_gt_component_grow", type=int, default=0)
    parser.add_argument("--shadow_gt_component_grow_threshold", type=float, default=None)
    parser.add_argument(
        "--shadow_candidate_mode",
        choices=["directional", "directional_prior", "fixed_direction", "fixed_direction_prior"],
        default="directional_prior",
    )
    parser.add_argument("--shadow_fixed_direction_deg", type=float, default=None)
    parser.add_argument("--shadow_gt_auto_fixed_direction_gate", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_gt_use_fixed_direction_gate", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_gt_fixed_direction_min_concentration", type=float, default=0.90)
    parser.add_argument("--shadow_gt_fixed_direction_gate_tolerance_deg", type=float, default=28.0)
    parser.add_argument("--shadow_gt_fixed_direction_gate_min_dist", type=float, default=1.0)
    parser.add_argument("--shadow_gt_fixed_direction_gate_max_width", type=float, default=0.0)
    parser.add_argument("--shadow_gt_low_seed_min_evidence", type=float, default=0.0)
    parser.add_argument("--shadow_gt_fixed_direction_fallback", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_gt_fixed_direction_fallback_tolerance_deg", type=float, default=35.0)
    parser.add_argument("--shadow_gt_fixed_direction_fallback_threshold", type=float, default=0.10)
    parser.add_argument("--shadow_gt_fixed_direction_fallback_components", type=int, default=1)
    parser.add_argument("--shadow_gt_fixed_direction_fallback_grow", type=int, default=1)
    parser.add_argument("--shadow_geometry_extent_gate", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_geometry_extent_apply_to_recognition", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_geometry_extent_require_dataset_direction", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_geometry_extent_forward_scale", type=float, default=1.0)
    parser.add_argument("--shadow_geometry_extent_lateral_scale", type=float, default=1.0)
    parser.add_argument("--shadow_geometry_extent_margin_px", type=float, default=1.5)
    parser.add_argument("--shadow_geometry_extent_min_forward_px", type=float, default=0.0)
    parser.add_argument("--shadow_candidate_supervision_mix", type=float, default=1.0)
    parser.add_argument("--shadow_bce_weight", type=float, default=0.45)
    parser.add_argument("--shadow_dice_weight", type=float, default=0.85)
    parser.add_argument("--shadow_l1_weight", type=float, default=0.55)
    parser.add_argument("--shadow_render_l1_weight", type=float, default=0.0)
    parser.add_argument("--shadow_area_weight", type=float, default=0.35)
    parser.add_argument("--shadow_leak_weight", type=float, default=0.05)
    parser.add_argument("--shadow_positive_weight", type=float, default=4.0)
    parser.add_argument("--shadow_negative_weight", type=float, default=0.15)
    parser.add_argument("--shadow_apply_strength", type=float, default=0.95)
    parser.add_argument("--shadow_apply_max_darken", type=float, default=0.92)
    parser.add_argument("--shadow_apply_floor", type=float, default=0.0)
    parser.add_argument("--shadow_apply_mode", choices=["multiply", "subtract", "ceiling"], default="multiply")
    parser.add_argument("--shadow_apply_subtract", type=float, default=0.20)
    parser.add_argument("--shadow_apply_ceiling", type=float, default=0.025)
    parser.add_argument("--shadow_apply_recognition_mask", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_recognition_gate_threshold", type=float, default=0.4)
    parser.add_argument("--shadow_apply_feather_blur", type=int, default=4)
    parser.add_argument("--shadow_apply_feather_core", type=float, default=0.80)
    parser.add_argument("--shadow_carrier_background", choices=["none", "constant", "constant_rgb"], default="none")
    parser.add_argument("--shadow_carrier_value", type=float, default=0.85)
    parser.add_argument("--shadow_carrier_color", type=str, default="1.0,0.85,0.05")
    parser.add_argument("--shadow_carrier_target_dilate", type=int, default=1)
    parser.add_argument("--shadow_carrier_target_blur", type=int, default=1)
    parser.add_argument("--shadow_input_color_channels", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_image_support_dilate", type=int, default=0)
    parser.add_argument("--shadow_image_use_joint_mask", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_image_include_full_target", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_image_delta_log_scale", type=float, default=0.28)
    parser.add_argument("--shadow_image_bright_log_scale", type=float, default=0.20)
    parser.add_argument("--shadow_image_extinction_log_strength", type=float, default=0.42)
    parser.add_argument("--shadow_image_compose_alpha_mode", choices=["prediction", "support"], default="prediction")
    parser.add_argument("--shadow_image_compose_alpha_threshold", type=float, default=0.50)
    parser.add_argument("--shadow_image_compose_alpha_softness", type=float, default=0.15)
    parser.add_argument("--shadow_image_compose_alpha_floor", type=float, default=0.0)
    parser.add_argument("--shadow_image_compose_alpha_min_support_mean", type=float, default=0.0)
    parser.add_argument("--shadow_image_compose_blur", type=int, default=0)
    parser.add_argument("--shadow_image_detail_radius", type=int, default=2)
    parser.add_argument("--shadow_image_target_detail_preserve_weight", type=float, default=0.75)
    parser.add_argument("--shadow_image_shadow_detail_preserve_weight", type=float, default=0.35)
    parser.add_argument("--shadow_image_log_l1_weight", type=float, default=1.0)
    parser.add_argument("--shadow_image_log_mse_weight", type=float, default=0.15)
    parser.add_argument("--shadow_image_sar_ssim_weight", type=float, default=0.15)
    parser.add_argument("--shadow_image_sar_ssim_window", type=int, default=7)
    parser.add_argument("--shadow_image_gradient_weight", type=float, default=0.45)
    parser.add_argument("--shadow_image_dark_leak_weight", type=float, default=0.18)
    parser.add_argument("--shadow_image_target_l1_weight", type=float, default=0.12)
    parser.add_argument("--shadow_image_target_identity_weight", type=float, default=0.35)
    parser.add_argument("--shadow_image_target_identity_threshold_log", type=float, default=0.42)
    parser.add_argument("--shadow_image_outside_identity_weight", type=float, default=0.20)
    parser.add_argument("--shadow_image_extinction_reg_weight", type=float, default=0.02)
    parser.add_argument("--shadow_output_gain", type=float, default=2.0)
    parser.add_argument("--shadow_candidate_prior_strength", type=float, default=0.10)
    parser.add_argument("--shadow_output_dilate", type=int, default=1)
    parser.add_argument("--shadow_output_blur", type=int, default=2)
    parser.add_argument("--shadow_output_gamma", type=float, default=0.65)
    parser.add_argument("--shadow_output_mask_floor", type=float, default=0.0)
    parser.add_argument("--shadow_output_mask_threshold", type=float, default=0.05)
    parser.add_argument("--shadow_recognition_source", choices=["reference_connected", "legacy_opacity", "geometry", "shape_prior", "candidate", "prediction", "compose_alpha"], default="candidate")
    parser.add_argument("--shadow_recognition_checkpoint", type=str, default=None)
    parser.add_argument("--shadow_recognition_map_dir", type=str, default=None)
    parser.add_argument("--shadow_recognition_threshold", type=float, default=0.4)
    parser.add_argument("--shadow_recognition_connect_length", type=int, default=40)
    parser.add_argument("--shadow_recognition_connect_decay", type=float, default=24.0)
    parser.add_argument("--shadow_recognition_connect_blur", type=int, default=2)
    parser.add_argument("--shadow_recognition_min_evidence", type=float, default=0.05)
    parser.add_argument("--shadow_recognition_reference_blur", type=int, default=4)
    parser.add_argument("--shadow_recognition_context_blur", type=int, default=21)
    parser.add_argument("--shadow_recognition_reference_threshold", type=float, default=0.18)
    parser.add_argument("--shadow_recognition_ratio_mix", type=float, default=0.75)
    parser.add_argument("--shadow_pred_component_filter", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--shadow_pred_global_direction_deg", type=float, default=None)
    parser.add_argument("--shadow_pred_global_direction_tolerance_deg", type=float, default=65.0)
    parser.add_argument("--shadow_pred_component_threshold", type=float, default=0.08)
    parser.add_argument("--shadow_pred_component_score_min", type=float, default=0.28)
    parser.add_argument("--shadow_pred_min_component_area_ratio", type=float, default=0.06)
    parser.add_argument("--shadow_pred_max_component_area_ratio", type=float, default=2.5)
    parser.add_argument("--shadow_pred_min_component_pixels", type=float, default=8.0)
    parser.add_argument("--shadow_pred_max_components", type=int, default=1)
    parser.add_argument("--shadow_pred_direction_tolerance_deg", type=float, default=55.0)
    parser.add_argument("--shadow_pred_contact_dilate", type=int, default=4)
    parser.add_argument("--shadow_pred_component_open", type=int, default=1)
    parser.add_argument("--shadow_pred_component_density_radius", type=int, default=2)
    parser.add_argument("--shadow_pred_component_min_density", type=float, default=0.18)
    parser.add_argument("--shadow_pred_component_min_bbox_density", type=float, default=0.10)
    parser.add_argument("--shadow_pred_component_grow", type=int, default=0)
    parser.add_argument("--shadow_pred_component_grow_threshold", type=float, default=None)
    parser.add_argument("--shadow_pred_component_min_keep_ratio", type=float, default=0.0)
    parser.add_argument("--force_grayscale_output", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--save_maps", action=argparse.BooleanOptionalAction, default=False)
    args = parser.parse_args()

    if args.model_path:
        root = Path(args.model_path)
        args.train_target_dir = args.train_target_dir or str(root / "train_renders")
        args.train_gt_dir = args.train_gt_dir or str(root / "train_gt")
        args.apply_target_dir = args.apply_target_dir or str(root / "novel_target_only" / "target_renders")
        args.render_dir = args.render_dir or str(root / "novel_target_only" / "target_renders")
        args.output_dir = args.output_dir or str(root / "azimuth_shadow_refiner" / "apply")
        args.checkpoint = args.checkpoint or str(root / "azimuth_shadow_refiner" / "azimuth_shadow_refiner.pth")
    if not args.output_dir:
        args.output_dir = "azimuth_shadow_refiner_apply" if args.apply_only else "azimuth_shadow_refiner_train"
    if not args.checkpoint:
        args.checkpoint = str(Path(args.output_dir) / "azimuth_shadow_refiner.pth")

    if args.apply_only:
        if not args.render_dir:
            raise RuntimeError("--apply_only requires --render_dir")
        if not Path(args.checkpoint).is_file():
            raise RuntimeError(f"--apply_only requires checkpoint: {args.checkpoint}")
        _apply(args)
    else:
        if not args.train_target_dir or not args.train_gt_dir:
            raise RuntimeError("training requires --train_target_dir and --train_gt_dir")
        _train(args)
        if not args.train_only:
            _apply(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
