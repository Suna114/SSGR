# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
渲染并保存高斯泼溅模型的测试视角图像

功能：
1. 加载训练好的高斯泼溅模型
2. 渲染测试视角（或训练视角）
3. 保存渲染结果和原始图像到指定目录
4. 使用原始图像文件名保存，便于后续对比

使用方法：
    # 渲染测试视角
    python render_and_save.py -m ./output/model --iteration 30000
    
    # 渲染训练视角
    python render_and_save.py -m ./output/model --iteration 30000 --render_train
    
    # 指定输出目录
    python render_and_save.py -m ./output/model --iteration 30000 --output_dir ./rendered_images
"""

import torch
import os
from pathlib import Path
from tqdm import tqdm
import torchvision
import torchvision.transforms as tf
from argparse import ArgumentParser

from scene import Scene, GaussianModel
from gaussian_renderer import render
from utils.general_utils import safe_state
from arguments import ModelParams, PipelineParams, get_combined_args

try:
    from diff_gaussian_rasterization import SparseGaussianAdam
    SPARSE_ADAM_AVAILABLE = True
except:
    SPARSE_ADAM_AVAILABLE = False


def render_and_save_views(
    model_path,
    iteration,
    views,
    gaussians,
    pipeline,
    background,
    output_dir,
    use_trained_exp=False,
    separate_sh=False,
    use_sar_mode=False,
    use_original_filename=True
):
    """
    渲染视角并保存图像
    
    Args:
        model_path: 模型路径
        iteration: 迭代次数
        views: 视角列表
        gaussians: 高斯模型
        pipeline: 渲染管道参数
        background: 背景颜色
        output_dir: 输出目录
        use_trained_exp: 是否使用训练时的曝光
        separate_sh: 是否分离球谐函数
        use_sar_mode: 是否使用SAR渲染模式
        use_original_filename: 是否使用原始图像文件名
    """
    # 创建输出目录
    renders_dir = Path(output_dir) / "renders"
    gt_dir = Path(output_dir) / "gt"
    renders_dir.mkdir(parents=True, exist_ok=True)
    gt_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"渲染结果保存到: {renders_dir}")
    print(f"原始图像保存到: {gt_dir}")
    print(f"共 {len(views)} 个视角\n")
    
    with torch.no_grad():
        for idx, view in enumerate(tqdm(views, desc="渲染进度")):
            # 渲染图像
            use_sar_rendering = (use_sar_mode and 
                               hasattr(view, 'use_sar_rendering') and 
                               view.use_sar_rendering)
            
            render_result = render(
                view, 
                gaussians, 
                pipeline, 
                background, 
                use_trained_exp=use_trained_exp,
                separate_sh=separate_sh,
                sar_mode=use_sar_rendering
            )
            
            rendering = render_result["render"]
            gt_image = view.original_image[0:3, :, :].cuda()
            
            # 🔧 修复：确保渲染图像与原始图像尺寸一致
            # 渲染可能使用相机的原始分辨率，但原始图像可能是训练时的分辨率
            if rendering.shape[1:] != gt_image.shape[1:]:
                print(f"⚠️ 调整渲染图像尺寸: {rendering.shape[1:]} -> {gt_image.shape[1:]}")
                rendering = tf.resize(rendering, size=(gt_image.shape[1], gt_image.shape[2]))
            
            # 确保值范围在[0, 1]
            rendering = torch.clamp(rendering, 0.0, 1.0)
            gt_image = torch.clamp(gt_image, 0.0, 1.0)
            
            # 确定文件名
            if use_original_filename and hasattr(view, 'image_name'):
                # 使用原始图像文件名（不含路径）
                image_name = Path(view.image_name).stem + ".png"
            else:
                # 使用索引编号
                image_name = f"{idx:05d}.png"
            
            # 保存渲染结果
            render_path = renders_dir / image_name
            torchvision.utils.save_image(rendering, str(render_path))
            
            # 保存原始图像
            gt_path = gt_dir / image_name
            torchvision.utils.save_image(gt_image, str(gt_path))
    
    print(f"\n✅ 渲染完成！")
    print(f"   渲染结果: {renders_dir} ({len(views)} 张)")
    print(f"   原始图像: {gt_dir} ({len(views)} 张)")
    print(f"\n💡 提示: 可以使用以下命令进行对比:")
    print(f"   python compare_render_gt.py --render_dir {renders_dir} --gt_dir {gt_dir} --output_dir {output_dir}/comparison")


def main():
    parser = ArgumentParser(description="渲染并保存高斯泼溅模型的视角图像")
    
    # 模型参数
    model = ModelParams(parser, sentinel=True)
    pipeline = PipelineParams(parser)
    
    # 渲染参数
    parser.add_argument("--iteration", type=int, default=-1,
                       help="要加载的迭代次数（-1表示最新）")
    parser.add_argument("--output_dir", type=str, default=None,
                       help="输出目录（默认: model_path/rendered_images）")
    parser.add_argument("--render_train", action="store_true",
                       help="渲染训练视角（默认只渲染测试视角）")
    parser.add_argument("--render_test", action="store_true", default=True,
                       help="渲染测试视角（默认启用）")
    parser.add_argument("--no_render_test", dest="render_test", action="store_false",
                       help="不渲染测试视角")
    parser.add_argument("--use_index_filename", action="store_true",
                       help="使用索引编号作为文件名（默认使用原始图像文件名）")
    parser.add_argument("--quiet", action="store_true",
                       help="静默模式")
    
    args = get_combined_args(parser)
    
    print("=" * 80)
    print("高斯泼溅模型渲染工具")
    print("=" * 80)
    
    # 提取参数
    model_params = model.extract(args)
    pipeline_params = pipeline.extract(args)
    
    print(f"模型路径: {model_params.model_path}")
    iteration = getattr(args, 'iteration', -1)
    render_train = getattr(args, 'render_train', False)
    render_test = getattr(args, 'render_test', True)
    print(f"迭代次数: {iteration if iteration >= 0 else '最新'}")
    print(f"渲染训练视角: {'是' if render_train else '否'}")
    print(f"渲染测试视角: {'是' if render_test else '否'}")
    print("=" * 80 + "\n")
    
    # 初始化系统状态
    quiet = getattr(args, 'quiet', False)
    safe_state(quiet)
    
    # 确定输出目录
    # 使用getattr安全访问，因为get_combined_args可能没有包含所有参数
    output_dir_arg = getattr(args, 'output_dir', None)
    if output_dir_arg is None:
        output_dir = Path(model_params.model_path) / "rendered_images"
    else:
        output_dir = Path(output_dir_arg)
    
    # 加载场景和高斯模型
    print("加载模型...")
    gaussians = GaussianModel(model_params.sh_degree)
    iteration = getattr(args, 'iteration', -1)
    scene = Scene(model_params, gaussians, load_iteration=iteration, shuffle=False)
    
    # 确定背景颜色
    bg_color = [1, 1, 1] if model_params.white_background else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device="cuda")
    
    # 检查SAR模式
    use_sar_mode = getattr(model_params, 'sar_mode', False)
    
    # 渲染测试视角
    render_test = getattr(args, 'render_test', True)
    if render_test:
        test_views = scene.getTestCameras()
        if len(test_views) > 0:
            print(f"\n渲染测试视角 ({len(test_views)} 个)...")
            test_output_dir = output_dir / "test"
            render_and_save_views(
                model_params.model_path,
                scene.loaded_iter,
                test_views,
                gaussians,
                pipeline_params,
                background,
                test_output_dir,
                use_trained_exp=model_params.train_test_exp,
                separate_sh=SPARSE_ADAM_AVAILABLE,
                use_sar_mode=use_sar_mode,
                use_original_filename=not getattr(args, 'use_index_filename', False)
            )
        else:
            print("⚠️ 警告: 没有找到测试视角")
            print("💡 提示: 如果没有测试视角，可以使用 --render_train 渲染训练视角")
    
    # 渲染训练视角
    render_train = getattr(args, 'render_train', False)
    if render_train:
        train_views = scene.getTrainCameras()
        if len(train_views) > 0:
            print(f"\n渲染训练视角 ({len(train_views)} 个)...")
            train_output_dir = output_dir / "train"
            render_and_save_views(
                model_params.model_path,
                scene.loaded_iter,
                train_views,
                gaussians,
                pipeline_params,
                background,
                train_output_dir,
                use_trained_exp=model_params.train_test_exp,
                separate_sh=SPARSE_ADAM_AVAILABLE,
                use_sar_mode=use_sar_mode,
                use_original_filename=not getattr(args, 'use_index_filename', False)
            )
        else:
            print("⚠️ 警告: 没有找到训练视角")
    
    # 检查是否有任何视角被渲染
    render_test = getattr(args, 'render_test', True)
    render_train = getattr(args, 'render_train', False)
    
    if render_test and len(scene.getTestCameras()) == 0 and not render_train:
        print("\n" + "=" * 80)
        print("⚠️ 没有找到测试视角，也没有渲染训练视角")
        print("💡 建议: 使用 --render_train 渲染训练视角")
        print("=" * 80)
    else:
        print("\n" + "=" * 80)
        print("✅ 所有渲染任务完成！")
        print("=" * 80)


if __name__ == "__main__":
    main()
