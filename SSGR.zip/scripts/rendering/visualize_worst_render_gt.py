#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
将指定文件名的「渲染图 vs GT」并排保存，并输出 |render-GT| 误差图，便于看斑点/亮度差异。

示例:
  python visualize_worst_render_gt.py \\
    --render_dir output/124/rendered_images/train/renders \\
    --gt_dir output/124/rendered_images/train/gt \\
    --output_dir output/124/worst_views_compare
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

try:
    from PIL import Image
except ImportError:
    raise SystemExit("需要 Pillow: pip install Pillow")


DEFAULT_WORST = [
    "T72-15-074.png",
    "T72-15-319.png",
    "T72-15-033.png",
    "T72-15-299.png",
]


def load_rgb(path: Path) -> np.ndarray:
    img = Image.open(path).convert("RGB")
    arr = np.asarray(img).astype(np.float32)
    if arr.max() > 1.5:
        arr = arr / 255.0
    return arr


def resize_to(ref: np.ndarray, src: np.ndarray) -> np.ndarray:
    if ref.shape[:2] == src.shape[:2]:
        return src
    from PIL import Image as PILImage

    h, w = ref.shape[0], ref.shape[1]
    u8 = (np.clip(src, 0, 1) * 255).astype(np.uint8)
    pil = PILImage.fromarray(u8).resize((w, h), PILImage.Resampling.BILINEAR)
    return np.asarray(pil).astype(np.float32) / 255.0


def main():
    p = argparse.ArgumentParser(description="并排保存 render 与 GT + 误差图")
    p.add_argument("--render_dir", type=str, required=True)
    p.add_argument("--gt_dir", type=str, required=True)
    p.add_argument("--output_dir", type=str, default="worst_views_compare")
    p.add_argument("--names", nargs="*", default=None, help="文件名列表；默认 074/319/033/299")
    args = p.parse_args()

    render_dir = Path(args.render_dir)
    gt_dir = Path(args.gt_dir)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    names = args.names if args.names else DEFAULT_WORST

    print(f"输出目录: {out_dir.resolve()}")
    print("左=渲染 render，右=GT；另存 *_diff.png 为灰度绝对误差（越亮=差异越大）。\n")

    for name in names:
        rp = render_dir / name
        gp = gt_dir / name
        if not rp.is_file():
            print(f"⚠️ 跳过（无渲染）: {rp}")
            continue
        if not gp.is_file():
            print(f"⚠️ 跳过（无 GT）: {gp}")
            continue

        render = load_rgb(rp)
        gt = load_rgb(gp)
        gt = resize_to(render, gt)

        h, w, _ = render.shape
        gap = np.ones((h, 6, 3), dtype=np.float32) * 0.35
        pair = np.concatenate([render, gap, gt], axis=1)
        pair_u8 = (np.clip(pair, 0, 1) * 255).astype(np.uint8)
        stem = Path(name).stem
        out_pair = out_dir / f"compare_{stem}.png"
        Image.fromarray(pair_u8).save(out_pair)

        diff = np.abs(render - gt).mean(axis=-1)
        mae = float(diff.mean())
        # 误差可视化：放大便于看
        diff_vis = np.stack([diff, diff, diff], axis=-1)
        diff_u8 = (np.clip(diff_vis / (diff.max() + 1e-8), 0, 1) * 255).astype(np.uint8)
        out_diff = out_dir / f"diff_{stem}.png"
        Image.fromarray(diff_u8).save(out_diff)

        print(f"✅ {name}  MAE={mae:.4f}")
        print(f"   并排: {out_pair.name}")
        print(f"   误差: {out_diff.name}")

    print(f"\n请打开文件夹查看: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
