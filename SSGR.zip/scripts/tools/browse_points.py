#!/usr/bin/env python

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
点云和图像点浏览工具 - 查看3D点ID和2D点索引

使用方法：
    python browse_points.py --source_path <数据路径> [选项]

功能：
    1. 列出所有3D点及其ID
    2. 列出图像中的所有2D点及其索引
    3. 可视化点云和图像中的点
    4. 交互式查询
"""
import os
import sys
import struct
import argparse
import numpy as np
import cv2
from pathlib import Path

# 导入query_3d_point.py中的函数
sys.path.append(os.path.dirname(__file__))
from query_3d_point import (
    read_points3d_bin, read_points3d_txt,
    read_images_bin, read_images_txt,
    find_image_path, visualize_point_in_image
)


def list_all_3d_points(points3d, max_display=50, output_file=None):
    """列出所有3D点及其ID"""
    print(f"\n{'='*80}")
    print(f"📊 3D点云列表 (共 {len(points3d)} 个点)")
    print(f"{'='*80}")
    print(f"{'点ID':<10} {'X':<12} {'Y':<12} {'Z':<12} {'R':<5} {'G':<5} {'B':<5} {'Track长度':<10}")
    print(f"{'-'*80}")
    
    lines = []
    lines.append(f"3D点云列表 (共 {len(points3d)} 个点)\n")
    lines.append(f"{'点ID':<10} {'X':<12} {'Y':<12} {'Z':<12} {'R':<5} {'G':<5} {'B':<5} {'Track长度':<10}\n")
    lines.append(f"{'-'*80}\n")
    
    # 按ID排序
    sorted_point_ids = sorted(points3d.keys())
    
    display_count = min(max_display, len(sorted_point_ids))
    for i, point_id in enumerate(sorted_point_ids[:display_count]):
        point_data = points3d[point_id]
        xyz = point_data['xyz']
        rgb = point_data['rgb']
        track_len = len(point_data['track'])
        
        line = f"{point_id:<10} {xyz[0]:<12.6f} {xyz[1]:<12.6f} {xyz[2]:<12.6f} " \
               f"{int(rgb[0]):<5} {int(rgb[1]):<5} {int(rgb[2]):<5} {track_len:<10}"
        print(line)
        lines.append(line + "\n")
    
    if len(sorted_point_ids) > display_count:
        print(f"\n... 还有 {len(sorted_point_ids) - display_count} 个点未显示")
        print(f"💡 提示: 使用 --max_points 参数查看更多点，或使用 --output_file 保存完整列表")
        lines.append(f"\n... 还有 {len(sorted_point_ids) - display_count} 个点未显示\n")
    
    # 保存到文件
    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.writelines(lines)
            # 写入所有点
            for point_id in sorted_point_ids[display_count:]:
                point_data = points3d[point_id]
                xyz = point_data['xyz']
                rgb = point_data['rgb']
                track_len = len(point_data['track'])
                f.write(f"{point_id:<10} {xyz[0]:<12.6f} {xyz[1]:<12.6f} {xyz[2]:<12.6f} "
                       f"{int(rgb[0]):<5} {int(rgb[1]):<5} {int(rgb[2]):<5} {track_len:<10}\n")
        print(f"\n✅ 完整列表已保存到: {output_file}")
    
    # 统计信息
    track_lengths = [len(p['track']) for p in points3d.values()]
    print(f"\n📈 统计信息:")
    print(f"   总点数: {len(points3d)}")
    print(f"   平均Track长度: {np.mean(track_lengths):.2f}")
    print(f"   最大Track长度: {max(track_lengths)}")
    print(f"   最小Track长度: {min(track_lengths)}")
    print(f"   Track长度分布:")
    for length in sorted(set(track_lengths)):
        count = track_lengths.count(length)
        print(f"     {length} 张图像: {count} 个点 ({count/len(track_lengths)*100:.1f}%)")


def list_image_2d_points(images, image_id_to_name, image_id=None, image_name=None, 
                         max_display=100, output_file=None):
    """列出图像中的所有2D点及其索引"""
    if image_id is None and image_name is None:
        print(f"\n{'='*80}")
        print(f"📸 所有图像列表 (共 {len(images)} 张图像)")
        print(f"{'='*80}")
        print(f"{'图像ID':<10} {'图像名称':<40} {'2D点数':<10}")
        print(f"{'-'*80}")
        
        for img_id in sorted(images.keys()):
            img_info = images[img_id]
            num_points = len(img_info['points2d'])
            print(f"{img_id:<10} {img_info['name']:<40} {num_points:<10}")
        
        print(f"\n💡 提示: 使用 --image_id 或 --image_name 查看特定图像的2D点")
        return
    
    # 查找目标图像
    target_image_id = None
    if image_id:
        if image_id in images:
            target_image_id = image_id
        else:
            print(f"❌ 错误: 图像ID {image_id} 不存在")
            return
    elif image_name:
        for img_id, img_info in images.items():
            if img_info['name'] == image_name or img_info['name'].startswith(image_name):
                target_image_id = img_id
                break
        if target_image_id is None:
            print(f"❌ 错误: 找不到图像 '{image_name}'")
            return
    
    img_info = images[target_image_id]
    image_name = img_info['name']
    points2d = img_info['points2d']
    point3d_ids = img_info['point3d_ids']
    
    print(f"\n{'='*80}")
    print(f"📸 图像: {image_name} (图像ID={target_image_id})")
    print(f"   2D点总数: {len(points2d)}")
    print(f"{'='*80}")
    print(f"{'2D索引':<10} {'X':<12} {'Y':<12} {'3D点ID':<10} {'状态':<20}")
    print(f"{'-'*80}")
    
    lines = []
    lines.append(f"图像: {image_name} (图像ID={target_image_id})\n")
    lines.append(f"2D点总数: {len(points2d)}\n")
    lines.append(f"{'2D索引':<10} {'X':<12} {'Y':<12} {'3D点ID':<10} {'状态':<20}\n")
    lines.append(f"{'-'*80}\n")
    
    # 统计
    has_3d_count = 0
    no_3d_count = 0
    
    display_count = min(max_display, len(points2d))
    for idx in range(display_count):
        x, y = points2d[idx]
        point3d_id = point3d_ids[idx]
        
        if point3d_id > 0:
            status = "已三角化"
            has_3d_count += 1
        else:
            status = "未三角化"
            no_3d_count += 1
        
        line = f"{idx:<10} {x:<12.2f} {y:<12.2f} {point3d_id if point3d_id > 0 else '-':<10} {status:<20}"
        print(line)
        lines.append(line + "\n")
    
    if len(points2d) > display_count:
        print(f"\n... 还有 {len(points2d) - display_count} 个点未显示")
        lines.append(f"\n... 还有 {len(points2d) - display_count} 个点未显示\n")
    
    # 保存到文件
    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.writelines(lines)
            # 写入所有点
            for idx in range(display_count, len(points2d)):
                x, y = points2d[idx]
                point3d_id = point3d_ids[idx]
                status = "已三角化" if point3d_id > 0 else "未三角化"
                f.write(f"{idx:<10} {x:<12.2f} {y:<12.2f} "
                       f"{point3d_id if point3d_id > 0 else '-':<10} {status:<20}\n")
        print(f"\n✅ 完整列表已保存到: {output_file}")
    
    print(f"\n📈 统计信息:")
    print(f"   已三角化的2D点: {has_3d_count} ({has_3d_count/len(points2d)*100:.1f}%)")
    print(f"   未三角化的2D点: {no_3d_count} ({no_3d_count/len(points2d)*100:.1f}%)")


def visualize_image_points(images_dir, images, image_id_to_name, image_id, 
                          points_indices=None, output_path=None):
    """可视化图像中的2D点"""
    if image_id not in images:
        print(f"❌ 错误: 图像ID {image_id} 不存在")
        return False
    
    img_info = images[image_id]
    image_name = img_info['name']
    points2d = img_info['points2d']
    point3d_ids = img_info['point3d_ids']
    
    # 查找图像文件
    image_path = find_image_path(images_dir, image_name)
    if not image_path:
        print(f"❌ 错误: 找不到图像文件: {image_name}")
        return False
    
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 错误: 无法读取图像: {image_path}")
        return False
    
    # 转换为RGB（用于显示）
    if len(image.shape) == 2:
        image_display = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    else:
        image_display = image.copy()
    
    # 确定要显示的点
    if points_indices is None:
        # 显示所有点
        points_to_show = list(range(len(points2d)))
    else:
        points_to_show = [idx for idx in points_indices if 0 <= idx < len(points2d)]
    
    # 绘制点
    for idx in points_to_show:
        x, y = int(points2d[idx][0]), int(points2d[idx][1])
        point3d_id = point3d_ids[idx]
        
        if 0 <= x < image_display.shape[1] and 0 <= y < image_display.shape[0]:
            # 根据是否有3D点选择颜色
            if point3d_id > 0:
                color = (0, 255, 0)  # 绿色：已三角化
                label = f"#{idx}\n3D:{point3d_id}"
            else:
                color = (0, 0, 255)  # 红色：未三角化
                label = f"#{idx}\nNo3D"
            
            # 绘制圆圈
            cv2.circle(image_display, (x, y), 5, color, 2)
            # 绘制十字
            cv2.line(image_display, (x - 5, y), (x + 5, y), color, 1)
            cv2.line(image_display, (x, y - 5), (x, y + 5), color, 1)
            
            # 添加文本标签
            label_lines = label.split('\n')
            for i, line in enumerate(label_lines):
                y_offset = y + 15 + i * 15
                cv2.putText(image_display, line, (x + 8, y_offset),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
                cv2.putText(image_display, line, (x + 8, y_offset),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # 添加图例
    legend_y = 30
    cv2.putText(image_display, f"Image: {image_name} (ID={image_id})", (10, legend_y),
               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    cv2.putText(image_display, f"Image: {image_name} (ID={image_id})", (10, legend_y),
               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1)
    
    legend_y += 25
    cv2.circle(image_display, (10, legend_y), 5, (0, 255, 0), 2)
    cv2.putText(image_display, "Green: Has 3D point", (25, legend_y + 5),
               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
    cv2.putText(image_display, "Green: Has 3D point", (25, legend_y + 5),
               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    
    legend_y += 25
    cv2.circle(image_display, (10, legend_y), 5, (0, 0, 255), 2)
    cv2.putText(image_display, "Red: No 3D point", (25, legend_y + 5),
               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
    cv2.putText(image_display, "Red: No 3D point", (25, legend_y + 5),
               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    
    # 保存图像
    if output_path:
        cv2.imwrite(output_path, image_display)
        print(f"✅ 可视化图像已保存到: {output_path}")
    
    return True


def browse_points(source_path, sfm_out_dir=None, 
                 list_3d=True, list_images=False, 
                 image_id=None, image_name=None,
                 max_points=50, max_2d_points=100,
                 output_3d_file=None, output_2d_file=None,
                 visualize_image_id=None, visualize_output=None,
                 images_dir=None):
    """浏览点云和图像点"""
    
    # 确定输出目录
    if sfm_out_dir is None:
        sfm_out_dir = os.path.join(source_path, "sfm_results")
    
    sparse_dir = os.path.join(sfm_out_dir, "sparse", "0")
    
    # 检查文件是否存在
    points3d_bin = os.path.join(sparse_dir, "points3D.bin")
    points3d_txt = os.path.join(sparse_dir, "points3D.txt")
    images_bin = os.path.join(sparse_dir, "images.bin")
    images_txt = os.path.join(sparse_dir, "images.txt")
    
    # 读取点云数据
    if list_3d:
        print("📖 读取点云数据...")
        if os.path.exists(points3d_bin):
            points3d = read_points3d_bin(points3d_bin)
            print(f"   ✅ 从二进制文件读取 {len(points3d)} 个3D点")
        elif os.path.exists(points3d_txt):
            points3d = read_points3d_txt(points3d_txt)
            print(f"   ✅ 从文本文件读取 {len(points3d)} 个3D点")
        else:
            print(f"   ❌ 错误: 找不到点云文件")
            print(f"      查找路径: {points3d_bin} 或 {points3d_txt}")
            points3d = None
    else:
        points3d = None
    
    # 读取图像数据
    if list_images or image_id or image_name or visualize_image_id:
        print("📖 读取图像数据...")
        if os.path.exists(images_bin):
            images, image_id_to_name = read_images_bin(images_bin)
            print(f"   ✅ 从二进制文件读取 {len(images)} 张图像")
        elif os.path.exists(images_txt):
            images, image_id_to_name = read_images_txt(images_txt)
            print(f"   ✅ 从文本文件读取 {len(images)} 张图像")
        else:
            print(f"   ❌ 错误: 找不到图像文件")
            print(f"      查找路径: {images_bin} 或 {images_txt}")
            images = None
            image_id_to_name = None
    else:
        images = None
        image_id_to_name = None
    
    # 查找图像目录
    if images_dir is None:
        images_dir = os.path.join(source_path, "images")
        if not os.path.exists(images_dir):
            images_dir = os.path.join(source_path, "input")
    
    # 列出3D点
    if list_3d and points3d:
        list_all_3d_points(points3d, max_display=max_points, output_file=output_3d_file)
    
    # 列出图像
    if list_images and images:
        list_image_2d_points(images, image_id_to_name, 
                           image_id=image_id, image_name=image_name,
                           max_display=max_2d_points, output_file=output_2d_file)
    
    # 可视化图像中的点
    if visualize_image_id and images and images_dir:
        visualize_image_points(images_dir, images, image_id_to_name, 
                              visualize_image_id, output_path=visualize_output)
    
    return True


def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description='浏览3D点ID和2D点索引',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 列出所有3D点
  python browse_points.py --source_path ./data
  
  # 列出特定图像的2D点
  python browse_points.py --source_path ./data --image_id 1
  
  # 可视化图像中的2D点
  python browse_points.py --source_path ./data --visualize_image_id 1 --visualize_output ./viz.png
  
  # 保存3D点列表到文件
  python browse_points.py --source_path ./data --output_3d_file ./points3d_list.txt
        """
    )
    
    parser.add_argument(
        "--source_path", "-s",
        required=True,
        type=str,
        help="源数据路径"
    )
    
    parser.add_argument(
        "--sfm_out_dir",
        type=str,
        default=None,
        help="SfM输出目录（默认: {source_path}/sfm_results）"
    )
    
    parser.add_argument(
        "--list_3d",
        action="store_true",
        default=True,
        help="列出所有3D点（默认启用）"
    )
    
    parser.add_argument(
        "--no_list_3d",
        action="store_true",
        help="不列出3D点"
    )
    
    parser.add_argument(
        "--list_images",
        action="store_true",
        help="列出所有图像"
    )
    
    parser.add_argument(
        "--image_id",
        type=int,
        default=None,
        help="查看特定图像的2D点（图像ID）"
    )
    
    parser.add_argument(
        "--image_name",
        type=str,
        default=None,
        help="查看特定图像的2D点（图像名称）"
    )
    
    parser.add_argument(
        "--max_points",
        type=int,
        default=50,
        help="最多显示的3D点数（默认: 50）"
    )
    
    parser.add_argument(
        "--max_2d_points",
        type=int,
        default=100,
        help="最多显示的2D点数（默认: 100）"
    )
    
    parser.add_argument(
        "--output_3d_file",
        type=str,
        default=None,
        help="保存3D点列表到文件"
    )
    
    parser.add_argument(
        "--output_2d_file",
        type=str,
        default=None,
        help="保存2D点列表到文件"
    )
    
    parser.add_argument(
        "--visualize_image_id",
        type=int,
        default=None,
        help="可视化图像中的2D点（图像ID）"
    )
    
    parser.add_argument(
        "--visualize_output",
        type=str,
        default=None,
        help="可视化图像输出路径"
    )
    
    parser.add_argument(
        "--images_dir",
        type=str,
        default=None,
        help="图像目录路径（默认自动查找）"
    )
    
    return parser.parse_args()


def main():
    """主函数"""
    args = parse_arguments()
    
    # 处理list_3d标志
    list_3d = args.list_3d and not args.no_list_3d
    
    # 执行浏览
    success = browse_points(
        source_path=args.source_path,
        sfm_out_dir=args.sfm_out_dir,
        list_3d=list_3d,
        list_images=args.list_images,
        image_id=args.image_id,
        image_name=args.image_name,
        max_points=args.max_points,
        max_2d_points=args.max_2d_points,
        output_3d_file=args.output_3d_file,
        output_2d_file=args.output_2d_file,
        visualize_image_id=args.visualize_image_id,
        visualize_output=args.visualize_output,
        images_dir=args.images_dir
    )
    
    if success:
        print("\n✅ 浏览完成!")
        return 0
    else:
        print("\n❌ 浏览失败!")
        return 1


if __name__ == "__main__":
    exit(main())

