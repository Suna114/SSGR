from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff"}
DEFAULT_FONT = Path(r"C:\Windows\Fonts\timesbd.ttf")


def list_images(folder: Path) -> list[Path]:
    return sorted(
        [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in EXTS],
        key=lambda p: p.name.lower(),
    )


def load_font(size: int, font_path: Path | None = None) -> ImageFont.ImageFont:
    for path in [font_path, DEFAULT_FONT, Path(r"C:\Windows\Fonts\times.ttf"), Path(r"C:\Windows\Fonts\arialbd.ttf")]:
        if path is not None and path.is_file():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def text_size(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont) -> tuple[int, int]:
    box = draw.textbbox((0, 0), text, font=font)
    return box[2] - box[0], box[3] - box[1]


def fit_font(labels: list[str], cell_h: int, max_w: int | None, font_path: Path | None, ratio: float) -> ImageFont.ImageFont:
    target_h = max(8, int(round(cell_h * ratio)))
    probe = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    for size in range(max(8, int(cell_h)), 7, -1):
        font = load_font(size, font_path)
        sizes = [text_size(probe, label, font) for label in labels]
        if sizes and max(h for _, h in sizes) <= target_h and (max_w is None or max(w for w, _ in sizes) <= max_w):
            return font
    return load_font(8, font_path)


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a 4x9 ablation montage with centered Times New Roman labels.")
    parser.add_argument("-i", "--input", required=True, type=Path)
    parser.add_argument("-o", "--output", required=True, type=Path)
    parser.add_argument("--cols", type=int, default=9)
    parser.add_argument("--rows", type=int, default=4)
    parser.add_argument("--row-labels", required=True)
    parser.add_argument("--col-labels", required=True)
    parser.add_argument("--cell-size", type=int, default=158)
    parser.add_argument("--gap", type=int, default=6)
    parser.add_argument("--label-padding", type=int, default=16)
    parser.add_argument("--font-ratio", type=float, default=0.20)
    parser.add_argument("--font", type=Path, default=DEFAULT_FONT)
    parser.add_argument("--bgcolor", choices=("white", "black"), default="white")
    args = parser.parse_args()

    row_labels = [x.strip() for x in args.row_labels.split(",")]
    col_labels = [x.strip() for x in args.col_labels.split(",")]
    if len(row_labels) != args.rows:
        raise SystemExit(f"row-labels count must equal rows={args.rows}")
    if len(col_labels) != args.cols:
        raise SystemExit(f"col-labels count must equal cols={args.cols}")

    bg = (255, 255, 255) if args.bgcolor == "white" else (0, 0, 0)
    fg = (0, 0, 0) if args.bgcolor == "white" else (255, 255, 255)
    paths = list_images(args.input)
    cap = args.cols * args.rows
    if len(paths) < cap:
        raise SystemExit(f"not enough images: {len(paths)}/{cap}")
    paths = paths[:cap]

    cells: list[Image.Image] = []
    for path in paths:
        with Image.open(path) as im:
            im = im.convert("RGB").resize((args.cell_size, args.cell_size), Image.Resampling.LANCZOS)
            cells.append(im.copy())

    probe = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    font = fit_font(row_labels + col_labels, args.cell_size, None, args.font, args.font_ratio)
    row_label_w = max(text_size(probe, label, font)[0] for label in row_labels)
    col_label_h = max(text_size(probe, label, font)[1] for label in col_labels)

    left_pad = row_label_w + args.label_padding * 2
    top_pad = col_label_h + args.label_padding
    grid_w = args.cols * args.cell_size + (args.cols - 1) * args.gap
    grid_h = args.rows * args.cell_size + (args.rows - 1) * args.gap
    out = Image.new("RGB", (left_pad + grid_w, top_pad + grid_h), bg)

    for idx, cell in enumerate(cells):
        r, c = divmod(idx, args.cols)
        x = left_pad + c * (args.cell_size + args.gap)
        y = top_pad + r * (args.cell_size + args.gap)
        out.paste(cell, (x, y))

    draw = ImageDraw.Draw(out)
    row_x = left_pad / 2.0
    col_y = top_pad / 2.0
    for r, label in enumerate(row_labels):
        y = top_pad + r * (args.cell_size + args.gap) + args.cell_size / 2.0
        draw.text((row_x, y), label, font=font, fill=fg, anchor="mm")
    for c, label in enumerate(col_labels):
        x = left_pad + c * (args.cell_size + args.gap) + args.cell_size / 2.0
        draw.text((x, col_y), label, font=font, fill=fg, anchor="mm")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    out.save(args.output)
    print(f"wrote {args.output} ({out.width}x{out.height}), font={getattr(font, 'size', 'default')}")


if __name__ == "__main__":
    main()
