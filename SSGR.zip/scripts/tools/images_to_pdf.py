#!/usr/bin/env python3
"""Convert images in a folder to PDF (root only by default)."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image
from PIL.Image import DecompressionBombError

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}


def _iter_images(folder: Path, recursive: bool) -> list[Path]:
    if recursive:
        paths = [p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    else:
        paths = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    return sorted(paths, key=lambda p: p.name.lower())


def _to_rgb(im: Image.Image) -> Image.Image:
    if im.mode in ("RGBA", "LA"):
        bg = Image.new("RGB", im.size, (255, 255, 255))
        bg.paste(im, mask=im.split()[-1])
        return bg
    if im.mode == "P":
        return im.convert("RGBA").convert("RGB")
    if im.mode != "RGB":
        return im.convert("RGB")
    return im


def convert_image(src: Path, dst: Path, resolution: float, allow_large_images: bool) -> None:
    old_max_pixels = Image.MAX_IMAGE_PIXELS
    if allow_large_images:
        Image.MAX_IMAGE_PIXELS = None

    try:
        with Image.open(src) as im:
            im = _to_rgb(im)
            dst.parent.mkdir(parents=True, exist_ok=True)
            im.save(dst, "PDF", resolution=resolution)
    finally:
        Image.MAX_IMAGE_PIXELS = old_max_pixels


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Convert images to PDF. By default only files in the target folder root are processed."
    )
    parser.add_argument(
        "-i",
        "--input",
        type=Path,
        default=Path(r"F:\shuju"),
        help="Folder containing source images (default: F:\\shuju).",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Output folder. Default: same as --input.",
    )
    parser.add_argument(
        "--recursive",
        action="store_true",
        help="Also convert images in subfolders.",
    )
    parser.add_argument(
        "--resolution",
        type=float,
        default=300.0,
        help="PDF resolution in dpi (default: 300).",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing PDF files.",
    )
    parser.add_argument(
        "--allow-large-images",
        action="store_true",
        help="Allow images larger than Pillow's decompression-bomb safety limit. Use only for trusted local files.",
    )
    args = parser.parse_args()

    src_dir = args.input.resolve()
    if not src_dir.is_dir():
        raise SystemExit(f"Input folder not found: {src_dir}")

    out_dir = src_dir if args.output is None else args.output.resolve()
    images = _iter_images(src_dir, args.recursive)
    if not images:
        print(f"No supported images in: {src_dir}")
        return 1

    converted = 0
    skipped = 0
    errors: list[tuple[str, str]] = []

    for src in images:
        if args.recursive:
            rel = src.relative_to(src_dir)
            dst = out_dir / rel.with_suffix(".pdf")
        else:
            dst = out_dir / f"{src.stem}.pdf"

        if dst.exists() and not args.overwrite:
            skipped += 1
            continue

        try:
            convert_image(src, dst, args.resolution, args.allow_large_images)
            converted += 1
            print(f"[ok] {src.name} -> {dst.name}")
        except DecompressionBombError as exc:
            errors.append((src.name, str(exc)))
            print(f"[error] {src.name}: {exc}")
            print("        trusted file? rerun with --allow-large-images")
        except Exception as exc:
            errors.append((src.name, str(exc)))
            print(f"[error] {src.name}: {exc}")

    print(
        f"Done. converted={converted}, skipped={skipped}, errors={len(errors)}, "
        f"scope={'recursive' if args.recursive else 'root-only'}"
    )
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
