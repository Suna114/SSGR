#!/usr/bin/env python3
"""Rerun shadow train + background-then-shadow apply for output/final datasets."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace


REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CLASSES = [
    "2S1",
    "BMP2",
    "BRDM_2",
    "BTR70",
    "D7",
    "SLICY",
    "T62",
    "T72",
    "ZIL131",
    "ZSU_23_4",
]
PIPELINE_STAGES = ("train_shadow", "apply_shadow")


def _import_agent():
    sys.path.insert(0, str(REPO_ROOT / "scripts" / "pipeline"))
    import novel_view_agent as agent  # type: ignore

    return agent


def _ui_default_agent_args(python: str, device: str, output_root: Path) -> SimpleNamespace:
    return SimpleNamespace(
        python=python,
        device=device,
        output_root=str(output_root),
        refiner_azimuth_shadow=True,
        azimuth_shadow_geometry_extent_gate=False,
        azimuth_shadow_geometry_extent_apply_to_recognition=False,
        azimuth_shadow_geometry_extent_require_dataset_direction=False,
        azimuth_shadow_geometry_extent_forward_scale=1.0,
        azimuth_shadow_geometry_extent_lateral_scale=1.0,
        azimuth_shadow_geometry_extent_margin_px=1.5,
        azimuth_shadow_geometry_extent_min_forward_px=0.0,
        matched_real_background=True,
        matched_background_strength=1.0,
        matched_background_shadow_alpha_source="compose_alpha",
        matched_background_hard_shadow_copy=False,
        matched_background_patch_size=24,
        matched_background_patch_overlap=6,
        matched_background_patch_smooth=1,
        matched_background_patch_smooth_mix=0.30,
        matched_background_reference_exclude_dilate=2,
        matched_background_nearest_refs=6,
        matched_background_reference_clean_blend_refs=4,
        matched_background_reference_clean_blend_mix=0.45,
        matched_background_reference_clean_angle_sigma=12.0,
        matched_background_reference_clean_patch_mix=0.20,
        matched_background_min_background_fraction=0.96,
        matched_background_stat_match="mean_std",
        matched_background_shadow_from_render_percentile=20.0,
        matched_background_target_mask_dilate=1,
        matched_background_blend_dilate=0,
        matched_background_target_mask_blur=1,
        matched_background_target_gap_dark_threshold=0.012,
        matched_background_target_gap_edge_px=2,
        matched_background_target_gap_shadow_protect_threshold=0.02,
        matched_background_hard_target_copy=False,
        export_classification_labels=True,
        classification_source="extra",
        background_filtered_eval=False,
        background_filtered_eval_percentile=90.0,
        background_filtered_eval_gt_dir=None,
        background_filtered_eval_output_dir=None,
        azimuth_match_tolerance=5,
        azimuth_shadow_fixed_direction_deg=None,
        azimuth_shadow_intensity_strength=1.22,
        azimuth_shadow_intensity_min_attenuation=0.38,
        azimuth_shadow_intensity_max_attenuation=0.93,
        azimuth_shadow_intensity_gamma=0.80,
        azimuth_shadow_intensity_context_radius=13,
        azimuth_shadow_intensity_block_radius=7,
        azimuth_shadow_intensity_exclude_dilate=2,
    )


def _build_refiner_stage_cmd(
    agent,
    args: SimpleNamespace,
    data_dir: Path,
    output_root: Path,
    *,
    stage: str,
) -> list[str]:
    dataset_name = data_dir.name
    run_root = output_root / dataset_name
    model_dir = run_root / "gaussian"
    refiner_work_dir = run_root / "refiner"
    gt_dir = data_dir / "input"
    classification_label_output_dir = output_root

    cmd = agent._build_refiner_cmd(
        args,
        data_dir,
        model_dir,
        refiner_work_dir,
        gt_dir,
        gt_dir,
        classification_label_output_dir,
        None,
    )
    for i, part in enumerate(cmd):
        if part == "--stage" and i + 1 < len(cmd) and cmd[i + 1] == "full_train":
            cmd[i + 1] = stage
            break
    else:
        raise RuntimeError("Could not locate --stage full_train in refiner command")

    extras = [
        "--no-target_shadow_eval",
        "--no-refiner_delta_eval",
        "--no-background_filtered_eval",
    ]
    if stage == "apply_shadow":
        extras.append("--save_maps")
    for flag in extras:
        if flag.startswith("--no-"):
            positive = flag.replace("--no-", "--", 1)
            if positive in cmd:
                idx = cmd.index(positive)
                cmd[idx : idx + 2] = [flag]
        elif flag not in cmd:
            cmd.append(flag)
    return cmd


def _copy_renders_to_figure(src_dir: Path, dst_dir: Path) -> int:
    if not src_dir.is_dir():
        raise FileNotFoundError(f"Missing final renders: {src_dir}")
    if dst_dir.exists():
        shutil.rmtree(dst_dir)
    dst_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    for src in sorted(src_dir.glob("*.png")):
        shutil.copy2(src, dst_dir / src.name)
        count += 1
    return count


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output_root", type=Path, default=Path(r"F:\3dgs\SSGR\output\final"))
    parser.add_argument("--data_root", type=Path, default=REPO_ROOT / "data")
    parser.add_argument(
        "--figure_root",
        type=Path,
        default=REPO_ROOT / "output" / "final" / "picture2",
        help="Default: output/final/picture2.",
    )
    parser.add_argument("--classes", nargs="*", default=DEFAULT_CLASSES)
    parser.add_argument("--python", type=str, default=None)
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--dry_run", action="store_true")
    parser.add_argument(
        "--stages",
        nargs="+",
        choices=PIPELINE_STAGES,
        default=list(PIPELINE_STAGES),
        help="Default: train_shadow then apply_shadow (shadow refiner -> background -> export).",
    )
    args = parser.parse_args()

    agent = _import_agent()
    python = args.python or r"C:\Users\s\miniconda3\envs\3dgs\python.exe"
    agent_args = _ui_default_agent_args(python, args.device, args.output_root)

    output_root = args.output_root.resolve()
    figure_root = args.figure_root.resolve()
    log_root = REPO_ROOT / "output" / f"rerun_shadow_figure_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    log_root.mkdir(parents=True, exist_ok=True)

    failures: list[str] = []
    for name in args.classes:
        data_dir = (args.data_root / name).resolve()
        if not data_dir.is_dir():
            failures.append(f"{name}: missing data dir {data_dir}")
            continue

        class_ok = True
        for stage in args.stages:
            cmd = _build_refiner_stage_cmd(agent, agent_args, data_dir, output_root, stage=stage)
            log_path = log_root / f"{name}_{stage}.log"
            print(f"\n==== [{name}] {stage} ====")
            print(" ".join(f'"{p}"' if " " in p else p for p in cmd))

            if args.dry_run:
                continue

            env = os.environ.copy()
            env["PYTHONUNBUFFERED"] = "1"
            proc = subprocess.run(
                cmd,
                cwd=str(REPO_ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=env,
            )
            log_path.write_text(proc.stdout or "", encoding="utf-8")
            print(proc.stdout[-3000:] if proc.stdout else "")
            if proc.returncode != 0:
                failures.append(f"{name}/{stage}: exit {proc.returncode}, see {log_path}")
                class_ok = False
                break

        if args.dry_run or not class_ok:
            continue

        post = output_root / name / "refiner" / "03.apply_postprocess"
        renders_candidates = [
            post / "apply" / "renders",
            post / "apply_background_then_shadow" / "renders",
            post / "azimuth_shadow_refiner" / "learned_intensity_prior" / "renders",
            post / "background_after_shadow" / "renders",
        ]
        renders_dir = next((p for p in renders_candidates if p.is_dir() and any(p.glob("*.png"))), None)
        if renders_dir is None:
            failures.append(f"{name}: no final renders under {post}")
            continue
        dst_dir = figure_root / name
        copied = _copy_renders_to_figure(renders_dir, dst_dir)
        print(f"[figure] copied {copied} images -> {dst_dir}")

    print(f"\nLogs: {log_root}")
    print(f"Figure root: {figure_root}")
    if failures:
        print("Failures:")
        for item in failures:
            print(" ", item)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
