# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
角度性能分析工具

功能：
1. 分析不同角度（方位角）的渲染性能
2. 识别表现好/差的角度范围
3. 生成角度-性能关系图

使用方法：
    python 角度性能分析.py --comparison_json my_renders/train/comparison/comparison_results.json
"""

import json
import argparse
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import re

# 设置matplotlib支持中文
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def parse_azimuth_from_filename(filename):
    """
    从文件名解析方位角
    
    例如: T72-15-074.png -> 74°
    """
    match = re.search(r'-(\d+)\.(png|jpg|jpeg)$', filename, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return None


def analyze_angle_performance(comparison_json_path):
    """
    分析角度性能
    
    Args:
        comparison_json_path: 对比结果JSON文件路径
    """
    # 加载对比结果
    with open(comparison_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    per_image = data['per_image']
    
    # 提取角度和指标
    angle_metrics = []
    for img_data in per_image:
        filename = img_data['image_name']
        azimuth = parse_azimuth_from_filename(filename)
        
        if azimuth is not None:
            angle_metrics.append({
                'azimuth': azimuth,
                'filename': filename,
                'PSNR': img_data.get('PSNR'),
                'SSIM': img_data.get('SSIM'),
                'LPIPS': img_data.get('LPIPS'),
                'MSE': img_data.get('MSE'),
                'MAE': img_data.get('MAE')
            })
    
    if len(angle_metrics) == 0:
        print("⚠️ 无法从文件名解析方位角")
        return
    
    # 按角度排序
    angle_metrics.sort(key=lambda x: x['azimuth'])
    
    # 提取数据
    angles = [m['azimuth'] for m in angle_metrics]
    psnr_values = [m['PSNR'] for m in angle_metrics if m['PSNR'] is not None]
    ssim_values = [m['SSIM'] for m in angle_metrics if m['SSIM'] is not None]
    lpips_values = [m['LPIPS'] for m in angle_metrics if m['LPIPS'] is not None]
    
    # 统计分析
    print("=" * 80)
    print("角度性能分析")
    print("=" * 80)
    print(f"总图像数: {len(angle_metrics)}")
    print(f"角度范围: {min(angles)}° - {max(angles)}°")
    print()
    
    # 找出表现最好和最差的角度
    ssim_with_angles = [(m['SSIM'], m['azimuth'], m['filename']) for m in angle_metrics if m['SSIM'] is not None]
    ssim_with_angles.sort(key=lambda x: x[0])
    
    print("【表现最差的角度】")
    print("-" * 80)
    for i, (ssim, angle, filename) in enumerate(ssim_with_angles[:5]):
        metrics = next(m for m in angle_metrics if m['filename'] == filename)
        print(f"{i+1}. {filename} (方位角: {angle}°)")
        print(f"   SSIM: {ssim:.4f}, PSNR: {metrics['PSNR']:.2f} dB, LPIPS: {metrics['LPIPS']:.4f}")
    print()
    
    print("【表现最好的角度】")
    print("-" * 80)
    for i, (ssim, angle, filename) in enumerate(ssim_with_angles[-5:]):
        metrics = next(m for m in angle_metrics if m['filename'] == filename)
        print(f"{i+1}. {filename} (方位角: {angle}°)")
        print(f"   SSIM: {ssim:.4f}, PSNR: {metrics['PSNR']:.2f} dB, LPIPS: {metrics['LPIPS']:.4f}")
    print()
    
    # 角度范围分析
    print("【角度范围性能统计】")
    print("-" * 80)
    
    angle_ranges = [
        (0, 90, "0-90°"),
        (90, 180, "90-180°"),
        (180, 270, "180-270°"),
        (270, 360, "270-360°")
    ]
    
    for start, end, label in angle_ranges:
        range_metrics = [m for m in angle_metrics if start <= m['azimuth'] < end]
        if len(range_metrics) > 0:
            range_ssim = [m['SSIM'] for m in range_metrics if m['SSIM'] is not None]
            range_psnr = [m['PSNR'] for m in range_metrics if m['PSNR'] is not None]
            
            if range_ssim:
                print(f"{label}:")
                print(f"  图像数: {len(range_metrics)}")
                print(f"  SSIM: 平均={np.mean(range_ssim):.4f}, 范围=[{np.min(range_ssim):.4f}, {np.max(range_ssim):.4f}]")
                print(f"  PSNR: 平均={np.mean(range_psnr):.2f} dB, 范围=[{np.min(range_psnr):.2f}, {np.max(range_psnr):.2f}] dB")
                print()
    
    # 创建可视化
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('Angle Performance Analysis', fontsize=16)
    
    # 1. SSIM vs 角度
    axes[0, 0].scatter(angles, ssim_values, alpha=0.6, s=50)
    axes[0, 0].plot(angles, ssim_values, alpha=0.3, linestyle='--')
    axes[0, 0].axhline(y=np.mean(ssim_values), color='r', linestyle='--', label=f'Mean: {np.mean(ssim_values):.4f}')
    axes[0, 0].set_xlabel('Azimuth Angle (degrees)')
    axes[0, 0].set_ylabel('SSIM')
    axes[0, 0].set_title('SSIM vs Azimuth Angle')
    axes[0, 0].grid(True, alpha=0.3)
    axes[0, 0].legend()
    axes[0, 0].set_xlim(0, 360)
    
    # 2. PSNR vs 角度
    axes[0, 1].scatter(angles, psnr_values, alpha=0.6, s=50, color='green')
    axes[0, 1].plot(angles, psnr_values, alpha=0.3, linestyle='--', color='green')
    axes[0, 1].axhline(y=np.mean(psnr_values), color='r', linestyle='--', label=f'Mean: {np.mean(psnr_values):.2f} dB')
    axes[0, 1].set_xlabel('Azimuth Angle (degrees)')
    axes[0, 1].set_ylabel('PSNR (dB)')
    axes[0, 1].set_title('PSNR vs Azimuth Angle')
    axes[0, 1].grid(True, alpha=0.3)
    axes[0, 1].legend()
    axes[0, 1].set_xlim(0, 360)
    
    # 3. LPIPS vs 角度
    axes[1, 0].scatter(angles, lpips_values, alpha=0.6, s=50, color='orange')
    axes[1, 0].plot(angles, lpips_values, alpha=0.3, linestyle='--', color='orange')
    axes[1, 0].axhline(y=np.mean(lpips_values), color='r', linestyle='--', label=f'Mean: {np.mean(lpips_values):.4f}')
    axes[1, 0].set_xlabel('Azimuth Angle (degrees)')
    axes[1, 0].set_ylabel('LPIPS')
    axes[1, 0].set_title('LPIPS vs Azimuth Angle')
    axes[1, 0].grid(True, alpha=0.3)
    axes[1, 0].legend()
    axes[1, 0].set_xlim(0, 360)
    
    # 4. 综合性能（SSIM + PSNR归一化）
    ssim_norm = (np.array(ssim_values) - np.min(ssim_values)) / (np.max(ssim_values) - np.min(ssim_values))
    psnr_norm = (np.array(psnr_values) - np.min(psnr_values)) / (np.max(psnr_values) - np.min(psnr_values))
    combined_score = (ssim_norm + psnr_norm) / 2
    
    axes[1, 1].scatter(angles, combined_score, alpha=0.6, s=50, color='purple')
    axes[1, 1].plot(angles, combined_score, alpha=0.3, linestyle='--', color='purple')
    axes[1, 1].axhline(y=np.mean(combined_score), color='r', linestyle='--', label=f'Mean: {np.mean(combined_score):.4f}')
    axes[1, 1].set_xlabel('Azimuth Angle (degrees)')
    axes[1, 1].set_ylabel('Combined Score (Normalized)')
    axes[1, 1].set_title('Combined Performance Score vs Azimuth Angle')
    axes[1, 1].grid(True, alpha=0.3)
    axes[1, 1].legend()
    axes[1, 1].set_xlim(0, 360)
    
    plt.tight_layout()
    
    # 保存图像
    output_path = Path(comparison_json_path).parent / 'angle_performance_analysis.png'
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"✅ 角度性能分析图已保存: {output_path}")
    plt.close()
    
    # 识别问题角度范围
    print("=" * 80)
    print("【问题角度识别】")
    print("=" * 80)
    
    # 找出SSIM低于平均值的角度
    mean_ssim = np.mean(ssim_values)
    poor_angles = [(m['azimuth'], m['SSIM'], m['filename']) 
                   for m in angle_metrics 
                   if m['SSIM'] is not None and m['SSIM'] < mean_ssim - 0.05]
    
    if poor_angles:
        print(f"发现 {len(poor_angles)} 个表现较差的角度（SSIM < {mean_ssim - 0.05:.4f}）:")
        for angle, ssim, filename in sorted(poor_angles, key=lambda x: x[1])[:10]:
            print(f"  - {filename}: 方位角={angle}°, SSIM={ssim:.4f}")
    else:
        print("未发现明显的问题角度")
    
    print("=" * 80)


def main():
    parser = argparse.ArgumentParser(description='分析不同角度的渲染性能')
    parser.add_argument('--comparison_json', type=str, required=True,
                       help='对比结果JSON文件路径')
    
    args = parser.parse_args()
    
    analyze_angle_performance(args.comparison_json)


if __name__ == "__main__":
    main()
