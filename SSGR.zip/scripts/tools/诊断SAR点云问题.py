# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
诊断SAR点云问题的工具
用于检查点云分布、坐标系和3D-2D对应关系
"""

import numpy as np
import json
import os
import sys

def analyze_point_cloud_distribution(points3d_file):
    """
    分析点云分布，检查是否在第二象限
    """
    print("="*60)
    print("📊 点云分布分析")
    print("="*60)
    
    # 读取点云文件
    points = []
    with open(points3d_file, 'r') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.strip().split()
            if len(parts) >= 4:
                point_id = int(parts[0])
                x = float(parts[1])
                y = float(parts[2])
                z = float(parts[3])
                points.append([x, y, z])
    
    points = np.array(points)
    
    if len(points) == 0:
        print("❌ 没有找到点云数据")
        return
    
    print(f"\n✅ 读取了 {len(points)} 个3D点")
    
    # 分析坐标分布
    x_coords = points[:, 0]
    y_coords = points[:, 1]
    z_coords = points[:, 2]
    
    print(f"\n📍 坐标范围:")
    print(f"   X: [{x_coords.min():.2f}, {x_coords.max():.2f}]")
    print(f"   Y: [{y_coords.min():.2f}, {y_coords.max():.2f}]")
    print(f"   Z: [{z_coords.min():.2f}, {z_coords.max():.2f}]")
    
    # 分析象限分布
    quadrants = {
        '第一象限 (X>0, Z>0)': 0,
        '第二象限 (X<0, Z>0)': 0,
        '第三象限 (X<0, Z<0)': 0,
        '第四象限 (X>0, Z<0)': 0
    }
    
    for x, z in zip(x_coords, z_coords):
        if x >= 0 and z >= 0:
            quadrants['第一象限 (X>0, Z>0)'] += 1
        elif x < 0 and z >= 0:
            quadrants['第二象限 (X<0, Z>0)'] += 1
        elif x < 0 and z < 0:
            quadrants['第三象限 (X<0, Z<0)'] += 1
        else:
            quadrants['第四象限 (X>0, Z<0)'] += 1
    
    print(f"\n📊 象限分布:")
    total = len(points)
    for quadrant, count in quadrants.items():
        percentage = count / total * 100
        print(f"   {quadrant}: {count} 个点 ({percentage:.1f}%)")
    
    # 检查是否集中在第二象限
    if quadrants['第二象限 (X<0, Z>0)'] > total * 0.5:
        print(f"\n⚠️ 警告: 超过50%的点在第二象限！")
        print(f"   这可能说明坐标系定义有问题")
        print(f"   如果方位角是0-45°，点应该在第一象限")
    
    # 分析点云中心
    center = points.mean(axis=0)
    print(f"\n📍 点云中心: ({center[0]:.2f}, {center[1]:.2f}, {center[2]:.2f})")
    
    # 主成分分析
    centered_points = points - center
    cov_matrix = np.cov(centered_points.T)
    eigenvals, eigenvecs = np.linalg.eigh(cov_matrix)
    eigenvals = eigenvals[::-1]  # 降序排列
    eigenvecs = eigenvecs[:, ::-1]
    
    variance_ratio = eigenvals / eigenvals.sum()
    print(f"\n📊 主成分分析:")
    print(f"   主成分1方差占比: {variance_ratio[0]:.1%}")
    print(f"   主成分2方差占比: {variance_ratio[1]:.1%}")
    print(f"   主成分3方差占比: {variance_ratio[2]:.1%}")
    
    if variance_ratio[0] + variance_ratio[1] > 0.95:
        print(f"\n⚠️ 警告: 点云可能退化为一维或平面（96%+的方差在前两个主成分）")
        print(f"   可能原因:")
        print(f"   1. 相机姿态计算错误")
        print(f"   2. 三角化方法不正确")
        print(f"   3. 所有点都在同一个平面上")
    
    print("="*60)

def analyze_camera_positions(images_file):
    """
    分析相机位置分布
    """
    print("\n" + "="*60)
    print("📷 相机位置分析")
    print("="*60)
    
    cameras = []
    with open(images_file, 'r') as f:
        lines = f.readlines()
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith('#') or not line.strip():
                i += 1
                continue
            
            parts = line.strip().split()
            if len(parts) >= 10:
                # IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME
                image_id = int(parts[0])
                qw, qx, qy, qz = map(float, parts[1:5])
                tx, ty, tz = map(float, parts[5:8])
                camera_id = int(parts[8])
                name = parts[9]
                
                # 从四元数计算旋转矩阵
                from scipy.spatial.transform import Rotation as R
                quat = [qx, qy, qz, qw]
                rotation = R.from_quat(quat)
                R_matrix = rotation.as_matrix()
                
                # 计算相机位置：camera_pos = -R^T @ t
                t_vec = np.array([[tx], [ty], [tz]])
                camera_pos = -R_matrix.T @ t_vec
                
                cameras.append({
                    'name': name,
                    'position': camera_pos.flatten(),
                    't': [tx, ty, tz]
                })
            i += 1
    
    if len(cameras) == 0:
        print("❌ 没有找到相机数据")
        return
    
    print(f"\n✅ 读取了 {len(cameras)} 个相机")
    
    # 分析相机位置分布
    positions = np.array([c['position'] for c in cameras])
    x_pos = positions[:, 0]
    y_pos = positions[:, 1]
    z_pos = positions[:, 2]
    
    print(f"\n📍 相机位置范围:")
    print(f"   X: [{x_pos.min():.2f}, {x_pos.max():.2f}]")
    print(f"   Y: [{y_pos.min():.2f}, {y_pos.max():.2f}]")
    print(f"   Z: [{z_pos.min():.2f}, {z_pos.max():.2f}]")
    
    # 分析象限分布
    quadrants = {
        '第一象限 (X>0, Z>0)': 0,
        '第二象限 (X<0, Z>0)': 0,
        '第三象限 (X<0, Z<0)': 0,
        '第四象限 (X>0, Z<0)': 0
    }
    
    for x, z in zip(x_pos, z_pos):
        if x >= 0 and z >= 0:
            quadrants['第一象限 (X>0, Z>0)'] += 1
        elif x < 0 and z >= 0:
            quadrants['第二象限 (X<0, Z>0)'] += 1
        elif x < 0 and z < 0:
            quadrants['第三象限 (X<0, Z<0)'] += 1
        else:
            quadrants['第四象限 (X>0, Z<0)'] += 1
    
    print(f"\n📊 相机象限分布:")
    total = len(cameras)
    for quadrant, count in quadrants.items():
        percentage = count / total * 100
        print(f"   {quadrant}: {count} 个相机 ({percentage:.1f}%)")
    
    # 检查相机和点云的象限是否一致
    print(f"\n🔍 诊断:")
    if quadrants['第一象限 (X>0, Z>0)'] == total:
        print(f"   ✅ 所有相机都在第一象限（正确！）")
        print(f"   如果点云在第二象限，说明三角化或坐标系有问题")
    else:
        print(f"   ⚠️ 相机不在第一象限，可能有问题")
    
    print("="*60)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法: python 诊断SAR点云问题.py <sparse_dir>")
        print("例如: python 诊断SAR点云问题.py data/20/sparse/0")
        sys.exit(1)
    
    sparse_dir = sys.argv[1]
    points3d_file = os.path.join(sparse_dir, 'points3D.txt')
    images_file = os.path.join(sparse_dir, 'images.txt')
    
    if not os.path.exists(points3d_file):
        print(f"❌ 错误: 找不到点云文件 {points3d_file}")
        sys.exit(1)
    
    if not os.path.exists(images_file):
        print(f"❌ 错误: 找不到图像文件 {images_file}")
        sys.exit(1)
    
    analyze_point_cloud_distribution(points3d_file)
    analyze_camera_positions(images_file)
    
    print("\n💡 建议:")
    print("   1. 如果点云在第二象限但相机在第一象限，启用SAR BA:")
    print("      python convert.py --source_path ./data/20 --sfm_use_sar_ba")
    print("   2. 检查重投影误差是否过大（>100像素）")
    print("   3. 如果问题仍然存在，可能需要检查三角化方法")







