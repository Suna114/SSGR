#!/usr/bin/env python3
"""Standalone azimuth shadow refiner train/apply for isolated testing.

This entry point extracts only the shadow-refiner stages from the full novel-view
pipeline.  By default it does **not** run background fusion, so you can inspect
shadow training and apply results without touching the verified v12 figure flow.

Examples:
  python scripts/tools/shadow_refiner_standalone.py --dataset BTR70 --stage train
  python scripts/tools/shadow_refiner_standalone.py --dataset BTR70 --stage apply
  python scripts/tools/shadow_refiner_standalone.py --dataset BTR70 --stage both
  python scripts/tools/shadow_refiner_standalone.py --dataset BTR70 --isolated
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace


REPO_ROOT = Path(__file__).resolve().parents[2]
STAGES = ("train", "apply", "both")
PIPELINE_STAGE = {"train": "train_shadow", "apply": "apply_shadow"}


def _import_agent():
    sys.path.insert(0, str(REPO_ROOT / "scripts" / "pipeline"))
    import novel_view_agent as agent  # type: ignore

    return agent


def _default_agent_args(python: str, device: str, output_root: Path) -> SimpleNamespace:
    return SimpleNamespace(
        python=python,
        device=device,
        output_root=str(output_root),
        refiner_azimuth_shadow=True,
        azimuth_shadow_geometry_extent_gate=True,
        azimuth_shadow_geometry_extent_apply_to_recognition=True,
        azimuth_shadow_geometry_extent_require_dataset_direction=True,
        azimuth_shadow_geometry_extent_forward_scale=1.0,
        azimuth_shadow_geometry_extent_lateral_scale=1.0,
        azimuth_shadow_geometry_extent_margin_px=1.5,
        azimuth_shadow_geometry_extent_min_forward_px=0.0,
        matched_real_background=False,
        matched_background_strength=1.0,
        matched_background_shadow_alpha_source="apply_alpha",
        matched_background_hard_shadow_copy=False,
        matched_background_patch_size=24,
        matched_background_patch_overlap=6,
        matched_background_patch_smooth=1,
        matched_background_patch_smooth_mix=0.30,
        matched_background_reference_exclude_dilate=2,
        matched_background_nearest_refs=6,
        matched_background_reference_clean_blend_refs=4,
        matched_background_reference_clean_blend_mix=0.45,
        matched_background_reference_clean_angle_sigma=12.0,
        matched_background_reference_clean_patch_mix=0.20,
        matched_background_min_background_fraction=0.96,
        matched_background_stat_match="mean_std",
        matched_background_shadow_from_render_percentile=20.0,
        export_classification_labels=False,
        classification_source="extra",
        background_filtered_eval=False,
        background_filtered_eval_percentile=90.0,
        background_filtered_eval_gt_dir=None,
        background_filtered_eval_output_dir=None,
        azimuth_match_tolerance=5,
        azimuth_shadow_fixed_direction_deg=None,
    )


def _replace_stage(cmd: list[str], stage: str) -> None:
    for i, part in enumerate(cmd):
        if part == "--stage" and i + 1 < len(cmd):
            cmd[i + 1] = stage
            return
    raise RuntimeError("Could not locate --stage in pipeline command")


def _strip_background(cmd: list[str]) -> list[str]:
    out: list[str] = []
    skip_next = False
    for part in cmd:
        if skip_next:
            skip_next = False
            continue
        if part == "--background_after_shadow":
            out.append("--no-background_after_shadow")
            continue
        if part.startswith("--background_after_shadow_"):
            skip_next = True
            continue
        if part.startswith("--matched_") or part.startswith("--empirical_background_"):
            skip_next = True
            continue
        out.append(part)
    if "--no-background_after_shadow" not in out:
        out.append("--no-background_after_shadow")
    return out


def _append_shadow_only_flags(cmd: list[str], *, pipeline_stage: str) -> list[str]:
    extras = [
        "--no-export_classification_labels",
        "--no-target_shadow_eval",
        "--no-refiner_delta_eval",
        "--no-background_filtered_eval",
        "--no-adjacent_similarity_eval",
    ]
    if pipeline_stage == "apply_shadow":
        extras.append("--save_maps")
    for flag in extras:
        if flag.startswith("--no-"):
            positive = flag.replace("--no-", "--", 1)
            if positive in cmd:
                idx = cmd.index(positive)
                cmd[idx : idx + 2] = [flag]
        elif flag not in cmd:
            cmd.append(flag)
    return cmd


def _resolve_paths(
    dataset: str,
    output_root: Path,
    data_root: Path,
    *,
    isolated: bool,
    isolated_root: Path | None,
) -> dict[str, Path]:
    data_dir = data_root / dataset
    model_dir = output_root / dataset / "gaussian"
    if isolated:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        isolated_base = (isolated_root or (REPO_ROOT / "output" / "shadow_refiner_standalone")) / dataset / stamp
        refiner_work_dir = isolated_base / "refiner"
        shadow_output = isolated_base / "shadow_apply"
        shadow_checkpoint = isolated_base / "azimuth_shadow_refiner.pth"
        log_dir = isolated_base / "logs"
    else:
        isolated_base = None
        refiner_work_dir = output_root / dataset / "refiner"
        shadow_output = refiner_work_dir / "03.apply_postprocess" / "azimuth_shadow_refiner" / "apply"
        shadow_checkpoint = refiner_work_dir / "01.refiner" / "azimuth_shadow_refiner.pth"
        log_dir = REPO_ROOT / "output" / f"shadow_refiner_standalone_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    prod_base_ckpt = output_root / dataset / "refiner" / "01.refiner" / "sar_target_modulation_refiner_patchgan_no_ring.pth"
    return {
        "data_dir": data_dir,
        "model_dir": model_dir,
        "refiner_work_dir": refiner_work_dir,
        "gt_dir": data_dir / "input",
        "shadow_output": shadow_output,
        "shadow_checkpoint": shadow_checkpoint,
        "prod_base_ckpt": prod_base_ckpt,
        "log_dir": log_dir,
        "isolated_base": isolated_base,
    }


def _build_cmd(
    agent,
    agent_args: SimpleNamespace,
    paths: dict[str, Path],
    *,
    pipeline_stage: str,
    iterations: int | None,
) -> list[str]:
    cmd = agent._build_refiner_cmd(
        agent_args,
        paths["data_dir"],
        paths["model_dir"],
        paths["refiner_work_dir"],
        paths["gt_dir"],
        paths["gt_dir"],
        None,
        None,
    )
    _replace_stage(cmd, pipeline_stage)
    cmd = _strip_background(cmd)
    cmd = _append_shadow_only_flags(cmd, pipeline_stage=pipeline_stage)

    def _set(parts: list[str], flag: str, value: str) -> None:
        if flag in parts:
            parts[parts.index(flag) + 1] = value
        else:
            parts += [flag, value]

    _set(cmd, "--azimuth_shadow_output", str(paths["shadow_output"]))
    _set(cmd, "--azimuth_shadow_checkpoint", str(paths["shadow_checkpoint"]))
    if paths["isolated_base"] is not None and paths["prod_base_ckpt"].is_file():
        _set(cmd, "--base_checkpoint", str(paths["prod_base_ckpt"]))
    if iterations is not None:
        _set(cmd, "--azimuth_shadow_iterations", str(iterations))
    return cmd


def _run(cmd: list[str], log_path: Path) -> int:
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    proc = subprocess.run(
        cmd,
        cwd=str(REPO_ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
    )
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text(proc.stdout or "", encoding="utf-8")
    print(proc.stdout[-4000:] if proc.stdout else "")
    return int(proc.returncode)


def main() -> int:
    parser = argparse.ArgumentParser(description="Standalone azimuth shadow refiner train/apply.")
    parser.add_argument("--dataset", required=True, help="Dataset class name, e.g. BTR70.")
    parser.add_argument("--data_root", type=Path, default=REPO_ROOT / "data")
    parser.add_argument("--output_root", type=Path, default=REPO_ROOT / "output" / "final")
    parser.add_argument("--stage", choices=STAGES, default="both")
    parser.add_argument("--python", default=r"C:\Users\s\miniconda3\envs\3dgs\python.exe")
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument(
        "--isolated",
        action="store_true",
        help="Write to output/shadow_refiner_standalone/<dataset>/<timestamp>/ instead of output/final/<dataset>/refiner.",
    )
    parser.add_argument("--isolated_root", type=Path, default=None)
    parser.add_argument("--iterations", type=int, default=None, help="Override --azimuth_shadow_iterations.")
    parser.add_argument("--dry_run", action="store_true")
    args = parser.parse_args()

    agent = _import_agent()
    agent_args = _default_agent_args(args.python, args.device, args.output_root)
    paths = _resolve_paths(
        args.dataset,
        args.output_root.resolve(),
        args.data_root.resolve(),
        isolated=bool(args.isolated),
        isolated_root=args.isolated_root.resolve() if args.isolated_root else None,
    )

    if not paths["data_dir"].is_dir():
        raise SystemExit(f"Missing data dir: {paths['data_dir']}")
    if not paths["model_dir"].is_dir():
        raise SystemExit(f"Missing gaussian model dir: {paths['model_dir']}")
    if bool(args.isolated) and not paths["prod_base_ckpt"].is_file():
        raise SystemExit(f"Isolated mode requires production base checkpoint: {paths['prod_base_ckpt']}")

    stages = ["train", "apply"] if args.stage == "both" else [args.stage]
    paths["log_dir"].mkdir(parents=True, exist_ok=True)

    print(f"Dataset       : {args.dataset}")
    print(f"Work dir      : {paths['refiner_work_dir']}")
    print(f"Shadow output : {paths['shadow_output']}")
    print(f"Checkpoint    : {paths['shadow_checkpoint']}")
    print(f"Logs          : {paths['log_dir']}")

    for stage in stages:
        pipeline_stage = PIPELINE_STAGE[stage]
        cmd = _build_cmd(agent, agent_args, paths, pipeline_stage=pipeline_stage, iterations=args.iterations)
        log_path = paths["log_dir"] / f"{args.dataset}_{pipeline_stage}.log"
        print(f"\n==== {args.dataset} / {pipeline_stage} ====")
        print(" ".join(f'"{p}"' if " " in p else p for p in cmd))
        if args.dry_run:
            continue
        code = _run(cmd, log_path)
        if code != 0:
            print(f"Failed: exit {code}, log={log_path}")
            return code

    if not args.dry_run:
        print(f"\nDone. Inspect renders: {paths['shadow_output'] / 'renders'}")
        print(f"Maps: {paths['shadow_output'] / 'maps'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
