#!/usr/bin/env python3
"""Build GT | Gaussian montage: 10 classes x 2 cols x N rows with azimuth labels."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

DEFAULT_CLASSES = [
    "2S1",
    "BMP2",
    "BRDM_2",
    "BTR70",
    "D7",
    "SLICY",
    "T62",
    "T72",
    "ZIL131",
    "ZSU_23_4",
]

DEFAULT_LABEL_FONT = Path(r"C:\Windows\Fonts\timesbd.ttf")
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp")


def _load_font(size: int, font_path: Path | None = None) -> ImageFont.ImageFont:
    candidates: list[Path] = []
    if font_path is not None:
        candidates.append(font_path)
    candidates.extend(
        [
            DEFAULT_LABEL_FONT,
            Path(r"C:\Windows\Fonts\times.ttf"),
            Path(r"C:\Windows\Fonts\arialbd.ttf"),
        ]
    )
    for path in candidates:
        if path.is_file():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def _text_bbox(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont) -> tuple[int, int, int, int]:
    return draw.textbbox((0, 0), text, font=font, anchor="lt")


def _text_size(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont) -> tuple[int, int]:
    box = _text_bbox(draw, text, font)
    return box[2] - box[0], box[3] - box[1]


def _fit_font_to_height(
    labels: list[str],
    font_path: Path,
    target_height: int,
    start_size: int,
) -> ImageFont.ImageFont:
    size = max(8, start_size)
    measure = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    while size > 8:
        font = _load_font(size, font_path)
        if max(_text_size(measure, label, font)[1] for label in labels) <= target_height:
            return font
        size -= 1
    return _load_font(max(8, size), font_path)


def _pick_equal_indices(total: int, count: int) -> list[int]:
    if total <= 0:
        return []
    if count <= 1:
        return [0]
    if count >= total:
        return list(range(total))
    return [int(round(i * total / count)) % total for i in range(count)]


def _azimuth_from_render(path: Path) -> int:
    return int(path.stem.split("_", 1)[1])


def _azimuth_from_gt(path: Path) -> int:
    suffix = path.stem.rsplit("-", 1)[-1]
    return int(suffix) if suffix.isdigit() else 0


def _list_renders(render_dir: Path) -> list[Path]:
    paths = sorted(render_dir.glob("azimuth_*.png"), key=_azimuth_from_render)
    if not paths:
        raise FileNotFoundError(f"No azimuth_*.png under {render_dir}")
    return paths


def _list_gt_images(gt_dir: Path) -> list[Path]:
    paths = [p for p in gt_dir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    if not paths:
        raise FileNotFoundError(f"No GT images under {gt_dir}")
    return paths


def _find_nearest_gt(gt_files: list[Path], azimuth: int) -> Path:
    return min(gt_files, key=lambda path: abs(_azimuth_from_gt(path) - azimuth))


def _collect_pairs(
    class_name: str,
    render_dir: Path,
    gt_dir: Path,
    pick_count: int,
) -> list[tuple[int, Path, Path]]:
    renders = _list_renders(render_dir)
    gt_files = _list_gt_images(gt_dir)
    indices = _pick_equal_indices(len(renders), pick_count)
    pairs: list[tuple[int, Path, Path]] = []
    for idx in indices:
        render_path = renders[idx]
        azimuth = _azimuth_from_render(render_path)
        gt_path = _find_nearest_gt(gt_files, azimuth)
        pairs.append((azimuth, gt_path, render_path))
    if len(pairs) < pick_count:
        raise RuntimeError(f"{class_name}: only collected {len(pairs)}/{pick_count} pairs")
    return pairs


def _fit_cell(im: Image.Image, cell_size: int, bg: tuple[int, int, int]) -> Image.Image:
    if im.mode == "RGBA":
        base = Image.new("RGB", im.size, bg)
        base.paste(im, mask=im.split()[3])
        im = base
    elif im.mode != "RGB":
        im = im.convert("RGB")
    return im.resize((cell_size, cell_size), Image.Resampling.LANCZOS)


def build_montage(
    render_root: Path,
    gt_root: Path,
    classes: list[str],
    render_relpath: Path,
    pick_count: int,
    cell_size: int,
    gap: int,
    class_gap: int,
    label_padding: int,
    bgcolor: str,
    label_font_path: Path | None,
    label_font_ratio: float,
) -> Image.Image:
    bg = (255, 255, 255) if bgcolor == "white" else (0, 0, 0)
    text_color = (0, 0, 0) if bgcolor == "white" else (255, 255, 255)

    class_pairs: dict[str, list[tuple[int, Path, Path]]] = {}
    for cls in classes:
        render_dir = render_root / cls / render_relpath
        gt_dir = gt_root / cls
        class_pairs[cls] = _collect_pairs(cls, render_dir, gt_dir, pick_count)

    target_text_h = max(8, int(round(cell_size * label_font_ratio)))
    row_azimuths = [az for az, _, _ in class_pairs[classes[0]]]
    azimuth_labels = [f"{az}°" for az in row_azimuths]
    font = _fit_font_to_height(classes + azimuth_labels, label_font_path or DEFAULT_LABEL_FONT, target_text_h, target_text_h)

    measure = ImageDraw.Draw(Image.new("RGB", (1, 1), bg))
    class_text_h = max(_text_size(measure, cls, font)[1] for cls in classes)
    az_text_w = max(_text_size(measure, label, font)[0] for label in azimuth_labels)
    left_pad = az_text_w + label_padding
    top_pad = class_text_h + label_padding

    block_w = cell_size + gap + cell_size
    grid_h = pick_count * cell_size + max(0, pick_count - 1) * gap
    out_w = left_pad + len(classes) * block_w + max(0, len(classes) - 1) * class_gap
    out_h = top_pad + grid_h
    mosaic = Image.new("RGB", (out_w, out_h), bg)
    draw = ImageDraw.Draw(mosaic)

    y0 = top_pad
    for row, az in enumerate(row_azimuths):
        row_center_y = y0 + row * (cell_size + gap) + cell_size / 2.0
        draw.text((left_pad / 2.0, row_center_y), f"{az}°", fill=text_color, font=font, anchor="mm")

    for idx, cls in enumerate(classes):
        x0 = left_pad + idx * (block_w + class_gap)
        block_center_x = x0 + block_w / 2.0
        draw.text((block_center_x, class_text_h / 2.0), cls.replace("_", " "), fill=text_color, font=font, anchor="mm")

        gt_x = x0
        gauss_x = x0 + cell_size + gap
        for row, (_, gt_path, render_path) in enumerate(class_pairs[cls]):
            y = y0 + row * (cell_size + gap)
            with Image.open(gt_path) as gt_im:
                mosaic.paste(_fit_cell(gt_im, cell_size, bg), (gt_x, y))
            with Image.open(render_path) as render_im:
                mosaic.paste(_fit_cell(render_im, cell_size, bg), (gauss_x, y))

    return mosaic


def main() -> int:
    repo = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description="GT | Gaussian montage for agent2 vs GT folder.")
    parser.add_argument(
        "--render-root",
        type=Path,
        default=Path(r"F:\3dgs\SSGR\output\agent2"),
    )
    parser.add_argument(
        "--gt-root",
        type=Path,
        default=Path(r"F:\3dgs\新建文件夹\15"),
    )
    parser.add_argument(
        "--render-relpath",
        type=Path,
        default=Path("gaussian/novel_target_only/renders"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=repo / "output" / "final" / "picture2" / "fig_sfm_ablation_agent2_gt_gaussian_montage.png",
    )
    parser.add_argument("--classes", nargs="*", default=DEFAULT_CLASSES)
    parser.add_argument("--pick-count", type=int, default=6)
    parser.add_argument("--cell-size", type=int, default=128)
    parser.add_argument("--gap", type=int, default=12)
    parser.add_argument("--class-gap", type=int, default=12)
    parser.add_argument(
        "--label-padding",
        type=int,
        default=6,
        help="Gap below top class labels and right of azimuth labels (default 6 when gap=12).",
    )
    parser.add_argument("--bgcolor", choices=("black", "white"), default="white")
    parser.add_argument(
        "--label-font-ratio",
        type=float,
        default=0.2,
        help="Label cap height = cell_size * ratio (default 0.2 ~ 1/5 of cell).",
    )
    parser.add_argument("--label-font", type=Path, default=DEFAULT_LABEL_FONT)
    args = parser.parse_args()

    mosaic = build_montage(
        render_root=args.render_root.resolve(),
        gt_root=args.gt_root.resolve(),
        classes=list(args.classes),
        render_relpath=args.render_relpath,
        pick_count=max(1, args.pick_count),
        cell_size=max(1, args.cell_size),
        gap=max(0, args.gap),
        class_gap=max(0, args.class_gap),
        label_padding=max(0, args.label_padding),
        bgcolor=args.bgcolor,
        label_font_path=args.label_font.resolve() if args.label_font else None,
        label_font_ratio=args.label_font_ratio,
    )
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    mosaic.save(output, quality=95)
    print(f"[prepare_gt_gaussian] output: {output} ({mosaic.width}x{mosaic.height})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
