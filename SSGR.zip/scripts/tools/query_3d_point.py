#!/usr/bin/env python

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
3D点查询工具 - 查询3D点对应的2D匹配点位置

使用方法：
    python query_3d_point.py --source_path <数据路径> --point_id <3D点ID> [其他选项]

示例：
    # 查询点ID为100的3D点在所有图像中的位置
    python query_3d_point.py --source_path ./data --point_id 100
    
    # 查询并保存可视化图像
    python query_3d_point.py --source_path ./data --point_id 100 --save_images
    
    # 查询多个点
    python query_3d_point.py --source_path ./data --point_id 100,200,300
"""
import os
import sys
import struct
import argparse
import numpy as np
import cv2
import pickle
from pathlib import Path

# 添加当前目录到路径，以便导入sfm_utils
sys.path.append(os.path.dirname(__file__))
from sfm_utils import DeserializeKeypoints, DeserializeMatches
import pickle


def read_cameras_bin(cameras_file):
    """读取COLMAP格式的cameras.bin文件"""
    cameras = {}
    with open(cameras_file, 'rb') as f:
        num_cameras = struct.unpack('<Q', f.read(8))[0]
        for _ in range(num_cameras):
            camera_id = struct.unpack('<i', f.read(4))[0]
            model_id = struct.unpack('<i', f.read(4))[0]
            width = struct.unpack('<Q', f.read(8))[0]
            height = struct.unpack('<Q', f.read(8))[0]
            
            if model_id == 1:  # PINHOLE模型
                params = struct.unpack('<dddd', f.read(32))
                fx, fy, cx, cy = params
                cameras[camera_id] = {
                    'model': 'PINHOLE',
                    'width': width,
                    'height': height,
                    'fx': fx,
                    'fy': fy,
                    'cx': cx,
                    'cy': cy
                }
    return cameras


def read_images_bin(images_file):
    """读取COLMAP格式的images.bin文件"""
    images = {}
    image_id_to_name = {}
    
    with open(images_file, 'rb') as f:
        num_images = struct.unpack('<Q', f.read(8))[0]
        
        for _ in range(num_images):
            image_id = struct.unpack('<i', f.read(4))[0]
            
            # 读取四元数 [w, x, y, z]
            quat = struct.unpack('<dddd', f.read(32))
            qw, qx, qy, qz = quat
            
            # 读取平移向量
            tvec = struct.unpack('<ddd', f.read(24))
            
            # 读取相机ID
            camera_id = struct.unpack('<i', f.read(4))[0]
            
            # 读取图像名称（以null结尾）
            image_name_bytes = b''
            while True:
                char = f.read(1)
                if char == b'\x00':
                    break
                image_name_bytes += char
            image_name = image_name_bytes.decode('utf-8')
            
            # 读取2D点信息
            num_points2d = struct.unpack('<Q', f.read(8))[0]
            points2d = []
            point3d_ids = []
            
            for _ in range(num_points2d):
                x, y, point3d_id = struct.unpack('<ddq', f.read(24))
                points2d.append((x, y))
                point3d_ids.append(point3d_id)
            
            images[image_id] = {
                'name': image_name,
                'quat': quat,
                'tvec': tvec,
                'camera_id': camera_id,
                'points2d': points2d,
                'point3d_ids': point3d_ids
            }
            image_id_to_name[image_id] = image_name
    
    return images, image_id_to_name


def read_points3d_bin(points3d_file):
    """读取COLMAP格式的points3D.bin文件"""
    points3d = {}
    
    with open(points3d_file, 'rb') as f:
        num_points = struct.unpack('<Q', f.read(8))[0]
        
        for _ in range(num_points):
            point3d_id = struct.unpack('<Q', f.read(8))[0]
            x, y, z = struct.unpack('<ddd', f.read(24))
            r, g, b = struct.unpack('<BBB', f.read(3))
            error = struct.unpack('<d', f.read(8))[0]
            
            # 读取track信息
            track_length = struct.unpack('<Q', f.read(8))[0]
            track = []
            for _ in range(track_length):
                image_id, point2d_idx = struct.unpack('<ii', f.read(8))
                track.append((image_id, point2d_idx))
            
            points3d[point3d_id] = {
                'xyz': np.array([x, y, z]),
                'rgb': np.array([r, g, b]),
                'error': error,
                'track': track
            }
    
    return points3d


def read_points3d_txt(points3d_file):
    """读取COLMAP格式的points3D.txt文件"""
    points3d = {}
    
    with open(points3d_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            parts = line.split()
            if len(parts) < 8:
                continue
            
            point3d_id = int(parts[0])
            x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
            r, g, b = int(parts[4]), int(parts[5]), int(parts[6])
            error = float(parts[7])
            
            # 解析track信息
            track = []
            if len(parts) > 8:
                for i in range(8, len(parts), 2):
                    if i + 1 < len(parts):
                        image_id = int(parts[i])
                        point2d_idx = int(parts[i + 1])
                        track.append((image_id, point2d_idx))
            
            points3d[point3d_id] = {
                'xyz': np.array([x, y, z]),
                'rgb': np.array([r, g, b]),
                'error': error,
                'track': track
            }
    
    return points3d


def read_images_txt(images_file):
    """读取COLMAP格式的images.txt文件"""
    images = {}
    image_id_to_name = {}
    
    with open(images_file, 'r') as f:
        lines = f.readlines()
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if not line or line.startswith('#'):
                i += 1
                continue
            
            # 第一行：图像信息
            parts = line.split()
            if len(parts) < 10:
                i += 1
                continue
            
            image_id = int(parts[0])
            qw, qx, qy, qz = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
            tx, ty, tz = float(parts[5]), float(parts[6]), float(parts[7])
            camera_id = int(parts[8])
            image_name = ' '.join(parts[9:])
            
            # 第二行：2D点信息
            i += 1
            if i >= len(lines):
                break
            
            points_line = lines[i].strip()
            points_parts = points_line.split()
            
            points2d = []
            point3d_ids = []
            
            for j in range(0, len(points_parts), 3):
                if j + 2 < len(points_parts):
                    x = float(points_parts[j])
                    y = float(points_parts[j + 1])
                    point3d_id = int(points_parts[j + 2])
                    points2d.append((x, y))
                    point3d_ids.append(point3d_id)
            
            images[image_id] = {
                'name': image_name,
                'quat': (qw, qx, qy, qz),
                'tvec': (tx, ty, tz),
                'camera_id': camera_id,
                'points2d': points2d,
                'point3d_ids': point3d_ids
            }
            image_id_to_name[image_id] = image_name
            
            i += 1
    
    return images, image_id_to_name


def visualize_match_pair(image1_path, image2_path, point1_2d, point2_2d, point3d_id,
                        image1_name, image2_name, output_path=None, radius=5):
    """可视化匹配对图像，显示两个图像中的对应点
    
    Args:
        image1_path: 第一张图像路径
        image2_path: 第二张图像路径
        point1_2d: 第一张图像中的2D点坐标 (x, y)
        point2_2d: 第二张图像中的2D点坐标 (x, y)
        point3d_id: 3D点ID
        image1_name: 第一张图像名称
        image2_name: 第二张图像名称
        output_path: 输出图像路径
        radius: 标记点半径
    """
    # 读取两张图像
    img1 = cv2.imread(image1_path)
    img2 = cv2.imread(image2_path)
    
    if img1 is None:
        print(f"   ⚠️ 无法读取图像: {image1_path}")
        return None
    if img2 is None:
        print(f"   ⚠️ 无法读取图像: {image2_path}")
        return None
    
    # 转换为RGB（用于显示）
    if len(img1.shape) == 2:
        img1_display = cv2.cvtColor(img1, cv2.COLOR_GRAY2BGR)
    else:
        img1_display = img1.copy()
    
    if len(img2.shape) == 2:
        img2_display = cv2.cvtColor(img2, cv2.COLOR_GRAY2BGR)
    else:
        img2_display = img2.copy()
    
    h1, w1 = img1_display.shape[:2]
    h2, w2 = img2_display.shape[:2]
    
    # 调整图像大小以便并排显示（保持宽高比）
    max_height = max(h1, h2)
    scale1 = max_height / h1 if h1 > 0 else 1.0
    scale2 = max_height / h2 if h2 > 0 else 1.0
    
    new_w1 = int(w1 * scale1)
    new_h1 = int(h1 * scale1)
    new_w2 = int(w2 * scale2)
    new_h2 = int(h2 * scale2)
    
    img1_resized = cv2.resize(img1_display, (new_w1, new_h1))
    img2_resized = cv2.resize(img2_display, (new_w2, new_h2))
    
    # 确保坐标是标量值（处理元组、列表或numpy数组）
    if isinstance(point1_2d, (tuple, list, np.ndarray)):
        point1_x = float(point1_2d[0])
        point1_y = float(point1_2d[1])
    else:
        point1_x = float(point1_2d)
        point1_y = float(point1_2d)
    
    if isinstance(point2_2d, (tuple, list, np.ndarray)):
        point2_x = float(point2_2d[0])
        point2_y = float(point2_2d[1])
    else:
        point2_x = float(point2_2d)
        point2_y = float(point2_2d)
    
    # 调整点坐标
    x1, y1 = int(point1_x * scale1), int(point1_y * scale1)
    x2, y2 = int(point2_x * scale2), int(point2_y * scale2)
    
    # 在第一张图像中绘制点
    if 0 <= x1 < new_w1 and 0 <= y1 < new_h1:
        cv2.circle(img1_resized, (x1, y1), radius, (0, 255, 0), 2)
        cross_size = radius + 2
        cv2.line(img1_resized, (x1 - cross_size, y1), (x1 + cross_size, y1), (0, 255, 0), 1)
        cv2.line(img1_resized, (x1, y1 - cross_size), (x1, y1 + cross_size), (0, 255, 0), 1)
    
    # 在第二张图像中绘制点
    if 0 <= x2 < new_w2 and 0 <= y2 < new_h2:
        cv2.circle(img2_resized, (x2, y2), radius, (0, 255, 0), 2)
        cross_size = radius + 2
        cv2.line(img2_resized, (x2 - cross_size, y2), (x2 + cross_size, y2), (0, 255, 0), 1)
        cv2.line(img2_resized, (x2, y2 - cross_size), (x2, y2 + cross_size), (0, 255, 0), 1)
    
    # 并排拼接图像
    # 如果高度不同，用黑色填充
    if new_h1 != new_h2:
        if new_h1 < new_h2:
            padding = np.zeros((new_h2 - new_h1, new_w1, 3), dtype=np.uint8)
            img1_resized = np.vstack([img1_resized, padding])
        else:
            padding = np.zeros((new_h1 - new_h2, new_w2, 3), dtype=np.uint8)
            img2_resized = np.vstack([img2_resized, padding])
    
    combined_image = np.hstack([img1_resized, img2_resized])
    
    # 添加分隔线
    separator_x = new_w1
    cv2.line(combined_image, (separator_x, 0), (separator_x, combined_image.shape[0]), (255, 255, 255), 2)
    
    # 添加文本信息（在顶部，不遮挡图像内容）
    info_height = 60
    info_panel = np.ones((info_height, combined_image.shape[1], 3), dtype=np.uint8) * 255
    
    # 添加信息文本
    info_text = [
        f"3D Point ID: {point3d_id}",
        f"Left: {image1_name} | Right: {image2_name}",
        f"Left Coord: ({point1_x:.2f}, {point1_y:.2f}) | Right Coord: ({point2_x:.2f}, {point2_y:.2f})"
    ]
    
    for i, text in enumerate(info_text):
        y_pos = 20 + i * 18
        cv2.putText(info_panel, text, (10, y_pos),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    
    # 合并信息面板和图像
    final_image = np.vstack([info_panel, combined_image])
    
    # 绘制连接线（在两张图像之间）
    line_y1 = info_height + y1
    line_y2 = info_height + y2
    line_x2 = separator_x + x2
    
    # 绘制连接线（从第一张图像的点到第二张图像的点）
    cv2.line(final_image, (x1, line_y1), (line_x2, line_y2), (0, 255, 255), 1)
    
    # 保存图像
    if output_path:
        success = cv2.imwrite(output_path, final_image)
        if success:
            print(f"   ✅ 已保存匹配对可视化图像: {output_path}")
            return True
        else:
            print(f"   ❌ 保存匹配对可视化图像失败: {output_path}")
            return False
    
    # 如果没有输出路径，返回True表示成功生成图像
    return True


def visualize_point_in_image(image_path, point2d, point3d_id, output_path=None, radius=5, 
                             show_label=True, label_position='corner'):
    """在图像中可视化2D点位置
    
    Args:
        image_path: 图像文件路径
        point2d: 2D点坐标 (x, y)
        point3d_id: 3D点ID
        output_path: 输出图像路径
        radius: 标记点半径
        show_label: 是否显示标签
        label_position: 标签位置 ('corner'=角落, 'near'=点附近, 'none'=不显示)
    """
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"   ⚠️ 无法读取图像: {image_path}")
        return None
    
    # 转换为RGB（用于显示）
    if len(image.shape) == 2:
        image_display = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    else:
        image_display = image.copy()
    
    height, width = image_display.shape[:2]
    
    # 绘制点
    x, y = int(point2d[0]), int(point2d[1])
    if 0 <= x < width and 0 <= y < height:
        # 绘制圆圈（更明显但不太遮挡）
        cv2.circle(image_display, (x, y), radius, (0, 255, 0), 2)
        # 绘制十字（更精确）
        cross_size = radius + 2
        cv2.line(image_display, (x - cross_size, y), (x + cross_size, y), (0, 255, 0), 1)
        cv2.line(image_display, (x, y - cross_size), (x, y + cross_size), (0, 255, 0), 1)
        
        # 添加文本标签（根据位置选择）
        if show_label:
            if label_position == 'corner':
                # 在图像角落显示信息，不遮挡内容
                label_lines = [
                    f"3D Point ID: {point3d_id}",
                    f"2D Coord: ({point2d[0]:.2f}, {point2d[1]:.2f})"
                ]
                # 在左上角显示
                y_offset = 25
                for i, line in enumerate(label_lines):
                    cv2.putText(image_display, line, (10, y_offset + i * 25),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 3)  # 黑色背景
                    cv2.putText(image_display, line, (10, y_offset + i * 25),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)  # 绿色文字
            elif label_position == 'near':
                # 在点附近显示，但尽量不遮挡
                label = f"ID:{point3d_id}"
                # 根据点位置选择标签位置（避免超出边界）
                label_x = x + radius + 5
                label_y = y - radius - 5
                
                # 如果标签会超出右边界，放在左边
                if label_x + 80 > width:
                    label_x = x - radius - 80
                
                # 如果标签会超出上边界，放在下面
                if label_y < 15:
                    label_y = y + radius + 15
                
                cv2.putText(image_display, label, (label_x, label_y),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 2)  # 黑色背景
                cv2.putText(image_display, label, (label_x, label_y),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)  # 绿色文字
    
    # 保存图像
    if output_path:
        success = cv2.imwrite(output_path, image_display)
        if success:
            print(f"   ✅ 已保存可视化图像: {output_path}")
            return True
        else:
            print(f"   ❌ 保存可视化图像失败: {output_path}")
            return False
    
    # 如果没有输出路径，返回True表示成功生成图像
    return True


def find_image_path(images_dir, image_name):
    """查找图像文件路径"""
    if images_dir is None or not os.path.exists(images_dir):
        return None
    
    image_extensions = ['.jpg', '.jpeg', '.png', '.tif', '.tiff']
    image_name_base = os.path.splitext(image_name)[0]
    
    # 首先尝试直接使用图像名称
    image_path = os.path.join(images_dir, image_name)
    if os.path.exists(image_path):
        return image_path
    
    # 尝试不带扩展名的文件名 + 各种扩展名
    for ext in image_extensions:
        image_path = os.path.join(images_dir, image_name_base + ext)
        if os.path.exists(image_path):
            return image_path
    
    # 尝试带扩展名的文件名（如果原名称没有扩展名）
    if '.' not in image_name:
        for ext in image_extensions:
            image_path = os.path.join(images_dir, image_name + ext)
            if os.path.exists(image_path):
                return image_path
    
    return None


def load_matches(matches_dir, image1_name, image2_name):
    """加载匹配文件"""
    # 移除扩展名
    name1_base = os.path.splitext(image1_name)[0]
    name2_base = os.path.splitext(image2_name)[0]
    
    # 尝试两种文件名顺序
    match_file1 = os.path.join(matches_dir, f'match_{name1_base}_{name2_base}.pkl')
    match_file2 = os.path.join(matches_dir, f'match_{name2_base}_{name1_base}.pkl')
    
    match_file = None
    if os.path.exists(match_file1):
        match_file = match_file1
        swap_indices = False
    elif os.path.exists(match_file2):
        match_file = match_file2
        swap_indices = True
    else:
        return None, False
    
    try:
        with open(match_file, 'rb') as f:
            matches = pickle.load(f)
        matches = DeserializeMatches(matches)
        
        # 如果使用的是反向文件名，需要交换queryIdx和trainIdx
        if swap_indices:
            swapped_matches = []
            for m in matches:
                new_match = cv2.DMatch()
                new_match.queryIdx = m.trainIdx
                new_match.trainIdx = m.queryIdx
                new_match.imgIdx = m.imgIdx
                new_match.distance = m.distance
                swapped_matches.append(new_match)
            matches = swapped_matches
        
        return matches, False
    except Exception as e:
        print(f"   ⚠️ 警告: 加载匹配文件失败: {e}")
        return None, False


def query_3d_point(source_path, point_ids, sfm_out_dir=None, save_images=False, output_dir=None,
                  save_coordinates=False, coordinates_file=None, visualize_pairs=True):
    """查询3D点对应的2D位置"""
    
    # 确定输出目录
    if sfm_out_dir is None:
        sfm_out_dir = os.path.join(source_path, "sfm_results")
    
    sparse_dir = os.path.join(sfm_out_dir, "sparse", "0")
    
    # 检查文件是否存在
    points3d_bin = os.path.join(sparse_dir, "points3D.bin")
    points3d_txt = os.path.join(sparse_dir, "points3D.txt")
    images_bin = os.path.join(sparse_dir, "images.bin")
    images_txt = os.path.join(sparse_dir, "images.txt")
    
    # 读取点云数据
    print("📖 读取点云数据...")
    if os.path.exists(points3d_bin):
        points3d = read_points3d_bin(points3d_bin)
        print(f"   ✅ 从二进制文件读取 {len(points3d)} 个3D点")
    elif os.path.exists(points3d_txt):
        points3d = read_points3d_txt(points3d_txt)
        print(f"   ✅ 从文本文件读取 {len(points3d)} 个3D点")
    else:
        print(f"   ❌ 错误: 找不到点云文件")
        print(f"      查找路径: {points3d_bin} 或 {points3d_txt}")
        return False
    
    # 读取图像数据
    print("📖 读取图像数据...")
    if os.path.exists(images_bin):
        images, image_id_to_name = read_images_bin(images_bin)
        print(f"   ✅ 从二进制文件读取 {len(images)} 张图像")
    elif os.path.exists(images_txt):
        images, image_id_to_name = read_images_txt(images_txt)
        print(f"   ✅ 从文本文件读取 {len(images)} 张图像")
    else:
        print(f"   ❌ 错误: 找不到图像文件")
        print(f"      查找路径: {images_bin} 或 {images_txt}")
        return False
    
    # 查找图像目录（按优先级）
    images_dir = None
    possible_dirs = [
        os.path.join(source_path, "images"),
        os.path.join(source_path, "input"),
        os.path.join(sfm_out_dir, "images"),
        source_path  # 最后尝试直接在源目录中查找
    ]
    
    for dir_path in possible_dirs:
        if os.path.exists(dir_path):
            # 检查目录中是否有图像文件
            image_extensions = ['.jpg', '.jpeg', '.png', '.tif', '.tiff']
            has_images = False
            for file in os.listdir(dir_path):
                if any(file.lower().endswith(ext) for ext in image_extensions):
                    has_images = True
                    break
            
            if has_images:
                images_dir = dir_path
                print(f"   ✅ 找到图像目录: {images_dir}")
                break
    
    if images_dir is None:
        print(f"   ⚠️ 警告: 找不到图像目录，将无法可视化")
        print(f"      查找路径: {possible_dirs}")
    
    # 创建输出目录
    if save_images and output_dir:
        os.makedirs(output_dir, exist_ok=True)
    
    # 查找匹配文件目录
    matches_dir = None
    if visualize_pairs:
        # 尝试多个可能的匹配目录位置
        possible_match_dirs = [
            os.path.join(source_path, "matches"),
            os.path.join(sfm_out_dir, "matches"),
            os.path.join(source_path, "sfm_results", "matches"),
        ]
        
        # 从图像数据中推断数据集名称
        if images and len(images) > 0:
            # 尝试从图像路径推断
            first_image_name = list(images.values())[0]['name']
            # 尝试常见的目录结构
            dataset_name = os.path.basename(os.path.normpath(source_path))
            possible_match_dirs.extend([
                os.path.join(source_path, dataset_name, "matches", "SAR_SIFT"),
                os.path.join(source_path, dataset_name, "matches"),
            ])
        
        for match_dir in possible_match_dirs:
            if os.path.exists(match_dir):
                matches_dir = match_dir
                print(f"   ✅ 找到匹配文件目录: {matches_dir}")
                break
        
        if matches_dir is None:
            print(f"   ⚠️ 警告: 找不到匹配文件目录，将无法生成匹配对图像")
            print(f"      查找路径: {possible_match_dirs}")
            visualize_pairs = False
    
    # 处理每个点ID
    saved_count = 0
    for point_id in point_ids:
        print(f"\n{'='*60}")
        print(f"🔍 查询3D点 ID={point_id}")
        print(f"{'='*60}")
        
        if point_id not in points3d:
            print(f"   ❌ 错误: 点ID {point_id} 不存在")
            print(f"      有效点ID范围: 1-{len(points3d)}")
            continue
        
        point_data = points3d[point_id]
        xyz = point_data['xyz']
        rgb = point_data['rgb']
        error = point_data['error']
        track = point_data['track']
        
        print(f"\n   📍 3D坐标: ({xyz[0]:.6f}, {xyz[1]:.6f}, {xyz[2]:.6f})")
        print(f"   🎨 RGB颜色: ({int(rgb[0])}, {int(rgb[1])}, {int(rgb[2])})")
        print(f"   📊 Track长度: {len(track)} (出现在 {len(track)} 张图像中)")
        if error > 0:
            print(f"   ⚠️ 重投影误差: {error:.6f}")
        
        # 显示该点在每张图像中的位置
        print(f"\n   📸 该点在以下图像中的位置:")
        print(f"   {'序号':<6} {'图像名称':<40} {'图像ID':<10} {'2D坐标(X,Y)':<20} {'2D索引':<10}")
        print(f"   {'-'*90}")
        
        valid_tracks = 0
        coordinates_summary = []  # 用于保存坐标摘要
        
        for idx, (image_id, point2d_idx) in enumerate(track, 1):
            if image_id not in images:
                print(f"   {idx:<6} 图像ID {image_id}: ❌ 图像数据不存在")
                continue
            
            image_info = images[image_id]
            image_name = image_info['name']
            
            if point2d_idx < 0 or point2d_idx >= len(image_info['points2d']):
                print(f"   {idx:<6} {image_name:<40} {image_id:<10} ❌ 2D点索引无效 ({point2d_idx})")
                continue
            
            point2d = image_info['points2d'][point2d_idx]
            x, y = point2d
            
            # 格式化显示
            coord_str = f"({x:.2f}, {y:.2f})"
            print(f"   {idx:<6} {image_name[:38]:<40} {image_id:<10} {coord_str:<20} {point2d_idx:<10}")
            
            # 保存坐标摘要
            coordinates_summary.append({
                'image_id': image_id,
                'image_name': image_name,
                'point2d_idx': point2d_idx,
                'x': x,
                'y': y
            })
            
            valid_tracks += 1
        
        # 可视化匹配对
        if save_images and output_dir and visualize_pairs and matches_dir and len(coordinates_summary) >= 2:
            print(f"\n   🎨 生成匹配对可视化图像...")
            
            # 为每对图像生成匹配对可视化
            for i in range(len(coordinates_summary)):
                for j in range(i + 1, len(coordinates_summary)):
                    coord1 = coordinates_summary[i]
                    coord2 = coordinates_summary[j]
                    
                    # 查找图像文件
                    image1_path = find_image_path(images_dir, coord1['image_name']) if images_dir else None
                    image2_path = find_image_path(images_dir, coord2['image_name']) if images_dir else None
                    
                    if not image1_path or not image2_path:
                        continue
                    
                    # 清理文件名
                    safe_name1 = "".join(c for c in os.path.splitext(coord1['image_name'])[0] 
                                        if c.isalnum() or c in ('_', '-'))
                    safe_name2 = "".join(c for c in os.path.splitext(coord2['image_name'])[0] 
                                        if c.isalnum() or c in ('_', '-'))
                    
                    output_image_path = os.path.join(
                        output_dir,
                        f"point_{point_id}_pair_{coord1['image_id']}_{coord2['image_id']}_{safe_name1}_{safe_name2}.png"
                    )
                    
                    # 生成匹配对可视化
                    if visualize_match_pair(
                        image1_path, image2_path,
                        (coord1['x'], coord1['y']), (coord2['x'], coord2['y']),
                        point_id,
                        coord1['image_name'], coord2['image_name'],
                        output_image_path
                    ):
                        saved_count += 1
        
        # 如果没有匹配对可视化，使用单图像可视化
        elif save_images and output_dir and not visualize_pairs:
            print(f"\n   🎨 生成单图像可视化...")
            for coord in coordinates_summary:
                image_path = find_image_path(images_dir, coord['image_name']) if images_dir else None
                if image_path:
                    safe_image_name = "".join(c for c in os.path.splitext(coord['image_name'])[0] 
                                             if c.isalnum() or c in ('_', '-'))
                    output_image_path = os.path.join(
                        output_dir,
                        f"point_{point_id}_image_{coord['image_id']}_{safe_image_name}.png"
                    )
                    if visualize_point_in_image(image_path, (coord['x'], coord['y']), point_id, 
                                               output_image_path, label_position='corner'):
                        saved_count += 1
        elif save_images and not output_dir:
            if len(coordinates_summary) > 0:
                print(f"         💡 提示: 使用 --save_images 保存可视化图像")
        
        # 显示坐标摘要
        if coordinates_summary:
            print(f"\n   📋 2D坐标摘要 (共 {len(coordinates_summary)} 个点):")
            for coord in coordinates_summary:
                print(f"      {coord['image_name']}: ({coord['x']:.6f}, {coord['y']:.6f})")
            
            # 保存坐标到文件
            if save_coordinates:
                if coordinates_file is None:
                    if output_dir:
                        os.makedirs(output_dir, exist_ok=True)
                        coordinates_file = os.path.join(output_dir, f"point_{point_id}_coordinates.txt")
                    else:
                        coordinates_file = f"point_{point_id}_coordinates.txt"
                
                with open(coordinates_file, 'w', encoding='utf-8') as f:
                    f.write(f"3D点ID: {point_id}\n")
                    f.write(f"3D坐标: ({xyz[0]:.6f}, {xyz[1]:.6f}, {xyz[2]:.6f})\n")
                    f.write(f"Track长度: {len(track)}\n")
                    f.write(f"\n2D坐标列表:\n")
                    f.write(f"{'序号':<6} {'图像ID':<10} {'图像名称':<40} {'2D坐标X':<15} {'2D坐标Y':<15} {'2D索引':<10}\n")
                    f.write(f"{'-'*100}\n")
                    for idx, coord in enumerate(coordinates_summary, 1):
                        f.write(f"{idx:<6} {coord['image_id']:<10} {coord['image_name']:<40} "
                               f"{coord['x']:<15.6f} {coord['y']:<15.6f} {coord['point2d_idx']:<10}\n")
                
                print(f"\n   ✅ 2D坐标已保存到: {coordinates_file}")
        
        if valid_tracks == 0:
            print(f"      ⚠️ 警告: 该点没有有效的track信息")
    
    # 显示总结
    if save_images and output_dir:
        print(f"\n{'='*60}")
        print(f"✅ 查询完成!")
        print(f"   查询点数: {len(point_ids)}")
        print(f"   保存可视化图像: {saved_count} 张")
        print(f"   输出目录: {output_dir}")
        print(f"{'='*60}")
    
    return True


def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description='查询3D点对应的2D匹配点位置',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 查询单个3D点
  python query_3d_point.py --source_path ./data --point_id 100
  
  # 查询多个3D点
  python query_3d_point.py --source_path ./data --point_id 100,200,300
  
  # 查询并保存可视化图像
  python query_3d_point.py --source_path ./data --point_id 100 --save_images --output_dir ./query_results
        """
    )
    
    parser.add_argument(
        "--source_path", "-s",
        required=True,
        type=str,
        help="源数据路径（与convert.py中的source_path相同）"
    )
    
    parser.add_argument(
        "--point_id",
        required=True,
        type=str,
        help="要查询的3D点ID（可以是单个ID或多个ID，用逗号分隔，如：100 或 100,200,300）"
    )
    
    parser.add_argument(
        "--sfm_out_dir",
        type=str,
        default=None,
        help="SfM输出目录（默认: {source_path}/sfm_results）"
    )
    
    parser.add_argument(
        "--save_images",
        action="store_true",
        help="保存可视化图像（在图像中标记2D点位置）"
    )
    
    parser.add_argument(
        "--output_dir",
        type=str,
        default=None,
        help="可视化图像输出目录（默认: {source_path}/query_results）"
    )
    
    parser.add_argument(
        "--save_coordinates",
        action="store_true",
        help="保存2D坐标到文本文件"
    )
    
    parser.add_argument(
        "--coordinates_file",
        type=str,
        default=None,
        help="2D坐标保存文件路径（默认: {output_dir}/point_{point_id}_coordinates.txt）"
    )
    
    parser.add_argument(
        "--visualize_pairs",
        action="store_true",
        default=True,
        help="可视化匹配对图像（默认启用，显示两张图像中的对应点）"
    )
    
    parser.add_argument(
        "--no_visualize_pairs",
        action="store_true",
        help="不生成匹配对图像，只生成单图像可视化"
    )
    
    return parser.parse_args()


def main():
    """主函数"""
    args = parse_arguments()
    
    # 解析点ID
    try:
        point_ids = [int(x.strip()) for x in args.point_id.split(',')]
    except ValueError:
        print(f"❌ 错误: 无效的点ID格式: {args.point_id}")
        print("   请使用单个ID或多个ID（用逗号分隔），如：100 或 100,200,300")
        return 1
    
    # 确定输出目录
    if args.save_images:
        if args.output_dir is None:
            args.output_dir = os.path.join(args.source_path, "query_results")
        print(f"📁 可视化图像将保存到: {args.output_dir}")
    
    # 处理可视化选项
    visualize_pairs = args.visualize_pairs and not args.no_visualize_pairs
    
    # 执行查询
    success = query_3d_point(
        source_path=args.source_path,
        point_ids=point_ids,
        sfm_out_dir=args.sfm_out_dir,
        save_images=args.save_images,
        output_dir=args.output_dir,
        save_coordinates=args.save_coordinates,
        coordinates_file=args.coordinates_file,
        visualize_pairs=visualize_pairs
    )
    
    if success:
        print("\n✅ 查询完成!")
        return 0
    else:
        print("\n❌ 查询失败!")
        return 1


if __name__ == "__main__":
    exit(main())

