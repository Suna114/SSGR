#!/usr/bin/env python3
"""Convert an OBJ mesh to an ASCII PLY point cloud.

The default mode samples points on mesh surfaces with triangle-area weighting.
Use --mode vertices to export the original OBJ vertices directly.
"""

from __future__ import annotations

import argparse
import math
import random
from pathlib import Path


Vec3 = tuple[float, float, float]
Tri = tuple[int, int, int]


def _parse_face_index(token: str, vertex_count: int) -> int:
    raw = token.split("/")[0]
    if not raw:
        raise ValueError(f"empty face index in token: {token!r}")
    idx = int(raw)
    if idx < 0:
        idx = vertex_count + idx + 1
    if idx <= 0 or idx > vertex_count:
        raise ValueError(f"face index out of range: {token!r}")
    return idx - 1


def read_obj(path: Path) -> tuple[list[Vec3], list[Tri]]:
    vertices: list[Vec3] = []
    triangles: list[Tri] = []
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line_no, line in enumerate(f, start=1):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            parts = stripped.split()
            tag = parts[0].lower()
            if tag == "v":
                if len(parts) < 4:
                    raise ValueError(f"invalid vertex at {path}:{line_no}")
                vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
            elif tag == "f":
                if len(parts) < 4:
                    continue
                face = [_parse_face_index(token, len(vertices)) for token in parts[1:]]
                for i in range(1, len(face) - 1):
                    triangles.append((face[0], face[i], face[i + 1]))
    if not vertices:
        raise ValueError(f"no OBJ vertices found: {path}")
    return vertices, triangles


def _sub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _cross(a: Vec3, b: Vec3) -> Vec3:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def _norm(a: Vec3) -> float:
    return math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])


def triangle_area(vertices: list[Vec3], tri: Tri) -> float:
    a, b, c = (vertices[tri[0]], vertices[tri[1]], vertices[tri[2]])
    return 0.5 * _norm(_cross(_sub(b, a), _sub(c, a)))


def sample_triangle(vertices: list[Vec3], tri: Tri, rng: random.Random) -> Vec3:
    a, b, c = (vertices[tri[0]], vertices[tri[1]], vertices[tri[2]])
    r1 = math.sqrt(rng.random())
    r2 = rng.random()
    wa = 1.0 - r1
    wb = r1 * (1.0 - r2)
    wc = r1 * r2
    return (
        wa * a[0] + wb * b[0] + wc * c[0],
        wa * a[1] + wb * b[1] + wc * c[1],
        wa * a[2] + wb * b[2] + wc * c[2],
    )


def sample_surface(vertices: list[Vec3], triangles: list[Tri], count: int, seed: int) -> list[Vec3]:
    if not triangles:
        raise ValueError("surface sampling needs OBJ faces; use --mode vertices for vertex-only OBJ files")
    weighted: list[tuple[float, Tri]] = []
    total = 0.0
    for tri in triangles:
        area = triangle_area(vertices, tri)
        if area <= 0.0 or not math.isfinite(area):
            continue
        total += area
        weighted.append((total, tri))
    if not weighted:
        raise ValueError("all OBJ faces are degenerate; cannot sample surface")

    rng = random.Random(seed)
    points: list[Vec3] = []
    for _ in range(count):
        target = rng.random() * total
        lo, hi = 0, len(weighted) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if weighted[mid][0] < target:
                lo = mid + 1
            else:
                hi = mid
        points.append(sample_triangle(vertices, weighted[lo][1], rng))
    return points


def write_ply(path: Path, points: list[Vec3], color: tuple[int, int, int] | None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"element vertex {len(points)}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        if color is not None:
            f.write("property uchar red\n")
            f.write("property uchar green\n")
            f.write("property uchar blue\n")
        f.write("end_header\n")
        if color is None:
            for x, y, z in points:
                f.write(f"{x:.9g} {y:.9g} {z:.9g}\n")
        else:
            r, g, b = color
            for x, y, z in points:
                f.write(f"{x:.9g} {y:.9g} {z:.9g} {r} {g} {b}\n")


def _parse_color(text: str) -> tuple[int, int, int] | None:
    if str(text).strip().lower() in {"", "none", "off"}:
        return None
    parts = [int(x.strip()) for x in str(text).split(",")]
    if len(parts) != 3 or any(x < 0 or x > 255 for x in parts):
        raise argparse.ArgumentTypeError("color must be R,G,B with values in 0..255, or 'none'")
    return (parts[0], parts[1], parts[2])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_obj", type=Path, help="Input OBJ mesh path")
    parser.add_argument("output_ply", type=Path, help="Output ASCII PLY point cloud path")
    parser.add_argument("--mode", choices=["surface", "vertices"], default="surface")
    parser.add_argument("--points", type=int, default=100_000, help="Surface sample count")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--color", type=_parse_color, default=(180, 180, 180), help="R,G,B or none")
    args = parser.parse_args(argv)

    if not args.input_obj.is_file():
        raise SystemExit(f"input OBJ does not exist: {args.input_obj}")
    if args.points <= 0:
        raise SystemExit("--points must be positive")

    vertices, triangles = read_obj(args.input_obj)
    if args.mode == "vertices":
        points = vertices
    else:
        points = sample_surface(vertices, triangles, int(args.points), int(args.seed))
    write_ply(args.output_ply, points, args.color)
    print(f"[obj_to_ply] vertices: {len(vertices)}")
    print(f"[obj_to_ply] triangles: {len(triangles)}")
    print(f"[obj_to_ply] points written: {len(points)}")
    print(f"[obj_to_ply] output: {args.output_ply.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
