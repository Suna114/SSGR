#!/usr/bin/env python3
"""Build per-class training-view montage: label | optical photo | SAR input grid."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ALL_CLASSES = [
    "2S1",
    "BMP2",
    "BRDM_2",
    "BTR70",
    "D7",
    "SLICY",
    "T62",
    "T72",
    "ZIL131",
    "ZSU_23_4",
]

DEFAULT_CLASSES = [c for c in ALL_CLASSES if c != "SLICY"]

DISPLAY_NAMES = {
    "T72": "T-72",
}

OPTICAL_ALIASES = {
    "2S1": ("2S1",),
    "BMP2": ("BMP2",),
    "BRDM_2": ("BRDM2", "BRDM_2"),
    "BTR70": ("BTR70",),
    "D7": ("D7",),
    "SLICY": ("SLICY",),
    "T62": ("T62",),
    "T72": ("T72",),
    "ZIL131": ("ZIL131",),
    "ZSU_23_4": ("ZSU234", "ZSU_23_4"),
}

DEFAULT_LABEL_FONT = Path(r"C:\Windows\Fonts\timesbd.ttf")
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp")


def _load_font(size: int, font_path: Path | None = None) -> ImageFont.ImageFont:
    candidates: list[Path] = []
    if font_path is not None:
        candidates.append(font_path)
    candidates.extend(
        [
            DEFAULT_LABEL_FONT,
            Path(r"C:\Windows\Fonts\times.ttf"),
            Path(r"C:\Windows\Fonts\arialbd.ttf"),
            Path(r"C:\Windows\Fonts\arial.ttf"),
        ]
    )
    for path in candidates:
        if path.is_file():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def _parse_report_azimuths(report_path: Path) -> dict[str, float]:
    mapping: dict[str, float] = {}
    if not report_path.is_file():
        return mapping
    for line in report_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith(
            ("source_", "projection_", "camera_", "mesh_", "world_", "gs_", "train ", "views:", "view", "-")
        ):
            continue
        parts = re.split(r"\s+", line)
        if len(parts) < 2:
            continue
        try:
            mapping[parts[0]] = float(parts[1])
        except ValueError:
            continue
    return mapping


def _training_entries(class_dir: Path, verify_dir: str) -> list[tuple[float, Path]]:
    report = _parse_report_azimuths(class_dir / verify_dir / "report.txt")
    entries: list[tuple[float, Path]] = []
    seen: set[str] = set()
    input_dir = class_dir / "input"
    if not input_dir.is_dir():
        return entries

    for path in sorted(input_dir.iterdir()):
        if path.suffix.lower() not in IMAGE_EXTS:
            continue
        view_name = path.stem
        if view_name in seen:
            continue
        suffix = view_name.rsplit("-", 1)[-1]
        az = float(report.get(view_name, int(suffix) if suffix.isdigit() else 0))
        entries.append((az, path))
        seen.add(view_name)

    entries.sort(key=lambda item: item[0])
    return entries


def _pick_equal_indices(total: int, count: int) -> list[int]:
    if total <= 0:
        return []
    if count <= 1:
        return [0]
    if count >= total:
        return list(range(total))
    return [int(round(i * (total - 1) / (count - 1))) for i in range(count)]


def _select_sar_images(class_dir: Path, verify_dir: str, pick_count: int) -> list[Path]:
    entries = _training_entries(class_dir, verify_dir)
    if not entries:
        raise FileNotFoundError(f"{class_dir.name}: no images under {class_dir / 'input'}")
    indices = _pick_equal_indices(len(entries), pick_count)
    return [entries[i][1] for i in indices]


def _find_optical_image(optical_dir: Path, class_name: str) -> Path | None:
    aliases = OPTICAL_ALIASES.get(class_name, (class_name,))
    if not optical_dir.is_dir():
        return None
    files = [p for p in optical_dir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    for alias in aliases:
        token = alias.lower()
        for path in files:
            if token in path.stem.lower():
                return path
    return None


def _to_rgb(im: Image.Image, bg: tuple[int, int, int]) -> Image.Image:
    if im.mode == "RGBA":
        out = Image.new("RGB", im.size, bg)
        out.paste(im, mask=im.split()[3])
        return out
    if im.mode != "RGB":
        return im.convert("RGB")
    return im


def _fit_square(im: Image.Image, size: int, bg: tuple[int, int, int]) -> Image.Image:
    im = _to_rgb(im, bg)
    return im.resize((size, size), Image.Resampling.LANCZOS)


def _fit_height(im: Image.Image, height: int, bg: tuple[int, int, int]) -> Image.Image:
    im = _to_rgb(im, bg)
    w, h = im.size
    if h <= 0:
        return Image.new("RGB", (height, height), bg)
    width = max(1, int(round(w * (height / h))))
    return im.resize((width, height), Image.Resampling.LANCZOS)


def _draw_dashed_line(
    draw: ImageDraw.ImageDraw,
    x0: int,
    y: int,
    x1: int,
    *,
    color: tuple[int, int, int],
    dash: int = 10,
    gap: int = 8,
    width: int = 1,
) -> None:
    x = x0
    while x < x1:
        x_end = min(x + dash, x1)
        draw.line([(x, y), (x_end, y)], fill=color, width=width)
        x += dash + gap


def build_montage(
    data_root: Path,
    optical_dir: Path,
    classes: list[str],
    verify_dir: str,
    pick_count: int,
    sar_cols: int,
    cell_size: int,
    gap: int,
    row_gap: int,
    label_padding: int,
    bgcolor: str,
    label_font_size: int,
    label_font_path: Path | None,
) -> Image.Image:
    bg = (255, 255, 255) if bgcolor == "white" else (0, 0, 0)
    text_color = (0, 0, 0) if bgcolor == "white" else (255, 255, 255)
    line_color = text_color
    font = _load_font(label_font_size, label_font_path)

    sar_rows = max(1, (pick_count + sar_cols - 1) // sar_cols)
    sar_grid_w = sar_cols * cell_size + max(0, sar_cols - 1) * gap
    sar_grid_h = sar_rows * cell_size + max(0, sar_rows - 1) * gap
    row_h = sar_grid_h

    class_sar: dict[str, list[Path]] = {}
    class_optical: dict[str, Path | None] = {}
    missing_optical: list[str] = []
    for cls in classes:
        class_sar[cls] = _select_sar_images(data_root / cls, verify_dir, pick_count)
        optical = _find_optical_image(optical_dir, cls)
        class_optical[cls] = optical
        if optical is None:
            missing_optical.append(cls)

    measure = ImageDraw.Draw(Image.new("RGB", (1, 1), bg))
    labels = [DISPLAY_NAMES.get(cls, cls) for cls in classes]
    left_pad = max(measure.textbbox((0, 0), label, font=font, anchor="lt")[2] for label in labels)
    left_pad += label_padding

    optical_widths: list[int] = []
    for cls in classes:
        optical = class_optical[cls]
        if optical is None:
            optical_widths.append(row_h)
            continue
        with Image.open(optical) as im:
            optical_widths.append(_fit_height(im, row_h, bg).width)
    optical_slot_w = max(optical_widths)

    row_width = left_pad + gap + optical_slot_w + gap + sar_grid_w
    row_stride = row_h + row_gap
    out_h = len(classes) * row_h + max(0, len(classes) - 1) * row_gap
    mosaic = Image.new("RGB", (row_width, out_h), bg)
    draw = ImageDraw.Draw(mosaic)

    for row_idx, cls in enumerate(classes):
        y0 = row_idx * row_stride
        row_center_y = y0 + row_h / 2.0
        label = DISPLAY_NAMES.get(cls, cls)
        draw.text((left_pad - label_padding, row_center_y), label, fill=text_color, font=font, anchor="rm")

        x = left_pad + gap
        optical = class_optical[cls]
        if optical is not None:
            with Image.open(optical) as im:
                optical_im = _fit_height(im, row_h, bg)
            paste_x = x + (optical_slot_w - optical_im.width) // 2
            mosaic.paste(optical_im, (paste_x, y0))
        else:
            draw.rectangle([x, y0, x + optical_slot_w - 1, y0 + row_h - 1], outline=line_color, width=1)
            draw.text((x + optical_slot_w / 2, row_center_y), "N/A", fill=text_color, font=font, anchor="mm")

        sar_x = left_pad + gap + optical_slot_w + gap
        sar_paths = class_sar[cls]
        for idx, sar_path in enumerate(sar_paths):
            r, c = divmod(idx, sar_cols)
            sx = sar_x + c * (cell_size + gap)
            sy = y0 + r * (cell_size + gap)
            with Image.open(sar_path) as im:
                mosaic.paste(_fit_square(im, cell_size, bg), (sx, sy))

        if row_idx < len(classes) - 1:
            sep_y = y0 + row_h + row_gap // 2
            _draw_dashed_line(draw, 0, sep_y, row_width, color=line_color)

    if missing_optical:
        print(f"[prepare_training_views] missing optical for: {', '.join(missing_optical)}")

    return mosaic


def main() -> int:
    repo = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(
        description="Montage: class label | optical photo | equally-spaced SAR input grid."
    )
    parser.add_argument("--data-root", type=Path, default=repo / "data")
    parser.add_argument(
        "--optical-dir",
        type=Path,
        default=repo / "figure" / "optical_mstar",
        help="Folder with Fig2_MSTAR_optical_clear_* images.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=repo / "output" / "final" / "picture2" / "training_views_montage_9class_18sar_2x9_128_white_gap12.png",
    )
    parser.add_argument("--verify-dir", type=str, default="sar_imaging_verify")
    parser.add_argument("--classes", nargs="*", default=None)
    parser.add_argument(
        "--exclude-classes",
        nargs="*",
        default=["SLICY"],
        help="Classes to skip (default: SLICY).",
    )
    parser.add_argument("--pick-count", type=int, default=18, help="Number of SAR views per class.")
    parser.add_argument("--sar-cols", type=int, default=9, help="SAR grid columns (default 9 -> 2x9 for 18 views).")
    parser.add_argument("--cell-size", type=int, default=128)
    parser.add_argument("--gap", type=int, default=12, help="Gap inside SAR grid and between blocks.")
    parser.add_argument("--row-gap", type=int, default=18, help="Gap between class rows (dashed separator).")
    parser.add_argument("--label-padding", type=int, default=12)
    parser.add_argument("--bgcolor", choices=("black", "white"), default="white")
    parser.add_argument("--label-font-size", type=int, default=28)
    parser.add_argument(
        "--label-font-ratio",
        type=float,
        default=0.22,
        help="If set with --cell-size, cap label font to cell_size * ratio.",
    )
    parser.add_argument("--label-font", type=Path, default=DEFAULT_LABEL_FONT)
    args = parser.parse_args()

    if args.classes:
        classes = list(args.classes)
    else:
        classes = list(ALL_CLASSES)
    excluded = {c.strip() for c in args.exclude_classes if c.strip()}
    classes = [c for c in classes if c not in excluded]
    if not classes:
        raise SystemExit("No classes left after --exclude-classes.")

    label_font_size = args.label_font_size
    if args.label_font_ratio is not None and args.cell_size > 0:
        label_font_size = max(8, int(round(args.cell_size * args.label_font_ratio)))

    mosaic = build_montage(
        data_root=args.data_root.resolve(),
        optical_dir=args.optical_dir.resolve(),
        classes=classes,
        verify_dir=args.verify_dir,
        pick_count=max(1, args.pick_count),
        sar_cols=max(1, args.sar_cols),
        cell_size=max(1, args.cell_size),
        gap=max(0, args.gap),
        row_gap=max(0, args.row_gap),
        label_padding=max(0, args.label_padding),
        bgcolor=args.bgcolor,
        label_font_size=label_font_size,
        label_font_path=args.label_font.resolve() if args.label_font else None,
    )
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    mosaic.save(output, quality=95)
    print(f"[prepare_training_views] output: {output} ({mosaic.width}x{mosaic.height})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
