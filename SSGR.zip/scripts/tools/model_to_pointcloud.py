#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
三维模型转换为点云工具
支持多种3D模型格式（OBJ, PLY, STL, FBX, GLTF等）转换为PLY格式点云
"""

import os
import sys
import numpy as np
from pathlib import Path
from plyfile import PlyData, PlyElement
import argparse

try:
    import trimesh
    TRIMESH_AVAILABLE = True
except ImportError:
    TRIMESH_AVAILABLE = False
    print("⚠️  警告: 未安装trimesh库，部分格式可能无法支持")
    print("   安装方法: pip install trimesh")

try:
    import open3d as o3d
    OPEN3D_AVAILABLE = True
except ImportError:
    OPEN3D_AVAILABLE = False


def load_3d_model(file_path):
    """
    加载3D模型文件
    
    Args:
        file_path: 模型文件路径
        
    Returns:
        vertices: 顶点坐标 (N, 3)
        colors: 顶点颜色 (N, 3)，如果模型没有颜色则为None
        normals: 顶点法线 (N, 3)，如果模型没有法线则为None
        faces: 面片索引，如果模型没有面片则为None
    """
    file_path = Path(file_path)
    ext = file_path.suffix.lower()
    
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    print(f"📂 加载模型: {file_path}")
    print(f"   格式: {ext}")
    
    # 如果已经是PLY格式，直接读取
    if ext == '.ply':
        return load_ply(file_path)
    
    # 使用trimesh加载其他格式
    if TRIMESH_AVAILABLE:
        try:
            mesh = trimesh.load(str(file_path))
            
            # 处理多个网格的情况
            if isinstance(mesh, trimesh.Scene):
                print(f"   检测到场景，包含 {len(mesh.geometry)} 个网格")
                # 合并所有网格
                vertices_list = []
                colors_list = []
                normals_list = []
                faces_list = []
                face_offset = 0
                
                for name, geom in mesh.geometry.items():
                    if isinstance(geom, trimesh.Trimesh):
                        v = geom.vertices
                        vertices_list.append(v)
                        
                        # 获取颜色
                        if hasattr(geom.visual, 'vertex_colors') and geom.visual.vertex_colors is not None:
                            c = geom.visual.vertex_colors[:, :3]  # RGB
                            if c.max() > 1.0:
                                c = c / 255.0
                            colors_list.append(c)
                        else:
                            colors_list.append(None)
                        
                        # 获取法线
                        if geom.vertex_normals is not None:
                            normals_list.append(geom.vertex_normals)
                        else:
                            normals_list.append(None)
                        
                        # 获取面片
                        if geom.faces is not None:
                            faces_list.append(geom.faces + face_offset)
                            face_offset += len(v)
                
                # 合并所有顶点
                vertices = np.vstack(vertices_list)
                
                # 合并颜色
                if all(c is not None for c in colors_list):
                    colors = np.vstack(colors_list)
                else:
                    colors = None
                
                # 合并法线
                if all(n is not None for n in normals_list):
                    normals = np.vstack(normals_list)
                else:
                    normals = None
                
                # 合并面片
                if faces_list:
                    faces = np.vstack(faces_list)
                else:
                    faces = None
                
                print(f"   合并后: {len(vertices)} 个顶点, {len(faces) if faces is not None else 0} 个面片")
                return vertices, colors, normals, faces
            
            elif isinstance(mesh, trimesh.Trimesh):
                vertices = mesh.vertices
                
                # 获取颜色
                colors = None
                if hasattr(mesh.visual, 'vertex_colors') and mesh.visual.vertex_colors is not None:
                    colors = mesh.visual.vertex_colors[:, :3]  # RGB
                    if colors.max() > 1.0:
                        colors = colors / 255.0
                
                # 获取法线
                normals = mesh.vertex_normals if mesh.vertex_normals is not None else None
                
                # 获取面片
                faces = mesh.faces if mesh.faces is not None else None
                
                print(f"   顶点数: {len(vertices)}")
                print(f"   面片数: {len(faces) if faces is not None else 0}")
                print(f"   有颜色: {colors is not None}")
                print(f"   有法线: {normals is not None}")
                
                return vertices, colors, normals, faces
            else:
                raise ValueError(f"不支持的网格类型: {type(mesh)}")
                
        except Exception as e:
            raise ValueError(f"无法使用trimesh加载模型: {e}")
    else:
        raise ImportError("需要安装trimesh库来加载此格式: pip install trimesh")


def load_ply(file_path):
    """加载PLY文件"""
    plydata = PlyData.read(str(file_path))
    vertices = plydata['vertex']
    
    xyz = np.vstack([vertices['x'], vertices['y'], vertices['z']]).T
    
    # 获取颜色
    colors = None
    if 'red' in vertices.dtype.names and 'green' in vertices.dtype.names and 'blue' in vertices.dtype.names:
        colors = np.vstack([vertices['red'], vertices['green'], vertices['blue']]).T
        if colors.max() > 1.0:
            colors = colors / 255.0
    
    # 获取法线
    normals = None
    if 'nx' in vertices.dtype.names and 'ny' in vertices.dtype.names and 'nz' in vertices.dtype.names:
        normals = np.vstack([vertices['nx'], vertices['ny'], vertices['nz']]).T
    
    # PLY文件通常不包含面片信息在vertex元素中
    faces = None
    
    return xyz, colors, normals, faces


def sample_points_from_mesh(vertices, faces, num_points, colors=None, normals=None):
    """
    从网格面片采样生成点云
    
    Args:
        vertices: 顶点坐标 (N, 3)
        faces: 面片索引 (M, 3)
        num_points: 采样点数
        colors: 顶点颜色 (N, 3)，可选
        normals: 顶点法线 (N, 3)，可选
        
    Returns:
        sampled_points: 采样点坐标 (num_points, 3)
        sampled_colors: 采样点颜色 (num_points, 3)，如果输入有颜色
        sampled_normals: 采样点法线 (num_points, 3)，如果输入有法线
    """
    if not TRIMESH_AVAILABLE:
        raise ImportError("需要trimesh库进行面片采样")
    
    if faces is None or len(faces) == 0:
        print("⚠️  模型没有面片信息，无法进行面片采样")
        return vertices, colors, normals
    
    # 创建trimesh网格
    mesh = trimesh.Trimesh(vertices=vertices, faces=faces)
    
    # 计算每个面片的面积
    face_areas = mesh.area_faces
    
    # 按面积加权采样
    if face_areas.sum() > 0:
        # 归一化面积作为采样权重
        probabilities = face_areas / face_areas.sum()
        # 采样面片索引
        sampled_face_indices = np.random.choice(len(faces), size=num_points, p=probabilities)
    else:
        sampled_face_indices = np.random.choice(len(faces), size=num_points)
    
    # 在每个采样面片上随机采样点
    sampled_points = []
    sampled_colors = []
    sampled_normals = []
    
    for face_idx in sampled_face_indices:
        face = faces[face_idx]
        v0, v1, v2 = vertices[face]
        
        # 在三角形内均匀采样
        r1, r2 = np.random.rand(2)
        if r1 + r2 > 1:
            r1, r2 = 1 - r1, 1 - r2
        
        point = v0 + r1 * (v1 - v0) + r2 * (v2 - v0)
        sampled_points.append(point)
        
        # 插值颜色
        if colors is not None:
            c0, c1, c2 = colors[face]
            color = c0 + r1 * (c1 - c0) + r2 * (c2 - c0)
            sampled_colors.append(color)
        
        # 插值法线
        if normals is not None:
            n0, n1, n2 = normals[face]
            normal = n0 + r1 * (n1 - n0) + r2 * (n2 - n0)
            normal = normal / (np.linalg.norm(normal) + 1e-8)  # 归一化
            sampled_normals.append(normal)
    
    sampled_points = np.array(sampled_points)
    sampled_colors = np.array(sampled_colors) if colors is not None else None
    sampled_normals = np.array(sampled_normals) if normals is not None else None
    
    return sampled_points, sampled_colors, sampled_normals


def save_pointcloud_ply(file_path, points, colors=None, normals=None):
    """
    保存点云为PLY格式
    
    Args:
        file_path: 输出文件路径
        points: 点坐标 (N, 3)
        colors: 点颜色 (N, 3)，值范围0-1，可选
        normals: 点法线 (N, 3)，可选
    """
    print(f"\n💾 保存点云: {file_path}")
    print(f"   点数: {len(points)}")
    
    # 确保输出目录存在
    os.makedirs(os.path.dirname(file_path) if os.path.dirname(file_path) else '.', exist_ok=True)
    
    # 准备数据
    num_points = len(points)
    
    # 如果没有颜色，使用默认颜色（白色）
    if colors is None:
        colors = np.ones((num_points, 3), dtype=np.float32)
    
    # 确保颜色值在0-255范围内
    if colors.max() <= 1.0:
        colors_uint8 = (colors * 255).astype(np.uint8)
    else:
        colors_uint8 = colors.astype(np.uint8)
    
    # 如果没有法线，使用零向量
    if normals is None:
        normals = np.zeros((num_points, 3), dtype=np.float32)
    
    # 创建PLY数据结构
    dtype = [
        ('x', 'f4'),
        ('y', 'f4'),
        ('z', 'f4'),
        ('nx', 'f4'),
        ('ny', 'f4'),
        ('nz', 'f4'),
        ('red', 'u1'),
        ('green', 'u1'),
        ('blue', 'u1')
    ]
    
    elements = np.empty(num_points, dtype=dtype)
    elements['x'] = points[:, 0].astype(np.float32)
    elements['y'] = points[:, 1].astype(np.float32)
    elements['z'] = points[:, 2].astype(np.float32)
    elements['nx'] = normals[:, 0].astype(np.float32)
    elements['ny'] = normals[:, 1].astype(np.float32)
    elements['nz'] = normals[:, 2].astype(np.float32)
    elements['red'] = colors_uint8[:, 0]
    elements['green'] = colors_uint8[:, 1]
    elements['blue'] = colors_uint8[:, 2]
    
    # 创建并保存PLY文件
    vertex_element = PlyElement.describe(elements, 'vertex')
    ply_data = PlyData([vertex_element], text=False)
    ply_data.write(file_path)
    
    print(f"✅ 点云已保存")


def main():
    parser = argparse.ArgumentParser(
        description='将3D模型转换为点云',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  # 基本用法：提取顶点作为点云
  python model_to_pointcloud.py input.obj output.ply
  
  # 从面片采样生成密集点云（100000个点）
  python model_to_pointcloud.py input.obj output.ply --sample 100000
  
  # 使用顶点法线（如果模型有）
  python model_to_pointcloud.py input.obj output.ply --use-normals
  
支持的格式:
  OBJ, PLY, STL, FBX, GLTF/GLB, 3DS, DAE等（需要trimesh库）
        """
    )
    
    parser.add_argument('input', type=str, help='输入3D模型文件路径')
    parser.add_argument('output', type=str, help='输出PLY点云文件路径')
    parser.add_argument('--sample', type=int, default=None,
                       help='从面片采样生成点云，指定采样点数（默认：仅使用顶点）')
    parser.add_argument('--use-normals', action='store_true',
                       help='使用模型中的法线信息（如果可用）')
    parser.add_argument('--seed', type=int, default=None,
                       help='随机种子（用于可重复的采样结果）')
    
    args = parser.parse_args()
    
    # 设置随机种子
    if args.seed is not None:
        np.random.seed(args.seed)
    
    print("="*70)
    print("3D模型转点云工具")
    print("="*70)
    
    # 检查输入文件
    if not os.path.exists(args.input):
        print(f"❌ 错误: 输入文件不存在: {args.input}")
        return 1
    
    # 加载模型
    try:
        vertices, colors, normals, faces = load_3d_model(args.input)
    except Exception as e:
        print(f"❌ 加载模型失败: {e}")
        return 1
    
    # 决定使用哪些点
    if args.sample is not None and faces is not None:
        print(f"\n🔄 从面片采样生成点云...")
        print(f"   目标点数: {args.sample}")
        points, point_colors, point_normals = sample_points_from_mesh(
            vertices, faces, args.sample, colors, normals if args.use_normals else None
        )
    else:
        print(f"\n📌 使用模型顶点作为点云")
        points = vertices
        point_colors = colors
        point_normals = normals if args.use_normals else None
    
    # 保存点云
    try:
        save_pointcloud_ply(args.output, points, point_colors, point_normals)
    except Exception as e:
        print(f"❌ 保存点云失败: {e}")
        return 1
    
    # 统计信息
    print("\n" + "="*70)
    print("📊 转换统计")
    print("="*70)
    print(f"输入文件: {args.input}")
    print(f"输出文件: {args.output}")
    print(f"点云数量: {len(points)}")
    
    if point_colors is not None:
        print(f"颜色信息: ✅")
    else:
        print(f"颜色信息: ❌")
    
    if point_normals is not None:
        print(f"法线信息: ✅")
    else:
        print(f"法线信息: ❌")
    
    # 计算包围盒
    min_pt = points.min(axis=0)
    max_pt = points.max(axis=0)
    center = (min_pt + max_pt) / 2
    size = max_pt - min_pt
    
    print(f"\n包围盒:")
    print(f"  最小值: [{min_pt[0]:.3f}, {min_pt[1]:.3f}, {min_pt[2]:.3f}]")
    print(f"  最大值: [{max_pt[0]:.3f}, {max_pt[1]:.3f}, {max_pt[2]:.3f}]")
    print(f"  中心:   [{center[0]:.3f}, {center[1]:.3f}, {center[2]:.3f}]")
    print(f"  尺寸:   [{size[0]:.3f}, {size[1]:.3f}, {size[2]:.3f}]")
    
    print("\n" + "="*70)
    print("✅ 转换完成")
    print("="*70)
    
    return 0


if __name__ == '__main__':
    sys.exit(main())

