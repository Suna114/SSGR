#!/usr/bin/env python3
"""Restore scripts from a code_backups/<name> folder."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True, help="Backup folder name under code_backups/.")
    parser.add_argument("--dry_run", action="store_true")
    args = parser.parse_args()

    backup_root = REPO_ROOT / "code_backups" / args.name
    if not backup_root.is_dir():
        raise SystemExit(f"Missing backup: {backup_root}")

    restored = 0
    for src in sorted(backup_root.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(backup_root)
        if rel.name.startswith("STABLE_MARK_") or rel.name in {"BACKUP_MANIFEST.json"} or rel.name.startswith("USAGE_"):
            continue
        if rel.parts[0] not in {"scripts", "output"}:
            continue
        dst = REPO_ROOT / rel
        if args.dry_run:
            print(f"would restore {rel}")
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            print(f"restored {rel}")
        restored += 1

    print(f"{'Would restore' if args.dry_run else 'Restored'} {restored} files from {backup_root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
