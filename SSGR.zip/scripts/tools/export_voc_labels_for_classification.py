#!/usr/bin/env python3
"""Export Pascal VOC XML labels for generated novel-view classification images.

This standalone helper converts the refiner classification export:

  picture/<source>/<class_name>/*.png
  label/<source>/<class_name>/*.png

into VOC-style XML labels like:

  class_label/<source>/<class_name>/*.xml

The object bbox is computed from the nonzero pixels of the corresponding mask.
The script intentionally avoids Pillow/OpenCV so it can run in lightweight
pipeline environments that only have the Python standard library.
"""

from __future__ import annotations

import argparse
import json
import struct
import sys
import zlib
from dataclasses import dataclass
from pathlib import Path
from xml.dom import minidom
from xml.etree import ElementTree as ET


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
Image = None


def require_pillow():
    global Image
    if Image is None:
        from PIL import Image as _Image

        Image = _Image
    return Image


@dataclass(frozen=True)
class ImageInfo:
    width: int
    height: int
    depth: int = 3


@dataclass(frozen=True)
class BBox:
    xmin: int
    ymin: int
    xmax: int
    ymax: int


def image_files(path: Path) -> list[Path]:
    if not path.is_dir():
        raise FileNotFoundError(f"Directory not found: {path}")
    return sorted(
        (p for p in path.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS),
        key=lambda p: p.name.lower(),
    )


def read_png_chunks(path: Path):
    with path.open("rb") as f:
        signature = f.read(8)
        if signature != PNG_SIGNATURE:
            raise ValueError(f"Not a PNG file: {path}")
        while True:
            length_bytes = f.read(4)
            if len(length_bytes) == 0:
                break
            if len(length_bytes) != 4:
                raise ValueError(f"Truncated PNG chunk length: {path}")
            length = struct.unpack(">I", length_bytes)[0]
            chunk_type = f.read(4)
            data = f.read(length)
            crc = f.read(4)
            if len(chunk_type) != 4 or len(data) != length or len(crc) != 4:
                raise ValueError(f"Truncated PNG chunk data: {path}")
            yield chunk_type, data
            if chunk_type == b"IEND":
                break


def read_png_header(path: Path) -> tuple[int, int, int, int, int, int]:
    for chunk_type, data in read_png_chunks(path):
        if chunk_type == b"IHDR":
            width, height, bit_depth, color_type, compression, filter_method, interlace = struct.unpack(
                ">IIBBBBB", data
            )
            if compression != 0 or filter_method != 0:
                raise ValueError(f"Unsupported PNG compression/filter method: {path}")
            return width, height, bit_depth, color_type, interlace, compression
    raise ValueError(f"PNG has no IHDR chunk: {path}")


def png_depth_from_color_type(color_type: int) -> int:
    if color_type == 0:
        return 1
    if color_type == 2:
        return 3
    if color_type == 3:
        return 3
    if color_type == 4:
        return 2
    if color_type == 6:
        return 4
    return 3


def read_image_info(path: Path) -> ImageInfo:
    suffix = path.suffix.lower()
    if suffix == ".png":
        width, height, _bit_depth, color_type, _interlace, _compression = read_png_header(path)
        return ImageInfo(width=width, height=height, depth=png_depth_from_color_type(color_type))
    Image = require_pillow()
    with Image.open(path) as im:
        return ImageInfo(width=int(im.width), height=int(im.height), depth=len(im.getbands()))


def paeth_predictor(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def unfilter_png_scanlines(raw: bytes, width: int, height: int, row_bytes: int, bpp: int) -> list[bytes]:
    rows: list[bytes] = []
    pos = 0
    prev = bytearray(row_bytes)
    for _ in range(height):
        if pos >= len(raw):
            raise ValueError("Truncated PNG image data")
        filter_type = raw[pos]
        pos += 1
        row = bytearray(raw[pos : pos + row_bytes])
        pos += row_bytes
        if len(row) != row_bytes:
            raise ValueError("Truncated PNG scanline")

        if filter_type == 0:
            pass
        elif filter_type == 1:
            for i in range(row_bytes):
                left = row[i - bpp] if i >= bpp else 0
                row[i] = (row[i] + left) & 0xFF
        elif filter_type == 2:
            for i in range(row_bytes):
                row[i] = (row[i] + prev[i]) & 0xFF
        elif filter_type == 3:
            for i in range(row_bytes):
                left = row[i - bpp] if i >= bpp else 0
                up = prev[i]
                row[i] = (row[i] + ((left + up) // 2)) & 0xFF
        elif filter_type == 4:
            for i in range(row_bytes):
                left = row[i - bpp] if i >= bpp else 0
                up = prev[i]
                up_left = prev[i - bpp] if i >= bpp else 0
                row[i] = (row[i] + paeth_predictor(left, up, up_left)) & 0xFF
        else:
            raise ValueError(f"Unsupported PNG filter type: {filter_type}")

        rows.append(bytes(row))
        prev = row
    return rows


def png_channels(color_type: int) -> int:
    if color_type == 0:
        return 1
    if color_type == 2:
        return 3
    if color_type == 3:
        return 1
    if color_type == 4:
        return 2
    if color_type == 6:
        return 4
    raise ValueError(f"Unsupported PNG color type: {color_type}")


def collect_png_idat(path: Path) -> tuple[int, int, int, int, bytes]:
    width = height = bit_depth = color_type = interlace = None
    idat_parts: list[bytes] = []
    for chunk_type, data in read_png_chunks(path):
        if chunk_type == b"IHDR":
            width, height, bit_depth, color_type, _compression, _filter_method, interlace = struct.unpack(
                ">IIBBBBB", data
            )
        elif chunk_type == b"IDAT":
            idat_parts.append(data)
    if width is None or height is None or bit_depth is None or color_type is None or interlace is None:
        raise ValueError(f"PNG has no IHDR chunk: {path}")
    if interlace != 0:
        raise ValueError(f"Interlaced PNG masks are not supported: {path}")
    return int(width), int(height), int(bit_depth), int(color_type), b"".join(idat_parts)


def positive_pixel_from_samples(samples: bytes, color_type: int, bit_depth: int) -> bool:
    if bit_depth == 8:
        if color_type == 6:
            return samples[3] > 0 and any(v > 0 for v in samples[:3])
        if color_type == 4:
            return samples[1] > 0 and samples[0] > 0
        return any(v > 0 for v in samples)
    if bit_depth == 16:
        values = [struct.unpack(">H", samples[i : i + 2])[0] for i in range(0, len(samples), 2)]
        if color_type == 6:
            return values[3] > 0 and any(v > 0 for v in values[:3])
        if color_type == 4:
            return values[1] > 0 and values[0] > 0
        return any(v > 0 for v in values)
    raise ValueError(f"Unsupported PNG bit depth for mask bbox: {bit_depth}")


def bbox_from_png_mask(path: Path, margin: int = 0) -> tuple[BBox | None, ImageInfo]:
    width, height, bit_depth, color_type, idat = collect_png_idat(path)
    channels = png_channels(color_type)
    if bit_depth not in {8, 16}:
        raise ValueError(f"Unsupported PNG mask bit depth {bit_depth}: {path}")
    bytes_per_sample = bit_depth // 8
    bytes_per_pixel = channels * bytes_per_sample
    row_bytes = width * bytes_per_pixel
    rows = unfilter_png_scanlines(zlib.decompress(idat), width, height, row_bytes, max(bytes_per_pixel, 1))

    xs: list[int] = []
    ys: list[int] = []
    for y, row in enumerate(rows):
        for x in range(width):
            start = x * bytes_per_pixel
            samples = row[start : start + bytes_per_pixel]
            if positive_pixel_from_samples(samples, color_type, bit_depth):
                xs.append(x)
                ys.append(y)

    info = ImageInfo(width=width, height=height, depth=png_depth_from_color_type(color_type))
    if not xs:
        return None, info

    margin = max(int(margin), 0)
    return (
        BBox(
            xmin=max(0, min(xs) - margin),
            ymin=max(0, min(ys) - margin),
            xmax=min(width - 1, max(xs) + margin),
            ymax=min(height - 1, max(ys) + margin),
        ),
        info,
    )


def bbox_from_pillow_mask(path: Path, margin: int = 0) -> tuple[BBox | None, ImageInfo]:
    Image = require_pillow()
    with Image.open(path) as im:
        rgb = im.convert("RGB")
        width, height = rgb.size
        pixels = rgb.load()
        xmin, ymin = width, height
        xmax, ymax = -1, -1
        for y in range(height):
            for x in range(width):
                r, g, b = pixels[x, y]
                if r > 0 or g > 0 or b > 0:
                    xmin = min(xmin, x)
                    ymin = min(ymin, y)
                    xmax = max(xmax, x)
                    ymax = max(ymax, y)
    info = ImageInfo(width=width, height=height, depth=3)
    if xmax < 0:
        return None, info
    margin = max(int(margin), 0)
    return (
        BBox(
            xmin=max(0, xmin - margin),
            ymin=max(0, ymin - margin),
            xmax=min(width - 1, xmax + margin),
            ymax=min(height - 1, ymax + margin),
        ),
        info,
    )


def bbox_from_mask(path: Path, margin: int = 0) -> tuple[BBox | None, ImageInfo]:
    if path.suffix.lower() == ".png":
        return bbox_from_png_mask(path, margin=margin)
    return bbox_from_pillow_mask(path, margin=margin)


def add_text(parent: ET.Element, tag: str, text: str | int) -> ET.Element:
    elem = ET.SubElement(parent, tag)
    elem.text = str(text)
    return elem


def build_voc_xml(
    *,
    image_path: Path,
    image_info: ImageInfo,
    class_name: str,
    bbox: BBox,
    folder: str,
) -> ET.Element:
    root = ET.Element("annotation")
    add_text(root, "folder", folder)
    add_text(root, "filename", image_path.name)
    add_text(root, "path", str(image_path.resolve()))

    source = ET.SubElement(root, "source")
    add_text(source, "database", "Unknown")

    size = ET.SubElement(root, "size")
    add_text(size, "width", image_info.width)
    add_text(size, "height", image_info.height)
    add_text(size, "depth", image_info.depth)
    add_text(root, "segmented", 0)

    obj = ET.SubElement(root, "object")
    add_text(obj, "name", class_name)
    add_text(obj, "pose", "Unspecified")
    add_text(obj, "truncated", 0)
    add_text(obj, "difficult", 0)
    box = ET.SubElement(obj, "bndbox")
    add_text(box, "xmin", bbox.xmin)
    add_text(box, "ymin", bbox.ymin)
    add_text(box, "xmax", bbox.xmax)
    add_text(box, "ymax", bbox.ymax)
    return root


def write_pretty_xml(root: ET.Element, path: Path) -> None:
    rough = ET.tostring(root, encoding="utf-8")
    pretty = minidom.parseString(rough).toprettyxml(indent="\t", encoding="utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(pretty)


def resolve_default_dirs(args: argparse.Namespace) -> tuple[Path, Path, Path, str | None]:
    run_dir = args.run_dir.resolve()
    class_name = args.class_name
    image_dir = args.image_dir.resolve() if args.image_dir else None
    mask_dir = args.mask_dir.resolve() if args.mask_dir else None
    output_dir = args.output_dir.resolve() if args.output_dir else None
    if class_name is not None:
        image_dir = image_dir or run_dir / "picture" / args.source / class_name
        mask_dir = mask_dir or run_dir / "label" / args.source / class_name
        output_dir = output_dir or run_dir / "class_label" / args.source / class_name
    else:
        image_dir = image_dir or run_dir / "picture" / args.source
        mask_dir = mask_dir or run_dir / "label" / args.source
        output_dir = output_dir or run_dir / "class_label" / args.source
    return image_dir, mask_dir, output_dir, class_name


def has_images(path: Path) -> bool:
    if not path.is_dir():
        return False
    return any(p.is_file() and p.suffix.lower() in IMAGE_EXTS for p in path.iterdir())


def class_jobs(image_dir: Path, mask_dir: Path, output_dir: Path, class_name: str | None) -> list[tuple[Path, Path, Path, str]]:
    if class_name is not None:
        return [(image_dir, mask_dir, output_dir, class_name)]
    class_dirs = []
    if image_dir.is_dir():
        class_dirs = sorted((p for p in image_dir.iterdir() if p.is_dir()), key=lambda p: p.name.lower())
    if has_images(image_dir) and not class_dirs:
        inferred = image_dir.name
        return [(image_dir, mask_dir, output_dir, inferred)]

    jobs: list[tuple[Path, Path, Path, str]] = []
    if not image_dir.is_dir():
        raise FileNotFoundError(f"Directory not found: {image_dir}")
    for class_image_dir in class_dirs:
        inferred = class_image_dir.name
        class_mask_dir = mask_dir / inferred if (mask_dir / inferred).is_dir() else mask_dir
        class_output_dir = output_dir / inferred
        jobs.append((class_image_dir, class_mask_dir, class_output_dir, inferred))
    if not jobs:
        raise FileNotFoundError(f"No class image directories found under: {image_dir}")
    return jobs


def remove_legacy_txt_labels(output_dir: Path) -> int:
    if not output_dir.exists():
        return 0
    removed = 0
    for path in output_dir.rglob("*.txt"):
        if path.is_file():
            path.unlink()
            removed += 1
    return removed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--run_dir", type=Path, required=True, help="Refiner output directory, e.g. output/agent/2S1/refiner.")
    parser.add_argument("--class_name", default=None, help="Target class name written to <object><name>.")
    parser.add_argument("--source", default="extra", help="Classification split/source directory name.")
    parser.add_argument("--image_dir", type=Path, default=None, help="Class image directory. Defaults to <run_dir>/picture/<source>/<class_name>.")
    parser.add_argument("--mask_dir", type=Path, default=None, help="Class mask directory. Defaults to <run_dir>/label/<source>/<class_name>.")
    parser.add_argument("--output_dir", type=Path, default=None, help="VOC XML output directory. Defaults to <run_dir>/class_label/<source>/<class_name>.")
    parser.add_argument("--folder", default=None, help="VOC <folder> value. Defaults to the image directory name.")
    parser.add_argument("--bbox_margin", type=int, default=0, help="Pixels to expand bbox on each side.")
    parser.add_argument(
        "--empty_mask",
        choices=("skip", "full", "error"),
        default="skip",
        help="What to do if the matching mask has no positive pixels.",
    )
    parser.add_argument("--manifest_name", default="voc_export_manifest.json")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    image_dir, mask_dir, output_dir, class_name = resolve_default_dirs(args)
    jobs = class_jobs(image_dir, mask_dir, output_dir, class_name)
    removed_legacy_txt = remove_legacy_txt_labels(output_dir)

    exported: list[dict[str, str | int]] = []
    skipped: list[dict[str, str]] = []

    for class_image_dir, class_mask_dir, class_output_dir, job_class_name in jobs:
        folder = args.folder if args.folder is not None else class_image_dir.name
        masks_by_stem = {p.stem: p for p in image_files(class_mask_dir)}

        for image_path in image_files(class_image_dir):
            mask_path = masks_by_stem.get(image_path.stem)
            if mask_path is None:
                skipped.append({"image": image_path.name, "class_name": job_class_name, "reason": "missing matching mask"})
                continue

            try:
                bbox, mask_info = bbox_from_mask(mask_path, margin=args.bbox_margin)
                image_info = read_image_info(image_path)
            except Exception as exc:
                skipped.append({"image": image_path.name, "class_name": job_class_name, "reason": str(exc)})
                continue

            if bbox is None:
                if args.empty_mask == "error":
                    raise RuntimeError(f"Mask has no positive pixels: {mask_path}")
                if args.empty_mask == "skip":
                    skipped.append({"image": image_path.name, "class_name": job_class_name, "reason": "empty mask"})
                    continue
                bbox = BBox(0, 0, image_info.width - 1, image_info.height - 1)

            if image_info.width != mask_info.width or image_info.height != mask_info.height:
                skipped.append({
                    "image": image_path.name,
                    "class_name": job_class_name,
                    "reason": f"image/mask size mismatch: image={image_info.width}x{image_info.height}, mask={mask_info.width}x{mask_info.height}",
                })
                continue

            xml_root = build_voc_xml(
                image_path=image_path,
                image_info=image_info,
                class_name=job_class_name,
                bbox=bbox,
                folder=folder,
            )
            xml_path = class_output_dir / f"{image_path.stem}.xml"
            write_pretty_xml(xml_root, xml_path)
            exported.append({
                "image": str(image_path),
                "mask": str(mask_path),
                "xml": str(xml_path),
                "class_name": job_class_name,
                "xmin": bbox.xmin,
                "ymin": bbox.ymin,
                "xmax": bbox.xmax,
                "ymax": bbox.ymax,
            })

    manifest = {
        "count": len(exported),
        "skipped": skipped,
        "class_name": class_name,
        "classes": sorted({str(row["class_name"]) for row in exported}),
        "source": args.source,
        "image_dir": str(image_dir),
        "mask_dir": str(mask_dir),
        "output_dir": str(output_dir),
        "removed_legacy_txt": removed_legacy_txt,
        "exported": exported,
    }
    manifest_path = output_dir.parent.parent / args.manifest_name
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"exported {len(exported)} VOC XML labels to {output_dir}")
    if skipped:
        print(f"skipped {len(skipped)} samples; see {manifest_path}", file=sys.stderr)
    return 0 if exported else 1


if __name__ == "__main__":
    raise SystemExit(main())
