#!/usr/bin/env python3
"""Export target masks and class labels for downstream ATR/classification tests.

The script builds binary target masks from target-only renders, matches each view
to a training/eval GT image by azimuth, and writes classification-friendly labels.
GT filenames are expected to look like CLASS-elevation-azimuth, for example
T72-15-331.png.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
from collections import deque
from pathlib import Path


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
DEFAULT_MODEL_PATH = Path(r"F:\3dgs\SSGR\output\360-3-target-black-5000")
DEFAULT_GT_DIR = Path(r"F:\3dgs\SSGR\data\360-3\input")
DEFAULT_CLASSIFICATION_ROOT = Path(r"F:\3dgs\PyTorch-Image-Models-Multi-Label-Classification-main")
np = None
Image = None


def require_numpy():
    global np
    if np is None:
        import numpy as _np

        np = _np
    return np


def require_pillow():
    global Image
    if Image is None:
        from PIL import Image as _Image

        Image = _Image
    return Image


def image_files(path: Path) -> list[Path]:
    if not path.is_dir():
        raise FileNotFoundError(f"Directory not found: {path}")
    return sorted((p for p in path.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS), key=lambda p: p.name.lower())


def find_latest_run_dir(model_path: Path) -> Path:
    output_root = model_path / "output"
    if not output_root.is_dir():
        raise FileNotFoundError(f"Default run root not found: {output_root}")
    dirs = [p for p in output_root.iterdir() if p.is_dir()]
    timestamp_dirs = [p for p in dirs if re.fullmatch(r"\d{8}_\d{6}", p.name)]
    candidates = timestamp_dirs or dirs
    if not candidates:
        raise FileNotFoundError(f"No run directories found under: {output_root}")
    return sorted(candidates, key=lambda p: (p.name, p.stat().st_mtime))[-1]


def extract_render_azimuth(stem: str) -> int | None:
    match = re.search(r"(?i)azimuth[_-](\d+)", stem)
    if match:
        return int(match.group(1)) % 360
    return extract_gt_azimuth(stem)


def extract_gt_azimuth(stem: str) -> int | None:
    for part in reversed(stem.split("-")):
        match = re.match(r"^(\d+)", part.strip())
        if match:
            return int(match.group(1)) % 360
    return None


def extract_class_name(stem: str) -> str:
    return stem.split("-", 1)[0].strip()


def angular_distance(a: int, b: int) -> int:
    delta = abs((int(a) % 360) - (int(b) % 360))
    return min(delta, 360 - delta)


def build_gt_index(gt_dir: Path) -> tuple[dict[int, Path], dict[int, list[str]]]:
    buckets: dict[int, list[Path]] = {}
    for path in image_files(gt_dir):
        azimuth = extract_gt_azimuth(path.stem)
        if azimuth is None:
            continue
        buckets.setdefault(azimuth, []).append(path)

    index: dict[int, Path] = {}
    ambiguous: dict[int, list[str]] = {}
    for azimuth, paths in buckets.items():
        chosen = sorted(paths, key=lambda p: p.name.lower())
        index[azimuth] = chosen[0]
        if len(chosen) > 1:
            ambiguous[azimuth] = [p.name for p in chosen]
    return index, ambiguous


def unique_gt_class(gt_dir: Path) -> tuple[str | None, Path | None, list[str]]:
    paths = image_files(gt_dir)
    classes = sorted({extract_class_name(p.stem) for p in paths if extract_class_name(p.stem)})
    if len(classes) == 1:
        return classes[0], paths[0] if paths else None, classes
    return None, None, classes


def find_gt(gt_index: dict[int, Path], azimuth: int | None, tolerance: int) -> tuple[Path | None, int | None]:
    if azimuth is None or not gt_index:
        return None, None
    if azimuth in gt_index:
        return gt_index[azimuth], azimuth
    if tolerance <= 0:
        return None, None
    best_az = min(gt_index.keys(), key=lambda candidate: angular_distance(azimuth, candidate))
    if angular_distance(azimuth, best_az) <= tolerance:
        return gt_index[best_az], best_az
    return None, None


def load_gray01(path: Path) -> np.ndarray:
    np = require_numpy()
    Image = require_pillow()
    arr = np.asarray(Image.open(path).convert("RGB"), dtype=np.float32) / 255.0
    return arr.mean(axis=2)


def largest_connected_component(mask: np.ndarray) -> np.ndarray:
    np = require_numpy()
    mask = np.asarray(mask, dtype=bool)
    if not mask.any():
        return np.zeros(mask.shape, dtype=np.uint8)

    height, width = mask.shape
    visited = np.zeros(mask.shape, dtype=bool)
    best: list[tuple[int, int]] = []
    neighbors = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    ys, xs = np.nonzero(mask)
    for start_y, start_x in zip(ys.tolist(), xs.tolist()):
        if visited[start_y, start_x]:
            continue
        component: list[tuple[int, int]] = []
        queue: deque[tuple[int, int]] = deque([(start_y, start_x)])
        visited[start_y, start_x] = True
        while queue:
            y, x = queue.popleft()
            component.append((y, x))
            for dy, dx in neighbors:
                ny, nx = y + dy, x + dx
                if ny < 0 or ny >= height or nx < 0 or nx >= width:
                    continue
                if visited[ny, nx] or not mask[ny, nx]:
                    continue
                visited[ny, nx] = True
                queue.append((ny, nx))
        if len(component) > len(best):
            best = component

    out = np.zeros(mask.shape, dtype=np.uint8)
    if best:
        yy, xx = zip(*best)
        out[np.asarray(yy), np.asarray(xx)] = 1
    return out


def dilate_mask(mask: np.ndarray, radius: int) -> np.ndarray:
    np = require_numpy()
    radius = max(int(radius), 0)
    if radius <= 0:
        return mask.astype(np.uint8)
    padded = np.pad(mask.astype(bool), radius, mode="constant", constant_values=False)
    out = np.zeros(mask.shape, dtype=bool)
    size = radius * 2 + 1
    for dy in range(size):
        for dx in range(size):
            out |= padded[dy : dy + mask.shape[0], dx : dx + mask.shape[1]]
    return out.astype(np.uint8)


def erode_mask(mask: np.ndarray, radius: int) -> np.ndarray:
    np = require_numpy()
    radius = max(int(radius), 0)
    if radius <= 0:
        return mask.astype(np.uint8)
    return (1 - dilate_mask(1 - mask.astype(np.uint8), radius)).astype(np.uint8)


def make_target_mask(gray: np.ndarray, args: argparse.Namespace) -> np.ndarray:
    np = require_numpy()
    positive = gray[gray > 1e-6]
    min_pixels = max(float(args.min_pixels), 1.0)
    if positive.size >= int(min_pixels):
        percentile = min(max(float(args.percentile), 0.0), 100.0)
        threshold = max(float(np.quantile(positive, percentile / 100.0)), 1e-6)
        mask = ((gray >= threshold) & (gray > 1e-6)).astype(np.uint8)
        if args.largest_cc:
            mask = largest_connected_component(mask)
        if mask.sum() > 0:
            mask = erode_mask(mask, int(args.erode))
            mask = dilate_mask(mask, int(args.dilate))
            return mask.astype(np.uint8)

    threshold = max(float(args.threshold), 0.0)
    quantile = min(max(float(args.quantile), 0.0), 1.0)
    cutoff = threshold
    if positive.size > 0:
        cutoff = max(cutoff, float(np.quantile(positive, quantile)))
    mask = (gray >= cutoff).astype(np.uint8)
    if mask.sum() < min_pixels and positive.size > 0:
        mask = (gray >= float(np.quantile(positive, 0.15))).astype(np.uint8)
    if args.largest_cc:
        mask = largest_connected_component(mask)
    mask = erode_mask(mask, int(args.erode))
    mask = dilate_mask(mask, int(args.dilate))
    return mask.astype(np.uint8)


def save_masked_image(src: Path, mask: np.ndarray, dst: Path) -> None:
    np = require_numpy()
    Image = require_pillow()
    arr = np.asarray(Image.open(src).convert("RGB"), dtype=np.uint8)
    masked = arr * mask[:, :, None].astype(np.uint8)
    dst.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(masked).save(dst)


def rel_or_abs(path: Path, root: Path | None) -> str:
    if root is None:
        return str(path.resolve())
    try:
        return "./" + path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--model_path", type=Path, default=DEFAULT_MODEL_PATH)
    parser.add_argument(
        "--run_dir",
        type=Path,
        default=None,
        help="Pipeline timestamp/work directory. Defaults to the latest timestamp directory under <model_path>/output.",
    )
    parser.add_argument("--target_dir", type=Path, default=None, help="Target-only renders used to build masks. Defaults to <model_path>/novel_target_only/target_renders.")
    parser.add_argument("--image_dir", type=Path, default=None, help="Images to export for classification. Defaults to <run_dir>/03.apply_postprocess/apply/renders.")
    parser.add_argument("--gt_dir", type=Path, default=DEFAULT_GT_DIR, help="GT directory with CLASS-elevation-azimuth filenames.")
    parser.add_argument("--output_dir", type=Path, default=None, help="Output root. Defaults to run_dir, so masks go under <run_dir>/label.")
    parser.add_argument("--classification_root", type=Path, default=DEFAULT_CLASSIFICATION_ROOT, help="Root used for relative CSV paths, e.g. the timm classification repo.")
    parser.add_argument("--source", default="extra")
    parser.add_argument(
        "--mask_root_name",
        default="label",
        help="Directory name under output_dir for exported mask PNGs. Use mask_label when VOC XML owns label/.",
    )
    parser.add_argument("--azimuth_match_tolerance", type=int, default=0)
    parser.add_argument(
        "--fallback_class_from_gt",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="If no GT view matches an azimuth, use the single unique class found in gt_dir.",
    )
    parser.add_argument("--percentile", type=float, default=95.0)
    parser.add_argument("--threshold", type=float, default=0.08)
    parser.add_argument("--quantile", type=float, default=0.35)
    parser.add_argument("--min_pixels", type=float, default=16.0)
    parser.add_argument("--dilate", type=int, default=0)
    parser.add_argument("--erode", type=int, default=0)
    parser.add_argument("--largest_cc", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--copy_original_images", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument(
        "--write_class_txt",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Write legacy class_label/<source>/<class>/*.txt files. Disable when VOC XML labels are exported separately.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    np = require_numpy()
    Image = require_pillow()
    model_path = args.model_path.resolve()
    run_dir = args.run_dir.resolve() if args.run_dir else find_latest_run_dir(model_path).resolve()
    target_dir = (args.target_dir or (model_path / "novel_target_only" / "target_renders")).resolve()
    image_dir = (args.image_dir or (run_dir / "03.apply_postprocess" / "apply" / "renders")).resolve()
    gt_dir = args.gt_dir.resolve()
    output_dir = (args.output_dir or run_dir).resolve()
    csv_root = args.classification_root.resolve() if args.classification_root else None

    gt_index, ambiguous = build_gt_index(gt_dir)
    fallback_class, fallback_gt_path, gt_classes = unique_gt_class(gt_dir)
    target_by_az = {extract_render_azimuth(p.stem): p for p in image_files(target_dir)}
    image_paths = image_files(image_dir)

    rows_full: list[dict[str, str]] = []
    rows_class: list[dict[str, str]] = []
    skipped: list[dict[str, str]] = []

    for image_path in image_paths:
        azimuth = extract_render_azimuth(image_path.stem)
        target_path = target_by_az.get(azimuth)
        gt_path, matched_az = find_gt(gt_index, azimuth, int(args.azimuth_match_tolerance))
        if target_path is None or gt_path is None:
            if (
                target_path is not None
                and gt_path is None
                and bool(args.fallback_class_from_gt)
                and fallback_class is not None
                and fallback_gt_path is not None
            ):
                gt_path = fallback_gt_path
                matched_az = None
            else:
                reason = "missing target render" if target_path is None else "missing GT azimuth match"
                if gt_path is None and bool(args.fallback_class_from_gt) and fallback_class is None:
                    reason += "; gt_dir does not contain exactly one class"
                skipped.append({
                    "image": image_path.name,
                    "reason": reason,
                })
                continue

        if target_path is None or gt_path is None:
            skipped.append({
                "image": image_path.name,
                "reason": "missing target render" if target_path is None else "missing GT azimuth match",
            })
            continue

        class_name = extract_class_name(gt_path.stem)
        out_stem = image_path.stem
        mask_path = output_dir / str(args.mask_root_name) / args.source / class_name / f"{out_stem}.png"
        class_txt_path = output_dir / "class_label" / args.source / class_name / f"{out_stem}.txt"
        class_label_path = class_txt_path if bool(args.write_class_txt) else class_txt_path.with_suffix(".xml")
        export_img_path = output_dir / "picture" / args.source / class_name / f"{out_stem}{image_path.suffix.lower()}"

        mask = make_target_mask(load_gray01(target_path), args)
        mask_path.parent.mkdir(parents=True, exist_ok=True)
        Image.fromarray((mask * 255).astype(np.uint8), mode="L").save(mask_path)

        if bool(args.write_class_txt):
            class_txt_path.parent.mkdir(parents=True, exist_ok=True)
            class_txt_path.write_text(class_name + "\n", encoding="utf-8")

        if args.copy_original_images:
            export_img_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(image_path, export_img_path)
        else:
            save_masked_image(image_path, mask, export_img_path)

        row_class = {
            "image_path": rel_or_abs(export_img_path, csv_root),
            "target_class": class_name,
            "source": args.source,
        }
        rows_class.append(row_class)
        rows_full.append({
            **row_class,
            "mask_path": rel_or_abs(mask_path, csv_root),
            "class_label_path": rel_or_abs(class_label_path, csv_root),
            "source_image_path": rel_or_abs(image_path, csv_root),
            "target_render_path": rel_or_abs(target_path, csv_root),
            "gt_path": rel_or_abs(gt_path, csv_root),
            "azimuth": "" if azimuth is None else str(azimuth),
            "matched_gt_azimuth": "" if matched_az is None else str(matched_az),
        })

    label_dir = output_dir / "mstar-exp"
    write_csv(label_dir / "generated_target_masks_class_only.csv", ["image_path", "target_class", "source"], rows_class)
    write_csv(
        label_dir / "generated_target_masks_full.csv",
        [
            "image_path",
            "target_class",
            "source",
            "mask_path",
            "class_label_path",
            "source_image_path",
            "target_render_path",
            "gt_path",
            "azimuth",
            "matched_gt_azimuth",
        ],
        rows_full,
    )
    (label_dir / "class_names.txt").write_text("\n".join(sorted({r["target_class"] for r in rows_class})) + "\n", encoding="utf-8")
    manifest = {
        "count": len(rows_class),
        "skipped": skipped,
        "ambiguous_gt_azimuths": ambiguous,
        "gt_classes": gt_classes,
        "fallback_class_from_gt": bool(args.fallback_class_from_gt),
        "target_dir": str(target_dir),
        "image_dir": str(image_dir),
        "gt_dir": str(gt_dir),
        "model_path": str(model_path),
        "run_dir": str(run_dir),
        "output_dir": str(output_dir),
    }
    (label_dir / "export_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"exported {len(rows_class)} samples to {output_dir}")
    if skipped:
        print(f"skipped {len(skipped)} samples; see {label_dir / 'export_manifest.json'}")


if __name__ == "__main__":
    main()
