# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
验证图像对齐效果工具

功能：
1. 对渲染图像进行亮度/对比度对齐
2. 重新计算对齐后的指标
3. 验证是否是预处理问题导致的指标差

使用方法：
    python 验证对齐效果.py --render_path render.png --gt_path gt.png
"""

import argparse
import numpy as np
import torch
import torchvision.transforms.functional as tf
from PIL import Image
import cv2
from pathlib import Path
from utils.image_utils import psnr
from utils.loss_utils import ssim

try:
    from lpipsPyTorch import lpips as lpips_fn
    LPIPS_AVAILABLE = True
except ImportError:
    LPIPS_AVAILABLE = False
    print("⚠️ LPIPS未安装，将跳过LPIPS计算")


def load_image(image_path):
    """加载图像"""
    image = Image.open(image_path)
    if image.mode == 'L':
        image = image.convert('RGB')
    elif image.mode != 'RGB':
        image = image.convert('RGB')
    
    # 转换为numpy数组
    img_array = np.array(image, dtype=np.float32) / 255.0
    return img_array


def align_brightness_contrast(render_img, gt_img, method='mean_std'):
    """
    对齐图像的亮度和对比度
    
    Args:
        render_img: 渲染图像 (H, W, C) [0, 1]
        gt_img: 原始图像 (H, W, C) [0, 1]
        method: 对齐方法 ('mean_std', 'min_max', 'histogram')
    
    Returns:
        aligned_render: 对齐后的渲染图像
    """
    if method == 'mean_std':
        # 均值-标准差对齐
        aligned_channels = []
        for c in range(render_img.shape[2]):
            render_ch = render_img[:, :, c]
            gt_ch = gt_img[:, :, c]
            
            render_mean = render_ch.mean()
            render_std = render_ch.std()
            gt_mean = gt_ch.mean()
            gt_std = gt_ch.std()
            
            # 对齐：保持结构，调整亮度和对比度
            aligned_ch = (render_ch - render_mean) / (render_std + 1e-8) * gt_std + gt_mean
            aligned_ch = np.clip(aligned_ch, 0, 1)
            aligned_channels.append(aligned_ch)
        
        aligned_render = np.stack(aligned_channels, axis=2)
        return aligned_render
    
    elif method == 'min_max':
        # 最小-最大值对齐
        aligned_channels = []
        for c in range(render_img.shape[2]):
            render_ch = render_img[:, :, c]
            gt_ch = gt_img[:, :, c]
            
            render_min = render_ch.min()
            render_max = render_ch.max()
            gt_min = gt_ch.min()
            gt_max = gt_ch.max()
            
            if render_max > render_min:
                aligned_ch = (render_ch - render_min) / (render_max - render_min) * (gt_max - gt_min) + gt_min
            else:
                aligned_ch = render_ch
            aligned_ch = np.clip(aligned_ch, 0, 1)
            aligned_channels.append(aligned_ch)
        
        aligned_render = np.stack(aligned_channels, axis=2)
        return aligned_render
    
    elif method == 'histogram':
        # 直方图匹配
        try:
            from skimage import exposure
            aligned_channels = []
            for c in range(render_img.shape[2]):
                render_ch = (render_img[:, :, c] * 255).astype(np.uint8)
                gt_ch = (gt_img[:, :, c] * 255).astype(np.uint8)
                aligned_ch = exposure.match_histograms(render_ch, gt_ch)
                aligned_channels.append(aligned_ch.astype(np.float32) / 255.0)
            aligned_render = np.stack(aligned_channels, axis=2)
            return aligned_render
        except ImportError:
            print("⚠️ skimage未安装，使用mean_std方法")
            return align_brightness_contrast(render_img, gt_img, 'mean_std')
    
    else:
        return render_img


def calculate_metrics(render_tensor, gt_tensor):
    """计算图像质量指标"""
    metrics = {}
    
    # 确保tensor是连续的
    render_tensor = render_tensor.contiguous()
    gt_tensor = gt_tensor.contiguous()
    
    # MSE
    mse = ((render_tensor - gt_tensor) ** 2).mean().item()
    metrics['MSE'] = mse
    
    # MAE
    mae = torch.abs(render_tensor - gt_tensor).mean().item()
    metrics['MAE'] = mae
    
    # PSNR（手动计算，避免view问题）
    mse_psnr = ((render_tensor - gt_tensor) ** 2).view(render_tensor.shape[0], -1).mean(1, keepdim=True)
    psnr_value = 20 * torch.log10(1.0 / torch.sqrt(mse_psnr + 1e-10))
    metrics['PSNR'] = psnr_value.item()
    
    # SSIM
    metrics['SSIM'] = ssim(render_tensor, gt_tensor).item()
    
    # LPIPS
    if LPIPS_AVAILABLE:
        # LPIPS需要[-1, 1]范围
        render_lpips = render_tensor * 2.0 - 1.0
        gt_lpips = gt_tensor * 2.0 - 1.0
        metrics['LPIPS'] = lpips_fn(render_lpips, gt_lpips).item()
    else:
        metrics['LPIPS'] = None
    
    return metrics


def main():
    parser = argparse.ArgumentParser(description='验证图像对齐效果')
    parser.add_argument('--render_path', type=str, required=True,
                       help='渲染结果图像路径')
    parser.add_argument('--gt_path', type=str, required=True,
                       help='原始图像路径')
    parser.add_argument('--output_dir', type=str, default=None,
                       help='输出目录（保存对齐后的图像）')
    parser.add_argument('--method', type=str, default='mean_std',
                       choices=['mean_std', 'min_max', 'histogram'],
                       help='对齐方法')
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("验证图像对齐效果")
    print("=" * 80)
    print(f"渲染图像: {args.render_path}")
    print(f"原始图像: {args.gt_path}")
    print(f"对齐方法: {args.method}")
    print("=" * 80 + "\n")
    
    # 加载图像
    render_img = load_image(args.render_path)
    gt_img = load_image(args.gt_path)
    
    # 确保尺寸一致
    if render_img.shape[:2] != gt_img.shape[:2]:
        print(f"⚠️ 调整渲染图像尺寸: {render_img.shape[:2]} -> {gt_img.shape[:2]}")
        render_img = cv2.resize(render_img, (gt_img.shape[1], gt_img.shape[0]), interpolation=cv2.INTER_LINEAR)
    
    # 转换为tensor（确保连续内存）
    render_tensor = torch.from_numpy(render_img).permute(2, 0, 1).unsqueeze(0).float().contiguous()  # (1, C, H, W)
    gt_tensor = torch.from_numpy(gt_img).permute(2, 0, 1).unsqueeze(0).float().contiguous()
    
    if torch.cuda.is_available():
        render_tensor = render_tensor.cuda()
        gt_tensor = gt_tensor.cuda()
    
    # 计算对齐前的指标
    print("【对齐前的指标】")
    print("-" * 80)
    metrics_before = calculate_metrics(render_tensor, gt_tensor)
    for key, value in metrics_before.items():
        if value is not None:
            print(f"  {key}: {value:.6f}" if isinstance(value, float) else f"  {key}: {value}")
    print()
    
    # 对齐图像
    print(f"【对齐图像（方法: {args.method}）】")
    print("-" * 80)
    aligned_render = align_brightness_contrast(render_img, gt_img, args.method)
    
    # 显示对齐前后的统计信息
    print("对齐前统计:")
    print(f"  均值: {render_img.mean():.6f}, 标准差: {render_img.std():.6f}")
    print(f"  值范围: [{render_img.min():.6f}, {render_img.max():.6f}]")
    print("\n对齐后统计:")
    print(f"  均值: {aligned_render.mean():.6f}, 标准差: {aligned_render.std():.6f}")
    print(f"  值范围: [{aligned_render.min():.6f}, {aligned_render.max():.6f}]")
    print("\n目标统计:")
    print(f"  均值: {gt_img.mean():.6f}, 标准差: {gt_img.std():.6f}")
    print(f"  值范围: [{gt_img.min():.6f}, {gt_img.max():.6f}]")
    print()
    
    # 转换为tensor（确保连续内存）
    aligned_tensor = torch.from_numpy(aligned_render).permute(2, 0, 1).unsqueeze(0).float().contiguous()
    if torch.cuda.is_available():
        aligned_tensor = aligned_tensor.cuda()
    
    # 计算对齐后的指标
    print("【对齐后的指标】")
    print("-" * 80)
    metrics_after = calculate_metrics(aligned_tensor, gt_tensor)
    for key, value in metrics_after.items():
        if value is not None:
            print(f"  {key}: {value:.6f}" if isinstance(value, float) else f"  {key}: {value}")
    print()
    
    # 对比改进
    print("=" * 80)
    print("【改进对比】")
    print("=" * 80)
    print(f"{'指标':<10} {'对齐前':<15} {'对齐后':<15} {'改进':<15} {'改进率':<10}")
    print("-" * 80)
    
    for key in ['MSE', 'MAE', 'PSNR', 'SSIM', 'LPIPS']:
        if key in metrics_before and metrics_before[key] is not None:
            before = metrics_before[key]
            after = metrics_after[key]
            
            if key == 'PSNR' or key == 'SSIM':
                # PSNR和SSIM越大越好
                improvement = after - before
                improvement_pct = (improvement / before * 100) if before > 0 else 0
                print(f"{key:<10} {before:<15.6f} {after:<15.6f} {improvement:+.6f} {improvement_pct:+.2f}%")
            else:
                # MSE、MAE、LPIPS越小越好
                improvement = before - after
                improvement_pct = (improvement / before * 100) if before > 0 else 0
                print(f"{key:<10} {before:<15.6f} {after:<15.6f} {improvement:+.6f} {improvement_pct:+.2f}%")
    
    print("=" * 80)
    
    # 保存对齐后的图像
    if args.output_dir:
        output_dir = Path(args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        aligned_uint8 = (aligned_render * 255).astype(np.uint8)
        aligned_path = output_dir / f'aligned_{Path(args.render_path).stem}.png'
        cv2.imwrite(str(aligned_path), cv2.cvtColor(aligned_uint8, cv2.COLOR_RGB2BGR))
        print(f"\n✅ 对齐后的图像已保存: {aligned_path}")
    
    # 结论
    print("\n" + "=" * 80)
    print("【结论】")
    print("=" * 80)
    
    ssim_improvement = metrics_after['SSIM'] - metrics_before['SSIM']
    psnr_improvement = metrics_after['PSNR'] - metrics_before['PSNR']
    
    if ssim_improvement > 0.1 or psnr_improvement > 3:
        print("✅ 对齐后指标显著提升！")
        print("   这说明指标差主要是由亮度/对比度偏移导致的，而不是结构性问题。")
        print("   建议：")
        print("   1. 检查训练时的图像预处理是否一致")
        print("   2. 检查渲染时的归一化方式")
        print("   3. 考虑在训练时使用更一致的预处理")
    elif ssim_improvement > 0.05 or psnr_improvement > 1:
        print("⚠️ 对齐后指标有所提升，但仍有改进空间。")
        print("   可能存在结构性问题，建议进一步检查。")
    else:
        print("⚠️ 对齐后指标提升不明显。")
        print("   这可能不是预处理问题，而是模型本身的问题。")
        print("   建议：")
        print("   1. 增加训练迭代次数")
        print("   2. 调整训练参数")
        print("   3. 检查点云质量")
    
    print("=" * 80)


if __name__ == "__main__":
    main()
