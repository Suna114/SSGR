#!/usr/bin/env python3
"""Build train|render montage for paper figures."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

DEFAULT_CLASSES = [
    "2S1",
    "BMP2",
    "BRDM_2",
    "BTR70",
    "D7",
    "SLICY",
    "T62",
    "T72",
    "ZIL131",
    "ZSU_23_4",
]

DEFAULT_CLASS_FONT = Path(r"C:\Windows\Fonts\timesbd.ttf")
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp")


def _load_font(size: int, font_path: Path | None = None) -> ImageFont.ImageFont:
    candidates = []
    if font_path is not None:
        candidates.append(font_path)
    candidates.extend(
        [
            DEFAULT_CLASS_FONT,
            Path(r"C:\Windows\Fonts\times.ttf"),
            Path(r"C:\Windows\Fonts\arialbd.ttf"),
            Path(r"C:\Windows\Fonts\arial.ttf"),
        ]
    )
    for path in candidates:
        if path.is_file():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def _text_size(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont) -> tuple[int, int]:
    box = draw.textbbox((0, 0), text, font=font)
    return box[2] - box[0], box[3] - box[1]


def _parse_report_azimuths(report_path: Path) -> dict[str, float]:
    mapping: dict[str, float] = {}
    if not report_path.is_file():
        return mapping
    for line in report_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith(
            ("source_", "projection_", "camera_", "mesh_", "world_", "gs_", "train ", "views:", "view", "-")
        ):
            continue
        parts = re.split(r"\s+", line)
        if len(parts) < 2:
            continue
        try:
            mapping[parts[0]] = float(parts[1])
        except ValueError:
            continue
    return mapping


def _find_train_image(class_dir: Path, view_name: str) -> Path | None:
    for sub in ("images", "input"):
        for ext in IMAGE_EXTS:
            candidate = class_dir / sub / f"{view_name}{ext}"
            if candidate.is_file():
                return candidate
    return None


def _fit_cell(im: Image.Image, cell_size: int, bg: tuple[int, int, int]) -> Image.Image:
    if im.mode == "RGBA":
        base = Image.new("RGB", im.size, bg)
        base.paste(im, mask=im.split()[3])
        im = base
    elif im.mode != "RGB":
        im = im.convert("RGB")
    return im.resize((cell_size, cell_size), Image.Resampling.LANCZOS)


def _azimuth_from_render_name(path: Path) -> int:
    return int(path.stem.split("_", 1)[1])


def _find_render_for_azimuth(render_dir: Path, azimuth: float) -> Path | None:
    renders = sorted(render_dir.glob("azimuth_*.png"), key=_azimuth_from_render_name)
    if not renders:
        return None
    target = int(round(azimuth))
    return min(renders, key=lambda path: abs(_azimuth_from_render_name(path) - target))


def _training_entries(class_dir: Path, verify_dir: str) -> list[tuple[float, str]]:
    report = _parse_report_azimuths(class_dir / verify_dir / "report.txt")
    entries: list[tuple[float, str]] = []
    seen: set[str] = set()

    for view_name, az in sorted(report.items(), key=lambda item: item[1]):
        if view_name in seen:
            continue
        if _find_train_image(class_dir, view_name) is None:
            continue
        entries.append((az, view_name))
        seen.add(view_name)

    if entries:
        return entries

    for sub in ("images", "input"):
        img_dir = class_dir / sub
        if not img_dir.is_dir():
            continue
        for path in sorted(img_dir.iterdir()):
            if path.suffix.lower() not in IMAGE_EXTS:
                continue
            view_name = path.stem
            if view_name in seen:
                continue
            suffix = view_name.rsplit("-", 1)[-1]
            az = float(report.get(view_name, int(suffix) if suffix.isdigit() else 0))
            entries.append((az, view_name))
            seen.add(view_name)
    entries.sort(key=lambda item: item[0])
    return entries


def _collect_pairs(
    class_name: str,
    class_dir: Path,
    render_dir: Path | None,
    verify_dir: str,
    sim_source: str,
    pick_every: int,
    pick_count: int,
) -> list[tuple[Path, Path]]:
    if sim_source == "verify":
        verify_path = class_dir / verify_dir
        report = _parse_report_azimuths(verify_path / "report.txt")
        entries: list[tuple[float, str, Path]] = []
        for sim_path in sorted(verify_path.glob("sim_*.png")):
            view_name = sim_path.stem.removeprefix("sim_")
            az = report.get(view_name)
            if az is None:
                suffix = view_name.rsplit("-", 1)[-1]
                az = float(int(suffix)) if suffix.isdigit() else 0.0
            entries.append((az, view_name, sim_path))
        entries.sort(key=lambda item: item[0])
        selected = entries[::pick_every][:pick_count]
        pairs: list[tuple[Path, Path]] = []
        missing: list[str] = []
        for _, view_name, sim_path in selected:
            train_path = _find_train_image(class_dir, view_name)
            if train_path is None:
                missing.append(view_name)
                continue
            pairs.append((train_path, sim_path))
    else:
        if render_dir is None or not render_dir.is_dir():
            raise FileNotFoundError(f"{class_name}: render dir not found: {render_dir}")
        entries = _training_entries(class_dir, verify_dir)
        if not entries:
            raise FileNotFoundError(f"{class_name}: no training views found under {class_dir}")
        selected = entries[::pick_every][:pick_count]
        pairs = []
        missing: list[str] = []
        for az, view_name in selected:
            train_path = _find_train_image(class_dir, view_name)
            render_path = _find_render_for_azimuth(render_dir, az)
            if train_path is None:
                missing.append(view_name)
                continue
            if render_path is None:
                missing.append(f"render@{int(round(az))}")
                continue
            pairs.append((train_path, render_path))

    if missing:
        raise FileNotFoundError(f"{class_name}: missing pairs for {missing}")
    if len(pairs) < pick_count:
        raise RuntimeError(f"{class_name}: only collected {len(pairs)}/{pick_count} pairs")
    return pairs


def build_montage(
    data_root: Path,
    final_root: Path,
    classes: list[str],
    verify_dir: str,
    render_relpath: Path,
    sim_source: str,
    pick_every: int,
    pick_count: int,
    cell_size: int,
    gap: int,
    class_gap: int,
    header_gap: int,
    bgcolor: str,
    class_font_size: int,
    class_font_path: Path | None,
) -> Image.Image:
    bg = (255, 255, 255) if bgcolor == "white" else (0, 0, 0)
    text_color = (0, 0, 0) if bgcolor == "white" else (255, 255, 255)
    class_font = _load_font(class_font_size, class_font_path)

    class_pairs: dict[str, list[tuple[Path, Path]]] = {}
    for cls in classes:
        render_dir = final_root / cls / render_relpath if sim_source == "novel_render" else None
        class_pairs[cls] = _collect_pairs(
            class_name=cls,
            class_dir=data_root / cls,
            render_dir=render_dir,
            verify_dir=verify_dir,
            sim_source=sim_source,
            pick_every=pick_every,
            pick_count=pick_count,
        )

    measure = ImageDraw.Draw(Image.new("RGB", (1, 1), bg))
    header_h = max(_text_size(measure, cls, class_font)[1] for cls in classes) + header_gap
    block_w = cell_size + gap + cell_size
    grid_h = pick_count * cell_size + max(0, pick_count - 1) * gap
    block_h = header_h + grid_h

    out_w = len(classes) * block_w + max(0, len(classes) - 1) * class_gap
    mosaic = Image.new("RGB", (out_w, block_h), bg)
    draw = ImageDraw.Draw(mosaic)

    for idx, cls in enumerate(classes):
        x0 = idx * (block_w + class_gap)
        train_x = x0
        sim_x = x0 + cell_size + gap

        class_tw, class_th = _text_size(draw, cls, class_font)
        draw.text(
            (x0 + (block_w - class_tw) // 2, (header_h - class_th) // 2),
            cls,
            fill=text_color,
            font=class_font,
        )

        y0 = header_h
        for row, (train_path, sim_path) in enumerate(class_pairs[cls]):
            y = y0 + row * (cell_size + gap)
            with Image.open(train_path) as train_im:
                mosaic.paste(_fit_cell(train_im, cell_size, bg), (train_x, y))
            with Image.open(sim_path) as sim_im:
                mosaic.paste(_fit_cell(sim_im, cell_size, bg), (sim_x, y))

    return mosaic


def main() -> int:
    repo = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description="Montage train|render pairs for paper figures.")
    parser.add_argument("--data-root", type=Path, default=repo / "data")
    parser.add_argument("--final-root", type=Path, default=repo / "output" / "final")
    parser.add_argument(
        "--output",
        type=Path,
        default=repo / "output" / "final" / "picture2" / "fig_sfm_ablation_verify_sim_montage.png",
    )
    parser.add_argument("--verify-dir", type=str, default="sar_imaging_verify")
    parser.add_argument(
        "--render-relpath",
        type=Path,
        default=Path("gaussian/novel_target_only/renders"),
        help="Relative path under final-root/<class>/ for rendered images.",
    )
    parser.add_argument(
        "--sim-source",
        choices=("novel_render", "verify"),
        default="novel_render",
        help="Right column source: novel_target_only renders or sar_imaging_verify/sim_*.png.",
    )
    parser.add_argument("--classes", nargs="*", default=DEFAULT_CLASSES)
    parser.add_argument("--pick-every", type=int, default=6, help="Keep one view every N sorted views.")
    parser.add_argument("--pick-count", type=int, default=6, help="Maximum rows per class.")
    parser.add_argument("--cell-size", type=int, default=128)
    parser.add_argument("--gap", type=int, default=12, help="Gap between train/render columns and between rows.")
    parser.add_argument("--class-gap", type=int, default=12, help="Horizontal gap between class blocks.")
    parser.add_argument("--header-gap", type=int, default=8, help="Padding below class title.")
    parser.add_argument("--bgcolor", choices=("black", "white"), default="white")
    parser.add_argument("--class-font-size", type=int, default=20)
    parser.add_argument(
        "--class-font",
        type=Path,
        default=DEFAULT_CLASS_FONT,
        help="Class title font file (default: Times New Roman Bold).",
    )
    args = parser.parse_args()

    mosaic = build_montage(
        data_root=args.data_root.resolve(),
        final_root=args.final_root.resolve(),
        classes=list(args.classes),
        verify_dir=args.verify_dir,
        render_relpath=args.render_relpath,
        sim_source=args.sim_source,
        pick_every=max(1, args.pick_every),
        pick_count=max(1, args.pick_count),
        cell_size=max(1, args.cell_size),
        gap=max(0, args.gap),
        class_gap=max(0, args.class_gap),
        header_gap=max(0, args.header_gap),
        bgcolor=args.bgcolor,
        class_font_size=max(8, args.class_font_size),
        class_font_path=args.class_font.resolve() if args.class_font else None,
    )
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    mosaic.save(output, quality=95)
    print(f"[prepare_verify_sim] sim_source={args.sim_source}")
    print(f"[prepare_verify_sim] output: {output} ({mosaic.width}x{mosaic.height})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
