# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# ============================================================================
# 方案2：地面平整度正则化项 - 完整实现代码
# ============================================================================
# 
# 使用方法：将以下代码添加到 comple/train.py 的损失计算部分（第126行之后）
# 
# ============================================================================

# ========== 代码片段1：添加到损失计算部分（在 loss.backward() 之前） ==========

# 地面平整度正则化项
ground_flatness_loss = 0.0
ground_flatness_weight = 0.0  # 用于记录实际使用的权重

if iteration > 0:  # 从第一次迭代开始应用
    # 获取地面高度参数
    ground_height = 0.0  # 默认地面高度（COLMAP坐标系中Y=0）
    if hasattr(dataset, 'background_height'):
        ground_height = dataset.background_height
    
    # 识别地面点：Y坐标接近ground_height的点
    ground_tolerance = 0.2  # 容差：允许地面点在这个范围内
    xyz = gaussians.get_xyz
    ground_mask = torch.abs(xyz[:, 1] - ground_height) < ground_tolerance
    
    if torch.sum(ground_mask) > 0:
        ground_y = xyz[ground_mask, 1]
        
        # ========== 选择正则化项形式 ==========
        # 形式1：方差正则化（推荐，不依赖ground_height的精确值）
        y_variance = torch.var(ground_y)
        regularization_term = y_variance
        
        # 形式2：L2正则化（明确约束到ground_height）
        # regularization_term = torch.mean((ground_y - ground_height) ** 2)
        
        # 形式3：L1正则化（对异常值更鲁棒）
        # regularization_term = torch.mean(torch.abs(ground_y - ground_height))
        
        # 形式4：Huber损失（结合L1和L2的优点）
        # delta = 0.1  # 阈值
        # diff = ground_y - ground_height
        # huber_loss = torch.where(
        #     torch.abs(diff) < delta,
        #     0.5 * diff ** 2,
        #     delta * (torch.abs(diff) - 0.5 * delta)
        # )
        # regularization_term = torch.mean(huber_loss)
        
        # ========== 选择权重策略 ==========
        # 策略1：固定权重（最简单，需要手动调优）
        lambda_flatness = 0.01  # 固定值，需要根据实际情况调整
        
        # 策略2：线性增长权重（训练初期小，后期大）
        # progress = iteration / opt.iterations
        # lambda_flatness = 0.001 * (1.0 + progress * 9.0)  # 从0.001增长到0.01
        
        # 策略3：基于方差的自适应权重（方差大时增加权重）
        # if y_variance > 0.1:  # 如果方差很大
        #     lambda_flatness = 0.05  # 使用大权重
        # else:
        #     lambda_flatness = 0.01  # 使用小权重
        
        # 策略4：指数增长权重（训练初期权重很小，后期快速增长）
        # progress = iteration / opt.iterations
        # lambda_flatness = 0.001 * (2.0 ** (progress * 3.0))  # 从0.001指数增长
        
        # 计算正则化损失
        ground_flatness_loss = lambda_flatness * regularization_term
        ground_flatness_weight = lambda_flatness
        
        # ========== 监控和日志（每100次迭代打印一次） ==========
        if iteration % 100 == 0:
            y_mean = torch.mean(ground_y).item()
            y_std = torch.std(ground_y).item()
            y_min = torch.min(ground_y).item()
            y_max = torch.max(ground_y).item()
            
            print(f"[ITER {iteration}] 地面平整度正则化:")
            print(f"  地面点数量: {torch.sum(ground_mask).item()}")
            print(f"  平均高度: {y_mean:.4f}")
            print(f"  标准差: {y_std:.4f}")
            print(f"  高度范围: [{y_min:.4f}, {y_max:.4f}]")
            print(f"  Y坐标方差: {y_variance.item():.6f}")
            print(f"  正则化损失: {ground_flatness_loss.item():.6f}")
            print(f"  权重: {lambda_flatness:.6f}")

# 添加到总损失
loss = loss + ground_flatness_loss


# ============================================================================
# ========== 代码片段2：添加到参数定义（可选，用于命令行参数） ==========
# ============================================================================
# 
# 如果要通过命令行参数控制权重，可以在 arguments/__init__.py 的 OptimizationParams 类中添加：
# 
# class OptimizationParams(ParamGroup):
#     def __init__(self, parser):
#         # ... 现有参数 ...
#         self.ground_flatness_weight = 0.01  # 地面平整度正则化权重
#         self.ground_flatness_tolerance = 0.2  # 地面点识别容差
#         super().__init__(parser, "Optimization Parameters")
# 
# 然后在训练代码中使用：
# lambda_flatness = opt.ground_flatness_weight
# ground_tolerance = opt.ground_flatness_tolerance
# 
# ============================================================================


# ============================================================================
# ========== 代码片段3：TensorBoard记录（可选） ==========
# ============================================================================
# 
# 如果使用TensorBoard，可以添加：
# 
# if iteration % 100 == 0 and tb_writer:
#     tb_writer.add_scalar('train/ground_flatness_loss', ground_flatness_loss.item(), iteration)
#     tb_writer.add_scalar('train/ground_y_variance', y_variance.item(), iteration)
#     tb_writer.add_scalar('train/ground_y_mean', y_mean, iteration)
#     tb_writer.add_scalar('train/ground_y_std', y_std, iteration)
#     tb_writer.add_scalar('train/ground_point_count', torch.sum(ground_mask).item(), iteration)
# 
# ============================================================================

