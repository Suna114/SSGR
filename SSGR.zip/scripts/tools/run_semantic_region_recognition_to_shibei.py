#!/usr/bin/env python3
"""Run semantic target/shadow recognition for data/* without replacing originals."""

from __future__ import annotations

import argparse
import contextlib
import csv
import io
import json
import os
import shutil
import sys
import time
from pathlib import Path

import numpy as np


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
FEATURE_DIR = REPO_ROOT / "scripts" / "data_prep"
if str(FEATURE_DIR) not in sys.path:
    sys.path.insert(0, str(FEATURE_DIR))

from sar.semantic_mask_config import SEMANTIC_MASK_DEFAULTS, compute_scattering_threshold  # noqa: E402
from sar_utils import preprocess_sar_image  # noqa: E402
from feature_extraction import (  # noqa: E402
    apply_dataset_shadow_consistency_refinement,
    create_scattering_mask,
    enhance_target_contrast_adaptive,
    visualize_adaptive_threshold_effect,
    visualize_scattering_regions,
)


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}
DEFAULT_CLASSES = [
    "2S1",
    "BMP2",
    "BRDM_2",
    "BTR70",
    "D7",
    "SLICY",
    "T62",
    "T72",
    "ZIL131",
    "ZSU_23_4",
]


def _image_dir(data_dir: Path) -> Path:
    for name in ("input", "images"):
        candidate = data_dir / name
        if candidate.is_dir() and any(p.suffix.lower() in IMAGE_EXTS for p in candidate.iterdir()):
            return candidate
    return data_dir


def _load_gray(path: Path) -> np.ndarray:
    try:
        import cv2

        arr = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if arr is None:
            raise OSError(f"cv2.imread returned None: {path}")
        return preprocess_sar_image(arr)
    except Exception:
        from PIL import Image

        return preprocess_sar_image(np.asarray(Image.open(path).convert("L")))


def _params() -> dict:
    p = dict(SEMANTIC_MASK_DEFAULTS)
    p.update(
        {
            "shadow_target_geometry_filter": not bool(p.get("no_shadow_target_geometry_filter", False)),
            "shadow_require_background_mask": not bool(p.get("no_shadow_require_background_mask", True)),
            "shadow_geometry_azimuth_mode": "mstar_axis_split",
            "target_boost": 1.1,
            "background_suppress": 0.6,
            "target_dark_suppress": 0.6,
            "target_bright_boost": 1.1,
        }
    )
    return p


def _write_mask_run(
    class_out: Path,
    masks: dict[str, np.ndarray],
    params: dict,
    *,
    source_data_dir: Path,
    source_image_dir: Path,
    run_id: str,
) -> Path:
    out_dir = class_out / "scattering_masks" / "from_convert" / run_id
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, mask in masks.items():
        np.save(out_dir / f"{Path(name).stem}_mask.npy", np.asarray(mask, dtype=np.int8))
    semantic_params = {
        "run_id": run_id,
        "source_data_dir": str(source_data_dir),
        "source_image_dir": str(source_image_dir),
        "params": params,
        "count": len(masks),
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    (out_dir / "semantic_params.json").write_text(
        json.dumps(semantic_params, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    latest = {
        "run_id": run_id,
        "saved_at": semantic_params["saved_at"],
        "count": len(masks),
        "source_data_dir": str(source_data_dir),
        "source_image_dir": str(source_image_dir),
        "params": params,
    }
    latest_path = class_out / "scattering_masks" / "from_convert" / "latest.json"
    latest_path.parent.mkdir(parents=True, exist_ok=True)
    latest_path.write_text(json.dumps(latest, indent=2, ensure_ascii=False), encoding="utf-8")
    return out_dir


def _write_target_masks(class_out: Path, masks: dict[str, np.ndarray]) -> Path:
    from PIL import Image

    out_dir = class_out / "scattering_masks" / "target_masks_from_convert" / "latest"
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, mask in masks.items():
        target = ((mask == 1) | (mask == 2)).astype(np.uint8) * 255
        Image.fromarray(target, mode="L").save(out_dir / f"{Path(name).stem}.png")
    (out_dir / "semantic_target_mask_manifest.json").write_text(
        json.dumps(
            {
                "target_labels": [1, 2],
                "count": len(masks),
                "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    return out_dir


def _copy_source_images(source_image_dir: Path, class_out: Path) -> None:
    dst = class_out / "input"
    dst.mkdir(parents=True, exist_ok=True)
    for src in sorted(p for p in source_image_dir.iterdir() if p.suffix.lower() in IMAGE_EXTS):
        target = dst / src.name
        if not target.exists() or target.stat().st_size != src.stat().st_size:
            shutil.copy2(src, target)


def _recognize_one_class(data_dir: Path, out_root: Path, run_id: str, *, copy_images: bool) -> dict:
    params = _params()
    image_dir = _image_dir(data_dir)
    class_out = out_root / data_dir.name
    viz_dir = class_out / "adaptive_threshold_visualization"
    viz_dir.mkdir(parents=True, exist_ok=True)
    if copy_images:
        _copy_source_images(image_dir, class_out)

    image_paths = sorted(p for p in image_dir.iterdir() if p.suffix.lower() in IMAGE_EXTS)
    all_results: dict[str, dict] = {}
    print(f"\n[{data_dir.name}] images={len(image_paths)} source={image_dir}")
    for idx, path in enumerate(image_paths, 1):
        image = _load_gray(path)
        target_thr, bg_thr = compute_scattering_threshold(
            image,
            target_percentile=float(params["target_percentile"]),
            background_percentile=float(params["background_percentile"]),
            verbose=False,
        )
        with contextlib.redirect_stdout(io.StringIO()):
            mask = create_scattering_mask(
                image,
                target_thr,
                bg_thr,
                shadow_threshold_factor=float(params["shadow_threshold_factor"]),
                output_dir=None,
                img_name=path.name,
                target_selection_mode=str(params["target_selection_mode"]),
                target_percentile=float(params["target_percentile"]),
                target_filter_blur_sigma=float(params["target_filter_blur_sigma"]),
                target_filter_open_iter=int(params["target_filter_open_iter"]),
                target_filter_close_iter=int(params["target_filter_close_iter"]),
                target_filter_morph_kernel=int(params["target_filter_morph_kernel"]),
                target_filter_largest_cc=bool(params["target_filter_largest_cc"]),
                target_filter_min_target_ratio=float(params["target_filter_min_target_ratio"]),
                target_filter_min_cc_area=int(params["target_filter_min_cc_area"]),
                target_filter_erode_px=int(params["target_filter_erode_px"]),
                target_mask_dilate_px=int(params["target_mask_dilate_px"]),
                target_edge_band_px=int(params["target_edge_band_px"]),
                target_edge_inner_px=int(params["target_edge_inner_px"]),
                target_edge_outer_px=int(params["target_edge_outer_px"]),
                merge_target_edge_into_interior=bool(params["merge_scattering_target_edge"]),
                target_mask_largest_component_only=bool(params["target_mask_largest_component_only"]),
                target_mask_min_component_area_px=int(params["target_mask_min_component_area_px"]),
                target_semantic_largest_component_only=bool(params["target_semantic_largest_component_only"]),
                target_semantic_keep_dilate_px=int(params["target_semantic_keep_dilate_px"]),
                shadow_percentile=float(params["shadow_percentile"]),
                shadow_target_geometry_filter=bool(params["shadow_target_geometry_filter"]),
                shadow_min_area_fraction=float(params["shadow_min_area_fraction"]),
                shadow_min_target_area_fraction=float(params["shadow_min_target_area_fraction"]),
                shadow_y_margin_fraction=float(params["shadow_y_margin_fraction"]),
                shadow_require_background_mask=bool(params["shadow_require_background_mask"]),
                shadow_target_dilate_px=int(params["shadow_target_dilate_px"]),
                shadow_bridge_along_azimuth=bool(params["shadow_bridge_along_azimuth"]),
                shadow_bridge_length_px=int(params["shadow_bridge_length_px"]),
                shadow_bridge_width_px=int(params["shadow_bridge_width_px"]),
                target_center_roi_fraction=float(params["target_center_roi_fraction"]),
                target_center_roi_min_keep_fraction=float(params["target_center_roi_min_keep_fraction"]),
                shadow_use_azimuth_prior=bool(params["shadow_use_azimuth_prior"]),
                shadow_direction_offset_deg=float(params["shadow_direction_offset_deg"]),
                shadow_azimuth_tolerance_deg=float(params["shadow_azimuth_tolerance_deg"]),
                shadow_azimuth_direction_weight=float(params["shadow_azimuth_direction_weight"]),
            )
        mask = np.asarray(mask, dtype=np.int8)
        all_results[path.name] = {"scattering_mask": mask, "path": str(path)}
        with contextlib.redirect_stdout(io.StringIO()):
            region_path = visualize_scattering_regions(image, mask, str(viz_dir), path.name, verbose=False)
            enhanced = enhance_target_contrast_adaptive(
                image,
                mask,
                target_boost=params["target_boost"],
                background_suppress=params["background_suppress"],
                target_dark_suppress=params["target_dark_suppress"],
                target_bright_boost=params["target_bright_boost"],
            )
            effect_path = visualize_adaptive_threshold_effect(image, enhanced, mask, str(viz_dir), path.name)
        all_results[path.name]["region_classification"] = region_path
        all_results[path.name]["threshold_effect"] = effect_path
        if idx % max(1, len(image_paths) // 4) == 0 or idx == len(image_paths):
            print(f"  progress {idx}/{len(image_paths)}")

    if all_results and params.get("shadow_dataset_consistency", True):
        with contextlib.redirect_stdout(io.StringIO()):
            all_results = apply_dataset_shadow_consistency_refinement(
                image_paths,
                all_results,
                output_dir=str(viz_dir),
                params=params,
            )

    masks = {
        name: np.asarray(result["scattering_mask"], dtype=np.int8)
        for name, result in all_results.items()
        if result.get("scattering_mask") is not None
    }
    mask_dir = _write_mask_run(class_out, masks, params, source_data_dir=data_dir, source_image_dir=image_dir, run_id=run_id)
    target_dir = _write_target_masks(class_out, masks)

    rows = []
    for name, mask in sorted(masks.items()):
        labels, counts = np.unique(mask, return_counts=True)
        count_by_label = {int(k): int(v) for k, v in zip(labels, counts)}
        total = int(mask.size)
        rows.append(
            {
                "class": data_dir.name,
                "image": name,
                "total_px": total,
                "background_px": count_by_label.get(0, 0),
                "target_px": count_by_label.get(1, 0) + count_by_label.get(2, 0),
                "target_core_px": count_by_label.get(1, 0),
                "target_edge_px": count_by_label.get(2, 0),
                "shadow_px": count_by_label.get(3, 0),
                "mask_path": str(mask_dir / f"{Path(name).stem}_mask.npy"),
            }
        )
    return {
        "class": data_dir.name,
        "count": len(masks),
        "mask_dir": str(mask_dir),
        "target_mask_dir": str(target_dir),
        "viz_dir": str(viz_dir),
        "rows": rows,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_root", type=Path, default=REPO_ROOT / "data")
    parser.add_argument("--output_root", type=Path, default=REPO_ROOT / "data" / "shibei")
    parser.add_argument("--classes", nargs="*", default=DEFAULT_CLASSES)
    parser.add_argument("--run_id", default=None)
    parser.add_argument("--copy_images", action=argparse.BooleanOptionalAction, default=False)
    args = parser.parse_args()

    run_id = args.run_id or time.strftime("%Y%m%d_%H%M%S")
    args.output_root.mkdir(parents=True, exist_ok=True)
    summaries = []
    all_rows = []
    for name in args.classes:
        data_dir = args.data_root / name
        if not data_dir.is_dir():
            print(f"[skip] missing {data_dir}")
            continue
        summary = _recognize_one_class(data_dir, args.output_root, run_id, copy_images=bool(args.copy_images))
        summaries.append({k: v for k, v in summary.items() if k != "rows"})
        all_rows.extend(summary["rows"])

    summary_path = args.output_root / "semantic_region_shibei_summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = [
            "class",
            "image",
            "total_px",
            "background_px",
            "target_px",
            "target_core_px",
            "target_edge_px",
            "shadow_px",
            "mask_path",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_rows)
    manifest = {
        "run_id": run_id,
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "output_root": str(args.output_root),
        "classes": summaries,
        "summary_csv": str(summary_path),
    }
    manifest_path = args.output_root / "semantic_region_shibei_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\n[done] summary: {summary_path}")
    print(f"[done] manifest: {manifest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
