#!/usr/bin/env python3
"""从 Gaussian point_cloud.ply 中删除 red/green/blue 列，生成与原版 3DGS / SIBR 兼容的 PLY。

本仓库曾为 MeshLab 等工具写入顶点 RGB；SIBR_gaussianViewer 的 CUDA 路径通常按
「无 rgb 列」的布局解析，多出的 u8 列可能导致 illegal memory access。

用法:
  python scripts/tools/strip_ply_vertex_rgb_for_sibr.py input.ply output.ply
  python scripts/tools/strip_ply_vertex_rgb_for_sibr.py ./output/exp2/point_cloud/iteration_30000/point_cloud.ply ./output/exp2/point_cloud/iteration_30000/point_cloud_sibr.ply
"""
from __future__ import annotations

import sys
from pathlib import Path

from plyfile import PlyData, PlyElement
import numpy as np


def main() -> None:
    if len(sys.argv) != 3:
        print(__doc__.strip())
        sys.exit(1)
    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    if not src.is_file():
        print(f"找不到文件: {src}")
        sys.exit(1)

    ply = PlyData.read(str(src))
    v = ply["vertex"].data
    names = list(v.dtype.names)
    drop = {"red", "green", "blue"}
    if not drop.intersection(names):
        print("PLY 中无 red/green/blue，直接复制属性即可；仍写出新文件。")
        new_names = names
    else:
        new_names = [n for n in names if n not in drop]

    new_dtype = [(n, v.dtype.fields[n][0]) for n in new_names]
    out = np.empty(v.shape[0], dtype=new_dtype)
    for n in new_names:
        out[n] = v[n]

    el = PlyElement.describe(out, "vertex")
    PlyData([el]).write(str(dst))
    print(f"已写入: {dst}（属性数 {len(new_names)}）")


if __name__ == "__main__":
    main()
