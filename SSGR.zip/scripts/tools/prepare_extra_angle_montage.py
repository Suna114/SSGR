#!/usr/bin/env python3
"""Prepare montage from picture2 azimuth renders or data/input training views."""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

DEFAULT_LABEL_FONT = Path(r"C:\Windows\Fonts\timesbd.ttf")


def _run_gt_gaussian(args: argparse.Namespace, repo: Path) -> int:
    script = repo / "scripts" / "tools" / "prepare_gt_gaussian_montage.py"
    cell_size = args.cell_size if args.cell_size is not None else 128
    cmd = [
        sys.executable,
        str(script),
        "--render-root",
        str(args.render_root),
        "--gt-root",
        str(args.gt_root),
        "--render-relpath",
        str(args.render_relpath),
        "--output",
        str(args.output),
        "--cell-size",
        str(cell_size),
        "--gap",
        str(args.gap),
        "--class-gap",
        str(args.class_gap),
        "--label-padding",
        str(args.label_padding),
        "--bgcolor",
        args.bgcolor,
        "--pick-count",
        str(args.pick_count),
        "--label-font",
        str(args.label_font.resolve()),
        "--label-font-ratio",
        str(args.label_font_ratio),
    ]
    if "--classes" in sys.argv:
        cmd.extend(["--classes", *args.classes])
    print("[prepare] mode: gt-gaussian")
    print("[prepare] run:", " ".join(cmd))
    subprocess.run(cmd, check=True)
    print(f"[prepare] output: {args.output}")
    return 0


def _run_training_views(args: argparse.Namespace, repo: Path) -> int:
    script = repo / "scripts" / "tools" / "prepare_training_views_montage.py"
    cmd = [
        sys.executable,
        str(script),
        "--data-root",
        str(args.data_root),
        "--optical-dir",
        str(args.optical_dir),
        "--output",
        str(args.output),
        "--cell-size",
        str(args.cell_size),
        "--gap",
        str(args.gap),
        "--pick-count",
        str(18 if "--pick-count" not in sys.argv else args.pick_count),
        "--sar-cols",
        str(args.sar_cols),
        "--bgcolor",
        args.bgcolor,
        "--label-font",
        str(args.label_font.resolve()),
    ]
    if args.exclude_classes:
        cmd.extend(["--exclude-classes", *args.exclude_classes])
    if "--classes" in sys.argv:
        cmd.extend(["--classes", *args.classes])
    if args.label_font_ratio is not None:
        cmd.extend(["--label-font-ratio", str(args.label_font_ratio)])
    print("[prepare] mode: training-views")
    print("[prepare] run:", " ".join(cmd))
    subprocess.run(cmd, check=True)
    print(f"[prepare] output: {args.output}")
    return 0


def main() -> int:
    repo = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        choices=("azimuth", "training-views", "gt-gaussian"),
        default="azimuth",
        help="azimuth: picture2 grid; training-views: optical+input SAR; gt-gaussian: GT|render pairs.",
    )
    parser.add_argument(
        "--render-root",
        type=Path,
        default=Path(r"F:\3dgs\SSGR\output\agent2"),
        help="Render root for gt-gaussian mode.",
    )
    parser.add_argument(
        "--gt-root",
        type=Path,
        default=Path(r"F:\3dgs\新建文件夹\15"),
        help="GT image root for gt-gaussian mode.",
    )
    parser.add_argument(
        "--render-relpath",
        type=Path,
        default=Path("gaussian/novel_target_only/renders"),
        help="Relative path under render-root/<class>/ for gt-gaussian mode.",
    )
    parser.add_argument("--class-gap", type=int, default=12, help="Gap between class blocks (gt-gaussian).")
    parser.add_argument(
        "--data-root",
        type=Path,
        default=Path(r"F:\3dgs\SSGR\data"),
        help="Data root for training-views mode (uses <class>/input).",
    )
    parser.add_argument(
        "--optical-dir",
        type=Path,
        default=repo / "figure" / "optical_mstar",
        help="Optical reference images for training-views mode.",
    )
    parser.add_argument(
        "--exclude-classes",
        nargs="*",
        default=["SLICY"],
        help="Skip these classes in training-views mode.",
    )
    parser.add_argument("--pick-count", type=int, default=6, help="Rows per class block (training-views / gt-gaussian).")
    parser.add_argument("--sar-cols", type=int, default=9, help="SAR grid columns (training-views).")
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(r"F:\3dgs\SSGR\output\final\picture\extra"),
    )
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--start", type=int, default=5)
    parser.add_argument("--stop", type=int, default=355)
    parser.add_argument("--step", type=int, default=10)
    parser.add_argument(
        "--classes",
        nargs="*",
        default=["2S1", "BMP2", "BRDM_2", "BTR70", "D7", "SLICY", "T62", "T72", "ZIL131", "ZSU_23_4"],
    )
    parser.add_argument("--max-side", type=int, default=512)
    parser.add_argument("--cell-size", type=int, default=None)
    parser.add_argument("--bgcolor", choices=("black", "white"), default="black")
    parser.add_argument("--gap", type=int, default=0)
    parser.add_argument("--gap-x", type=int, default=None)
    parser.add_argument("--gap-y", type=int, default=None)
    parser.add_argument("--labels", action="store_true")
    parser.add_argument("--label-font-size", type=int, default=24)
    parser.add_argument(
        "--label-font-ratio",
        type=float,
        default=0.33,
        help="With --cell-size, cap label height to cell_size * ratio (default 0.33).",
    )
    parser.add_argument("--label-padding", type=int, default=12)
    parser.add_argument(
        "--label-font",
        type=Path,
        default=DEFAULT_LABEL_FONT,
        help="Label font file (default: Times New Roman Bold).",
    )
    parser.add_argument("--keep-staging", action="store_true")
    args = parser.parse_args()

    if args.mode == "gt-gaussian":
        if args.output is None:
            cell = args.cell_size if args.cell_size is not None else 128
            args.output = (
                Path(r"F:\3dgs\SSGR\output\final\picture2")
                / f"fig_gt_gaussian_montage_{args.pick_count}rows_{cell}_{args.bgcolor}_gap{args.gap}.png"
            )
        return _run_gt_gaussian(args, repo)

    if args.mode == "training-views":
        if args.output is None:
            args.output = (
                args.root
                / f"training_views_{args.pick_count}sar_{args.sar_cols}cols_{args.cell_size or 128}_{args.bgcolor}_gap{args.gap}.png"
            )
        return _run_training_views(args, repo)

    label_font_size = args.label_font_size
    if args.labels and args.cell_size is not None:
        label_font_size = max(8, int(round(args.cell_size * args.label_font_ratio)))

    angles = list(range(args.start, args.stop + 1, args.step))
    if not angles:
        raise SystemExit("No angles selected.")

    root = args.root.resolve()
    cols = len(angles)
    rows = len(args.classes)
    output = args.output or (
        root / f"montage_{args.start:03d}_{args.stop:03d}_step{args.step}_by_class_{rows}x{cols}.png"
    )
    staging = root / f"_montage_staging_{args.start:03d}_{args.stop:03d}_step{args.step}"

    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir()

    missing: list[str] = []
    idx = 0
    for cls in args.classes:
        for angle in angles:
            src = root / cls / f"azimuth_{angle:03d}.png"
            dst = staging / f"{idx:04d}_{cls}_az{angle:03d}.png"
            if not src.is_file():
                missing.append(str(src))
            else:
                shutil.copy2(src, dst)
            idx += 1

    montage_script = repo / "scripts" / "tools" / "montage_grid_folder.py"
    cmd = [
        sys.executable,
        str(montage_script),
        "-i",
        str(staging),
        "-o",
        str(output),
        "--cols",
        str(cols),
        "--rows",
        str(rows),
        "--max-side",
        str(args.max_side),
        "--bgcolor",
        args.bgcolor,
        "--gap",
        str(args.gap),
    ]
    if args.gap_x is not None:
        cmd.extend(["--gap-x", str(args.gap_x)])
    if args.gap_y is not None:
        cmd.extend(["--gap-y", str(args.gap_y)])
    if args.cell_size is not None:
        cmd.extend(["--cell-size", str(args.cell_size)])
    if args.labels:
        cmd.extend(
            [
                "--row-labels",
                ",".join(args.classes),
                "--col-labels",
                ",".join(f"{angle}°" for angle in angles),
                "--label-font-size",
                str(label_font_size),
                "--label-padding",
                str(args.label_padding),
                "--label-font",
                str(args.label_font.resolve()),
            ]
        )
        if args.labels:
            cmd.extend(["--label-font-ratio", str(args.label_font_ratio)])
    print("[prepare] staging:", staging)
    print("[prepare] angles:", len(angles), "classes:", len(args.classes))
    print("[prepare] run:", " ".join(cmd))
    subprocess.run(cmd, check=True)

    if not args.keep_staging:
        shutil.rmtree(staging)

    print(f"[prepare] output: {output}")
    if missing:
        print(f"[prepare] missing: {len(missing)}")
        for item in missing[:20]:
            print(" ", item)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
