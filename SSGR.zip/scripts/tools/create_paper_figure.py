# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
SAR-GS渲染结果论文展示图生成工具

功能：
1. 读取渲染结果图像（带方位角信息）
2. 按方位角排序
3. 组合成网格布局（可设置每行图像数量）
4. 生成适合论文的高质量图像（PNG/PDF）

使用方法：
    # 基本用法
    python create_paper_figure.py
    
    # 指定输入目录和每行图像数
    python create_paper_figure.py --input_dir ./my_renders/train/renders --cols 6 --output paper_figure.png
    
    # 生成PDF格式（适合论文）
    python create_paper_figure.py --input_dir ./my_renders/train/renders --cols 6 --output paper_figure.pdf --format pdf
"""

import os
import argparse
import re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np
from typing import List, Tuple, Optional


def extract_azimuth_from_filename(filename: str) -> Optional[int]:
    """
    从文件名提取方位角
    
    支持格式：
    - T72-15-002.png -> 2
    - T72-15-012.png -> 12
    - T72-15-123.png -> 123
    - image_045.png -> 45
    
    Args:
        filename: 文件名
        
    Returns:
        方位角（度），如果无法提取则返回None
    """
    # 提取文件名（不含扩展名）
    stem = Path(filename).stem
    
    # 尝试匹配最后的三位数字（可能是方位角）
    # 模式1: T72-15-002 格式
    match = re.search(r'-(\d{3})$', stem)
    if match:
        return int(match.group(1))
    
    # 模式2: 文件名末尾的数字
    match = re.search(r'(\d{3})$', stem)
    if match:
        return int(match.group(1))
    
    # 模式3: 任意位置的3位数字
    matches = re.findall(r'\d{3}', stem)
    if matches:
        return int(matches[-1])  # 使用最后一个3位数字
    
    return None


def load_and_sort_images(input_dir: str) -> List[Tuple[str, int]]:
    """
    加载图像并按方位角排序
    
    Args:
        input_dir: 输入目录路径
        
    Returns:
        [(图像路径, 方位角), ...] 的列表，按方位角排序
    """
    input_path = Path(input_dir)
    if not input_path.exists():
        raise FileNotFoundError(f"输入目录不存在: {input_dir}")
    
    # 支持的图像格式
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff']
    
    # 收集所有图像文件（使用set去重，避免Windows大小写问题）
    image_files_set = set()
    for ext in image_extensions:
        # Windows文件系统不区分大小写，所以只需要匹配一次
        image_files_set.update(input_path.glob(f'*{ext}'))
        image_files_set.update(input_path.glob(f'*{ext.upper()}'))
    
    image_files = list(image_files_set)
    
    if len(image_files) == 0:
        raise ValueError(f"在目录 {input_dir} 中未找到图像文件")
    
    # 提取方位角并排序
    images_with_azimuth = []
    azimuth_to_files = {}  # 用于检测重复方位角
    
    for img_path in image_files:
        azimuth = extract_azimuth_from_filename(img_path.name)
        if azimuth is not None:
            # 检查是否有相同方位角的图像
            if azimuth in azimuth_to_files:
                print(f"⚠️  警告: 发现重复方位角 {azimuth}°: {Path(azimuth_to_files[azimuth]).name} 和 {img_path.name}")
                # 如果已存在，跳过重复的（保留第一个）
                continue
            azimuth_to_files[azimuth] = str(img_path)
            images_with_azimuth.append((str(img_path), azimuth))
        else:
            print(f"⚠️  警告: 无法从文件名提取方位角，跳过: {img_path.name}")
    
    # 按方位角排序
    images_with_azimuth.sort(key=lambda x: x[1])
    
    # 检查是否有重复的方位角
    azimuths = [azimuth for _, azimuth in images_with_azimuth]
    unique_azimuths = set(azimuths)
    if len(azimuths) != len(unique_azimuths):
        print(f"⚠️  警告: 发现 {len(azimuths) - len(unique_azimuths)} 个重复方位角")
        from collections import Counter
        azimuth_counts = Counter(azimuths)
        duplicates = {az: count for az, count in azimuth_counts.items() if count > 1}
        for az, count in duplicates.items():
            print(f"   方位角 {az}° 出现 {count} 次")
    
    print(f"✅ 找到 {len(image_files)} 个文件，成功处理 {len(images_with_azimuth)} 张图像")
    print(f"   方位角范围: {images_with_azimuth[0][1]}° - {images_with_azimuth[-1][1]}°")
    
    return images_with_azimuth


def resize_image_to_fit(img: Image.Image, target_size: Tuple[int, int], 
                        keep_aspect: bool = True) -> Image.Image:
    """
    调整图像大小以适应目标尺寸
    
    Args:
        img: PIL图像
        target_size: 目标尺寸 (width, height)
        keep_aspect: 是否保持宽高比
        
    Returns:
        调整后的图像
    """
    if keep_aspect:
        img.thumbnail(target_size, Image.Resampling.LANCZOS)
    else:
        img = img.resize(target_size, Image.Resampling.LANCZOS)
    return img


def create_grid_layout(images_with_azimuth: List[Tuple[str, int]], 
                      cols: int,
                      target_size: Optional[Tuple[int, int]] = None,
                      spacing: int = 0,
                      show_labels: bool = False,
                      label_font_size: int = 20) -> Image.Image:
    """
    创建网格布局的图像组合
    
    Args:
        images_with_azimuth: [(图像路径, 方位角), ...] 列表
        cols: 每行图像数量
        target_size: 每个图像的目标尺寸 (width, height)，None表示使用原始尺寸
        spacing: 图像之间的间距（像素）
        show_labels: 是否显示方位角标签
        label_font_size: 标签字体大小
        
    Returns:
        组合后的PIL图像
    """
    num_images = len(images_with_azimuth)
    rows = (num_images + cols - 1) // cols  # 向上取整
    
    # 加载第一张图像以确定尺寸
    first_img = Image.open(images_with_azimuth[0][0])
    if target_size is None:
        target_size = first_img.size
    
    # 调整目标尺寸（如果指定了标签，需要额外空间）
    label_height = label_font_size + 10 if show_labels else 0
    actual_target_size = (target_size[0], target_size[1] + label_height)
    
    # 计算画布大小（紧凑布局，无间距）
    canvas_width = cols * actual_target_size[0] + max(0, (cols - 1)) * spacing
    canvas_height = rows * actual_target_size[1] + max(0, (rows - 1)) * spacing
    
    # 创建画布（白色背景）
    canvas = Image.new('RGB', (canvas_width, canvas_height), color='white')
    
    # 尝试加载字体
    try:
        # Windows系统字体
        font = ImageFont.truetype("arial.ttf", label_font_size)
    except:
        try:
            # Linux系统字体
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", label_font_size)
        except:
            # 使用默认字体
            font = ImageFont.load_default()
            print("⚠️  警告: 无法加载系统字体，使用默认字体")
    
    # 绘制图像
    for idx, (img_path, azimuth) in enumerate(images_with_azimuth):
        row = idx // cols
        col = idx % cols
        
        # 计算位置（紧凑布局，无间距）
        x = col * actual_target_size[0] + col * spacing
        y = row * actual_target_size[1] + row * spacing
        
        # 加载并调整图像大小（填充整个单元格，不保持宽高比）
        img = Image.open(img_path)
        if show_labels:
            # 如果有标签，图像需要适应target_size
            img_resized = resize_image_to_fit(img, target_size, keep_aspect=True)
            img_x = x + (target_size[0] - img_resized.width) // 2
            img_y = y + (target_size[1] - img_resized.height) // 2
        else:
            # 无标签时，图像填充整个单元格
            img_resized = img.resize(target_size, Image.Resampling.LANCZOS)
            img_x = x
            img_y = y
        
        # 粘贴图像
        canvas.paste(img_resized, (img_x, img_y))
        
        # 绘制方位角标签
        if show_labels:
            draw = ImageDraw.Draw(canvas)
            label_text = f"{azimuth}°"
            
            # 计算标签位置（图像下方居中）
            label_x = x + target_size[0] // 2
            label_y = y + target_size[1] + 5
            
            # 获取文本尺寸
            bbox = draw.textbbox((0, 0), label_text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
            
            # 绘制文本（居中）
            draw.text(
                (label_x - text_width // 2, label_y),
                label_text,
                fill='black',
                font=font
            )
    
    return canvas


def save_as_pdf(canvas: Image.Image, output_path: str, dpi: int = 300):
    """
    将图像保存为PDF格式（适合论文）
    
    Args:
        canvas: PIL图像
        output_path: 输出路径
        dpi: 分辨率（每英寸点数）
    """
    # 转换为RGB模式（PDF需要）
    if canvas.mode != 'RGB':
        canvas = canvas.convert('RGB')
    
    # 保存为PDF
    canvas.save(output_path, 'PDF', resolution=dpi, quality=95)
    print(f"✅ PDF已保存: {output_path} (DPI: {dpi})")


def main():
    parser = argparse.ArgumentParser(
        description='生成SAR-GS渲染结果的论文展示图',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  # 基本用法（紧凑布局，无标签，无间距）
  python create_paper_figure.py
  
  # 指定输入目录和每行图像数
  python create_paper_figure.py --input_dir ./my_renders/train/renders --cols 6
  
  # 生成PDF格式（适合论文）
  python create_paper_figure.py --input_dir ./my_renders/train/renders --cols 6 --format pdf --output paper_figure.pdf
  
  # 如果需要显示方位角标签
  python create_paper_figure.py --input_dir ./my_renders/train/renders --cols 6 --show_labels
  
  # 如果需要图像之间有间距
  python create_paper_figure.py --input_dir ./my_renders/train/renders --cols 6 --spacing 10
        """
    )
    
    parser.add_argument('--input_dir', type=str, 
                       default='./my_renders/train/renders',
                       help='输入图像目录（默认: ./my_renders/train/renders）')
    parser.add_argument('--output', type=str, 
                       default='paper_figure.png',
                       help='输出文件路径（默认: paper_figure.png）')
    parser.add_argument('--cols', type=int, default=6,
                       help='每行图像数量（默认: 6）')
    parser.add_argument('--image_size', type=int, nargs=2, default=None,
                       metavar=('WIDTH', 'HEIGHT'),
                       help='每个图像的尺寸（宽 高），默认使用原始尺寸')
    parser.add_argument('--spacing', type=int, default=0,
                       help='图像之间的间距（像素，默认: 0，紧凑布局）')
    parser.add_argument('--format', type=str, choices=['png', 'pdf', 'jpg'], 
                       default='png',
                       help='输出格式（默认: png）')
    parser.add_argument('--show_labels', action='store_true',
                       help='显示方位角标签（默认不显示）')
    parser.add_argument('--label_font_size', type=int, default=20,
                       help='标签字体大小（默认: 20）')
    parser.add_argument('--dpi', type=int, default=300,
                       help='PDF输出分辨率（默认: 300）')
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("SAR-GS渲染结果论文展示图生成工具")
    print("=" * 80)
    print(f"输入目录: {args.input_dir}")
    print(f"输出文件: {args.output}")
    print(f"每行图像数: {args.cols}")
    print(f"输出格式: {args.format}")
    print("=" * 80 + "\n")
    
    # 加载并排序图像
    try:
        images_with_azimuth = load_and_sort_images(args.input_dir)
    except Exception as e:
        print(f"❌ 错误: {e}")
        return 1
    
    if len(images_with_azimuth) == 0:
        print("❌ 错误: 没有找到有效的图像文件")
        return 1
    
    # 确定图像尺寸
    target_size = None
    if args.image_size:
        target_size = tuple(args.image_size)
    else:
        # 使用第一张图像的尺寸
        first_img = Image.open(images_with_azimuth[0][0])
        target_size = first_img.size
        print(f"ℹ️  使用原始图像尺寸: {target_size[0]}×{target_size[1]}")
    
    # 创建网格布局
    print(f"\n正在创建网格布局...")
    print(f"   图像数量: {len(images_with_azimuth)}")
    print(f"   布局: {args.cols}列 × {(len(images_with_azimuth) + args.cols - 1) // args.cols}行")
    print(f"   图像尺寸: {target_size[0]}×{target_size[1]}")
    print(f"   间距: {args.spacing}像素")
    
    canvas = create_grid_layout(
        images_with_azimuth,
        cols=args.cols,
        target_size=target_size,
        spacing=args.spacing,
        show_labels=args.show_labels,
        label_font_size=args.label_font_size
    )
    
    # 保存结果
    output_path = Path(args.output)
    # 如果是相对路径，转换为绝对路径
    if not output_path.is_absolute():
        output_path = Path.cwd() / output_path
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if args.format == 'pdf':
        save_as_pdf(canvas, str(output_path), dpi=args.dpi)
    else:
        # 保存为PNG或JPG
        if args.format == 'jpg':
            canvas = canvas.convert('RGB')
        canvas.save(str(output_path), quality=95)
        print(f"✅ 图像已保存: {output_path}")
    
    print(f"\n✅ 完成！")
    print(f"   输出文件: {output_path.resolve()}")
    print(f"   完整路径: {output_path.absolute()}")
    print(f"   文件大小: {output_path.stat().st_size / 1024 / 1024:.2f} MB")
    
    return 0


if __name__ == "__main__":
    exit(main())
