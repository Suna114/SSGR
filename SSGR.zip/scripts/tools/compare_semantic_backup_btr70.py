#!/usr/bin/env python3
"""Compare BTR70 semantic stats: current code vs a backup snapshot."""
from __future__ import annotations

import argparse
import csv
import shutil
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
DATA_PREP = REPO / "scripts" / "data_prep"
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))
if str(DATA_PREP) not in sys.path:
    sys.path.insert(0, str(DATA_PREP))


def _run_preview(fe_src: Path, cfg_src: Path, out_dir: Path) -> list[dict]:
    out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        shutil.copy2(fe_src, tdp / "feature_extraction.py")
        shutil.copy2(cfg_src, tdp / "semantic_mask_config.py")
        # shadow helpers live in repo sar/
        sar_dst = tdp / "sar"
        sar_dst.mkdir(exist_ok=True)
        shutil.copy2(REPO / "sar" / "scattering_filter.py", sar_dst / "scattering_filter.py")
        shutil.copy2(cfg_src, sar_dst / "semantic_mask_config.py")

        sys.path.insert(0, str(tdp))
        sys.path.insert(0, str(sar_dst))
        for mod in ("feature_extraction", "sar.semantic_mask_config", "semantic_mask_config"):
            sys.modules.pop(mod, None)

        from feature_extraction import create_scattering_mask  # noqa: WPS433
        from sar.scattering_filter import load_sar_grayscale_like_convert  # noqa: WPS433
        from sar.semantic_mask_config import (  # noqa: WPS433
            compute_scattering_threshold,
            semantic_mask_kwargs_from_args,
        )
        import argparse as ap

        args = ap.Namespace(**__import__("sar.semantic_mask_config", fromlist=["SEMANTIC_MASK_DEFAULTS"]).SEMANTIC_MASK_DEFAULTS)
        kw = semantic_mask_kwargs_from_args(args)
        rows = []
        img_dir = REPO / "data" / "BTR70" / "input"
        for img in sorted(img_dir.glob("*.jpg")):
            image = load_sar_grayscale_like_convert(str(img))
            if image.ndim != 2:
                image = image.mean(axis=2)
            tt, bt = compute_scattering_threshold(image, verbose=False)
            mask = create_scattering_mask(
                image,
                tt,
                bt,
                output_dir=str(out_dir),
                img_name=img.name,
                shadow_threshold_factor=kw["shadow_threshold_factor"],
                target_mask_dilate_px=kw["target_mask_dilate_px"],
                merge_target_edge_into_interior=kw["merge_scattering_target_edge"],
                target_mask_largest_component_only=kw["target_mask_largest_component_only"],
                target_mask_min_component_area_px=kw["target_mask_min_component_area_px"],
                target_semantic_largest_component_only=kw["target_semantic_largest_component_only"],
                target_semantic_keep_dilate_px=kw["target_semantic_keep_dilate_px"],
                shadow_percentile=kw["shadow_percentile"],
                shadow_target_geometry_filter=kw["shadow_target_geometry_filter"],
                shadow_min_area_fraction=kw["shadow_min_area_fraction"],
                shadow_min_target_area_fraction=kw["shadow_min_target_area_fraction"],
                shadow_y_margin_fraction=kw["shadow_y_margin_fraction"],
                shadow_require_background_mask=kw["shadow_require_background_mask"],
                shadow_target_dilate_px=kw["shadow_target_dilate_px"],
                shadow_bridge_along_azimuth=kw.get("shadow_bridge_along_azimuth", False),
                shadow_bridge_length_px=kw.get("shadow_bridge_length_px", 13),
                shadow_bridge_width_px=kw.get("shadow_bridge_width_px", 5),
                target_center_roi_fraction=kw["target_center_roi_fraction"],
                target_center_roi_min_keep_fraction=kw["target_center_roi_min_keep_fraction"],
                shadow_use_azimuth_prior=kw.get("shadow_use_azimuth_prior", True),
                shadow_direction_offset_deg=kw.get("shadow_direction_offset_deg", 180.0),
                shadow_azimuth_tolerance_deg=kw.get("shadow_azimuth_tolerance_deg", 70.0),
                shadow_azimuth_direction_weight=kw.get("shadow_azimuth_direction_weight", 0.28),
            )
            import numpy as np

            total = mask.size
            tgt = int(np.sum((mask == 1) | (mask == 2)))
            sh = int(np.sum(mask == 3))
            rows.append(
                {
                    "image": img.name,
                    "target_total_percent": 100.0 * tgt / total,
                    "shadow_percent": 100.0 * sh / total,
                }
            )
        return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--backup-fe", type=Path, required=True)
    parser.add_argument("--backup-cfg", type=Path, required=True)
    parser.add_argument("--label", default="backup")
    args = parser.parse_args()

    cur_fe = REPO / "scripts" / "data_prep" / "feature_extraction.py"
    cur_cfg = REPO / "sar" / "semantic_mask_config.py"
    out = REPO / "output" / "semantic_compare_btr70"
    cur_rows = _run_preview(cur_fe, cur_cfg, out / "current")
    bak_rows = _run_preview(args.backup_fe, args.backup_cfg, out / args.label)

    by_img = {r["image"]: r for r in cur_rows}
    diffs = []
    for br in bak_rows:
        cr = by_img[br["image"]]
        dt = br["target_total_percent"] - cr["target_total_percent"]
        ds = br["shadow_percent"] - cr["shadow_percent"]
        if abs(dt) > 0.25 or abs(ds) > 0.25:
            diffs.append((br["image"], dt, ds, cr["target_total_percent"], br["target_total_percent"], cr["shadow_percent"], br["shadow_percent"]))

    print(f"Compared {len(bak_rows)} images: CURRENT vs {args.label}")
    print(f"Large diffs (|dt|>0.25 or |ds|>0.25): {len(diffs)}")
    for item in sorted(diffs, key=lambda x: -abs(x[1]))[:20]:
        print(
            f"  {item[0]}: target {item[3]:.2f}% -> {item[4]:.2f}% (delta {item[1]:+.2f}); "
            f"shadow {item[5]:.2f}% -> {item[6]:.2f}% (delta {item[2]:+.2f})"
        )
    summary_path = out / f"compare_{args.label}.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["image", "cur_target_pct", "bak_target_pct", "cur_shadow_pct", "bak_shadow_pct"])
        for br in bak_rows:
            cr = by_img[br["image"]]
            w.writerow([br["image"], cr["target_total_percent"], br["target_total_percent"], cr["shadow_percent"], br["shadow_percent"]])
    print("Wrote", summary_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
