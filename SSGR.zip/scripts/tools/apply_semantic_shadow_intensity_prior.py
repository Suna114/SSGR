#!/usr/bin/env python3
"""Apply a learned-from-GT semantic shadow intensity prior.

This is a lightweight postprocess for testing the idea that shape and strength
should be separated: semantic/refiner maps provide the shadow region, while real
training images provide a per-azimuth attenuation field.
"""

from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

import numpy as np
from PIL import Image


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}


def _image_files(path: Path) -> list[Path]:
    return sorted(p for p in path.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS)


def _parse_azimuth(path: Path) -> float:
    text = path.stem
    matches = re.findall(r"(?<!\d)(\d{1,3})(?!\d)", text)
    if not matches:
        return 0.0
    return float(matches[-1]) % 360.0


def _angle_diff(a: float, b: float) -> float:
    return abs((float(a) - float(b) + 180.0) % 360.0 - 180.0)


def _load_gray(path: Path, size: tuple[int, int] | None = None) -> np.ndarray:
    img = Image.open(path).convert("L")
    if size is not None and img.size != size:
        img = img.resize(size, Image.BILINEAR)
    return np.asarray(img, dtype=np.float32) / 255.0


def _load_rgb(path: Path) -> tuple[np.ndarray, tuple[int, int]]:
    img = Image.open(path).convert("RGB")
    return np.asarray(img, dtype=np.float32) / 255.0, img.size


def _resize_mask(mask: np.ndarray, size: tuple[int, int]) -> np.ndarray:
    img = Image.fromarray((mask.astype(np.float32).clip(0.0, 1.0) * 255.0 + 0.5).astype(np.uint8))
    if img.size != size:
        img = img.resize(size, Image.NEAREST)
    return np.asarray(img, dtype=np.float32) / 255.0


def _mask_run_dir(root: Path, run_id: str) -> Path:
    if list(root.glob("*_mask.npy")):
        return root
    if (root / "scattering_masks" / "from_convert").is_dir():
        return _mask_run_dir(root / "scattering_masks" / "from_convert", run_id)
    if (root / "from_convert").is_dir():
        return _mask_run_dir(root / "from_convert", run_id)
    if run_id.lower() not in {"", "latest", "none"}:
        candidate = root / run_id
        if candidate.is_dir() and list(candidate.glob("*_mask.npy")):
            return candidate
    latest = root / "latest.json"
    if latest.is_file():
        meta = json.loads(latest.read_text(encoding="utf-8-sig"))
        candidate = root / str(meta.get("run_id", ""))
        if candidate.is_dir() and list(candidate.glob("*_mask.npy")):
            return candidate
    runs = [p for p in sorted(root.iterdir()) if p.is_dir() and list(p.glob("*_mask.npy"))]
    if not runs:
        raise FileNotFoundError(f"No *_mask.npy semantic masks under {root}")
    return runs[-1]


def _semantic_items(mask_root: Path, image_dir: Path, run_id: str) -> list[dict]:
    mask_dir = _mask_run_dir(mask_root, run_id)
    image_by_stem = {p.stem: p for p in _image_files(image_dir)}
    items: list[dict] = []
    for mask_path in sorted(mask_dir.glob("*_mask.npy")):
        stem = mask_path.stem
        if stem.endswith("_mask"):
            stem = stem[: -len("_mask")]
        image = image_by_stem.get(stem)
        if image is None:
            # Fall back to nearest azimuth if names are not exact.
            az = _parse_azimuth(Path(stem))
            images = list(image_by_stem.values())
            image = min(images, key=lambda p: _angle_diff(_parse_azimuth(p), az)) if images else None
        if image is None:
            continue
        items.append({"mask": mask_path, "image": image, "azimuth": _parse_azimuth(Path(stem))})
    return sorted(items, key=lambda x: (float(x["azimuth"]), str(x["mask"])))


def _bracket(items: list[dict], azimuth: float) -> tuple[dict, dict, float, float]:
    if not items:
        raise ValueError("No semantic items")
    az = float(azimuth) % 360.0
    vals = [(float(item["azimuth"]) % 360.0, item) for item in items]
    vals.sort(key=lambda x: x[0])
    prev = vals[-1]
    nxt = vals[0]
    for cur in vals:
        if cur[0] <= az:
            prev = cur
        if cur[0] >= az:
            nxt = cur
            break
    if prev[1] is nxt[1]:
        return prev[1], nxt[1], 1.0, 0.0
    span = (nxt[0] - prev[0]) % 360.0
    pos = (az - prev[0]) % 360.0
    if span <= 1e-6:
        return prev[1], nxt[1], 1.0, 0.0
    whi = min(max(pos / span, 0.0), 1.0)
    return prev[1], nxt[1], 1.0 - whi, whi


def _box_blur(arr: np.ndarray, radius: int) -> np.ndarray:
    if radius <= 0:
        return arr.astype(np.float32)
    try:
        from scipy import ndimage

        size = radius * 2 + 1
        return ndimage.uniform_filter(arr.astype(np.float32), size=size, mode="reflect")
    except Exception:
        pad = radius
        padded = np.pad(arr.astype(np.float32), pad, mode="reflect")
        out = np.zeros_like(arr, dtype=np.float32)
        area = float((radius * 2 + 1) ** 2)
        for dy in range(radius * 2 + 1):
            for dx in range(radius * 2 + 1):
                out += padded[dy : dy + arr.shape[0], dx : dx + arr.shape[1]]
        return out / area


def _dilate(mask: np.ndarray, radius: int) -> np.ndarray:
    if radius <= 0:
        return mask.astype(bool)
    try:
        from scipy import ndimage

        return ndimage.binary_dilation(mask.astype(bool), iterations=radius)
    except Exception:
        out = mask.astype(bool)
        for _ in range(radius):
            padded = np.pad(out, 1, mode="edge")
            nxt = np.zeros_like(out, dtype=bool)
            for dy in range(3):
                for dx in range(3):
                    nxt |= padded[dy : dy + out.shape[0], dx : dx + out.shape[1]]
            out = nxt
        return out


def _attenuation_for_item(
    item: dict,
    size: tuple[int, int],
    *,
    target_labels: tuple[int, ...],
    shadow_label: int,
    context_radius: int,
    block_radius: int,
    exclude_dilate: int,
    min_context: float,
) -> np.ndarray:
    gray = _load_gray(Path(item["image"]), size=size)
    labels = np.load(item["mask"])
    if labels.shape[::-1] != size:
        labels_img = Image.fromarray(labels.astype(np.int32), mode="I")
        labels = np.asarray(labels_img.resize(size, Image.NEAREST), dtype=np.int32)
    target = np.isin(labels, target_labels)
    shadow = labels == int(shadow_label)
    exclude = _dilate(target | shadow, exclude_dilate)
    valid_bg = (~exclude).astype(np.float32)
    bg_values = gray * valid_bg
    num = _box_blur(bg_values, context_radius)
    den = _box_blur(valid_bg, context_radius)
    global_bg = float(gray[valid_bg > 0.5].mean()) if np.any(valid_bg > 0.5) else float(gray.mean())
    context = np.where(den > 1e-4, num / np.maximum(den, 1e-4), global_bg)
    context = np.maximum(context, float(min_context))
    attenuation = ((context - gray) / context).clip(0.0, 1.0)
    attenuation *= shadow.astype(np.float32)
    if block_radius > 0:
        shadow_f = shadow.astype(np.float32)
        num = _box_blur(attenuation, block_radius)
        den = _box_blur(shadow_f, block_radius)
        block = np.where(den > 1e-4, num / np.maximum(den, 1e-4), attenuation)
        attenuation = (0.35 * attenuation + 0.65 * block).clip(0.0, 1.0) * shadow_f
    return attenuation.astype(np.float32)


def _parse_labels(raw: str) -> tuple[int, ...]:
    labels = []
    for part in str(raw).split(","):
        part = part.strip()
        if part:
            labels.append(int(part))
    return tuple(labels)


def main() -> int:
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--background_dir", required=True)
    parser.add_argument("--region_map_dir", required=True)
    parser.add_argument("--gt_dir", required=True)
    parser.add_argument("--semantic_mask_dir", required=True)
    parser.add_argument("--semantic_mask_run", default="latest")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--target_labels", default="1,2")
    parser.add_argument("--shadow_label", type=int, default=3)
    parser.add_argument("--context_radius", type=int, default=10)
    parser.add_argument("--block_radius", type=int, default=5)
    parser.add_argument("--exclude_dilate", type=int, default=2)
    parser.add_argument("--strength", type=float, default=1.25)
    parser.add_argument("--min_attenuation", type=float, default=0.35)
    parser.add_argument("--max_attenuation", type=float, default=0.92)
    parser.add_argument("--gamma", type=float, default=0.75)
    parser.add_argument("--min_context", type=float, default=0.02)
    parser.add_argument("--use_apply_alpha", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--hard_region", action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args()

    bg_dir = Path(args.background_dir)
    region_dir = Path(args.region_map_dir)
    out_root = Path(args.output_dir)
    render_out = out_root / "renders"
    map_out = out_root / "maps"
    render_out.mkdir(parents=True, exist_ok=True)
    map_out.mkdir(parents=True, exist_ok=True)

    items = _semantic_items(Path(args.semantic_mask_dir), Path(args.gt_dir), str(args.semantic_mask_run))
    if not items:
        raise RuntimeError("No semantic GT items found")
    target_labels = _parse_labels(args.target_labels)

    stats = []
    for bg_path in _image_files(bg_dir):
        stem = bg_path.stem
        bg, size = _load_rgb(bg_path)
        lo, hi, wlo, whi = _bracket(items, _parse_azimuth(bg_path))
        att_lo = _attenuation_for_item(
            lo,
            size,
            target_labels=target_labels,
            shadow_label=int(args.shadow_label),
            context_radius=max(int(args.context_radius), 1),
            block_radius=max(int(args.block_radius), 0),
            exclude_dilate=max(int(args.exclude_dilate), 0),
            min_context=float(args.min_context),
        )
        att = att_lo * float(wlo)
        if Path(hi["mask"]) != Path(lo["mask"]) and float(whi) > 0.0:
            att += _attenuation_for_item(
                hi,
                size,
                target_labels=target_labels,
                shadow_label=int(args.shadow_label),
                context_radius=max(int(args.context_radius), 1),
                block_radius=max(int(args.block_radius), 0),
                exclude_dilate=max(int(args.exclude_dilate), 0),
                min_context=float(args.min_context),
            ) * float(whi)
        region_path = region_dir / f"{stem}_final_shadow_mask.png"
        apply_path = region_dir / f"{stem}_shadow_apply_alpha.png"
        if not region_path.exists():
            continue
        region = _load_gray(region_path, size=size)
        apply_alpha = _load_gray(apply_path, size=size) if bool(args.use_apply_alpha) and apply_path.exists() else region
        if bool(args.hard_region):
            region_gate = (region > 0.05).astype(np.float32)
            alpha = apply_alpha.clip(0.0, 1.0) * region_gate
        else:
            alpha = np.minimum(region.clip(0.0, 1.0), apply_alpha.clip(0.0, 1.0))
        attenuation = np.maximum(att, float(args.min_attenuation) * (att > 0.001).astype(np.float32))
        attenuation = np.where(att > 0.001, attenuation, float(args.min_attenuation))
        attenuation = np.power(attenuation.clip(0.0, 1.0), max(float(args.gamma), 0.05))
        attenuation = np.clip(attenuation * float(args.strength), 0.0, float(args.max_attenuation))
        amount = (alpha * attenuation).clip(0.0, float(args.max_attenuation))
        out = bg * (1.0 - amount[..., None])
        out = np.where(alpha[..., None] > 0.0, out, bg).clip(0.0, 1.0)

        Image.fromarray((out * 255.0 + 0.5).astype(np.uint8)).save(render_out / bg_path.name)
        Image.fromarray((attenuation * 255.0 + 0.5).astype(np.uint8)).save(map_out / f"{stem}_learned_shadow_attenuation.png")
        Image.fromarray((amount * 255.0 + 0.5).astype(np.uint8)).save(map_out / f"{stem}_learned_shadow_amount.png")

        mask = alpha > 0.05
        diff = out.mean(axis=2) - bg.mean(axis=2)
        stats.append(
            {
                "stem": stem,
                "mask_pixels": int(mask.sum()),
                "bg_inside_mean": float(bg.mean(axis=2)[mask].mean()) if np.any(mask) else 0.0,
                "out_inside_mean": float(out.mean(axis=2)[mask].mean()) if np.any(mask) else 0.0,
                "mean_delta": float(diff[mask].mean()) if np.any(mask) else 0.0,
                "outside_changed": int((np.abs(diff[~mask]) > 0.01).sum()) if np.any(~mask) else 0,
            }
        )

    (out_root / "summary.json").write_text(json.dumps({"args": vars(args), "items": stats}, indent=2), encoding="utf-8")
    print(f"[done] wrote {len(stats)} renders -> {render_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
