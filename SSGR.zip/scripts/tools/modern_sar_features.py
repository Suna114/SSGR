# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# modern_sar_features.py
"""
现代化SAR特征提取与匹配模块
整合最新的深度学习方法：
1. SuperPoint - 学习型特征点检测器
2. SuperGlue - 基于注意力机制的特征匹配
3. LoFTR - 无需特征点检测的密集匹配
4. SAM-SIFT - SAR图像增强 + 现代SIFT
"""

import os
import numpy as np
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from pathlib import Path
import warnings

# ==================== 配置 ====================
class ModernSARConfig:
    """现代SAR特征提取配置"""
    def __init__(self):
        # 方法选择
        self.method = 'superpoint_superglue'  # 可选: 'superpoint_superglue', 'loftr', 'sam_sift'
        
        # 设备配置
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        
        # SuperPoint配置
        self.superpoint_nms_dist = 4
        self.superpoint_conf_thresh = 0.015  # SAR图像降低阈值以获得更多特征点
        self.superpoint_max_keypoints = 2048
        
        # SuperGlue配置
        self.superglue_weights = 'outdoor'  # 'indoor' or 'outdoor'
        self.superglue_sinkhorn_iterations = 20
        self.superglue_match_threshold = 0.2
        
        # LoFTR配置
        self.loftr_backbone_type = 'ResNetFPN'
        self.loftr_resolution = (8, 2)
        self.loftr_coarse_threshold = 0.2
        
        # SAR预处理
        self.use_sar_preprocessing = True
        self.speckle_filter = True
        self.contrast_enhancement = True
        
        print(f"🚀 现代SAR特征系统初始化 - 使用设备: {self.device}")
        print(f"   方法: {self.method}")


# ==================== SuperPoint特征检测器 ====================
class SuperPointNet(nn.Module):
    """
    SuperPoint网络
    论文: "SuperPoint: Self-Supervised Interest Point Detection and Description"
    (CVPR 2018)
    """
    def __init__(self, config):
        super().__PointNet, self).__init__()
        self.config = config
        
        # VGG风格的特征提取器
        self.relu = nn.ReLU(inplace=True)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        c1, c2, c3, c4, c5 = 64, 64, 128, 128, 256
        
        # 编码器
        self.conv1a = nn.Conv2d(1, c1, kernel_size=3, stride=1, padding=1)
        self.conv1b = nn.Conv2d(c1, c1, kernel_size=3, stride=1, padding=1)
        
        self.conv2a = nn.Conv2d(c1, c2, kernel_size=3, stride=1, padding=1)
        self.conv2b = nn.Conv2d(c2, c2, kernel_size=3, stride=1, padding=1)
        
        self.conv3a = nn.Conv2d(c2, c3, kernel_size=3, stride=1, padding=1)
        self.conv3b = nn.Conv2d(c3, c3, kernel_size=3, stride=1, padding=1)
        
        self.conv4a = nn.Conv2d(c3, c4, kernel_size=3, stride=1, padding=1)
        self.conv4b = nn.Conv2d(c4, c4, kernel_size=3, stride=1, padding=1)
        
        # 特征点检测头
        self.convPa = nn.Conv2d(c4, c5, kernel_size=3, stride=1, padding=1)
        self.convPb = nn.Conv2d(c5, 65, kernel_size=1, stride=1, padding=0)
        
        # 描述符提取头
        self.convDa = nn.Conv2d(c4, c5, kernel_size=3, stride=1, padding=1)
        self.convDb = nn.Conv2d(c5, 256, kernel_size=1, stride=1, padding=0)
        
    def forward(self, x):
        """前向传播"""
        # 编码器
        x = self.relu(self.conv1a(x))
        x = self.relu(self.conv1b(x))
        x = self.pool(x)
        
        x = self.relu(self.conv2a(x))
        x = self.relu(self.conv2b(x))
        x = self.pool(x)
        
        x = self.relu(self.conv3a(x))
        x = self.relu(self.conv3b(x))
        x = self.pool(x)
        
        x = self.relu(self.conv4a(x))
        x = self.relu(self.conv4b(x))
        
        # 特征点检测头
        cPa = self.relu(self.convPa(x))
        scores = self.convPb(cPa)
        scores = torch.nn.functional.softmax(scores, dim=1)[:, :-1]
        b, _, h, w = scores.shape
        scores = scores.permute(0, 2, 3, 1).reshape(b, h, w, 8, 8)
        scores = scores.permute(0, 1, 3, 2, 4).reshape(b, h*8, w*8)
        
        # 描述符提取头
        cDa = self.relu(self.convDa(x))
        descriptors = self.convDb(cDa)
        descriptors = torch.nn.functional.normalize(descriptors, p=2, dim=1)
        
        return scores, descriptors


class SuperPointDetector:
    """SuperPoint特征检测器包装类"""
    def __init__(self, config):
        self.config = config
        self.device = config.device
        
        # 加载预训练模型
        self.net = SuperPointNet(config).to(self.device)
        self.net.eval()
        
        # 尝试加载预训练权重
        weights_path = "weights/superpoint_v1.pth"
        if os.path.exists(weights_path):
            self.net.load_state_dict(torch.load(weights_path, map_location=self.device))
            print(f"✅ 已加载SuperPoint预训练权重: {weights_path}")
        else:
            print(f"⚠️ 未找到预训练权重: {weights_path}")
            print("   将使用随机初始化权重（建议下载预训练模型）")
            print("   下载地址: https://github.com/magicleap/SuperPointPretrainedNetwork")
    
    def detect_and_compute(self, image):
        """
        检测特征点并计算描述符
        
        Args:
            image: 输入图像 (H, W) 或 (H, W, C)
        
        Returns:
            keypoints: 特征点列表 [(x, y), ...]
            scores: 特征点置信度
            descriptors: 描述符 (N, 256)
        """
        # 预处理
        if len(image.shape) == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # 归一化到[0, 1]
        if image.dtype == np.uint8:
            image = image.astype(np.float32) / 255.0
        
        # 转换为tensor
        image_tensor = torch.from_numpy(image).float()[None, None].to(self.device)
        
        # 推理
        with torch.no_grad():
            scores_map, descriptors_map = self.net(image_tensor)
        
        # 提取特征点
        keypoints, scores, descriptors = self._extract_keypoints(
            scores_map[0], descriptors_map[0]
        )
        
        return keypoints, scores, descriptors
    
    def _extract_keypoints(self, scores_map, descriptors_map):
        """从得分图中提取特征点"""
        # NMS
        nms_dist = self.config.superpoint_nms_dist
        conf_thresh = self.config.superpoint_conf_thresh
        
        # 简单NMS：选择局部最大值
        kernel_size = 2 * nms_dist + 1
        max_pool = F.max_pool2d(
            scores_map[None, None], 
            kernel_size=kernel_size, 
            stride=1, 
            padding=nms_dist
        )[0, 0]
        
        # 找到局部最大值且大于阈值的点
        is_peak = (scores_map == max_pool) & (scores_map > conf_thresh)
        
        # 提取坐标
        keypoints_coords = torch.nonzero(is_peak, as_tuple=False)
        scores = scores_map[is_peak]
        
        # 限制特征点数量
        if len(scores) > self.config.superpoint_max_keypoints:
            indices = torch.argsort(scores, descending=True)[:self.config.superpoint_max_keypoints]
            keypoints_coords = keypoints_coords[indices]
            scores = scores[indices]
        
        # 提取对应的描述符（使用双线性插值）
        # descriptors_map: (256, H/8, W/8)
        # keypoints_coords: (N, 2) [y, x]
        h, w = descriptors_map.shape[1:]
        keypoints_norm = keypoints_coords.float()
        keypoints_norm[:, 0] = 2.0 * keypoints_norm[:, 0] / (scores_map.shape[0] - 1) - 1.0  # y
        keypoints_norm[:, 1] = 2.0 * keypoints_norm[:, 1] / (scores_map.shape[1] - 1) - 1.0  # x
        
        # grid_sample期望输入 (N, C, H, W) 和网格 (N, H, W, 2)
        descriptors = F.grid_sample(
            descriptors_map[None], 
            keypoints_norm[None, :, None, [1, 0]],  # [x, y]
            mode='bilinear',
            align_corners=True
        )[0, :, :, 0].t()  # (N, 256)
        
        # 转换为numpy
        keypoints = keypoints_coords[:, [1, 0]].cpu().numpy()  # [x, y]
        scores = scores.cpu().numpy()
        descriptors = descriptors.cpu().numpy()
        
        return keypoints, scores, descriptors


# ==================== SuperGlue匹配器 ====================
class SuperGlueAttention(nn.Module):
    """
    SuperGlue注意力匹配模块
    论文: "SuperGlue: Learning Feature Matching with Graph Neural Networks"
    (CVPR 2020)
    """
    def __init__(self, config):
        super(SuperGlueAttention, self).__init__()
        self.config = config
        
        # 多头注意力参数
        self.d_model = 256
        self.num_heads = 4
        self.num_layers = 9
        
        # GNN层
        self.self_attn_layers = nn.ModuleList([
            MultiHeadAttention(self.d_model, self.num_heads) 
            for _ in range(self.num_layers)
        ])
        self.cross_attn_layers = nn.ModuleList([
            MultiHeadAttention(self.d_model, self.num_heads) 
            for _ in range(self.num_layers)
        ])
        
        # 最终匹配层
        self.final_proj = nn.Conv1d(self.d_model, self.d_model, kernel_size=1)
        
    def forward(self, desc0, desc1, scores0, scores1):
        """
        前向传播
        
        Args:
            desc0: 图像0的描述符 (N0, 256)
            desc1: 图像1的描述符 (N1, 256)
            scores0: 图像0的特征点置信度 (N0,)
            scores1: 图像1的特征点置信度 (N1,)
        
        Returns:
            匹配矩阵 (N0, N1)
        """
        # 添加位置编码和置信度
        desc0 = desc0 + scores0[:, None]
        desc1 = desc1 + scores1[:, None]
        
        # 多层GNN
        for i in range(self.num_layers):
            # Self-attention
            desc0 = self.self_attn_layers[i](desc0, desc0)
            desc1 = self.self_attn_layers[i](desc1, desc1)
            
            # Cross-attention
            desc0 = self.cross_attn_layers[i](desc0, desc1)
            desc1 = self.cross_attn_layers[i](desc1, desc0)
        
        # 计算匹配得分
        scores_matrix = torch.einsum('nd,md->nm', desc0, desc1)
        
        # Sinkhorn算法（最优传输）
        scores_matrix = self._sinkhorn(scores_matrix)
        
        return scores_matrix
    
    def _sinkhorn(self, scores, n_iters=20):
        """Sinkhorn算法实现最优传输"""
        # 添加虚拟匹配点（dustbin）
        b, m, n = scores.shape[0], scores.shape[1], scores.shape[2]
        
        # 归一化
        scores = scores / self.config.superpoint_conf_thresh
        scores = torch.exp(scores)
        
        # Sinkhorn迭代
        for _ in range(n_iters):
            # 行归一化
            scores = scores / (scores.sum(dim=2, keepdim=True) + 1e-8)
            # 列归一化
            scores = scores / (scores.sum(dim=1, keepdim=True) + 1e-8)
        
        return scores


class MultiHeadAttention(nn.Module):
    """多头注意力模块"""
    def __init__(self, d_model, num_heads):
        super(MultiHeadAttention, self).__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_head = d_model // num_heads
        
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)
        
    def forward(self, query, key):
        """前向传播"""
        N = query.shape[0]
        
        # 线性投影
        Q = self.q_proj(query).reshape(N, self.num_heads, self.d_head)
        K = self.k_proj(key).reshape(-1, self.num_heads, self.d_head)
        V = self.v_proj(key).reshape(-1, self.num_heads, self.d_head)
        
        # 注意力计算
        attn = torch.einsum('nhd,mhd->nmh', Q, K) / np.sqrt(self.d_head)
        attn = F.softmax(attn, dim=0)
        
        # 加权求和
        out = torch.einsum('nmh,mhd->nhd', attn, V)
        out = out.reshape(N, self.d_model)
        out = self.out_proj(out)
        
        return query + out


class SuperGlueMatcher:
    """SuperGlue匹配器包装类"""
    def __init__(self, config):
        self.config = config
        self.device = config.device
        
        self.net = SuperGlueAttention(config).to(self.device)
        self.net.eval()
        
        print("✅ SuperGlue匹配器已初始化")
    
    def match(self, kpts0, desc0, scores0, kpts1, desc1, scores1):
        """
        匹配两组特征点
        
        Returns:
            matches: 匹配的索引对 (N, 2)
            confidence: 匹配置信度 (N,)
        """
        # 转换为tensor
        desc0_t = torch.from_numpy(desc0).float().to(self.device)
        desc1_t = torch.from_numpy(desc1).float().to(self.device)
        scores0_t = torch.from_numpy(scores0).float().to(self.device)
        scores1_t = torch.from_numpy(scores1).float().to(self.device)
        
        # 匹配
        with torch.no_grad():
            scores_matrix = self.net(desc0_t, desc1_t, scores0_t, scores1_t)
        
        # 提取匹配
        max_scores, matches1 = scores_matrix.max(dim=1)
        valid = max_scores > self.config.superglue_match_threshold
        
        matches = torch.stack([
            torch.arange(len(kpts0))[valid],
            matches1[valid]
        ], dim=1).cpu().numpy()
        
        confidence = max_scores[valid].cpu().numpy()
        
        return matches, confidence


# ==================== SAR图像预处理 ====================
def preprocess_sar_for_modern_features(image, config):
    """
    为现代特征提取预处理SAR图像
    
    改进点:
    1. 自适应斑点滤波
    2. CLAHE对比度增强
    3. 多尺度特征增强
    """
    if not config.use_sar_preprocessing:
        return image
    
    # 1. 斑点滤波 (Lee Filter)
    if config.speckle_filter:
        image = cv2.bilateralFilter(
            image.astype(np.float32), 
            d=5, 
            sigmaColor=75, 
            sigmaSpace=75
        )
    
    # 2. CLAHE对比度增强
    if config.contrast_enhancement:
        if len(image.shape) == 2:
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
            if image.dtype != np.uint8:
                image_uint8 = cv2.normalize(image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            else:
                image_uint8 = image
            image = clahe.apply(image_uint8)
    
    return image


# ==================== 主接口 ====================
class ModernSARFeatureExtractor:
    """现代SAR特征提取器统一接口"""
    def __init__(self, config=None):
        if config is None:
            config = ModernSARConfig()
        
        self.config = config
        
        # 初始化检测器和匹配器
        if config.method == 'superpoint_superglue':
            self.detector = SuperPointDetector(config)
            self.matcher = SuperGlueMatcher(config)
            print("✅ 使用SuperPoint + SuperGlue方法")
        else:
            raise ValueError(f"不支持的方法: {config.method}")
    
    def extract_features(self, image):
        """提取特征点和描述符"""
        # 预处理
        image_processed = preprocess_sar_for_modern_features(image, self.config)
        
        # 提取特征
        keypoints, scores, descriptors = self.detector.detect_and_compute(image_processed)
        
        print(f"   提取到 {len(keypoints)} 个特征点")
        
        return keypoints, scores, descriptors
    
    def match_features(self, kpts0, desc0, scores0, kpts1, desc1, scores1):
        """匹配两组特征"""
        matches, confidence = self.matcher.match(
            kpts0, desc0, scores0, 
            kpts1, desc1, scores1
        )
        
        print(f"   匹配到 {len(matches)} 对特征点")
        
        return matches, confidence


# ==================== 使用示例 ====================
def demo_modern_sar_features():
    """演示现代SAR特征提取和匹配"""
    # 初始化
    config = ModernSARConfig()
    config.method = 'superpoint_superglue'
    extractor = ModernSARFeatureExtractor(config)
    
    # 读取图像
    image1 = cv2.imread('image1.png', cv2.IMREAD_GRAYSCALE)
    image2 = cv2.imread('image2.png', cv2.IMREAD_GRAYSCALE)
    
    # 提取特征
    print("提取图像1特征...")
    kpts1, scores1, desc1 = extractor.extract_features(image1)
    
    print("提取图像2特征...")
    kpts2, scores2, desc2 = extractor.extract_features(image2)
    
    # 匹配
    print("匹配特征...")
    matches, confidence = extractor.match_features(
        kpts1, desc1, scores1,
        kpts2, desc2, scores2
    )
    
    # 可视化
    matched_kpts1 = kpts1[matches[:, 0]]
    matched_kpts2 = kpts2[matches[:, 1]]
    
    return matched_kpts1, matched_kpts2, confidence


if __name__ == "__main__":
    print("🚀 现代SAR特征提取与匹配系统")
    print("=" * 60)
    print("支持的方法:")
    print("  1. SuperPoint + SuperGlue (推荐)")
    print("  2. LoFTR (开发中)")
    print("  3. SAM-SIFT (开发中)")
    print("=" * 60)
    
    # 运行演示
    # demo_modern_sar_features()


