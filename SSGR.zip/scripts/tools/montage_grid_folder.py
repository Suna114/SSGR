"""
将文件夹内图像按固定列×行拼成一张大图（从左到右、从上到下，行优先）。

示例:
  python scripts/tools/montage_grid_folder.py -i ./out/renders -o mosaic.png --cols 12 --rows 30 --gap 8

依赖: Pillow (pip install pillow)
"""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def _list_images(folder: Path) -> list[Path]:
    exts = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff"}
    paths = []
    for p in folder.iterdir():
        if p.is_file() and p.suffix.lower() in exts:
            paths.append(p)
    paths.sort(key=lambda x: x.name.lower())
    return paths


def _to_rgb_canvas(im: Image.Image, bgcolor: tuple[int, int, int]) -> Image.Image:
    if im.mode == "RGBA":
        bg = Image.new("RGB", im.size, bgcolor)
        bg.paste(im, mask=im.split()[3])
        return bg
    if im.mode != "RGB":
        return im.convert("RGB")
    return im


def _fit_thumbnail(
    im: Image.Image,
    max_side: int,
    bgcolor: tuple[int, int, int],
    cell_size: int | None = None,
) -> Image.Image:
    """必须在 Image.open 的 with 块内调用；返回独立像素副本，避免文件关闭后 paste 报 fp=None。"""
    im = _to_rgb_canvas(im, bgcolor)
    if cell_size is not None:
        return im.resize((cell_size, cell_size), Image.Resampling.LANCZOS).copy()

    w, h = im.size
    if max(w, h) <= max_side:
        out = im
    elif w >= h:
        nw = max_side
        nh = max(1, int(round(h * (max_side / w))))
        out = im.resize((nw, nh), Image.Resampling.LANCZOS)
    else:
        nh = max_side
        nw = max(1, int(round(w * (max_side / h))))
        out = im.resize((nw, nh), Image.Resampling.LANCZOS)
    return out.copy()


DEFAULT_LABEL_FONT = Path(r"C:\Windows\Fonts\timesbd.ttf")


def _load_font(size: int, font_path: Path | None = None) -> ImageFont.ImageFont:
    candidates = []
    if font_path is not None:
        candidates.append(font_path)
    candidates.extend(
        [
            DEFAULT_LABEL_FONT,
            Path(r"C:\Windows\Fonts\times.ttf"),
            Path(r"C:\Windows\Fonts\arialbd.ttf"),
            Path(r"C:\Windows\Fonts\arial.ttf"),
        ]
    )
    for path in candidates:
        if path.is_file():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def _parse_labels(value: str | None) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split(",")]


def _text_bbox(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont) -> tuple[int, int, int, int]:
    return draw.textbbox((0, 0), text, font=font, anchor="lt")


def _text_size(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont) -> tuple[int, int]:
    box = _text_bbox(draw, text, font)
    return box[2] - box[0], box[3] - box[1]


def _draw_text_centered(
    draw: ImageDraw.ImageDraw,
    center_x: float,
    center_y: float,
    text: str,
    font: ImageFont.ImageFont,
    fill: tuple[int, int, int],
    *,
    anchor: str = "mm",
) -> None:
    draw.text((center_x, center_y), text, font=font, fill=fill, anchor=anchor)


def _cell_center_x(col: int, left_pad: int, cw: int, stride_x: int) -> float:
    return left_pad + col * stride_x + cw / 2.0


def _cell_center_y(row: int, top_pad: int, ch: int, stride_y: int) -> float:
    return top_pad + row * stride_y + ch / 2.0


def _fit_label_font_size(
    labels: list[str],
    font_path: Path,
    max_text_height: int,
    max_text_width: int | None = None,
    start_size: int = 24,
) -> ImageFont.ImageFont:
    size = max(8, start_size)
    measure = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    while size > 8:
        font = _load_font(size, font_path)
        heights = [_text_size(measure, label, font)[1] for label in labels]
        if max(heights) <= max_text_height:
            if max_text_width is None:
                return font
            widths = [_text_size(measure, label, font)[0] for label in labels]
            if max(widths) <= max_text_width:
                return font
        size -= 1
    return _load_font(max(8, size), font_path)


def main() -> None:
    ap = argparse.ArgumentParser(description="文件夹图像 → cols×rows 拼图")
    ap.add_argument("-i", "--input", required=True, type=str, help="图像文件夹")
    ap.add_argument("-o", "--output", required=True, type=str, help="输出 PNG/JPEG 路径")
    ap.add_argument("--cols", type=int, default=12, help="列数（默认 12）")
    ap.add_argument("--rows", type=int, default=30, help="行数（默认 30）")
    ap.add_argument(
        "--max-side",
        type=int,
        default=512,
        help="每张图缩放时最长边上限（像素），保持宽高比后再统一格子（默认 512）",
    )
    ap.add_argument(
        "--cell-size",
        type=int,
        default=None,
        help="将每张图直接上/下采样到固定 cell-size×cell-size 后拼接；设置后覆盖 --max-side",
    )
    ap.add_argument(
        "--bgcolor",
        type=str,
        default="black",
        choices=("black", "white"),
        help="空白格及透明底填充色（默认 black）",
    )
    ap.add_argument(
        "--gap",
        type=int,
        default=0,
        help="相邻两格之间的水平/垂直间隔（像素，默认 0；用 --bgcolor 颜色填充缝隙）",
    )
    ap.add_argument(
        "--gap-x",
        type=int,
        default=None,
        help="相邻两格之间的水平间隔（像素）；未设置时使用 --gap",
    )
    ap.add_argument(
        "--gap-y",
        type=int,
        default=None,
        help="相邻两格之间的垂直间隔（像素）；未设置时使用 --gap",
    )
    ap.add_argument("--row-labels", type=str, default=None, help="逗号分隔的行标签")
    ap.add_argument("--col-labels", type=str, default=None, help="逗号分隔的列标签")
    ap.add_argument("--label-font-size", type=int, default=24, help="标签字号（默认 24）")
    ap.add_argument("--label-padding", type=int, default=12, help="标签与网格之间的距离（默认 12）")
    ap.add_argument(
        "--label-font",
        type=str,
        default=str(DEFAULT_LABEL_FONT),
        help="标签字体文件（默认 Times New Roman Bold）",
    )
    ap.add_argument(
        "--label-font-ratio",
        type=float,
        default=None,
        help="With --cell-size, cap label height to cell_size * ratio (e.g. 0.33).",
    )
    args = ap.parse_args()

    folder = Path(args.input).resolve()
    if not folder.is_dir():
        raise SystemExit(f"目录不存在: {folder}")

    bg = (0, 0, 0) if args.bgcolor == "black" else (255, 255, 255)
    paths = _list_images(folder)
    cols, rows = int(args.cols), int(args.rows)
    cap = cols * rows
    if len(paths) > cap:
        print(f"[提示] 共 {len(paths)} 张，仅使用前 {cap} 张（{cols}列×{rows}行）")
        paths = paths[:cap]

    if not paths:
        raise SystemExit(f"文件夹内无支持的图像: {folder}")

    gap = max(0, int(args.gap))
    gap_x = gap if args.gap_x is None else max(0, int(args.gap_x))
    gap_y = gap if args.gap_y is None else max(0, int(args.gap_y))
    cell_size = None if args.cell_size is None else int(args.cell_size)
    if cell_size is not None and cell_size <= 0:
        raise SystemExit(f"--cell-size 必须为正整数: {cell_size}")

    thumbs: list[Image.Image] = []
    for p in paths:
        with Image.open(p) as im:
            thumbs.append(_fit_thumbnail(im, args.max_side, bg, cell_size))

    cw = max(t.width for t in thumbs)
    ch = max(t.height for t in thumbs)
    for i, t in enumerate(thumbs):
        if t.size != (cw, ch):
            cell = Image.new("RGB", (cw, ch), bg)
            x = (cw - t.width) // 2
            y = (ch - t.height) // 2
            cell.paste(t, (x, y))
            thumbs[i] = cell

    stride_x = cw + gap_x
    stride_y = ch + gap_y
    out_w = cols * cw + max(0, cols - 1) * gap_x
    out_h = rows * ch + max(0, rows - 1) * gap_y
    row_labels = _parse_labels(args.row_labels)
    col_labels = _parse_labels(args.col_labels)
    if row_labels and len(row_labels) != rows:
        raise SystemExit(f"--row-labels 数量必须等于 rows={rows}: {len(row_labels)}")
    if col_labels and len(col_labels) != cols:
        raise SystemExit(f"--col-labels 数量必须等于 cols={cols}: {len(col_labels)}")

    font_path = Path(args.label_font)
    pad = max(0, int(args.label_padding))
    label_font_size = max(1, int(args.label_font_size))
    if args.label_font_ratio is not None:
        if cell_size is None:
            raise SystemExit("--label-font-ratio requires --cell-size")
        cap_h = max(8, int(round(cell_size * args.label_font_ratio)))
        all_labels = row_labels + col_labels
        font = _fit_label_font_size(all_labels, font_path, cap_h, start_size=label_font_size)
    else:
        font = _load_font(label_font_size, font_path)

    measure = Image.new("RGB", (1, 1), bg)
    draw_measure = ImageDraw.Draw(measure)
    left_pad = 0
    top_pad = 0
    if row_labels:
        left_pad = max(_text_size(draw_measure, label, font)[0] for label in row_labels) + pad
    if col_labels:
        top_pad = max(_text_size(draw_measure, label, font)[1] for label in col_labels) + pad

    mosaic = Image.new("RGB", (out_w + left_pad, out_h + top_pad), bg)
    filled = len(thumbs)
    for idx in range(cap):
        r, c = divmod(idx, cols)
        paste_x = left_pad + c * stride_x
        paste_y = top_pad + r * stride_y
        if idx < filled:
            mosaic.paste(thumbs[idx], (paste_x, paste_y))

    draw = ImageDraw.Draw(mosaic)
    label_color = (0, 0, 0) if args.bgcolor == "white" else (255, 255, 255)
    row_label_x = float(left_pad - pad)
    col_label_y = top_pad / 2.0
    for r, label in enumerate(row_labels):
        _draw_text_centered(
            draw,
            row_label_x,
            _cell_center_y(r, top_pad, ch, stride_y),
            label,
            font,
            label_color,
            anchor="rm",
        )
    for c, label in enumerate(col_labels):
        _draw_text_centered(
            draw,
            _cell_center_x(c, left_pad, cw, stride_x),
            col_label_y,
            label,
            font,
            label_color,
            anchor="mm",
        )

    outp = Path(args.output).resolve()
    outp.parent.mkdir(parents=True, exist_ok=True)
    mosaic.save(outp, quality=95)
    print(
        f"已写入: {outp}  ({mosaic.width}×{mosaic.height} 像素), 格子 {cw}×{ch}, 间隔 gap_x={gap_x}, gap_y={gap_y}, "
        f"填入 {filled}/{cap} 张"
    )


if __name__ == "__main__":
    main()
