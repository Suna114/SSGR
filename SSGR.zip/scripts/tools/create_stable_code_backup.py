#!/usr/bin/env python3
"""Create a timestamped code backup with STABLE_MARK and BACKUP_MANIFEST.json."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from datetime import datetime
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]

DEFAULT_FILES = [
    "scripts/data_prep/background_after_shadow_preview.py",
    "scripts/pipeline/sar_novel_view_refiner_pipeline.py",
    "scripts/pipeline/novel_view_agent.py",
    "scripts/pipeline/novel_view_agent_ui.py",
    "scripts/rendering/learn_sar_azimuth_shadow_refiner.py",
    "scripts/tools/rerun_final_shadow_bg_to_figure.py",
    "scripts/tools/shadow_refiner_standalone.py",
    "scripts/tools/create_stable_code_backup.py",
    "output/final/picture/extra/README_background_fusion_v12.txt",
]


def _md5(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True, help="Stable backup folder name (under code_backups/).")
    parser.add_argument("--title", required=True, help="Human-readable stable mark title.")
    parser.add_argument("--purpose", required=True, help="Short purpose paragraph for STABLE_MARK.")
    parser.add_argument("--verified", action="append", default=[], help="Verified output line (repeatable).")
    parser.add_argument("--note", action="append", default=[], help="Important note (repeatable).")
    parser.add_argument("--file", dest="files", action="append", default=[], help="Extra file to include (repeatable).")
    args = parser.parse_args()

    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S %z").strip()
    backup_root = REPO_ROOT / "code_backups" / args.name
    if backup_root.exists():
        raise SystemExit(f"Backup already exists: {backup_root}")

    rel_files = list(dict.fromkeys(DEFAULT_FILES + list(args.files)))
    manifest: list[dict[str, object]] = []
    copied: list[str] = []

    for rel in rel_files:
        src = REPO_ROOT / rel
        if not src.is_file():
            print(f"[skip] missing: {rel}")
            continue
        dst = backup_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        copied.append(rel)
        manifest.append({"path": rel.replace("/", "\\"), "size": src.stat().st_size, "md5": _md5(src)})

    mark_lines = [
        f"Stable mark: {args.title}",
        "=" * max(10, len(args.title) + 14),
        "",
        "Marked at",
        "---------",
        stamp,
        "",
        "Stable name",
        "-----------",
        args.name,
        "",
        "Purpose",
        "-------",
        args.purpose,
        "",
    ]
    if args.verified:
        mark_lines += ["Verified outputs", "----------------", *args.verified, ""]
    if copied:
        mark_lines += ["Main files covered by this mark", "-------------------------------"]
        mark_lines += [str(REPO_ROOT / rel) for rel in copied]
        mark_lines.append("")
    if args.note:
        mark_lines += ["Important notes", "---------------"]
        mark_lines += args.note
        mark_lines.append("")

    mark_name = f"STABLE_MARK_{args.name}.txt"
    (backup_root / mark_name).write_text("\n".join(mark_lines), encoding="utf-8")
    manifest.insert(0, {"path": mark_name, "size": (backup_root / mark_name).stat().st_size, "md5": _md5(backup_root / mark_name)})
    (backup_root / "BACKUP_MANIFEST.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    usage = backup_root / f"USAGE_{args.name}.txt"
    usage.write_text(
        "\n".join(
            [
                f"Usage: {args.title}",
                "=" * max(10, len(args.title)),
                "",
                f"Backup folder: {backup_root}",
                "",
                "Restore all backed-up scripts:",
                f"  python scripts/tools/restore_code_backup.py --name {args.name}",
                "",
                "Or copy files manually from:",
                f"  {backup_root}",
                "",
                "Shadow refiner isolated test:",
                "  python scripts/tools/shadow_refiner_standalone.py --dataset BTR70 --stage both",
                "",
            ]
        ),
        encoding="utf-8",
    )

    print(f"Created backup: {backup_root}")
    print(f"  files: {len(copied)}")
    print(f"  mark : {backup_root / mark_name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
