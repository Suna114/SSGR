#!/usr/bin/env python3
"""
将 PDF 转为纯文本（便于检索、给模型读、或存档）。

依赖：
    pip install pymupdf

用法：
    python scripts/tools/pdf_to_txt.py input.pdf
    python scripts/tools/pdf_to_txt.py input.pdf -o out.txt
    python scripts/tools/pdf_to_txt.py ./papers -o ./papers_txt   # 目录批量

说明：
    - 复杂排版、公式、扫描版 PDF 可能乱码或几乎无字，需 OCR（未内置）。
    - 默认用 UTF-8 写入。
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def _extract_with_pymupdf(pdf_path: Path) -> str:
    import fitz  # PyMuPDF

    doc = fitz.open(pdf_path)
    parts: list[str] = []
    for i in range(doc.page_count):
        page = doc.load_page(i)
        text = page.get_text("text") or ""
        parts.append(f"--- 第 {i + 1} 页 ---\n{text}\n")
    doc.close()
    return "\n".join(parts)


def convert_one(pdf_path: Path, out_path: Path | None) -> Path:
    if not pdf_path.is_file():
        raise FileNotFoundError(f"找不到文件: {pdf_path}")

    if out_path is None:
        out_path = pdf_path.with_suffix(".txt")
    else:
        out_path = Path(out_path)

    if out_path.is_dir() or str(out_path).endswith(("/", "\\")):
        out_path = out_path / f"{pdf_path.stem}.txt"

    text = _extract_with_pymupdf(pdf_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(text, encoding="utf-8", newline="\n")
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(description="PDF → UTF-8 文本（需 pymupdf）")
    parser.add_argument(
        "path",
        type=str,
        help="PDF 文件路径，或包含多个 .pdf 的目录",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default=None,
        help="输出 .txt 路径；若输入为目录则为输出目录（默认与 PDF 同目录同名 .txt）",
    )
    args = parser.parse_args()

    try:
        import fitz  # noqa: F401
    except ImportError:
        print(
            "未安装 pymupdf。请在当前环境执行：\n  pip install pymupdf",
            file=sys.stderr,
        )
        sys.exit(1)

    root = Path(args.path)
    if root.is_dir():
        pdfs = sorted(root.glob("*.pdf"))
        if not pdfs:
            print(f"目录内无 .pdf：{root}", file=sys.stderr)
            sys.exit(1)
        out_dir = Path(args.output) if args.output else root / "_txt_export"
        out_dir.mkdir(parents=True, exist_ok=True)
        for p in pdfs:
            target = out_dir / f"{p.stem}.txt"
            convert_one(p, target)
            print(target)
        return

    out = convert_one(root, Path(args.output) if args.output else None)
    print(out)


if __name__ == "__main__":
    main()
