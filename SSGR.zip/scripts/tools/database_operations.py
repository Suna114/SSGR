# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# database_operations.py
import os
import sqlite3
import numpy as np
import logging
import traceback
import cv2

def create_colmap_database_from_features(source_path, keypoints, descriptors, camera_model="OPENCV",
                                         feature_type="SAR_SIFT", args=None):
    """
    从OpenCV提取的特征创建COLMAP数据库 - 完全兼容COLMAP标准格式
    """
    print("创建COLMAP标准格式数据库...")

    # 确保distorted目录存在
    distorted_dir = os.path.join(source_path, "distorted")
    os.makedirs(distorted_dir, exist_ok=True)

    db_path = os.path.join(distorted_dir, "database.db")
    print(f"数据库路径: {db_path}")

    # 清理现有数据库
    if os.path.exists(db_path):
        try:
            os.remove(db_path)
            print("已删除现有数据库文件")
        except Exception as e:
            error_msg = f"删除现有数据库失败: {e}"
            logging.error(error_msg)
            logging.error(traceback.format_exc())
            print(f"❌ {error_msg}")

    # 连接数据库
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        print("数据库连接成功")
    except Exception as e:
        error_msg = f"数据库连接失败: {e}"
        logging.error(error_msg)
        logging.error(traceback.format_exc())
        print(f"❌ {error_msg}")
        return None, {}

    # 创建表 - 使用COLMAP标准表结构
    try:
        # 删除现有表（如果存在）
        cursor.execute("DROP TABLE IF EXISTS cameras")
        cursor.execute("DROP TABLE IF EXISTS images")
        cursor.execute("DROP TABLE IF EXISTS keypoints")
        cursor.execute("DROP TABLE IF EXISTS descriptors")
        cursor.execute("DROP TABLE IF EXISTS matches")
        cursor.execute("DROP TABLE IF EXISTS two_view_geometries")
        cursor.execute("DROP TABLE IF EXISTS inlier_matches")

        # 创建 cameras 表
        cursor.execute('''
                       CREATE TABLE cameras
                       (
                           camera_id          INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                           model              INTEGER NOT NULL,
                           width              INTEGER NOT NULL,
                           height             INTEGER NOT NULL,
                           params             BLOB,
                           prior_focal_length INTEGER NOT NULL
                       )
                       ''')

        # 创建 images 表
        cursor.execute('''
                       CREATE TABLE images
                       (
                           image_id  INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                           name      TEXT    NOT NULL UNIQUE,
                           camera_id INTEGER NOT NULL,
                           prior_qw  REAL,
                           prior_qx  REAL,
                           prior_qy  REAL,
                           prior_qz  REAL,
                           prior_tx  REAL,
                           prior_ty  REAL,
                           prior_tz  REAL,
                           CONSTRAINT images_id_key UNIQUE (image_id),
                           FOREIGN KEY (camera_id) REFERENCES cameras (camera_id)
                       )
                       ''')

        # 创建 keypoints 表
        cursor.execute('''
                       CREATE TABLE keypoints
                       (
                           image_id INTEGER NOT NULL,
                           rows     INTEGER NOT NULL,
                           cols     INTEGER NOT NULL,
                           data     BLOB,
                           FOREIGN KEY (image_id) REFERENCES images (image_id) ON DELETE CASCADE
                       )
                       ''')

        # 创建 descriptors 表
        cursor.execute('''
                       CREATE TABLE descriptors
                       (
                           image_id INTEGER NOT NULL,
                           rows     INTEGER NOT NULL,
                           cols     INTEGER NOT NULL,
                           data     BLOB,
                           FOREIGN KEY (image_id) REFERENCES images (image_id) ON DELETE CASCADE
                       )
                       ''')

        # 创建 matches 表 - 使用COLMAP标准格式
        cursor.execute('''
                       CREATE TABLE matches
                       (
                           pair_id INTEGER PRIMARY KEY NOT NULL,
                           rows    INTEGER             NOT NULL,
                           cols    INTEGER             NOT NULL,
                           data    BLOB
                       )
                       ''')

        # 创建 two_view_geometries 表
        cursor.execute('''
                       CREATE TABLE two_view_geometries
                       (
                           pair_id INTEGER PRIMARY KEY NOT NULL,
                           rows    INTEGER             NOT NULL,
                           cols    INTEGER             NOT NULL,
                           data    BLOB,
                           config  INTEGER             NOT NULL,
                           F       BLOB,
                           E       BLOB,
                           H       BLOB,
                           qvec    BLOB,
                           tvec    BLOB
                       )
                       ''')

        # 创建索引
        cursor.execute('CREATE INDEX IF NOT EXISTS keypoints_image_id_idx ON keypoints(image_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS descriptors_image_id_idx ON descriptors(image_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS matches_pair_id_idx ON matches(pair_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS two_view_geometries_pair_id_idx ON two_view_geometries(pair_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS images_name_idx ON images(name)')
        cursor.execute('CREATE INDEX IF NOT EXISTS images_camera_id_idx ON images(camera_id)')

        print("数据库表创建成功")

    except Exception as e:
        error_msg = f"创建数据库表失败: {e}"
        logging.error(error_msg)
        logging.error(traceback.format_exc())
        print(f"❌ {error_msg}")
        conn.close()
        return None, {}

    # 使用正确的相机模型ID
    camera_model_map = {
        "SIMPLE_PINHOLE": 0,  # f, cx, cy
        "PINHOLE": 1,  # fx, fy, cx, cy
        "SIMPLE_RADIAL": 2,  # f, cx, cy, k
        "RADIAL": 3,  # f, cx, cy, k1, k2
        "OPENCV": 4,  # fx, fy, cx, cy, k1, k2, p1, p2
        "FULL_OPENCV": 5,  # fx, fy, cx, cy, k1, k2, p1, p2, k3, k4, k5, k6
        "SIMPLE_RADIAL_FISHEYE": 6,  # f, cx, cy, k
        "RADIAL_FISHEYE": 7,  # f, cx, cy, k1, k2
        "OPENCV_FISHEYE": 8,  # fx, fy, cx, cy, k1, k2, k3, k4
        "FOV": 9,  # fx, fy, cx, cy, omega
        "THIN_PRISM_FISHEYE": 10  # fx, fy, cx, cy, k1, k2, p1, p2, k3, k4, sx1, sy1
    }

    # SAR图像参数
    # 获取第一张图像的实际尺寸
    image_files = [f for f in os.listdir(os.path.join(source_path, "input"))
                   if f.lower().endswith(('.jpg', '.jpeg', '.png', '.tif', '.tiff'))]

    if image_files:
        first_image_path = os.path.join(source_path, "input", image_files[0])
        first_image = cv2.imread(first_image_path, cv2.IMREAD_GRAYSCALE)
        if first_image is not None:
            original_height, original_width = first_image.shape
            print(f"使用实际图像尺寸: {original_width} x {original_height}")
        else:
            # 回退到默认尺寸
            original_width, original_height = 128, 128
            print(f"无法读取第一张图像，使用默认尺寸: {original_width} x {original_height}")
    else:
        # 回退到默认尺寸
        original_width, original_height = 128, 128
        print(f"未找到图像文件，使用默认尺寸: {original_width} x {original_height}")
    upscaled_width = int(original_width * args.image_scale)
    upscaled_height = int(original_height * args.image_scale)
    img_size=original_width/2
    # 使用SIMPLE_PINHOLE模型，参数: [f, cx, cy]
    focal_length = img_size * args.image_scale
    camera_params = np.array([
        focal_length,  # f
        upscaled_width / 2,  # cx
        upscaled_height / 2  # cy
    ], dtype=np.float64)

    model_id = camera_model_map.get("SIMPLE_PINHOLE", 0)

    try:
        cursor.execute(
            "INSERT INTO cameras (model, width, height, params, prior_focal_length) VALUES (?, ?, ?, ?, ?)",
            (model_id, upscaled_width, upscaled_height, camera_params.tobytes(), 1)
        )
        camera_id = cursor.lastrowid
        print(f"相机参数插入成功，相机ID: {camera_id}")
    except Exception as e:
        error_msg = f"插入相机参数失败: {e}"
        logging.error(error_msg)
        logging.error(traceback.format_exc())
        print(f"❌ {error_msg}")
        conn.close()
        return None, {}

    # 添加图像和特征点
    image_ids = {}
    successful_images = 0

    for img_name in keypoints.keys():
        try:
            # 添加图像
            cursor.execute(
                "INSERT INTO images (name, camera_id) VALUES (?, ?)",
                (img_name, camera_id)
            )
            image_id = cursor.lastrowid
            image_ids[img_name] = image_id

            # 添加关键点 - 确保格式正确
            kp_data = keypoints[img_name]
            rows, cols = kp_data.shape

            # COLMAP期望的关键点格式: [x, y, scale, orientation, ...]
            # 确保数据是float32类型
            kp_data = kp_data.astype(np.float32)

            cursor.execute(
                "INSERT INTO keypoints (image_id, rows, cols, data) VALUES (?, ?, ?, ?)",
                (image_id, rows, cols, kp_data.tobytes())
            )

            # 添加描述符
            desc_data = descriptors[img_name]
            rows, cols = desc_data.shape

            # 确保描述符是float32类型
            desc_data = desc_data.astype(np.float32)

            cursor.execute(
                "INSERT INTO descriptors (image_id, rows, cols, data) VALUES (?, ?, ?, ?)",
                (image_id, rows, cols, desc_data.tobytes())
            )

            successful_images += 1
            print(f"✅ 图像 {img_name} 特征点添加成功: {rows} 个特征点")

        except Exception as e:
            error_msg = f"处理图像 {img_name} 时出错: {e}"
            logging.error(error_msg)
            logging.error(traceback.format_exc())
            print(f"❌ {error_msg}")
            continue

    try:
        conn.commit()
        conn.close()
        print(f"数据库创建完成: {db_path}")
        print(f"成功添加了 {successful_images} 张图像的特征点")
    except Exception as e:
        error_msg = f"提交数据库更改失败: {e}"
        logging.error(error_msg)
        logging.error(traceback.format_exc())
        print(f"❌ {error_msg}")
        return None, {}

    # 验证数据库
    if not verify_database_integrity(db_path):
        error_msg = "数据库完整性验证失败"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None, {}

    return db_path, image_ids


def save_matches_to_database(db_path, matches_dict, image_ids):
    """将匹配结果保存到数据库 - 使用COLMAP标准格式"""
    print("保存匹配结果到数据库...")

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # 清空现有的匹配表
        cursor.execute("DELETE FROM matches")
        cursor.execute("DELETE FROM two_view_geometries")

        match_count = 0
        valid_match_count = 0

        for (img1_name, img2_name), match_data in matches_dict.items():
            if img1_name not in image_ids or img2_name not in image_ids:
                warning_msg = f"跳过匹配对 {img1_name}-{img2_name}: 图像ID未找到"
                logging.warning(warning_msg)
                print(f"⚠️ {warning_msg}")
                continue

            image_id1 = image_ids[img1_name]
            image_id2 = image_ids[img2_name]

            # 确保匹配数据有效
            if match_data is None or len(match_data) == 0:
                warning_msg = f"跳过匹配对 {img1_name}-{img2_name}: 无匹配数据"
                logging.warning(warning_msg)
                print(f"⚠️ {warning_msg}")
                continue

            # COLMAP标准的pair_id计算方式: 2147483647 * min_id + max_id
            if image_id1 > image_id2:
                image_id1, image_id2 = image_id2, image_id1
                # 注意：如果交换了图像ID，也需要交换匹配索引
                match_data = match_data[:, [1, 0]]  # 交换列顺序

            pair_id = 2147483647 * image_id1 + image_id2

            if match_data.size > 0:
                rows, cols = match_data.shape

                # 验证匹配数据格式
                if cols != 2:
                    warning_msg = f"匹配数据列数不正确: {cols}，应为2"
                    logging.warning(warning_msg)
                    print(f"⚠️ {warning_msg}")
                    continue

                try:
                    # 确保匹配数据是uint32类型 - 这是COLMAP要求的格式
                    match_data = match_data.astype(np.uint32)

                    # ========== 新增：去除重复匹配 ==========
                    unique_matches = set()
                    spatial_positions = {}  # 按图像分别记录空间位置

                    for match in match_data:
                        match_tuple = tuple(match)
                        unique_matches.add(match_tuple)

                    # 进一步空间过滤
                    filtered_matches = []
                    for match in unique_matches:
                        filtered_matches.append(match)
                    # 转换回数组
                    unique_match_data = np.array(list(unique_matches), dtype=np.uint32)
                    rows, cols = unique_match_data.shape

                    if len(unique_match_data) < len(match_data):
                        print(f"  去重: {len(match_data)} -> {len(unique_match_data)} 个匹配")
                    # ========== 去重结束 ==========

                    # 使用INSERT OR REPLACE确保覆盖现有数据
                    cursor.execute(
                        "INSERT OR REPLACE INTO matches (pair_id, rows, cols, data) VALUES (?, ?, ?, ?)",
                        (pair_id, rows, cols, unique_match_data.tobytes())
                    )

                    # 同时插入two_view_geometries表（COLMAP需要这个表）
                    cursor.execute(
                        "INSERT OR REPLACE INTO two_view_geometries (pair_id, rows, cols, data, config) VALUES (?, ?, ?, ?, ?)",
                        (pair_id, rows, cols, unique_match_data.tobytes(), 2)  # config=2 表示已验证的几何
                    )

                    match_count += 1
                    valid_match_count += rows

                    print(f"✅ 保存匹配对: {img1_name}({image_id1}) - {img2_name}({image_id2}) -> {rows} 个匹配")

                except Exception as e:
                    error_msg = f"保存匹配对 {img1_name}-{img2_name} 时出错: {e}"
                    logging.error(error_msg)
                    logging.error(traceback.format_exc())
                    print(f"❌ {error_msg}")
                    continue

        conn.commit()
        conn.close()

        print(f"✅ 匹配保存完成:")
        print(f"   保存的匹配对数: {match_count}")
        print(f"   保存的匹配总数: {valid_match_count}")

        return match_count > 0

    except Exception as e:
        error_msg = f"保存匹配到数据库时出错: {e}"
        logging.error(error_msg)
        logging.error(traceback.format_exc())
        print(f"❌ {error_msg}")
        return False

def verify_database_integrity(db_path):
    """验证数据库完整性"""
    print("🔍 验证数据库完整性...")

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # 检查所有表是否存在
        tables = ['cameras', 'images', 'keypoints', 'descriptors', 'matches', 'two_view_geometries']
        for table in tables:
            cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
            if cursor.fetchone() is None:
                error_msg = f"表 {table} 不存在"
                logging.error(error_msg)
                print(f"❌ {error_msg}")
                conn.close()
                return False

        # 检查数据完整性
        cursor.execute("SELECT COUNT(*) FROM cameras")
        camera_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM images")
        image_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM keypoints")
        keypoint_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM descriptors")
        descriptor_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM matches")
        match_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM two_view_geometries")
        geometry_count = cursor.fetchone()[0]

        print(f"📊 数据库完整性检查:")
        print(f"   相机数量: {camera_count}")
        print(f"   图像数量: {image_count}")
        print(f"   关键点数量: {keypoint_count}")
        print(f"   描述符数量: {descriptor_count}")
        print(f"   匹配对数: {match_count}")
        print(f"   几何验证对数: {geometry_count}")

        # 基本验证
        if camera_count == 0 or image_count == 0:
            error_msg = "数据库缺少基本数据"
            logging.error(error_msg)
            print(f"❌ {error_msg}")
            conn.close()
            return False

        if keypoint_count != image_count or descriptor_count != image_count:
            warning_msg = "关键点或描述符数量与图像数量不匹配"
            logging.warning(warning_msg)
            print(f"⚠️ {warning_msg}")

        conn.close()
        print("✅ 数据库完整性验证通过")
        return True

    except Exception as e:
        error_msg = f"数据库完整性验证失败: {e}"
        logging.error(error_msg)
        logging.error(traceback.format_exc())
        print(f"❌ {error_msg}")
        return False