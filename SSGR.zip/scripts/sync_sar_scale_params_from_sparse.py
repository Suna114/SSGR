#!/usr/bin/env python3
"""将 sparse/0 外参同步到 sar_scale_params.json（修复 json 与 COLMAP 不一致）。"""

from __future__ import annotations

import argparse
import os
import sys

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)


def main() -> int:
    ap = argparse.ArgumentParser(
        description="sparse/0 → sar_scale_params.json cameras 外参同步"
    )
    ap.add_argument("-s", "--source_path", required=True)
    ap.add_argument(
        "--check_only",
        action="store_true",
        help="仅检查一致性，不写 json",
    )
    ap.add_argument("--tol_m", type=float, default=1e-3)
    args = ap.parse_args()

    source_path = os.path.abspath(args.source_path)

    from sar.colmap_pose_sync import (
        sync_sar_scale_params_cameras_from_sparse,
        verify_sparse_json_pose_consistency,
    )

    ok, max_d, n = verify_sparse_json_pose_consistency(
        source_path, tol_m=args.tol_m
    )
    print(f"检查: {n} 相机, 最大光心差 {max_d:.6f} m, 一致={ok}")

    if args.check_only:
        return 0 if ok else 1

    if ok:
        print("已一致，跳过写入。")
        return 0

    sync_sar_scale_params_cameras_from_sparse(source_path, verbose=True)
    ok2, max_d2, _ = verify_sparse_json_pose_consistency(
        source_path, tol_m=args.tol_m
    )
    print(f"同步后: 最大光心差 {max_d2:.6f} m, 一致={ok2}")
    return 0 if ok2 else 1


if __name__ == "__main__":
    raise SystemExit(main())
