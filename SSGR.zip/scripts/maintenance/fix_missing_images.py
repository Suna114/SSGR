#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
修复缺失图像问题
检查并清理COLMAP数据库中不存在的图像
"""

import os
import sys


def check_missing_images(dataset_path):
    """
    检查data/24中哪些图像缺失
    """
    print("\n" + "="*70)
    print("检查缺失图像")
    print("="*70)
    
    # 1. 检查images目录
    images_dir = os.path.join(dataset_path, 'images')
    if not os.path.exists(images_dir):
        images_dir = os.path.join(dataset_path, 'input')
    
    if not os.path.exists(images_dir):
        print(f"错误: 找不到图像目录")
        return None, None
    
    # 获取实际存在的图像
    actual_images = set()
    for f in os.listdir(images_dir):
        if f.lower().endswith(('.jpg', '.jpeg', '.png', '.tif', '.tiff')):
            actual_images.add(f)
    
    print(f"\n【实际图像文件】")
    print(f"  图像目录: {images_dir}")
    print(f"  图像数量: {len(actual_images)}")
    
    # 2. 检查COLMAP记录的图像
    try:
        from utils.read_write_model import read_images_binary, read_images_text
    except ImportError:
        print("错误: 无法导入read_write_model")
        return actual_images, None
    
    sparse_dir = os.path.join(dataset_path, 'sparse/0')
    images_file = os.path.join(sparse_dir, 'images.bin')
    
    if os.path.exists(images_file):
        try:
            colmap_images = read_images_binary(images_file)
        except:
            images_file = os.path.join(sparse_dir, 'images.txt')
            colmap_images = read_images_text(images_file)
    else:
        print(f"错误: 找不到COLMAP images文件")
        return actual_images, None
    
    colmap_image_names = set([img.name for img in colmap_images.values()])
    
    print(f"\n【COLMAP记录的图像】")
    print(f"  数量: {len(colmap_image_names)}")
    
    # 3. 找出缺失的
    missing_images = colmap_image_names - actual_images
    extra_images = actual_images - colmap_image_names
    
    if missing_images:
        print(f"\n🔴 【缺失的图像】（COLMAP有记录但文件不存在）")
        for img in sorted(missing_images):
            print(f"  - {img}")
    else:
        print(f"\n✅ 所有COLMAP记录的图像都存在")
    
    if extra_images:
        print(f"\n🟡 【额外的图像】（文件存在但COLMAP没记录）")
        for img in sorted(extra_images):
            print(f"  - {img}")
    
    return actual_images, missing_images


def fix_colmap_database(dataset_path, missing_images):
    """
    从COLMAP数据库中删除缺失图像的记录
    """
    if not missing_images:
        print("\n✅ 无需修复")
        return True
    
    print(f"\n【修复方案】")
    print(f"需要从COLMAP数据库中删除{len(missing_images)}个缺失图像的记录")
    
    # 方案1: 重新运行SFM（推荐）
    print(f"\n方案1（推荐）: 重新运行SFM")
    print(f"  rm -rf {dataset_path}/sparse")
    print(f"  python convert.py -s {dataset_path}")
    print(f"  → 只处理实际存在的图像")
    
    # 方案2: 手动编辑（复杂）
    print(f"\n方案2: 手动删除COLMAP记录")
    print(f"  需要编辑 {dataset_path}/sparse/0/images.bin")
    print(f"  这很复杂，不推荐")
    
    # 方案3: 复制缺失图像（临时）
    print(f"\n方案3: 复制相似图像（临时解决）")
    images_dir = os.path.join(dataset_path, 'images')
    if not os.path.exists(images_dir):
        images_dir = os.path.join(dataset_path, 'input')
    
    # 获取第一张存在的图像作为占位符
    actual_images = [f for f in os.listdir(images_dir) 
                    if f.lower().endswith(('.jpg', '.jpeg', '.png', '.tif'))]
    
    if actual_images:
        placeholder = os.path.join(images_dir, actual_images[0])
        print(f"  使用占位符: {actual_images[0]}")
        
        for missing in sorted(missing_images):
            target = os.path.join(images_dir, missing)
            print(f"  copy {placeholder} {target}")
        
        print(f"\n  ⚠️  这只是临时方案，训练质量会受影响")
    
    return False


def main():
    if len(sys.argv) < 2:
        print("用法: python fix_missing_images.py <dataset_path>")
        print("示例: python fix_missing_images.py data/24")
        return 1
    
    dataset_path = sys.argv[1]
    
    actual_images, missing_images = check_missing_images(dataset_path)
    
    if missing_images is None:
        return 1
    
    fix_colmap_database(dataset_path, missing_images)
    
    print("\n" + "="*70)
    print("诊断完成")
    print("="*70 + "\n")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

