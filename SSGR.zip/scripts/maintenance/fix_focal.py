# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

import json
import numpy as np

# 加载cameras.json
with open('./output/sar_reconstruction1/cameras.json', 'r') as f:
    cameras = json.load(f)

print(f'找到 {len(cameras)} 个相机')

# 计算场景中心（使用相机位置的中心）
positions = np.array([c['position'] for c in cameras])
scene_center = np.mean(positions, axis=0)
print(f'场景中心: {scene_center}')

# 计算每个相机到场景中心的距离
camera_distances = []
for cam in cameras:
    pos = np.array(cam['position'])
    distance = np.linalg.norm(pos - scene_center)
    camera_distances.append(distance)

camera_distances = np.array(camera_distances)
print(f'距离范围: [{np.min(camera_distances):.2f}, {np.max(camera_distances):.2f}]')
print(f'基准距离(中位数): {np.median(camera_distances):.2f}')

# 更新焦距
base_distance = np.median(camera_distances)
base_focal = 192.0

for i, cam in enumerate(cameras):
    distance = camera_distances[i]
    ratio = distance / base_distance
    cam['fx'] = float(base_focal * ratio)
    cam['fy'] = float(base_focal * ratio)

# 显示更新后的焦距
fx_values = [c['fx'] for c in cameras]
print(f'新焦距范围: [{min(fx_values):.2f}, {max(fx_values):.2f}]')
print(f'新焦距均值: {np.mean(fx_values):.2f}')

# 显示前5个相机的焦距变化
print('\n前5个相机的焦距:')
for i in range(min(5, len(cameras))):
    cam = cameras[i]
    print(f'  相机{i}: fx={cam["fx"]:.2f}, fy={cam["fy"]:.2f}')

# 保存
with open('./output/sar_reconstruction1/cameras.json', 'w') as f:
    json.dump(cameras, f)

print('\n已保存更新后的cameras.json')

