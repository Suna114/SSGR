#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
修复相机位置尺度问题的脚本
将相机位置缩放到更合理的范围
"""

import json
import numpy as np
import sys
import os

def fix_camera_scale(input_file, output_file=None, scale_factor=0.1):
    """
    缩放相机位置
    
    Args:
        input_file: 输入的cameras.json文件路径
        output_file: 输出的cameras.json文件路径（如果为None，则覆盖原文件）
        scale_factor: 缩放因子（默认0.1，即缩小到原来的1/10）
    """
    # 读取原始文件
    with open(input_file, 'r', encoding='utf-8') as f:
        cameras = json.load(f)
    
    print(f"读取了 {len(cameras)} 个相机")
    
    # 计算场景中心
    positions = np.array([cam['position'] for cam in cameras])
    center = np.mean(positions, axis=0)
    print(f"场景中心: {center}")
    
    # 计算平均距离
    distances = np.linalg.norm(positions - center, axis=1)
    avg_dist = np.mean(distances)
    max_dist = np.max(distances)
    print(f"平均距离: {avg_dist:.2f}")
    print(f"最大距离: {max_dist:.2f}")
    
    # 缩放相机位置
    for cam in cameras:
        # 将位置相对于场景中心缩放
        pos = np.array(cam['position'])
        scaled_pos = center + (pos - center) * scale_factor
        cam['position'] = scaled_pos.tolist()
    
    # 计算缩放后的统计信息
    scaled_positions = np.array([cam['position'] for cam in cameras])
    scaled_distances = np.linalg.norm(scaled_positions - center, axis=1)
    scaled_avg_dist = np.mean(scaled_distances)
    scaled_max_dist = np.max(scaled_distances)
    print(f"\n缩放后:")
    print(f"平均距离: {scaled_avg_dist:.2f}")
    print(f"最大距离: {scaled_max_dist:.2f}")
    
    # 保存文件
    if output_file is None:
        output_file = input_file
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(cameras, f, indent=2, ensure_ascii=False)
    
    print(f"\n已保存到: {output_file}")
    print(f"缩放因子: {scale_factor}")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法: python fix_camera_scale.py <cameras.json> [output_file] [scale_factor]")
        print("示例: python fix_camera_scale.py output/sar_reconstruction/cameras.json")
        print("示例: python fix_camera_scale.py output/sar_reconstruction/cameras.json cameras_fixed.json 0.1")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    scale_factor = float(sys.argv[3]) if len(sys.argv) > 3 else 0.1
    
    if not os.path.exists(input_file):
        print(f"错误: 文件不存在: {input_file}")
        sys.exit(1)
    
    fix_camera_scale(input_file, output_file, scale_factor)

