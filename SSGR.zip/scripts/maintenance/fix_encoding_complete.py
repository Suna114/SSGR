#!/usr/bin/env python

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""修复 scene/__init__.py 中的所有编码和语法错误"""

with open('scene/__init__.py', 'r', encoding='utf-8', errors='replace') as f:
    lines = f.readlines()

# 修复所有编码和语法问题
for i, line in enumerate(lines):
    # 修复第617行的语法错误
    if i == 616 and 'if save_target_cloud:`n' in line:
        lines[i] = '        # 🔧 新增：保存只包含目标点的点云（基于颜色/亮度过滤）\n'
        lines.insert(i+1, '        # 目标点通常是白色/亮色，背景点是黑灰色\n')
        lines.insert(i+2, '        if save_target_cloud:\n')
        lines.insert(i+3, '            try:\n')
        continue
    
    # 修复第620行的注释
    if i == 619 and '# 获取高斯点的DC分量' in line:
        line = '            # 获取高斯点的DC分量（0阶球谐系数，表示平均颜色）\n'
    
    # 修复第622行的注释
    if i == 621 and 'f_dc shape:' in line:
        line = '            # f_dc shape: (N, 1, 3)，需要reshape为(N, 3)\n'
    
    # 修复第625行的注释
    if i == 624 and '# 限制在[0, 1]范围' in line:
        line = '            # 限制在[0, 1]范围内\n'
    
    # 修复第627行的注释
    if i == 626 and '# 计算每个点的亮度' in line:
        line = '            # 计算每个点的亮度（使用RGB的加权平均，符合人眼感知）\n'
        lines.insert(i+1, '            # 亮度公式：0.299*R + 0.587*G + 0.114*B\n')
        continue
    
    # 修复第630行的注释
    if i == 629 and '# 🔧 使用每幅图像的散射强度分位数作为阈值' in line:
        line = '            # 🔧 使用每幅图像的散射强度分位数作为阈值（类似SFM）\n'
        lines[i+1] = '            # SFM使用每幅图像的99%分位数作为目标阈值，而不是固定阈值\n'
        lines[i+2] = '            # 这里我们使用点云亮度的99%分位数作为自适应阈值\n'
        lines[i+3] = '            # 注意：numpy已在文件顶部导入，无需重复导入\n'
        continue
    
    # 修复第631行的注释
    if i == 630 and 'target_percentile = 99.0' in line:
        line = '            target_percentile = 99.0  # 99%分位数，与SFM一致\n'
    
    # 修复第633行的注释
    if i == 632 and '# 过滤出目标点' in line:
        line = '            # 过滤出目标点（亮度大于等于99%分位数阈值）\n'
    
    # 修复第640行的字符串
    if i == 639 and '总点' in line:
        line = '                print(f"   - 总点数: {len(brightness)}")\n'
    
    # 修复第641行的字符串
    if i == 640 and '目标点数（亮' in line:
        line = '                print(f"   - 目标点数（亮度>={target_brightness_threshold:.2f}）: {num_target_points} ({100*num_target_points/len(brightness):.1f}%)")\n'
    
    # 修复第647行的字符串
    if i == 646 and '目标点云已保' in line:
        line = '                print(f"   ✅ 目标点云已保存: {target_point_cloud_path}")\n'
    
    # 修复第649行的字符串终止问题
    if i == 648 and '没有找到目标点' in line:
        line = '                print(f"\\n⚠️ 警告: 没有找到目标点（所有点的亮度都<{target_brightness_threshold:.2f}）")\n'
    
    # 修复第651行的 except 缩进
    if i == 650 and 'except Exception as e:' in line:
        line = '            except Exception as e:\n'
    
    # 修复第652行的缩进
    if i == 651 and '保存目标点云时出' in line:
        line = '                print(f"⚠️ 保存目标点云时出错: {e}")\n'
    
    # 修复其他编码错误
    line = line.replace('', '')
    line = line.replace('亮度过滤', '颜色/亮度过滤）')
    line = line.replace('白亮色', '白色/亮色')
    line = line.replace('阶球谐系数，表示平均颜色', '（0阶球谐系数，表示平均颜色）')
    line = line.replace('N, 3)', '为(N, 3)')
    line = line.replace('范围', '内）')
    line = line.replace('人眼感知', '）')
    line = line.replace('.299*R', '0.299*R')
    line = line.replace('SFM', '）')
    line = line.replace('9%分位数', '的99%分位数')
    line = line.replace('固定阈', '值')
    line = line.replace('自适应阈', '值')
    line = line.replace('SFM一', '，与SFM一致')
    line = line.replace('9%分位数阈值）', '于99%分位数阈值）')
    line = line.replace('总点', '数:')
    line = line.replace('亮=', '度>=')
    line = line.replace('目标点云已保', '✅ 目标点云已保存:')
    line = line.replace('时出', '时出错')
    
    lines[i] = line

# 写回文件
with open('scene/__init__.py', 'w', encoding='utf-8') as f:
    f.writelines(lines)

print("✅ 所有编码和语法问题已修复")

