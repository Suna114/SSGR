#!/usr/bin/env python

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""修复 scene/__init__.py 中的所有编码和语法错误"""

import re

with open('scene/__init__.py', 'r', encoding='utf-8', errors='replace') as f:
    lines = f.readlines()

# 修复所有编码和语法问题
for i, line in enumerate(lines):
    # 修复第617行的语法错误：`n 应该是换行符
    if 'if save_target_cloud:`n' in line:
        line = line.replace('if save_target_cloud:`n', 'if save_target_cloud:\n')
        # 确保 try 语句有正确的缩进
        if 'try:' in line:
            line = '        if save_target_cloud:\n            try:\n'
    
    # 修复所有编码错误（替换字符）
    replacements = {
        '': '',  # 删除替换字符
        '亮度过滤': '颜色/亮度过滤）',
        '阶球谐系数，表示平均颜色': '（0阶球谐系数，表示平均颜色）',
        'N, 3)': '为(N, 3)',
        '范围': '内）',
        '人眼感知': '）',
        '.299*R': '0.299*R',
        'SFM': '）',
        '9%分位数': '的99%分位数',
        '固定阈': '值',
        '9%分位数': '的99%分位数',
        '自适应阈': '值',
        'SFM一': '，与SFM一致',
        '9%分位数阈值）': '于99%分位数阈值）',
        '总点': '数:',
        '亮=': '度>=',
        '目标点云已保': '✅ 目标点云已保存:',
        ')': '）',
        ' {e}': ': {e}',
        '修改：': '修改：',
        '位': '姿',
        '高': '度',
        '已更': '✅ 已更新',
        '已保存': '✅ 已保存',
        '均': '值:',
        '时出': '时出错',
        '相机': '机',
        '坐标系': '）',
        '平移向': '量）',
        '稳健': '）',
        ' {iteration}': f'，迭代 {iteration}）',
        '调整': '）',
        '输出': '）',
    }
    
    for old, new in replacements.items():
        if old in line:
            line = line.replace(old, new)
    
    # 修复第649行的字符串终止问题
    if i == 648 and 'target_brightness_threshold:.2f})' in line:
        line = '                print(f"\\n⚠️ 警告: 没有找到目标点（所有点的亮度都<{target_brightness_threshold:.2f}）")\n'
    
    # 修复第651行的 except 缩进
    if i == 650 and 'except Exception as e:' in line and not line.startswith('            '):
        line = '            except Exception as e:\n'
    
    # 修复第652行的缩进
    if i == 651 and 'print(f"⚠️ 保存目标点云时出' in line and not line.startswith('                '):
        line = '                print(f"⚠️ 保存目标点云时出错: {e}")\n'
    
    lines[i] = line

# 写回文件
with open('scene/__init__.py', 'w', encoding='utf-8') as f:
    f.writelines(lines)

print("✅ 所有编码和语法问题已修复")

