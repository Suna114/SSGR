#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# upgrade_features.py
"""
SAR特征提取升级工具
一键式从SAR-SIFT升级到SuperPoint+SuperGlue

使用方法:
    python upgrade_features.py --mode download      # 下载预训练模型
    python upgrade_features.py --mode test          # 测试新方法
    python upgrade_features.py --mode compare       # 对比新旧方法
    python upgrade_features.py --mode integrate     # 集成到现有流程
"""

import os
import sys
import argparse
import time
import cv2
import numpy as np
from pathlib import Path
import requests
from tqdm import tqdm
import matplotlib.pyplot as plt

# ==================== 预训练模型下载 ====================
PRETRAINED_MODELS = {
    'superpoint': {
        'url': 'https://github.com/magicleap/SuperPointPretrainedNetwork/raw/master/superpoint_v1.pth',
        'path': 'weights/superpoint_v1.pth',
        'size': '1.3 MB'
    },
    'superglue_outdoor': {
        'url': 'https://github.com/magicleap/SuperGluePretrainedNetwork/raw/master/models/weights/superglue_outdoor.pth',
        'path': 'weights/superglue_outdoor.pth',
        'size': '10.2 MB'
    },
    'superglue_indoor': {
        'url': 'https://github.com/magicleap/SuperGluePretrainedNetwork/raw/master/models/weights/superglue_indoor.pth',
        'path': 'weights/superglue_indoor.pth',
        'size': '10.2 MB'
    }
}


def download_file(url, dest_path, desc="下载"):
    """下载文件并显示进度条"""
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    
    response = requests.get(url, stream=True)
    total_size = int(response.headers.get('content-length', 0))
    
    with open(dest_path, 'wb') as f, tqdm(
        desc=desc,
        total=total_size,
        unit='iB',
        unit_scale=True,
        unit_divisor=1024,
    ) as pbar:
        for data in response.iter_content(chunk_size=1024):
            size = f.write(data)
            pbar.update(size)
    
    print(f"✅ 已下载: {dest_path}")


def download_pretrained_models():
    """下载所有预训练模型"""
    print("📥 开始下载预训练模型...")
    print("=" * 60)
    
    for model_name, model_info in PRETRAINED_MODELS.items():
        dest_path = model_info['path']
        
        if os.path.exists(dest_path):
            print(f"⏭️ {model_name} 已存在，跳过下载")
            continue
        
        print(f"📦 下载 {model_name} ({model_info['size']})...")
        try:
            download_file(model_info['url'], dest_path, desc=model_name)
        except Exception as e:
            print(f"❌ 下载失败: {e}")
            print(f"   请手动下载: {model_info['url']}")
            print(f"   保存到: {dest_path}")
    
    print("=" * 60)
    print("✅ 预训练模型下载完成！")


# ==================== 特征提取测试 ====================
def test_sar_sift(image):
    """测试SAR-SIFT（旧方法）"""
    print("🔍 测试SAR-SIFT...")
    
    try:
        from feature_extraction import extract_features_from_images
        import config
        
        args = config.parse_arguments()
        args.source_path = "."  # 临时路径
        
        start_time = time.time()
        
        # 调用SAR-SIFT
        # 注意：这里需要根据实际API调整
        # keypoints, descriptors = extract_sar_sift(image, args)
        
        elapsed_time = time.time() - start_time
        
        print(f"   特征点数: {len(keypoints) if 'keypoints' in locals() else 'N/A'}")
        print(f"   耗时: {elapsed_time:.2f}秒")
        
        return keypoints, descriptors, elapsed_time
    except Exception as e:
        print(f"   ❌ SAR-SIFT测试失败: {e}")
        return None, None, 0


def test_superpoint(image):
    """测试SuperPoint（新方法）"""
    print("🚀 测试SuperPoint...")
    
    try:
        from modern_sar_features import ModernSARFeatureExtractor, ModernSARConfig
        
        config = ModernSARConfig()
        config.method = 'superpoint_superglue'
        extractor = ModernSARFeatureExtractor(config)
        
        start_time = time.time()
        keypoints, scores, descriptors = extractor.extract_features(image)
        elapsed_time = time.time() - start_time
        
        print(f"   特征点数: {len(keypoints)}")
        print(f"   平均置信度: {np.mean(scores):.3f}")
        print(f"   耗时: {elapsed_time:.3f}秒")
        
        return keypoints, descriptors, elapsed_time
    except Exception as e:
        print(f"   ❌ SuperPoint测试失败: {e}")
        import traceback
        traceback.print_exc()
        return None, None, 0


def compare_methods(image_path):
    """对比新旧方法"""
    print("\n" + "=" * 60)
    print("📊 性能对比测试")
    print("=" * 60)
    
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        print(f"❌ 无法读取图像: {image_path}")
        return
    
    print(f"图像尺寸: {image.shape}")
    
    # 测试SAR-SIFT
    print("\n【方法1: SAR-SIFT (传统方法)】")
    kpts_old, desc_old, time_old = test_sar_sift(image)
    
    # 测试SuperPoint
    print("\n【方法2: SuperPoint (现代方法)】")
    kpts_new, desc_new, time_new = test_superpoint(image)
    
    # 对比结果
    if kpts_old is not None and kpts_new is not None:
        print("\n" + "=" * 60)
        print("📈 对比结果")
        print("=" * 60)
        
        print(f"特征点数量:")
        print(f"  SAR-SIFT:   {len(kpts_old):>6} 个")
        print(f"  SuperPoint: {len(kpts_new):>6} 个")
        print(f"  提升:       {len(kpts_new)/len(kpts_old):.1f}x")
        
        print(f"\n处理时间:")
        print(f"  SAR-SIFT:   {time_old:>6.2f} 秒")
        print(f"  SuperPoint: {time_new:>6.3f} 秒")
        print(f"  加速:       {time_old/time_new:.1f}x")
        
        # 可视化
        visualize_comparison(image, kpts_old, kpts_new)


def visualize_comparison(image, kpts_old, kpts_new):
    """可视化对比"""
    print("\n生成可视化对比图...")
    
    fig, axes = plt.subplots(1, 2, figsize=(15, 7))
    
    # SAR-SIFT
    img_old = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR) if len(image.shape) == 2 else image.copy()
    for kp in kpts_old:
        cv2.circle(img_old, (int(kp[0]), int(kp[1])), 3, (0, 255, 0), -1)
    axes[0].imshow(cv2.cvtColor(img_old, cv2.COLOR_BGR2RGB))
    axes[0].set_title(f'SAR-SIFT ({len(kpts_old)} 特征点)')
    axes[0].axis('off')
    
    # SuperPoint
    img_new = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR) if len(image.shape) == 2 else image.copy()
    for kp in kpts_new:
        cv2.circle(img_new, (int(kp[0]), int(kp[1])), 3, (255, 0, 0), -1)
    axes[1].imshow(cv2.cvtColor(img_new, cv2.COLOR_BGR2RGB))
    axes[1].set_title(f'SuperPoint ({len(kpts_new)} 特征点)')
    axes[1].axis('off')
    
    plt.tight_layout()
    output_path = 'feature_comparison.png'
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"✅ 对比图已保存: {output_path}")


# ==================== 集成到现有流程 ====================
def integrate_to_existing_code():
    """将新方法集成到现有代码"""
    print("\n" + "=" * 60)
    print("🔧 集成新方法到现有代码")
    print("=" * 60)
    
    integration_code = '''
# ========== 在 feature_extraction.py 中添加 ==========

# 1. 导入新模块（添加到文件顶部）
try:
    from modern_sar_features import ModernSARFeatureExtractor, ModernSARConfig
    MODERN_FEATURES_AVAILABLE = True
except ImportError:
    MODERN_FEATURES_AVAILABLE = False
    print("⚠️ 未找到现代特征模块，使用传统SAR-SIFT")


# 2. 修改特征提取函数
def extract_features_from_images(args):
    """特征提取 - 支持新旧方法"""
    
    # 检查是否使用现代方法
    use_modern = getattr(args, 'use_modern_features', False)
    
    if use_modern and MODERN_FEATURES_AVAILABLE:
        print("🚀 使用现代特征提取方法 (SuperPoint)")
        return extract_features_modern(args)
    else:
        print("📌 使用传统特征提取方法 (SAR-SIFT)")
        return extract_features_traditional(args)


def extract_features_modern(args):
    """使用SuperPoint提取特征"""
    # 初始化
    config = ModernSARConfig()
    config.device = 'cuda' if torch.cuda.is_available() else 'cpu'
    config.superpoint_conf_thresh = args.sar_sift_harris_threshold / 100  # 自适应调整
    config.superpoint_max_keypoints = args.max_features
    
    extractor = ModernSARFeatureExtractor(config)
    
    # 处理所有图像
    features_dict = {}
    for image_path in tqdm(image_paths, desc="提取特征"):
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        
        # 提取
        keypoints, scores, descriptors = extractor.extract_features(image)
        
        # 转换为OpenCV格式（兼容性）
        cv_keypoints = []
        for i, kp in enumerate(keypoints):
            cv_kp = cv2.KeyPoint()
            cv_kp.pt = (float(kp[0]), float(kp[1]))
            cv_kp.response = float(scores[i])
            cv_kp.size = 10.0
            cv_keypoints.append(cv_kp)
        
        features_dict[image_path] = {
            'keypoints': cv_keypoints,
            'descriptors': descriptors
        }
    
    return features_dict


# ========== 在 config.py 中添加 ==========

# 添加命令行参数
parser.add_argument("--use_modern_features", action='store_true', default=False,
                   help="使用现代特征提取方法 (SuperPoint+SuperGlue)")

parser.add_argument("--modern_feature_method", type=str, default="superpoint_superglue",
                   choices=["superpoint_superglue", "loftr"],
                   help="现代特征提取方法选择")


# ========== 使用方法 ==========

# 方式1: 命令行启用
python sar_sorc_sfm.py -s /path/to/data --use_modern_features

# 方式2: 修改默认值
parser.add_argument("--use_modern_features", action='store_true', default=True,  # 改为True
                   help="使用现代特征提取方法")

# 方式3: 代码中切换
args.use_modern_features = True  # 强制使用新方法
'''
    
    print(integration_code)
    
    # 保存集成代码
    with open('integration_guide.py', 'w', encoding='utf-8') as f:
        f.write(integration_code)
    
    print("\n✅ 集成代码已保存到: integration_guide.py")
    print("\n📝 下一步:")
    print("   1. 查看 integration_guide.py")
    print("   2. 复制相关代码到 feature_extraction.py 和 config.py")
    print("   3. 运行测试: python sar_sorc_sfm.py --use_modern_features")


# ==================== 主函数 ====================
def main():
    parser = argparse.ArgumentParser(description='SAR特征提取升级工具')
    parser.add_argument('--mode', type=str, required=True,
                       choices=['download', 'test', 'compare', 'integrate'],
                       help='运行模式')
    parser.add_argument('--image', type=str, default=None,
                       help='测试图像路径 (用于test/compare模式)')
    
    args = parser.parse_args()
    
    print("🚀 SAR特征提取升级工具")
    print("=" * 60)
    
    if args.mode == 'download':
        download_pretrained_models()
    
    elif args.mode == 'test':
        if args.image is None:
            print("❌ 请指定测试图像: --image /path/to/image.png")
            return
        
        image = cv2.imread(args.image, cv2.IMREAD_GRAYSCALE)
        if image is None:
            print(f"❌ 无法读取图像: {args.image}")
            return
        
        test_superpoint(image)
    
    elif args.mode == 'compare':
        if args.image is None:
            # 查找示例图像
            example_images = list(Path('.').rglob('*.png')) + list(Path('.').rglob('*.jpg'))
            if example_images:
                args.image = str(example_images[0])
                print(f"📸 使用示例图像: {args.image}")
            else:
                print("❌ 请指定测试图像: --image /path/to/image.png")
                return
        
        compare_methods(args.image)
    
    elif args.mode == 'integrate':
        integrate_to_existing_code()
    
    print("\n" + "=" * 60)
    print("✅ 完成！")


if __name__ == "__main__":
    main()


