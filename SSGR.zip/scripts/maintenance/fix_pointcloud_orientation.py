#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
修正SFM点云方向

问题：SAR图像使用斜距投影，但COLMAP SFM假设透视投影，
导致三角测量深度估计错误，点云被"竖起来"。

解决方案：
1. 分析点云的主成分方向
2. 旋转点云使其正确放置（坦克平放在XOY面上）
3. 同步更新相机位置

用法:
    python fix_pointcloud_orientation.py [数据路径]
"""

import numpy as np
import json
import os
import shutil
from plyfile import PlyData, PlyElement

def load_pointcloud(ply_path):
    """加载PLY点云"""
    plydata = PlyData.read(ply_path)
    vertices = plydata['vertex']
    xyz = np.vstack([vertices['x'], vertices['y'], vertices['z']]).T
    
    # 尝试读取颜色
    try:
        colors = np.vstack([vertices['red'], vertices['green'], vertices['blue']]).T
    except:
        colors = np.ones_like(xyz) * 128
    
    # 尝试读取法向量
    try:
        normals = np.vstack([vertices['nx'], vertices['ny'], vertices['nz']]).T
    except:
        normals = np.zeros_like(xyz)
    
    return xyz, colors, normals

def save_pointcloud(ply_path, xyz, colors, normals=None):
    """保存PLY点云"""
    if normals is None:
        normals = np.zeros_like(xyz)
    
    dtype = [('x', 'f4'), ('y', 'f4'), ('z', 'f4'),
             ('nx', 'f4'), ('ny', 'f4'), ('nz', 'f4'),
             ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')]
    
    elements = np.empty(xyz.shape[0], dtype=dtype)
    attributes = np.concatenate((xyz, normals, colors), axis=1)
    elements[:] = list(map(tuple, attributes))
    
    vertex_element = PlyElement.describe(elements, 'vertex')
    ply_data = PlyData([vertex_element])
    ply_data.write(ply_path)

def analyze_and_fix_orientation(xyz, target_up='Z'):
    """
    分析点云主成分方向并修正
    
    T72坦克应该是平放的：
    - 长度方向：最大尺寸
    - 宽度方向：中等尺寸
    - 高度方向：最小尺寸
    
    目标：使高度方向对齐Z轴（向上）
    """
    # 中心化点云
    center = np.mean(xyz, axis=0)
    xyz_centered = xyz - center
    
    # PCA分析
    cov = np.cov(xyz_centered.T)
    eigenvalues, eigenvectors = np.linalg.eigh(cov)
    
    # 按特征值排序（从大到小）
    # 最大特征值对应长度方向
    # 最小特征值对应高度方向
    order = np.argsort(eigenvalues)[::-1]
    eigenvalues = eigenvalues[order]
    eigenvectors = eigenvectors[:, order]
    
    print(f"\n📐 PCA分析:")
    print(f"   特征值: {eigenvalues}")
    print(f"   主方向1 (长度): {eigenvectors[:, 0]}")
    print(f"   主方向2 (宽度): {eigenvectors[:, 1]}")
    print(f"   主方向3 (高度): {eigenvectors[:, 2]}")
    
    # 当前最小主成分方向（高度方向）
    current_up = eigenvectors[:, 2]
    
    # 目标方向
    if target_up == 'Z':
        target_up_vec = np.array([0, 0, 1])
    elif target_up == 'Y':
        target_up_vec = np.array([0, 1, 0])
    else:
        target_up_vec = np.array([1, 0, 0])
    
    # 计算旋转矩阵
    # 使用Rodrigues公式计算从current_up到target_up的旋转
    v = np.cross(current_up, target_up_vec)
    s = np.linalg.norm(v)
    c = np.dot(current_up, target_up_vec)
    
    if s < 1e-6:  # current_up和target_up_vec共线
        if c > 0:
            R = np.eye(3)  # 同向，不需要旋转
        else:
            # 反向，旋转180度
            # 选择一个垂直于current_up的轴
            if abs(current_up[0]) < 0.9:
                perp = np.cross(current_up, np.array([1, 0, 0]))
            else:
                perp = np.cross(current_up, np.array([0, 1, 0]))
            perp = perp / np.linalg.norm(perp)
            R = 2 * np.outer(perp, perp) - np.eye(3)
    else:
        vx = np.array([
            [0, -v[2], v[1]],
            [v[2], 0, -v[0]],
            [-v[1], v[0], 0]
        ])
        R = np.eye(3) + vx + np.dot(vx, vx) * (1 - c) / (s * s)
    
    print(f"\n🔄 旋转矩阵:")
    print(R)
    
    # 应用旋转
    xyz_rotated = (R @ xyz_centered.T).T + center
    
    return xyz_rotated, R, center

def transform_cameras(cameras_json_path, R, center, output_path):
    """
    转换相机位置和姿态
    
    如果点云旋转了R，相机也需要做相应变换
    """
    with open(cameras_json_path, 'r') as f:
        cameras = json.load(f)
    
    for cam in cameras:
        # 转换位置
        pos = np.array(cam['position'])
        pos_centered = pos - center
        pos_rotated = R @ pos_centered + center
        cam['position'] = pos_rotated.tolist()
        
        # 转换旋转矩阵
        rot = np.array(cam['rotation'])
        # 新的相机旋转 = R @ 原旋转
        rot_new = R @ rot
        cam['rotation'] = rot_new.tolist()
    
    with open(output_path, 'w') as f:
        json.dump(cameras, f, indent=2)
    
    return cameras

def main():
    import sys
    
    # 默认路径
    if len(sys.argv) > 1:
        data_path = sys.argv[1]
    else:
        data_path = "./output/sar_reconstruction1"
    
    # 查找点云和相机文件
    input_ply = os.path.join(data_path, "input.ply")
    cameras_json = os.path.join(data_path, "cameras.json")
    
    if not os.path.exists(input_ply):
        # 尝试其他路径
        alt_paths = [
            os.path.join(data_path, "sparse/0/points3D.ply"),
            os.path.join(data_path, "point_cloud/iteration_30000/point_cloud.ply"),
        ]
        for alt in alt_paths:
            if os.path.exists(alt):
                input_ply = alt
                break
    
    if not os.path.exists(input_ply):
        print(f"❌ 未找到点云文件: {input_ply}")
        return
    
    print("="*60)
    print("点云方向修正工具")
    print("="*60)
    
    # 1. 加载点云
    print(f"\n📂 加载点云: {input_ply}")
    xyz, colors, normals = load_pointcloud(input_ply)
    print(f"   点数: {len(xyz)}")
    
    # 2. 分析并修正方向
    print(f"\n🔍 分析点云方向...")
    
    # 先显示修正前的尺寸
    size_before = np.max(xyz, axis=0) - np.min(xyz, axis=0)
    print(f"\n📦 修正前尺寸:")
    print(f"   X: {size_before[0]:.2f}")
    print(f"   Y: {size_before[1]:.2f}")
    print(f"   Z: {size_before[2]:.2f}")
    
    xyz_fixed, R, center = analyze_and_fix_orientation(xyz, target_up='Z')
    
    # 显示修正后的尺寸
    size_after = np.max(xyz_fixed, axis=0) - np.min(xyz_fixed, axis=0)
    print(f"\n📦 修正后尺寸:")
    print(f"   X: {size_after[0]:.2f}")
    print(f"   Y: {size_after[1]:.2f}")
    print(f"   Z: {size_after[2]:.2f}")
    
    # 验证Z是否变成最小
    sorted_dims_after = np.argsort(size_after)
    dim_names = ['X', 'Y', 'Z']
    if sorted_dims_after[0] == 2:  # Z是最小
        print(f"\n✅ 修正成功: Z方向现在是最小尺寸")
    else:
        print(f"\n⚠️ 注意: Z方向不是最小尺寸")
        print(f"   尺寸排序: {dim_names[sorted_dims_after[2]]} > {dim_names[sorted_dims_after[1]]} > {dim_names[sorted_dims_after[0]]}")
    
    # 3. 备份并保存修正后的点云
    backup_ply = input_ply + ".backup"
    if not os.path.exists(backup_ply):
        shutil.copy(input_ply, backup_ply)
        print(f"\n💾 已备份原点云到: {backup_ply}")
    
    save_pointcloud(input_ply, xyz_fixed, colors, normals)
    print(f"✅ 已保存修正后的点云: {input_ply}")
    
    # 4. 同步更新相机
    if os.path.exists(cameras_json):
        backup_cameras = cameras_json + ".backup"
        if not os.path.exists(backup_cameras):
            shutil.copy(cameras_json, backup_cameras)
            print(f"💾 已备份原相机到: {backup_cameras}")
        
        cameras = transform_cameras(cameras_json, R, center, cameras_json)
        print(f"✅ 已更新相机位置: {cameras_json}")
        
        # 验证相机位置
        positions = np.array([c['position'] for c in cameras])
        print(f"\n📷 更新后的相机位置范围:")
        print(f"   X: [{np.min(positions[:,0]):.2f}, {np.max(positions[:,0]):.2f}]")
        print(f"   Y: [{np.min(positions[:,1]):.2f}, {np.max(positions[:,1]):.2f}]")
        print(f"   Z: [{np.min(positions[:,2]):.2f}, {np.max(positions[:,2]):.2f}]")
    
    print("\n" + "="*60)
    print("修正完成！")
    print("="*60)
    print("\n建议: 重新训练3DGS模型以获得正确的渲染结果")

if __name__ == "__main__":
    main()

