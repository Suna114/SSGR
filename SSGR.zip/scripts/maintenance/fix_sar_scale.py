#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
SAR点云尺度自动修复工具

问题：SFM初始点云比GS训练后的点云太小
解决：自动计算并调整radius_scale参数
"""

import json
import numpy as np
import os
import sys
import argparse


def analyze_sfm_point_cloud(sparse_dir):
    """
    分析SFM点云的尺度
    """
    try:
        from utils.read_write_model import read_points3D_binary, read_points3D_text
    except ImportError:
        print("错误: 无法导入read_write_model模块")
        return None
    
    # 尝试读取二进制格式
    points3d_file = os.path.join(sparse_dir, 'points3D.bin')
    if os.path.exists(points3d_file):
        try:
            points = read_points3D_binary(points3d_file)
        except:
            # 尝试文本格式
            points3d_file = os.path.join(sparse_dir, 'points3D.txt')
            if os.path.exists(points3d_file):
                points = read_points3D_text(points3d_file)
            else:
                print(f"错误: 找不到points3D文件")
                return None
    else:
        print(f"错误: 找不到{points3d_file}")
        return None
    
    if not points:
        print("错误: 点云为空")
        return None
    
    # 提取坐标
    coords = np.array([p.xyz for p in points.values()])
    
    # 计算范围
    extent = coords.max(axis=0) - coords.min(axis=0)
    center = coords.mean(axis=0)
    max_extent = extent.max()
    
    info = {
        'num_points': len(coords),
        'extent': extent,
        'center': center,
        'max_extent': max_extent
    }
    
    return info


def analyze_gs_point_cloud(ply_file):
    """
    分析GS训练后点云的尺度
    """
    try:
        from plyfile import PlyData
    except ImportError:
        print("错误: 需要安装plyfile库: pip install plyfile")
        return None
    
    if not os.path.exists(ply_file):
        print(f"错误: 找不到{ply_file}")
        return None
    
    ply = PlyData.read(ply_file)
    coords = np.vstack([
        ply['vertex']['x'],
        ply['vertex']['y'],
        ply['vertex']['z']
    ]).T
    
    extent = coords.max(axis=0) - coords.min(axis=0)
    center = coords.mean(axis=0)
    max_extent = extent.max()
    
    info = {
        'num_points': len(coords),
        'extent': extent,
        'center': center,
        'max_extent': max_extent
    }
    
    return info


def calculate_recommended_radius_scale(sfm_max_extent, gs_max_extent, current_radius_scale):
    """
    根据SFM和GS点云的尺寸比例，计算推荐的radius_scale
    """
    # 尺度比例（GS/SFM）
    scale_ratio = gs_max_extent / sfm_max_extent
    
    # 推荐的radius_scale
    # 如果GS比SFM大2倍，radius_scale应该增加2倍
    recommended_radius_scale = current_radius_scale * scale_ratio
    
    return recommended_radius_scale, scale_ratio


def update_sar_scale_params(dataset_path, new_radius_scale):
    """
    更新sar_scale_params.json文件
    """
    params_file = os.path.join(dataset_path, 'sar_scale_params.json')
    
    if not os.path.exists(params_file):
        print(f"错误: 找不到{params_file}")
        return False
    
    # 备份原文件
    backup_file = params_file + '.backup'
    import shutil
    shutil.copy(params_file, backup_file)
    print(f"✅ 已备份原文件到: {backup_file}")
    
    # 读取参数
    with open(params_file, 'r', encoding='utf-8') as f:
        params = json.load(f)
    
    # 更新radius_scale
    old_unified = params.get('unified_radius_scale', 0.0)
    old_estimated = params.get('estimated_radius_scale', 0.0)
    
    params['unified_radius_scale'] = new_radius_scale
    if 'estimated_radius_scale' in params:
        params['estimated_radius_scale'] = new_radius_scale
    
    # 保存
    with open(params_file, 'w', encoding='utf-8') as f:
        json.dump(params, f, indent=2, ensure_ascii=False)
    
    print(f"✅ 已更新参数文件:")
    print(f"   unified_radius_scale: {old_unified:.4f} → {new_radius_scale:.4f}")
    if old_estimated > 0:
        print(f"   estimated_radius_scale: {old_estimated:.4f} → {new_radius_scale:.4f}")
    
    return True


def main():
    parser = argparse.ArgumentParser(description='SAR点云尺度自动修复工具')
    parser.add_argument('--dataset', '-s', required=True, help='数据集路径（如data/24）')
    parser.add_argument('--gs_output', '-g', help='GS训练输出路径（可选，用于对比）')
    parser.add_argument('--target_radius_scale', '-r', type=float, help='目标radius_scale值（手动指定）')
    parser.add_argument('--apply', action='store_true', help='自动应用修复（否则只显示建议）')
    
    args = parser.parse_args()
    
    print("\n" + "="*70)
    print("SAR点云尺度诊断工具")
    print("="*70)
    
    # 1. 检查SFM点云
    print(f"\n【步骤1】分析SFM初始点云...")
    sparse_dir = os.path.join(args.dataset, 'sparse/0')
    
    if not os.path.exists(sparse_dir):
        print(f"错误: 找不到SFM结果目录: {sparse_dir}")
        print("请先运行SFM重建")
        return 1
    
    sfm_info = analyze_sfm_point_cloud(sparse_dir)
    if sfm_info is None:
        return 1
    
    print(f"✅ SFM点云信息:")
    print(f"   点数: {sfm_info['num_points']}")
    print(f"   范围: X={sfm_info['extent'][0]:.2f}m, Y={sfm_info['extent'][1]:.2f}m, Z={sfm_info['extent'][2]:.2f}m")
    print(f"   最大范围: {sfm_info['max_extent']:.2f}m")
    
    # 2. 检查当前radius_scale
    print(f"\n【步骤2】检查当前参数...")
    params_file = os.path.join(args.dataset, 'sar_scale_params.json')
    
    if not os.path.exists(params_file):
        print(f"警告: 找不到{params_file}")
        print("将使用默认参数计算")
        current_radius_scale = 0.2108
    else:
        with open(params_file, 'r', encoding='utf-8') as f:
            params = json.load(f)
        
        current_radius_scale = params.get('unified_radius_scale', 
                                         params.get('estimated_radius_scale', 0.2108))
        
        print(f"✅ 当前参数:")
        print(f"   unified_radius_scale: {params.get('unified_radius_scale', 'N/A')}")
        print(f"   estimated_radius_scale: {params.get('estimated_radius_scale', 'N/A')}")
        print(f"   使用值: {current_radius_scale:.4f}")
    
    # 3. 分析GS点云（如果提供）
    if args.gs_output:
        print(f"\n【步骤3】分析GS训练后点云...")
        
        # 查找最新的点云文件
        point_cloud_dir = os.path.join(args.gs_output, 'point_cloud')
        if not os.path.exists(point_cloud_dir):
            print(f"警告: 找不到{point_cloud_dir}")
        else:
            # 查找所有iteration目录
            iterations = []
            for d in os.listdir(point_cloud_dir):
                if d.startswith('iteration_'):
                    try:
                        iter_num = int(d.split('_')[1])
                        iterations.append((iter_num, d))
                    except:
                        continue
            
            if iterations:
                # 使用最大迭代的点云
                latest_iter = max(iterations)[1]
                ply_file = os.path.join(point_cloud_dir, latest_iter, 'point_cloud.ply')
                
                gs_info = analyze_gs_point_cloud(ply_file)
                if gs_info:
                    print(f"✅ GS点云信息 ({latest_iter}):")
                    print(f"   点数: {gs_info['num_points']}")
                    print(f"   范围: X={gs_info['extent'][0]:.2f}m, Y={gs_info['extent'][1]:.2f}m, Z={gs_info['extent'][2]:.2f}m")
                    print(f"   最大范围: {gs_info['max_extent']:.2f}m")
                    
                    # 4. 计算推荐值
                    print(f"\n【步骤4】计算推荐参数...")
                    
                    recommended, ratio = calculate_recommended_radius_scale(
                        sfm_info['max_extent'],
                        gs_info['max_extent'],
                        current_radius_scale
                    )
                    
                    print(f"📊 尺度分析:")
                    print(f"   SFM点云尺寸: {sfm_info['max_extent']:.2f}m")
                    print(f"   GS点云尺寸: {gs_info['max_extent']:.2f}m")
                    print(f"   尺度比例 (GS/SFM): {ratio:.2f}x")
                    
                    print(f"\n💡 建议:")
                    print(f"   当前 radius_scale: {current_radius_scale:.4f}")
                    print(f"   推荐 radius_scale: {recommended:.4f}")
                    
                    if ratio > 1.5:
                        print(f"   🔴 GS点云比SFM大{ratio:.1f}倍，需要增加radius_scale!")
                    elif ratio < 0.7:
                        print(f"   🟡 GS点云比SFM小，可以考虑减小radius_scale")
                    else:
                        print(f"   ✅ 尺度基本一致")
                    
                    # 应用修复
                    if args.apply and ratio > 1.5:
                        print(f"\n【步骤5】应用修复...")
                        if update_sar_scale_params(args.dataset, recommended):
                            print(f"✅ 修复完成！")
                            print(f"\n下一步:")
                            print(f"  rm -rf {args.gs_output}")
                            print(f"  python train_sar_complete.py -s {args.dataset} -m output/fixed --iterations 5000")
                    elif args.apply:
                        print(f"\n尺度已经合理，无需修复")
    
    # 如果没有GS输出，只能给出经验建议
    else:
        print(f"\n【建议】（基于SFM点云）")
        print(f"SFM点云最大范围: {sfm_info['max_extent']:.2f}m")
        
        # 经验公式：目标范围应该是点云范围的10-20%
        target_size = 8.0  # 假设目标长度约8米（车辆/坦克）
        if sfm_info['max_extent'] > 100:
            print(f"⚠️  SFM点云范围过大（{sfm_info['max_extent']:.1f}m），可能有异常点")
            recommended_radius_scale = current_radius_scale * 2.0
        elif sfm_info['max_extent'] < 20:
            print(f"⚠️  SFM点云范围过小（{sfm_info['max_extent']:.1f}m），可能特征点不足")
            recommended_radius_scale = current_radius_scale * 0.5
        else:
            print(f"✅ SFM点云范围合理")
            # 保守估计：假设GS会变大1.5-2倍
            recommended_radius_scale = current_radius_scale * 1.5
        
        print(f"\n建议 radius_scale: {recommended_radius_scale:.4f}")
    
    # 手动指定
    if args.target_radius_scale:
        print(f"\n【手动设置】")
        print(f"指定 radius_scale = {args.target_radius_scale:.4f}")
        
        if args.apply:
            if update_sar_scale_params(args.dataset, args.target_radius_scale):
                print(f"✅ 已应用！")
    
    print("\n" + "="*70)
    print("诊断完成")
    print("="*70 + "\n")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

