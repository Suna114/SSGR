#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
修复depression_angle_mapping.json
只保留实际存在的图像
"""

import json
import os
import sys

def fix_mapping(dataset_path):
    """
    从映射文件中删除不存在的图像记录
    """
    # 1. 获取实际存在的图像
    images_dir = os.path.join(dataset_path, 'images')
    if not os.path.exists(images_dir):
        images_dir = os.path.join(dataset_path, 'input')
    
    actual_images = set()
    for f in os.listdir(images_dir):
        if f.lower().endswith(('.jpg', '.jpeg', '.png', '.tif', '.tiff')):
            # 去掉扩展名
            name_without_ext = os.path.splitext(f)[0]
            actual_images.add(name_without_ext)
            actual_images.add(f)  # 也保留带扩展名的
    
    print(f"实际图像数量: {len([f for f in os.listdir(images_dir) if f.endswith('.jpg')])}")
    
    # 2. 读取映射文件
    mapping_file = os.path.join(dataset_path, 'depression_angle_mapping.json')
    
    if not os.path.exists(mapping_file):
        print(f"找不到映射文件: {mapping_file}")
        return False
    
    with open(mapping_file, 'r', encoding='utf-8') as f:
        mapping = json.load(f)
    
    print(f"映射文件记录数: {len(mapping)}")
    
    # 3. 找出不存在的
    missing = []
    for img_name in mapping.keys():
        if img_name not in actual_images:
            missing.append(img_name)
    
    if not missing:
        print("✅ 映射文件中所有图像都存在")
        return True
    
    print(f"\n🔴 映射文件中有{len(missing)}个不存在的图像:")
    for m in missing:
        print(f"  - {m}")
    
    # 4. 备份并修复
    backup_file = mapping_file + '.backup'
    os.rename(mapping_file, backup_file)
    print(f"\n✅ 已备份到: {backup_file}")
    
    # 5. 删除不存在的记录
    for m in missing:
        del mapping[m]
    
    # 6. 保存
    with open(mapping_file, 'w', encoding='utf-8') as f:
        json.dump(mapping, f, indent=2, ensure_ascii=False)
    
    print(f"✅ 已更新映射文件")
    print(f"   修复前: {len(mapping) + len(missing)} 条记录")
    print(f"   修复后: {len(mapping)} 条记录")
    
    return True


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python fix_depression_mapping.py <dataset_path>")
        print("示例: python fix_depression_mapping.py data/24")
        sys.exit(1)
    
    dataset_path = sys.argv[1]
    
    print("\n" + "="*70)
    print("修复depression_angle_mapping.json")
    print("="*70 + "\n")
    
    if fix_mapping(dataset_path):
        print("\n✅ 修复完成！现在可以训练了：")
        print(f"   python train_sar_complete.py -s {dataset_path} -m output/test --iterations 1000")
    else:
        print("\n❌ 修复失败")
    
    print("="*70 + "\n")

