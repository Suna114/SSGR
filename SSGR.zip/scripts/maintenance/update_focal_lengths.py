#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
根据相机到场景中心的距离更新cameras.json中的焦距

用法:
    python update_focal_lengths.py <cameras.json路径> [点云ply路径]
    
示例:
    python update_focal_lengths.py ./output/sar_reconstruction1/cameras.json
    python update_focal_lengths.py ./output/sar_reconstruction1/cameras.json ./output/sar_reconstruction1/point_cloud/iteration_30000/point_cloud.ply
"""

import json
import numpy as np
import sys
import os

def load_ply_points(ply_path):
    """加载PLY点云文件，返回点的位置"""
    try:
        from plyfile import PlyData
        plydata = PlyData.read(ply_path)
        vertices = plydata['vertex']
        xyz = np.vstack([vertices['x'], vertices['y'], vertices['z']]).T
        print(f"  加载了 {len(xyz)} 个点")
        return xyz
    except Exception as e:
        print(f"  ⚠️ 加载PLY失败: {e}")
        return None

def update_focal_lengths(cameras_json_path, point_cloud_path=None):
    """
    根据相机到场景中心的距离更新焦距
    
    参数:
        cameras_json_path: cameras.json文件路径
        point_cloud_path: 点云PLY文件路径（可选，用于计算场景中心）
    """
    # 加载cameras.json
    print(f"\n📂 加载相机数据: {cameras_json_path}")
    with open(cameras_json_path, 'r') as f:
        cameras = json.load(f)
    
    print(f"  找到 {len(cameras)} 个相机")
    
    # 计算场景中心
    if point_cloud_path and os.path.exists(point_cloud_path):
        print(f"\n📍 从点云计算场景中心: {point_cloud_path}")
        xyz = load_ply_points(point_cloud_path)
        if xyz is not None:
            scene_center = np.mean(xyz, axis=0)
        else:
            # 使用相机位置的中心作为场景中心
            print("  使用相机位置中心作为场景中心")
            positions = np.array([c['position'] for c in cameras])
            scene_center = np.mean(positions, axis=0)
    else:
        # 使用相机位置的中心作为场景中心（假设相机围绕目标物体）
        print("\n📍 使用相机位置中心作为场景中心")
        positions = np.array([c['position'] for c in cameras])
        scene_center = np.mean(positions, axis=0)
    
    print(f"  场景中心: [{scene_center[0]:.4f}, {scene_center[1]:.4f}, {scene_center[2]:.4f}]")
    
    # 计算每个相机到场景中心的距离
    camera_distances = []
    for cam in cameras:
        pos = np.array(cam['position'])
        distance = np.linalg.norm(pos - scene_center)
        camera_distances.append(distance)
    
    camera_distances = np.array(camera_distances)
    
    # 计算基准距离（使用中位数）
    base_distance = np.median(camera_distances)
    
    # 获取基准焦距（使用当前焦距的中位数）
    base_focal_x = np.median([c['fx'] for c in cameras])
    base_focal_y = np.median([c['fy'] for c in cameras])
    
    print(f"\n📊 距离统计:")
    print(f"  基准距离（中位数）: {base_distance:.4f}")
    print(f"  距离范围: [{np.min(camera_distances):.4f}, {np.max(camera_distances):.4f}]")
    print(f"  距离标准差: {np.std(camera_distances):.4f}")
    
    print(f"\n📷 焦距统计（更新前）:")
    print(f"  基准焦距: fx={base_focal_x:.2f}, fy={base_focal_y:.2f}")
    
    # 更新每个相机的焦距
    updated_count = 0
    for i, cam in enumerate(cameras):
        distance = camera_distances[i]
        distance_ratio = distance / base_distance if base_distance > 0 else 1.0
        
        # 根据距离比例计算新焦距
        new_fx = base_focal_x * distance_ratio
        new_fy = base_focal_y * distance_ratio
        
        # 检查是否有变化
        if abs(new_fx - cam['fx']) > 0.01 or abs(new_fy - cam['fy']) > 0.01:
            updated_count += 1
        
        cam['fx'] = float(new_fx)
        cam['fy'] = float(new_fy)
    
    # 显示更新后的焦距统计
    fx_values = [c['fx'] for c in cameras]
    fy_values = [c['fy'] for c in cameras]
    
    print(f"\n📷 焦距统计（更新后）:")
    print(f"  焦距范围: fx=[{min(fx_values):.2f}, {max(fx_values):.2f}], fy=[{min(fy_values):.2f}, {max(fy_values):.2f}]")
    print(f"  焦距均值: fx={np.mean(fx_values):.2f}, fy={np.mean(fy_values):.2f}")
    print(f"  焦距标准差: fx={np.std(fx_values):.2f}, fy={np.std(fy_values):.2f}")
    
    print(f"\n✅ 更新了 {updated_count}/{len(cameras)} 个相机的焦距")
    
    # 显示前5个相机的详细信息
    print(f"\n📝 前5个相机的详细信息:")
    for i in range(min(5, len(cameras))):
        cam = cameras[i]
        dist = camera_distances[i]
        ratio = dist / base_distance if base_distance > 0 else 1.0
        print(f"  相机{i} ({cam['img_name']}): 距离={dist:.2f}, 比例={ratio:.3f}, fx={cam['fx']:.2f}, fy={cam['fy']:.2f}")
    
    # 保存更新后的cameras.json
    backup_path = cameras_json_path + '.backup'
    if not os.path.exists(backup_path):
        import shutil
        shutil.copy(cameras_json_path, backup_path)
        print(f"\n💾 已备份原文件到: {backup_path}")
    
    with open(cameras_json_path, 'w') as f:
        json.dump(cameras, f, indent=2)
    
    print(f"✅ 已保存更新后的cameras.json: {cameras_json_path}")
    
    return cameras

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    
    cameras_json_path = sys.argv[1]
    
    if not os.path.exists(cameras_json_path):
        print(f"❌ 文件不存在: {cameras_json_path}")
        sys.exit(1)
    
    # 尝试自动找到点云文件
    point_cloud_path = None
    if len(sys.argv) >= 3:
        point_cloud_path = sys.argv[2]
    else:
        # 尝试在同一目录下找点云文件
        output_dir = os.path.dirname(cameras_json_path)
        possible_paths = [
            os.path.join(output_dir, "point_cloud", "iteration_30000", "point_cloud.ply"),
            os.path.join(output_dir, "point_cloud", "iteration_7000", "point_cloud.ply"),
            os.path.join(output_dir, "input.ply"),
        ]
        for p in possible_paths:
            if os.path.exists(p):
                point_cloud_path = p
                break
    
    update_focal_lengths(cameras_json_path, point_cloud_path)

if __name__ == "__main__":
    main()

