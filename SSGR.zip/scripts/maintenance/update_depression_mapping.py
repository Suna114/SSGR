#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
更新depression_angle_mapping.json - 增量更新功能
支持：加入新记录、保留旧记录、覆盖冲突记录
"""

import json
import os
import sys
import glob
from sar_utils import parse_mstar_filename


def update_depression_mapping(dataset_path, 
                              cyclic_mode=True,
                              start_angle=15.0,
                              end_angle=45.0,
                              step=15.0,
                              force_overwrite=False):
    """
    更新depression_angle_mapping.json
    
    Args:
        dataset_path: 数据集路径
        cyclic_mode: 是否使用循环俯视角模式
        start_angle, end_angle, step: 循环参数
        force_overwrite: 是否强制覆盖整个文件
    
    Returns:
        True if成功
    """
    print("\n" + "="*70)
    print("更新depression_angle_mapping.json")
    print("="*70)
    
    # 1. 获取实际存在的图像
    images_dir = os.path.join(dataset_path, 'images')
    if not os.path.exists(images_dir):
        images_dir = os.path.join(dataset_path, 'input')
    
    if not os.path.exists(images_dir):
        print(f"错误: 找不到图像目录")
        return False
    
    # 扫描所有图像
    image_files = []
    for ext in ['*.jpg', '*.jpeg', '*.png', '*.tif', '*.tiff']:
        image_files.extend(glob.glob(os.path.join(images_dir, ext)))
    
    print(f"\n【步骤1】扫描图像文件")
    print(f"  图像目录: {images_dir}")
    print(f"  找到图像: {len(image_files)} 张")
    
    # 2. 解析每张图像的角度
    new_mapping = {}
    for img_path in image_files:
        img_name = os.path.basename(img_path)
        name_without_ext = os.path.splitext(img_name)[0]
        
        # 从文件名解析角度
        depression_angle, azimuth_angle = parse_mstar_filename(img_name)
        
        if cyclic_mode:
            # 使用循环俯视角
            angles = [start_angle, start_angle + step, end_angle]
            idx = len(new_mapping) % len(angles)
            assigned_angle = angles[idx]
        else:
            # 使用文件名中的原始角度
            assigned_angle = float(depression_angle)
        
        new_mapping[name_without_ext] = assigned_angle
    
    print(f"\n【步骤2】生成新映射")
    print(f"  模式: {'循环俯视角' if cyclic_mode else '原始角度'}")
    if cyclic_mode:
        print(f"  角度序列: {start_angle}° → {start_angle + step}° → {end_angle}°")
    print(f"  生成记录: {len(new_mapping)} 条")
    
    # 3. 加载旧映射（如果存在）
    mapping_file = os.path.join(dataset_path, 'depression_angle_mapping.json')
    old_mapping = {}
    
    if os.path.exists(mapping_file) and not force_overwrite:
        print(f"\n【步骤3】加载现有映射")
        with open(mapping_file, 'r', encoding='utf-8') as f:
            old_mapping = json.load(f)
        print(f"  现有记录: {len(old_mapping)} 条")
        
        # 备份
        backup_file = mapping_file + '.backup'
        with open(backup_file, 'w', encoding='utf-8') as f:
            json.dump(old_mapping, f, indent=2, ensure_ascii=False)
        print(f"  ✅ 已备份到: {backup_file}")
    else:
        print(f"\n【步骤3】创建新映射（无现有文件）")
    
    # 4. 合并：新记录覆盖旧记录
    merged_mapping = old_mapping.copy()
    
    added = 0
    updated = 0
    for key, value in new_mapping.items():
        if key in merged_mapping:
            if merged_mapping[key] != value:
                print(f"  更新: {key}: {merged_mapping[key]}° → {value}°")
                updated += 1
            merged_mapping[key] = value
        else:
            print(f"  新增: {key}: {value}°")
            added += 1
            merged_mapping[key] = value
    
    # 5. 删除不存在的图像记录
    removed = 0
    to_remove = []
    actual_names = set(new_mapping.keys())
    
    for key in merged_mapping.keys():
        if key not in actual_names:
            to_remove.append(key)
    
    for key in to_remove:
        print(f"  删除: {key} (图像不存在)")
        del merged_mapping[key]
        removed += 1
    
    print(f"\n【步骤4】合并结果")
    print(f"  新增: {added} 条")
    print(f"  更新: {updated} 条")
    print(f"  删除: {removed} 条")
    print(f"  最终: {len(merged_mapping)} 条记录")
    
    # 6. 保存
    with open(mapping_file, 'w', encoding='utf-8') as f:
        json.dump(merged_mapping, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ 已保存到: {mapping_file}")
    
    # 7. 验证
    print(f"\n【验证】")
    print(f"  实际图像: {len(image_files)} 张")
    print(f"  映射记录: {len(merged_mapping)} 条")
    
    if len(image_files) == len(merged_mapping):
        print(f"  ✅ 数量一致！")
    else:
        print(f"  ⚠️  数量不一致")
    
    return True


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='更新depression_angle_mapping.json')
    parser.add_argument('-s', '--source_path', required=True, help='数据集路径')
    parser.add_argument('--cyclic', action='store_true', default=True,
                       help='使用循环俯视角模式（默认启用）')
    parser.add_argument('--no_cyclic', dest='cyclic', action='store_false',
                       help='使用文件名中的原始角度')
    parser.add_argument('--start_angle', type=float, default=15.0,
                       help='循环起始角度（默认15°）')
    parser.add_argument('--end_angle', type=float, default=45.0,
                       help='循环结束角度（默认45°）')
    parser.add_argument('--step', type=float, default=15.0,
                       help='循环步长（默认15°）')
    parser.add_argument('--force', action='store_true',
                       help='强制覆盖（不保留旧记录）')
    
    args = parser.parse_args()
    
    if update_depression_mapping(
        args.source_path,
        cyclic_mode=args.cyclic,
        start_angle=args.start_angle,
        end_angle=args.end_angle,
        step=args.step,
        force_overwrite=args.force
    ):
        print("\n✅ 更新完成！可以开始训练：")
        print(f"   python train_sar_complete.py -s {args.source_path} -m output/test --iterations 1000")
    else:
        print("\n❌ 更新失败")
    
    print("="*70 + "\n")


if __name__ == "__main__":
    main()

