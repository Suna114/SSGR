#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
快速对比示例脚本
用于快速测试点云与模型的对比功能
"""

import os
import sys
from compare_pointcloud_with_model import (
    load_point_cloud, load_model, get_bounding_box,
    calculate_scale_factor, scale_geometry, align_geometries,
    visualize_comparison, save_aligned_point_cloud
)
import numpy as np
import open3d as o3d


def quick_compare(pointcloud_path, model_path, output_path=None, scale_factor=None):
    """
    快速对比函数
    
    Args:
        pointcloud_path: 点云文件路径
        model_path: 模型文件路径
        output_path: 输出路径（可选）
        scale_factor: 缩放因子（可选，None表示自动计算）
    """
    print("=" * 60)
    print("🚀 快速对比模式")
    print("=" * 60)
    
    # 加载文件
    print("\n📂 加载文件...")
    point_cloud = load_point_cloud(pointcloud_path)
    model = load_model(model_path)
    
    # 获取尺寸信息
    print("\n📐 分析尺寸...")
    pc_bbox = get_bounding_box(point_cloud)
    model_bbox = get_bounding_box(model)
    
    print(f"\n点云边界框:")
    print(f"  最小: [{pc_bbox['min'][0]:.4f}, {pc_bbox['min'][1]:.4f}, {pc_bbox['min'][2]:.4f}]")
    print(f"  最大: [{pc_bbox['max'][0]:.4f}, {pc_bbox['max'][1]:.4f}, {pc_bbox['max'][2]:.4f}]")
    print(f"  尺寸: [{pc_bbox['size'][0]:.4f}, {pc_bbox['size'][1]:.4f}, {pc_bbox['size'][2]:.4f}]")
    print(f"  中心: [{pc_bbox['center'][0]:.4f}, {pc_bbox['center'][1]:.4f}, {pc_bbox['center'][2]:.4f}]")
    
    print(f"\n模型边界框:")
    print(f"  最小: [{model_bbox['min'][0]:.4f}, {model_bbox['min'][1]:.4f}, {model_bbox['min'][2]:.4f}]")
    print(f"  最大: [{model_bbox['max'][0]:.4f}, {model_bbox['max'][1]:.4f}, {model_bbox['max'][2]:.4f}]")
    print(f"  尺寸: [{model_bbox['size'][0]:.4f}, {model_bbox['size'][1]:.4f}, {model_bbox['size'][2]:.4f}]")
    print(f"  中心: [{model_bbox['center'][0]:.4f}, {model_bbox['center'][1]:.4f}, {model_bbox['center'][2]:.4f}]")
    
    # 计算缩放因子
    if scale_factor is None:
        print("\n🔍 自动计算缩放因子...")
        scale_factor = calculate_scale_factor(pc_bbox, model_bbox, 'fit')
        print(f"\n💡 建议的缩放因子: {scale_factor:.6f}")
        print(f"   这意味着点云需要缩放 {scale_factor:.6f} 倍才能匹配模型大小")
        
        if scale_factor < 1.0:
            print(f"   （点云将被缩小 {1.0/scale_factor:.2f} 倍）")
        else:
            print(f"   （点云将被放大 {scale_factor:.2f} 倍）")
    else:
        print(f"\n📐 使用指定的缩放因子: {scale_factor:.6f}")
    
    # 询问用户是否继续
    print("\n" + "=" * 60)
    response = input("是否继续缩放和对齐？(y/n): ").strip().lower()
    if response != 'y':
        print("已取消操作")
        return
    
    # 缩放点云
    print("\n🔄 缩放点云...")
    pc_center = pc_bbox['center']
    point_cloud = scale_geometry(point_cloud, scale_factor, pc_center)
    
    # 更新边界框
    pc_bbox = get_bounding_box(point_cloud)
    print(f"   缩放后尺寸: [{pc_bbox['size'][0]:.4f}, {pc_bbox['size'][1]:.4f}, {pc_bbox['size'][2]:.4f}]")
    
    # 对齐
    print("\n🔄 对齐几何体...")
    point_cloud = align_geometries(point_cloud, model, 'center')
    
    # 保存
    if output_path:
        save_aligned_point_cloud(point_cloud, output_path)
    
    # 可视化
    print("\n🎨 打开可视化窗口...")
    visualize_comparison(point_cloud, model)
    
    print("\n" + "=" * 60)
    print("✅ 完成！")
    print("=" * 60)


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("使用方法:")
        print(f"  python {sys.argv[0]} <点云路径> <模型路径> [输出路径] [缩放因子]")
        print("\n示例:")
        print(f"  python {sys.argv[0]} pointcloud.ply T72_model.ply")
        print(f"  python {sys.argv[0]} pointcloud.ply T72_model.ply aligned.ply")
        print(f"  python {sys.argv[0]} pointcloud.ply T72_model.ply aligned.ply 0.001")
        sys.exit(1)
    
    pointcloud_path = sys.argv[1]
    model_path = sys.argv[2]
    output_path = sys.argv[3] if len(sys.argv) > 3 else None
    scale_factor = float(sys.argv[4]) if len(sys.argv) > 4 else None
    
    quick_compare(pointcloud_path, model_path, output_path, scale_factor)

