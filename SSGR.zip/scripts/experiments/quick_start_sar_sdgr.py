# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
SAR-GS快速启动脚本（Python版SDGR）
快速验证SAR渲染功能
"""

import argparse
import subprocess
import sys
from pathlib import Path

def check_dependencies():
    """检查依赖"""
    print("检查依赖...")
    
    required_modules = [
        "torch",
        "numpy",
        "PIL",
        "tqdm"
    ]
    
    missing = []
    for module in required_modules:
        try:
            __import__(module)
            print(f"  ✅ {module}")
        except ImportError:
            print(f"  ❌ {module}")
            missing.append(module)
    
    if missing:
        print(f"\n缺少依赖: {', '.join(missing)}")
        print("请运行: pip install " + " ".join(missing))
        return False
    
    return True


def check_sar_modules():
    """检查SAR模块"""
    print("\n检查SAR模块...")
    
    modules = [
        ("sar_gaussian_projection", "SAR投影模块"),
        ("sar_sdgr_renderer", "SDGR渲染器"),
        ("sar_geometry", "SAR几何模块")
    ]
    
    all_ok = True
    for module_name, desc in modules:
        try:
            __import__(module_name)
            print(f"  ✅ {desc}")
        except ImportError as e:
            print(f"  ❌ {desc}: {e}")
            all_ok = False
    
    return all_ok


def run_tests():
    """运行测试"""
    print("\n运行SAR渲染测试...")
    
    try:
        result = subprocess.run(
            [sys.executable, "test_sar_rendering.py"],
            check=False,
            capture_output=False
        )
        return result.returncode == 0
    except Exception as e:
        print(f"测试失败: {e}")
        return False


def print_usage_examples():
    """打印使用示例"""
    print("\n" + "="*60)
    print("使用示例")
    print("="*60)
    
    examples = [
        (
            "标准SAR训练",
            "python train.py -s /path/to/sar_dataset -m /path/to/output --sar_rendering"
        ),
        (
            "MSTAR数据集训练",
            """python train.py \\
    -s /path/to/mstar_dataset \\
    -m /path/to/output \\
    --sar_mode \\
    --sar_rendering \\
    --sar_camera_height 12000.0 \\
    --sar_camera_distribution_mode sphere \\
    --iterations 30000"""
        ),
        (
            "快速测试（低分辨率）",
            "python train.py -s /path/to/dataset -m /path/to/output --sar_rendering --resolution 256 --iterations 1000"
        )
    ]
    
    for i, (title, cmd) in enumerate(examples, 1):
        print(f"\n{i}. {title}:")
        print(f"   {cmd}")
    
    print("\n" + "="*60)


def main():
    parser = argparse.ArgumentParser(description="SAR-GS快速启动")
    parser.add_argument("--check-only", action="store_true",
                      help="仅检查环境，不运行测试")
    parser.add_argument("--run-tests", action="store_true",
                      help="运行完整测试套件")
    parser.add_argument("--show-examples", action="store_true",
                      help="显示使用示例")
    
    args = parser.parse_args()
    
    print("="*60)
    print("SAR-GS Python版SDGR快速启动")
    print("="*60)
    
    # 检查依赖
    if not check_dependencies():
        return 1
    
    # 检查SAR模块
    if not check_sar_modules():
        print("\n❌ SAR模块不完整")
        return 1
    
    print("\n✅ 所有模块检查通过")
    
    if args.check_only:
        print("\n环境检查完成。")
        return 0
    
    # 运行测试
    if args.run_tests or (not args.show_examples):
        if run_tests():
            print("\n✅ 所有测试通过！")
        else:
            print("\n⚠️ 部分测试失败，但可以继续使用。")
    
    # 显示使用示例
    if args.show_examples or (not args.run_tests):
        print_usage_examples()
    
    print("\n🎉 SAR-GS Python版SDGR已就绪！")
    print("\n详细文档: SAR_SDGR_使用说明.md")
    print("测试脚本: python test_sar_rendering.py")
    
    return 0


if __name__ == "__main__":
    exit(main())

