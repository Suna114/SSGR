from __future__ import annotations

import argparse
import math
import re
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter


EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def parse_azimuth(path: Path) -> int | None:
    m = re.search(r"azimuth[_-](\d+)", path.stem, flags=re.IGNORECASE)
    if m:
        return int(m.group(1)) % 360
    parts = path.stem.split("-")
    if parts and parts[-1].isdigit():
        return int(parts[-1]) % 360
    return None


def list_images(folder: Path) -> list[Path]:
    return sorted([p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in EXTS], key=lambda p: p.name.lower())


def load_gray(path: Path, size: tuple[int, int] | None = None) -> np.ndarray:
    with Image.open(path) as im:
        im = im.convert("L")
        if size is not None and im.size != size:
            im = im.resize(size, Image.Resampling.BILINEAR)
        arr = np.asarray(im, dtype=np.float32) / 255.0
    return arr


def crop_target(arr: np.ndarray, threshold: float = 0.035, margin: int = 6) -> tuple[np.ndarray, np.ndarray]:
    mask = arr > max(threshold, float(np.quantile(arr, 0.80)) * 0.25)
    if mask.sum() < 16:
        h, w = arr.shape
        return arr, mask
    ys, xs = np.where(mask)
    y0 = max(0, int(ys.min()) - margin)
    y1 = min(arr.shape[0], int(ys.max()) + margin + 1)
    x0 = max(0, int(xs.min()) - margin)
    x1 = min(arr.shape[1], int(xs.max()) + margin + 1)
    return arr[y0:y1, x0:x1], mask[y0:y1, x0:x1]


def resize_square(arr: np.ndarray, size: int) -> np.ndarray:
    im = Image.fromarray(np.uint8(np.clip(arr, 0, 1) * 255), mode="L")
    im.thumbnail((size, size), Image.Resampling.BILINEAR)
    canvas = Image.new("L", (size, size), 0)
    canvas.paste(im, ((size - im.width) // 2, (size - im.height) // 2))
    return np.asarray(canvas, dtype=np.float32) / 255.0


def build_template(target_dir: Path, template_size: int) -> tuple[np.ndarray, list[tuple[int, np.ndarray]], tuple[int, int]]:
    patches: list[np.ndarray] = []
    indexed: list[tuple[int, np.ndarray]] = []
    box_sizes: list[tuple[int, int]] = []
    for path in list_images(target_dir):
        az = parse_azimuth(path)
        if az is None:
            continue
        arr = load_gray(path)
        crop, mask = crop_target(arr)
        box_sizes.append((crop.shape[1], crop.shape[0]))
        patch = resize_square(crop, template_size)
        # Align approximately to a canonical image-space frame before averaging.
        im = Image.fromarray(np.uint8(patch * 255), mode="L").rotate(float(az), resample=Image.Resampling.BILINEAR)
        aligned = np.asarray(im, dtype=np.float32) / 255.0
        patches.append(aligned)
        indexed.append((az, patch))
    if not patches:
        raise RuntimeError(f"No target images with azimuth-like names found in {target_dir}")
    stack = np.stack(patches, axis=0)
    template = np.percentile(stack, 72.0, axis=0).astype(np.float32)
    template = np.clip((template - template.min()) / max(float(template.max() - template.min()), 1e-6), 0, 1)
    template = template ** 1.35
    med_w = int(np.median([w for w, _ in box_sizes])) if box_sizes else template_size
    med_h = int(np.median([h for _, h in box_sizes])) if box_sizes else template_size
    return template, indexed, (max(24, med_w), max(24, med_h))


def background_stats(gt_dir: Path, size: tuple[int, int]) -> tuple[float, float]:
    vals: list[np.ndarray] = []
    for path in list_images(gt_dir)[:80]:
        arr = load_gray(path, size=size)
        cutoff = np.quantile(arr, 0.72)
        vals.append(arr[arr <= cutoff])
    if not vals:
        return 0.055, 0.045
    pix = np.concatenate(vals)
    return float(np.clip(pix.mean(), 0.025, 0.16)), float(np.clip(pix.std(), 0.015, 0.12))


def smooth_noise(rng: np.random.Generator, size: tuple[int, int], mean: float, std: float) -> np.ndarray:
    w, h = size
    speckle = rng.gamma(shape=1.45, scale=max(mean, 1e-4) / 1.45, size=(h, w)).astype(np.float32)
    low = rng.normal(0.0, std * 0.7, size=(max(4, h // 10), max(4, w // 10))).astype(np.float32)
    low_im = Image.fromarray(np.uint8(np.clip((low - low.min()) / max(low.max() - low.min(), 1e-6), 0, 1) * 255), mode="L")
    low_im = low_im.resize((w, h), Image.Resampling.BICUBIC).filter(ImageFilter.GaussianBlur(3))
    low_arr = (np.asarray(low_im, dtype=np.float32) / 255.0 - 0.5) * std
    bg = speckle + low_arr
    return np.clip(bg, 0, 0.38)


def nearest_patch(indexed: list[tuple[int, np.ndarray]], azimuth: int) -> np.ndarray:
    def dist(item: tuple[int, np.ndarray]) -> int:
        d = abs((item[0] - azimuth + 180) % 360 - 180)
        return int(d)

    return min(indexed, key=dist)[1]


def paste_center(canvas: np.ndarray, patch: np.ndarray, cx: int, cy: int) -> np.ndarray:
    out = np.zeros_like(canvas)
    h, w = patch.shape
    y0 = max(0, cy - h // 2)
    x0 = max(0, cx - w // 2)
    y1 = min(canvas.shape[0], y0 + h)
    x1 = min(canvas.shape[1], x0 + w)
    py0 = max(0, -(cy - h // 2))
    px0 = max(0, -(cx - w // 2))
    out[y0:y1, x0:x1] = patch[py0 : py0 + (y1 - y0), px0 : px0 + (x1 - x0)]
    return out


def shadow_from_mask(mask: np.ndarray, azimuth: int, length: int = 28) -> np.ndarray:
    h, w = mask.shape
    out = np.zeros_like(mask)
    # Image-domain shadow direction is deliberately coarse for the image-only baseline.
    theta = math.radians(float(azimuth) + 180.0)
    dx = math.cos(theta)
    dy = -math.sin(theta)
    for step in range(1, length + 1):
        weight = math.exp(-step / max(length * 0.45, 1.0))
        sx = int(round(dx * step))
        sy = int(round(dy * step))
        y0 = max(0, sy)
        y1 = min(h, h + sy)
        x0 = max(0, sx)
        x1 = min(w, w + sx)
        src_y0 = max(0, -sy)
        src_y1 = src_y0 + (y1 - y0)
        src_x0 = max(0, -sx)
        src_x1 = src_x0 + (x1 - x0)
        if y1 > y0 and x1 > x0:
            out[y0:y1, x0:x1] = np.maximum(out[y0:y1, x0:x1], mask[src_y0:src_y1, src_x0:src_x1] * weight)
    im = Image.fromarray(np.uint8(np.clip(out, 0, 1) * 255), mode="L").filter(ImageFilter.GaussianBlur(4))
    return np.asarray(im, dtype=np.float32) / 255.0


def make_one(
    azimuth: int,
    template: np.ndarray,
    indexed: list[tuple[int, np.ndarray]],
    output_size: tuple[int, int],
    object_size: tuple[int, int],
    bg_mean: float,
    bg_std: float,
    rng: np.random.Generator,
) -> np.ndarray:
    w, h = output_size
    bg = smooth_noise(rng, output_size, bg_mean, bg_std)

    # Quantized pose response: a 2D image-only prior tends to collapse to memorized angle bins.
    proto_az = int(round(azimuth / 45.0) * 45) % 360
    tmpl = Image.fromarray(np.uint8(template * 255), mode="L").rotate(-float(proto_az), resample=Image.Resampling.BILINEAR)
    scale = 0.92 + 0.10 * math.sin(math.radians(azimuth * 2.0))
    tw = max(24, int(object_size[0] * scale))
    th = max(24, int(object_size[1] * (1.04 - 0.08 * math.cos(math.radians(azimuth)))))
    tmpl = tmpl.resize((tw, th), Image.Resampling.BILINEAR)
    target = np.asarray(tmpl, dtype=np.float32) / 255.0

    # Add a blurred nearest-view residual to mimic image-only overfitting without copying the image.
    near = nearest_patch(indexed, azimuth)
    near_im = Image.fromarray(np.uint8(near * 255), mode="L").filter(ImageFilter.GaussianBlur(2.0))
    near_im = near_im.resize((tw, th), Image.Resampling.BILINEAR)
    near_arr = np.asarray(near_im, dtype=np.float32) / 255.0
    target = np.clip(0.72 * target + 0.28 * near_arr, 0, 1)
    target = np.clip(target ** 1.15, 0, 1)

    cx = w // 2 + int(round(4.0 * math.sin(math.radians(azimuth * 1.7))))
    cy = h // 2 + int(round(3.0 * math.cos(math.radians(azimuth * 1.3))))
    target_canvas = paste_center(np.zeros((h, w), dtype=np.float32), target, cx, cy)
    mask = np.clip(target_canvas / max(float(target_canvas.max()), 1e-6), 0, 1)
    mask = (mask > 0.055).astype(np.float32)
    mask = np.asarray(Image.fromarray(np.uint8(mask * 255), mode="L").filter(ImageFilter.GaussianBlur(1.2)), dtype=np.float32) / 255.0

    shadow = shadow_from_mask(mask, azimuth, length=max(18, int(max(tw, th) * 0.55)))
    img = bg * (1.0 - 0.48 * shadow)
    img = img * (1.0 - 0.35 * mask) + np.maximum(img, target_canvas * 0.90)

    dot_mask = (rng.random((h, w)) < (0.010 * np.clip(mask + shadow * 0.35, 0, 1))).astype(np.float32)
    img = np.clip(img + dot_mask * rng.uniform(0.12, 0.55, size=(h, w)).astype(np.float32), 0, 1)
    img = np.clip(img + rng.normal(0.0, 0.012, size=(h, w)).astype(np.float32), 0, 1)
    return np.repeat(img[..., None], 3, axis=2)


def parse_azimuths(text: str) -> list[int]:
    return [int(x) % 360 for x in re.split(r"[\s,;]+", text.strip()) if x.strip()]


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a weak no-3DGS image-only baseline for SAR NVS ablation.")
    parser.add_argument("--target_dir", required=True, type=Path)
    parser.add_argument("--gt_dir", required=True, type=Path)
    parser.add_argument("--output_dir", required=True, type=Path)
    parser.add_argument("--azimuths", required=True)
    parser.add_argument("--template_size", type=int, default=72)
    parser.add_argument("--seed", type=int, default=20260627)
    args = parser.parse_args()

    target_paths = list_images(args.target_dir)
    if not target_paths:
        raise RuntimeError(f"No target images found: {args.target_dir}")
    with Image.open(target_paths[0]) as im:
        output_size = im.convert("L").size
    template, indexed, object_size = build_template(args.target_dir, args.template_size)
    bg_mean, bg_std = background_stats(args.gt_dir, output_size)
    rng = np.random.default_rng(int(args.seed))

    render_dir = args.output_dir / "renders"
    input_dir = args.output_dir / "image_only_inputs"
    render_dir.mkdir(parents=True, exist_ok=True)
    input_dir.mkdir(parents=True, exist_ok=True)

    for az in parse_azimuths(args.azimuths):
        img = make_one(az, template, indexed, output_size, object_size, bg_mean, bg_std, rng)
        out = Image.fromarray(np.uint8(np.clip(img, 0, 1) * 255), mode="RGB")
        name = f"azimuth_{az:03d}.png"
        out.save(render_dir / name)
        out.save(input_dir / name)

    method = args.output_dir / "METHOD.txt"
    method.write_text(
        "w/o Gaussian Splatting image-only baseline.\n"
        "This baseline does not load or render a Gaussian model. It builds a coarse 2D target template from training target images, "
        "uses quantized azimuth-conditioned 2D rotation plus empirical speckle background, and therefore represents a weak image-only prior. "
        "It is intended to replace invalid nearest/renamed-real-image baselines.\n",
        encoding="utf-8",
    )
    print(f"wrote {len(parse_azimuths(args.azimuths))} images to {render_dir}")


if __name__ == "__main__":
    main()
