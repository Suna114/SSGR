# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
SAR-GS集成示例
展示如何将SAR-GS投影算法集成到现有的gaussian-splatting代码中
"""
import numpy as np
import torch
from sar_gaussian_projection import (
    SARProjectionMatrices,
    SARGaussianProjection,
    SARScatteringIntensity,
    create_sar_projection_from_params
)
from sar_geometry import DEFAULT_SAR_PARAMS


def example_basic_projection():
    """示例1：基本投影操作"""
    print("=" * 60)
    print("示例1：基本SAR投影操作")
    print("=" * 60)
    
    # 设置SAR参数
    sar_params = DEFAULT_SAR_PARAMS.copy()
    sar_params['Na'] = 512
    sar_params['Nr'] = 512
    
    # 创建投影对象
    proj_matrices, gaussian_proj = create_sar_projection_from_params(
        sar_params, 
        depression_angle=45.0,
        azimuth_angle=0.0
    )
    
    # 测试3D点投影
    points_3d = np.array([
        [1.0, 2.0, 3.0],
        [4.0, 5.0, 6.0],
        [10.0, 20.0, 30.0]
    ])
    
    print(f"\n原始3D点:\n{points_3d}")
    
    # 投影到计算平面
    points_2d_computation = proj_matrices.project_to_computation_plane(points_3d)
    print(f"\n投影到计算平面:\n{points_2d_computation}")
    
    # 投影到成像平面
    points_2d_imaging = proj_matrices.project_to_imaging_plane(points_3d)
    print(f"\n投影到成像平面:\n{points_2d_imaging}")


def example_covariance_projection():
    """示例2：协方差矩阵投影"""
    print("\n" + "=" * 60)
    print("示例2：3D高斯协方差矩阵投影")
    print("=" * 60)
    
    sar_params = DEFAULT_SAR_PARAMS.copy()
    sar_params['Na'] = 512
    sar_params['Nr'] = 512
    
    _, gaussian_proj = create_sar_projection_from_params(
        sar_params,
        depression_angle=45.0,
        azimuth_angle=0.0
    )
    
    # 创建3D协方差矩阵（示例：各向同性高斯）
    Sigma_3d = np.eye(3) * 0.1  # 3x3协方差矩阵
    
    print(f"\n原始3D协方差矩阵:\n{Sigma_3d}")
    
    # 投影到2D
    Sigma_2d = gaussian_proj.project_covariance(Sigma_3d)
    print(f"\n投影后的2D协方差矩阵:\n{Sigma_2d}")
    
    # 批量投影（PyTorch版本）
    Sigma_3d_batch = torch.eye(3).unsqueeze(0).repeat(5, 1, 1) * 0.1
    Sigma_2d_batch = gaussian_proj.project_covariance_batch(Sigma_3d_batch)
    print(f"\n批量投影结果形状: {Sigma_2d_batch.shape}")
    print(f"第一个2D协方差矩阵:\n{Sigma_2d_batch[0].numpy()}")


def example_scattering_intensity():
    """示例3：散射强度计算"""
    print("\n" + "=" * 60)
    print("示例3：SAR散射强度计算")
    print("=" * 60)
    
    # 创建散射强度计算器
    scattering_calc = SARScatteringIntensity(use_attenuation=True)
    
    # 示例数据
    gaussian_intensity = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    depth = np.array([10.0, 20.0, 30.0, 40.0, 50.0])
    
    print(f"\n基础高斯强度: {gaussian_intensity}")
    print(f"深度: {depth}")
    
    # 计算散射强度
    scattering_intensity = scattering_calc.compute_scattering_intensity(
        gaussian_intensity, depth
    )
    
    print(f"\n计算后的散射强度: {scattering_intensity}")
    print(f"衰减因子: {scattering_intensity / gaussian_intensity}")
    
    # PyTorch版本
    intensity_tensor = torch.tensor(gaussian_intensity)
    depth_tensor = torch.tensor(depth)
    scattering_tensor = scattering_calc.compute_scattering_intensity_batch(
        intensity_tensor, depth_tensor
    )
    print(f"\nPyTorch版本散射强度: {scattering_tensor.numpy()}")


def example_integration_with_gaussian_model():
    """示例4：与GaussianModel集成"""
    print("\n" + "=" * 60)
    print("示例4：与GaussianModel集成（伪代码）")
    print("=" * 60)
    
    print("""
    在实际集成中，你需要：
    
    1. 修改GaussianModel以支持SAR投影：
       - 在计算协方差矩阵时，使用SAR投影
       - 在渲染前，将3D协方差投影到2D
    
    2. 修改渲染器：
       - 检测是否使用SAR模式
       - 应用SAR投影矩阵
       - 计算SAR散射强度
    
    3. 修改训练循环：
       - 传递SAR参数
       - 使用SAR特定的损失函数
    
    示例代码结构：
    
    ```python
    # 在训练循环中
    for iteration in range(iterations):
        # 选择相机
        viewpoint_cam = scene.getTrainCameras()[cam_idx]
        
        # 如果使用SAR投影
        if viewpoint_cam.use_sar:
            # 创建SAR投影对象
            proj_matrices, gaussian_proj = create_sar_projection_from_params(
                viewpoint_cam.sar_params,
                viewpoint_cam.depression_angle,
                viewpoint_cam.azimuth_angle
            )
            
            # 投影高斯协方差矩阵
            # （需要在GaussianModel中实现）
            
            # 计算散射强度
            # （需要在渲染器中实现）
        
        # 渲染
        render(viewpoint_cam, gaussians, ...)
    ```
    """)


def example_projection_matrices_details():
    """示例5：投影矩阵详细说明"""
    print("\n" + "=" * 60)
    print("示例5：投影矩阵详细说明")
    print("=" * 60)
    
    sar_params = DEFAULT_SAR_PARAMS.copy()
    sar_params['Na'] = 512
    sar_params['Nr'] = 512
    
    proj_matrices, _ = create_sar_projection_from_params(
        sar_params,
        depression_angle=45.0,
        azimuth_angle=0.0
    )
    
    print("\n计算平面投影矩阵 P_C:")
    print(proj_matrices.P_C)
    
    print("\n成像平面投影矩阵 P_I:")
    print(proj_matrices.P_I)
    
    print("\n参数说明:")
    print(f"  方位向分辨率 ΔA: {proj_matrices.delta_A:.6f} m/pixel")
    print(f"  距离向分辨率 ΔR: {proj_matrices.delta_R:.6f} m/pixel")
    print(f"  方位向像素数 N_A: {proj_matrices.N_A}")
    print(f"  距离向像素数 N_R: {proj_matrices.N_R}")
    print(f"  擦地角 θ: {np.rad2deg(proj_matrices.theta):.2f}°")
    print(f"  高度参数 h: {proj_matrices.h:.2f} m")


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("SAR-GS集成示例")
    print("=" * 60)
    
    # 运行所有示例
    example_basic_projection()
    example_covariance_projection()
    example_scattering_intensity()
    example_integration_with_gaussian_model()
    example_projection_matrices_details()
    
    print("\n" + "=" * 60)
    print("示例完成！")
    print("=" * 60)
    print("\n更多信息请参考 SAR_GS_INTEGRATION.md")

