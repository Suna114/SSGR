# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
简单的scene_scale计算工具（不依赖numpy）

根据已知的scene_scale和相机高度，计算新的scene_scale值
例如：scene_scale=0.1时相机高度≈500m，要得到30m的相机高度
"""

import math

def calculate_scene_scale_from_height(
    current_scene_scale=0.1,      # 当前scene_scale值
    current_camera_height=500.0,  # 当前相机高度（米）
    target_camera_height=30.0     # 目标相机高度（米）
):
    """
    根据已知的scene_scale和相机高度，计算新的scene_scale值
    
    scene_scale与相机高度成线性关系：
    新scene_scale = 当前scene_scale × (目标高度 / 当前高度)
    """
    print("="*70)
    print("根据已知scene_scale计算新的scene_scale值")
    print("="*70)
    print(f"\n已知信息:")
    print(f"  - 当前scene_scale: {current_scene_scale}")
    print(f"  - 当前相机高度: {current_camera_height} 米")
    print(f"  - 目标相机高度: {target_camera_height} 米")
    
    # 计算比例关系
    height_ratio = target_camera_height / current_camera_height
    new_scene_scale = current_scene_scale * height_ratio
    
    print(f"\n计算过程:")
    print(f"  高度比例 = 目标高度 / 当前高度")
    print(f"  高度比例 = {target_camera_height:.2f} / {current_camera_height:.2f}")
    print(f"  高度比例 = {height_ratio:.6f}")
    print(f"\n  新scene_scale = 当前scene_scale × 高度比例")
    print(f"  新scene_scale = {current_scene_scale:.6f} × {height_ratio:.6f}")
    print(f"  新scene_scale = {new_scene_scale:.6f}")
    
    print(f"\n" + "="*70)
    print("结果")
    print("="*70)
    print(f"\n✅ 新的scene_scale值: {new_scene_scale:.6f}")
    print(f"\n命令行参数:")
    print(f"  --sar_scene_scale {new_scene_scale:.6f}")
    
    print(f"\n完整示例命令:")
    print(f"  python sfm.py --sar_scene_scale {new_scene_scale:.6f} \\")
    print(f"                 --sfm_scale_constraint_resolution 0.3 \\")
    print(f"                 --sfm_scale_constraint_pixel_width 128 \\")
    print(f"                 --sfm_scale_constraint_pixel_height 128")
    
    print(f"\n" + "="*70)
    print("说明")
    print("="*70)
    print(f"  1. scene_scale值越小，相机高度越小（相机越近）")
    print(f"  2. 当前: scene_scale={current_scene_scale:.6f} → 相机高度≈{current_camera_height:.0f}米")
    print(f"  3. 新值: scene_scale={new_scene_scale:.6f} → 相机高度≈{target_camera_height:.0f}米")
    print(f"  4. 实际高度可能因俯视角不同而略有变化，但比例关系保持不变")
    
    return new_scene_scale


if __name__ == "__main__":
    # 默认计算：从0.1（500m）到30m
    new_scene_scale = calculate_scene_scale_from_height(
        current_scene_scale=0.1,
        current_camera_height=500.0,
        target_camera_height=30.0
    )
    
    print(f"\n" + "="*70)
    print("快速参考")
    print("="*70)
    print(f"\n如果 scene_scale=0.1 对应相机高度≈500m")
    print(f"那么 scene_scale={new_scene_scale:.6f} 对应相机高度≈30m")
    print(f"\n比例关系: scene_scale × 5000 ≈ 相机高度（米）")
    print(f"验证: {new_scene_scale:.6f} × 5000 ≈ {new_scene_scale * 5000:.2f} 米")





