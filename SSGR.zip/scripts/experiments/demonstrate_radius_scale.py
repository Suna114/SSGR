#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
演示 radius_scale 的作用和计算过程
"""

import numpy as np

print("="*70)
print("radius_scale 自动缩放因子演示")
print("="*70)

# ========== 参数设置 ==========
print("\n【步骤1】输入参数")
print("-"*70)

camera_height = 12000  # 米（MSTAR数据集）
depression_angle = 15  # 度
image_size = 512  # 像素
scene_scale = 10.0  # 默认场景倍数

print(f"SAR系统参数:")
print(f"  - 相机高度: {camera_height} m")
print(f"  - 俯视角: {depression_angle}°")
print(f"  - 图像尺寸: {image_size} × {image_size} 像素")
print(f"  - 场景倍数: {scene_scale}")

# ========== 计算真实物理距离 ==========
print("\n【步骤2】计算真实物理距离（无缩放）")
print("-"*70)

dep_rad = np.deg2rad(depression_angle)
R0 = camera_height / np.sin(dep_rad)

print(f"参考斜距 R0 = camera_height / sin(depression_angle)")
print(f"           = {camera_height} / sin({depression_angle}°)")
print(f"           = {camera_height} / {np.sin(dep_rad):.4f}")
print(f"           = {R0:.2f} m")

azi_rad = 0  # 方位角0度（朝向X轴正方向）
x_true = R0 * np.sin(dep_rad) * np.cos(azi_rad)
y_true = R0 * np.sin(dep_rad) * np.sin(azi_rad)
z_true = R0 * np.cos(dep_rad)

print(f"\n真实物理空间中的相机位置:")
print(f"  x = R0 × sin({depression_angle}°) × cos(0°) = {x_true:.2f} m")
print(f"  y = R0 × sin({depression_angle}°) × sin(0°) = {y_true:.2f} m")
print(f"  z = R0 × cos({depression_angle}°) = {z_true:.2f} m")
print(f"  相机到原点距离: {R0:.2f} m")

# ========== 计算自动缩放因子 ==========
print("\n【步骤3】计算自动缩放因子")
print("-"*70)

print(f"radius_scale = (image_size × scene_scale) / R0")
print(f"             = ({image_size} × {scene_scale}) / {R0:.2f}")
print(f"             = {image_size * scene_scale} / {R0:.2f}")

radius_scale = (image_size * scene_scale) / R0

print(f"             = {radius_scale:.6f}")
print(f"             ≈ {radius_scale:.2f}")

# ========== 应用缩放 ==========
print("\n【步骤4】应用缩放后的相机位置")
print("-"*70)

sphere_radius = R0 * radius_scale
x_scaled = sphere_radius * np.sin(dep_rad) * np.cos(azi_rad)
y_scaled = sphere_radius * np.sin(dep_rad) * np.sin(azi_rad)
z_scaled = sphere_radius * np.cos(dep_rad)

print(f"缩放后的球面半径 = R0 × radius_scale")
print(f"                  = {R0:.2f} × {radius_scale:.4f}")
print(f"                  = {sphere_radius:.2f} m")

print(f"\n缩放后的相机位置:")
print(f"  x = {sphere_radius:.2f} × sin({depression_angle}°) × cos(0°) = {x_scaled:.2f} m")
print(f"  y = {sphere_radius:.2f} × sin({depression_angle}°) × sin(0°) = {y_scaled:.2f} m")
print(f"  z = {sphere_radius:.2f} × cos({depression_angle}°) = {z_scaled:.2f} m")
print(f"  相机到原点距离: {sphere_radius:.2f} m")

# ========== 对比分析 ==========
print("\n【步骤5】对比分析")
print("-"*70)

print(f"{'指标':<20} {'无缩放（radius_scale=1.0）':<30} {'有缩放（radius_scale≈{:.2f}）':<30}".format(radius_scale))
print("-"*70)
print(f"{'相机位置 X':<20} {x_true:>25.2f} m {x_scaled:>25.2f} m")
print(f"{'相机位置 Y':<20} {y_true:>25.2f} m {y_scaled:>25.2f} m")
print(f"{'相机位置 Z':<20} {z_true:>25.2f} m {z_scaled:>25.2f} m")
print(f"{'距离原点':<20} {R0:>25.2f} m {sphere_radius:>25.2f} m")
print(f"{'坐标数量级':<20} {int(np.log10(R0)):>25} (10^{int(np.log10(R0))}) {int(np.log10(sphere_radius)):>25} (10^{int(np.log10(sphere_radius))})")

# ========== 为什么要缩放？==========
print("\n【步骤6】为什么要缩放？")
print("-"*70)

focal_length = 768  # 像素（默认焦距）

print(f"问题1: 数值范围不匹配")
print(f"  - 无缩放时相机距离: {R0:.0f} m（约 {R0/1000:.1f} km）")
print(f"  - 焦距（像素单位）: {focal_length} px")
print(f"  - 比例: {R0/focal_length:.0f} : 1 （差距过大！）")
print(f"  → 导致数值精度问题、优化困难")

print(f"\n问题2: 与图像尺寸不匹配")
print(f"  - 图像尺寸: {image_size} px")
print(f"  - 相机距离: {R0:.0f} m")
print(f"  - 比例: {R0/image_size:.0f} : 1 （差距过大！）")
print(f"  → 点云坐标与图像坐标数量级相差太大")

print(f"\n解决方案: 使用 radius_scale ≈ {radius_scale:.2f}")
print(f"  - 缩放后相机距离: {sphere_radius:.0f} m")
print(f"  - 与图像尺寸比例: {sphere_radius/image_size:.1f} : 1 （合理！）")
print(f"  - 与焦距比例: {sphere_radius/focal_length:.1f} : 1 （合理！）")
print(f"  → 数值稳定、优化收敛快")

# ========== 场景倍数的意义 ==========
print("\n【步骤7】scene_scale = {:.1f} 的物理意义".format(scene_scale))
print("-"*70)

print(f"假设SAR图像分辨率为 0.3 m/pixel（MSTAR典型值）:")
print(f"  - 图像覆盖区域: {image_size} × 0.3 = {image_size * 0.3:.1f} m")
print(f"  - 场景应该比图像大一些（留出余量）")
print(f"  - scene_scale = {scene_scale} → 场景大小 = {image_size} × {scene_scale} = {image_size * scene_scale} 单位")
print(f"  - 这刚好是缩放后的相机距离！({sphere_radius:.0f} m)")

print(f"\n含义: 相机距离 ≈ 图像尺寸 × 场景倍数")
print(f"     = 场景的合理视距")

# ========== 不同图像尺寸的自适应 ==========
print("\n【步骤8】自动适应不同图像尺寸")
print("-"*70)

test_sizes = [128, 256, 512, 1024, 2048]
print(f"{'图像尺寸':<15} {'radius_scale':<20} {'球面半径':<20} {'与焦距比例':<20}")
print("-"*70)

for size in test_sizes:
    rs = (size * scene_scale) / R0
    sr = R0 * rs
    ratio = sr / focal_length
    print(f"{size:>10} px {rs:>18.4f} {sr:>18.2f} m {ratio:>18.1f} : 1")

print(f"\n规律: 图像越大 → radius_scale 越大 → 场景范围越大")
print(f"     自动保持 球面半径/图像尺寸 的比例恒定（≈{scene_scale}）")

# ========== 关键公式总结 ==========
print("\n【关键公式总结】")
print("="*70)

print(f"""
1. 参考斜距（真实物理距离）:
   R0 = camera_height / sin(depression_angle)
      = {camera_height} / sin({depression_angle}°)
      = {R0:.2f} m

2. 自动缩放因子:
   radius_scale = (图像尺寸 × 场景倍数) / R0
                = ({image_size} × {scene_scale}) / {R0:.2f}
                = {radius_scale:.4f}

3. 缩放后的球面半径:
   sphere_radius = R0 × radius_scale
                 = {R0:.2f} × {radius_scale:.4f}
                 = {sphere_radius:.2f} m

4. 相机位置（球面坐标）:
   x = sphere_radius × sin(depression) × cos(azimuth)
   y = sphere_radius × sin(depression) × sin(azimuth)
   z = sphere_radius × cos(depression)
""")

print("="*70)
print("✅ 演示完成！")
print("="*70)

print("\n💡 关键理解:")
print("  1. radius_scale 不是随意的，而是基于图像尺寸和物理尺度计算的")
print("  2. 缩放不改变几何关系，只改变整体尺度")
print("  3. 目的是让坐标数值在合理范围内，提高数值稳定性")
print("  4. 自动适应不同图像尺寸，保持场景/图像的比例关系")

