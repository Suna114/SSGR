#!/usr/bin/env python

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
SAR高斯泼溅快速开始脚本
用于快速复现论文"A Differentiable Framework for Image-Based SAR Target Reconstruction with 3D Gaussian Splatting"

使用方法:
    python quick_start_sar_gs.py --source_path /path/to/dataset --model_path /path/to/output
"""

import os
import sys
import argparse
import subprocess

def check_requirements():
    """检查必要的依赖"""
    print("检查依赖...")
    try:
        import torch
        print(f"✓ PyTorch {torch.__version__}")
    except ImportError:
        print("✗ PyTorch未安装")
        return False
    
    try:
        import numpy
        print(f"✓ NumPy {numpy.__version__}")
    except ImportError:
        print("✗ NumPy未安装")
        return False
    
    try:
        from diff_gaussian_rasterization import GaussianRasterizationSettings
        print("✓ diff-gaussian-rasterization已安装")
    except ImportError:
        print("✗ diff-gaussian-rasterization未安装，请运行: pip install diff-gaussian-rasterization")
        return False
    
    return True

def check_dataset_structure(source_path):
    """检查数据集结构"""
    print(f"\n检查数据集结构: {source_path}")
    
    required_dirs = ['images']
    optional_dirs = ['sparse/0']
    
    for dir_name in required_dirs:
        dir_path = os.path.join(source_path, dir_name)
        if not os.path.exists(dir_path):
            print(f"✗ 缺少必需目录: {dir_path}")
            return False
        print(f"✓ 找到目录: {dir_path}")
    
    for dir_name in optional_dirs:
        dir_path = os.path.join(source_path, dir_name)
        if os.path.exists(dir_path):
            print(f"✓ 找到可选目录: {dir_path}")
        else:
            print(f"⚠ 可选目录不存在: {dir_path} (将使用随机初始化)")
    
    # 检查图像文件
    images_dir = os.path.join(source_path, 'images')
    image_files = [f for f in os.listdir(images_dir) 
                   if f.lower().endswith(('.jpg', '.jpeg', '.png', '.tif', '.tiff'))]
    
    if len(image_files) == 0:
        print(f"✗ 在 {images_dir} 中未找到图像文件")
        return False
    
    print(f"✓ 找到 {len(image_files)} 张图像")
    return True

def run_training(source_path, model_path, args):
    """运行训练"""
    print(f"\n开始训练...")
    print(f"源数据路径: {source_path}")
    print(f"模型输出路径: {model_path}")
    
    # 构建训练命令
    cmd = [
        sys.executable, 'train.py',
        '-s', source_path,
        '-m', model_path,
        '--sar_mode',
        '--sar_camera_height', str(args.sar_camera_height),
        '--sar_camera_distribution_mode', args.sar_camera_distribution_mode,
        '--sar_platform_velocity', str(args.sar_platform_velocity),
        '--sar_prf', str(args.sar_prf),
        '--sar_bandwidth', str(args.sar_bandwidth),
        '--sar_image_size_azimuth', str(args.sar_image_size_azimuth),
        '--sar_image_size_range', str(args.sar_image_size_range),
        '--iterations', str(args.iterations),
        '--test_iterations'] + [str(x) for x in args.test_iterations] + [
        '--save_iterations'] + [str(x) for x in args.save_iterations]
    
    # 添加可选参数
    if args.sar_shape_constraint_weight > 0:
        cmd.extend([
            '--sar_shape_constraint_weight', str(args.sar_shape_constraint_weight),
            '--sar_shape_constraint_start_iter', str(args.sar_shape_constraint_start_iter),
            '--sar_shape_constraint_end_iter', str(args.sar_shape_constraint_end_iter)
        ])
    
    if args.position_lr_init is not None:
        cmd.extend(['--position_lr_init', str(args.position_lr_init)])
    
    if args.lambda_dssim is not None:
        cmd.extend(['--lambda_dssim', str(args.lambda_dssim)])
    
    print(f"\n执行命令:")
    print(' '.join(cmd))
    print()
    
    # 运行训练
    try:
        subprocess.run(cmd, check=True)
        print("\n✓ 训练完成!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n✗ 训练失败: {e}")
        return False
    except KeyboardInterrupt:
        print("\n⚠ 训练被用户中断")
        return False

def main():
    parser = argparse.ArgumentParser(
        description='SAR高斯泼溅快速开始脚本',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # MSTAR数据集（默认参数）
  python quick_start_sar_gs.py -s /path/to/mstar_dataset -m /path/to/output
  
  # 自定义参数
  python quick_start_sar_gs.py -s /path/to/dataset -m /path/to/output \\
      --sar_camera_height 12000.0 \\
      --sar_camera_distribution_mode sphere \\
      --iterations 30000
        """
    )
    
    # 必需参数
    parser.add_argument('-s', '--source_path', required=True,
                       help='数据集路径（包含images文件夹）')
    parser.add_argument('-m', '--model_path', required=True,
                       help='模型输出路径')
    
    # SAR参数（MSTAR数据集默认值）
    parser.add_argument('--sar_camera_height', type=float, default=12000.0,
                       help='SAR平台高度（米），MSTAR默认12000.0')
    parser.add_argument('--sar_camera_distribution_mode', type=str, 
                       default='sphere', choices=['sphere', 'ring'],
                       help='相机分布模式：sphere（球面，推荐）或ring（水平圆环）')
    parser.add_argument('--sar_platform_velocity', type=float, default=250.0,
                       help='平台速度（m/s），MSTAR默认250.0')
    parser.add_argument('--sar_prf', type=float, default=2500.0,
                       help='脉冲重复频率（Hz），MSTAR默认2500.0')
    parser.add_argument('--sar_bandwidth', type=float, default=500e6,
                       help='带宽（Hz），MSTAR默认500MHz')
    parser.add_argument('--sar_image_size_azimuth', type=int, default=512,
                       help='方位向图像尺寸（像素）')
    parser.add_argument('--sar_image_size_range', type=int, default=512,
                       help='距离向图像尺寸（像素）')
    
    # 训练参数
    parser.add_argument('--iterations', type=int, default=30000,
                       help='训练迭代次数')
    parser.add_argument('--test_iterations', type=int, nargs='+', 
                       default=[7000, 30000],
                       help='测试迭代次数列表')
    parser.add_argument('--save_iterations', type=int, nargs='+',
                       default=[7000, 30000],
                       help='保存迭代次数列表')
    parser.add_argument('--position_lr_init', type=float, default=None,
                       help='位置学习率初始值（默认使用train.py的默认值）')
    parser.add_argument('--lambda_dssim', type=float, default=None,
                       help='SSIM损失权重（默认使用train.py的默认值0.2）')
    
    # SAR形状约束参数
    parser.add_argument('--sar_shape_constraint_weight', type=float, default=0.01,
                       help='形状约束权重（默认0.01，设为0禁用）')
    parser.add_argument('--sar_shape_constraint_start_iter', type=int, default=1000,
                       help='形状约束开始迭代')
    parser.add_argument('--sar_shape_constraint_end_iter', type=int, default=20000,
                       help='形状约束结束迭代')
    
    # 其他选项
    parser.add_argument('--skip_check', action='store_true',
                       help='跳过依赖和数据集检查')
    parser.add_argument('--dry_run', action='store_true',
                       help='仅显示命令，不实际运行')
    
    args = parser.parse_args()
    
    # 检查依赖
    if not args.skip_check:
        if not check_requirements():
            print("\n请先安装缺失的依赖")
            return 1
        
        if not check_dataset_structure(args.source_path):
            print("\n数据集结构不正确，请检查数据集路径和结构")
            return 1
    
    # 确保输出目录存在
    os.makedirs(args.model_path, exist_ok=True)
    
    # 运行训练
    if args.dry_run:
        print("\n[DRY RUN] 将执行以下命令:")
        cmd = [
            sys.executable, 'train.py',
            '-s', args.source_path,
            '-m', args.model_path,
            '--sar_mode',
            '--sar_camera_height', str(args.sar_camera_height),
            '--sar_camera_distribution_mode', args.sar_camera_distribution_mode,
            '--iterations', str(args.iterations),
        ]
        print(' '.join(cmd))
        return 0
    
    success = run_training(args.source_path, args.model_path, args)
    
    if success:
        print(f"\n训练完成！模型保存在: {args.model_path}")
        print("\n下一步:")
        print("1. 查看TensorBoard日志: tensorboard --logdir " + args.model_path)
        print("2. 使用SIBR查看器可视化点云")
        print("3. 参考 SAR_GS_REPRODUCTION_GUIDE.md 了解更多信息")
        return 0
    else:
        return 1

if __name__ == '__main__':
    sys.exit(main())






