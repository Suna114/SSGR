# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
计算SAR场景缩放因子scene_scale的工具

用于确定合适的scene_scale值，使相机到场景中心的距离在目标范围内（如30-60米）
或使相机高度在目标范围内（如30米）
"""

import numpy as np
import argparse

def calculate_scene_scale(
    target_distance_min=30.0,  # 目标最小距离（米）
    target_distance_max=60.0,   # 目标最大距离（米）
    image_size=128,             # 图像尺寸（像素）
    resolution=0.3,              # 分辨率（米/像素）
    camera_height=6100.0,       # SAR相机高度（米）
    depression_angle=15.0,      # 俯视角（度）
    use_target_height=True      # 是否使用target_height方法（推荐）
):
    """
    计算scene_scale值
    
    参数:
        target_distance_min: 目标最小距离（相机到场景中心的距离，米）
        target_distance_max: 目标最大距离（米）
        image_size: 图像尺寸（像素）
        resolution: 分辨率（米/像素）
        camera_height: SAR相机高度（米）
        depression_angle: 俯视角（度）
        use_target_height: 是否使用target_height方法（推荐，会自动计算scene_scale）
    
    返回:
        scene_scale值和建议的参数设置
    """
    print("="*70)
    print("SAR场景缩放因子计算工具")
    print("="*70)
    print(f"\n输入参数:")
    print(f"  - 图像尺寸: {image_size}×{image_size} 像素")
    print(f"  - 分辨率: {resolution} 米/像素")
    print(f"  - SAR相机高度: {camera_height} 米")
    print(f"  - 俯视角: {depression_angle}°")
    print(f"  - 目标距离范围: {target_distance_min}-{target_distance_max} 米")
    
    # 计算原始R0（斜距）
    depression_rad = np.deg2rad(depression_angle)
    R0 = camera_height / np.sin(depression_rad)
    
    print(f"\n计算过程:")
    print(f"  1. 原始斜距 R0 = camera_height / sin(俯视角)")
    print(f"     R0 = {camera_height:.2f} / sin({depression_angle}°)")
    print(f"     R0 = {camera_height:.2f} / {np.sin(depression_rad):.4f}")
    print(f"     R0 = {R0:.2f} 米")
    
    # 计算目标R0（使用中值）
    target_distance = (target_distance_min + target_distance_max) / 2.0
    target_R0 = target_distance
    
    print(f"\n  2. 目标斜距（相机到场景中心的距离）")
    print(f"     目标距离 = {target_distance:.2f} 米（使用中值）")
    print(f"     目标R0 = {target_R0:.2f} 米")
    
    # 计算radius_scale
    radius_scale = target_R0 / R0
    
    print(f"\n  3. radius_scale = 目标R0 / 原始R0")
    print(f"     radius_scale = {target_R0:.2f} / {R0:.2f}")
    print(f"     radius_scale = {radius_scale:.6f}")
    
    # 计算scene_scale
    # 公式：radius_scale = (image_size × scene_scale) / R0
    # 所以：scene_scale = (radius_scale × R0) / image_size
    scene_scale = (radius_scale * R0) / image_size
    
    print(f"\n  4. scene_scale = (radius_scale × R0) / image_size")
    print(f"     scene_scale = ({radius_scale:.6f} × {R0:.2f}) / {image_size}")
    print(f"     scene_scale = {scene_scale:.6f}")
    
    # 验证：计算缩放后的距离
    scaled_R0 = R0 * radius_scale
    scaled_camera_height = scaled_R0 * np.sin(depression_rad)
    
    print(f"\n验证结果:")
    print(f"  ✅ 缩放后R0 = {scaled_R0:.2f} 米（目标: {target_distance:.2f} 米）")
    print(f"  ✅ 缩放后相机高度 = {scaled_camera_height:.2f} 米")
    print(f"  ✅ scene_scale = {scene_scale:.6f}")
    
    # 计算覆盖范围
    actual_coverage = image_size * resolution
    print(f"  ✅ 实际覆盖范围 = {actual_coverage:.2f} 米（{image_size}像素 × {resolution}米/像素）")
    
    print(f"\n" + "="*70)
    print("推荐参数设置")
    print("="*70)
    
    if use_target_height:
        print(f"\n方法1（推荐）：使用 --sfm_camera_scaling_target_height")
        print(f"  设置目标相机高度在 {target_distance_min:.0f}-{target_distance_max:.0f} 米范围内")
        print(f"  系统会自动计算scene_scale")
        print(f"\n  命令行参数:")
        print(f"    --sfm_camera_scaling_target_height {target_distance:.2f}")
        print(f"    或")
        print(f"    --sfm_camera_scaling_target_min {target_distance_min:.0f}")
        print(f"    --sfm_camera_scaling_target_max {target_distance_max:.0f}")
    else:
        print(f"\n方法2：直接设置 --sar_scene_scale")
        print(f"  命令行参数:")
        print(f"    --sar_scene_scale {scene_scale:.6f}")
    
    print(f"\n完整示例命令:")
    print(f"  python sfm.py --sar_scene_scale {scene_scale:.6f} \\")
    print(f"                 --sfm_scale_constraint_resolution {resolution} \\")
    print(f"                 --sfm_scale_constraint_pixel_width {image_size} \\")
    print(f"                 --sfm_scale_constraint_pixel_height {image_size}")
    
    print(f"\n" + "="*70)
    print("注意事项")
    print("="*70)
    print(f"  1. scene_scale值越小，相机距离场景越近")
    print(f"  2. 对于高斯泼溅训练，建议相机距离在1-150米范围内")
    print(f"  3. 30-60米的距离适合高斯泼溅训练（越近越好）")
    print(f"  4. 如果使用target_height方法，系统会自动优化scene_scale")
    print(f"  5. 实际距离可能因俯视角不同而略有变化")
    
    return {
        'scene_scale': scene_scale,
        'radius_scale': radius_scale,
        'target_distance': target_distance,
        'scaled_R0': scaled_R0,
        'scaled_camera_height': scaled_camera_height
    }


def calculate_scene_scale_from_height(
    current_scene_scale=0.1,      # 当前scene_scale值
    current_camera_height=500.0,   # 当前相机高度（米）
    target_camera_height=30.0,    # 目标相机高度（米）
    image_size=128,                # 图像尺寸（像素）
    resolution=0.3,                # 分辨率（米/像素）
    camera_height=6100.0,          # SAR相机高度（米）
    depression_angle=15.0          # 俯视角（度）
):
    """
    根据已知的scene_scale和相机高度，计算新的scene_scale值
    
    参数:
        current_scene_scale: 当前scene_scale值（如0.1）
        current_camera_height: 当前相机高度（米，如500）
        target_camera_height: 目标相机高度（米，如30）
        其他参数用于验证计算
    
    返回:
        新的scene_scale值
    """
    print("="*70)
    print("根据已知scene_scale计算新的scene_scale值")
    print("="*70)
    print(f"\n已知信息:")
    print(f"  - 当前scene_scale: {current_scene_scale}")
    print(f"  - 当前相机高度: {current_camera_height} 米")
    print(f"  - 目标相机高度: {target_camera_height} 米")
    
    # 计算比例关系
    # scene_scale与相机高度成线性关系
    height_ratio = target_camera_height / current_camera_height
    new_scene_scale = current_scene_scale * height_ratio
    
    print(f"\n计算过程:")
    print(f"  高度比例 = 目标高度 / 当前高度")
    print(f"  高度比例 = {target_camera_height:.2f} / {current_camera_height:.2f}")
    print(f"  高度比例 = {height_ratio:.6f}")
    print(f"\n  新scene_scale = 当前scene_scale × 高度比例")
    print(f"  新scene_scale = {current_scene_scale:.6f} × {height_ratio:.6f}")
    print(f"  新scene_scale = {new_scene_scale:.6f}")
    
    # 验证计算（使用完整公式）
    depression_rad = np.deg2rad(depression_angle)
    R0 = camera_height / np.sin(depression_rad)
    
    # 从当前scene_scale反推radius_scale
    # scene_scale = (radius_scale × R0) / image_size
    # 所以：radius_scale = (scene_scale × image_size) / R0
    current_radius_scale = (current_scene_scale * image_size) / R0
    current_scaled_R0 = R0 * current_radius_scale
    current_scaled_height = current_scaled_R0 * np.sin(depression_rad)
    
    # 计算新的radius_scale
    new_radius_scale = current_radius_scale * height_ratio
    new_scaled_R0 = R0 * new_radius_scale
    new_scaled_height = new_scaled_R0 * np.sin(depression_rad)
    
    print(f"\n验证计算:")
    print(f"  原始R0 = {R0:.2f} 米")
    print(f"  当前radius_scale = {current_radius_scale:.6f}")
    print(f"  当前缩放后R0 = {current_scaled_R0:.2f} 米")
    print(f"  当前缩放后相机高度 = {current_scaled_height:.2f} 米（已知: {current_camera_height:.2f} 米）")
    print(f"\n  新radius_scale = {new_radius_scale:.6f}")
    print(f"  新缩放后R0 = {new_scaled_R0:.2f} 米")
    print(f"  新缩放后相机高度 = {new_scaled_height:.2f} 米（目标: {target_camera_height:.2f} 米）")
    
    print(f"\n" + "="*70)
    print("推荐参数设置")
    print("="*70)
    print(f"\n新的scene_scale值: {new_scene_scale:.6f}")
    print(f"\n命令行参数:")
    print(f"  --sar_scene_scale {new_scene_scale:.6f}")
    
    print(f"\n完整示例命令:")
    print(f"  python sfm.py --sar_scene_scale {new_scene_scale:.6f} \\")
    print(f"                 --sfm_scale_constraint_resolution {resolution} \\")
    print(f"                 --sfm_scale_constraint_pixel_width {image_size} \\")
    print(f"                 --sfm_scale_constraint_pixel_height {image_size}")
    
    print(f"\n" + "="*70)
    print("注意事项")
    print("="*70)
    print(f"  1. scene_scale值越小，相机高度越小（相机越近）")
    print(f"  2. 当前: scene_scale={current_scene_scale:.6f} → 相机高度≈{current_camera_height:.0f}米")
    print(f"  3. 新值: scene_scale={new_scene_scale:.6f} → 相机高度≈{target_camera_height:.0f}米")
    print(f"  4. 实际高度可能因俯视角不同而略有变化")
    
    return {
        'new_scene_scale': new_scene_scale,
        'height_ratio': height_ratio,
        'new_scaled_height': new_scaled_height,
        'new_scaled_R0': new_scaled_R0
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='计算SAR场景缩放因子scene_scale')
    parser.add_argument('--target_distance_min', type=float, default=30.0,
                       help='目标最小距离（米），默认30.0')
    parser.add_argument('--target_distance_max', type=float, default=60.0,
                       help='目标最大距离（米），默认60.0')
    parser.add_argument('--image_size', type=int, default=128,
                       help='图像尺寸（像素），默认128')
    parser.add_argument('--resolution', type=float, default=0.3,
                       help='分辨率（米/像素），默认0.3')
    parser.add_argument('--camera_height', type=float, default=6100.0,
                       help='SAR相机高度（米），默认6100.0')
    parser.add_argument('--depression_angle', type=float, default=15.0,
                       help='俯视角（度），默认15.0')
    
    # 新增参数：从已知scene_scale计算
    parser.add_argument('--from_height', action='store_true',
                       help='使用已知scene_scale和相机高度计算新值')
    parser.add_argument('--current_scene_scale', type=float, default=0.1,
                       help='当前scene_scale值，默认0.1')
    parser.add_argument('--current_camera_height', type=float, default=500.0,
                       help='当前相机高度（米），默认500.0')
    parser.add_argument('--target_camera_height', type=float, default=30.0,
                       help='目标相机高度（米），默认30.0')
    
    args = parser.parse_args()
    
    if args.from_height:
        # 使用已知高度计算
        result = calculate_scene_scale_from_height(
            current_scene_scale=args.current_scene_scale,
            current_camera_height=args.current_camera_height,
            target_camera_height=args.target_camera_height,
            image_size=args.image_size,
            resolution=args.resolution,
            camera_height=args.camera_height,
            depression_angle=args.depression_angle
        )
        print(f"\n计算结果:")
        print(f"  新scene_scale = {result['new_scene_scale']:.6f}")
        print(f"  预期相机高度 = {result['new_scaled_height']:.2f} 米")
    else:
        # 使用目标距离计算
        result = calculate_scene_scale(
            target_distance_min=args.target_distance_min,
            target_distance_max=args.target_distance_max,
            image_size=args.image_size,
            resolution=args.resolution,
            camera_height=args.camera_height,
            depression_angle=args.depression_angle
        )
        print(f"\n计算结果已保存到变量 result 中")
        print(f"scene_scale = {result['scene_scale']:.6f}")

