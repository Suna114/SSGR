#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
测试SFM阴影约束功能的演示脚本
"""

import os
import sys
import numpy as np

# 添加项目路径
sys.path.append('.')

def create_sample_shadow_constraints_file(file_path):
    """创建示例阴影约束文件"""
    content = """目标尺寸约束计算结果
计算时间: 2024-01-01 12:00:00

基于阴影几何分析的目标尺寸比例:

推荐高度/长度比例 (H/L): 0.3243
推荐高度/宽度比例 (H/W): 0.4567
推荐长度/宽度比例 (L/W): 1.2345

计算详情:
- 阴影长度: 45.2 像素
- 目标长度: 139.5 像素
- 目标宽度: 113.1 像素
- 目标高度: 45.2 像素
- 俯视角: 30.0 度
- 方位角: 45.0 度

注意: 这些比例基于SAR阴影几何计算，具有物理意义。
"""
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ 创建示例阴影约束文件: {file_path}")

def test_shadow_constraint_loading():
    """测试阴影约束加载功能"""
    print("🧪 测试SFM阴影约束加载功能")
    print("="*50)

    # 创建测试文件
    test_file = 'test_shadow_constraints.txt'
    create_sample_shadow_constraints_file(test_file)

    try:
        # 导入加载函数
        from feature_extraction import load_target_dimension_constraints_from_summary

        # 测试加载
        constraints = load_target_dimension_constraints_from_summary(test_file)

        if constraints:
            print("✅ 阴影约束加载成功!")
            print(f"   高度/长度比例: {constraints.get('height_length_ratio', 'N/A')}")
            print(f"   高度/宽度比例: {constraints.get('height_width_ratio', 'N/A')}")
            print(f"   长度/宽度比例: {constraints.get('length_width_ratio', 'N/A')}")

            # 测试在高斯泼溅训练中的集成
            print("\n🔧 测试在高斯泼溅训练中的集成:")
            from train import load_sfm_shadow_constraints

            # 模拟训练参数
            source_path = '.'
            model_path = 'test_output'

            shadow_constraints = load_sfm_shadow_constraints(source_path, model_path)

            if shadow_constraints:
                print("✅ 高斯泼溅训练集成成功!")
                print("   阴影约束将在训练过程中自动应用")
            else:
                print("⚠️ 训练集成测试完成（未找到约束文件，这是正常的）")

        else:
            print("❌ 阴影约束加载失败")

    except ImportError as e:
        print(f"❌ 无法导入所需模块: {e}")
        print("   请确保feature_extraction.py可用")

    except Exception as e:
        print(f"❌ 测试过程中出错: {e}")

    finally:
        # 清理测试文件
        if os.path.exists(test_file):
            os.remove(test_file)
            print(f"\n🧹 清理测试文件: {test_file}")

def demonstrate_pointcloud_filtering():
    """演示点云过滤逻辑"""
    print("\n🔧 演示点云过滤逻辑")
    print("="*50)

    # 模拟点云数据（包含噪声点和多个集群）
    np.random.seed(42)  # 固定随机种子

    # 主要目标集群（T72坦克形状 - 紧凑集群）
    main_cluster = np.random.uniform([-60, -20, -30], [60, 0, 30], (600, 3))

    # 次要目标集群（另一个较小的目标）
    secondary_cluster = np.random.uniform([200, -10, 100], [300, 10, 150], (100, 3))

    # 散布的噪声点
    noise_points = np.random.uniform([-400, -100, -200], [400, 50, 200], (150, 3))

    # 离散的离群点
    outlier_points = np.random.uniform([-800, -300, -500], [800, 200, 500], (50, 3))

    # 合并所有点
    all_points = np.vstack([main_cluster, secondary_cluster, noise_points, outlier_points])

    print("模拟点云统计:")
    print(f"   总点数: {len(all_points)}")
    print(f"   主要目标集群: {len(main_cluster)}")
    print(f"   次要目标集群: {len(secondary_cluster)}")
    print(f"   散布噪声点: {len(noise_points)}")
    print(f"   离散离群点: {len(outlier_points)}")

    # 计算点云范围
    min_coords = np.min(all_points, axis=0)
    max_coords = np.max(all_points, axis=0)
    center = np.mean(all_points, axis=0)

    print("\n原始点云范围:")
    print(f"   X: [{min_coords[0]:.1f}, {max_coords[0]:.1f}] 范围:{max_coords[0]-min_coords[0]:.1f}")
    print(f"   Y: [{min_coords[1]:.1f}, {max_coords[1]:.1f}] 范围:{max_coords[1]-min_coords[1]:.1f}")
    print(f"   Z: [{min_coords[2]:.1f}, {max_coords[2]:.1f}] 范围:{max_coords[2]-min_coords[2]:.1f}")
    print(f"   中心: [{center[0]:.1f}, {center[1]:.1f}, {center[2]:.1f}]")

    # 计算距离统计
    distances = np.linalg.norm(all_points - center, axis=1)
    distance_percentiles = np.percentile(distances, [50, 75, 90, 95, 99])

    print("\n距离统计 (到中心):")
    print(f"   中位数: {distance_percentiles[0]:.1f}")
    print(f"   75%分位数: {distance_percentiles[1]:.1f}")
    print(f"   90%分位数: {distance_percentiles[2]:.1f}")
    print(f"   95%分位数: {distance_percentiles[3]:.1f}")
    print(f"   99%分位数: {distance_percentiles[4]:.1f}")

    # 模拟多层次过滤效果
    print("\n多层次过滤效果:")

    # 1. 距离过滤（保留95%近中心点）
    distance_threshold = distance_percentiles[3]  # 95%分位数
    distance_filtered = all_points[distances <= distance_threshold]
    print(f"   1. 距离过滤 (95%): {len(distance_filtered)}/{len(all_points)} 点保留")

    # 2. 模拟聚类过滤 - 识别主要集群
    print(f"   2. 聚类过滤: 识别主要目标集群")

    # 简单聚类模拟：基于空间距离的集群识别
    # 主要集群（T72坦克）在[-60,60]x[-20,0]x[-30,30]范围内
    main_cluster_filtered = distance_filtered[
        (distance_filtered[:, 0] >= -80) & (distance_filtered[:, 0] <= 80) &
        (distance_filtered[:, 1] >= -30) & (distance_filtered[:, 1] <= 10) &
        (distance_filtered[:, 2] >= -40) & (distance_filtered[:, 2] <= 40)
    ]

    # 次要集群在[200,300]x[-10,10]x[100,150]范围内
    secondary_cluster_filtered = distance_filtered[
        (distance_filtered[:, 0] >= 180) & (distance_filtered[:, 0] <= 320) &
        (distance_filtered[:, 1] >= -20) & (distance_filtered[:, 1] <= 20) &
        (distance_filtered[:, 2] >= 80) & (distance_filtered[:, 2] <= 170)
    ]

    # 只保留最大的集群（主要目标）
    if len(main_cluster_filtered) >= len(secondary_cluster_filtered):
        final_filtered = main_cluster_filtered
        kept_cluster = "主要集群"
    else:
        final_filtered = secondary_cluster_filtered
        kept_cluster = "次要集群"

    print(f"      识别到 {2} 个候选集群")
    print(f"      保留最大集群 ({kept_cluster}): {len(final_filtered)} 点")

    # 计算过滤后的几何尺寸
    if len(final_filtered) > 0:
        filtered_min = np.min(final_filtered, axis=0)
        filtered_max = np.max(final_filtered, axis=0)
        filtered_center = np.mean(final_filtered, axis=0)
        filtered_size = filtered_max - filtered_min

        print("   最终过滤结果:")
        print(f"     保留点数: {len(final_filtered)}/{len(all_points)} ({len(final_filtered)/len(all_points)*100:.1f}%)")
        print(f"     X尺寸: {filtered_size[0]:.1f} (原:{max_coords[0]-min_coords[0]:.1f})")
        print(f"     Y尺寸: {filtered_size[1]:.1f} (原:{max_coords[1]-min_coords[1]:.1f})")
        print(f"     Z尺寸: {filtered_size[2]:.1f} (原:{max_coords[2]-min_coords[2]:.1f})")
        print(f"     新的中心: [{filtered_center[0]:.1f}, {filtered_center[1]:.1f}, {filtered_center[2]:.1f}]")

def demonstrate_constraint_calculation():
    """演示约束计算逻辑"""
    print("\n📐 演示阴影约束计算逻辑")
    print("="*50)

    # 使用过滤后的点云尺寸（模拟真实情况）
    min_coords = np.array([-65.0, -22.0, -35.0])  # 最小坐标
    max_coords = np.array([65.0, 0.0, 35.0])      # 最大坐标

    current_size = max_coords - min_coords
    length = current_size[0]  # X方向（长度）
    height = current_size[1]  # Y方向（高度，COLMAP中Y越小越高）
    width = current_size[2]   # Z方向（宽度）

    print("过滤后点云尺寸（像素坐标）:")
    print(f"   长度 (X): {length}")
    print(f"   高度 (Y): {abs(height)}")  # 取绝对值显示
    print(f"   宽度 (Z): {width}")

    # 计算当前比例
    current_h_l_ratio = abs(height) / length if length > 0 else 0
    current_h_w_ratio = abs(height) / width if width > 0 else 0
    current_l_w_ratio = length / width if width > 0 else 0

    print("\n当前几何尺寸和比例:")
    print(f"   高度范围: {abs(height):.1f} 像素")
    print(f"   长度范围: {length:.1f} 像素")
    print(f"   宽度范围: {width:.1f} 像素")
    print(f"   高度/长度比例 (H/L): {current_h_l_ratio:.4f}")
    print(f"   高度/宽度比例 (H/W): {current_h_w_ratio:.4f}")
    print(f"   长度/宽度比例 (L/W): {current_l_w_ratio:.4f}")

    # 阴影计算的目标值（示例）
    target_height = 45.2   # 目标高度（像素）
    target_length = 139.5  # 目标长度（像素）
    target_width = 113.1   # 目标宽度（像素）
    target_h_l_ratio = 0.3243  # 高度/长度比例
    target_h_w_ratio = 0.4567  # 高度/宽度比例

    print("\n目标几何尺寸（来自阴影计算）:")
    print(f"   目标高度: {target_height:.1f} 像素")
    print(f"   目标长度: {target_length:.1f} 像素")
    print(f"   目标宽度: {target_width:.1f} 像素")
    print(f"   高度/长度比例 (H/L): {target_h_l_ratio:.4f}")
    print(f"   高度/宽度比例 (H/W): {target_h_w_ratio:.4f}")

    # 计算各种差异
    height_diff = abs(abs(height) - target_height)
    height_ratio_diff = height_diff / target_height if target_height > 0 else height_diff

    h_l_ratio_diff = abs(current_h_l_ratio - target_h_l_ratio)
    h_w_ratio_diff = abs(current_h_w_ratio - target_h_w_ratio)

    print("\n几何差异:")
    print(f"   高度绝对差异: {height_diff:.2f} 像素 ({height_ratio_diff:.1%})")
    print(f"   高度/长度比例差异: {h_l_ratio_diff:.4f}")
    print(f"   高度/宽度比例差异: {h_w_ratio_diff:.4f}")

    # 模拟约束计算（修复后的参数）
    tolerance = 0.01  # 1%容差（更严格）
    constraint_weight = 2.0  # 更高的权重
    direct_height_weight = 1.0  # 直接高度约束权重

    L_shadow = 0.0

    # 直接高度约束
    if height_ratio_diff > tolerance:
        L_shadow += direct_height_weight * height_ratio_diff
        print(f"   ✅ 直接高度约束激活: {direct_height_weight * height_ratio_diff:.4f}")

    # 比例约束
    if h_l_ratio_diff > tolerance:
        L_shadow += constraint_weight * h_l_ratio_diff
        print(f"   ✅ 高度/长度比例约束激活: {constraint_weight * h_l_ratio_diff:.4f}")

    if h_w_ratio_diff > tolerance:
        L_shadow += constraint_weight * h_w_ratio_diff
        print(f"   ✅ 高度/宽度比例约束激活: {constraint_weight * h_w_ratio_diff:.4f}")

    print(".4f")
    print(f"   约束权重设置: 比例={constraint_weight}, 直接高度={direct_height_weight}, 容差={tolerance:.1%}")

    # 阴影计算的目标比例（示例）
    target_h_l_ratio = 0.3243  # 高度/长度
    target_h_w_ratio = 0.4567  # 高度/宽度

    print("\n目标几何比例（来自阴影计算）:")
    print(".4f")
    print(".4f")

    # 计算比例差异
    h_l_diff = abs(current_h_l_ratio - target_h_l_ratio)
    h_w_diff = abs(current_h_w_ratio - target_h_w_ratio)

    print("\n比例差异:")
    print(".4f")
    print(".4f")

    # 模拟约束计算
    tolerance = 0.05  # 5%容差
    constraint_weight = 0.5

    L_shadow = 0.0
    if h_l_diff > tolerance:
        L_shadow += constraint_weight * h_l_diff
        print(f"   高度/长度约束激活: {constraint_weight * h_l_diff:.4f}")

    if h_w_diff > tolerance:
        L_shadow += constraint_weight * h_w_diff
        print(f"   高度/宽度约束激活: {constraint_weight * h_w_diff:.4f}")

    print(".4f")

if __name__ == "__main__":
    print("🚀 SFM阴影约束功能测试")
    print("="*60)

    test_shadow_constraint_loading()
    demonstrate_pointcloud_filtering()
    demonstrate_constraint_calculation()

    print("\n" + "="*60)
    print("✅ 测试完成!")
    print("\n使用方法:")
    print("1. 确保SFM生成了 target_dimension_constraints_summary.txt 文件")
    print("2. 运行标准训练: python train.py -s data/your_dataset -m output/model")
    print("3. 系统会自动加载并应用阴影约束")
    print("4. 训练日志中会显示约束状态")
