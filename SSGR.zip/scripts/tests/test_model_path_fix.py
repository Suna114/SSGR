#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
测试model_path修复是否正确工作
"""

def test_model_path_access():
    """测试在training函数中如何正确访问model_path"""

    print("🔍 测试model_path访问修复")
    print("="*50)

    # 模拟training函数的参数
    class MockArgs:
        def __init__(self):
            self.model_path = "output/test_model"

    class MockDataset:
        def __init__(self):
            self.model_path = "output/test_model"

    class MockScene:
        def __init__(self, model_path):
            self.model_path = model_path

    # 模拟training函数中的参数
    dataset = MockDataset()
    scene = MockScene(dataset.model_path)

    # 测试修复后的代码逻辑
    iteration = 30000
    point_cloud_dir = os.path.join(scene.model_path, "point_cloud", f"iteration_{iteration}")

    print(f"✅ scene.model_path: {scene.model_path}")
    print(f"✅ point_cloud_dir: {point_cloud_dir}")

    # 验证路径是否正确（标准化路径分隔符）
    expected_path = os.path.join("output", "test_model", "point_cloud", "iteration_30000")
    if os.path.normpath(point_cloud_dir) == os.path.normpath(expected_path):
        print("✅ 路径计算正确")
        return True
    else:
        print(f"❌ 路径计算错误，期望: {expected_path}，实际: {point_cloud_dir}")
        return False

if __name__ == "__main__":
    import os
    success = test_model_path_access()
    print("\n" + "="*50)
    if success:
        print("✅ model_path修复测试成功")
        print("现在training函数中的最终播报将能正确访问model_path")
    else:
        print("❌ model_path修复测试失败")
    print("="*50)
