# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
SAR渲染测试脚本
用于验证SAR SDGR渲染器的正确性
"""

import torch
import numpy as np
import argparse
from pathlib import Path
import matplotlib.pyplot as plt

def test_projection_matrices():
    """测试1：投影矩阵计算"""
    print("\n" + "="*60)
    print("测试1：投影矩阵计算")
    print("="*60)
    
    from sar_gaussian_projection import SARProjectionMatrices
    
    # 创建投影矩阵
    proj = SARProjectionMatrices(
        delta_A=0.34,
        delta_R=0.34,
        N_A=512,
        N_R=512,
        theta=np.deg2rad(45),
        h=12000.0
    )
    
    print("\n计算平面投影矩阵 P_C:")
    print(proj.P_C)
    print("\n成像平面投影矩阵 P_I:")
    print(proj.P_I)
    
    # 测试投影
    test_points = np.array([
        [0, 0, 0],
        [1, 2, 3],
        [10, 20, 30]
    ])
    
    points_2d = proj.project_to_imaging_plane(test_points)
    print(f"\n测试点投影:")
    for i, (p3d, p2d) in enumerate(zip(test_points, points_2d)):
        print(f"  3D点 {p3d} -> 2D点 {p2d}")
    
    print("\n✅ 投影矩阵测试通过")
    return True


def test_gaussian_projection():
    """测试2：高斯协方差矩阵投影"""
    print("\n" + "="*60)
    print("测试2：高斯协方差矩阵投影")
    print("="*60)
    
    from sar_gaussian_projection import SARGaussianProjection
    
    # 创建旋转矩阵（45度绕Z轴旋转）
    angle = np.deg2rad(45)
    R = np.array([
        [np.cos(angle), -np.sin(angle), 0],
        [np.sin(angle), np.cos(angle), 0],
        [0, 0, 1]
    ])
    
    proj = SARGaussianProjection(R)
    
    # 测试各向同性高斯
    cov3d = np.eye(3) * 0.1
    cov2d = proj.project_covariance(cov3d)
    
    print(f"\n3D协方差矩阵:")
    print(cov3d)
    print(f"\n2D协方差矩阵:")
    print(cov2d)
    
    # 检查2D协方差是否正定
    eigenvalues = np.linalg.eigvals(cov2d)
    print(f"\n2D协方差矩阵特征值: {eigenvalues}")
    
    if np.all(eigenvalues > 0):
        print("✅ 2D协方差矩阵正定")
    else:
        print("❌ 2D协方差矩阵不正定")
        return False
    
    print("\n✅ 高斯投影测试通过")
    return True


def test_coordinate_conversion():
    """测试3：坐标转换"""
    print("\n" + "="*60)
    print("测试3：坐标转换")
    print("="*60)
    
    from sar_gaussian_projection import SARCoordinateConverter
    
    converter = SARCoordinateConverter(512, 512)
    
    # 测试NDC到像素转换
    ndc_points = torch.tensor([
        [-1.0, -1.0],  # 左下角
        [0.0, 0.0],    # 中心
        [1.0, 1.0]     # 右上角
    ])
    
    pixel_points = converter.ndc_to_pixel(ndc_points)
    
    print("\nNDC -> 像素坐标:")
    for ndc, pixel in zip(ndc_points, pixel_points):
        print(f"  NDC {ndc.numpy()} -> 像素 {pixel.numpy()}")
    
    # 反向转换检验
    ndc_back = converter.pixel_to_ndc(pixel_points)
    error = torch.abs(ndc_points - ndc_back).max().item()
    
    print(f"\n往返转换误差: {error}")
    
    if error < 1e-5:
        print("✅ 坐标转换测试通过")
        return True
    else:
        print("❌ 坐标转换误差过大")
        return False


def test_conic_computation():
    """测试4：Conic矩阵计算"""
    print("\n" + "="*60)
    print("测试4：Conic矩阵计算")
    print("="*60)
    
    from sar_gaussian_projection import SARConicComputer
    
    # 创建测试协方差矩阵
    cov2d = torch.tensor([
        [[0.1, 0.0],
         [0.0, 0.1]],
        [[0.2, 0.05],
         [0.05, 0.15]]
    ])
    
    conics = SARConicComputer.compute_conic_from_covariance(cov2d)
    
    print("\n协方差矩阵 -> Conic矩阵:")
    for i, (cov, conic) in enumerate(zip(cov2d, conics)):
        print(f"\n协方差 {i}:")
        print(cov.numpy())
        print(f"Conic: [{conic[0]:.4f}, {conic[1]:.4f}, {conic[2]:.4f}]")
        
        # 验证：Conic应该是协方差的逆
        conic_mat = torch.tensor([
            [conic[0], conic[1]],
            [conic[1], conic[2]]
        ])
        product = torch.matmul(cov, conic_mat)
        identity = torch.eye(2)
        error = torch.abs(product - identity).max().item()
        print(f"验证 Σ * Conic^-1 ≈ I，误差: {error:.6f}")
        
        if error > 1e-4:
            print("❌ Conic矩阵计算错误")
            return False
    
    print("\n✅ Conic矩阵测试通过")
    return True


def test_sar_rasterizer():
    """测试5：SAR光栅化器"""
    print("\n" + "="*60)
    print("测试5：SAR光栅化器")
    print("="*60)
    
    try:
        from sar_sdgr_renderer import SARGaussianRasterizer
    except ImportError as e:
        print(f"❌ 无法导入SAR渲染器: {e}")
        return False
    
    # 创建简单测试数据
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\n使用设备: {device}")
    
    # 旋转矩阵
    R = np.eye(3)
    
    # 创建渲染器
    rasterizer = SARGaussianRasterizer(
        image_height=128,
        image_width=128,
        R_world_to_radar=R,
        use_attenuation=True
    ).to(device)
    
    # 创建测试高斯（一个在中心）
    N = 10
    means3D = torch.randn(N, 3, device=device) * 2.0
    scales = torch.ones(N, 3, device=device) * 0.5
    rotations = torch.tensor([[1, 0, 0, 0]], device=device).repeat(N, 1).float()
    opacities = torch.ones(N, 1, device=device) * 0.8
    colors = torch.ones(N, 3, device=device) * 0.5
    background = torch.zeros(3, device=device)
    
    print(f"\n渲染 {N} 个高斯...")
    
    try:
        output = rasterizer(
            means3D=means3D,
            scales=scales,
            rotations=rotations,
            opacities=opacities,
            colors=colors,
            background=background
        )
        
        rendered_image = output["render"]
        print(f"渲染图像形状: {rendered_image.shape}")
        print(f"渲染图像值范围: [{rendered_image.min():.4f}, {rendered_image.max():.4f}]")
        
        # 检查梯度
        if rendered_image.requires_grad:
            print("✅ 渲染图像支持梯度")
        else:
            print("⚠️ 渲染图像不支持梯度（可能正常，取决于输入）")
        
        # 保存测试图像
        import torchvision
        torchvision.utils.save_image(rendered_image, "test_sar_render.png")
        print("\n✅ 渲染结果已保存到 test_sar_render.png")
        
        print("\n✅ SAR光栅化器测试通过")
        return True
        
    except Exception as e:
        print(f"❌ 渲染失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_gradient_flow():
    """测试6：梯度反向传播"""
    print("\n" + "="*60)
    print("测试6：梯度反向传播")
    print("="*60)
    
    try:
        from sar_sdgr_renderer import SARGaussianRasterizer
    except ImportError:
        print("❌ 无法导入SAR渲染器")
        return False
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    R = np.eye(3)
    rasterizer = SARGaussianRasterizer(
        image_height=64,
        image_width=64,
        R_world_to_radar=R
    ).to(device)
    
    # 创建需要梯度的参数
    N = 5
    means3D = torch.randn(N, 3, device=device, requires_grad=True)
    scales = torch.ones(N, 3, device=device, requires_grad=True)
    rotations = torch.tensor([[1, 0, 0, 0]], device=device).repeat(N, 1).float()
    rotations.requires_grad = True
    opacities = torch.ones(N, 1, device=device, requires_grad=True)
    colors = torch.ones(N, 3, device=device, requires_grad=True)
    background = torch.zeros(3, device=device)
    
    print("\n执行前向传播...")
    output = rasterizer(
        means3D=means3D,
        scales=scales,
        rotations=rotations,
        opacities=opacities,
        colors=colors,
        background=background
    )
    
    rendered_image = output["render"]
    
    # 计算损失
    target = torch.ones_like(rendered_image) * 0.5
    loss = torch.nn.functional.mse_loss(rendered_image, target)
    print(f"损失值: {loss.item():.6f}")
    
    print("\n执行反向传播...")
    try:
        loss.backward()
        
        # 检查梯度
        params_with_grad = {
            "means3D": means3D,
            "scales": scales,
            "rotations": rotations,
            "opacities": opacities,
            "colors": colors
        }
        
        print("\n梯度检查:")
        all_have_grad = True
        for name, param in params_with_grad.items():
            if param.grad is not None:
                grad_norm = param.grad.norm().item()
                print(f"  {name}: 梯度范数 = {grad_norm:.6f}")
                if grad_norm == 0:
                    print(f"    ⚠️ {name} 梯度为0")
            else:
                print(f"  {name}: ❌ 无梯度")
                all_have_grad = False
        
        if all_have_grad:
            print("\n✅ 梯度反向传播测试通过")
            return True
        else:
            print("\n⚠️ 部分参数没有梯度（可能正常）")
            return True
            
    except Exception as e:
        print(f"❌ 反向传播失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """运行所有测试"""
    parser = argparse.ArgumentParser(description="SAR渲染测试")
    parser.add_argument("--test", type=str, default="all",
                      choices=["all", "projection", "gaussian", "coord", "conic", "rasterizer", "gradient"],
                      help="选择测试")
    args = parser.parse_args()
    
    print("\n" + "="*60)
    print("SAR SDGR渲染器测试套件")
    print("="*60)
    
    tests = {
        "projection": ("投影矩阵", test_projection_matrices),
        "gaussian": ("高斯投影", test_gaussian_projection),
        "coord": ("坐标转换", test_coordinate_conversion),
        "conic": ("Conic计算", test_conic_computation),
        "rasterizer": ("光栅化器", test_sar_rasterizer),
        "gradient": ("梯度流", test_gradient_flow)
    }
    
    if args.test == "all":
        tests_to_run = tests.items()
    else:
        tests_to_run = [(args.test, tests[args.test])]
    
    results = {}
    for test_name, (test_desc, test_func) in tests_to_run:
        try:
            results[test_desc] = test_func()
        except Exception as e:
            print(f"\n❌ 测试 {test_desc} 异常: {e}")
            import traceback
            traceback.print_exc()
            results[test_desc] = False
    
    # 总结
    print("\n" + "="*60)
    print("测试总结")
    print("="*60)
    
    for test_desc, passed in results.items():
        status = "✅ 通过" if passed else "❌ 失败"
        print(f"{test_desc}: {status}")
    
    total = len(results)
    passed = sum(results.values())
    print(f"\n总计: {passed}/{total} 测试通过")
    
    if passed == total:
        print("\n🎉 所有测试通过！SAR SDGR渲染器工作正常。")
        return 0
    else:
        print("\n⚠️ 部分测试失败，请检查上面的错误信息。")
        return 1


if __name__ == "__main__":
    exit(main())

