#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
测试compress_target_height.py的环境检查功能
"""

import os
import sys
import subprocess

def test_compress_script():
    """测试compress_target_height.py脚本"""

    # 测试命令 - 使用conda环境
    conda_env_python = r"C:\Users\s\miniconda3\envs\3dgs\python.exe"
    cmd = [
        conda_env_python,
        'compress_target_height.py',
        '--model_path', 'output/V1',
        '--target_h_l_ratio', '0.346',
        '--target_w_l_ratio', '0.8',  # 测试宽度约束
        '--iteration', '30000',
        '--target_only'  # 测试只压缩目标点云的功能
    ]

    print("执行测试命令:")
    print(' '.join(cmd))
    print()

    # 设置环境变量
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'

    try:
        # 执行命令
        result = subprocess.run(cmd, capture_output=True, text=False, env=env, timeout=30)

        # 解码输出
        def decode_output(data):
            if data is None:
                return ""
            try:
                return data.decode('utf-8')
            except UnicodeDecodeError:
                try:
                    return data.decode('gbk')
                except UnicodeDecodeError:
                    return data.decode('utf-8', errors='replace')

        stdout_text = decode_output(result.stdout)
        stderr_text = decode_output(result.stderr)

        print("="*60)
        print("执行结果:")
        print(f"返回码: {result.returncode}")
        print()

        if stdout_text:
            print("标准输出:")
            print(stdout_text)
            print()

        if stderr_text:
            print("标准错误:")
            print(stderr_text)
            print()

        if result.returncode == 0:
            print("[SUCCESS] 脚本执行成功")
        else:
            print("[FAILED] 脚本执行失败")

    except subprocess.TimeoutExpired:
        print("[ERROR] 脚本执行超时")
    except Exception as e:
        print(f"[ERROR] 测试失败: {e}")

if __name__ == "__main__":
    test_compress_script()
