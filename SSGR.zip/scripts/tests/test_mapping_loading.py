#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
测试GS训练时映射文件加载情况
模拟 scene/__init__.py 和 dataset_readers.py 的映射加载逻辑
"""

import os
import json
import sys

def test_mapping_loading(dataset_path):
    """测试映射文件加载"""
    print("="*80)
    print("测试GS训练时的映射文件加载")
    print("="*80)
    print(f"数据集路径: {dataset_path}\n")
    
    # 1. 检查映射文件（模拟 scene/__init__.py 第76-96行）
    print("【步骤1】加载俯视角映射文件（scene/__init__.py）")
    print("-"*80)
    
    mapping_file = os.path.join(dataset_path, 'depression_angle_mapping.json')
    depression_angle_mapping = None
    
    if os.path.exists(mapping_file):
        print(f"📋 发现俯视角映射文件: {mapping_file}")
        try:
            with open(mapping_file, 'r', encoding='utf-8') as f:
                depression_angle_mapping = json.load(f)
            print(f"   ✅ 加载了 {len(depression_angle_mapping)} 个图像的俯视角映射")
            
            # 显示前3个映射示例
            sample_items = list(depression_angle_mapping.items())[:3]
            if sample_items:
                print(f"   示例映射:")
                for img, dep in sample_items:
                    print(f"     - {img}: {dep}°")
        except Exception as e:
            print(f"   ⚠️  加载映射文件失败: {e}")
            depression_angle_mapping = None
    else:
        print(f"⚠️  未找到俯视角映射文件: {mapping_file}")
        print("   将使用文件名中的原始俯视角（可能导致位姿不一致）")
    
    print()
    
    # 2. 模拟读取COLMAP图像并匹配映射（dataset_readers.py 第127-160行）
    print("【步骤2】读取COLMAP图像并匹配映射（dataset_readers.py）")
    print("-"*80)
    
    # 读取images.txt前几行
    images_file = os.path.join(dataset_path, 'sparse', '0', 'images.txt')
    if not os.path.exists(images_file):
        print(f"❌ images.txt不存在: {images_file}")
        return
    
    test_images = []
    with open(images_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) >= 10:
                img_name = parts[9]
                test_images.append(img_name)
            if len(test_images) >= 5:  # 只测试前5张
                break
    
    print(f"测试前{len(test_images)}张图像的映射匹配:\n")
    
    for idx, extr_name in enumerate(test_images):
        print(f"图像{idx+1}: {extr_name}")
        
        # 模拟 dataset_readers.py 的匹配逻辑
        if depression_angle_mapping:
            # 从文件名解析俯视角
            try:
                # MSTAR格式: T72-15-XXX.jpg
                name_parts = extr_name.replace('.jpg', '').split('-')
                depression_angle_original = int(name_parts[1]) if len(name_parts) >= 2 else None
            except:
                depression_angle_original = None
            
            # 尝试匹配映射
            depression_angle = depression_angle_original  # 默认值
            mapping_key = None
            
            # 尝试完整文件名
            if extr_name in depression_angle_mapping:
                mapping_key = extr_name
                depression_angle = depression_angle_mapping[extr_name]
            else:
                # 尝试去掉扩展名
                name_without_ext = os.path.splitext(extr_name)[0]
                if name_without_ext in depression_angle_mapping:
                    mapping_key = name_without_ext
                    depression_angle = depression_angle_mapping[name_without_ext]
            
            if mapping_key:
                # 使用映射中的俯视角
                status = "✅" if depression_angle_original != depression_angle else "⚠️"
                print(f"  {status} 匹配成功")
                print(f"     - 文件名俯视角: {depression_angle_original}°")
                print(f"     - 映射俯视角: {depression_angle}° (SfM使用)")
                if depression_angle_original != depression_angle:
                    print(f"     - 俯视角已修正！使用映射值确保与SfM一致")
                else:
                    print(f"     - 俯视角相同，但使用映射值确保一致性")
            else:
                # 未找到映射
                print(f"  ❌ 未找到映射")
                print(f"     - 文件名俯视角: {depression_angle_original}°")
                print(f"     - 将使用文件名俯视角（可能导致焦距不一致）")
        else:
            print(f"  ❌ 映射文件未加载，将使用文件名俯视角")
        
        print()
    
    # 3. 总结
    print("="*80)
    print("【总结】")
    print("="*80)
    
    if depression_angle_mapping:
        matched = 0
        for img in test_images:
            if img in depression_angle_mapping or os.path.splitext(img)[0] in depression_angle_mapping:
                matched += 1
        
        print(f"✅ 映射文件正确加载")
        print(f"✅ {matched}/{len(test_images)} 张测试图像找到映射")
        
        if matched == len(test_images):
            print(f"\n🎉 完美！所有图像都能正确匹配映射")
            print(f"   GS训练时将使用SfM阶段的俯视角")
            print(f"   焦距计算将与SfM保持一致")
            print(f"   点云尺度不会发生变化")
        else:
            print(f"\n⚠️  部分图像无法匹配映射")
            print(f"   这些图像的焦距可能不一致")
    else:
        print(f"❌ 映射文件未加载")
        print(f"   GS训练将使用文件名俯视角")
        print(f"   可能导致焦距与SfM不一致，点云尺度变化")
    
    print("="*80)

if __name__ == '__main__':
    if len(sys.argv) > 1:
        dataset_path = sys.argv[1]
    else:
        dataset_path = 'data/24'
    
    test_mapping_loading(dataset_path)



