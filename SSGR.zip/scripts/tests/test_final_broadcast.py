#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
测试最终播报功能
"""

import os
import sys

def test_final_broadcast():
    """测试最终播报功能的尺寸计算逻辑"""

    print("🎤 测试最终播报功能 - 尺寸计算逻辑")
    print("="*50)

    # 模拟边界框数据（基于之前的分析结果）
    # 实际尺寸: H=23.961, L=23.472, W=24.688
    final_bbox_size = [23.472, 23.961, 24.688]  # [X, Y, Z]

    # 与SFM一致：基于XOZ面的几何形状确定长度和宽度
    xoz_size_x = final_bbox_size[0]  # X方向尺寸
    xoz_size_z = final_bbox_size[2]  # Z方向尺寸
    final_height = final_bbox_size[1]  # Y方向高度

    print(f"XOZ面尺寸: X={xoz_size_x:.3f}, Z={xoz_size_z:.3f}")
    print(f"高度(Y): {final_height:.3f}")

    # 根据XOZ面的几何形状：长的为长度，短的为宽度
    if xoz_size_x >= xoz_size_z:
        final_length = xoz_size_x
        final_width = xoz_size_z
        final_orientation = "X-长度，Z-宽度"
    else:
        final_length = xoz_size_z
        final_width = xoz_size_x
        final_orientation = "Z-长度，X-宽度"

    print(f"几何方向判断: {final_orientation}")
    print(f"确定长度: {final_length:.3f}, 宽度: {final_width:.3f}")

    # 计算比例
    eps = 1e-8
    final_h_l_ratio = abs(final_height) / (final_length + eps)

    # 获取约束目标值
    target_h_l = 0.4577

    print("\n📊 计算结果:")
    print("🎯 核心指标 - 高度/长度比例 (H/L): {:.4f}".format(final_h_l_ratio))
    print("🎯 SFM约束目标值 (H/L): {:.4f}".format(target_h_l))
    print("🎯 约束匹配度: {:.1%}".format(1.0 - min(abs(final_h_l_ratio - target_h_l) / target_h_l, 1.0)))

    print("\n📈 完整尺寸成果:")
    print("   目标尺寸: 高度={:.3f}, 长度={:.3f}, 宽度={:.3f}".format(abs(final_height), final_length, final_width))
    print("   几何方向: {}".format(final_orientation))
    print("   最终点数: 1,431 个")

    print("="*50)
    print("✅ 最终播报功能测试完成")

if __name__ == "__main__":
    test_final_broadcast()
