#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
测试完整P_I投影矩阵的准确性
对比简化投影vs完整投影的差异
"""

import torch
import numpy as np
import matplotlib.pyplot as plt
from sar_sdgr_renderer import SARGaussianRasterizer


def test_projection_comparison():
    """
    对比简化投影和完整P_I投影的差异
    """
    print("\n" + "="*70)
    print("测试：简化投影 vs 完整P_I投影")
    print("="*70)
    
    # 创建测试数据
    N = 1000
    np.random.seed(42)
    
    # 生成一个目标区域的3D点（如车辆，约8m x 3m x 2.5m）
    means3D = torch.zeros(N, 3)
    means3D[:, 0] = torch.randn(N) * 2.0  # X: -4 到 4米
    means3D[:, 1] = torch.randn(N) * 0.5 + 2.0  # Y: 1 到 3米（高度）
    means3D[:, 2] = torch.randn(N) * 1.0  # Z: -2 到 2米
    
    # 创建渲染器
    R_world_to_radar = np.eye(3)
    rasterizer = SARGaussianRasterizer(
        image_height=512,
        image_width=512,
        R_world_to_radar=R_world_to_radar,
        use_attenuation=True
    )
    
    # 测试投影
    scales = torch.ones(N, 3) * 0.1
    rotations = torch.zeros(N, 4)
    rotations[:, 0] = 1.0  # w=1, x=y=z=0 (单位四元数)
    
    # 简化投影
    means2D_simple, cov2D_simple, depths_simple = rasterizer.project_gaussians_to_2d(
        means3D, scales, rotations, use_full_projection=False
    )
    
    # 完整P_I投影
    means2D_full, cov2D_full, depths_full = rasterizer.project_gaussians_to_2d(
        means3D, scales, rotations, use_full_projection=True
    )
    
    # 计算差异
    diff = torch.abs(means2D_simple - means2D_full)
    mean_diff = diff.mean().item()
    max_diff = diff.max().item()
    
    print(f"\n【投影差异统计】")
    print(f"  平均差异: {mean_diff:.2f} 像素")
    print(f"  最大差异: {max_diff:.2f} 像素")
    print(f"  差异百分比: {mean_diff / 512 * 100:.2f}%")
    
    # 可视化对比
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    
    # 简化投影
    axes[0].scatter(
        means2D_simple[:, 0].cpu().numpy(),
        means2D_simple[:, 1].cpu().numpy(),
        c=depths_simple.cpu().numpy(),
        cmap='viridis',
        s=1,
        alpha=0.6
    )
    axes[0].set_title('简化投影', fontsize=14)
    axes[0].set_xlabel('X (像素)')
    axes[0].set_ylabel('Y (像素)')
    axes[0].set_xlim(0, 512)
    axes[0].set_ylim(512, 0)
    axes[0].grid(True, alpha=0.3)
    
    # 完整P_I投影
    axes[1].scatter(
        means2D_full[:, 0].cpu().numpy(),
        means2D_full[:, 1].cpu().numpy(),
        c=depths_full.cpu().numpy(),
        cmap='viridis',
        s=1,
        alpha=0.6
    )
    axes[1].set_title('完整P_I投影（论文公式10）', fontsize=14)
    axes[1].set_xlabel('X (像素)')
    axes[1].set_ylabel('Y (像素)')
    axes[1].set_xlim(0, 512)
    axes[1].set_ylim(512, 0)
    axes[1].grid(True, alpha=0.3)
    
    # 差异热图
    diff_magnitude = diff.norm(dim=1).cpu().numpy()
    scatter = axes[2].scatter(
        means2D_full[:, 0].cpu().numpy(),
        means2D_full[:, 1].cpu().numpy(),
        c=diff_magnitude,
        cmap='hot',
        s=5,
        alpha=0.8
    )
    axes[2].set_title(f'投影差异 (平均: {mean_diff:.2f}px)', fontsize=14)
    axes[2].set_xlabel('X (像素)')
    axes[2].set_ylabel('Y (像素)')
    axes[2].set_xlim(0, 512)
    axes[2].set_ylim(512, 0)
    axes[2].grid(True, alpha=0.3)
    plt.colorbar(scatter, ax=axes[2], label='差异 (像素)')
    
    plt.tight_layout()
    plt.savefig('projection_comparison.png', dpi=150, bbox_inches='tight')
    print(f"\n  ✅ 可视化保存到: projection_comparison.png")
    
    # 统计分析
    print(f"\n【详细统计】")
    print(f"  X方向平均差异: {diff[:, 0].mean().item():.2f} ± {diff[:, 0].std().item():.2f} 像素")
    print(f"  Y方向平均差异: {diff[:, 1].mean().item():.2f} ± {diff[:, 1].std().item():.2f} 像素")
    
    # 几何准确性评估
    if mean_diff < 1.0:
        print(f"\n  ✅ 差异很小（<1像素），但完整投影物理更准确")
    elif mean_diff < 5.0:
        print(f"\n  ⚠️  差异中等（1-5像素），建议使用完整投影")
    else:
        print(f"\n  🔴 差异较大（>5像素），必须使用完整投影！")
    
    return mean_diff, max_diff


def test_projection_matrix_properties():
    """
    测试P_I投影矩阵的数学性质
    """
    print("\n" + "="*70)
    print("测试：P_I投影矩阵的数学性质")
    print("="*70)
    
    # SAR参数（MSTAR典型值）
    delta_A = 0.1  # 方位向分辨率（米/像素）
    delta_R = 0.3  # 距离向分辨率（米/像素）
    N_A = 512
    N_R = 512
    theta = np.deg2rad(60.0)  # 擦地角
    h = 0.0
    
    # 构建P_I矩阵
    P_I = np.zeros((4, 4))
    P_I[0, 0] = 2.0 / (delta_A * N_A)
    P_I[0, 3] = 2.0 * h
    P_I[1, 1] = 2.0
    P_I[1, 3] = delta_R * N_R * np.sin(theta)
    P_I[2, 2] = delta_R * N_R * np.tan(theta)
    P_I[3, 3] = 1.0
    
    print(f"\n【P_I投影矩阵】")
    print(f"方位向分辨率 δ_A = {delta_A} m/px")
    print(f"距离向分辨率 δ_R = {delta_R} m/px")
    print(f"图像尺寸 = {N_A} x {N_R}")
    print(f"擦地角 θ = {np.rad2deg(theta):.1f}°")
    print(f"\nP_I =")
    print(P_I)
    
    # 测试特殊点
    test_points = np.array([
        [0, 0, 0, 1],  # 原点
        [1, 0, 0, 1],  # X轴上1米
        [0, 1, 0, 1],  # Y轴上1米
        [0, 0, 1, 1],  # Z轴上1米
    ])
    
    print(f"\n【测试点投影】")
    for i, point in enumerate(test_points):
        projected = P_I @ point
        projected_2d = projected[:2] / projected[3]
        print(f"  点 {i+1}: {point[:3]} → NDC: ({projected_2d[0]:.3f}, {projected_2d[1]:.3f})")
    
    # 计算视场范围
    fov_azimuth = N_A * delta_A  # 方位向视场（米）
    fov_range = N_R * delta_R    # 距离向视场（米）
    
    print(f"\n【视场范围】")
    print(f"  方位向: {fov_azimuth:.1f} 米")
    print(f"  距离向: {fov_range:.1f} 米")
    print(f"  场景覆盖: {fov_azimuth:.1f}m × {fov_range:.1f}m")


def compare_with_paper_example():
    """
    使用论文中的示例参数进行验证
    """
    print("\n" + "="*70)
    print("验证：使用论文示例参数")
    print("="*70)
    
    # 论文中可能使用的参数（需要根据实际论文调整）
    # 这里使用MSTAR数据集的典型参数
    
    print(f"\n【MSTAR数据集参数】")
    print(f"  中心频率: 9.6 GHz (X波段)")
    print(f"  波长: {3e8/9.6e9*100:.2f} cm")
    print(f"  方位向分辨率: 0.1 m")
    print(f"  距离向分辨率: 0.3 m")
    print(f"  图像尺寸: 512 x 512")
    print(f"  俯视角: 15°, 30°, 45° (对应擦地角: 75°, 60°, 45°)")
    
    # 不同俯视角的投影对比
    depression_angles = [15, 30, 45]
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    
    for idx, dep_angle in enumerate(depression_angles):
        grazing_angle = 90 - dep_angle
        theta = np.deg2rad(grazing_angle)
        
        # 构建P_I
        P_I = np.zeros((4, 4))
        P_I[0, 0] = 2.0 / (0.1 * 512)
        P_I[1, 1] = 2.0
        P_I[1, 3] = 0.3 * 512 * np.sin(theta)
        P_I[2, 2] = 0.3 * 512 * np.tan(theta)
        P_I[3, 3] = 1.0
        
        # 生成测试网格
        x = np.linspace(-4, 4, 20)
        y = np.linspace(0, 3, 10)
        X, Y = np.meshgrid(x, y)
        
        points = np.stack([X.flatten(), Y.flatten(), np.zeros_like(X.flatten()), np.ones_like(X.flatten())], axis=1)
        
        # 投影
        projected = (P_I @ points.T).T
        projected_2d = projected[:, :2] / projected[:, 3:4]
        
        # 转换到像素坐标
        pixel_x = (projected_2d[:, 0] + 1) * 0.5 * 512
        pixel_y = (projected_2d[:, 1] + 1) * 0.5 * 512
        
        # 绘制
        axes[idx].scatter(pixel_x, pixel_y, c=Y.flatten(), cmap='viridis', s=20)
        axes[idx].set_title(f'俯视角={dep_angle}° (擦地角={grazing_angle}°)', fontsize=12)
        axes[idx].set_xlabel('X (像素)')
        axes[idx].set_ylabel('Y (像素)')
        axes[idx].set_xlim(0, 512)
        axes[idx].set_ylim(512, 0)
        axes[idx].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('projection_different_angles.png', dpi=150, bbox_inches='tight')
    print(f"\n  ✅ 不同角度投影保存到: projection_different_angles.png")


if __name__ == "__main__":
    print("\n" + "="*70)
    print("完整P_I投影矩阵测试")
    print("="*70)
    
    # 测试1：投影对比
    mean_diff, max_diff = test_projection_comparison()
    
    # 测试2：矩阵性质
    test_projection_matrix_properties()
    
    # 测试3：论文参数验证
    compare_with_paper_example()
    
    print("\n" + "="*70)
    print("测试完成！")
    print("="*70)
    print(f"\n生成的文件：")
    print(f"  1. projection_comparison.png - 简化vs完整投影对比")
    print(f"  2. projection_different_angles.png - 不同俯视角的投影")
    print(f"\n【总结】")
    print(f"  • 平均差异: {mean_diff:.2f} 像素")
    print(f"  • 最大差异: {max_diff:.2f} 像素")
    print(f"  • 建议: 使用完整P_I投影以获得更准确的几何")
    print("="*70 + "\n")

