#!/usr/bin/env python3

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

"""
测试点云尺度约束功能
"""

import sys
import os

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_scale_constraint():
    """测试尺度约束逻辑"""
    print("🧪 测试点云尺度约束功能")

    # 模拟点云数据（手动创建简单数据，避免numpy依赖）
    # 创建偏离目标尺度的点云（比如当前是50米 × 30米）
    current_length = 50.0
    current_width = 30.0

    # 简单模拟点云范围
    x_min, x_max = -current_length/2, current_length/2
    y_min, y_max = -2, 2  # 高度范围小（不约束）
    z_min, z_max = -current_width/2, current_width/2

    print(f"📊 原始点云统计:")
    print(f"  - X范围: {x_min:.2f} 到 {x_max:.2f}米 (范围: {current_length:.2f}米)")
    print(f"  - Y范围: {y_min:.2f} 到 {y_max:.2f}米 (高度，不约束)")
    print(f"  - Z范围: {z_min:.2f} 到 {z_max:.2f}米 (范围: {current_width:.2f}米)")

    # 模拟尺度约束参数
    scale_constraint_resolution = 0.3
    scale_constraint_pixel_width = 128
    scale_constraint_pixel_height = 128
    scale_constraint_tolerance = 0.1

    # 计算目标尺度
    target_length_calc = scale_constraint_resolution * scale_constraint_pixel_width
    target_width_calc = scale_constraint_resolution * scale_constraint_pixel_height

    print(f"\n🎯 目标尺度配置:")
    print(f"  - 分辨率: {scale_constraint_resolution}米/像素")
    print(f"  - 像素尺寸: {scale_constraint_pixel_width} × {scale_constraint_pixel_height}")
    print(f"  - 目标尺度: {target_length_calc}米 × {target_width_calc}米")
    print(f"  - 容差: {scale_constraint_tolerance}")

    # 应用尺度约束逻辑（简化版）
    x_range = x_max - x_min
    z_range = z_max - z_min

    # 确定哪个方向是长度，哪个方向是宽度（使用较大的作为长度）
    if x_range >= z_range:
        current_length_meas = x_range
        current_width_meas = z_range
        length_axis = 'X'
        width_axis = 'Z'
    else:
        current_length_meas = z_range
        current_width_meas = x_range
        length_axis = 'Z'
        width_axis = 'X'

    # 检查是否需要应用尺度约束
    length_ratio = current_length_meas / target_length_calc if target_length_calc > 1e-6 else 1.0
    width_ratio = current_width_meas / target_width_calc if target_width_calc > 1e-6 else 1.0

    print(f"\n🔧 尺度分析:")
    print(f"  - 测量{length_axis}范围: {current_length_meas:.2f}米 (目标: {target_length_calc:.2f}米, 比例: {length_ratio:.3f})")
    print(f"  - 测量{width_axis}范围: {current_width_meas:.2f}米 (目标: {target_width_calc:.2f}米, 比例: {width_ratio:.3f})")

    # 如果当前尺度偏离目标尺度超过容差，应用约束
    if abs(length_ratio - 1.0) > scale_constraint_tolerance or abs(width_ratio - 1.0) > scale_constraint_tolerance:
        # 计算缩放因子（缩放到目标尺度）
        length_scale_factor = target_length_calc / current_length_meas if current_length_meas > 1e-6 else 1.0
        width_scale_factor = target_width_calc / current_width_meas if current_width_meas > 1e-6 else 1.0

        print(f"\n✅ 应用尺度约束:")
        print(f"  - {length_axis}缩放因子: {length_scale_factor:.4f}")
        print(f"  - {width_axis}缩放因子: {width_scale_factor:.4f}")
        print(f"  - Y方向（高度）保持不变")

        # 模拟约束后的结果
        new_x_range = x_range * (length_scale_factor if length_axis == 'X' else width_scale_factor)
        new_z_range = z_range * (length_scale_factor if length_axis == 'Z' else width_scale_factor)
        new_y_range = y_max - y_min  # 高度不变

        print(f"\n📊 约束后点云统计:")
        print(f"  - X范围: 中心±{new_x_range/2:.2f}米 (范围: {new_x_range:.2f}米)")
        print(f"  - Y范围: {y_min:.2f} 到 {y_max:.2f}米 (高度: {new_y_range:.2f}米)")
        print(f"  - Z范围: 中心±{new_z_range/2:.2f}米 (范围: {new_z_range:.2f}米)")

        # 验证结果
        expected_length = target_length_calc if length_axis == 'X' else target_width_calc
        expected_width = target_width_calc if width_axis == 'X' else target_length_calc
        actual_length = new_x_range if length_axis == 'X' else new_z_range
        actual_width = new_x_range if width_axis == 'X' else new_z_range

        length_error = abs(actual_length - expected_length) / expected_length * 100
        width_error = abs(actual_width - expected_width) / expected_width * 100

        print(f"\n🎯 精度验证:")
        print(f"  - 期望{length_axis}范围: {expected_length:.2f}米, 实际: {actual_length:.2f}米 (误差: {length_error:.2f}%)")
        print(f"  - 期望{width_axis}范围: {expected_width:.2f}米, 实际: {actual_width:.2f}米 (误差: {width_error:.2f}%)")

        if length_error < 1.0 and width_error < 1.0:
            print(f"  ✅ 尺度约束测试通过！")
        else:
            print(f"  ❌ 尺度约束测试失败！")

        print(f"  ✅ Y方向（高度）正确保持不变")

    else:
        print(f"  ℹ️ 当前尺度在容差范围内，无需约束")

    print(f"\n🎉 尺度约束功能测试完成")

def test_config_parameters():
    """测试配置参数是否正确添加"""
    print("\n🧪 测试配置参数")

    try:
        from config import parse_arguments
        import argparse

        # 创建一个最小参数集合来测试
        test_args = [
            '--source_path', 'test_path',
            '--sfm_enable_point_scale_constraint',
            '--sfm_scale_constraint_resolution', '0.3',
            '--sfm_scale_constraint_pixel_width', '128',
            '--sfm_scale_constraint_pixel_height', '128'
        ]

        # 解析参数
        parser = argparse.ArgumentParser()
        parser.add_argument('--source_path', required=True)
        parser.add_argument('--sfm_enable_point_scale_constraint', action='store_true', default=True)
        parser.add_argument('--sfm_scale_constraint_resolution', type=float, default=0.3)
        parser.add_argument('--sfm_scale_constraint_pixel_width', type=int, default=128)
        parser.add_argument('--sfm_scale_constraint_pixel_height', type=int, default=128)

        args = parser.parse_args(test_args)

        print("  ✅ 配置参数解析正常")
        print(f"  - sfm_enable_point_scale_constraint: {args.sfm_enable_point_scale_constraint}")
        print(f"  - sfm_scale_constraint_resolution: {args.sfm_scale_constraint_resolution}")
        print(f"  - sfm_scale_constraint_pixel_width: {args.sfm_scale_constraint_pixel_width}")
        print(f"  - sfm_scale_constraint_pixel_height: {args.sfm_scale_constraint_pixel_height}")

        # 计算目标尺度
        target_length = args.sfm_scale_constraint_resolution * args.sfm_scale_constraint_pixel_width
        target_width = args.sfm_scale_constraint_resolution * args.sfm_scale_constraint_pixel_height
        print(f"  - 计算目标尺度: {target_length}米 × {target_width}米")

    except Exception as e:
        print(f"  ❌ 配置参数测试失败: {e}")

if __name__ == "__main__":
    test_scale_constraint()
    test_config_parameters()

if __name__ == "__main__":
    test_scale_constraint()
