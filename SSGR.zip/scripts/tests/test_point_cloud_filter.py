#!/usr/bin/env python

# --- auto: ensure repo root on sys.path (script lives under scripts/) ---
import sys
from pathlib import Path as _Path
for _repo in _Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root (train.py) for " + str(_Path(__file__)))
del _Path, _repo, _s
# --- end auto ---

# -*- coding: utf-8 -*-
"""
测试点云过滤功能
对已有的训练结果点云进行过滤测试，无需重新训练
"""

import os
import sys
import argparse
import numpy as np
import torch
import torch.nn as nn
from scene.gaussian_model import GaussianModel
from utils.sh_utils import SH2RGB
from utils.system_utils import mkdir_p

def filter_point_cloud(ply_path, output_path=None, 
                       use_brightness=True, use_distance=True, use_opacity=True, 
                       use_height=True, use_clustering=True):
    """
    对点云进行过滤，提取目标点
    
    Args:
        ply_path: 输入点云文件路径
        output_path: 输出点云文件路径（可选）
        use_brightness: 是否使用亮度过滤
        use_distance: 是否使用位置过滤
        use_opacity: 是否使用不透明度过滤
        use_height: 是否使用高度过滤
        use_clustering: 是否使用DBSCAN聚类
    """
    print(f"\n{'='*70}")
    print(f"加载点云: {ply_path}")
    print(f"{'='*70}\n")
    
    # 加载点云
    if not os.path.exists(ply_path):
        print(f"❌ 错误: 文件不存在: {ply_path}")
        return False
    
    try:
        # 创建GaussianModel并加载点云
        gaussians = GaussianModel(3)  # sh_degree=3
        gaussians.load_ply(ply_path, use_train_test_exp=False)
        
        print(f"✅ 点云加载成功")
        print(f"   总点数: {gaussians._xyz.shape[0]}\n")
        
        # 获取点云属性
        xyz = gaussians._xyz.detach().cpu().numpy()
        f_dc = gaussians._features_dc.detach().cpu().numpy()  # Shape: (N, 1, 3)
        opacities = gaussians._opacity.detach().cpu().numpy().flatten()
        
        # 转换为RGB颜色
        f_dc_reshaped = f_dc.reshape(-1, 3)  # (N, 3)
        rgb_colors = SH2RGB(torch.tensor(f_dc_reshaped)).numpy()  # (N, 3)
        rgb_colors = np.clip(rgb_colors, 0.0, 1.0)
        
        # 计算亮度
        brightness = 0.299 * rgb_colors[:, 0] + 0.587 * rgb_colors[:, 1] + 0.114 * rgb_colors[:, 2]
        
        # 🔧 过滤参数（与scene/__init__.py中的参数一致）
        print(f"{'='*70}")
        print(f"应用过滤条件")
        print(f"{'='*70}\n")
        
        # 初始化所有mask（默认全部通过，如果对应过滤被禁用）
        brightness_mask = np.ones(len(brightness), dtype=bool)
        distance_mask = np.ones(len(brightness), dtype=bool)
        opacity_mask = np.ones(len(brightness), dtype=bool)
        height_mask = np.ones(len(brightness), dtype=bool)
        
        # 方法1：亮度过滤
        if use_brightness:
            target_percentile = 99.9  # 99.9%分位数
            target_brightness_threshold = np.percentile(brightness, target_percentile)
            brightness_mask = brightness >= target_brightness_threshold
            print(f"1. ✅ 亮度过滤 ({target_percentile}%): 阈值 = {target_brightness_threshold:.4f}")
            print(f"   满足条件的点数: {np.sum(brightness_mask)} ({100*np.sum(brightness_mask)/len(brightness):.1f}%)")
        else:
            print(f"1. ⏭️  亮度过滤: 已禁用")
        
        # 方法2：位置过滤
        scene_center = np.mean(xyz, axis=0)
        distances_to_center = np.linalg.norm(xyz - scene_center, axis=1)
        if use_distance:
            distance_threshold = np.percentile(distances_to_center, 80.0)
            distance_mask = distances_to_center <= distance_threshold
            print(f"\n2. ✅ 位置过滤 (80%): 阈值 = {distance_threshold:.4f}")
            print(f"   满足条件的点数: {np.sum(distance_mask)} ({100*np.sum(distance_mask)/len(distances_to_center):.1f}%)")
        else:
            print(f"\n2. ⏭️  位置过滤: 已禁用")
        
        # 方法3：不透明度过滤
        if use_opacity:
            opacity_threshold = np.percentile(opacities, 85.0)
            opacity_mask = opacities >= opacity_threshold
            print(f"\n3. ✅ 不透明度过滤 (85%): 阈值 = {opacity_threshold:.4f}")
            print(f"   满足条件的点数: {np.sum(opacity_mask)} ({100*np.sum(opacity_mask)/len(opacities):.1f}%)")
        else:
            print(f"\n3. ⏭️  不透明度过滤: 已禁用")
        
        # 方法4：高度过滤
        heights = -xyz[:, 1]  # 反转Y坐标（Y轴负方向是高度正向）
        if use_height:
            ground_height = np.percentile(heights, 10.0)
            height_range = np.percentile(heights, 90.0) - ground_height
            height_threshold = ground_height + height_range * 0.3
            height_mask = heights >= height_threshold
            print(f"\n4. ✅ 高度过滤:")
            print(f"   地面高度: {ground_height:.4f}, 高度阈值: {height_threshold:.4f}")
            print(f"   满足条件的点数: {np.sum(height_mask)} ({100*np.sum(height_mask)/len(heights):.1f}%)")
        else:
            print(f"\n4. ⏭️  高度过滤: 已禁用")
        
        # 基础条件组合
        # 构建条件列表（只包含启用的过滤）
        conditions = []
        if use_distance:
            conditions.append(distance_mask)
        if use_opacity:
            conditions.append(opacity_mask)
        if use_height:
            conditions.append(height_mask)
        
        # 组合过滤条件
        if use_brightness:
            if len(conditions) > 0:
                # 亮度必须满足，同时满足位置、不透明度或高度条件之一
                combined_conditions = np.any(conditions, axis=0) if len(conditions) > 1 else conditions[0]
                candidate_mask = brightness_mask & combined_conditions
            else:
                # 只有亮度过滤
                candidate_mask = brightness_mask
        else:
            if len(conditions) > 0:
                # 没有亮度过滤，使用位置、不透明度或高度条件
                candidate_mask = np.any(conditions, axis=0) if len(conditions) > 1 else conditions[0]
            else:
                # 所有过滤都被禁用
                candidate_mask = np.ones(len(brightness), dtype=bool)
        
        # 显示激活的过滤方法
        active_filters = []
        if use_brightness:
            active_filters.append("亮度")
        if use_distance:
            active_filters.append("位置")
        if use_opacity:
            active_filters.append("不透明度")
        if use_height:
            active_filters.append("高度")
        
        if len(active_filters) == 0:
            print(f"\n⚠️  警告: 所有基础过滤方法都已禁用")
        
        candidate_indices = np.where(candidate_mask)[0]
        print(f"\n5. 基础条件组合:")
        print(f"   激活的过滤方法: {', '.join(active_filters) if active_filters else '无'}")
        print(f"   候选点数: {len(candidate_indices)} ({100*len(candidate_indices)/len(brightness):.1f}%)")
        candidate_indices = np.where(candidate_mask)[0]
        print(f"\n5. 基础条件组合:")
        print(f"   候选点数: {len(candidate_indices)} ({100*len(candidate_indices)/len(brightness):.1f}%)")
        
        # 方法5：DBSCAN聚类
        if use_clustering and len(candidate_indices) > 100:
            try:
                from sklearn.cluster import DBSCAN
                from sklearn.neighbors import NearestNeighbors
                
                print(f"\n6. ✅ DBSCAN聚类:")
                candidate_xyz = xyz[candidate_indices]
                candidate_brightness = brightness[candidate_indices]
                
                # 计算自适应eps
                if len(candidate_xyz) > 50:
                    nbrs = NearestNeighbors(n_neighbors=min(10, len(candidate_xyz)//10)).fit(candidate_xyz)
                    distances, _ = nbrs.kneighbors(candidate_xyz)
                    eps = np.percentile(distances[:, 1:], 50)
                    eps = max(eps, 0.01)
                else:
                    eps = 0.1
                
                print(f"   eps = {eps:.4f}")
                
                # DBSCAN聚类
                clustering = DBSCAN(eps=eps, min_samples=5).fit(candidate_xyz)
                cluster_labels = clustering.labels_
                
                # 找到最大的聚类
                unique_labels, counts = np.unique(cluster_labels[cluster_labels >= 0], return_counts=True)
                if len(unique_labels) > 0:
                    largest_cluster_label = unique_labels[np.argmax(counts)]
                    cluster_brightness = {}
                    for label in unique_labels:
                        cluster_brightness[label] = np.mean(candidate_brightness[cluster_labels == label])
                    
                    best_cluster_label = largest_cluster_label
                    for label in unique_labels:
                        if counts[unique_labels == label][0] >= counts[unique_labels == largest_cluster_label][0] * 0.7:
                            if cluster_brightness[label] > cluster_brightness[best_cluster_label] * 1.1:
                                best_cluster_label = label
                    
                    # 创建聚类mask
                    target_mask = np.zeros(len(brightness), dtype=bool)
                    target_mask[candidate_indices[cluster_labels == best_cluster_label]] = True
                    
                    print(f"   聚类数量: {len(unique_labels)}")
                    print(f"   最大聚类大小: {counts[np.argmax(counts)]}")
                    print(f"   选择聚类大小: {counts[unique_labels == best_cluster_label][0]}")
                else:
                    # 回退到基础条件
                    target_mask = candidate_mask
                    print(f"   ⚠️ 聚类失败，使用基础条件")
            except ImportError:
                # 回退到基础条件
                target_mask = candidate_mask
                print(f"   ⚠️ sklearn不可用，使用基础条件")
            except Exception as e:
                # 回退到基础条件
                target_mask = candidate_mask
                print(f"   ⚠️ 聚类失败 ({e})，使用基础条件")
        else:
            # 使用基础条件组合
            target_mask = candidate_mask
            if not use_clustering:
                print(f"\n6. ⏭️  DBSCAN聚类: 已禁用")
            else:
                print(f"\n6. ⏭️  候选点太少 ({len(candidate_indices)} < 100)，跳过聚类")
        
        # 统计结果
        num_target_points = np.sum(target_mask)
        num_background_points = len(brightness) - num_target_points
        
        print(f"\n{'='*70}")
        print(f"过滤结果统计")
        print(f"{'='*70}\n")
        print(f"总点数: {len(brightness)}")
        print(f"目标点数: {num_target_points} ({100*num_target_points/len(brightness):.1f}%)")
        print(f"背景点数: {num_background_points} ({100*num_background_points/len(brightness):.1f}%)")
        
        # 保存过滤后的点云
        if output_path is None:
            base_name = os.path.splitext(ply_path)[0]
            output_path = f"{base_name}_filtered.ply"
        
        print(f"\n{'='*70}")
        print(f"保存过滤后的点云: {output_path}")
        print(f"{'='*70}\n")
        
        gaussians.save_ply_filtered(output_path, target_mask)
        print(f"✅ 过滤后的点云已保存: {output_path}\n")
        
        return True
        
    except Exception as e:
        print(f"❌ 错误: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    parser = argparse.ArgumentParser(
        description="测试点云过滤功能 - 可单独启用/禁用每个过滤方法",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  # 只使用亮度过滤
  python test_point_cloud_filter.py -i input.ply --no-distance --no-opacity --no-height --no-clustering
  
  # 使用亮度+位置过滤
  python test_point_cloud_filter.py -i input.ply --no-opacity --no-height --no-clustering
  
  # 使用所有过滤（默认）
  python test_point_cloud_filter.py -i input.ply
  
  # 禁用亮度过滤，使用其他所有方法
  python test_point_cloud_filter.py -i input.ply --no-brightness
  
  # 只使用高度过滤
  python test_point_cloud_filter.py -i input.ply --no-brightness --no-distance --no-opacity --no-clustering
        """
    )
    parser.add_argument("--input", "-i", type=str, required=True,
                       help="输入点云文件路径 (.ply)")
    parser.add_argument("--output", "-o", type=str, default=None,
                       help="输出点云文件路径 (可选，默认: <input>_filtered.ply)")
    
    # 过滤方法开关
    parser.add_argument("--no-brightness", action="store_true",
                       help="禁用亮度过滤")
    parser.add_argument("--no-distance", action="store_true",
                       help="禁用位置过滤")
    parser.add_argument("--no-opacity", action="store_true",
                       help="禁用不透明度过滤")
    parser.add_argument("--no-height", action="store_true",
                       help="禁用高度过滤")
    parser.add_argument("--no-clustering", action="store_true",
                       help="禁用DBSCAN聚类")
    
    args = parser.parse_args()
    
    # 执行过滤
    success = filter_point_cloud(
        args.input,
        args.output,
        use_brightness=not args.no_brightness,
        use_distance=not args.no_distance,
        use_opacity=not args.no_opacity,
        use_height=not args.no_height,
        use_clustering=not args.no_clustering
    )
    
    if success:
        print("✅ 过滤测试完成！")
        sys.exit(0)
    else:
        print("❌ 过滤测试失败！")
        sys.exit(1)

if __name__ == "__main__":
    main()
