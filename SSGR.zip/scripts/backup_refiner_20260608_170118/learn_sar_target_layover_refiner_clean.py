#!/usr/bin/env python3
"""
Clean SAR target layover refiner.

This script is intentionally narrow: it learns a target-only, azimuth-conditioned
log-domain correction from 3DGS target renders to adjacent real SAR target style.
It does not synthesize background, paste back the source target, or paint shadows
as a postprocess.
"""

from __future__ import annotations

import math
import re
import sys
from argparse import ArgumentParser, BooleanOptionalAction
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from tqdm import tqdm

for _repo in Path(__file__).resolve().parents:
    if (_repo / "train.py").is_file():
        _s = str(_repo)
        if _s not in sys.path:
            sys.path.insert(0, _s)
        break
else:
    raise RuntimeError("Could not locate repo root from " + str(Path(__file__)))

from scripts.rendering.learn_sar_image_refiner import (  # noqa: E402
    _blur01,
    _dilate01_batch,
    _force_grayscale_batch,
    _gradient_mag_map,
    _image_files,
    _load_image,
    _local_std_map,
    _parse_azimuth,
    _parse_quantiles,
    _resize_chw,
)


class ConvBlock(nn.Module):
    def __init__(self, cin: int, cout: int, padding_mode: str = "reflect"):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(cin, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
            nn.Conv2d(cout, cout, 3, padding=1, padding_mode=padding_mode),
            nn.GroupNorm(4, cout),
            nn.SiLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class CleanLayoverUNet(nn.Module):
    def __init__(self, in_ch: int = 5, base: int = 32, padding_mode: str = "reflect"):
        super().__init__()
        self.e1 = ConvBlock(in_ch, base, padding_mode)
        self.e2 = ConvBlock(base, base * 2, padding_mode)
        self.e3 = ConvBlock(base * 2, base * 4, padding_mode)
        self.mid = ConvBlock(base * 4, base * 4, padding_mode)
        self.d2 = ConvBlock(base * 6, base * 2, padding_mode)
        self.d1 = ConvBlock(base * 3, base, padding_mode)
        self.out = nn.Conv2d(base, 3, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e1 = self.e1(x)
        e2 = self.e2(F.avg_pool2d(e1, 2))
        e3 = self.e3(F.avg_pool2d(e2, 2))
        y = self.mid(e3)
        y = F.interpolate(y, size=e2.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d2(torch.cat([y, e2], dim=1))
        y = F.interpolate(y, size=e1.shape[-2:], mode="bilinear", align_corners=False)
        y = self.d1(torch.cat([y, e1], dim=1))
        return self.out(y)


def _configure_torch(args, device: torch.device) -> None:
    if device.type != "cuda":
        return
    allow_tf32 = bool(getattr(args, "allow_tf32", True))
    if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
        torch.backends.cuda.matmul.allow_tf32 = allow_tf32
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.allow_tf32 = allow_tf32
        torch.backends.cudnn.benchmark = bool(getattr(args, "cudnn_benchmark", True))
    try:
        torch.set_float32_matmul_precision("high" if allow_tf32 else "highest")
    except Exception:
        pass


def _derive_paths(args) -> None:
    model_path = Path(args.model_path) if args.model_path else None
    if model_path is not None:
        args.train_target_dir = args.train_target_dir or str(model_path / "train_renders")
        args.train_gt_dir = args.train_gt_dir or str(model_path / "train_gt")
        args.apply_target_dir = args.apply_target_dir or str(model_path / "novel_target_only" / "target_renders")
        args.output_dir = args.output_dir or str(model_path / "novel_sar_target_layover_clean")
        args.checkpoint = args.checkpoint or str(model_path / "sar_target_layover_refiner_clean.pth")
    if not args.checkpoint:
        args.checkpoint = str(Path(args.output_dir or ".") / "sar_target_layover_refiner_clean.pth")


def _ld(x: torch.Tensor, scale: float) -> torch.Tensor:
    return torch.log1p(x.clamp(0.0, 1.0) * scale) / math.log1p(scale)


def _from_ld(x: torch.Tensor, scale: float) -> torch.Tensor:
    return torch.expm1(x.clamp(0.0, 1.0) * math.log1p(scale)) / scale


def _angle_dist(a: float, b: float) -> float:
    d = abs(float(a) - float(b)) % 360.0
    return min(d, 360.0 - d)


def _azimuth_prefix(path: Path) -> str:
    stem = path.stem
    m = re.search(r"(?i)azimuth[_-]?(\d+(?:\.\d+)?)", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    m = re.search(r"(\d+(?:\.\d+)?)$", stem)
    if m:
        return stem[: m.start(1)].rstrip("_-")
    return stem


def _candidates(path: Path) -> list[dict]:
    return [{"path": p, "azimuth": _parse_azimuth(p), "prefix": _azimuth_prefix(p)} for p in _image_files(path)]


def _nearest(cands: list[dict], az: float) -> dict:
    if not cands:
        raise RuntimeError("No azimuth candidates")
    return min(cands, key=lambda c: (_angle_dist(float(c["azimuth"]), az), c["path"].name))


def _bracket(cands: list[dict], az: float) -> tuple[dict, dict, float, float]:
    ordered = sorted(cands, key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    if not ordered:
        raise RuntimeError("No GT candidates")
    if len(ordered) == 1:
        return ordered[0], ordered[0], 1.0, 0.0
    target = float(az) % 360.0
    exact = [c for c in ordered if _angle_dist(float(c["azimuth"]), target) <= 1e-6]
    if exact:
        return exact[0], exact[0], 1.0, 0.0
    back = [((target - float(c["azimuth"])) % 360.0, c) for c in ordered]
    fwd = [((float(c["azimuth"]) - target) % 360.0, c) for c in ordered]
    prev_gap, prev = min((x for x in back if x[0] > 1e-6), key=lambda x: (x[0], x[1]["path"].name))
    next_gap, nxt = min((x for x in fwd if x[0] > 1e-6), key=lambda x: (x[0], x[1]["path"].name))
    total = max(prev_gap + next_gap, 1e-6)
    return prev, nxt, next_gap / total, prev_gap / total


def _select_pairs(target_dir: Path, gt_dir: Path, args) -> list[dict]:
    targets = sorted(_candidates(target_dir), key=lambda c: (float(c["azimuth"]) % 360.0, c["path"].name))
    gts = _candidates(gt_dir)
    if not targets or not gts:
        raise RuntimeError(f"No training images found: {target_dir} vs {gt_dir}")
    gt_by_prefix: dict[str, list[dict]] = {}
    for g in gts:
        gt_by_prefix.setdefault(g["prefix"], []).append(g)
    selected = []
    if not bool(getattr(args, "train_use_all_targets", False)):
        step = max(float(getattr(args, "train_azimuth_step", 10.0) or 10.0), 1e-6)
        slots = {round((i * step) % 360.0, 6) for i in range(int(math.ceil(360.0 / step)))}
        targets = [_nearest(targets, s) for s in sorted(slots)]
    for t in targets:
        az = float(t["azimuth"]) % 360.0
        pool = gt_by_prefix.get(t["prefix"], gts)
        lo, hi, wlo, whi = _bracket(pool, az)
        selected.append({"target": t["path"], "azimuth": az, "lo": lo, "hi": hi, "wlo": wlo, "whi": whi})
    return selected


def _mix_gt(gt_lo: torch.Tensor, gt_hi: torch.Tensor, wlo: float, whi: float, scale: float) -> torch.Tensor:
    lo = _ld(gt_lo, scale)
    hi = _ld(gt_hi, scale)
    return _from_ld(lo * float(wlo) + hi * float(whi), scale).clamp(0.0, 1.0)


def _target_mask(target: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    threshold = float(getattr(args, "target_loss_mask_threshold", 0.08) or 0.08)
    mask = (gray > threshold).float()
    if float(mask.sum()) < float(getattr(args, "target_loss_mask_min_pixels", 16.0) or 16.0):
        vals = gray[gray > 0]
        if int(vals.numel()) > 0:
            mask = (gray >= torch.quantile(vals, 0.35)).float()
    dilate = int(getattr(args, "target_loss_mask_dilate", 2) or 0)
    if dilate > 0:
        mask = _dilate01_batch(mask[None], dilate)[0]
    return mask.clamp(0.0, 1.0)


def _compose_alpha_one(target: torch.Tensor, args) -> torch.Tensor:
    gray = target.mean(dim=0).clamp(0.0, 1.0)
    low = max(float(getattr(args, "compose_alpha_threshold", 0.012) or 0.012), 0.0)
    high = max(float(getattr(args, "compose_alpha_high", 0.08) or 0.08), low + 1e-6)
    alpha = ((gray - low) / (high - low)).clamp(0.0, 1.0)
    alpha = alpha.pow(max(float(getattr(args, "compose_alpha_gamma", 0.8) or 0.8), 0.05))
    dilate = int(getattr(args, "compose_alpha_dilate", 0) or 0)
    if dilate > 0:
        alpha = _dilate01_batch(alpha[None], dilate)[0]
    blur = int(getattr(args, "compose_alpha_blur", 0) or 0)
    if blur > 0:
        alpha = _blur01(alpha, blur)
    return alpha.clamp(0.0, 1.0)


def _compose_alpha_batch(target: torch.Tensor, args) -> torch.Tensor:
    if target.dim() == 3:
        return _compose_alpha_one(target, args)
    return torch.stack([_compose_alpha_one(target[i], args) for i in range(target.shape[0])], dim=0)


def _make_input(target: torch.Tensor, mask: torch.Tensor, azimuth: float, scale: float) -> torch.Tensor:
    gray = target.mean(dim=0, keepdim=True).clamp(0.0, 1.0)
    ld = _ld(gray, scale)
    h, w = gray.shape[-2:]
    rad = math.radians(float(azimuth) % 360.0)
    sin = torch.full((1, h, w), math.sin(rad), device=target.device, dtype=target.dtype)
    cos = torch.full((1, h, w), math.cos(rad), device=target.device, dtype=target.dtype)
    return torch.cat([gray, ld, mask[None], sin, cos], dim=0)


def _dark_supervision(target: torch.Tensor, gt_mix: torch.Tensor, gt_lo: torch.Tensor, gt_hi: torch.Tensor, mask: torch.Tensor, args) -> torch.Tensor:
    scale = float(getattr(args, "log_intensity_scale", 20.0) or 20.0)
    src = _ld(target.mean(dim=0, keepdim=True), scale)[0]
    mix = _ld(gt_mix.mean(dim=0, keepdim=True), scale)[0]
    lo = _ld(gt_lo.mean(dim=0, keepdim=True), scale)[0]
    hi = _ld(gt_hi.mean(dim=0, keepdim=True), scale)[0]
    # A dark layover candidate is bright in the 3DGS target but dark in either
    # adjacent real view.  Using min(lo, hi) avoids averaging dark structures away.
    gt_dark = torch.minimum(lo, hi)
    bright_src = ((src - float(args.dark_src_threshold)) / max(1e-6, 1.0 - float(args.dark_src_threshold))).clamp(0.0, 1.0)
    dark_gap = ((src - gt_dark - float(args.dark_gap_threshold)) / max(float(args.dark_gap_softness), 1e-6)).clamp(0.0, 1.0)
    mix_gap = ((src - mix - float(args.dark_gap_threshold) * 0.5) / max(float(args.dark_gap_softness), 1e-6)).clamp(0.0, 1.0)
    dark = torch.maximum(dark_gap, mix_gap * 0.5) * bright_src * mask
    blur = int(getattr(args, "dark_supervision_blur", 1) or 0)
    if blur > 0:
        dark = _blur01(dark, blur) * mask
    return dark.clamp(0.0, 1.0)


def _content_support(gt: torch.Tensor, mask: torch.Tensor, args) -> torch.Tensor:
    gray = gt.mean(dim=0).clamp(0.0, 1.0)
    threshold = max(float(getattr(args, "content_gt_support_threshold", 0.015) or 0.015), 0.0)
    support = (gray > threshold).float() * mask
    dilate = int(getattr(args, "content_gt_support_dilate", 1) or 0)
    if dilate > 0:
        support = _dilate01_batch(support[None], dilate)[0] * mask
    blur = int(getattr(args, "content_gt_support_blur", 0) or 0)
    if blur > 0:
        support = _blur01(support, blur) * mask
    return support.clamp(0.0, 1.0)


def _erode01_one(mask: torch.Tensor, radius: int) -> torch.Tensor:
    if radius <= 0:
        return mask.clamp(0.0, 1.0)
    inv = (1.0 - mask).clamp(0.0, 1.0)
    return (1.0 - _dilate01_batch(inv[None], radius)[0]).clamp(0.0, 1.0)


def _bright_profile_maps(gt: torch.Tensor, mask: torch.Tensor, args) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    gray = gt.mean(dim=0).clamp(0.0, 1.0)
    m = mask.clamp(0.0, 1.0)
    valid = (m > 0.5) & (gray > 0)
    if int(valid.sum()) >= 8:
        q = min(max(float(getattr(args, "bright_profile_core_quantile", 0.82) or 0.82), 0.0), 1.0)
        thr_q = torch.quantile(gray[valid], q)
    else:
        thr_q = gray.new_tensor(float(getattr(args, "bright_profile_core_threshold", 0.12) or 0.12))
    thr_abs = gray.new_tensor(max(float(getattr(args, "bright_profile_core_threshold", 0.12) or 0.12), 0.0))
    thr = torch.minimum(thr_q, thr_abs) if int(valid.sum()) < 32 else torch.maximum(thr_q, thr_abs)
    core = ((gray >= thr) & (m > 0.5)).float()
    if float(core.sum()) < float(getattr(args, "bright_profile_min_core_pixels", 8.0) or 8.0) and int(valid.sum()) > 0:
        fallback_q = min(max(1.0 - float(getattr(args, "bright_profile_min_core_pixels", 8.0) or 8.0) / max(float(valid.sum()), 1.0), 0.0), 1.0)
        core = ((gray >= torch.quantile(gray[valid], fallback_q)) & (m > 0.5)).float()
    core_dilate = int(getattr(args, "bright_profile_core_dilate", 1) or 0)
    if core_dilate > 0:
        core = _dilate01_batch(core[None], core_dilate)[0] * m

    radius = max(int(getattr(args, "bright_profile_radius", 14) or 14), 1)
    covered = core.clamp(0.0, 1.0)
    dist = torch.ones_like(m)
    dist = torch.where(covered > 0.5, torch.zeros_like(dist), dist)
    for step in range(1, radius + 1):
        grown = _dilate01_batch(covered[None], 1)[0] * m
        new = (grown > 0.5) & (covered <= 0.5)
        dist = torch.where(new, dist.new_tensor(float(step) / float(radius)), dist)
        covered = grown
    dist = dist.clamp(0.0, 1.0) * m

    floor = max(float(getattr(args, "bright_profile_floor_log", 0.025) or 0.025), 0.0)
    near = max(float(getattr(args, "bright_profile_near_log", 0.24) or 0.24), 0.0)
    decay = max(float(getattr(args, "bright_profile_decay", 3.5) or 3.5), 0.0)
    ceiling = (floor + near * torch.exp(-dist * decay)).clamp(0.0, 1.0) * m

    power = max(float(getattr(args, "bright_profile_distance_power", 1.5) or 1.5), 0.05)
    profile_weight = dist.pow(power) * m * (1.0 - core).clamp(0.0, 1.0)
    min_dist = max(float(getattr(args, "bright_profile_min_distance", 0.05) or 0.05), 0.0)
    if min_dist > 0:
        profile_weight = profile_weight * (dist >= min_dist).float()

    ring_width = int(getattr(args, "boundary_ring_width", 2) or 0)
    inner = _erode01_one(m, ring_width)
    ring = (m - inner).clamp(0.0, 1.0)
    far = max(float(getattr(args, "boundary_far_distance", 0.35) or 0.35), 0.0)
    boundary_weight = ring * (dist >= far).float() * dist.pow(power)
    return ceiling, profile_weight.clamp(0.0, 1.0), boundary_weight.clamp(0.0, 1.0)


def _extinction_target(target: torch.Tensor, gt_mix: torch.Tensor, gt_lo: torch.Tensor, gt_hi: torch.Tensor, mask: torch.Tensor, args) -> torch.Tensor:
    scale = float(getattr(args, "log_intensity_scale", 20.0) or 20.0)
    src = _ld(target.mean(dim=0, keepdim=True), scale)[0]
    mix = _ld(gt_mix.mean(dim=0, keepdim=True), scale)[0]
    lo = _ld(gt_lo.mean(dim=0, keepdim=True), scale)[0]
    hi = _ld(gt_hi.mean(dim=0, keepdim=True), scale)[0]
    dark_ref = torch.minimum(lo, hi)
    ref_mode = str(getattr(args, "extinction_target_reference", "min_mix") or "min_mix").lower().strip()
    if ref_mode == "mix":
        ref = mix
    elif ref_mode == "dark":
        ref = dark_ref
    else:
        ref = torch.minimum(mix, dark_ref)
    margin = max(float(getattr(args, "extinction_target_margin", 0.0) or 0.0), 0.0)
    strength = max(float(getattr(args, "extinction_log_strength", 0.55) or 0.55), 1e-6)
    target_ext = ((src - ref - margin).clamp_min(0.0) / strength).clamp(0.0, 1.0) * mask
    gamma = max(float(getattr(args, "extinction_target_gamma", 1.0) or 1.0), 0.05)
    if abs(gamma - 1.0) > 1e-6:
        target_ext = target_ext.pow(gamma)
    blur = int(getattr(args, "extinction_target_blur", 0) or 0)
    if blur > 0:
        target_ext = _blur01(target_ext, blur) * mask
    return target_ext.clamp(0.0, 1.0)


def _compose(raw: torch.Tensor, target: torch.Tensor, mask: torch.Tensor, args) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    scale = float(getattr(args, "log_intensity_scale", 20.0) or 20.0)
    target_gray = target.mean(dim=1, keepdim=True).clamp(0.0, 1.0)
    src_ld = _ld(target_gray, scale)
    delta = torch.tanh(raw[:, 0:1]) * float(args.delta_log_scale)
    extinction = torch.sigmoid(raw[:, 1:2])
    gain = torch.tanh(raw[:, 2:3]) * float(args.bright_log_scale)
    m = mask[:, None].clamp(0.0, 1.0)
    pred_ld = src_ld + (delta + gain - extinction * float(args.extinction_log_strength)) * m
    pred = _from_ld(pred_ld, scale).clamp(0.0, 1.0)
    pred = pred.expand(-1, 3, -1, -1).contiguous()
    compose_alpha = _compose_alpha_batch(target, args)[:, None].clamp(0.0, 1.0)
    extinction_alpha_weight = max(float(getattr(args, "extinction_compose_alpha_weight", 0.0) or 0.0), 0.0)
    if extinction_alpha_weight > 0:
        extinction_alpha_gamma = max(float(getattr(args, "extinction_compose_alpha_gamma", 1.0) or 1.0), 0.05)
        extinction_alpha = (extinction.clamp(0.0, 1.0).pow(extinction_alpha_gamma) * m * extinction_alpha_weight).clamp(0.0, 1.0)
        compose_alpha = torch.maximum(compose_alpha, extinction_alpha)
    pred = (pred * compose_alpha + target_gray.expand_as(pred) * (1.0 - compose_alpha)).clamp(0.0, 1.0)
    return pred, {"delta_log": delta, "extinction": extinction, "gain_log": gain, "compose_alpha": compose_alpha}


def _masked_mean(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    if mask.dim() == 3:
        mask = mask[:, None]
    return (x * mask).sum() / (mask.sum().clamp_min(1.0) * x.shape[1])


def _quantile_loss(pred_ld: torch.Tensor, gt_ld: torch.Tensor, mask: torch.Tensor, quantiles: list[float]) -> torch.Tensor:
    losses = []
    if mask.dim() == 3:
        mask = mask[:, None]
    valid = mask > 0.5
    for b in range(pred_ld.shape[0]):
        vals_p = pred_ld[b][valid[b].expand_as(pred_ld[b])]
        vals_g = gt_ld[b][valid[b].expand_as(gt_ld[b])]
        if int(vals_p.numel()) < 8 or int(vals_g.numel()) < 8:
            continue
        q = torch.tensor(quantiles, device=pred_ld.device, dtype=pred_ld.dtype)
        losses.append((torch.quantile(vals_p, q) - torch.quantile(vals_g, q)).abs().mean())
    if not losses:
        return torch.zeros((), device=pred_ld.device, dtype=pred_ld.dtype)
    return torch.stack(losses).mean()


def _train(args, device: torch.device) -> CleanLayoverUNet:
    pairs = _select_pairs(Path(args.train_target_dir), Path(args.train_gt_dir), args)
    dark_pairs = (
        _select_pairs(Path(args.train_target_dir), Path(args.dark_gt_dir), args)
        if getattr(args, "dark_gt_dir", None)
        else pairs
    )
    dark_by_target = {p["target"].name: p for p in dark_pairs}
    Path(args.checkpoint).parent.mkdir(parents=True, exist_ok=True)
    report = Path(args.checkpoint).parent / "train_azimuth_pairs.txt"
    with report.open("w", encoding="utf-8") as f:
        f.write("target\tazimuth\tgt_lo\tlo_az\tlo_w\tgt_hi\thi_az\thi_w\n")
        for p in pairs:
            f.write(
                f"{p['target'].name}\t{p['azimuth']:.3f}\t{p['lo']['path'].name}\t{float(p['lo']['azimuth']):.3f}\t{p['wlo']:.6f}"
                f"\t{p['hi']['path'].name}\t{float(p['hi']['azimuth']):.3f}\t{p['whi']:.6f}\n"
            )
    print(f"[clean layover] train pairs: {len(pairs)}; report: {report}")

    model = CleanLayoverUNet(base=int(args.model_base), padding_mode=str(args.conv_padding_mode)).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
    scaler = torch.amp.GradScaler("cuda", enabled=bool(args.amp) and device.type == "cuda")
    quantiles = _parse_quantiles(str(args.stat_quantiles))
    scale = float(args.log_intensity_scale)

    loaded = []
    for p in pairs:
        dark_p = dark_by_target.get(p["target"].name, p)
        target = _load_image(p["target"], args).to(device)
        gt_lo = _resize_chw(_load_image(p["lo"]["path"], args).to(device), tuple(target.shape[-2:]))
        gt_hi = _resize_chw(_load_image(p["hi"]["path"], args).to(device), tuple(target.shape[-2:]))
        gt_mix = _mix_gt(gt_lo, gt_hi, float(p["wlo"]), float(p["whi"]), scale)
        dark_gt_lo = _resize_chw(_load_image(dark_p["lo"]["path"], args).to(device), tuple(target.shape[-2:]))
        dark_gt_hi = _resize_chw(_load_image(dark_p["hi"]["path"], args).to(device), tuple(target.shape[-2:]))
        dark_gt_mix = _mix_gt(dark_gt_lo, dark_gt_hi, float(dark_p["wlo"]), float(dark_p["whi"]), scale)
        mask = _target_mask(target, args)
        dark = _dark_supervision(target, dark_gt_mix, dark_gt_lo, dark_gt_hi, mask, args)
        ext_target = _extinction_target(target, dark_gt_mix, dark_gt_lo, dark_gt_hi, mask, args)
        content_support = (
            _content_support(dark_gt_mix, mask, args)
            if bool(getattr(args, "content_loss_use_dark_gt_support", False)) and getattr(args, "dark_gt_dir", None)
            else mask
        )
        profile_ceiling, profile_weight, boundary_weight = _bright_profile_maps(dark_gt_mix, mask, args)
        loaded.append(
            (
                target,
                gt_mix,
                dark_gt_mix,
                mask,
                content_support,
                dark,
                ext_target,
                profile_ceiling,
                profile_weight,
                boundary_weight,
                float(p["azimuth"]),
                p["target"].name,
            )
        )

    pbar = tqdm(range(int(args.iterations)), desc="train clean layover", dynamic_ncols=True, mininterval=float(args.progress_refresh_seconds))
    bad_steps = 0
    for it in pbar:
        idx = torch.randint(0, len(loaded), (int(args.batch_size),), device=device)
        targets, gts, dark_gts, masks, content_supports, darks, ext_targets = [], [], [], [], [], [], []
        profile_ceilings, profile_weights, boundary_weights, azs = [], [], [], []
        for i in idx.tolist():
            t, g, dg, m, cs, d, e, pc, pw, bw, az, _name = loaded[i]
            targets.append(t)
            gts.append(g)
            dark_gts.append(dg)
            masks.append(m)
            content_supports.append(cs)
            darks.append(d)
            ext_targets.append(e)
            profile_ceilings.append(pc)
            profile_weights.append(pw)
            boundary_weights.append(bw)
            azs.append(az)
        target_b = torch.stack(targets, dim=0)
        gt_b = torch.stack(gts, dim=0)
        dark_gt_b = torch.stack(dark_gts, dim=0)
        mask_b = torch.stack(masks, dim=0)
        content_support_b = torch.stack(content_supports, dim=0)
        dark_b = torch.stack(darks, dim=0)
        ext_target_b = torch.stack(ext_targets, dim=0)
        profile_ceiling_b = torch.stack(profile_ceilings, dim=0)
        profile_weight_b = torch.stack(profile_weights, dim=0)
        boundary_weight_b = torch.stack(boundary_weights, dim=0)
        x_b = torch.stack([_make_input(targets[i], masks[i], azs[i], scale) for i in range(len(targets))], dim=0)

        opt.zero_grad(set_to_none=True)
        with torch.amp.autocast(device_type=device.type, enabled=bool(args.amp) and device.type == "cuda"):
            raw = model(x_b)
            pred, maps = _compose(raw, target_b, mask_b, args)
            pred_ld = _ld(pred, scale)
            gt_ld = _ld(gt_b, scale)
            dark_gt_ld = _ld(dark_gt_b, scale)
            src_ld = _ld(target_b.mean(dim=1, keepdim=True).expand_as(pred), scale)
            content_mask = content_support_b.clamp(0.0, 1.0)
            target_l1 = _masked_mean((pred_ld - gt_ld).abs(), content_mask)
            dark_mask = dark_b[:, None]
            ext_target = ext_target_b[:, None]
            dark_ceiling = _masked_mean((pred_ld - dark_gt_ld.detach()).clamp_min(0.0).pow(2), dark_mask)
            ext_bce = F.binary_cross_entropy(maps["extinction"].clamp(1e-4, 1.0 - 1e-4), dark_mask.clamp(0.0, 1.0))
            ext_reg = _masked_mean(F.smooth_l1_loss(maps["extinction"], ext_target, reduction="none"), mask_b)
            ext_structure = _masked_mean((_gradient_mag_map(maps["extinction"]) - _gradient_mag_map(ext_target)).abs(), mask_b)
            visible = (content_mask[:, None] * (1.0 - dark_mask)).clamp(0.0, 1.0)
            identity = _masked_mean((pred_ld - src_ld).abs(), visible)
            grad = _masked_mean((_gradient_mag_map(pred_ld) - _gradient_mag_map(gt_ld)).abs(), content_mask)
            pred_std = _local_std_map(pred_ld, int(args.local_texture_radius))
            gt_std = _local_std_map(gt_ld, int(args.local_texture_radius))
            texture = _masked_mean((pred_std - gt_std).abs(), content_mask)
            quant = _quantile_loss(pred_ld, gt_ld, content_mask, quantiles)
            profile_ceiling = profile_ceiling_b[:, None].clamp(0.0, 1.0)
            profile_weight = profile_weight_b[:, None].clamp(0.0, 1.0)
            boundary_weight = boundary_weight_b[:, None].clamp(0.0, 1.0)
            profile = _masked_mean((pred_ld - profile_ceiling).clamp_min(0.0).pow(2), profile_weight)
            boundary_ceiling = float(args.boundary_ceiling_log)
            boundary = _masked_mean((pred_ld - boundary_ceiling).clamp_min(0.0).pow(2), boundary_weight)
            sparsity = _masked_mean(maps["extinction"], mask_b)
            loss = (
                float(args.target_l1_weight) * target_l1
                + float(args.dark_ceiling_weight) * dark_ceiling
                + float(args.extinction_bce_weight) * ext_bce
                + float(args.extinction_regression_weight) * ext_reg
                + float(args.extinction_structure_weight) * ext_structure
                + float(args.bright_profile_loss_weight) * profile
                + float(args.boundary_suppression_weight) * boundary
                + float(args.visible_identity_weight) * identity
                + float(args.gradient_loss_weight) * grad
                + float(args.texture_loss_weight) * texture
                + float(args.quantile_loss_weight) * quant
                + float(args.extinction_sparsity_weight) * sparsity
            )

        if not torch.isfinite(loss):
            bad_steps += 1
            if bad_steps > 20:
                raise RuntimeError("Too many non-finite clean layover losses")
            continue
        scaler.scale(loss).backward()
        if float(args.max_grad_norm) > 0:
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(args.max_grad_norm))
        scaler.step(opt)
        scaler.update()

        if it % max(1, int(args.progress_interval)) == 0:
            pbar.set_postfix(
                l1=f"{float(target_l1.detach()):.4f}",
                dark=f"{float(dark_ceiling.detach()):.4f}",
                ext=f"{float(ext_bce.detach()):.4f}",
                ereg=f"{float(ext_reg.detach()):.4f}",
                prof=f"{float(profile.detach()):.4f}",
                tex=f"{float(texture.detach()):.4f}",
            )

    ckpt = {
        "model": model.state_dict(),
        "args": vars(args),
        "refiner_mode": "target_layover_clean",
        "in_ch": 5,
        "out_ch": 3,
        "train_pairs": [name for *_rest, name in loaded],
    }
    torch.save(ckpt, args.checkpoint)
    print(f"[clean layover] saved checkpoint: {args.checkpoint}")
    model.eval()
    return model


def _load_model(args, device: torch.device) -> CleanLayoverUNet:
    ckpt = torch.load(args.checkpoint, map_location=device)
    ckpt_args = ckpt.get("args", {})
    base = int(ckpt_args.get("model_base", args.model_base))
    model = CleanLayoverUNet(base=base, padding_mode=str(getattr(args, "conv_padding_mode", "reflect"))).to(device)
    model.load_state_dict(ckpt["model"], strict=True)
    model.eval()
    print(f"[clean layover] loaded checkpoint: {args.checkpoint}")
    return model


@torch.no_grad()
def _run_one(model: CleanLayoverUNet, target: torch.Tensor, az: float, args) -> tuple[torch.Tensor, torch.Tensor, dict[str, torch.Tensor]]:
    scale = float(args.log_intensity_scale)
    mask = _target_mask(target, args)
    x = _make_input(target, mask, az, scale)[None]
    raw = model(x)
    pred, maps = _compose(raw, target[None], mask[None], args)
    pred = _force_grayscale_batch(pred, args)[0]
    return pred, mask, {k: v[0] for k, v in maps.items()}


def _apply(args, model: CleanLayoverUNet, device: torch.device) -> None:
    target_dir = Path(args.apply_target_dir)
    out_root = Path(args.output_dir)
    render_dir = out_root / "renders"
    target_dir_out = out_root / "target_modulated_renders"
    map_dir = out_root / "maps"
    render_dir.mkdir(parents=True, exist_ok=True)
    target_dir_out.mkdir(parents=True, exist_ok=True)
    if bool(args.save_maps):
        map_dir.mkdir(parents=True, exist_ok=True)

    files = _image_files(target_dir)
    if not files:
        raise RuntimeError(f"No apply target renders found: {target_dir}")
    for path in tqdm(files, desc="apply clean layover", dynamic_ncols=True):
        target = _load_image(path, args).to(device)
        az = _parse_azimuth(path)
        pred, mask, maps = _run_one(model, target, az, args)
        torchvision.utils.save_image(pred.clamp(0.0, 1.0), str(target_dir_out / path.name))
        torchvision.utils.save_image(pred.clamp(0.0, 1.0), str(render_dir / path.name))
        if bool(args.save_maps):
            stem = path.stem
            torchvision.utils.save_image(mask[None], str(map_dir / f"{stem}_mask.png"))
            for name, value in maps.items():
                img = value.detach().clamp(-1.0, 1.0)
                if name in {"delta_log", "gain_log"}:
                    img = img * 0.5 + 0.5
                torchvision.utils.save_image(img, str(map_dir / f"{stem}_{name}.png"))
    print(f"[clean layover] wrote: {out_root}")


def main() -> None:
    parser = ArgumentParser(description="Clean target-only SAR layover refiner")
    parser.add_argument("-m", "--model_path", type=str, default=None)
    parser.add_argument("--train_target_dir", type=str, default=None)
    parser.add_argument("--train_gt_dir", type=str, default=None)
    parser.add_argument("--dark_gt_dir", type=str, default=None)
    parser.add_argument("--apply_target_dir", type=str, default=None)
    parser.add_argument("--output_dir", type=str, default=None)
    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--postprocess_output_dir", type=str, default=None)
    parser.add_argument("--refiner_mode", type=str, default="target_layover_clean")
    parser.add_argument("--train_only", action="store_true", default=False)
    parser.add_argument("--apply_only", action="store_true", default=False)
    parser.add_argument("--target_only_refiner", action=BooleanOptionalAction, default=True)
    parser.add_argument("--train_use_all_targets", action=BooleanOptionalAction, default=False)
    parser.add_argument("--train_azimuth_step", type=float, default=10.0)
    parser.add_argument("--iterations", type=int, default=5000)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--model_base", type=int, default=32)
    parser.add_argument("--conv_padding_mode", choices=["zeros", "reflect", "replicate", "circular"], default="reflect")
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--amp", action="store_true", default=False)
    parser.add_argument("--allow_tf32", action=BooleanOptionalAction, default=True)
    parser.add_argument("--cudnn_benchmark", action=BooleanOptionalAction, default=True)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--progress_metrics", choices=["compact", "full", "none"], default="compact")
    parser.add_argument("--progress_interval", type=int, default=20)
    parser.add_argument("--progress_refresh_seconds", type=float, default=0.5)
    parser.add_argument("--grayscale_sar", action=BooleanOptionalAction, default=True)
    parser.add_argument("--force_grayscale_output", action=BooleanOptionalAction, default=True)
    parser.add_argument("--log_intensity_scale", type=float, default=20.0)
    parser.add_argument("--target_loss_mask_threshold", type=float, default=0.08)
    parser.add_argument("--target_loss_mask_dilate", type=int, default=2)
    parser.add_argument("--target_loss_mask_min_pixels", type=float, default=16.0)
    parser.add_argument("--compose_alpha_threshold", type=float, default=0.012)
    parser.add_argument("--compose_alpha_high", type=float, default=0.08)
    parser.add_argument("--compose_alpha_gamma", type=float, default=0.8)
    parser.add_argument("--compose_alpha_dilate", type=int, default=0)
    parser.add_argument("--compose_alpha_blur", type=int, default=0)
    parser.add_argument("--extinction_compose_alpha_weight", type=float, default=0.0)
    parser.add_argument("--extinction_compose_alpha_gamma", type=float, default=1.0)
    parser.add_argument("--delta_log_scale", type=float, default=0.35)
    parser.add_argument("--bright_log_scale", type=float, default=0.18)
    parser.add_argument("--extinction_log_strength", type=float, default=0.55)
    parser.add_argument("--dark_src_threshold", type=float, default=0.16)
    parser.add_argument("--dark_gap_threshold", type=float, default=0.12)
    parser.add_argument("--dark_gap_softness", type=float, default=0.18)
    parser.add_argument("--dark_supervision_blur", type=int, default=1)
    parser.add_argument("--content_loss_use_dark_gt_support", action=BooleanOptionalAction, default=False)
    parser.add_argument("--content_gt_support_threshold", type=float, default=0.015)
    parser.add_argument("--content_gt_support_dilate", type=int, default=1)
    parser.add_argument("--content_gt_support_blur", type=int, default=0)
    parser.add_argument("--extinction_target_reference", choices=["min_mix", "mix", "dark"], default="min_mix")
    parser.add_argument("--extinction_target_gamma", type=float, default=1.0)
    parser.add_argument("--extinction_target_margin", type=float, default=0.0)
    parser.add_argument("--extinction_target_blur", type=int, default=0)
    parser.add_argument("--target_l1_weight", type=float, default=0.55)
    parser.add_argument("--dark_ceiling_weight", type=float, default=1.6)
    parser.add_argument("--extinction_bce_weight", type=float, default=0.9)
    parser.add_argument("--extinction_regression_weight", type=float, default=0.0)
    parser.add_argument("--extinction_structure_weight", type=float, default=0.0)
    parser.add_argument("--bright_profile_loss_weight", type=float, default=0.0)
    parser.add_argument("--bright_profile_core_quantile", type=float, default=0.82)
    parser.add_argument("--bright_profile_core_threshold", type=float, default=0.12)
    parser.add_argument("--bright_profile_min_core_pixels", type=float, default=8.0)
    parser.add_argument("--bright_profile_core_dilate", type=int, default=1)
    parser.add_argument("--bright_profile_radius", type=int, default=14)
    parser.add_argument("--bright_profile_decay", type=float, default=3.5)
    parser.add_argument("--bright_profile_floor_log", type=float, default=0.025)
    parser.add_argument("--bright_profile_near_log", type=float, default=0.24)
    parser.add_argument("--bright_profile_distance_power", type=float, default=1.5)
    parser.add_argument("--bright_profile_min_distance", type=float, default=0.05)
    parser.add_argument("--boundary_suppression_weight", type=float, default=0.0)
    parser.add_argument("--boundary_ring_width", type=int, default=2)
    parser.add_argument("--boundary_far_distance", type=float, default=0.35)
    parser.add_argument("--boundary_ceiling_log", type=float, default=0.04)
    parser.add_argument("--visible_identity_weight", type=float, default=0.06)
    parser.add_argument("--gradient_loss_weight", type=float, default=0.30)
    parser.add_argument("--texture_loss_weight", type=float, default=0.45)
    parser.add_argument("--quantile_loss_weight", type=float, default=0.20)
    parser.add_argument("--extinction_sparsity_weight", type=float, default=0.004)
    parser.add_argument("--local_texture_radius", type=int, default=2)
    parser.add_argument("--stat_quantiles", type=str, default="0.05,0.10,0.25,0.50,0.75,0.90,0.97")
    parser.add_argument("--save_maps", action=BooleanOptionalAction, default=True)
    args, unknown = parser.parse_known_args()
    if unknown:
        unknown_opts = [x for x in unknown if str(x).startswith("-")]
        shown = ", ".join(unknown_opts[:16])
        suffix = "" if len(unknown_opts) <= 16 else f", ... (+{len(unknown_opts) - 16})"
        print(f"[clean layover] warning: ignoring unsupported CLI options: {shown}{suffix}", file=sys.stderr)
    _derive_paths(args)
    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    _configure_torch(args, device)
    if args.apply_only:
        model = _load_model(args, device)
    else:
        if not args.train_target_dir or not args.train_gt_dir:
            raise RuntimeError("Training requires --train_target_dir and --train_gt_dir")
        model = _train(args, device)
    if not args.train_only:
        if not args.apply_target_dir:
            raise RuntimeError("Apply requires --apply_target_dir")
        _apply(args, model, device)


if __name__ == "__main__":
    main()
