"""
固定目标初始点云前提下，**仅**联合拟合背景 / 阴影，服务新方位角 NVS（不过拟合训练角）。

设计要点（相对旧 exp15-5）：
- 冻结初始目标高斯（不 densify、不反传），只增生/优化背景+阴影；
- 背景片状种子落在 **目标底面水平面**（ground_plane），避免光学俯视下背景斜面在多视角纠缠成锥；
- 阴影沿相机→目标方向多层薄板初值，训练期靠分区损失 + 叠掩正则细化；
- 新增高斯 DC 亮度上限 = 目标中位亮度 × ``sar_refine_new_point_max_luma_fraction``（默认 0.5），
  禁止为凑训练视角而长出倾斜高亮平面盖住目标；
- 默认 **关闭** 旧版 shape/ground/spread/depth_order/旧亮度帽 等抑制项；按需再手动打开。

铺路（``--no_sar_refine_seed_bg_shadow_plates`` 可关）：placement=ground_plane 时
背景在底面水平网格；阴影仍为沿 ω 的多层薄板（见 sar_seed_refine_bg_shadow.py）。
"""
from __future__ import annotations

import os
import sys
from argparse import Namespace
from typing import List, Optional


def _cli_specifies_dest(argv: Optional[List[str]], dest: str) -> bool:
    if not argv:
        return False
    flag = "--" + dest
    pre = flag + "="
    for a in argv:
        if a == flag or a.startswith(pre):
            return True
    return False


def apply_sar_refine_target_bg_preset(args: Namespace, argv: Optional[List[str]] = None) -> None:
    """
    BG/阴影 NVS 预设：命令行已显式传入的参数不会被覆盖。
    """
    if argv is None:
        argv = sys.argv[1:]

    uniform = bool(getattr(args, "sar_refine_uniform_loss", False))
    light_densify = bool(getattr(args, "sar_refine_light_densify", True))

    o: dict = {
        # ---------- 只训 BG + 阴影 ----------
        "sar_refine_freeze_target_gaussians": True,
        "sar_refine_bg_shadow_only_loss": True,
        "sar_target_only_loss_until_iter": 0,
        "sar_uniform_region_loss": uniform,
        "background_loss_weight": 1.0,
        "shadow_loss_weight": 1.35,
        "target_loss_weight": 0.0,
        "edge_loss_weight": 0.0,
        "sar_refine_bg_shadow_target_anchor_weight": 0.02,
        "lambda_dssim": 0.04,
        "sar_target_gradient_l1_weight": 0.0,
        # ---------- 新视角：插值软监督 ----------
        "sar_interp_soft_supervision": True,
        "sar_interp_soft_every": 250,
        "sar_interp_soft_weight": 0.22,
        "sar_interp_soft_start_iter": 800,
        "sar_interp_soft_t_values": "0.2,0.35,0.5,0.65,0.8",
        "sar_interp_soft_samples_per_step": 1,
        # ---------- 阴影叠掩细化（非硬 depth_order） ----------
        "sar_refine_shadow_over_occlusion_weight": 0.18,
        "sar_refine_shadow_under_occlusion_weight": 0.08,
        "sar_refine_shadow_occlusion_margin": 0.035,
        # ---------- 背景水平面软约束（替代旧 sar_ground/spread） ----------
        "sar_refine_bg_ground_plane_weight": 0.06,
        "sar_refine_bg_ground_plane_tol_frac": 0.045,
        "sar_refine_seed_ground_axis": "z",
        "sar_refine_seed_ground_bottom_quantile": 0.10,
        # ---------- 新增点：≤ 目标中位亮度 × 0.5（防倾斜高亮平面） ----------
        "sar_refine_brightness_cap_disable": True,
        "sar_refine_brightness_cap_weight": 0.0,
        "sar_refine_new_point_max_luma_fraction": 0.5,
        "sar_refine_new_point_luma_cap_weight": 0.35,
        # ---------- 默认关闭的旧抑制项（要求 2） ----------
        "sar_shape_constraint_weight": 0.0,
        "sar_ground_constraint_weight": 0.0,
        "sar_spread_constraint_weight": 0.0,
        "sar_target_depth_order_weight": 0.0,
        "sar_shadow_depth_before_target": False,
        "sar_target_dimension_constraint_weight": 0.0,
        "sar_scale_constraint_weight": 0.0,
        "sar_target_height_constraint_weight": 0.0,
        "sar_height_constraint_weight": 0.0,
        "sar_shadow_constraint_weight": 0.0,
        "sar_multiview_consistency_weight": 0.0,
        "sar_refine_disable_clamp_scaling": True,
        "sar_dense_shadow_scaling_log_cap": -999.0,
        "sar_dense_by_dc_luminance": False,
        # ---------- 种子：背景水平面 + 多层阴影 ----------
        "sar_refine_seed_placement_mode": "ground_plane",
        "sar_refine_seed_bg_plane_resolution": 18,
        "sar_refine_seed_bg_plane_resolution_v": 18,
        "sar_refine_seed_shadow_plane_resolution": 14,
        "sar_refine_seed_shadow_plane_resolution_v": 14,
        "sar_refine_seed_shadow_depth_fracs": "0.010,0.022,0.038",
        "sar_refine_seed_bg_brightness_scale": 0.42,
        "sar_refine_seed_shadow_brightness_scale": 0.28,
        "sar_refine_seed_plane_gaussian_scale_mult": 1.55,
        "sar_refine_seed_slab_thin_scale_mult": 0.38,
        "sar_refine_seed_bg_initial_opacity": 0.32,
        "sar_refine_seed_shadow_initial_opacity": 0.38,
        "sar_refine_seed_above_extent_frac": 0.022,
        # ---------- 学习率 / densify：允许 BG/SH 大量增生 ----------
        "position_lr_init": 6.5e-5,
        "position_lr_final": 8.0e-7,
        "scaling_lr": 0.0055,
        "rotation_lr": 0.0014,
        "opacity_lr": 0.04,
        "percent_dense": 0.014,
        "densify_from_iter": 400,
        "opacity_reset_interval": 100000,
        "densification_interval": 100,
        "densify_grad_threshold": 0.00085,
        "sh_degree_interval": 900,
        "sar_stratify_azimuth": True,
    }

    if light_densify:
        o["densify_until_iter"] = 28_000
        o["densification_interval"] = 90
        o["densify_grad_threshold"] = 0.00075
        o["densify_from_iter"] = 450
        o["percent_dense"] = 0.016
    else:
        o["densify_until_iter"] = 0

    skipped = [k for k in o if _cli_specifies_dest(argv, k)]
    for k, v in o.items():
        if _cli_specifies_dest(argv, k):
            continue
        if (
            k == "sar_shadow_depth_before_target"
            and argv is not None
            and "--no_sar_shadow_depth_before_target" in argv
        ):
            continue
        if hasattr(args, k):
            setattr(args, k, v)

    print("\n" + "=" * 62)
    print("sar_refine_target_bg：BG/阴影 NVS 预设（冻结目标 + 水平背景 + 半亮度新增上限）")
    print("=" * 62)
    print(f"  sar_refine_freeze_target_gaussians: {getattr(args, 'sar_refine_freeze_target_gaussians', False)}")
    print(f"  sar_refine_bg_shadow_only_loss: {getattr(args, 'sar_refine_bg_shadow_only_loss', False)}")
    print(f"  sar_uniform_region_loss: {getattr(args, 'sar_uniform_region_loss', False)}")
    print(f"  sar_refine_light_densify: {light_densify}")
    print(f"  densify_until_iter: {getattr(args, 'densify_until_iter', '?')}")
    print(f"  seed placement: {getattr(args, 'sar_refine_seed_placement_mode', '?')}")
    print(
        f"  新增点亮度上限: {getattr(args, 'sar_refine_new_point_max_luma_fraction', 0.5):.2f}×目标 DC 中位 "
        f"(weight={getattr(args, 'sar_refine_new_point_luma_cap_weight', 0)})"
    )
    print(
        f"  区域 L1（bg/shadow/目标锚定）: "
        f"{getattr(args, 'background_loss_weight', '?')}/"
        f"{getattr(args, 'shadow_loss_weight', '?')}/"
        f"anchor={getattr(args, 'sar_refine_bg_shadow_target_anchor_weight', 0)}"
    )
    print(
        f"  阴影叠掩正则 over/under: "
        f"{getattr(args, 'sar_refine_shadow_over_occlusion_weight', 0)}/"
        f"{getattr(args, 'sar_refine_shadow_under_occlusion_weight', 0)}"
    )
    print(
        f"  背景水平面软约束 weight={getattr(args, 'sar_refine_bg_ground_plane_weight', 0)} "
        f"(axis={getattr(args, 'sar_refine_seed_ground_axis', 'z')})"
    )
    print(
        f"  已默认关闭: shape/ground/spread/depth_order/旧亮度帽/clamp_scaling/shadow_log_cap"
    )
    if bool(getattr(args, "sar_interp_soft_supervision", False)):
        print(
            f"  插值软监督: every={getattr(args, 'sar_interp_soft_every', '?')}, "
            f"w={getattr(args, 'sar_interp_soft_weight', '?')}"
        )
    if light_densify:
        print(
            "  提示：阴影仍可能偏多；可试 --sar_dense_by_dc_luminance 且压低 shadow_upper，"
            "或略增 sar_refine_shadow_over_occlusion_weight。"
        )
    if skipped:
        print(f"  （以下项保留命令行，预设未覆盖: {', '.join(skipped)}）")
    print("=" * 62 + "\n")


def write_refine_eval_suggestions(model_path: str, source_path: str, iterations: int) -> str:
    os.makedirs(model_path, exist_ok=True)
    out = os.path.join(model_path, "refine_eval_suggestions.txt")
    repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cr = os.path.join(repo, "scripts", "evaluation", "compare_render_gt.py")
    last = os.path.join(model_path, "test", "ours_" + str(iterations), "renders")
    gt = os.path.join(model_path, "test", "ours_" + str(iterations), "gt")
    lines = [
        "# SAR refine BG/SH 模式：新视角验证示例",
        f"# 数据根目录: {os.path.abspath(source_path)}",
        f"# 模型目录: {os.path.abspath(model_path)}",
        "",
        "# 1) scripts/rendering/render_novel_sar_views.py --novel_pose_mode colmap_track",
        "# 2) compare_render_gt（无 GT 时可只做目视对比）",
        f'# python "{cr}" ^',
        f'#   --render_dir "{last}" ^',
        f'#   --gt_dir "{gt}" ^',
        f'#   --output_dir "{os.path.join(model_path, "refine_novel_compare")}"',
        "",
    ]
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return out
