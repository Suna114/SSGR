"""SAR 场景锚点：底面/footprint 中心与相机视线交汇原点（COLMAP 世界系，Y 向下）。"""

from __future__ import annotations

import os
from typing import Any, Optional, Tuple

import numpy as np


def sar_footprint_bottom_center(
    pts: np.ndarray,
    *,
    y_percentile: float = 90.0,
) -> np.ndarray:
    """
    稀疏/点云在 XZ 的 footprint 中心 + 底面 Y（高 Y 分位，COLMAP Y 向下为「地面侧」）。
    作为目标接地点，与水平圆环相机共视原点语义一致。
    """
    p = np.asarray(pts, dtype=np.float64).reshape(-1, 3)
    if p.shape[0] == 0:
        return np.zeros(3, dtype=np.float64)
    yp = float(np.clip(y_percentile, 50.0, 100.0))
    return np.array(
        [
            float(np.median(p[:, 0])),
            float(np.percentile(p[:, 1], yp)),
            float(np.median(p[:, 2])),
        ],
        dtype=np.float64,
    )


def resolve_scene_anchor_mu(
    pts: np.ndarray,
    args: Optional[Any] = None,
) -> Tuple[np.ndarray, str]:
    """根据 ``sfm_center_scene_anchor`` 选择平移量 μ（世界点 x' = x - μ）。"""
    mode = "ground_contact"
    if args is not None:
        mode = str(getattr(args, "sfm_center_scene_anchor", "ground_contact") or "ground_contact").strip().lower()
    if mode in ("ground_contact", "footprint_bottom", "bottom", "sar"):
        y_pct = 90.0
        if args is not None:
            try:
                y_pct = float(getattr(args, "sfm_center_scene_ground_y_percentile", 90.0) or 90.0)
            except (TypeError, ValueError):
                y_pct = 90.0
        return sar_footprint_bottom_center(pts, y_percentile=y_pct), "ground_contact"
    if mode in ("mean", "centroid", "avg"):
        p = np.asarray(pts, dtype=np.float64).reshape(-1, 3)
        if p.shape[0] == 0:
            return np.zeros(3, dtype=np.float64), "mean"
        return np.mean(p, axis=0).astype(np.float64), "mean"
    raise ValueError(
        f"未知 sfm_center_scene_anchor={mode!r}；可选 ground_contact / mean"
    )


def colmap_apply_world_translation_to_sparse(
    sparse_dir: str,
    mu: np.ndarray,
) -> int:
    """
    平移 COLMAP 点云与外参：x' = x - μ，t' = t + R @ μ。
    返回更新的相机数量。
    """
    mu = np.asarray(mu, dtype=np.float64).reshape(3)
    if float(np.linalg.norm(mu)) < 1e-12:
        return 0

    from post_sfm.colmap_points import read_points3d_binary_full, sync_colmap_point_outputs

    bin_path = os.path.join(sparse_dir, "points3D.bin")
    if os.path.isfile(bin_path):
        records = read_points3d_binary_full(bin_path)
        for rec in records:
            rec.xyz = (rec.xyz.reshape(3) - mu).astype(np.float64)
        sync_colmap_point_outputs(sparse_dir, records)

    img_bin = os.path.join(sparse_dir, "images.bin")
    img_txt = os.path.join(sparse_dir, "images.txt")
    n_cam = 0
    try:
        from scene.colmap_loader import (
            read_extrinsics_binary,
            read_extrinsics_text,
            rotmat2qvec,
        )

        if os.path.isfile(img_bin):
            images = read_extrinsics_binary(img_bin)
        elif os.path.isfile(img_txt):
            images = read_extrinsics_text(img_txt)
        else:
            return 0

        mu_col = mu.reshape(3, 1)
        for im in images.values():
            R = im.qvec2rotmat()
            t = np.asarray(im.tvec, dtype=np.float64).reshape(3, 1)
            t_new = (t + R @ mu_col).reshape(3)
            qvec = rotmat2qvec(R)
            images[im.id] = im._replace(qvec=qvec, tvec=t_new)
            n_cam += 1

        if os.path.isfile(img_bin):
            with open(img_bin, "wb") as fid:
                import struct

                fid.write(struct.pack("<Q", len(images)))
                for im in images.values():
                    q = np.asarray(im.qvec, dtype=np.float64).reshape(4)
                    t = np.asarray(im.tvec, dtype=np.float64).reshape(3)
                    fid.write(struct.pack("<i", int(im.id)))
                    fid.write(struct.pack("<ddddddd", *q, *t))
                    fid.write(struct.pack("<i", int(im.camera_id)))
                    fid.write(im.name.encode("utf-8") + b"\x00")
                    n2d = im.xys.shape[0]
                    fid.write(struct.pack("<Q", n2d))
                    for j in range(n2d):
                        fid.write(
                            struct.pack(
                                "<ddq",
                                float(im.xys[j, 0]),
                                float(im.xys[j, 1]),
                                int(im.point3D_ids[j]),
                            )
                        )
        if os.path.isfile(img_txt):
            with open(img_txt, "w", encoding="utf-8") as f:
                f.write("# Image list with two lines of data per image:\n")
                f.write("#   IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n")
                f.write("#   POINTS2D[] as (X, Y, POINT3D_ID)\n")
                f.write(f"# Number of images: {len(images)}\n")
                for im in images.values():
                    q = np.asarray(im.qvec, dtype=np.float64).reshape(4)
                    t = np.asarray(im.tvec, dtype=np.float64).reshape(3)
                    f.write(
                        f"{im.id} {q[0]:.17g} {q[1]:.17g} {q[2]:.17g} {q[3]:.17g} "
                        f"{t[0]:.17g} {t[1]:.17g} {t[2]:.17g} {im.camera_id} {im.name}\n"
                    )
                    if im.xys.shape[0] == 0:
                        f.write("\n")
                        continue
                    parts = [
                        f"{im.xys[j, 0]:.6f} {im.xys[j, 1]:.6f} {int(im.point3D_ids[j])}"
                        for j in range(im.xys.shape[0])
                    ]
                    f.write(" ".join(parts) + "\n")
    except Exception:
        return n_cam
    return n_cam


def maybe_center_colmap_scene_at_sar_anchor(
    source_path: str,
    args: Any,
    *,
    tag: str = "mesh_prior",
) -> bool:
    """replace 后：将 footprint 底面中心（或均值）平移到原点并同步外参。"""
    if not bool(getattr(args, "sfm_center_scene_after_prior_replace", True)):
        return False
    sparse_dir = os.path.join(source_path, "sparse", "0")
    bin_path = os.path.join(sparse_dir, "points3D.bin")
    if not os.path.isfile(bin_path):
        return False
    from post_sfm.colmap_points import read_points3d_binary_full

    records = read_points3d_binary_full(bin_path)
    if not records:
        return False
    pts = np.stack([r.xyz for r in records], axis=0)
    mu, mode = resolve_scene_anchor_mu(pts, args)
    if float(np.linalg.norm(mu)) < 1e-12:
        return False
    n_cam = colmap_apply_world_translation_to_sparse(sparse_dir, mu)
    label = "底面/footprint 中心" if mode == "ground_contact" else "点云均值"
    print(
        f"   📍 {tag}: SAR 场景平移 μ=({mu[0]:.5f},{mu[1]:.5f},{mu[2]:.5f})（{label}→原点）；"
        f"已更新 sparse/0 点云与 {n_cam} 个相机 tvec"
    )
    try:
        from sar.colmap_pose_sync import sync_sar_scale_params_cameras_from_sparse

        sync_sar_scale_params_cameras_from_sparse(
            source_path, args=args, verbose=True
        )
    except Exception as e:
        print(f"   ⚠️ sar_scale_params 外参同步失败: {e}")
    return True
