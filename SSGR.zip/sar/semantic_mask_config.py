"""SfM(convert) 与 GS(train) 共用的语义/散射掩码参数与 from_convert 缓存约定。

唯一默认值来源：SEMANTIC_MASK_DEFAULTS。修改默认配方请只改此字典。

from_convert 目录结构::

    scattering_masks/from_convert/
        latest.json              # 指向最近一次 convert 生成的批次
        20260523_153045/         # 按时间戳命名的批次子文件夹
            *_mask.npy
            semantic_params.json
        20260522_101200/
            ...
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import time
from typing import Any, Dict, Optional, Tuple, List

import numpy as np

CONVERT_MASK_SUBDIR = "from_convert"
CONVERT_MASK_LATEST_FILE = "latest.json"

# convert / train 共用默认（MSTAR / BMP2 推荐配方）
SEMANTIC_MASK_DEFAULTS: Dict[str, Any] = {
    # filter_background: 与 utils/filter_background.py --percentile --largest_cc 一致
    # scatter_percentile: 旧版散射分位数 + 中心 ROI + 语义最大连通域
    "target_selection_mode": "filter_background",
    "target_percentile": 95.0,
    "target_filter_blur_sigma": 1.0,
    "target_filter_open_iter": 1,
    "target_filter_close_iter": 2,
    "target_filter_morph_kernel": 5,
    "target_filter_largest_cc": True,
    "target_filter_min_target_ratio": 0.002,
    "target_filter_min_cc_area": 0,
    "target_filter_erode_px": 0,
    "background_percentile": 1.0,
    "shadow_percentile": 25.0,
    "shadow_threshold_factor": 0.15,
    "target_mask_dilate_px": 0,
    "target_edge_band_px": 2,
    "target_edge_inner_px": 2,
    "target_edge_outer_px": 1,
    "merge_scattering_target_edge": False,
    "target_center_roi_fraction": 0.78,
    "target_center_roi_min_keep_fraction": 0.15,
    "target_mask_largest_component_only": True,
    "target_mask_min_component_area_px": 15,
    "target_semantic_largest_component_only": True,
    "target_semantic_keep_dilate_px": 3,
    "shadow_target_dilate_px": 1,
    "shadow_min_area_fraction": 0.006,
    "shadow_min_target_area_fraction": 0.2,
    "shadow_y_margin_fraction": 0.15,
    "shadow_bridge_along_azimuth": False,
    "shadow_bridge_length_px": 13,
    "shadow_bridge_width_px": 5,
    "shadow_use_azimuth_prior": True,
    "shadow_direction_offset_deg": 180.0,
    "shadow_azimuth_tolerance_deg": 70.0,
    "shadow_azimuth_direction_weight": 0.28,
    "shadow_dataset_consistency": True,
    "shadow_dataset_direction_tolerance_deg": 45.0,
    "shadow_dataset_shape_width_scale": 1.25,
    "shadow_dataset_shape_length_scale": 1.65,
    "shadow_dataset_shape_min_length_scale": 0.35,
    "shadow_dataset_min_valid_fraction": 0.45,
    "no_shadow_require_background_mask": True,
    "no_shadow_target_geometry_filter": False,
}


def mask_default(key: str) -> Any:
    """读取语义掩码默认参数（单一来源）。"""
    if key not in SEMANTIC_MASK_DEFAULTS:
        raise KeyError(f"未知语义掩码参数: {key!r}，可选: {sorted(SEMANTIC_MASK_DEFAULTS)}")
    return SEMANTIC_MASK_DEFAULTS[key]


def resolve_scattering_percentiles(
    args=None,
    *,
    target_percentile: Optional[float] = None,
    background_percentile: Optional[float] = None,
) -> Tuple[float, float]:
    """从显式值、args 或 SEMANTIC_MASK_DEFAULTS 解析目标/背景分位数。"""
    tp = target_percentile
    if tp is None and args is not None:
        tp = getattr(args, "target_percentile", None)
    if tp is None:
        tp = mask_default("target_percentile")

    bp = background_percentile
    if bp is None and args is not None:
        bp = getattr(args, "background_percentile", None)
    if bp is None:
        bp = mask_default("background_percentile")
    return float(tp), float(bp)


def compute_scattering_threshold(
    image: np.ndarray,
    target_percentile: Optional[float] = None,
    background_percentile: Optional[float] = None,
    args=None,
    *,
    verbose: bool = True,
) -> Tuple[float, float]:
    """根据散射强度分位数计算目标/背景阈值（convert 与 train 共用）。"""
    tp, bp = resolve_scattering_percentiles(
        args, target_percentile=target_percentile, background_percentile=background_percentile
    )
    target_threshold = float(np.percentile(image, tp))
    background_threshold = float(np.percentile(image, bp))
    if verbose:
        print(
            f"   散射强度统计: 目标阈值={target_threshold:.3f} ({tp:g}%), "
            f"背景阈值={background_threshold:.3f} ({bp:g}%)"
        )
    return target_threshold, background_threshold


def register_semantic_mask_cli_args(parser: argparse.ArgumentParser) -> None:
    """向 argparse 注册语义掩码 CLI 参数，默认值全部来自 SEMANTIC_MASK_DEFAULTS。"""
    d = SEMANTIC_MASK_DEFAULTS
    g = parser.add_argument_group(
        "语义掩码",
        "convert 与 train_sar_complete 共用；默认值见 sar/semantic_mask_config.SEMANTIC_MASK_DEFAULTS",
    )
    g.add_argument(
        "--target_selection_mode",
        type=str,
        choices=["filter_background", "scatter_percentile"],
        default=d["target_selection_mode"],
        help="目标掩码生成方式：filter_background=utils/filter_background 分位数+形态学+最大连通域；"
        "scatter_percentile=散射分位数+中心ROI+语义连通域筛选",
    )
    g.add_argument(
        "--target_percentile",
        type=float,
        default=d["target_percentile"],
        help="目标区域散射强度分位数 (0-100，越大目标区域越小)",
    )
    g.add_argument(
        "--target_filter_blur_sigma",
        type=float,
        default=d["target_filter_blur_sigma"],
        help="filter_background 模式：阈值前高斯平滑 σ（与 filter_background.py --blur_sigma 一致）",
    )
    g.add_argument(
        "--target_filter_open_iter",
        type=int,
        default=d["target_filter_open_iter"],
        help="filter_background 模式：开运算次数（去背景亮斑）",
    )
    g.add_argument(
        "--target_filter_close_iter",
        type=int,
        default=d["target_filter_close_iter"],
        help="filter_background 模式：闭运算次数（填目标孔洞）",
    )
    g.add_argument(
        "--target_filter_morph_kernel",
        type=int,
        default=d["target_filter_morph_kernel"],
        help="filter_background 模式：形态学结构元素直径",
    )
    g.add_argument(
        "--target_filter_largest_cc",
        action=argparse.BooleanOptionalAction,
        default=d["target_filter_largest_cc"],
        help="filter_background 模式：仅保留最大连通域（等同 filter_background.py --largest_cc）",
    )
    g.add_argument(
        "--target_filter_min_target_ratio",
        type=float,
        default=d["target_filter_min_target_ratio"],
        help="filter_background 模式：目标占比低于此值则保留全图",
    )
    g.add_argument(
        "--target_filter_min_cc_area",
        type=int,
        default=d["target_filter_min_cc_area"],
        help="filter_background 模式：剔除小于该面积的连通域（0=关闭）",
    )
    g.add_argument(
        "--target_filter_erode_px",
        type=int,
        default=d["target_filter_erode_px"],
        help="filter_background 模式：前景腐蚀半径（去边缘发毛背景）",
    )
    g.add_argument(
        "--background_percentile",
        type=float,
        default=d["background_percentile"],
        help="背景区域散射强度分位数 (0-100，越小背景区域越小)",
    )
    g.add_argument(
        "--shadow_threshold_factor",
        type=float,
        default=d["shadow_threshold_factor"],
        help="阴影阈值因子（未设 shadow_percentile 时的自适应阴影上界）",
    )
    g.add_argument(
        "--shadow_percentile",
        type=float,
        default=d["shadow_percentile"],
        help="阴影强度上界分位数 (0-100，越大越易纳入暗区)；候选=像素值≤该分位数且不在目标内",
    )
    g.add_argument(
        "--no_shadow_target_geometry_filter",
        action="store_true",
        default=d["no_shadow_target_geometry_filter"],
        help="关闭阴影几何约束（默认：目标左侧 + Y 向长度≈目标）",
    )
    g.add_argument(
        "--shadow_y_margin_fraction",
        type=float,
        default=d["shadow_y_margin_fraction"],
        help="阴影 Y 向允许超出目标包络的比例（相对目标高度）",
    )
    g.add_argument(
        "--shadow_min_area_fraction",
        type=float,
        default=d["shadow_min_area_fraction"],
        help="阴影连通域最小面积占整图比例",
    )
    g.add_argument(
        "--shadow_min_target_area_fraction",
        type=float,
        default=d["shadow_min_target_area_fraction"],
        help="阴影总面积下限 = 该比例 × 目标面积",
    )
    g.add_argument(
        "--no_shadow_require_background_mask",
        action=argparse.BooleanOptionalAction,
        default=d["no_shadow_require_background_mask"],
        help="阴影不要求同时落在 background_mask 内，仅排除目标",
    )
    g.add_argument(
        "--target_mask_dilate_px",
        type=int,
        default=d["target_mask_dilate_px"],
        help="目标掩码 3×3 形态学膨胀迭代次数（0=关闭）",
    )
    g.add_argument(
        "--target_edge_band_px",
        type=int,
        default=d["target_edge_band_px"],
        help="目标边缘内外膨胀共用像素数（未单独指定 inner/outer 时，对内、对外各膨胀 N 次 3×3）",
    )
    g.add_argument(
        "--target_edge_inner_px",
        type=int,
        default=d["target_edge_inner_px"],
        help="目标边缘：交界核心圈向目标内部膨胀次数（3×3）",
    )
    g.add_argument(
        "--target_edge_outer_px",
        type=int,
        default=d["target_edge_outer_px"],
        help="目标边缘：交界核心圈向背景/阴影外侧膨胀次数（3×3）",
    )
    g.add_argument(
        "--target_mask_largest_component_only",
        action=argparse.BooleanOptionalAction,
        default=d["target_mask_largest_component_only"],
        help="单目标：阴影参考掩码在语义 target 上仅保留最大连通域",
    )
    g.add_argument(
        "--target_mask_min_component_area_px",
        type=int,
        default=d["target_mask_min_component_area_px"],
        help="语义目标(标签1)剔除面积小于该值的连通域；0=关闭",
    )
    g.add_argument(
        "--target_semantic_largest_component_only",
        action=argparse.BooleanOptionalAction,
        default=d["target_semantic_largest_component_only"],
        help="Keep only the centered main semantic target component and nearby scatter points.",
    )
    g.add_argument(
        "--target_semantic_keep_dilate_px",
        type=int,
        default=d["target_semantic_keep_dilate_px"],
        help="Dilation radius around the main target component used to keep nearby semantic target scatter.",
    )
    g.add_argument(
        "--shadow_target_dilate_px",
        type=int,
        default=d["shadow_target_dilate_px"],
        help="阴影候选排除：在语义 target_mask 上额外 3×3 膨胀次数（0=与语义完全一致）",
    )
    g.add_argument(
        "--merge_scattering_target_edge",
        action="store_true",
        default=d["merge_scattering_target_edge"],
        help="将语义目标边缘 (2) 并入目标内部 (1)，仅保留 0/1/3",
    )
    g.add_argument(
        "--target_center_roi_fraction",
        type=float,
        default=d["target_center_roi_fraction"],
        help="目标高散射核心中心 ROI 边长比例；MSTAR 目标通常居中，0=关闭",
    )
    g.add_argument(
        "--target_center_roi_min_keep_fraction",
        type=float,
        default=d["target_center_roi_min_keep_fraction"],
        help="中心 ROI 至少保留原高亮候选的比例；不足则自动回退不用 ROI",
    )
    g.add_argument(
        "--shadow_bridge_along_azimuth",
        action=argparse.BooleanOptionalAction,
        default=d["shadow_bridge_along_azimuth"],
        help="Connect fragmented low-scatter shadow candidates along the expected azimuth direction.",
    )
    g.add_argument(
        "--shadow_bridge_length_px",
        type=int,
        default=d["shadow_bridge_length_px"],
        help="Length of the directional bridge kernel for fragmented shadows.",
    )
    g.add_argument(
        "--shadow_bridge_width_px",
        type=int,
        default=d["shadow_bridge_width_px"],
        help="Width of the directional bridge kernel for fragmented shadows.",
    )
    g.add_argument(
        "--shadow_use_azimuth_prior",
        action=argparse.BooleanOptionalAction,
        default=d["shadow_use_azimuth_prior"],
        help="用 MSTAR 文件名方位角对阴影连通域做方向优先评分",
    )
    g.add_argument(
        "--shadow_direction_offset_deg",
        type=float,
        default=d["shadow_direction_offset_deg"],
        help="阴影方向 = 方位角 + offset；图像坐标不一致时调此项，默认 180",
    )
    g.add_argument(
        "--shadow_azimuth_tolerance_deg",
        type=float,
        default=d["shadow_azimuth_tolerance_deg"],
        help="阴影方位先验容差，越小越严格",
    )
    g.add_argument(
        "--shadow_azimuth_direction_weight",
        type=float,
        default=d["shadow_azimuth_direction_weight"],
        help="方位角方向先验在阴影连通域评分中的权重，0=只用自动几何评分",
    )
    g.add_argument(
        "--shadow_dataset_consistency",
        action=argparse.BooleanOptionalAction,
        default=d["shadow_dataset_consistency"],
        help="convert 特征阶段结束后，按整文件夹主阴影方向对异常/漏检阴影做二次修正",
    )
    g.add_argument(
        "--shadow_dataset_direction_tolerance_deg",
        type=float,
        default=d["shadow_dataset_direction_tolerance_deg"],
        help="整文件夹阴影主方向一致性容差；偏离超过该角度的图会被重检",
    )
    g.add_argument(
        "--shadow_dataset_shape_width_scale",
        type=float,
        default=d["shadow_dataset_shape_width_scale"],
        help="方向坐标下阴影横向宽度上限 = 目标横向宽度 × 该系数",
    )
    g.add_argument(
        "--shadow_dataset_shape_length_scale",
        type=float,
        default=d["shadow_dataset_shape_length_scale"],
        help="方向坐标下阴影纵向长度上限 = 整批中位阴影长度 × 该系数",
    )
    g.add_argument(
        "--shadow_dataset_shape_min_length_scale",
        type=float,
        default=d["shadow_dataset_shape_min_length_scale"],
        help="方向坐标下阴影纵向长度下限 = 整批中位阴影长度 × 该系数；小于此值视为疑似漏检",
    )
    g.add_argument(
        "--shadow_dataset_min_valid_fraction",
        type=float,
        default=d["shadow_dataset_min_valid_fraction"],
        help="启用整批一致性修正所需的有效阴影样本比例下限",
    )


def semantic_mask_kwargs_from_args(args) -> Dict[str, Any]:
    """与 create_scattering_mask / compute_scattering_masks_for_dataset 对齐的参数字典。"""
    d = SEMANTIC_MASK_DEFAULTS
    shadow_percentile = getattr(args, "shadow_percentile", d["shadow_percentile"])
    if shadow_percentile is None:
        shadow_percentile = d["shadow_percentile"]
    if bool(getattr(args, "no_shadow_require_background_mask", d["no_shadow_require_background_mask"])):
        shadow_require_background_mask = False
    elif getattr(args, "shadow_require_background_mask", None) is not None:
        shadow_require_background_mask = getattr(args, "shadow_require_background_mask")
    else:
        shadow_require_background_mask = not bool(d["no_shadow_require_background_mask"])
    # 指定 shadow_percentile 时背景分位数掩码过窄，会误删真实阴影
    if shadow_percentile is not None:
        shadow_require_background_mask = False

    return {
        "target_selection_mode": str(
            getattr(args, "target_selection_mode", d["target_selection_mode"]) or d["target_selection_mode"]
        ),
        "target_percentile": float(getattr(args, "target_percentile", d["target_percentile"])),
        "target_filter_blur_sigma": float(
            getattr(args, "target_filter_blur_sigma", d["target_filter_blur_sigma"])
        ),
        "target_filter_open_iter": max(
            0, int(getattr(args, "target_filter_open_iter", d["target_filter_open_iter"]) or 0)
        ),
        "target_filter_close_iter": max(
            0, int(getattr(args, "target_filter_close_iter", d["target_filter_close_iter"]) or 0)
        ),
        "target_filter_morph_kernel": max(
            3, int(getattr(args, "target_filter_morph_kernel", d["target_filter_morph_kernel"]) or 5)
        ),
        "target_filter_largest_cc": bool(
            getattr(args, "target_filter_largest_cc", d["target_filter_largest_cc"])
        ),
        "target_filter_min_target_ratio": float(
            getattr(args, "target_filter_min_target_ratio", d["target_filter_min_target_ratio"])
        ),
        "target_filter_min_cc_area": max(
            0, int(getattr(args, "target_filter_min_cc_area", d["target_filter_min_cc_area"]) or 0)
        ),
        "target_filter_erode_px": max(
            0, int(getattr(args, "target_filter_erode_px", d["target_filter_erode_px"]) or 0)
        ),
        "background_percentile": float(getattr(args, "background_percentile", d["background_percentile"])),
        "shadow_threshold_factor": float(getattr(args, "shadow_threshold_factor", d["shadow_threshold_factor"])),
        "target_mask_dilate_px": max(0, int(getattr(args, "target_mask_dilate_px", d["target_mask_dilate_px"]))),
        "target_edge_band_px": max(1, int(getattr(args, "target_edge_band_px", d["target_edge_band_px"]))),
        "target_edge_inner_px": max(
            1,
            int(getattr(args, "target_edge_inner_px", d["target_edge_inner_px"])),
        ),
        "target_edge_outer_px": max(
            1,
            int(getattr(args, "target_edge_outer_px", d["target_edge_outer_px"])),
        ),
        "merge_scattering_target_edge": bool(
            getattr(args, "merge_scattering_target_edge", d["merge_scattering_target_edge"])
        ),
        "target_center_roi_fraction": float(
            getattr(args, "target_center_roi_fraction", d["target_center_roi_fraction"]) or 0.0
        ),
        "target_center_roi_min_keep_fraction": float(
            getattr(
                args,
                "target_center_roi_min_keep_fraction",
                d["target_center_roi_min_keep_fraction"],
            )
            or 0.0
        ),
        "target_mask_largest_component_only": bool(
            getattr(args, "target_mask_largest_component_only", d["target_mask_largest_component_only"])
        ),
        "target_mask_min_component_area_px": max(
            0,
            int(getattr(args, "target_mask_min_component_area_px", d["target_mask_min_component_area_px"]) or 0),
        ),
        "target_semantic_largest_component_only": bool(
            getattr(
                args,
                "target_semantic_largest_component_only",
                d["target_semantic_largest_component_only"],
            )
        ),
        "target_semantic_keep_dilate_px": max(
            0,
            int(getattr(args, "target_semantic_keep_dilate_px", d["target_semantic_keep_dilate_px"]) or 0),
        ),
        "shadow_target_dilate_px": max(
            0,
            int(getattr(args, "shadow_target_dilate_px", d["shadow_target_dilate_px"])),
        ),
        "shadow_percentile": shadow_percentile,
        "shadow_target_geometry_filter": not bool(
            getattr(args, "no_shadow_target_geometry_filter", d["no_shadow_target_geometry_filter"])
        ),
        "shadow_min_area_fraction": float(
            getattr(args, "shadow_min_area_fraction", d["shadow_min_area_fraction"]) or d["shadow_min_area_fraction"]
        ),
        "shadow_min_target_area_fraction": float(
            getattr(args, "shadow_min_target_area_fraction", d["shadow_min_target_area_fraction"]) or 0.0
        ),
        "shadow_y_margin_fraction": float(
            getattr(args, "shadow_y_margin_fraction", d["shadow_y_margin_fraction"]) or d["shadow_y_margin_fraction"]
        ),
        "shadow_bridge_along_azimuth": bool(
            getattr(args, "shadow_bridge_along_azimuth", d["shadow_bridge_along_azimuth"])
        ),
        "shadow_bridge_length_px": max(
            1,
            int(getattr(args, "shadow_bridge_length_px", d["shadow_bridge_length_px"]) or 1),
        ),
        "shadow_bridge_width_px": max(
            1,
            int(getattr(args, "shadow_bridge_width_px", d["shadow_bridge_width_px"]) or 1),
        ),
        "shadow_use_azimuth_prior": bool(
            getattr(args, "shadow_use_azimuth_prior", d["shadow_use_azimuth_prior"])
        ),
        "shadow_direction_offset_deg": float(
            getattr(args, "shadow_direction_offset_deg", d["shadow_direction_offset_deg"]) or 0.0
        ),
        "shadow_azimuth_tolerance_deg": float(
            getattr(args, "shadow_azimuth_tolerance_deg", d["shadow_azimuth_tolerance_deg"])
            or d["shadow_azimuth_tolerance_deg"]
        ),
        "shadow_azimuth_direction_weight": float(
            getattr(args, "shadow_azimuth_direction_weight", d["shadow_azimuth_direction_weight"]) or 0.0
        ),
        "shadow_dataset_consistency": bool(
            getattr(args, "shadow_dataset_consistency", d["shadow_dataset_consistency"])
        ),
        "shadow_dataset_direction_tolerance_deg": float(
            getattr(
                args,
                "shadow_dataset_direction_tolerance_deg",
                d["shadow_dataset_direction_tolerance_deg"],
            )
            or d["shadow_dataset_direction_tolerance_deg"]
        ),
        "shadow_dataset_shape_width_scale": float(
            getattr(args, "shadow_dataset_shape_width_scale", d["shadow_dataset_shape_width_scale"])
            or d["shadow_dataset_shape_width_scale"]
        ),
        "shadow_dataset_shape_length_scale": float(
            getattr(args, "shadow_dataset_shape_length_scale", d["shadow_dataset_shape_length_scale"])
            or d["shadow_dataset_shape_length_scale"]
        ),
        "shadow_dataset_shape_min_length_scale": float(
            getattr(
                args,
                "shadow_dataset_shape_min_length_scale",
                d["shadow_dataset_shape_min_length_scale"],
            )
            or d["shadow_dataset_shape_min_length_scale"]
        ),
        "shadow_dataset_min_valid_fraction": float(
            getattr(args, "shadow_dataset_min_valid_fraction", d["shadow_dataset_min_valid_fraction"])
            or d["shadow_dataset_min_valid_fraction"]
        ),
        "shadow_require_background_mask": shadow_require_background_mask,
    }


def register_scattering_mask_cache_cli_args(parser: argparse.ArgumentParser) -> None:
    """训练时选择 convert 缓存批次（与语义掩码参数分组独立）。"""
    g = parser.add_argument_group(
        "散射掩码缓存",
        "优先复用 convert 写入 scattering_masks/from_convert/<时间戳>/ 的掩码",
    )
    g.add_argument(
        "--scattering_masks_run",
        type=str,
        default="latest",
        help="convert 掩码批次 ID（默认 latest=最新子文件夹；none=跳过缓存并重新计算）",
    )


def convert_masks_root(source_path: str) -> str:
    """scattering_masks/from_convert 根目录（各批次为其下子文件夹）。"""
    return os.path.join(source_path, "scattering_masks", CONVERT_MASK_SUBDIR)


def convert_masks_dir(source_path: str) -> str:
    """兼容旧名：返回 from_convert 根目录。"""
    return convert_masks_root(source_path)


def _make_convert_mask_run_id() -> str:
    return time.strftime("%Y%m%d_%H%M%S", time.localtime())


def list_convert_mask_runs(source_path: str) -> list:
    """列出 from_convert 下含 *_mask.npy 的批次子文件夹名（按时间戳升序）。"""
    root = convert_masks_root(source_path)
    if not os.path.isdir(root):
        return []
    runs = []
    for name in os.listdir(root):
        sub = os.path.join(root, name)
        if not os.path.isdir(sub):
            continue
        if glob.glob(os.path.join(sub, "*_mask.npy")):
            runs.append(name)
    return sorted(runs)


def resolve_convert_masks_run_dir(source_path: str, run_id: Optional[str] = None) -> Optional[str]:
    """
    解析应加载的 convert 掩码目录。
    run_id 为 None 或 'latest' 时使用 latest.json 或最新批次子文件夹；
    若 from_convert 根目录仍直接存放掩码（旧版布局），则返回根目录。
    """
    root = convert_masks_root(source_path)
    if not os.path.isdir(root):
        return None

    if run_id and str(run_id).lower() not in ("latest", "none", ""):
        candidate = os.path.join(root, run_id)
        if os.path.isdir(candidate):
            return candidate
        return None

    latest_path = os.path.join(root, CONVERT_MASK_LATEST_FILE)
    if os.path.isfile(latest_path):
        try:
            with open(latest_path, encoding="utf-8") as f:
                meta = json.load(f)
            rid = meta.get("run_id")
            if rid:
                candidate = os.path.join(root, str(rid))
                if os.path.isdir(candidate):
                    return candidate
        except Exception:
            pass

    runs = list_convert_mask_runs(source_path)
    if runs:
        return os.path.join(root, runs[-1])

    if glob.glob(os.path.join(root, "*_mask.npy")):
        return root

    return None


def save_convert_scattering_masks(
    source_path: str,
    masks_by_image_name: Dict[str, np.ndarray],
    params: Optional[Dict[str, Any]] = None,
    run_id: Optional[str] = None,
) -> str:
    """将 convert 特征提取阶段的语义掩码写入 scattering_masks/from_convert/<run_id>/。"""
    root = convert_masks_root(source_path)
    os.makedirs(root, exist_ok=True)
    rid = run_id or _make_convert_mask_run_id()
    out_dir = os.path.join(root, rid)
    os.makedirs(out_dir, exist_ok=True)

    saved_at = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
    for fname, arr in masks_by_image_name.items():
        stem = os.path.splitext(os.path.basename(fname))[0]
        np.save(os.path.join(out_dir, f"{stem}_mask.npy"), np.asarray(arr, dtype=np.int8))

    meta = {
        "run_id": rid,
        "saved_at": saved_at,
        "count": len(masks_by_image_name),
        "params": params or {},
    }
    with open(os.path.join(out_dir, "semantic_params.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)

    latest = {
        "run_id": rid,
        "saved_at": saved_at,
        "count": len(masks_by_image_name),
        "params": params or {},
    }
    with open(os.path.join(root, CONVERT_MASK_LATEST_FILE), "w", encoding="utf-8") as f:
        json.dump(latest, f, indent=2, ensure_ascii=False)

    return out_dir


def _list_image_files(images_folder: str) -> list:
    exts = (".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp")
    files = []
    if not os.path.isdir(images_folder):
        return files
    for fname in sorted(os.listdir(images_folder)):
        if fname.lower().endswith(exts):
            files.append(fname)
    return files


def load_convert_scattering_masks(
    source_path: str,
    images_folder: str,
    run_id: Optional[str] = None,
) -> Optional[Tuple[Dict[str, np.ndarray], str]]:
    """
    从 scattering_masks/from_convert/<run_id>/ 加载掩码（默认最新批次）。
    返回 (masks_dict, cache_dir)；masks 键为带扩展名的图像文件名。
    仅当 images_folder 中每张图均有对应 *_mask.npy 时视为成功。
    """
    out_dir = resolve_convert_masks_run_dir(source_path, run_id=run_id)
    if not out_dir:
        return None

    masks = load_scattering_masks_from_dir(out_dir, images_folder)
    if masks is None:
        return None
    return masks, out_dir


def diagnose_convert_masks_load(
    source_path: str,
    images_folder: str,
    run_id: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """
    当 load_convert_scattering_masks 失败时说明原因（目录不存在、掩码数不足、缺哪些 stem）。
    """
    out_dir = resolve_convert_masks_run_dir(source_path, run_id=run_id)
    if not out_dir:
        return {"reason": "no_run_dir", "run_dir": None}

    cache_stems = set()
    for p in glob.glob(os.path.join(out_dir, "*_mask.npy")):
        cache_stems.add(os.path.basename(p).replace("_mask.npy", ""))

    image_files = _list_image_files(images_folder)
    if not image_files:
        return {"reason": "no_images", "run_dir": out_dir}

    missing = []
    for fname in image_files:
        stem = os.path.splitext(fname)[0]
        if stem not in cache_stems:
            missing.append(fname)

    if not cache_stems:
        return {"reason": "no_mask_files", "run_dir": out_dir, "n_images": len(image_files)}

    if missing:
        return {
            "reason": "incomplete",
            "run_dir": out_dir,
            "n_images": len(image_files),
            "n_masks": len(cache_stems),
            "missing_files": missing,
        }

    return None


def load_scattering_masks_from_dir(
    masks_dir: str, images_folder: str
) -> Optional[Dict[str, np.ndarray]]:
    """从任意目录加载 *_mask.npy（与 load_convert_scattering_masks 相同的键约定）。"""
    if not masks_dir or not os.path.isdir(masks_dir):
        return None
    cache: Dict[str, np.ndarray] = {}
    for p in glob.glob(os.path.join(masks_dir, "*_mask.npy")):
        stem = os.path.basename(p).replace("_mask.npy", "")
        try:
            cache[stem] = normalize_scattering_mask_array(np.load(p))
        except Exception:
            continue
    if not cache:
        return None
    image_files = _list_image_files(images_folder)
    if not image_files:
        return None
    masks: Dict[str, np.ndarray] = {}
    for fname in image_files:
        stem = os.path.splitext(fname)[0]
        if stem not in cache:
            return None
        masks[fname] = np.asarray(cache[stem])
    return masks


def read_convert_semantic_params(cache_dir: str) -> Optional[Dict[str, Any]]:
    """读取 convert 批次目录下的 semantic_params.json。"""
    path = os.path.join(cache_dir, "semantic_params.json")
    if not os.path.isfile(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            meta = json.load(f)
        return meta.get("params") if isinstance(meta, dict) else None
    except Exception:
        return None


# convert 写入 semantic_params.json 的键 → CLI 选项（train 复用掩码时同步 args）
_CONVERT_SEMANTIC_PARAM_CLI_FLAGS: Dict[str, Tuple[str, ...]] = {
    "target_selection_mode": ("--target_selection_mode",),
    "target_percentile": ("--target_percentile",),
    "target_filter_blur_sigma": ("--target_filter_blur_sigma",),
    "target_filter_open_iter": ("--target_filter_open_iter",),
    "target_filter_close_iter": ("--target_filter_close_iter",),
    "target_filter_morph_kernel": ("--target_filter_morph_kernel",),
    "target_filter_largest_cc": ("--target_filter_largest_cc", "--no-target_filter_largest_cc"),
    "target_filter_min_target_ratio": ("--target_filter_min_target_ratio",),
    "target_filter_min_cc_area": ("--target_filter_min_cc_area",),
    "target_filter_erode_px": ("--target_filter_erode_px",),
    "background_percentile": ("--background_percentile",),
    "shadow_percentile": ("--shadow_percentile",),
    "shadow_threshold_factor": ("--shadow_threshold_factor",),
    "target_mask_dilate_px": ("--target_mask_dilate_px",),
    "target_edge_band_px": ("--target_edge_band_px",),
    "target_edge_inner_px": ("--target_edge_inner_px",),
    "target_edge_outer_px": ("--target_edge_outer_px",),
    "merge_scattering_target_edge": ("--merge_scattering_target_edge",),
    "target_mask_largest_component_only": (
        "--target_mask_largest_component_only",
        "--no_target_mask_largest_component_only",
    ),
    "target_mask_min_component_area_px": ("--target_mask_min_component_area_px",),
    "target_semantic_largest_component_only": (
        "--target_semantic_largest_component_only",
        "--no-target_semantic_largest_component_only",
    ),
    "target_semantic_keep_dilate_px": ("--target_semantic_keep_dilate_px",),
    "shadow_target_dilate_px": ("--shadow_target_dilate_px",),
    "shadow_min_area_fraction": ("--shadow_min_area_fraction",),
    "shadow_min_target_area_fraction": ("--shadow_min_target_area_fraction",),
    "shadow_y_margin_fraction": ("--shadow_y_margin_fraction",),
    "shadow_bridge_along_azimuth": ("--shadow_bridge_along_azimuth", "--no-shadow_bridge_along_azimuth"),
    "shadow_bridge_length_px": ("--shadow_bridge_length_px",),
    "shadow_bridge_width_px": ("--shadow_bridge_width_px",),
    "no_shadow_require_background_mask": (
        "--no_shadow_require_background_mask",
        "--shadow_require_background_mask",
    ),
    "no_shadow_target_geometry_filter": ("--no_shadow_target_geometry_filter",),
    "shadow_dataset_consistency": ("--shadow_dataset_consistency", "--no-shadow_dataset_consistency"),
    "shadow_dataset_direction_tolerance_deg": ("--shadow_dataset_direction_tolerance_deg",),
    "shadow_dataset_shape_width_scale": ("--shadow_dataset_shape_width_scale",),
    "shadow_dataset_shape_length_scale": ("--shadow_dataset_shape_length_scale",),
    "shadow_dataset_shape_min_length_scale": ("--shadow_dataset_shape_min_length_scale",),
    "shadow_dataset_min_valid_fraction": ("--shadow_dataset_min_valid_fraction",),
}


def _argv_specifies_semantic_cli(argv: Optional[Sequence[str]], option_names: Sequence[str]) -> bool:
    if not argv:
        return False
    for tok in argv:
        for name in option_names:
            if tok == name or tok.startswith(f"{name}="):
                return True
    return False


def apply_convert_semantic_params_to_args(
    args: Any,
    conv_params: Dict[str, Any],
    argv: Optional[Sequence[str]] = None,
) -> List[str]:
    """
    将 convert 批次 semantic_params.json 同步到 train args（仅覆盖命令行未显式指定的项）。
    返回已应用的参数名列表。
    """
    if argv is None:
        import sys

        argv = sys.argv[1:]

    applied: List[str] = []
    for key, val in conv_params.items():
        if key not in SEMANTIC_MASK_DEFAULTS and not hasattr(args, key):
            continue
        flags = _CONVERT_SEMANTIC_PARAM_CLI_FLAGS.get(key, (f"--{key}",))
        if _argv_specifies_semantic_cli(argv, flags):
            continue
        if hasattr(args, key):
            setattr(args, key, val)
            applied.append(key)
    return applied


def attach_scattering_masks_to_scene(scene, masks_by_fname: Dict[str, np.ndarray]) -> Dict[str, Any]:
    """
    将 0/1/2/3 语义散射掩码挂到 Scene 各分辨率下的 Camera（供 train.py 加权损失使用）。
    键约定与 load_convert_scattering_masks 一致：图像文件名（含扩展名）。
    """
    if not masks_by_fname:
        return {"attached": 0, "missing": 0, "missing_samples": []}

    by_stem: Dict[str, np.ndarray] = {}
    for fname, arr in masks_by_fname.items():
        stem = os.path.splitext(os.path.basename(fname))[0]
        by_stem[stem] = np.asarray(arr, dtype=np.int8)

    attached = 0
    missing: list[str] = []

    def _lookup(image_name: str) -> Optional[np.ndarray]:
        if image_name in masks_by_fname:
            return np.asarray(masks_by_fname[image_name], dtype=np.int8)
        stem = os.path.splitext(os.path.basename(image_name))[0]
        return by_stem.get(stem)

    for scale_dict in (getattr(scene, "train_cameras", {}), getattr(scene, "test_cameras", {})):
        for cam_list in scale_dict.values():
            for cam in cam_list:
                m = _lookup(getattr(cam, "image_name", ""))
                if m is None:
                    missing.append(getattr(cam, "image_name", "?"))
                    continue
                cam.scattering_mask = m
                attached += 1

    uniq_missing = sorted(set(missing))
    return {
        "attached": attached,
        "missing": len(uniq_missing),
        "missing_samples": uniq_missing[:8],
    }


def normalize_scattering_mask_array(arr: np.ndarray) -> np.ndarray:
    """将掩码规范为 int8 语义标签 0/1/2/3（四舍五入，剔除非法值）。"""
    a = np.rint(np.asarray(arr)).astype(np.int16)
    out = np.zeros(a.shape, dtype=np.int8)
    for lab in (0, 1, 2, 3):
        out[a == lab] = lab
    return out


def summarize_scattering_mask_labels(masks_by_fname: Dict[str, np.ndarray]) -> Dict[str, float]:
    """统计一批掩码中 0/1/2/3 像素占比（用于训练启动日志）。"""
    if not masks_by_fname:
        return {}
    total = 0
    counts = {0: 0, 1: 0, 2: 0, 3: 0}
    other = 0
    per_target_pct: List[float] = []
    for arr in masks_by_fname.values():
        a = normalize_scattering_mask_array(arr)
        total += a.size
        for lab in (0, 1, 2, 3):
            counts[lab] += int(np.sum(a == lab))
        other += int(np.sum((a != 0) & (a != 1) & (a != 2) & (a != 3)))
        fg = int(np.sum((a == 1) | (a == 2)))
        per_target_pct.append(100.0 * fg / max(1, a.size))
    if total <= 0:
        return {}
    out = {f"label_{k}": 100.0 * counts[k] / total for k in (0, 1, 2, 3)}
    out["label_target_plus_edge"] = out["label_1"] + out["label_2"]
    out["label_other"] = 100.0 * other / total
    if per_target_pct:
        out["per_image_target_edge_median_pct"] = float(np.median(per_target_pct))
    return out


def audit_scattering_masks_on_cameras(train_cameras, *, verbose: bool = True) -> Dict[str, Any]:
    """检查训练相机是否挂上散射掩码，以及尺寸/标签是否合法。"""
    n = len(train_cameras)
    with_mask = 0
    shape_mismatch = 0
    label_hist = {0: 0, 1: 0, 2: 0, 3: 0}
    for cam in train_cameras:
        sm = getattr(cam, "scattering_mask", None)
        if sm is None:
            continue
        with_mask += 1
        a = normalize_scattering_mask_array(sm)
        for lab in (0, 1, 2, 3):
            label_hist[lab] += int(np.sum(a == lab))
        if a.shape != (cam.image_height, cam.image_width):
            shape_mismatch += 1
    total_l = sum(label_hist.values()) or 1
    summary = {
        "n_cameras": n,
        "with_mask": with_mask,
        "shape_mismatch": shape_mismatch,
        "label_pct": {k: 100.0 * label_hist[k] / total_l for k in label_hist},
    }
    if verbose and getattr(train_cameras[0] if n else None, "scattering_mask", None) is not None or with_mask:
        tg = summary["label_pct"].get(1, 0) + summary["label_pct"].get(2, 0)
        print(
            f"[SAR 掩码挂载] 训练相机 {with_mask}/{n} 已挂掩码"
            + (f"，{shape_mismatch} 张原图尺寸≠训练分辨率（train 内 nearest 插值）" if shape_mismatch else "")
            + f"；挂载后像素: 背景={summary['label_pct'][0]:.1f}% "
            f"目标内部={summary['label_pct'][1]:.1f}% 边缘={summary['label_pct'][2]:.1f}% "
            f"阴影={summary['label_pct'][3]:.1f}% 目标+边缘={tg:.1f}%"
        )
    elif verbose and n > 0:
        print(f"[SAR 掩码挂载] 警告: {n} 个训练相机均未挂 scattering_mask")
    return summary


def resolve_scattering_masks_for_training(
    dataset,
    masks: Optional[Dict[str, np.ndarray]] = None,
    *,
    run_id: str = "latest",
) -> Tuple[Optional[Dict[str, np.ndarray]], Optional[str]]:
    """
    解析训练用散射掩码：优先显式传入，其次 dataset.scattering_masks，再尝试 from_convert 缓存。
    """
    if masks is not None and len(masks) > 0:
        return masks, "explicit"
    cached = getattr(dataset, "scattering_masks", None)
    if cached:
        return cached, "dataset.scattering_masks"

    source_path = getattr(dataset, "source_path", None)
    if not source_path:
        return None, None
    images_sub = getattr(dataset, "images", None) or "images"
    images_folder = os.path.join(source_path, images_sub)
    loaded = load_convert_scattering_masks(source_path, images_folder, run_id=run_id)
    if loaded is not None:
        masks_dict, cache_dir = loaded
        return masks_dict, cache_dir
    return None, None
