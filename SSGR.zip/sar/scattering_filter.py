"""
SAR散射强度过滤模块
用于在点云初始化和训练时过滤背景/阴影区域
与 convert/SFM 中 feature_extraction.create_scattering_mask 语义分割对齐
"""

import numpy as np
import torch
from typing import Tuple, Optional, Dict
from PIL import Image
import os


def load_sar_grayscale_like_convert(img_path: str) -> np.ndarray:
    """
    与 convert/SFM 中 feature_extraction.extract_single_image_features 一致：
    灰度读入 + sar_utils.preprocess_sar_image（含 eps 与 [0,1] 归一化）。
    """
    from sar_utils import preprocess_sar_image

    try:
        import cv2
        arr = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if arr is None:
            raise OSError("cv2.imread returned None")
        return preprocess_sar_image(arr)
    except Exception:
        pil = Image.open(img_path)
        if getattr(pil, "mode", None) != "L":
            pil = pil.convert("L")
        arr = np.array(pil)
        return preprocess_sar_image(arr)


def calculate_scattering_threshold(image: np.ndarray,
                                   target_percentile: Optional[float] = None,
                                   background_percentile: Optional[float] = None) -> Tuple[float, float]:
    """根据散射强度计算自适应阈值（委托 sar.semantic_mask_config）。"""
    from sar.semantic_mask_config import compute_scattering_threshold
    return compute_scattering_threshold(
        image,
        target_percentile=target_percentile,
        background_percentile=background_percentile,
        verbose=False,
    )


def create_scattering_mask(image: np.ndarray,
                           target_threshold: float,
                           background_threshold: float) -> np.ndarray:
    """简易三类掩码（0 背景、1 目标、2 边缘），无阴影类 3。"""
    target_mask = image >= target_threshold
    background_mask = image <= background_threshold
    scattering_mask = np.ones_like(image, dtype=np.uint8)
    scattering_mask[background_mask] = 0

    if np.any(target_mask):
        from scipy import ndimage
        combined_edges = np.zeros_like(target_mask, dtype=bool)
        for kernel_size in (3, 5):
            kernel = np.ones((kernel_size, kernel_size), dtype=bool)
            try:
                dilated_target = ndimage.binary_dilation(target_mask, structure=kernel, iterations=1)
                eroded_target = ndimage.binary_erosion(target_mask, structure=kernel, iterations=1)
                combined_edges |= dilated_target & ~eroded_target
            except Exception:
                continue
        scattering_mask[combined_edges] = 2

    return scattering_mask


def compute_scattering_masks_for_dataset(
    images_folder: str,
    target_percentile: Optional[float] = None,
    background_percentile: Optional[float] = None,
    cache_dir: Optional[str] = None,
    semantic_segmentation: bool = True,
    shadow_threshold_factor: Optional[float] = None,
    target_mask_dilate_px: Optional[int] = None,
    target_edge_band_px: Optional[int] = None,
    target_edge_inner_px: Optional[int] = None,
    target_edge_outer_px: Optional[int] = None,
    merge_scattering_target_edge: Optional[bool] = None,
    shadow_percentile: Optional[float] = None,
    shadow_target_geometry_filter: Optional[bool] = None,
    shadow_min_area_fraction: Optional[float] = None,
    shadow_min_target_area_fraction: Optional[float] = None,
    shadow_y_margin_fraction: Optional[float] = None,
    shadow_require_background_mask: Optional[bool] = None,
    target_mask_largest_component_only: Optional[bool] = None,
    target_mask_min_component_area_px: Optional[int] = None,
    target_semantic_largest_component_only: Optional[bool] = None,
    target_semantic_keep_dilate_px: Optional[int] = None,
    shadow_target_dilate_px: Optional[int] = None,
    shadow_bridge_along_azimuth: Optional[bool] = None,
    shadow_bridge_length_px: Optional[int] = None,
    shadow_bridge_width_px: Optional[int] = None,
    target_center_roi_fraction: Optional[float] = None,
    target_center_roi_min_keep_fraction: Optional[float] = None,
    shadow_use_azimuth_prior: Optional[bool] = None,
    shadow_direction_offset_deg: Optional[float] = None,
    shadow_azimuth_tolerance_deg: Optional[float] = None,
    shadow_azimuth_direction_weight: Optional[float] = None,
) -> Dict[str, np.ndarray]:
    """
    为整个数据集计算散射/语义掩码。
    semantic_segmentation=True 时使用 feature_extraction.create_scattering_mask（与 convert 一致）。
    """
    from sar.semantic_mask_config import mask_default, compute_scattering_threshold as _compute_thr

    _d = mask_default
    if target_percentile is None:
        target_percentile = float(_d("target_percentile"))
    if background_percentile is None:
        background_percentile = float(_d("background_percentile"))
    if shadow_threshold_factor is None:
        shadow_threshold_factor = float(_d("shadow_threshold_factor"))
    if target_mask_dilate_px is None:
        target_mask_dilate_px = int(_d("target_mask_dilate_px"))
    if target_edge_band_px is None:
        target_edge_band_px = int(_d("target_edge_band_px"))
    if target_edge_inner_px is None:
        target_edge_inner_px = int(_d("target_edge_inner_px"))
    if target_edge_outer_px is None:
        target_edge_outer_px = int(_d("target_edge_outer_px"))
    if merge_scattering_target_edge is None:
        merge_scattering_target_edge = bool(_d("merge_scattering_target_edge"))
    if shadow_percentile is None:
        shadow_percentile = _d("shadow_percentile")
    if shadow_target_geometry_filter is None:
        shadow_target_geometry_filter = not bool(_d("no_shadow_target_geometry_filter"))
    if shadow_min_area_fraction is None:
        shadow_min_area_fraction = float(_d("shadow_min_area_fraction"))
    if shadow_min_target_area_fraction is None:
        shadow_min_target_area_fraction = float(_d("shadow_min_target_area_fraction"))
    if shadow_y_margin_fraction is None:
        shadow_y_margin_fraction = float(_d("shadow_y_margin_fraction"))
    if target_mask_largest_component_only is None:
        target_mask_largest_component_only = bool(_d("target_mask_largest_component_only"))
    if target_mask_min_component_area_px is None:
        target_mask_min_component_area_px = int(_d("target_mask_min_component_area_px"))
    if target_semantic_largest_component_only is None:
        target_semantic_largest_component_only = bool(_d("target_semantic_largest_component_only"))
    if target_semantic_keep_dilate_px is None:
        target_semantic_keep_dilate_px = int(_d("target_semantic_keep_dilate_px"))
    if shadow_target_dilate_px is None:
        shadow_target_dilate_px = int(_d("shadow_target_dilate_px"))
    if shadow_bridge_along_azimuth is None:
        shadow_bridge_along_azimuth = bool(_d("shadow_bridge_along_azimuth"))
    if shadow_bridge_length_px is None:
        shadow_bridge_length_px = int(_d("shadow_bridge_length_px"))
    if shadow_bridge_width_px is None:
        shadow_bridge_width_px = int(_d("shadow_bridge_width_px"))
    if target_center_roi_fraction is None:
        target_center_roi_fraction = float(_d("target_center_roi_fraction"))
    if target_center_roi_min_keep_fraction is None:
        target_center_roi_min_keep_fraction = float(_d("target_center_roi_min_keep_fraction"))
    if shadow_use_azimuth_prior is None:
        shadow_use_azimuth_prior = bool(_d("shadow_use_azimuth_prior"))
    if shadow_direction_offset_deg is None:
        shadow_direction_offset_deg = float(_d("shadow_direction_offset_deg"))
    if shadow_azimuth_tolerance_deg is None:
        shadow_azimuth_tolerance_deg = float(_d("shadow_azimuth_tolerance_deg"))
    if shadow_azimuth_direction_weight is None:
        shadow_azimuth_direction_weight = float(_d("shadow_azimuth_direction_weight"))

    masks: Dict[str, np.ndarray] = {}
    fe_create_mask = None
    if semantic_segmentation:
        try:
            from feature_extraction import create_scattering_mask as fe_create_mask
        except Exception as e:
            print(f"  ⚠️ 无法导入 convert 用 create_scattering_mask ({e})，回退简易三类掩码")
            semantic_segmentation = False

    image_extensions = [".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"]
    image_files = [
        fname for fname in os.listdir(images_folder)
        if any(fname.lower().endswith(ext) for ext in image_extensions)
    ]

    cache_fname_suffix = "_mask.npy"
    print(f"\n计算散射强度掩码... ({'convert 语义 0/1/2/3' if semantic_segmentation else '简易三类'})")
    print(f"  图像数量: {len(image_files)}")
    print("  读图与 SFM/convert 对齐: cv2 灰度(优先) + preprocess_sar_image")
    print(f"  目标分位数: {target_percentile}%")
    print(f"  背景分位数: {background_percentile}%")
    if semantic_segmentation:
        print(f"  阴影阈值因子 shadow_threshold_factor: {shadow_threshold_factor}")
        if shadow_percentile is not None:
            print(f"  阴影分位数 shadow_percentile: {shadow_percentile}%")
        print(f"  阴影目标几何约束: {'开' if shadow_target_geometry_filter else '关'}")
        if shadow_target_geometry_filter:
            print(f"  阴影 Y 向余量 shadow_y_margin_fraction: {shadow_y_margin_fraction}")
        if shadow_min_target_area_fraction and shadow_min_target_area_fraction > 0:
            print(f"  阴影/目标面积比下限: {shadow_min_target_area_fraction}")
        _srb = shadow_require_background_mask
        if _srb is None:
            _srb = shadow_percentile is None
        print(f"  阴影须同时为背景分位数内: {'是' if _srb else '否'}")
        print(f"  目标掩码膨胀 target_mask_dilate_px: {target_mask_dilate_px} (0=关闭)")
        print(
            f"  语义目标主连通域约束: {target_semantic_largest_component_only}, "
            f"nearby_dilate={target_semantic_keep_dilate_px}"
        )
        print(
            f"  目标边缘带 target_edge_band/inner/outer: "
            f"{target_edge_band_px}/{target_edge_inner_px}/{target_edge_outer_px}"
        )
        print(f"  阴影参考掩码: 语义 target 对齐 + 最大连通域 {target_mask_largest_component_only}")
        print(f"  阴影参考额外膨胀 shadow_target_dilate_px: {shadow_target_dilate_px}")
        print(
            f"  阴影方向性连接: {shadow_bridge_along_azimuth}, "
            f"length={shadow_bridge_length_px}, width={shadow_bridge_width_px}"
        )
        print(
            f"  目标中心 ROI: fraction={target_center_roi_fraction}, "
            f"min_keep={target_center_roi_min_keep_fraction}"
        )
        print(
            f"  阴影方位角先验: {'开' if shadow_use_azimuth_prior else '关'}, "
            f"offset={shadow_direction_offset_deg}°, tol={shadow_azimuth_tolerance_deg}°, "
            f"weight={shadow_azimuth_direction_weight}"
        )
        print(f"  边缘并入目标 merge_scattering_target_edge: {merge_scattering_target_edge}")

    if cache_dir is not None:
        os.makedirs(cache_dir, exist_ok=True)

    for idx, fname in enumerate(image_files):
        if cache_dir is not None:
            cache_path = os.path.join(cache_dir, f"{os.path.splitext(fname)[0]}{cache_fname_suffix}")
            if os.path.exists(cache_path):
                masks[fname] = np.load(cache_path)
                continue

        img_path = os.path.join(images_folder, fname)
        try:
            img_array = load_sar_grayscale_like_convert(img_path)
            if img_array.ndim != 2:
                img_array = np.mean(img_array, axis=2)

            target_threshold, background_threshold = _compute_thr(
                img_array, target_percentile=target_percentile, background_percentile=background_percentile
            )

            if semantic_segmentation and fe_create_mask is not None:
                mask = fe_create_mask(
                    img_array,
                    target_threshold,
                    background_threshold,
                    shadow_threshold_factor=shadow_threshold_factor,
                    output_dir=None,
                    img_name=fname,
                    target_mask_dilate_px=target_mask_dilate_px,
                    target_edge_band_px=target_edge_band_px,
                    target_edge_inner_px=target_edge_inner_px,
                    target_edge_outer_px=target_edge_outer_px,
                    merge_target_edge_into_interior=merge_scattering_target_edge,
                    target_mask_largest_component_only=target_mask_largest_component_only,
                    target_mask_min_component_area_px=target_mask_min_component_area_px,
                    target_semantic_largest_component_only=target_semantic_largest_component_only,
                    target_semantic_keep_dilate_px=target_semantic_keep_dilate_px,
                    shadow_percentile=shadow_percentile,
                    shadow_target_geometry_filter=shadow_target_geometry_filter,
                    shadow_min_area_fraction=shadow_min_area_fraction,
                    shadow_min_target_area_fraction=shadow_min_target_area_fraction,
                    shadow_y_margin_fraction=shadow_y_margin_fraction,
                    shadow_require_background_mask=(
                        shadow_require_background_mask
                        if shadow_require_background_mask is not None
                        else (shadow_percentile is None)
                    ),
                    shadow_target_dilate_px=shadow_target_dilate_px,
                    shadow_bridge_along_azimuth=shadow_bridge_along_azimuth,
                    shadow_bridge_length_px=shadow_bridge_length_px,
                    shadow_bridge_width_px=shadow_bridge_width_px,
                    target_center_roi_fraction=target_center_roi_fraction,
                    target_center_roi_min_keep_fraction=target_center_roi_min_keep_fraction,
                    shadow_use_azimuth_prior=shadow_use_azimuth_prior,
                    shadow_direction_offset_deg=shadow_direction_offset_deg,
                    shadow_azimuth_tolerance_deg=shadow_azimuth_tolerance_deg,
                    shadow_azimuth_direction_weight=shadow_azimuth_direction_weight,
                )
            else:
                mask = create_scattering_mask(img_array, target_threshold, background_threshold)

            masks[fname] = np.asarray(mask, dtype=np.int8)

            if cache_dir is not None:
                np.save(cache_path, masks[fname])

            if (idx + 1) % 10 == 0:
                print(f"  处理进度: {idx + 1}/{len(image_files)}")

        except Exception as e:
            print(f"  警告: 无法处理图像 {fname}: {e}")
            continue

    print(f"  完成! 共生成 {len(masks)} 个掩码")
    return masks


def filter_point_cloud_by_scattering_masks(points_3d: np.ndarray,
                                          point_colors: list,
                                          camera_infos: list,
                                          scattering_masks: Dict[str, np.ndarray],
                                          min_target_views: int = 2) -> Tuple[np.ndarray, list]:
    """根据散射强度掩码过滤点云（需完整投影矩阵，当前为占位实现）"""
    if points_3d.shape[1] == 0:
        return points_3d, point_colors
    print(f"\n基于散射强度掩码过滤点云...")
    print(f"  原始点数: {points_3d.shape[1]}")
    print(f"  警告: 点云过滤功能需要完整的相机投影矩阵，暂时跳过")
    return points_3d, point_colors


def apply_scattering_mask_to_loss(image: torch.Tensor,
                                  gt_image: torch.Tensor,
                                  scattering_mask: torch.Tensor,
                                  background_weight: float = 0.1,
                                  target_weight: float = 1.0,
                                  edge_weight: float = 1.5) -> torch.Tensor:
    """应用散射强度掩码到损失函数"""
    tw = target_weight
    weight_map = torch.ones_like(scattering_mask, dtype=torch.float32)
    weight_map[scattering_mask == 0] = background_weight
    weight_map[scattering_mask == 1] = tw
    weight_map[scattering_mask == 2] = tw
    weight_map = weight_map / weight_map.mean()
    diff = torch.abs(image - gt_image)
    weighted_diff = diff * weight_map.unsqueeze(0)
    return weighted_diff.mean()


def visualize_scattering_mask(image: np.ndarray,
                             mask: np.ndarray,
                             output_path: str):
    """可视化散射强度掩码"""
    import matplotlib.pyplot as plt
    import cv2

    if image.shape[:2] != mask.shape:
        image = cv2.resize(image, (mask.shape[1], mask.shape[0]))

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    axes[0].imshow(image, cmap='gray')
    axes[0].set_title('Original SAR Image')
    axes[0].axis('off')

    mask_colored = np.zeros((*mask.shape, 3))
    mask_colored[mask == 0] = [0, 0, 1]
    mask_colored[mask == 1] = [0, 1, 0]
    mask_colored[mask == 2] = [1, 0, 0]
    mask_colored[mask == 3] = [0, 1, 1]
    axes[1].imshow(mask_colored)
    axes[1].set_title("Mask\n(Blue=Bg, Green=Tgt, Red=Edge, Yellow=Shadow)")
    axes[1].axis('off')

    overlay = np.stack([image] * 3, axis=2) if len(image.shape) == 2 else image.copy()
    if overlay.shape[:2] != mask.shape:
        overlay_resized = np.zeros((*mask.shape, 3))
        for i in range(3):
            overlay_resized[:, :, i] = cv2.resize(overlay[:, :, i], (mask.shape[1], mask.shape[0]))
        overlay = overlay_resized
    overlay[mask == 2, 0] = 1.0
    axes[2].imshow(overlay)
    axes[2].set_title('Overlay (Edge in Red)')
    axes[2].axis('off')

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  可视化保存到: {output_path}")
