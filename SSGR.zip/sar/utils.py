# 在utils.py开头添加
from __future__ import print_function, division
import numpy as np
import cv2
import re
import os
from scipy.spatial.transform import Rotation as R

# 确保Python3兼容性
try:
    from math import log2
except ImportError:
    from math import log
    def log2(x):
        return log(x, 2)

def mstar_filename_has_angle_metadata(filename):
    """
    若 basename 符合 MSTAR 式「目标-俯视角-方位角」模式，返回 True。
    用于判断俯仰/方位是否来自文件名数据（与 parse_mstar_filename 成功分支一致）。
    """
    basename = os.path.splitext(filename)[0]
    pattern = r'(.+)-(\d+)-(\d+)$'
    return re.search(pattern, basename) is not None


_UNPARSEABLE_FILENAME_WARNED: set = set()


def parse_mstar_filename(filename, verbose: bool = False):
    """
    解析MSTAR/OSU风格文件名，提取俯视角与方位角（第二、三段）。

    MSTAR 公开数据集中常见：第二段为**相对水平向下的俯角 φ**，内部再换为与天底夹角 θ=90°−φ。
    默认 `--sar_mstar_filename_depression_convention horizon`（正常俯视角）；若文件名段已是 θ 则设 zenith。

    默认不逐条打印；仅 ``verbose=True`` 时输出单条解析日志。无法解析时每种文件名只警告一次。
    """
    target_name, depression_angle, azimuth_angle = parse_mstar_filename_quiet(filename)
    if target_name is None:
        key = os.path.basename(str(filename))
        if key not in _UNPARSEABLE_FILENAME_WARNED:
            _UNPARSEABLE_FILENAME_WARNED.add(key)
            print(f"警告: 无法解析文件名 {filename}，使用默认角度")
        return 15, 0
    if verbose:
        print(
            f"解析文件名: {filename} -> 目标: {target_name}, "
            f"俯视角: {depression_angle}°, 方位角: {azimuth_angle}°"
        )
    return depression_angle, azimuth_angle


def parse_mstar_filename_quiet(filename):
    """
    与 parse_mstar_filename 相同解析规则，不打印。
    返回: (target_name, depression_angle, azimuth_angle)；无法解析时 target_name 为 None，角度为 (15, 0)。
    第二段角度的物理含义见 parse_mstar_filename 文档说明（常为相对水平俯视；与天底夹角需折合）。
    """
    basename = os.path.splitext(os.path.basename(filename))[0]
    pattern = r'(.+)-(\d+)-(\d+)$'
    match = re.search(pattern, basename)
    if not match:
        return None, 15, 0
    target_name = re.sub(r'[^A-Za-z0-9]+', '', match.group(1))
    return target_name, int(match.group(2)), int(match.group(3))


def preprocess_sar_image(image):
    """
    SAR图像预处理 - 改进版本
    """
    if image.dtype != np.float64:
        image = image.astype(np.float64)

    # 添加小常数避免零值
    eps = 1e-8
    image = np.maximum(image, eps)

    # 归一化到 [0, 1] 范围
    if image.max() > 1.0:
        image = image / 255.0

    # 可选：应用对数变换增强SAR图像对比度
    # image = np.log1p(image)  # log(1 + x) 避免对零取对数

    return image

def safe_keypoint_to_dict(kp):
    """将关键点安全转换为字典"""
    return {
        'pt': (float(kp.pt[0]), float(kp.pt[1])) if hasattr(kp, 'pt') else (0.0, 0.0),
        'size': float(kp.size) if hasattr(kp, 'size') and kp.size > 0 else 1.0,
        'angle': float(kp.angle) if hasattr(kp, 'angle') and kp.angle != -1 else 0.0,
        'response': float(kp.response) if hasattr(kp, 'response') else 1.0,
        'octave': int(kp.octave) if hasattr(kp, 'octave') else 0,
        'class_id': int(kp.class_id) if hasattr(kp, 'class_id') else -1
    }


def dict_to_keypoint(kp_dict):
    """将字典转换回关键点"""
    kp = cv2.KeyPoint()
    kp.pt = kp_dict['pt']
    kp.size = kp_dict['size']
    kp.angle = kp_dict['angle']
    kp.response = kp_dict['response']
    kp.octave = kp_dict['octave']
    kp.class_id = kp_dict['class_id']
    return kp


def check_gpu_availability():
    """
    检测GPU可用性
    """
    gpu_info = {
        'cupy_available': False,
        'pytorch_available': False,
        'best_backend': 'cpu'
    }

    # 检测CuPy
    try:
        import cupy as cp
        gpu_info['cupy_available'] = True
        gpu_info['best_backend'] = 'cupy'
        print("✓ CuPy GPU可用")
    except ImportError:
        print("✗ CuPy未安装")

    # 检测PyTorch
    try:
        import torch
        if torch.cuda.is_available():
            gpu_info['pytorch_available'] = True
            if gpu_info['best_backend'] == 'cpu':
                gpu_info['best_backend'] = 'pytorch'
            print(f"✓ PyTorch GPU可用: {torch.cuda.get_device_name(0)}")
    except ImportError:
        print("✗ PyTorch未安装")

    if gpu_info['best_backend'] == 'cpu':
        print("ℹ 将使用CPU进行计算")

    return gpu_info
