"""360° 方位圆环 / MSTAR 数据集推断（预设常量已迁至 config.py）。"""

from __future__ import annotations

import os
from typing import Any, List, Optional, Sequence

from sar_utils import parse_mstar_filename

# 预设：从 config 转发，便于旧代码 ``from sar.dataset_pose_defaults import ...``
from config import (  # noqa: F401
    GEOMETRY_PRIOR_GS_MODEL_CLI_FLAGS,
    GEOMETRY_PRIOR_GS_MODEL_PRESET,
    GEOMETRY_PRIOR_ROUGH_MODEL_CLI_FLAGS,
    GEOMETRY_PRIOR_ROUGH_MODEL_PRESET,
    apply_config_presets,
    apply_geometry_prior_gs_model_preset,
    apply_geometry_prior_rough_model_preset,
)


def detect_azimuth_ring_dataset(image_paths: Sequence[str]) -> Optional[dict]:
    """若文件名可解析为「固定俯角 + 方位跨 ≥180°」，返回统计 dict。"""
    deps: List[float] = []
    azis: List[float] = []
    for p in image_paths:
        stem = os.path.splitext(os.path.basename(str(p)))[0]
        try:
            d, a = parse_mstar_filename(stem)
            deps.append(float(d))
            azis.append(float(a))
        except Exception:
            return None
    if len(deps) < 8:
        return None
    dep_unique = len({round(x, 2) for x in deps})
    az_span = float(max(azis) - min(azis))
    if dep_unique != 1 or az_span < 180.0:
        return None
    return {
        "n_images": len(deps),
        "depression_deg": float(deps[0]),
        "azimuth_min_deg": float(min(azis)),
        "azimuth_max_deg": float(max(azis)),
        "azimuth_span_deg": az_span,
    }


def apply_360_ring_convert_defaults(args: Any, image_paths: Sequence[str]) -> bool:
    """360° 圆环：侧视 L/W 汇总、standalone 阴影汇总等（非 geometry_prior 主预设）。"""
    info = detect_azimuth_ring_dataset(image_paths)
    if info is None:
        return False

    changed: List[str] = []

    if str(getattr(args, "shadow_geometry_azimuth_mode", "oblique")).strip().lower() == "oblique":
        args.shadow_geometry_azimuth_mode = "mstar_axis_split"
        changed.append("shadow_geometry_azimuth_mode=mstar_axis_split")

    if str(getattr(args, "target_dimension_summary_azimuth_mode", "oblique")).strip().lower() == "oblique":
        args.target_dimension_summary_azimuth_mode = "mstar_axis_split"
        changed.append("target_dimension_summary_azimuth_mode=mstar_axis_split")

    if not bool(getattr(args, "convert_use_standalone_shadow_target_dimensions", False)):
        args.convert_use_standalone_shadow_target_dimensions = True
        changed.append("convert_use_standalone_shadow_target_dimensions=开")

    sb_mode = str(getattr(args, "sfm_summary_box_mesh_prior_mode", "off") or "off").strip().lower()
    if sb_mode in ("replace", "merge", "before_filter", "after_filter"):
        if not bool(getattr(args, "sfm_mesh_prior_sar_imaging_scale_match", False)):
            args.sfm_mesh_prior_sar_imaging_scale_match = True
            changed.append("sfm_mesh_prior_sar_imaging_scale_match=开")
        if not bool(getattr(args, "post_sfm_summary_box_align_camera_centers", False)):
            args.post_sfm_summary_box_align_camera_centers = True
            changed.append("post_sfm_summary_box_align_camera_centers=开")

    print(
        f"\n🛰️ 360° 方位圆环数据集（俯角 {info['depression_deg']:.0f}°，"
        f"方位 {info['azimuth_min_deg']:.0f}°–{info['azimuth_max_deg']:.0f}°）→ "
        "比例盒用 **90°/270° 侧视** L=Tr、W=Taz"
    )
    if changed:
        print(f"   自动调整: {', '.join(changed)}")
    return True
