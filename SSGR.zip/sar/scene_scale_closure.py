"""
MSTAR 128×128：由像素分辨率 + 焦距 + 俯角，在 SfM/SO-RCG **初始化** 阶段闭合场景尺度。

优先在 SO-RCG 之前写入 sar_params（camera_height、scene_scale、radius_scale），
再由 SO-RCG 在窄窗口内微调共享高度；**不**事后硬改 COLMAP 结果。
"""

from __future__ import annotations

import json
import math
import os
import sys
from dataclasses import dataclass, replace
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

from sar.scene_anchor import resolve_scene_anchor_mu
from sar.imaging_mode import resolve_dataset_world_yaw_deg

MSTAR_DEFAULT_RANGE_RES_M = 0.3
MSTAR_DEFAULT_AZIMUTH_RES_M = 0.3
MSTAR_DEFAULT_LENGTH_PX = 17.0
MSTAR_DEFAULT_WIDTH_PX = 38.0

# MSTAR BTR70 数据集典型米制包络（ρ=0.3 m/px：L≈38 px→11.4 m，W≈16.5 px→4.95 m）
MSTAR_CANONICAL_BTR70_LENGTH_M = 11.4
MSTAR_CANONICAL_BTR70_WIDTH_M = 4.95
MSTAR_CANONICAL_BTR70_HEIGHT_M = 5.25

# T72: body-only keeps the hull as the 3DGS support plane and excludes the gun barrel
# from the geometry prior.  t72_full is available when the barrel should be part of
# the target envelope.
MSTAR_CANONICAL_T72_BODY_LENGTH_M = 6.95
MSTAR_CANONICAL_T72_FULL_LENGTH_M = 9.53
MSTAR_CANONICAL_T72_WIDTH_M = 3.59
MSTAR_CANONICAL_T72_HEIGHT_M = 2.23


@dataclass
class MstarScaleDiagnostics:
    """360-1 等场景尺度诊断（便于打印定量表）。"""

    image_size: Tuple[int, int]
    focal_px: float
    slant_range_m: float
    camera_height_m: float
    radius_scale: float
    ring_ground_range_m: float
    depth_scale_observed: float
    rho_range_m: float
    rho_azimuth_m: float
    rho_geometric_mean_m: float
    length_px: Optional[float]
    width_px: Optional[float]
    height_px: Optional[float]
    length_phys_m: Optional[float]
    width_phys_m: Optional[float]
    height_phys_m: Optional[float]
    length_world_implied_m: Optional[float]
    width_world_implied_m: Optional[float]
    aabb_extent_xyz: Optional[Tuple[float, float, float]]
    aabb_max_extent_m: Optional[float]
    uniform_scale_s: float
    camera_height_after_m: float
    slant_range_after_m: float
    depth_scale_after: float

    def format_table(self) -> str:
        lines = [
            "",
            "=" * 72,
            "MSTAR 场景尺度诊断（像素分辨率 / 高斯泼溅）",
            "=" * 72,
            f"  图像尺寸        : {self.image_size[0]}×{self.image_size[1]} px",
            f"  焦距 f          : {self.focal_px:.4g} px",
            f"  斜距 Z          : {self.slant_range_m:.2f} m  ->  缩放后 {self.slant_range_after_m:.2f} m",
            f"  平台高度 H      : {self.camera_height_m:.2f} m  ->  缩放后 {self.camera_height_after_m:.2f} m",
            f"  radius_scale    : {self.radius_scale:.6g}",
            f"  圆环水平半径 g  : {self.ring_ground_range_m:.2f} m  ->  缩放后 {self.ring_ground_range_m * self.uniform_scale_s:.2f} m",
            "",
            "  分辨率 (m/px)   : 距离向 ρ_r={:.3g}, 方位向 ρ_a={:.3g}, 几何均值={:.3g}".format(
                self.rho_range_m, self.rho_azimuth_m, self.rho_geometric_mean_m
            ),
            f"  depth_scale=Z/f : {self.depth_scale_observed:.4g} m/px  ->  目标 {self.rho_geometric_mean_m:.4g}  (缩放后 {self.depth_scale_after:.4g})",
            "",
        ]
        if self.length_px is not None:
            lines += [
                "  阴影汇总 (px)   : "
                f"L={self.length_px:.2g}, W={self.width_px:.2g}, H={self.height_px:.2g}",
                "  物理尺寸 (m)    : "
                f"L={self.length_phys_m:.2f}, W={self.width_phys_m:.2f}, H≈{self.height_phys_m:.2f}",
                "  当前投影 implied: "
                f"L={self.length_world_implied_m:.1f} m, W={self.width_world_implied_m:.1f} m",
            ]
            if self.length_phys_m and self.length_world_implied_m:
                lines.append(
                    f"  目标应缩小      : L ×{self.length_world_implied_m / max(self.length_phys_m, 1e-9):.1f}, "
                    f"W ×{self.width_world_implied_m / max(self.width_phys_m, 1e-9):.1f}"
                )
        if self.aabb_extent_xyz is not None:
            ex, ey, ez = self.aabb_extent_xyz
            lines += [
                "",
                f"  sparse AABB (m): X={ex:.2f}, Y={ey:.2f}, Z={ez:.2f}, max={self.aabb_max_extent_m:.2f}",
            ]
            tgt = 2.0 * max(
                self.length_phys_m or 0.0,
                self.width_phys_m or 0.0,
                self.height_phys_m or 0.0,
            )
            if tgt > 1e-6 and self.aabb_max_extent_m:
                lines.append(
                    f"  AABB vs 目标包络: 缩小 ×{self.aabb_max_extent_m / tgt:.1f}  (目标长轴约 {tgt:.1f} m)"
                )
        lines += [
            "",
            f"  * 建议统一缩放 s = {self.uniform_scale_s:.6g}  (作用于点云+相机，绕接地点)",
            f"  * 相机高度缩放   : x{self.uniform_scale_s:.6g}  ({self.camera_height_m:.0f} -> {self.camera_height_after_m:.1f} m)",
            "=" * 72,
            "",
        ]
        return "\n".join(lines)


@dataclass
class MstarInitialSceneParams:
    """SO-RCG 初始化用的 MSTAR 闭合尺度（场景单位，非物理 12 km）。"""

    camera_height_m: float
    scene_scale: float
    radius_scale: float
    slant_range_m: float
    ground_range_m: float
    depth_scale_target: float
    focal_px: float
    image_size: int
    depression_horizon_deg: float
    length_px: float
    width_px: float
    length_phys_m: float
    width_phys_m: float
    rho_range_m: float
    rho_azimuth_m: float

    def format_init_table(self) -> str:
        mode = getattr(self, "_mstar_height_mode", "pinhole_Z_sin_phi")
        h_pin = getattr(self, "_mstar_h_pinhole_m", None)
        extra = ""
        if h_pin is not None and mode != "pinhole_Z_sin_phi":
            extra = (
                f"\n  高度闭合模式    : {mode}  (H_pinhole=Z·sinφ={float(h_pin):.3f} m"
                f" → H={self.camera_height_m:.3f} m, R0={self.slant_range_m:.3f} m)"
            )
        return (
            "\n"
            + "=" * 72
            + "\nMSTAR 像素分辨率 → SO-RCG 初始尺度（公式闭合，供流形微调）\n"
            + "=" * 72
            + f"\n  图像 {self.image_size}px, f={self.focal_px:g} px, 俯角 φ={self.depression_horizon_deg:g}° (horizon)"
            + f"\n  ρ_a={self.rho_azimuth_m:g}, ρ_r={self.rho_range_m:g} m/px"
            + f"\n  目标 {self.length_px:g}×{self.width_px:g} px → "
            f"L={self.length_phys_m:.2f} m, W={self.width_phys_m:.2f} m"
            + f"\n  闭合: R0(Z)={self.slant_range_m:.3f} m, H={self.camera_height_m:.3f} m, "
            f"g={self.ground_range_m:.3f} m"
            + extra
            + f"\n  scene_scale={self.scene_scale:.5f}, radius_scale={self.radius_scale:.5f}, "
            f"depth_scale={self.depth_scale_target:.4g} m/px"
            + "\n  SO-RCG 将在该 H 附近窄窗口微调（非事后缩放 COLMAP）"
            + "\n" + "=" * 72 + "\n"
        )


def _resolve_target_px(
    args: Any,
    source_path: Optional[str],
) -> Tuple[float, float, Optional[float]]:
    l_px = float(getattr(args, "sfm_mstar_default_length_px", MSTAR_DEFAULT_LENGTH_PX) or MSTAR_DEFAULT_LENGTH_PX)
    w_px = float(getattr(args, "sfm_mstar_default_width_px", MSTAR_DEFAULT_WIDTH_PX) or MSTAR_DEFAULT_WIDTH_PX)
    h_px: Optional[float] = None
    if source_path:
        sl, sw, sh = _load_summary_px(source_path)
        if sl is not None:
            l_px = float(sl)
        if sw is not None:
            w_px = float(sw)
        if sh is not None:
            h_px = float(sh)
    return l_px, w_px, h_px


def _cli_flag_specified(argv: Optional[Sequence[str]], option_names: Sequence[str]) -> bool:
    if not argv:
        return False
    for tok in argv:
        for name in option_names:
            if tok == name or tok.startswith(f"{name}="):
                return True
    return False


def mstar_authoritative_height_m(sar_params: Mapping[str, Any]) -> float:
    """MSTAR 闭合后的权威场景 H（auto_fill 后），不含 SO-RCG 污染。"""
    for key in ("mstar_init_camera_height_m", "mstar_formula_camera_height_m"):
        h = float(sar_params.get(key, 0.0) or 0.0)
        if h > 0:
            return h
    return 0.0


def mstar_height_search_ratio(sar_params: Mapping[str, Any]) -> float:
    r = float(sar_params.get("mstar_height_search_ratio", 0.35) or 0.35)
    return float(min(0.95, max(0.02, r)))


def solver_height_polluted(
    ch_solver: float,
    ch_authoritative: float,
    *,
    search_ratio: float,
) -> bool:
    """SO-RCG 共享高度是否偏离 MSTAR 权威值（过大 km 级或过小）。"""
    if ch_authoritative <= 0:
        return ch_solver <= 0
    if ch_solver <= 0:
        return True
    if ch_solver > max(50.0, ch_authoritative * 20.0):
        return True
    ratio = float(min(0.95, max(0.02, search_ratio)))
    lo = ch_authoritative * max(0.02, 1.0 - ratio)
    hi = ch_authoritative * (1.0 + ratio)
    return ch_solver < lo or ch_solver > hi


def mstar_auto_image_fill_match(args: Any) -> bool:
    """SAR 斜距投影闭合 L/W（光学透视 gs_model 默认关闭）。"""
    from sar.imaging_mode import gs_optical_perspective_only_enabled

    cli_args = getattr(args, "_full_cli_args", None) or args
    argv = getattr(cli_args, "_argv", None) or sys.argv
    if _cli_flag_specified(argv, ("--sfm_mstar_auto_image_fill_match",)):
        return True
    if gs_optical_perspective_only_enabled(cli_args):
        return False
    if bool(getattr(cli_args, "sfm_mstar_auto_image_fill_match", False)):
        return True
    full = getattr(args, "_full_cli_args", None)
    if full is not None and bool(getattr(full, "sfm_mstar_auto_image_fill_match", False)):
        return True
    return False


def mstar_auto_image_fill_all_views(args: Any) -> bool:
    """全部 shadow_diagnostic bbox 闭合（仅 SAR 斜距 auto_fill 开启时）。"""
    if not mstar_auto_image_fill_match(args):
        return False
    if bool(getattr(args, "sfm_mstar_auto_image_fill_all_views", False)):
        return True
    full = getattr(args, "_full_cli_args", None)
    if full is not None and bool(getattr(full, "sfm_mstar_auto_image_fill_all_views", False)):
        return True
    return False


def mstar_fixed_physical_target_dims_enabled(args: Any) -> bool:
    """比例盒使用 MSTAR 典型米制尺寸（不随 shadow L×ρ 放大），画幅占比仅调相机高度。"""
    if bool(getattr(args, "sfm_mstar_fixed_physical_target_dims", False)):
        return True
    full = getattr(args, "_full_cli_args", None)
    if full is not None and bool(getattr(full, "sfm_mstar_fixed_physical_target_dims", False)):
        return True
    if bool(getattr(args, "geometry_prior_gs_model", False)):
        return True
    if full is not None and bool(getattr(full, "geometry_prior_gs_model", False)):
        return True
    return False


def mstar_fixed_physical_snap_lw_from_summary_enabled(args: Any) -> bool:
    """固定米制 W 时，用 summary L/W 中位数校正 L（与 shadow_summary 推理一致）。"""
    if bool(getattr(args, "sfm_mstar_fixed_physical_snap_lw_from_summary", False)):
        return True
    full = getattr(args, "_full_cli_args", None)
    if full is not None and bool(
        getattr(full, "sfm_mstar_fixed_physical_snap_lw_from_summary", False)
    ):
        return True
    return False


def _summary_planform_lw_ratio(stats: Any, args: Any) -> Optional[float]:
    """
    与 ``mstar_physical_semiaxes_xyz`` / shadow_summary 相同的侧视 L/W 像素比。
    ρ_a=ρ_r 时 L_m/W_m = L_px/W_px；超出装甲车合理范围则视为汇总不可信（如 oblique 误汇总）。
    """
    if stats is None or stats.length_median_px is None or stats.width_median_px is None:
        return None
    w_px = float(stats.width_median_px)
    l_px = float(stats.length_median_px)
    if w_px < 1e-6 or l_px < 1e-6:
        return None
    lw = l_px / w_px
    lo = float(
        _resolve_mstar_arg(args, "sfm_mstar_fixed_physical_snap_lw_min", 1.75) or 1.75
    )
    hi = float(
        _resolve_mstar_arg(args, "sfm_mstar_fixed_physical_snap_lw_max", 3.75) or 3.75
    )
    if not math.isfinite(lw) or lw < lo or lw > hi:
        return None
    return float(lw)


def _detect_mstar_target_prefix(args: Any) -> str:
    cli_args = getattr(args, "_full_cli_args", None) or args
    source_path = (
        getattr(cli_args, "source_path", None)
        or getattr(cli_args, "data_dir", None)
        or getattr(args, "source_path", None)
        or ""
    )
    for sub in ("input", "images"):
        d = os.path.join(str(source_path), sub)
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            stem, ext = os.path.splitext(fn)
            if ext.lower() not in (".jpg", ".jpeg", ".png", ".tif", ".tiff"):
                continue
            prefix = stem.split("-", 1)[0].strip().upper()
            if prefix:
                return prefix
    return ""


def _resolve_mstar_vehicle_preset(args: Any) -> str:
    raw = str(_resolve_mstar_arg(args, "sfm_mstar_vehicle_preset", "generic") or "generic")
    preset = raw.strip().lower()
    if preset == "auto":
        prefix = _detect_mstar_target_prefix(args)
        if prefix == "T72":
            return "t72_body"
        return "generic"
    if preset in ("generic", "t72_body", "t72_full", "custom"):
        return preset
    return "generic"


def resolve_mstar_fixed_physical_meters(
    args: Any,
    stats: Any = None,
) -> Tuple[float, float, float]:
    """
    固定整车米制包络 (L, W, H)，默认 BTR70 @ MSTAR ρ=0.3。
    W 保持典型米制；L 默认 W×summary(L/W)（与 shadow 比例盒推理同源）；
    H 默认略高于阴影 H_px×ρ（~4.9 m → 5.25 m）。均可通过 CLI 覆盖。
    """
    rho_a = float(
        _resolve_mstar_arg(args, "sfm_mstar_azimuth_resolution_m", MSTAR_DEFAULT_AZIMUTH_RES_M)
        or MSTAR_DEFAULT_AZIMUTH_RES_M
    )
    rho_r = float(
        _resolve_mstar_arg(args, "sfm_mstar_range_resolution_m", MSTAR_DEFAULT_RANGE_RES_M)
        or MSTAR_DEFAULT_RANGE_RES_M
    )
    cli_args = getattr(args, "_full_cli_args", None) or args
    argv = getattr(cli_args, "_argv", None) or sys.argv
    length_cli_specified = _cli_flag_specified(argv, ("--sfm_mstar_target_length_m",))
    width_cli_specified = _cli_flag_specified(argv, ("--sfm_mstar_target_width_m",))
    height_cli_specified = _cli_flag_specified(argv, ("--sfm_mstar_target_height_m",))
    snap_cli_specified = _cli_flag_specified(
        argv,
        (
            "--sfm_mstar_fixed_physical_snap_lw_from_summary",
            "--no_sfm_mstar_fixed_physical_snap_lw_from_summary",
        ),
    )

    preset = _resolve_mstar_vehicle_preset(args)
    if preset == "t72_body":
        l_def = MSTAR_CANONICAL_T72_BODY_LENGTH_M
        w_def = MSTAR_CANONICAL_T72_WIDTH_M
        h_def = MSTAR_CANONICAL_T72_HEIGHT_M
    elif preset == "t72_full":
        l_def = MSTAR_CANONICAL_T72_FULL_LENGTH_M
        w_def = MSTAR_CANONICAL_T72_WIDTH_M
        h_def = MSTAR_CANONICAL_T72_HEIGHT_M
    else:
        l_def = MSTAR_CANONICAL_BTR70_LENGTH_M
        w_def = MSTAR_CANONICAL_BTR70_WIDTH_M
        h_def = MSTAR_CANONICAL_BTR70_HEIGHT_M

    width_m = float(_resolve_mstar_arg(args, "sfm_mstar_target_width_m", w_def) or w_def)
    width_m = max(width_m, 1e-3)

    lw_summary: Optional[float] = None
    allow_summary_snap = not (
        preset in ("t72_body", "t72_full") and not snap_cli_specified
    )
    if (
        stats is not None
        and not length_cli_specified
        and mstar_fixed_physical_snap_lw_from_summary_enabled(args)
        and allow_summary_snap
    ):
        lw_summary = _summary_planform_lw_ratio(stats, args)
        if lw_summary is not None:
            l_def = float(width_m * lw_summary)

    if stats is not None and stats.height_median_px is not None and stats.width_median_px is not None:
        h_shadow = float(stats.height_median_px) * rho_r
        h_boost = float(
            _resolve_mstar_arg(args, "sfm_mstar_target_height_boost", 1.08) or 1.08
        )
        h_def = max(h_def, h_shadow * max(1.0, h_boost))

    length_m = float(_resolve_mstar_arg(args, "sfm_mstar_target_length_m", l_def) or l_def)
    height_m = float(_resolve_mstar_arg(args, "sfm_mstar_target_height_m", h_def) or h_def)

    if preset in ("t72_body", "t72_full") and not (
        length_cli_specified or width_cli_specified or height_cli_specified
    ):
        desc = "主体（排除炮管）" if preset == "t72_body" else "整车（含炮管）"
        print(
            f"  [mstar] T72 尺寸预设: {desc} "
            f"L={length_m:.2f} m, W={width_m:.2f} m, H={height_m:.2f} m；"
            "默认不使用 summary L/W 校正以避免炮管污染主体长度"
        )

    if lw_summary is not None and not length_cli_specified:
        canon_lw = MSTAR_CANONICAL_BTR70_LENGTH_M / max(MSTAR_CANONICAL_BTR70_WIDTH_M, 1e-9)
        if abs(lw_summary - canon_lw) > 0.04:
            print(
                f"  [mstar] 固定米制 L 由 summary L/W 校正: "
                f"{MSTAR_CANONICAL_BTR70_LENGTH_M:.2f}→{length_m:.2f} m "
                f"(W={width_m:.2f} m 不变, L/W={lw_summary:.3f} vs 目录 {canon_lw:.2f})"
            )

    return max(length_m, 1e-3), max(width_m, 1e-3), max(height_m, 1e-3)


def resolve_mstar_fixed_physical_semiaxes(
    args: Any,
    stats: Any = None,
) -> Tuple[float, float, float]:
    """世界半轴 (rx, ry, rz)：X≈车长 L，Y≈竖直 H，Z≈车宽 W。"""
    length_m, width_m, height_m = resolve_mstar_fixed_physical_meters(args, stats)
    return length_m * 0.5, height_m * 0.5, width_m * 0.5


def fixed_physical_args_from_scale_json(scale: Optional[Mapping[str, Any]]) -> Any:
    """
    由 sar_scale_params.json 构造 fixed-physical 参数对象，供 verify / optical 闭合使用。
    json 未写入 L/W/H 时仍走 summary L/W 校正（与 convert mesh_prior 一致）。
    """
    scale = dict(scale or {})

    class _Args:
        sfm_mstar_fixed_physical_target_dims = True
        sfm_mstar_fixed_physical_snap_lw_from_summary = bool(
            scale.get("mstar_fixed_physical_snap_lw_from_summary", True)
        )

    args = _Args()
    if scale.get("mstar_target_length_m") is not None:
        args.sfm_mstar_target_length_m = float(scale["mstar_target_length_m"])
    if scale.get("mstar_target_width_m") is not None:
        args.sfm_mstar_target_width_m = float(scale["mstar_target_width_m"])
    if scale.get("mstar_target_height_m") is not None:
        args.sfm_mstar_target_height_m = float(scale["mstar_target_height_m"])
    return args


def load_sparse_points3d_xyz(sparse_dir: str) -> np.ndarray:
    """读取 sparse/0 points3D 世界坐标 (N,3)。"""
    try:
        from post_sfm.colmap_points import read_points3d_binary_full

        bin_path = os.path.join(sparse_dir, "points3D.bin")
        txt_path = os.path.join(sparse_dir, "points3D.txt")
        if os.path.isfile(bin_path):
            recs = read_points3d_binary_full(bin_path)
            if recs:
                return np.stack([r.xyz for r in recs], axis=0).astype(np.float64)
        if os.path.isfile(txt_path):
            pts: list[list[float]] = []
            with open(txt_path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if line.startswith("#") or not line.strip():
                        continue
                    parts = line.split()
                    if len(parts) >= 4:
                        pts.append([float(parts[1]), float(parts[2]), float(parts[3])])
            if pts:
                return np.asarray(pts, dtype=np.float64)
    except Exception:
        pass
    return np.zeros((0, 3), dtype=np.float64)


def world_aabb_from_points(xyz: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    pts = np.asarray(xyz, dtype=np.float64).reshape(-1, 3)
    if pts.shape[0] == 0:
        z = np.zeros(3, dtype=np.float64)
        return z.copy(), z.copy()
    return pts.min(axis=0), pts.max(axis=0)


def aabb_corners_from_lo_hi(lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
    """世界系轴对齐 AABB 八个角点。"""
    lo = np.asarray(lo, dtype=np.float64).reshape(3)
    hi = np.asarray(hi, dtype=np.float64).reshape(3)
    corners: list[list[float]] = []
    for x in (lo[0], hi[0]):
        for y in (lo[1], hi[1]):
            for z in (lo[2], hi[2]):
                corners.append([x, y, z])
    return np.asarray(corners, dtype=np.float64)


def target_physical_dims_from_world_points(
    xyz: np.ndarray,
    *,
    world_yaw_deg: float = -90.0,
) -> Tuple[float, float, float]:
    """
    从 replace 后的世界系点云 AABB 反推整车 (L, W, H) 米制。
    gs_model 默认 extra_world_yaw=-90 已烘焙：world X≈W, Y≈H, Z≈L。
    """
    lo, hi = world_aabb_from_points(xyz)
    ext = hi - lo
    if abs(float(world_yaw_deg) + 90.0) < 1.0:
        length_m = float(ext[2])
        width_m = float(ext[0])
        height_m = float(ext[1])
    else:
        length_m = float(ext[0])
        width_m = float(ext[2])
        height_m = float(ext[1])
    return max(length_m, 1e-3), max(width_m, 1e-3), max(height_m, 1e-3)


def write_world_aabb_box_obj(lo: np.ndarray, hi: np.ndarray, obj_path: str) -> None:
    """将世界系 AABB 写为 shadow_proportional_box.obj（与点云包络一致）。"""
    lo = np.asarray(lo, dtype=np.float64).reshape(3)
    hi = np.asarray(hi, dtype=np.float64).reshape(3)
    ext = np.maximum(hi - lo, 1e-9)
    parent = os.path.dirname(obj_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    try:
        import open3d as o3d

        mesh = o3d.geometry.TriangleMesh.create_box(
            float(ext[0]), float(ext[1]), float(ext[2])
        )
        mesh.translate(lo)
        mesh.compute_vertex_normals()
        if not o3d.io.write_triangle_mesh(
            obj_path, mesh, write_triangle_uvs=False, print_progress=False
        ):
            raise RuntimeError(f"open3d 写出失败: {obj_path}")
        return
    except ImportError:
        pass

    x0, y0, z0 = lo
    x1, y1, z1 = hi
    verts = [
        (x0, y0, z0),
        (x1, y0, z0),
        (x1, y1, z0),
        (x0, y1, z0),
        (x0, y0, z1),
        (x1, y0, z1),
        (x1, y1, z1),
        (x0, y1, z1),
    ]
    faces = [
        (1, 2, 3),
        (1, 3, 4),
        (5, 6, 7),
        (5, 7, 8),
        (1, 2, 6),
        (1, 6, 5),
        (2, 3, 7),
        (2, 7, 6),
        (3, 4, 8),
        (3, 8, 7),
        (4, 1, 5),
        (4, 5, 8),
    ]
    with open(obj_path, "w", encoding="utf-8") as f:
        for vx, vy, vz in verts:
            f.write(f"v {vx:.9g} {vy:.9g} {vz:.9g}\n")
        for a, b, c in faces:
            f.write(f"f {a} {b} {c}\n")


def sparse_target_envelope_usable(
    sparse_dir: str,
    *,
    min_pts: int = 64,
) -> bool:
    return int(load_sparse_points3d_xyz(sparse_dir).shape[0]) >= int(min_pts)


def scale_sparse_points3d_uniform(
    source_path: str,
    uniform_scale: float,
    *,
    sparse_dir: Optional[str] = None,
    pivot: Optional[np.ndarray] = None,
) -> int:
    """将 sparse/0 points3D 绕 pivot 做各向同性缩放（optical 闭合后烘焙 mesh 尺度）。"""
    from post_sfm.colmap_points import read_points3d_binary_full, sync_colmap_point_outputs

    s = float(uniform_scale)
    if not math.isfinite(s) or abs(s - 1.0) < 1e-6:
        return 0

    sparse_dir = sparse_dir or os.path.join(source_path, "sparse", "0")
    bin_path = os.path.join(sparse_dir, "points3D.bin")
    if not os.path.isfile(bin_path):
        return 0
    records = read_points3d_binary_full(bin_path)
    if not records:
        return 0

    pv = np.asarray(pivot if pivot is not None else [0.0, 0.0, 0.0], dtype=np.float64).reshape(3)
    for rec in records:
        xyz = np.asarray(rec.xyz, dtype=np.float64).reshape(3)
        rec.xyz = (pv + s * (xyz - pv)).astype(np.float64)
    sync_colmap_point_outputs(sparse_dir, records)
    return len(records)


def sync_target_envelope_from_sparse_points3d(
    source_path: str,
    args: Any,
    *,
    sparse_dir: Optional[str] = None,
    box_obj_path: Optional[str] = None,
    world_yaw_deg: Optional[float] = None,
    verbose: bool = True,
) -> Optional[Dict[str, Any]]:
    """
    replace 点云落地后：以 sparse AABB 为权威包络，回写 sar_scale_params 并刷新比例盒 OBJ。
    盒子不再独立于点云另行推算；verify / optical 闭合应读取同一包络。
    """
    from sar.sfm_scale_params import merge_scale_params_file

    sparse_dir = sparse_dir or os.path.join(source_path, "sparse", "0")
    xyz = load_sparse_points3d_xyz(sparse_dir)
    if xyz.shape[0] < 8:
        if verbose:
            print("[target_envelope] 跳过：sparse points3D 不足")
        return None

    if world_yaw_deg is None:
        world_yaw_deg = float(resolve_dataset_world_yaw_deg(args, default_yaw_deg=-90.0))

    lo, hi = world_aabb_from_points(xyz)
    length_m, width_m, height_m = target_physical_dims_from_world_points(
        xyz, world_yaw_deg=float(world_yaw_deg)
    )
    ext = hi - lo

    if box_obj_path is None:
        rel = str(
            getattr(args, "post_sfm_summary_box_mesh_out", "")
            or os.path.join("geometry_prior", "shadow_proportional_box.obj")
        ).strip()
        if not os.path.isabs(rel):
            box_obj_path = os.path.join(source_path, rel.replace("/", os.sep))
        else:
            box_obj_path = rel

    try:
        write_world_aabb_box_obj(lo, hi, box_obj_path)
    except Exception as e:
        if verbose:
            print(f"[target_envelope] 刷新 OBJ 失败（继续写 json）: {e}")
        box_obj_path = ""

    scale_path = os.path.join(source_path, "sar_scale_params.json")
    scale: Dict[str, Any] = {}
    if os.path.isfile(scale_path):
        try:
            with open(scale_path, encoding="utf-8") as f:
                raw = json.load(f)
            scale = raw if isinstance(raw, dict) else {}
        except Exception:
            scale = {}

    fixed_physical = mstar_fixed_physical_target_dims_enabled(args)
    scale.update(
        {
            "mstar_fixed_physical_target_dims": bool(fixed_physical),
            "gs_target_envelope_from_sparse": True,
            "mstar_target_length_m": float(length_m),
            "mstar_target_width_m": float(width_m),
            "mstar_target_height_m": float(height_m),
            "mstar_target_length_width_ratio": float(length_m / width_m) if abs(float(width_m)) > 1e-12 else None,
            "mstar_target_width_length_ratio": float(width_m / length_m) if abs(float(length_m)) > 1e-12 else None,
            "gs_target_world_aabb_lo": [float(x) for x in lo],
            "gs_target_world_aabb_hi": [float(x) for x in hi],
            "gs_target_world_extent_xyz": [float(x) for x in ext],
            "mstar_fixed_physical_snap_lw_from_summary": bool(
                mstar_fixed_physical_snap_lw_from_summary_enabled(args)
            ),
        }
    )
    if box_obj_path:
        scale["gs_target_box_obj_path"] = os.path.abspath(box_obj_path)
    # 点云即包络：mesh 统一缩放由 optical 闭合烘焙进 points3D 后保持 1.0
    if "mstar_computed_mesh_uniform_scale" not in scale:
        scale["mstar_computed_mesh_uniform_scale"] = 1.0

    merge_scale_params_file(scale_path, scale)

    if verbose:
        print(
            f"  [target_envelope] 由 sparse 点云 AABB 回写包络 / 比例盒 OBJ\n"
            f"    L={length_m:.3f} m  W={width_m:.3f} m  H={height_m:.3f} m  "
            f"(extent X/Y/Z = {ext[0]:.3f}/{ext[1]:.3f}/{ext[2]:.3f})\n"
            f"    box: {box_obj_path or '(未写出)'}"
        )

    return {
        "length_m": float(length_m),
        "width_m": float(width_m),
        "height_m": float(height_m),
        "lo": lo,
        "hi": hi,
        "box_obj_path": box_obj_path,
    }


def resolve_mstar_target_semiaxes_xyz(
    stats: Any,
    args: Any,
    *,
    rho_azimuth_m: float = MSTAR_DEFAULT_AZIMUTH_RES_M,
    rho_range_m: float = MSTAR_DEFAULT_RANGE_RES_M,
    planform_scale: float = 1.0,
    shadow_h_scale: float = 1.0,
    upper_h: float = 1.25,
    lower_h: float = 0.35,
) -> Optional[Tuple[float, float, float]]:
    """固定米制或 shadow L/W×ρ 推导半轴（供比例盒与 auto_fill 共用）。"""
    if mstar_fixed_physical_target_dims_enabled(args):
        return resolve_mstar_fixed_physical_semiaxes(args, stats)
    return mstar_physical_semiaxes_xyz(
        stats,
        rho_azimuth_m=rho_azimuth_m,
        rho_range_m=rho_range_m,
        planform_scale=planform_scale,
        shadow_h_scale=shadow_h_scale,
        upper_h=upper_h,
        lower_h=lower_h,
    )


@dataclass
class MstarImageFillCalibration:
    """SAR 成像投影下，使比例盒与训练图像素包络一致所需的尺度因子。"""

    camera_height_scale: float
    mesh_uniform_scale: float
    target_span_az_px: float
    target_span_rng_px: float
    simulated_span_az_px: float
    simulated_span_rng_px: float
    reference_depression_deg: float
    reference_azimuth_deg: float
    fill_factor_geom: float
    num_views_used: int = 0

    def format_table(self) -> str:
        views_note = f", 视角数={self.num_views_used}" if self.num_views_used > 0 else ""
        return (
            "\n"
            + "-" * 72
            + "\nMSTAR 训练图像素占比 → 相机/比例盒自动闭合（SAR 成像投影）\n"
            + "-" * 72
            + f"\n  参考视角: 俯角 {self.reference_depression_deg:g}°, 方位 {self.reference_azimuth_deg:g}°{views_note}"
            + f"\n  训练图目标包络( px ): 方位W≈{self.target_span_az_px:.2f}, 距离L≈{self.target_span_rng_px:.2f}"
            + f"\n  闭合前模型投影( px ): 方位≈{self.simulated_span_az_px:.2f}, 距离≈{self.simulated_span_rng_px:.2f}"
            + f"\n  几何校正比 F = {self.fill_factor_geom:.4f}  (成像包络 ×F → 对齐训练图 L/W)"
            + f"\n  → camera_height_scale = {self.camera_height_scale:.4f}  "
            + f"(mesh_uniform_scale = {self.mesh_uniform_scale:.4f}"
            + (
                ", 固定米制目标仅调 H"
                if abs(self.mesh_uniform_scale - 1.0) < 1e-6 and self.num_views_used >= 3
                else ""
            )
            + ")"
            + "\n" + "-" * 72 + "\n"
        )


def _box_corners_ground_contact(rx: float, ry: float, rz: float) -> np.ndarray:
    """与 make_axis_aligned_box_mesh(ground_contact) 一致：底面中心在原点，向上沿 -Y。"""
    rx = float(max(rx, 1e-9))
    ry = float(max(ry, 1e-9))
    rz = float(max(rz, 1e-9))
    corners: list[list[float]] = []
    for x in (-rx, rx):
        for y in (0.0, -2.0 * ry):
            for z in (-rz, rz):
                corners.append([x, y, z])
    return np.asarray(corners, dtype=np.float64)


def _robust_span_px(uv: np.ndarray) -> Tuple[float, float]:
    if uv is None or uv.size == 0:
        return 0.0, 0.0
    xy = np.asarray(uv, dtype=np.float64).reshape(-1, 2)
    if xy.shape[0] < 4:
        return (
            float(np.max(xy[:, 0]) - np.min(xy[:, 0])),
            float(np.max(xy[:, 1]) - np.min(xy[:, 1])),
        )
    u = float(np.percentile(xy[:, 0], 95) - np.percentile(xy[:, 0], 5))
    v = float(np.percentile(xy[:, 1], 95) - np.percentile(xy[:, 1], 5))
    return max(abs(u), 1e-6), max(abs(v), 1e-6)


def _mstar_fill_scales_from_ratio_lists(
    f_u_list: Sequence[float],
    f_v_list: Sequence[float],
    *,
    height_only: bool = False,
) -> Tuple[float, float, float]:
    """由逐视角 target/sim 比值列表求 camera_height_scale、mesh_uniform_scale、f_geom。"""
    if not f_u_list or not f_v_list:
        return 1.0, 1.0, 1.0
    f_u = float(np.median(np.asarray(f_u_list, dtype=np.float64)))
    f_v = float(np.median(np.asarray(f_v_list, dtype=np.float64)))
    overfill = (f_u < 1.0) or (f_v < 1.0)
    if overfill:
        f_geom = float(np.clip(min(f_u, f_v), 0.12, 1.0))
    else:
        f_geom = float(np.clip(max(f_u, f_v), 1.0, 4.0))
    if height_only:
        # 目标 3D 米制固定：span ∝ 1/H，仅调相机高度；俯视基准下禁止压低 H
        h_scale = float(np.clip(1.0 / f_geom, 0.45, 3.5))
        h_scale = max(1.0, h_scale)
        return h_scale, 1.0, f_geom
    h_scale = float(np.clip(math.sqrt(1.0 / f_geom), 0.45, 3.5))
    mesh_scale = float(np.clip(math.sqrt(f_geom), 0.35, 2.2))
    return h_scale, mesh_scale, f_geom


def _image_stem_from_name(name: str) -> str:
    return os.path.splitext(os.path.basename(name.strip()))[0]


def _collect_per_view_fill_targets(
    source_path: str,
    image_angles: Optional[Mapping[str, Mapping[str, float]]],
) -> List[Tuple[float, float, float]]:
    """
    收集 (azimuth_deg, target_u_px, target_v_px) 供全视角 bbox 闭合。
    优先 image_angles 与 shadow_diagnostic stem 匹配；否则扫描 input/images。
    """
    from post_sfm.summary_parser import load_per_view_shadow_targets

    per_view = load_per_view_shadow_targets(source_path)
    if not per_view:
        return []

    out: List[Tuple[float, float, float]] = []
    if image_angles:
        for name, ang in image_angles.items():
            stem = _image_stem_from_name(name)
            tgt = per_view.get(stem)
            if tgt is None:
                continue
            out.append((float(ang.get("azimuth", 0.0)), float(tgt.width_px), float(tgt.height_px)))
        if out:
            return out

    try:
        from sar.utils import parse_mstar_filename
    except ImportError:
        return out

    for sub in ("input", "images"):
        img_dir = os.path.join(source_path, sub)
        if not os.path.isdir(img_dir):
            continue
        for fn in sorted(os.listdir(img_dir)):
            stem, ext = os.path.splitext(fn)
            if ext.lower() not in (".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"):
                continue
            tgt = per_view.get(stem)
            if tgt is None:
                continue
            try:
                _dep, azi = parse_mstar_filename(stem)
                out.append((float(azi), float(tgt.width_px), float(tgt.height_px)))
            except Exception:
                continue
    return out


def compute_mstar_sar_image_fill_calibration(
    *,
    args: Any,
    init: MstarInitialSceneParams,
    ref_width: int,
    ref_height: int,
    source_path: Optional[str],
    depression_horizon_deg: float,
    image_angles: Optional[Mapping[str, Mapping[str, float]]] = None,
) -> Optional[MstarImageFillCalibration]:
    """
    用与 mesh_prior / SDGR 一致的 SAR 斜距成像，将名义比例盒投影到像素平面，
    与 target_dimension_constraints_summary 中的 L/W 中位数对齐，求 camera_height_scale
    与 mesh_uniform_scale（各向相似：span ∝ mesh_scale / camera_height_scale）。
    """
    if source_path is None:
        return None

    from post_sfm.summary_parser import (
        parse_target_dimension_summary,
        resolve_mstar_side_view_azimuth_deg,
    )

    summary_path = os.path.join(
        source_path, "adaptive_threshold_visualization", "target_dimension_constraints_summary.txt"
    )
    stats = parse_target_dimension_summary(summary_path)
    if stats is None or stats.length_median_px is None or stats.width_median_px is None:
        return None

    l_px = float(stats.length_median_px)
    w_px = float(stats.width_median_px)
    h_px = float(stats.height_median_px) if stats.height_median_px is not None else w_px

    rho_a = float(init.rho_azimuth_m)
    rho_r = float(init.rho_range_m)
    pf = float(_resolve_mstar_arg(args, "post_sfm_scheme_a_planform_scale", 1.0) or 1.0)
    shadow_h = float(_resolve_mstar_arg(args, "post_sfm_scheme_a_shadow_height_scale", 1.0) or 1.0)
    upper_h = float(_resolve_mstar_arg(args, "post_sfm_scheme_a_height_slab_upper_scale", 1.25) or 1.25)
    lower_h = float(_resolve_mstar_arg(args, "post_sfm_scheme_a_height_slab_lower_scale", 0.35) or 0.35)

    sem = resolve_mstar_target_semiaxes_xyz(
        stats,
        args,
        rho_azimuth_m=rho_a,
        rho_range_m=rho_r,
        planform_scale=pf,
        shadow_h_scale=shadow_h,
        upper_h=upper_h,
        lower_h=lower_h,
    )
    if sem is None:
        return None
    rx, ry, rz = sem
    height_only_fill = mstar_fixed_physical_target_dims_enabled(args)
    corners = _box_corners_ground_contact(rx, ry, rz)
    yaw_extra = float(resolve_dataset_world_yaw_deg(args, default_yaw_deg=0.0))
    if abs(yaw_extra) > 1e-9:
        th = math.radians(yaw_extra)
        c, s = math.cos(th), math.sin(th)
        R_y = np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]], dtype=np.float64)
        corners = corners @ R_y.T

    dep = float(depression_horizon_deg)
    mesh_scale_applied = float(
        _resolve_mstar_arg(args, "sfm_mesh_prior_final_uniform_scale", 1.0) or 1.0
    )
    if mstar_auto_image_fill_match(args):
        mesh_scale_applied = 1.0  # 标定前用名义盒，mesh_scale 由结果给出

    sar_sp: Dict[str, Any] = {
        "camera_height": float(init.camera_height_m),
        "Na": int(ref_width),
        "Nr": int(ref_height),
        "scene_scale": float(init.scene_scale),
        "radius_scale": float(init.radius_scale),
        "camera_distribution_mode": "ring",
        "range_pixel_spacing": rho_r,
        "azimuth_pixel_spacing": rho_a,
        "mstar_filename_depression_convention": str(
            getattr(args, "sar_mstar_filename_depression_convention", "horizon")
        ),
    }
    try:
        from sar.geometry import DEFAULT_SAR_PARAMS

        for k, v in DEFAULT_SAR_PARAMS.items():
            sar_sp.setdefault(k, v)
    except ImportError:
        pass

    try:
        from post_sfm.mesh_obj_prior_core import _sar_project_world_to_pixels_xy
    except ImportError:
        return None

    def _project_at(azi_deg: float) -> Optional[np.ndarray]:
        c = corners
        if abs(mesh_scale_applied - 1.0) > 1e-9:
            c = corners * float(mesh_scale_applied)
        return _sar_project_world_to_pixels_xy(
            c,
            sar_params=sar_sp,
            depression_deg=dep,
            azimuth_deg=float(azi_deg),
        )

    # 全视角 shadow_diagnostic bbox 闭合（gs_model 默认）
    if mstar_auto_image_fill_all_views(args) and source_path:
        view_targets = _collect_per_view_fill_targets(source_path, image_angles)
        if len(view_targets) >= 3:
            f_u_list: List[float] = []
            f_v_list: List[float] = []
            sim_u_list: List[float] = []
            sim_v_list: List[float] = []
            tgt_u_list: List[float] = []
            tgt_v_list: List[float] = []
            ref_azis: List[float] = []
            for azi, tu, tv in view_targets:
                pix = _project_at(azi)
                if pix is None:
                    continue
                su, sv = _robust_span_px(pix)
                tu = max(float(tu), 1.0)
                tv = max(float(tv), 1.0)
                f_u_list.append(tu / su if su > 1e-6 else 1.0)
                f_v_list.append(tv / sv if sv > 1e-6 else 1.0)
                sim_u_list.append(su)
                sim_v_list.append(sv)
                tgt_u_list.append(tu)
                tgt_v_list.append(tv)
                ref_azis.append(float(azi))
            if len(f_u_list) >= 3:
                h_scale, mesh_scale, f_geom = _mstar_fill_scales_from_ratio_lists(
                    f_u_list, f_v_list, height_only=height_only_fill
                )
                azi_ref = float(np.median(ref_azis)) if ref_azis else 90.0
                return MstarImageFillCalibration(
                    camera_height_scale=h_scale,
                    mesh_uniform_scale=mesh_scale,
                    target_span_az_px=float(np.median(tgt_u_list)),
                    target_span_rng_px=float(np.median(tgt_v_list)),
                    simulated_span_az_px=float(np.median(sim_u_list)),
                    simulated_span_rng_px=float(np.median(sim_v_list)),
                    reference_depression_deg=dep,
                    reference_azimuth_deg=azi_ref,
                    fill_factor_geom=f_geom,
                    num_views_used=len(f_u_list),
                )

    azimuths_to_try: List[float] = []
    if image_angles:
        tol = float(
            _resolve_mstar_arg(args, "target_dimension_summary_azimuth_tolerance_deg", 5.0)
            or 5.0
        )
        for ang in image_angles.values():
            azi_v = float(ang.get("azimuth", 0.0))
            a_n = azi_v % 360.0
            for ref in (90.0, 270.0):
                if min(abs(a_n - ref), abs(a_n - ref + 360.0), abs(a_n - ref - 360.0)) <= tol:
                    azimuths_to_try.append(azi_v)
                    break
    if not azimuths_to_try:
        azimuths_to_try = [resolve_mstar_side_view_azimuth_deg(summary_path, args)]

    span_pairs: List[Tuple[float, float]] = []
    ref_azis: List[float] = []
    for azi in azimuths_to_try:
        pix = _project_at(azi)
        if pix is None:
            continue
        span_pairs.append(_robust_span_px(pix))
        ref_azis.append(float(azi))

    if not span_pairs:
        return None

    span_u = float(np.median([s[0] for s in span_pairs]))
    span_v = float(np.median([s[1] for s in span_pairs]))
    azi = float(np.median(ref_azis)) if ref_azis else resolve_mstar_side_view_azimuth_deg(summary_path, args)
    from post_sfm.summary_parser import mstar_side_view_pixel_targets

    target_u, target_v = mstar_side_view_pixel_targets(l_px, w_px, side_view=True)
    target_u = max(target_u, 1.0)
    target_v = max(target_v, 1.0)

    f_u = float(target_u / span_u) if span_u > 1e-6 else 1.0
    f_v = float(target_v / span_v) if span_v > 1e-6 else 1.0

    h_scale, mesh_scale, f_geom = _mstar_fill_scales_from_ratio_lists(
        [f_u], [f_v], height_only=height_only_fill
    )

    return MstarImageFillCalibration(
        camera_height_scale=h_scale,
        mesh_uniform_scale=mesh_scale,
        target_span_az_px=target_u,
        target_span_rng_px=target_v,
        simulated_span_az_px=float(span_u),
        simulated_span_rng_px=float(span_v),
        reference_depression_deg=dep,
        reference_azimuth_deg=azi,
        fill_factor_geom=f_geom,
        num_views_used=len(span_pairs),
    )


def _resolve_mstar_camera_height_scale(
    args: Any,
    *,
    calibration: Optional[MstarImageFillCalibration] = None,
) -> float:
    cli_args = getattr(args, "_full_cli_args", None) or args
    argv = getattr(cli_args, "_argv", None) or sys.argv
    explicit = _resolve_mstar_arg(args, "sfm_mstar_camera_height_scale", None)
    if explicit is not None and _cli_flag_specified(
        argv, ("--sfm_mstar_camera_height_scale",)
    ):
        s = float(explicit)
        if math.isfinite(s) and s > 0:
            return float(min(8.0, max(0.25, s)))
    if mstar_auto_image_fill_match(args) and calibration is not None:
        return float(calibration.camera_height_scale)
    if explicit is not None and math.isfinite(float(explicit)) and float(explicit) > 0:
        return float(min(8.0, max(0.25, float(explicit))))
    return 1.0


def resolve_mstar_mesh_uniform_scale(
    args: Any,
    *,
    calibration: Optional[MstarImageFillCalibration] = None,
) -> float:
    """比例盒 final_uniform_scale：CLI 显式指定 > 自动闭合 > 默认 1.0。"""
    cli_args = getattr(args, "_full_cli_args", None) or args
    argv = getattr(cli_args, "_argv", None) or sys.argv
    explicit = getattr(cli_args, "sfm_mesh_prior_final_uniform_scale", None)
    if explicit is not None and _cli_flag_specified(
        argv, ("--sfm_mesh_prior_final_uniform_scale",)
    ):
        s = float(explicit)
        if math.isfinite(s) and s > 0:
            return float(s)
    if (
        mstar_fixed_physical_target_dims_enabled(args)
        and mstar_auto_image_fill_match(args)
        and not _cli_flag_specified(argv, ("--sfm_mesh_prior_final_uniform_scale",))
    ):
        return 1.0
    if mstar_auto_image_fill_match(args) and calibration is not None:
        return float(calibration.mesh_uniform_scale)
    if explicit is not None and math.isfinite(float(explicit)) and float(explicit) > 0:
        return float(explicit)
    return 1.0


def compute_mstar_initial_scene_params(
    *,
    image_size: int,
    focal_px: float,
    depression_horizon_deg: float,
    rho_range_m: float = MSTAR_DEFAULT_RANGE_RES_M,
    rho_azimuth_m: float = MSTAR_DEFAULT_AZIMUTH_RES_M,
    length_px: float = MSTAR_DEFAULT_LENGTH_PX,
    width_px: float = MSTAR_DEFAULT_WIDTH_PX,
    target_length_m: Optional[float] = None,
    target_aware_height: bool = False,
) -> MstarInitialSceneParams:
    """
    由 pinhole 闭合 depth_scale=Z/f=ρ 与 ring 几何 g=Na·sin(θ)·scene_scale 联立求初始 H、scene_scale。

    - φ：MSTAR 文件名 horizon 俯角（如 15°）
    - Z_pinhole = f·min(ρ_a, ρ_r)；H_pinhole = Z·sin(φ)
    - 固定米制目标（target_aware_height）：H = max(H_pinhole, L/tan(φ))，R0 = H/cos(θ_nadir)
      （L/tan(φ) 使圆环半径 g≈L·cot(φ)/tan(θ_nadir)∝车长，俯视视距显著大于 L·cos(φ)≈11 m）
    - scene_scale = g / (Na · sin(θ_nadir))，θ_nadir = 90° - φ
    """
    Na = int(max(image_size, 1))
    f = float(focal_px)
    phi = np.deg2rad(float(depression_horizon_deg))
    theta_nadir = np.deg2rad(90.0 - float(depression_horizon_deg))
    rho_eff = min(float(rho_azimuth_m), float(rho_range_m))

    z_slant = f * rho_eff
    h_pinhole = z_slant * float(np.sin(phi))
    h_platform = float(h_pinhole)
    height_mode = "pinhole_Z_sin_phi"

    if target_aware_height and target_length_m is not None and float(target_length_m) > 0:
        tan_phi = max(float(np.tan(phi)), 1e-9)
        h_overview = float(target_length_m) / tan_phi  # L/tan(φ)：保证 g∝L 的俯视视距
        h_target = max(float(target_length_m) * float(np.cos(phi)), h_overview)
        if h_target > h_platform + 1e-9:
            h_platform = h_target
            height_mode = "max_pinhole_L_over_tan_phi" if h_overview >= h_pinhole else "max_pinhole_L_cos_phi"
            cos_t = float(np.cos(theta_nadir))
            z_slant = h_platform / max(cos_t, 1e-9)
        elif abs(h_target - h_platform) <= 1e-9:
            height_mode = "L_over_tan_phi"

    g_ground = z_slant * float(np.cos(phi))
    if target_aware_height and h_platform > h_pinhole + 1e-9:
        g_ground = float(h_platform * np.tan(theta_nadir))

    sin_t = float(np.sin(theta_nadir))
    scene_scale = g_ground / max(Na * sin_t, 1e-9)

    cos_t = float(np.cos(theta_nadir))
    r0 = h_platform / max(cos_t, 1e-9)
    radius_scale = (Na * scene_scale) / max(r0, 1e-9)

    l_phys = float(length_px) * float(rho_azimuth_m)
    w_phys = float(width_px) * float(rho_range_m)
    if target_aware_height and target_length_m is not None and float(target_length_m) > 0:
        l_phys = float(target_length_m)

    init = MstarInitialSceneParams(
        camera_height_m=float(h_platform),
        scene_scale=float(scene_scale),
        radius_scale=float(radius_scale),
        slant_range_m=float(z_slant),
        ground_range_m=float(g_ground),
        depth_scale_target=float(rho_eff),
        focal_px=f,
        image_size=Na,
        depression_horizon_deg=float(depression_horizon_deg),
        length_px=float(length_px),
        width_px=float(width_px),
        length_phys_m=l_phys,
        width_phys_m=w_phys,
        rho_range_m=float(rho_range_m),
        rho_azimuth_m=float(rho_azimuth_m),
    )
    setattr(init, "_mstar_height_mode", height_mode)
    setattr(init, "_mstar_h_pinhole_m", float(h_pinhole))
    return init


def mstar_init_enabled(args: Any) -> bool:
    """MSTAR 像素分辨率初值是否启用（含 SFMOptions 未逐项转发时的 _full_cli_args 回退）。"""
    if bool(getattr(args, "sfm_mstar_init_from_pixel_resolution", False)):
        return True
    full = getattr(args, "_full_cli_args", None)
    if full is not None and bool(getattr(full, "sfm_mstar_init_from_pixel_resolution", False)):
        return True
    if bool(getattr(args, "geometry_prior_gs_model", False)):
        return True
    if full is not None and bool(getattr(full, "geometry_prior_gs_model", False)):
        return True
    if bool(getattr(args, "geometry_prior_rough_model", False)):
        return True
    if full is not None and bool(getattr(full, "geometry_prior_rough_model", False)):
        return True
    return False


def _resolve_mstar_arg(args: Any, key: str, default: Any) -> Any:
    val = getattr(args, key, None)
    if val is not None:
        return val
    full = getattr(args, "_full_cli_args", None)
    if full is not None:
        val = getattr(full, key, None)
        if val is not None:
            return val
    return default


def apply_mstar_initial_sar_params(
    sar_params: Dict[str, Any],
    args: Any,
    *,
    ref_width: int,
    ref_height: int,
    image_angles: Optional[Mapping[str, Mapping[str, float]]] = None,
    source_path: Optional[str] = None,
) -> Optional[MstarInitialSceneParams]:
    """
    将公式闭合的 H / scene_scale / radius_scale 写入 sar_params（SO-RCG 初值）。
    """
    if not mstar_init_enabled(args):
        return None

    rho_r = float(
        _resolve_mstar_arg(args, "sfm_mstar_range_resolution_m", MSTAR_DEFAULT_RANGE_RES_M)
        or MSTAR_DEFAULT_RANGE_RES_M
    )
    rho_a = float(
        _resolve_mstar_arg(args, "sfm_mstar_azimuth_resolution_m", MSTAR_DEFAULT_AZIMUTH_RES_M)
        or MSTAR_DEFAULT_AZIMUTH_RES_M
    )

    dep = 15.0
    if image_angles:
        deps = []
        for v in image_angles.values():
            if v.get("depression_sar") is not None:
                deps.append(float(v["depression_sar"]))
            else:
                deps.append(float(v.get("depression", dep)))
        if deps:
            dep = float(np.median(np.asarray(deps, dtype=np.float64)))

    from sar.imaging_mode import gs_optical_perspective_only_enabled

    cli_args = getattr(args, "_full_cli_args", None) or args
    if gs_optical_perspective_only_enabled(cli_args):
        from sar.optical_equivalent_depression import resolve_gs_render_depression_horizon_deg

        dep_render, dep_sar, dep_note = resolve_gs_render_depression_horizon_deg(
            float(dep),
            args=cli_args,
        )
        print(
            f"  [mstar] 光学透视初值: 文件名 φ_sar={dep_sar:.2f}° → "
            f"圆环渲染 φ_render={dep_render:.2f}° ({dep_note})"
        )
        dep = float(dep_render)

    Na = int(max(ref_width, ref_height))
    fs_override = _resolve_mstar_arg(args, "sfm_mstar_focal_scale", None)
    if fs_override is not None:
        focal_scale = float(fs_override)
    elif mstar_init_enabled(args):
        focal_scale = 0.5
    else:
        focal_scale = float(sar_params.get("focal_scale", 0.5))
    focal_px = Na * focal_scale

    l_px, w_px, _ = _resolve_target_px(
        getattr(args, "_full_cli_args", None) or args, source_path
    )

    target_length_m: Optional[float] = None
    target_aware = mstar_fixed_physical_target_dims_enabled(args)
    lm = wm = hm = None
    if target_aware:
        stats_dims = None
        if source_path:
            from post_sfm.summary_parser import parse_target_dimension_summary

            summary_path = os.path.join(
                source_path,
                "adaptive_threshold_visualization",
                "target_dimension_constraints_summary.txt",
            )
            stats_dims = parse_target_dimension_summary(summary_path)
        lm, wm, hm = resolve_mstar_fixed_physical_meters(args, stats_dims)
        target_length_m = float(lm)

    init = compute_mstar_initial_scene_params(
        image_size=Na,
        focal_px=focal_px,
        depression_horizon_deg=dep,
        rho_range_m=rho_r,
        rho_azimuth_m=rho_a,
        length_px=l_px,
        width_px=w_px,
        target_length_m=target_length_m,
        target_aware_height=target_aware,
    )
    if target_aware and lm is not None:
        init = replace(init, length_phys_m=float(lm), width_phys_m=float(wm))
        sar_params["mstar_fixed_physical_target_dims"] = True
        sar_params["mstar_target_length_m"] = float(lm)
        sar_params["mstar_target_width_m"] = float(wm)
        sar_params["mstar_target_height_m"] = float(hm)
        sar_params["mstar_fixed_physical_snap_lw_from_summary"] = bool(
            mstar_fixed_physical_snap_lw_from_summary_enabled(args)
        )
        print(
            f"  [mstar] 固定目标米制: L={lm:.2f} m, W={wm:.2f} m, H={hm:.2f} m"
            f"（L/W 可来自 summary；auto_fill / optical verify 仅调 R0/H）"
        )
    sar_params["mstar_formula_camera_height_m"] = float(init.camera_height_m)
    search_ratio = float(
        _resolve_mstar_arg(args, "sfm_sorc_height_only_search_ratio", 0.35) or 0.35
    )
    sar_params["mstar_height_search_ratio"] = float(min(0.95, max(0.02, search_ratio)))

    cli_args = getattr(args, "_full_cli_args", None) or args
    fill_cal: Optional[MstarImageFillCalibration] = None
    if mstar_auto_image_fill_match(cli_args):
        fill_cal = compute_mstar_sar_image_fill_calibration(
            args=cli_args,
            init=init,
            ref_width=ref_width,
            ref_height=ref_height,
            source_path=source_path,
            depression_horizon_deg=dep,
            image_angles=image_angles,
        )
        if fill_cal is not None:
            print(fill_cal.format_table())
        else:
            print(
                "⚠️ MSTAR 训练图像素占比自动闭合未生效（缺少 summary 或 SAR 投影），"
                "使用 camera_height_scale=1.0"
            )

    h_scale = _resolve_mstar_camera_height_scale(cli_args, calibration=fill_cal)
    mesh_scale = resolve_mstar_mesh_uniform_scale(cli_args, calibration=fill_cal)
    if mstar_auto_image_fill_match(cli_args) and not _cli_flag_specified(
        getattr(cli_args, "_argv", None) or sys.argv,
        ("--sfm_mesh_prior_final_uniform_scale",),
    ):
        setattr(cli_args, "sfm_mesh_prior_final_uniform_scale", float(mesh_scale))
        full = getattr(args, "_full_cli_args", None)
        if full is not None and full is not cli_args:
            setattr(full, "sfm_mesh_prior_final_uniform_scale", float(mesh_scale))
    if abs(h_scale - 1.0) > 1e-9:
        height_mode = getattr(init, "_mstar_height_mode", "pinhole_Z_sin_phi")
        h_pinhole = getattr(init, "_mstar_h_pinhole_m", None)
        init = MstarInitialSceneParams(
            camera_height_m=float(init.camera_height_m * h_scale),
            scene_scale=float(init.scene_scale * h_scale),
            radius_scale=float(init.radius_scale),
            slant_range_m=float(init.slant_range_m * h_scale),
            ground_range_m=float(init.ground_range_m * h_scale),
            depth_scale_target=float(init.depth_scale_target),
            focal_px=float(init.focal_px),
            image_size=int(init.image_size),
            depression_horizon_deg=float(init.depression_horizon_deg),
            length_px=float(init.length_px),
            width_px=float(init.width_px),
            length_phys_m=float(init.length_phys_m),
            width_phys_m=float(init.width_phys_m),
            rho_range_m=float(init.rho_range_m),
            rho_azimuth_m=float(init.rho_azimuth_m),
        )
        setattr(init, "_mstar_height_mode", height_mode)
        if h_pinhole is not None:
            setattr(init, "_mstar_h_pinhole_m", float(h_pinhole))
        print(
            f"  [mstar] camera_height_scale={h_scale:.3g} → "
            f"H={init.camera_height_m:.3f} m, R0={init.slant_range_m:.3f} m, "
            f"g={init.ground_range_m:.3f} m（ring 一致缩放）"
        )

    sar_params["camera_height"] = init.camera_height_m
    sar_params["scene_scale"] = init.scene_scale
    sar_params["radius_scale"] = init.radius_scale
    sar_params["default_radius_scale"] = init.radius_scale
    sar_params["focal_scale"] = focal_scale
    sar_params["mstar_init_from_pixel_resolution"] = True
    sar_params["mstar_init_camera_height_m"] = init.camera_height_m
    sar_params["mstar_init_scene_scale"] = init.scene_scale
    sar_params["mstar_init_slant_range_m"] = init.slant_range_m
    sar_params["mstar_init_ground_range_m"] = init.ground_range_m
    sar_params["mstar_init_focal_px"] = init.focal_px
    sar_params["mstar_target_length_m"] = init.length_phys_m
    sar_params["mstar_target_width_m"] = init.width_phys_m
    sar_params["mstar_camera_height_scale"] = float(h_scale)
    sar_params["mstar_computed_mesh_uniform_scale"] = float(mesh_scale)
    if fill_cal is not None:
        sar_params["mstar_auto_image_fill_match"] = True
        if fill_cal.num_views_used >= 3:
            sar_params["mstar_auto_image_fill_all_views"] = True
            sar_params["mstar_fill_num_views"] = int(fill_cal.num_views_used)
        sar_params["mstar_fill_target_span_az_px"] = float(fill_cal.target_span_az_px)
        sar_params["mstar_fill_target_span_rng_px"] = float(fill_cal.target_span_rng_px)
        sar_params["mstar_fill_simulated_span_az_px"] = float(fill_cal.simulated_span_az_px)
        sar_params["mstar_fill_simulated_span_rng_px"] = float(fill_cal.simulated_span_rng_px)
        sar_params["mstar_fill_factor_geom"] = float(fill_cal.fill_factor_geom)

    print(init.format_init_table())
    return init


def ensure_mstar_initial_sar_params(
    sar_params: Dict[str, Any],
    args: Any,
    *,
    ref_width: int,
    ref_height: int,
    image_angles: Optional[Mapping[str, Mapping[str, float]]] = None,
    source_path: Optional[str] = None,
) -> Optional[MstarInitialSceneParams]:
    """
    若启用 MSTAR/GS 预设则保证 sar_params 含公式闭合 H；已初始化时修正被 SO-RCG 污染的高度。
    """
    if not mstar_init_enabled(args):
        return None

    if sar_params.get("mstar_init_from_pixel_resolution"):
        h_auth = mstar_authoritative_height_m(sar_params)
        ch = float(sar_params.get("camera_height", 0.0) or 0.0)
        ratio = mstar_height_search_ratio(sar_params)
        if h_auth > 0 and solver_height_polluted(ch, h_auth, search_ratio=ratio):
            sar_params["camera_height"] = h_auth
        return None

    return apply_mstar_initial_sar_params(
        sar_params,
        args,
        ref_width=ref_width,
        ref_height=ref_height,
        image_angles=image_angles,
        source_path=source_path,
    )


def mstar_scale_fields_from_sar_params(sar_params: Mapping[str, Any]) -> Dict[str, Any]:
    """从 sar_params 提取应写入 sar_scale_params.json 的 MSTAR 字段。"""
    if not sar_params.get("mstar_init_from_pixel_resolution"):
        return {}
    h = float(sar_params.get("mstar_init_camera_height_m", sar_params.get("camera_height", 0.0)))
    fp = float(sar_params.get("mstar_init_focal_px", 0.0))
    out: Dict[str, Any] = {
        "mstar_init_from_pixel_resolution": True,
        "mstar_init_camera_height_m": h,
        "mstar_init_scene_scale": float(sar_params.get("mstar_init_scene_scale", sar_params.get("scene_scale", 1.0))),
        "mstar_init_slant_range_m": float(sar_params.get("mstar_init_slant_range_m", 0.0)),
        "camera_height": h,
        "scaled_camera_height": h,
        "scene_scale": float(sar_params.get("scene_scale", sar_params.get("mstar_init_scene_scale", 1.0))),
    }
    h_formula = float(sar_params.get("mstar_formula_camera_height_m", 0.0) or 0.0)
    if h_formula > 0:
        out["mstar_formula_camera_height_m"] = h_formula
    hr = float(sar_params.get("mstar_height_search_ratio", 0.0) or 0.0)
    if hr > 0:
        out["mstar_height_search_ratio"] = hr
    if fp > 0:
        out["unified_focal_azimuth"] = fp
        out["unified_focal_range"] = fp
        out["mstar_init_focal_px"] = fp
    hs = float(sar_params.get("mstar_camera_height_scale", 1.0) or 1.0)
    if abs(hs - 1.0) > 1e-9:
        out["mstar_camera_height_scale"] = hs
    ms = sar_params.get("mstar_computed_mesh_uniform_scale")
    if ms is not None:
        out["mstar_computed_mesh_uniform_scale"] = float(ms)
    if sar_params.get("mstar_fixed_physical_target_dims"):
        out["mstar_fixed_physical_target_dims"] = True
        for k in (
            "mstar_target_length_m",
            "mstar_target_width_m",
            "mstar_target_height_m",
            "mstar_target_length_width_ratio",
            "mstar_target_width_length_ratio",
            "gs_target_envelope_from_sparse",
            "gs_target_box_obj_path",
            "gs_target_world_aabb_lo",
            "gs_target_world_aabb_hi",
            "gs_target_world_extent_xyz",
            "mstar_fixed_physical_snap_lw_from_summary",
        ):
            if k in sar_params:
                out[k] = sar_params[k]
    if sar_params.get("mstar_auto_image_fill_match"):
        out["mstar_auto_image_fill_match"] = True
        if sar_params.get("mstar_auto_image_fill_all_views"):
            out["mstar_auto_image_fill_all_views"] = True
        for k in (
            "mstar_fill_target_span_az_px",
            "mstar_fill_target_span_rng_px",
            "mstar_fill_simulated_span_az_px",
            "mstar_fill_simulated_span_rng_px",
            "mstar_fill_factor_geom",
        ):
            if k in sar_params:
                out[k] = float(sar_params[k])
    return out


def scale_point_cloud_to_mstar_target_extent(
    point_cloud: np.ndarray,
    sar_params: Dict[str, Any],
    *,
    args: Optional[Any] = None,
) -> np.ndarray:
    """
    若稀疏点云包络与 MSTAR 目标米制差 >2×，在 SO-RCG 前做一次相似缩放（绕 footprint 锚点）。
    仅在 sfm_mstar_init_from_pixel_resolution 且点云非空时启用。
    """
    if not bool(sar_params.get("mstar_init_from_pixel_resolution")):
        return point_cloud
    pts = np.asarray(point_cloud, dtype=np.float64).reshape(-1, 3)
    if pts.shape[0] < 4:
        return point_cloud

    tgt_len = float(sar_params.get("mstar_target_length_m", 0.0))
    tgt_w = float(sar_params.get("mstar_target_width_m", 0.0))
    tgt = max(tgt_len, tgt_w, 1e-3)
    ext = float(np.max(np.ptp(pts, axis=0)))
    if ext < 1e-6 or ext / tgt < 2.0 and tgt / ext < 2.0:
        return point_cloud

    s = tgt / ext
    s = float(np.clip(s, 0.02, 50.0))
    pivot, _ = resolve_scene_anchor_mu(pts, args)
    scaled = pivot + s * (pts - pivot.reshape(1, 3))
    print(
        f"[mstar_init] 稀疏点云包络 {ext:.2f} m -> 目标 ~{tgt:.2f} m，"
        f"SO-RCG 前相似缩放 x{s:.4g}（绕接地点）"
    )
    return scaled.astype(np.float64)


def _read_points_aabb(sparse_dir: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    txt = os.path.join(sparse_dir, "points3D.txt")
    if not os.path.isfile(txt):
        return None, None
    pts: List[List[float]] = []
    with open(txt, encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            if line.startswith("#") or not line.strip():
                continue
            parts = line.split()
            if len(parts) >= 4:
                pts.append([float(parts[1]), float(parts[2]), float(parts[3])])
    if not pts:
        return None, None
    arr = np.asarray(pts, dtype=np.float64)
    return arr.min(0), arr.max(0)


def _load_summary_px(source_path: str) -> Tuple[Optional[float], Optional[float], Optional[float]]:
    import re

    viz = os.path.join(
        source_path,
        "adaptive_threshold_visualization",
        "target_dimension_constraints_summary.txt",
    )
    if not os.path.isfile(viz):
        return None, None, None
    with open(viz, encoding="utf-8", errors="ignore") as fh:
        text = fh.read()

    def _med(pattern: str) -> Optional[float]:
        m = re.search(pattern, text)
        return float(m.group(1)) if m else None

    return (
        _med(r"长度 \(L\):[^\n]*中位数=([\d.]+)"),
        _med(r"宽度 \(W\):[^\n]*中位数=([\d.]+)"),
        _med(r"高度 \(H\):[^\n]*中位数=([\d.]+)"),
    )


def _median_focal_from_sparse(sparse_dir: str) -> Tuple[float, int, int]:
    cam_txt = os.path.join(sparse_dir, "cameras.txt")
    if os.path.isfile(cam_txt):
        with open(cam_txt, encoding="utf-8", errors="ignore") as fh:
            for line in fh:
                if line.startswith("#") or not line.strip():
                    continue
                parts = line.split()
                if len(parts) >= 8 and parts[1] == "PINHOLE":
                    w, h = int(float(parts[2])), int(float(parts[3]))
                    fx, fy = float(parts[4]), float(parts[5])
                    return 0.5 * (fx + fy), w, h

    try:
        from post_sfm.sar_colmap_geom import load_colmap_views

        views = load_colmap_views(sparse_dir)
        if views:
            fs = [0.5 * (v.K[0, 0] + v.K[1, 1]) for v in views]
            return float(np.median(fs)), int(views[0].width), int(views[0].height)
    except ImportError:
        pass
    return 64.0, 128, 128


def estimate_uniform_scene_scale(
    *,
    slant_range_m: float,
    focal_px: float,
    rho_range_m: float = MSTAR_DEFAULT_RANGE_RES_M,
    rho_azimuth_m: float = MSTAR_DEFAULT_AZIMUTH_RES_M,
) -> float:
    """
    使 depth_scale=Z/f 降至 min(ρ_r, ρ_a) 的统一世界缩放因子（乘到点云与相机中心）。
    """
    z = float(slant_range_m)
    f = float(focal_px)
    if z <= 1e-9 or f <= 1e-9:
        return 1.0
    rho = min(float(rho_range_m), float(rho_azimuth_m))
    s = rho * f / z
    if not np.isfinite(s) or s <= 0:
        return 1.0
    return float(np.clip(s, 1e-6, 1.0))


def compute_mstar_scale_diagnostics(
    source_path: str,
    *,
    rho_range_m: float = MSTAR_DEFAULT_RANGE_RES_M,
    rho_azimuth_m: float = MSTAR_DEFAULT_AZIMUTH_RES_M,
) -> Optional[MstarScaleDiagnostics]:
    sparse_dir = os.path.join(source_path, "sparse", "0")
    scale_path = os.path.join(source_path, "sar_scale_params.json")
    if not os.path.isfile(scale_path):
        return None

    with open(scale_path, encoding="utf-8") as fh:
        sp = json.load(fh)

    focal, w, h = _median_focal_from_sparse(sparse_dir)
    z = float(sp.get("median_slant_range_m", sp.get("camera_height", 0.0)))
    h_cam = float(sp.get("camera_height", z))
    rs = float(sp.get("unified_radius_scale", 0.01))
    theta = np.deg2rad(75.0)
    ring_g = float(np.max(sp.get("reference_image_size", [128, 128]))) * float(np.sin(theta))
    if ring_g <= 0:
        ring_g = max(w, h) * float(np.sin(theta))

    l_px, w_px, h_px = _load_summary_px(source_path)
    rho_geo = float(np.sqrt(rho_range_m * rho_azimuth_m))
    ds_obs = z / focal if focal > 1e-9 else 0.0
    s = estimate_uniform_scene_scale(
        slant_range_m=z, focal_px=focal, rho_range_m=rho_range_m, rho_azimuth_m=rho_azimuth_m
    )

    mn, mx = _read_points_aabb(sparse_dir)
    aabb_ext = None
    aabb_max = None
    if mn is not None and mx is not None:
        ext = mx - mn
        aabb_ext = (float(ext[0]), float(ext[1]), float(ext[2]))
        aabb_max = float(ext.max())

    l_phys = l_px * rho_azimuth_m if l_px is not None else None
    w_phys = w_px * rho_range_m if w_px is not None else None
    h_phys = h_px * rho_range_m if h_px is not None else None
    l_world = l_px * ds_obs if l_px is not None else None
    w_world = w_px * ds_obs if w_px is not None else None

    return MstarScaleDiagnostics(
        image_size=(w, h),
        focal_px=focal,
        slant_range_m=z,
        camera_height_m=h_cam,
        radius_scale=rs,
        ring_ground_range_m=ring_g,
        depth_scale_observed=ds_obs,
        rho_range_m=rho_range_m,
        rho_azimuth_m=rho_azimuth_m,
        rho_geometric_mean_m=rho_geo,
        length_px=l_px,
        width_px=w_px,
        height_px=h_px,
        length_phys_m=l_phys,
        width_phys_m=w_phys,
        height_phys_m=h_phys,
        length_world_implied_m=l_world,
        width_world_implied_m=w_world,
        aabb_extent_xyz=aabb_ext,
        aabb_max_extent_m=aabb_max,
        uniform_scale_s=s,
        camera_height_after_m=h_cam * s,
        slant_range_after_m=z * s,
        depth_scale_after=ds_obs * s,
    )


def mstar_physical_semiaxes_xyz(
    stats: Any,
    *,
    rho_azimuth_m: float = MSTAR_DEFAULT_AZIMUTH_RES_M,
    rho_range_m: float = MSTAR_DEFAULT_RANGE_RES_M,
    planform_scale: float = 1.0,
    shadow_h_scale: float = 1.0,
    upper_h: float = 1.25,
    lower_h: float = 0.35,
) -> Optional[Tuple[float, float, float]]:
    """
    用 MSTAR 像素分辨率直接把阴影汇总 L/W/H（px）换到世界米制半轴，不依赖稀疏 depth_scale。
    L（方位）→ X，W（距离）→ Z，竖直 Y 仍用 H/L、H/W 比例。
    """
    from post_sfm.summary_parser import shadow_summary_semiaxes_xyz

    pf = float(planform_scale)
    h_world = None
    if stats.height_median_px is not None:
        h_world = float(stats.height_median_px) * float(rho_range_m) * float(shadow_h_scale)
    # depth_scale=1：L/W 已含米制
    lx_full = float(stats.length_median_px) * float(rho_azimuth_m) * pf
    lz_full = float(stats.width_median_px) * float(rho_range_m) * pf
    if lx_full <= 1e-9 or lz_full <= 1e-9:
        return None
    eff_ds_l = lx_full / max(float(stats.length_median_px), 1e-9)
    eff_ds_w = lz_full / max(float(stats.width_median_px), 1e-9)
    depth_scale = 0.5 * (eff_ds_l + eff_ds_w)
    return shadow_summary_semiaxes_xyz(
        stats, depth_scale, 1.0, h_world, upper_h, lower_h
    )


def _scale_colmap_extrinsics_about_pivot(
    sparse_dir: str,
    pivot: np.ndarray,
    scale: float,
) -> int:
    from scene.colmap_loader import read_extrinsics_binary, read_extrinsics_text, rotmat2qvec

    pivot = np.asarray(pivot, dtype=np.float64).reshape(3)
    s = float(scale)
    img_bin = os.path.join(sparse_dir, "images.bin")
    img_txt = os.path.join(sparse_dir, "images.txt")
    if os.path.isfile(img_bin):
        images = read_extrinsics_binary(img_bin)
    elif os.path.isfile(img_txt):
        images = read_extrinsics_text(img_txt)
    else:
        return 0

    from sar.gs_satellite_poses import _write_extrinsics_binary, _write_extrinsics_text

    n = 0
    for im in images.values():
        R = im.qvec2rotmat()
        C = (-R.T @ np.asarray(im.tvec, dtype=np.float64).reshape(3)).astype(np.float64)
        C_new = pivot + s * (C - pivot)
        t_new = (-R @ C_new).astype(np.float64)
        qvec = rotmat2qvec(R)
        images[im.id] = im._replace(qvec=qvec, tvec=t_new)
        n += 1

    if os.path.isfile(img_bin):
        _write_extrinsics_binary(img_bin, images)
    if os.path.isfile(img_txt):
        _write_extrinsics_text(img_txt, images)
    return n


def _scale_points_about_pivot(sparse_dir: str, pivot: np.ndarray, scale: float) -> int:
    from post_sfm.colmap_points import read_points3d_binary_full, sync_colmap_point_outputs

    pivot = np.asarray(pivot, dtype=np.float64).reshape(3)
    s = float(scale)
    bin_path = os.path.join(sparse_dir, "points3D.bin")
    if not os.path.isfile(bin_path):
        return 0
    records = read_points3d_binary_full(bin_path)
    if not records:
        return 0
    for rec in records:
        rec.xyz = (pivot + s * (rec.xyz.reshape(3) - pivot)).astype(np.float64)
    sync_colmap_point_outputs(sparse_dir, records)
    return len(records)


def _update_sar_scale_json(source_path: str, scale: float) -> None:
    path = os.path.join(source_path, "sar_scale_params.json")
    if not os.path.isfile(path):
        return
    with open(path, encoding="utf-8") as fh:
        sp = json.load(fh)
    s = float(scale)
    for key in ("camera_height", "scaled_camera_height", "median_slant_range_m", "median_platform_height_m"):
        if key in sp:
            sp[key] = float(sp[key]) * s
    if "point_cloud_max_extent" in sp:
        sp["point_cloud_max_extent"] = float(sp["point_cloud_max_extent"]) * s
    rs = sp.get("unified_radius_scale")
    if rs is not None and s > 1e-12:
        sp["unified_radius_scale"] = float(rs) / s
    sp["mstar_scene_scale_applied"] = s
    sp["mstar_scene_scale_reference"] = "sar/scene_scale_closure"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(sp, fh, indent=2, ensure_ascii=False)


def apply_mstar_scene_scale_normalization(
    source_path: str,
    args: Any,
    *,
    rho_range_m: Optional[float] = None,
    rho_azimuth_m: Optional[float] = None,
) -> Dict[str, Any]:
    """
    将 COLMAP 点云 + 外参 + sar_scale_params 统一缩放，使 depth_scale≈min(ρ_r,ρ_a)。
    应在 gs_satellite_poses 之前调用（SO-RCG 之后）。
    """
    sparse_dir = os.path.join(source_path, "sparse", "0")
    if not os.path.isdir(sparse_dir):
        return {"applied": False, "reason": "no_sparse"}

    rho_r = float(
        rho_range_m
        if rho_range_m is not None
        else getattr(args, "sfm_mstar_range_resolution_m", MSTAR_DEFAULT_RANGE_RES_M)
        or MSTAR_DEFAULT_RANGE_RES_M
    )
    rho_a = float(
        rho_azimuth_m
        if rho_azimuth_m is not None
        else getattr(args, "sfm_mstar_azimuth_resolution_m", MSTAR_DEFAULT_AZIMUTH_RES_M)
        or MSTAR_DEFAULT_AZIMUTH_RES_M
    )

    diag = compute_mstar_scale_diagnostics(source_path, rho_range_m=rho_r, rho_azimuth_m=rho_a)
    if diag is None:
        return {"applied": False, "reason": "no_diagnostics"}

    print(diag.format_table())

    s = float(diag.uniform_scale_s)
    tol = float(getattr(args, "sfm_mstar_scene_scale_skip_if_near", 0.92) or 0.92)
    if s >= tol:
        print(f"[mstar_scene_scale] 跳过：s={s:.4g} 已接近 1（阈值 {tol}）")
        return {"applied": False, "reason": "scale_near_unity", "scale": s, "diagnostics": diag}

    from post_sfm.colmap_points import read_points3d_binary_full

    bin_path = os.path.join(sparse_dir, "points3D.bin")
    pts = np.zeros((0, 3), dtype=np.float64)
    if os.path.isfile(bin_path):
        recs = read_points3d_binary_full(bin_path)
        if recs:
            pts = np.stack([r.xyz.reshape(3) for r in recs], axis=0)

    pivot, anchor_mode = resolve_scene_anchor_mu(pts, args)
    n_pts = _scale_points_about_pivot(sparse_dir, pivot, s)
    n_cam = _scale_colmap_extrinsics_about_pivot(sparse_dir, pivot, s)
    _update_sar_scale_json(source_path, s)

    print(
        f"[mstar_scene_scale] 已应用 s={s:.6g}（锚点={anchor_mode} "
        f"{pivot[0]:.2f},{pivot[1]:.2f},{pivot[2]:.2f}）\n"
        f"  点 {n_pts}，相机 {n_cam}；H {diag.camera_height_m:.1f}→{diag.camera_height_after_m:.1f} m，"
        f"depth_scale {diag.depth_scale_observed:.3g}→{diag.depth_scale_after:.3g} m/px\n"
    )
    return {
        "applied": True,
        "scale": s,
        "num_points": n_pts,
        "num_cameras": n_cam,
        "anchor_mode": anchor_mode,
        "diagnostics": diag,
    }


def mstar_scene_scale_enabled(args: Any) -> bool:
    return bool(getattr(args, "sfm_normalize_scene_to_mstar_resolution", False))


def maybe_apply_mstar_scene_scale_normalization(source_path: str, args: Any) -> None:
    if not mstar_scene_scale_enabled(args):
        return
    try:
        apply_mstar_scene_scale_normalization(source_path, args)
    except Exception as exc:
        print(f"⚠️ mstar_scene_scale 归一化失败（继续 convert）: {exc}")
