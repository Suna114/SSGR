"""
SAR refine：**在条件允许时**在「仅目标」初始点云外自动铺开两层片状高斯（轻量 densify 与铺板可同时启用，见文末条件）。

默认（sar_refine_seed_placement_mode=camera_ray）：以 **均值训练相机中心 → 目标质心** 的视线方向 ω 为「深度」：

- **阴影 / 遮光**：在 centroid − d_sh⋅ω 一侧——沿 ω 的反方向偏移；d_sh **越小**，薄片 **越靠近目标质心**、对各训练相机视角而言 **整体上离相机更远**；
- **背景**：在 centroid + d_bg⋅ω 一侧——沿 ω **远离均值相机**；
- ω 由各视角共享一根「平均射线」决定；离该视线很远的相机的合成几何与薄片相对关系会与「平均视角」不同（相邻视角易出现遮挡/拉丝）。

注意：仅用 **mean(cam_centers)→质心** 定 ω，本质是 **对所有训练相机一视同仁**；若只靠单一参考视角摆放，会令其它方位的相机上看到薄片错位，叠加上 alpha 排序就会产生「一侧正常、另一侧截断或散焦絮乱」。本仓库沿用均值射线以减少这种偏斜，但不能完全消除大角度差。**轻量 densify（sar_refine_light_densify）下也会铺板**：与增生的暗/薄片高斯区分开，可把阴影初值铺在更不伤目标的一侧（仍受 d_sh、d_bg 节制）。

world_axis：退回按世界坐标轴 sar_refine_seed_vertical_*（旧逻辑）。

ground_plane（BG/阴影 NVS 预设默认）：**背景**铺在目标底面水平面（``sar_refine_seed_ground_axis``，
默认 z，与 train.py SAR 高度轴一致）；切向 span 为目标 AABB 的另两轴。**阴影**仍为沿
均值相机→质心 ω 的多层薄板（``sar_refine_seed_shadow_depth_fracs`` 逗号分隔），模拟方位叠掩。

矩阵→四元数片段逻辑与 PyTorch3D ``matrix_to_quaternion`` 一致（BSD-3）。
"""

from __future__ import annotations

from typing import Any, Mapping, Optional, Tuple

import torch
import torch.nn.functional as F

from utils.sh_utils import RGB2SH


def _standardize_quaternion(quaternions: torch.Tensor) -> torch.Tensor:
    return torch.where(quaternions[..., 0:1] < 0, -quaternions, quaternions)


def _sqrt_positive_part(x: torch.Tensor) -> torch.Tensor:
    positive_mask = x > 0
    safe_x = torch.where(positive_mask, x, 1.0)
    return torch.where(positive_mask, torch.sqrt(safe_x), 0.0)


def _matrix_to_quaternion(matrix: torch.Tensor) -> torch.Tensor:
    if matrix.size(-1) != 3 or matrix.size(-2) != 3:
        raise ValueError(f"Invalid rotation matrix shape {matrix.shape}.")
    batch_dim = matrix.shape[:-2]
    m00, m01, m02, m10, m11, m12, m20, m21, m22 = torch.unbind(matrix.reshape(batch_dim + (9,)), dim=-1)
    q_abs = _sqrt_positive_part(
        torch.stack(
            [
                1.0 + m00 + m11 + m22,
                1.0 + m00 - m11 - m22,
                1.0 - m00 + m11 - m22,
                1.0 - m00 - m11 + m22,
            ],
            dim=-1,
        )
    )
    quat_by_rijk = torch.stack(
        [
            torch.stack(
                [torch.square(q_abs[..., 0]), m21 - m12, m02 - m20, m10 - m01], dim=-1
            ),
            torch.stack(
                [m21 - m12, torch.square(q_abs[..., 1]), m10 + m01, m02 + m20], dim=-1
            ),
            torch.stack(
                [m02 - m20, m10 + m01, torch.square(q_abs[..., 2]), m12 + m21], dim=-1
            ),
            torch.stack(
                [m10 - m01, m20 + m02, m21 + m12, torch.square(q_abs[..., 3])], dim=-1
            ),
        ],
        dim=-2,
    )
    flr = torch.tensor(0.1, dtype=q_abs.dtype, device=q_abs.device)
    quat_candidates = quat_by_rijk / (2.0 * q_abs[..., None].max(flr))
    indices = q_abs.argmax(dim=-1, keepdim=True)
    gather_indices = indices.unsqueeze(-1).expand(list(indices.shape[:-1]) + [1, 4])
    out = torch.gather(quat_candidates, -2, gather_indices).squeeze(-2)
    return _standardize_quaternion(out)


def _axis_idx(name: str) -> int:
    m = {"x": 0, "y": 1, "z": 2}
    k = (name or "y").lower().strip()
    if k not in m:
        raise ValueError(f"sar_refine_seed_vertical_axis 只能是 x/y/z，当前为 {name!r}")
    return m[k]


def _make_grid_world_axis_plane(
    *,
    plane_axis: int,
    lo_u: torch.Tensor,
    hi_u: torch.Tensor,
    lo_v: torch.Tensor,
    hi_v: torch.Tensor,
    nu: int,
    nv: int,
    plane_coord: torch.Tensor,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    if nu < 1 or nv < 1:
        return torch.zeros((0, 3), device=device, dtype=dtype)
    tus = torch.linspace(0.0, 1.0, nu, device=device, dtype=dtype)
    tvs = torch.linspace(0.0, 1.0, nv, device=device, dtype=dtype)
    uu = lo_u + (hi_u - lo_u) * tus.unsqueeze(1).expand(nu, nv)
    vv = lo_v + (hi_v - lo_v) * tvs.unsqueeze(0).expand(nu, nv)
    others = tuple(i for i in (0, 1, 2) if i != plane_axis)
    u_ax, v_ax = others[0], others[1]
    u_flat = uu.reshape(-1)
    v_flat = vv.reshape(-1)
    n = int(u_flat.numel())
    xyz = torch.zeros((n, 3), device=device, dtype=dtype)
    xyz[:, u_ax] = u_flat
    xyz[:, v_ax] = v_flat
    xyz[:, plane_axis] = plane_coord.reshape(1).expand(n).to(dtype=dtype)
    return xyz


def _orthonormal_uv_from_omega(omega: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    h = omega.new_tensor([1.0, 0.0, 0.0])
    if torch.abs(torch.dot(h, omega)) > 0.9:
        h = omega.new_tensor([0.0, 1.0, 0.0])
    u = F.normalize(h - torch.dot(h, omega) * omega, dim=-1)
    v = torch.linalg.cross(omega, u)
    v = F.normalize(v, dim=-1)
    return u, v


def _make_grid_cam_plane(
    *,
    origin: torch.Tensor,
    u_axes: torch.Tensor,
    v_axes: torch.Tensor,
    lo_u: torch.Tensor,
    hi_u: torch.Tensor,
    lo_v: torch.Tensor,
    hi_v: torch.Tensor,
    nu: int,
    nv: int,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    if nu < 1 or nv < 1:
        return torch.zeros((0, 3), device=device, dtype=dtype)
    tus = torch.linspace(0.0, 1.0, nu, device=device, dtype=dtype)
    tvs = torch.linspace(0.0, 1.0, nv, device=device, dtype=dtype)
    uu = lo_u + (hi_u - lo_u) * tus.unsqueeze(1).expand(nu, nv)
    vv = lo_v + (hi_v - lo_v) * tvs.unsqueeze(0).expand(nu, nv)
    u_flat = uu.reshape(-1)
    v_flat = vv.reshape(-1)
    return (
        origin.view(1, 3)
        + u_flat.view(-1, 1) * u_axes.view(1, 3)
        + v_flat.view(-1, 1) * v_axes.view(1, 3)
    )


def _mean_train_camera_center(
    scene: Any,
    *,
    device: torch.device,
    dtype: torch.dtype,
) -> Optional[torch.Tensor]:
    if scene is None:
        return None
    tk = getattr(scene, "train_cameras", None)
    if tk is None or len(tk) == 0:
        return None
    scales = list(tk.keys())
    scale_key = 1.0 if 1.0 in tk else scales[0]
    try:
        cams = tk[scale_key]
    except Exception:
        return None
    centers = []
    for cam in cams:
        c = cam.camera_center
        if isinstance(c, torch.Tensor):
            centers.append(c.detach().reshape(1, 3))
        else:
            centers.append(
                torch.as_tensor(c, dtype=torch.float32, device=device).reshape(1, 3)
            )
    if not centers:
        return None
    return torch.cat(centers, dim=0).mean(dim=0).to(device=device, dtype=dtype)


def maybe_seed_sar_refine_bg_shadow_at_init(
    gaussians: Any,
    opt: Mapping[str, Any],
    *,
    dataset_sar_mode: bool,
    checkpoint_was_loaded: bool,
    scene: Any = None,
) -> bool:
    if checkpoint_was_loaded:
        return False
    if not bool(dataset_sar_mode):
        return False
    if not bool(getattr(opt, "sar_refine_target_bg", False)):
        return False
    if not bool(getattr(opt, "sar_refine_seed_bg_shadow_plates", True)):
        return False

    light_densify = bool(getattr(opt, "sar_refine_light_densify", True))
    du_it = int(getattr(opt, "densify_until_iter", 0) or 0)
    # 「轻量 densify」仍希望有初始阴影/背景薄片（沿 ω），避免增生把暗椭球拖到极近相机；
    # 仅在「会 densify 但又不是 sar_refine 的轻量路径」的旧组合下跳过。
    if du_it > 0 and not light_densify:
        return False

    n_tgt = int(gaussians.get_xyz.shape[0])
    if n_tgt < 1:
        return False

    placement = (
        str(getattr(opt, "sar_refine_seed_placement_mode", "camera_ray") or "camera_ray")
        .lower()
        .strip()
    )
    if placement not in ("camera_ray", "world_axis", "ground_plane"):
        print(f"[SAR refine seed] placement_mode={placement!r} 未知，改用 ground_plane")
        placement = "ground_plane"

    device = gaussians.get_xyz.device
    dtype = gaussians.get_xyz.dtype

    bbox_margin = float(getattr(opt, "sar_refine_seed_bbox_margin_frac", 0.12) or 0.0)
    below_frac = float(getattr(opt, "sar_refine_seed_below_extent_frac", 0.06) or 0.0)
    above_frac = float(getattr(opt, "sar_refine_seed_above_extent_frac", 0.045) or 0.0)
    flip = bool(getattr(opt, "sar_refine_seed_vertical_flip", False))
    nu_bg = int(getattr(opt, "sar_refine_seed_bg_plane_resolution", 12) or 0)
    nv_bg = int(getattr(opt, "sar_refine_seed_bg_plane_resolution_v", 12) or 0)
    nu_sh = int(getattr(opt, "sar_refine_seed_shadow_plane_resolution", 10) or 0)
    nv_sh = int(getattr(opt, "sar_refine_seed_shadow_plane_resolution_v", 10) or 0)
    bg_bright = float(getattr(opt, "sar_refine_seed_bg_brightness_scale", 0.88) or 0.0)
    sh_bright = float(getattr(opt, "sar_refine_seed_shadow_brightness_scale", 0.32) or 0.0)
    plane_mult = float(getattr(opt, "sar_refine_seed_plane_gaussian_scale_mult", 1.45) or 1.0)
    thin_mult = float(getattr(opt, "sar_refine_seed_slab_thin_scale_mult", 0.42) or 0.05)
    bg_opaq = float(getattr(opt, "sar_refine_seed_bg_initial_opacity", 0.28) or 0.05)
    sh_opaq = float(getattr(opt, "sar_refine_seed_shadow_initial_opacity", 0.45) or 0.05)

    with torch.no_grad():
        xyz0 = gaussians.get_xyz[:n_tgt]
        lo_b, _ = torch.min(xyz0, dim=0)
        hi_b, _ = torch.max(xyz0, dim=0)
        diag = torch.norm(hi_b - lo_b)
        if diag < 1e-8:
            diag = xyz0.new_tensor(1.0)

        centroid = xyz0.mean(dim=0)

        placed_via_camera_ray = False
        placed_ground_bg = False
        omega_str = ""
        uv_desc = ""
        ax_name = ""

        xyz_bg_pts = torch.zeros((0, 3), device=device, dtype=dtype)
        xyz_shadow = torch.zeros((0, 3), device=device, dtype=dtype)
        rot_q_single = centroid.new_tensor([1.0, 0.0, 0.0, 0.0])

        def _parse_shadow_fracs() -> list:
            raw = str(getattr(opt, "sar_refine_seed_shadow_depth_fracs", "0.022") or "0.022")
            out: list = []
            for tok in raw.replace(";", ",").split(","):
                tok = tok.strip()
                if not tok:
                    continue
                try:
                    out.append(float(tok))
                except ValueError:
                    continue
            return out if out else [float(above_frac)]

        if placement == "ground_plane":
            try:
                g_ax = _axis_idx(str(getattr(opt, "sar_refine_seed_ground_axis", "z")))
            except ValueError as e:
                print(f"[SAR refine seed] {e}")
                g_ax = 2
            horiz = tuple(i for i in (0, 1, 2) if i != g_ax)
            u_ax, v_ax = horiz[0], horiz[1]
            q_bot = float(getattr(opt, "sar_refine_seed_ground_bottom_quantile", 0.10) or 0.10)
            q_bot = min(0.45, max(0.01, q_bot))
            pc_bg = torch.quantile(xyz0[:, g_ax].detach(), q_bot)
            pad_uv = bbox_margin * diag
            lo_u_w = lo_b[u_ax] - pad_uv
            hi_u_w = hi_b[u_ax] + pad_uv
            lo_v_w = lo_b[v_ax] - pad_uv
            hi_v_w = hi_b[v_ax] + pad_uv
            xyz_bg_pts = _make_grid_world_axis_plane(
                plane_axis=g_ax,
                lo_u=lo_u_w,
                hi_u=hi_u_w,
                lo_v=lo_v_w,
                hi_v=hi_v_w,
                nu=max(1, nu_bg),
                nv=max(1, nv_bg),
                plane_coord=pc_bg,
                device=device,
                dtype=dtype,
            )
            ax_name = ("x", "y", "z")[g_ax]
            placed_ground_bg = True
            rot_q_single = centroid.new_tensor([1.0, 0.0, 0.0, 0.0])

            cam_c = _mean_train_camera_center(scene, device=device, dtype=dtype)
            if cam_c is not None:
                view_vec = centroid - cam_c
                vn = torch.norm(view_vec)
                if vn.item() >= 1e-6:
                    omega = view_vec / (vn + 1e-9)
                    uv_u, uv_v = _orthonormal_uv_from_omega(omega)
                    dp = xyz0 - centroid.unsqueeze(0)
                    su = torch.sum(dp * uv_u.unsqueeze(0), dim=-1)
                    sv = torch.sum(dp * uv_v.unsqueeze(0), dim=-1)
                    pad = bbox_margin * diag
                    lo_u_s = su.min() - pad
                    hi_u_s = su.max() + pad
                    lo_v_s = sv.min() - pad
                    hi_v_s = sv.max() + pad
                    shadow_chunks = []
                    for frac in _parse_shadow_fracs():
                        d_sh = float(frac) * diag
                        if flip:
                            origin = centroid + d_sh * omega
                        else:
                            origin = centroid - d_sh * omega
                        shadow_chunks.append(
                            _make_grid_cam_plane(
                                origin=origin,
                                u_axes=uv_u,
                                v_axes=uv_v,
                                lo_u=lo_u_s,
                                hi_u=hi_u_s,
                                lo_v=lo_v_s,
                                hi_v=hi_v_s,
                                nu=max(1, nu_sh),
                                nv=max(1, nv_sh),
                                device=device,
                                dtype=dtype,
                            )
                        )
                    if shadow_chunks:
                        xyz_shadow = torch.cat(shadow_chunks, dim=0)
                    omega_str = ",".join(f"{float(omega[i]):+.4f}" for i in range(3))
                    uv_desc = (
                        f"ground_plane bg axis={ax_name} z={float(pc_bg):.5f}; "
                        f"shadow layers={len(_parse_shadow_fracs())} along ω=[{omega_str}]"
                    )

        if placement == "camera_ray":
            cam_c = _mean_train_camera_center(scene, device=device, dtype=dtype)
            if cam_c is None:
                print("[SAR refine seed] camera_ray 无训练相机中心，回退 world_axis")
            else:
                view_vec = centroid - cam_c
                vn = torch.norm(view_vec)
                if vn.item() < 1e-6:
                    print("[SAR refine seed] camera_ray：相机中心与目标质心几乎重合，回退 world_axis")
                else:
                    omega = view_vec / (vn + 1e-9)
                    d_sh = float(above_frac) * diag
                    d_bg = float(below_frac) * diag
                    if flip:
                        d_sh, d_bg = d_bg, d_sh
                    shadow_origin = centroid - d_sh * omega
                    bg_origin = centroid + d_bg * omega
                    uv_u, uv_v = _orthonormal_uv_from_omega(omega)
                    omega_str = ",".join(f"{float(omega[i]):+.4f}" for i in range(3))

                    dp = xyz0 - centroid.unsqueeze(0)
                    su = torch.sum(dp * uv_u.unsqueeze(0), dim=-1)
                    sv = torch.sum(dp * uv_v.unsqueeze(0), dim=-1)
                    pad = bbox_margin * diag
                    lo_u_s = su.min() - pad
                    hi_u_s = su.max() + pad
                    lo_v_s = sv.min() - pad
                    hi_v_s = sv.max() + pad

                    xyz_shadow = _make_grid_cam_plane(
                        origin=shadow_origin,
                        u_axes=uv_u,
                        v_axes=uv_v,
                        lo_u=lo_u_s,
                        hi_u=hi_u_s,
                        lo_v=lo_v_s,
                        hi_v=hi_v_s,
                        nu=max(1, nu_sh),
                        nv=max(1, nv_sh),
                        device=device,
                        dtype=dtype,
                    )
                    xyz_bg_pts = _make_grid_cam_plane(
                        origin=bg_origin,
                        u_axes=uv_u,
                        v_axes=uv_v,
                        lo_u=lo_u_s,
                        hi_u=hi_u_s,
                        lo_v=lo_v_s,
                        hi_v=hi_v_s,
                        nu=max(1, nu_bg),
                        nv=max(1, nv_bg),
                        device=device,
                        dtype=dtype,
                    )
                    Rmat = torch.stack([uv_u, uv_v, omega], dim=1)
                    rot_q_single = _matrix_to_quaternion(Rmat.unsqueeze(0)).squeeze(0)
                    uv_desc = (
                        f"ω(cam_center→tgt)=[{omega_str}] "
                        f"shadowΔ={float(d_sh):.5f}(沿−ω偏离质心侧) bgΔ={float(d_bg):.5f}(沿+ω远离均值相机侧)"
                    )
                    placed_via_camera_ray = True

        if not placed_via_camera_ray and not placed_ground_bg:
            try:
                ax = _axis_idx(str(getattr(opt, "sar_refine_seed_vertical_axis", "y")))
            except ValueError as e:
                print(f"[SAR refine seed] {e}")
                return False

            ax_name = ("x", "y", "z")[ax]
            others = tuple(i for i in (0, 1, 2) if i != ax)
            u_axis_num, v_axis_num = others[0], others[1]
            pad_uv = bbox_margin * diag
            lo_u_w = lo_b[u_axis_num] - pad_uv
            hi_u_w = hi_b[u_axis_num] + pad_uv
            lo_v_w = lo_b[v_axis_num] - pad_uv
            hi_v_w = hi_b[v_axis_num] + pad_uv

            if flip:
                pc_bg = lo_b[ax] - below_frac * diag
                pc_sh = hi_b[ax] + above_frac * diag
            else:
                pc_bg = hi_b[ax] + below_frac * diag
                pc_sh = lo_b[ax] - above_frac * diag

            xyz_bg_pts = _make_grid_world_axis_plane(
                plane_axis=ax,
                lo_u=lo_u_w,
                hi_u=hi_u_w,
                lo_v=lo_v_w,
                hi_v=hi_v_w,
                nu=max(1, nu_bg),
                nv=max(1, nv_bg),
                plane_coord=pc_bg,
                device=device,
                dtype=dtype,
            )
            xyz_shadow = _make_grid_world_axis_plane(
                plane_axis=ax,
                lo_u=lo_u_w,
                hi_u=hi_u_w,
                lo_v=lo_v_w,
                hi_v=hi_v_w,
                nu=max(1, nu_sh),
                nv=max(1, nv_sh),
                plane_coord=pc_sh,
                device=device,
                dtype=dtype,
            )
            rot_q_single = centroid.new_tensor([1.0, 0.0, 0.0, 0.0])
            uv_desc = f"world_axis axis={ax_name} bg_plane={float(pc_bg):.5f} shadow_plane={float(pc_sh):.5f}"

        n_bg = int(xyz_bg_pts.shape[0])
        n_sh = int(xyz_shadow.shape[0])
        if n_bg + n_sh == 0:
            return False

        luma_tgt = gaussians.get_dc_luminosity()
        q_snap = float(getattr(opt, "sar_refine_brightness_cap_quantile", 0.99))
        q_snap = min(0.9999, max(0.5, q_snap))
        med_snap = torch.median(luma_tgt[:n_tgt])
        cap_snap = torch.quantile(luma_tgt[:n_tgt], q_snap)

        gaussians._refine_brightness_snapshotted = True  # noqa: SLF001
        gaussians._refine_brightness_n0 = n_tgt  # noqa: SLF001
        gaussians._refine_brightness_cap_max = cap_snap.detach()  # noqa: SLF001
        gaussians._refine_brightness_cap_median = med_snap.detach()  # noqa: SLF001
        frac = float(getattr(opt, "sar_refine_new_point_max_luma_fraction", 0.0) or 0.0)
        if frac > 1e-6:
            gaussians._refine_new_point_luma_limit = (med_snap * frac).detach().clamp(min=1e-5)  # noqa: SLF001

        med_eff = torch.clamp(med_snap.detach(), min=1e-4)

        inverse_scal = gaussians.scaling_inverse_activation
        if placed_via_camera_ray or (placed_ground_bg and n_sh > 0):
            base_lin = (
                gaussians.get_scaling[:n_tgt].max(dim=1).values.median(dim=0).values.detach().clamp_min(1e-6)
            )
            scales_lin = (
                torch.stack(
                    [base_lin * plane_mult, base_lin * plane_mult, base_lin * thin_mult],
                    dim=-1,
                )
                .unsqueeze(0)
                .expand(n_bg + n_sh, -1)
                .clone()
            )
            new_scaling = inverse_scal(scales_lin)
        elif placed_ground_bg:
            med_lin_full = gaussians.get_scaling[:n_tgt].median(dim=0).values.detach()
            scales_lin = med_lin_full.unsqueeze(0).expand(n_bg, -1).clone()
            scales_lin[:, u_ax] *= plane_mult
            scales_lin[:, v_ax] *= plane_mult
            scales_lin[:, g_ax] *= thin_mult
            new_scaling = inverse_scal(scales_lin)
        else:
            med_lin_full = gaussians.get_scaling[:n_tgt].median(dim=0).values.detach()
            scales_lin = med_lin_full.unsqueeze(0).expand(n_bg + n_sh, -1).clone()
            scales_lin[:, u_axis_num] *= plane_mult
            scales_lin[:, v_axis_num] *= plane_mult
            scales_lin[:, ax] *= thin_mult
            new_scaling = inverse_scal(scales_lin)

        new_xyz = torch.cat([xyz_bg_pts, xyz_shadow], dim=0)
        fdtype = gaussians._features_dc.dtype  # noqa: SLF001

        bg_rgb = torch.full((3,), float(med_eff) * bg_bright, device=device, dtype=torch.float32)
        sh_rgb = torch.full((3,), float(med_eff) * sh_bright, device=device, dtype=torch.float32)
        # RGB2SH 输出 [1,3]；对每个板上网格角点各自一份 DC，须 expand/repeat，不可 view(n_bg,3)
        fc_bg = RGB2SH(bg_rgb.view(1, 3)).expand(n_bg, -1).contiguous()

        msh = gaussians.max_sh_degree
        n_coeff_rest = max(0, (msh + 1) ** 2 - 1)
        n_new = int(new_xyz.shape[0])
        f_rest = torch.zeros((n_new, n_coeff_rest, 3), device=device, dtype=fdtype)
        invopa = gaussians.inverse_opacity_activation
        if n_sh > 0:
            fc_sh = RGB2SH(sh_rgb.view(1, 3)).expand(n_sh, -1).contiguous()
            new_features_dc = (
                torch.cat([fc_bg.unsqueeze(1), fc_sh.unsqueeze(1)], dim=0).to(fdtype).contiguous()
            )
            o_bg = invopa(bg_opaq * torch.ones((n_bg, 1), device=device, dtype=gaussians._opacity.dtype))  # noqa: SLF001
            o_sh = invopa(sh_opaq * torch.ones((n_sh, 1), device=device, dtype=gaussians._opacity.dtype))  # noqa: SLF001
            new_opacity = torch.cat([o_bg, o_sh], dim=0)
        else:
            new_features_dc = fc_bg.unsqueeze(1).to(fdtype).contiguous()
            new_opacity = invopa(
                bg_opaq * torch.ones((n_bg, 1), device=device, dtype=gaussians._opacity.dtype)
            )  # noqa: SLF001

        rot_q_rep = (
            rot_q_single.to(device=device, dtype=gaussians._rotation.dtype)
            .unsqueeze(0)
            .expand(n_new, -1)
            .contiguous()
        )
        new_rotation = rot_q_rep

        tmp_radii_zeros = torch.zeros((n_new,), device=device, dtype=dtype)

        if getattr(gaussians, "tmp_radii", None) is None:
            n_cur = int(gaussians.get_xyz.shape[0])
            gaussians.tmp_radii = torch.zeros((n_cur,), device=device, dtype=dtype)  # noqa: SLF001

        gaussians.densification_postfix(
            new_xyz,
            new_features_dc,
            f_rest,
            new_opacity,
            new_scaling,
            new_rotation,
            tmp_radii_zeros,
        )

        if placed_ground_bg:
            eff = "ground_plane"
        elif placed_via_camera_ray:
            eff = "camera_ray"
        else:
            eff = "world_axis"
        print(
            f"[SAR refine seed] placement={eff}：背景 n={n_bg}，阴影 n={n_sh}；{uv_desc}"
            f"；vertical_flip={flip}；目标点数={n_tgt}；快照 p{q_snap:.2f}"
        )

    return True
