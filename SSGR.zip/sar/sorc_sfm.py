# sar_sorc_sfm.py
"""
基于SO-RCG算法的SAR Structure-from-Motion实现

参考论文: "Keypoint-Based SAR Structure From Motion via Riemannian Optimization"
(IEEE Transactions on Geoscience and Remote Sensing, 2025)

本实现严格按照论文中的公式和方法：

核心公式（均来自论文）：
1. Range-Doppler (RD) 投影模型：
   - 距离方程: R = |P_target - P_radar(t)|
   - 多普勒方程: f_d = -(2/λ) * (dR/dt)
   - 方位向位置: 雷达坐标系中的X坐标

2. 重投影误差：
   - 基于精确的RD成像模型建立
   - error_range = R_proj - R_obs
   - error_azimuth = azimuth_proj - azimuth_obs
   - total_error = error_range² + w * error_azimuth²

3. 三角化：
   - 使用斜距方程，而不是透视投影
   - 两个球面的交点（基于斜距约束）

4. 优化方法：
   - SO-RCG算法在SO(3)群上优化旋转矩阵
   - 5个自由度约束（SAR成像只依赖5个DoF）

GPU加速支持：
- 可以使用PyTorch进行GPU加速
- 通过设置use_gpu=True启用GPU加速
- 主要加速：
  - 批量计算重投影误差
  - 批量优化3D点

CPU多线程加速支持：
- 使用ThreadPoolExecutor进行多线程并行计算
- 自动检测CPU核心数
- 主要加速：
  - 批量计算重投影误差
  - 批量优化3D点
"""
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

import numpy as np
from scipy.spatial.transform import Rotation as Rot
from scipy.linalg import expm, logm
import warnings

# GPU支持（可选）
try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None


class SORCG_SAR_SfM:
    """
    基于SO-RCG算法的SAR SfM求解器
    
    目标函数：
        min_{R_k, t_k, X_j} Σ_k,j ||x_kj - π_RD(R_k, t_k, X_j)||²
        s.t. R_k ∈ SO(3)
    
    其中：
        - R_k: 第k个雷达的旋转矩阵（SO(3)群上的元素）
        - t_k: 第k个雷达的平移向量
        - X_j: 第j个3D点的坐标
        - π_RD: Range-Doppler成像模型的投影函数
    """
    
    def __init__(self, sar_params=None, max_iterations=100, tolerance=1e-6, 
                 verbose=True, use_5dof=True, use_gpu=False, device=None, 
                 num_threads=None):
        """
        初始化SO-RCG SAR SfM求解器
        
        Args:
            sar_params: SAR系统参数字典
            max_iterations: 最大迭代次数
            tolerance: 收敛容差
            verbose: 是否输出详细信息
            use_5dof: 是否使用5个DoF约束
            use_gpu: 是否使用GPU加速（需要PyTorch）
            device: PyTorch设备（如'torch.device('cuda:0')'），如果为None则自动选择
            num_threads: CPU多线程数量（None表示自动检测，0表示禁用多线程）
        """
        self.sar_params = sar_params or self._get_default_sar_params()
        self.max_iterations = max_iterations
        self.tolerance = tolerance
        self.verbose = verbose
        self.use_5dof = use_5dof
        self.error_history = []
        
        # 🔧 尝试从汇总文件加载阴影计算的目标长宽高比例
        self._load_shadow_calculated_ratio()
        
        # GPU设置（必须先设置，因为多线程检查需要用到）
        self.use_gpu = use_gpu and TORCH_AVAILABLE
        
        # 多线程设置（CPU版本）
        if num_threads is None:
            # 自动检测CPU核心数
            self.num_threads = os.cpu_count() or 4
        elif num_threads == 0:
            # 禁用多线程
            self.num_threads = 1
        else:
            self.num_threads = max(1, num_threads)
        
        if not self.use_gpu and self.num_threads > 1:
            if self.verbose:
                print(f"✅ CPU多线程加速已启用: {self.num_threads} 线程")
        if self.use_gpu:
            if device is None:
                self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            else:
                self.device = device
            
            if self.device.type == 'cuda':
                if self.verbose:
                    print(f"✅ GPU加速已启用: {torch.cuda.get_device_name(0)}")
            else:
                self.use_gpu = False
                if self.verbose:
                    print("⚠️ GPU不可用，回退到CPU")
        else:
            self.device = None
            if use_gpu and not TORCH_AVAILABLE:
                if self.verbose:
                    print("⚠️ PyTorch未安装，无法使用GPU加速")
        
    def _get_default_sar_params(self):
        """获取默认SAR参数"""
        return {
            'f0': 5.4e9,  # 雷达中心频率 (Hz)
            'lmda': 0.06,  # 波长 (m)
            'C': 3e8,  # 光速 (m/s)
            'camera_height': 1365.0,  # 相机/平台高度 (m)
            'Va': 755,  # 平台速度 (m/s)
            'sita0': 31.57 * np.pi / 180,  # 中心下视角 (弧度)
            'prf': 2200,  # 脉冲重复频率 (Hz)
            'fs': 1.1 * 240e6,  # 采样率 (Hz)
            'Na': 512,  # 方位向采样点数
            'Nr': 512,  # 距离向采样点数
            'camera_distribution_mode': 'ring',  # 使用水平圆环分布（SAR卫星应该在固定高度）
        }
    
    def _load_shadow_calculated_ratio(self):
        """
        从汇总文件加载阴影计算的目标长宽高比例，用于点云高度约束
        
        汇总文件路径：通常在特征提取输出目录下的 target_dimension_constraints_summary.txt
        """
        try:
            # 尝试从sar_params中获取汇总文件路径
            summary_file_path = self.sar_params.get('target_dimension_summary_file', None)
            
            # 如果没有指定路径，尝试从常见位置查找
            if summary_file_path is None or not os.path.exists(summary_file_path):
                # 尝试从特征提取输出目录查找
                feature_output_dir = self.sar_params.get('feature_output_dir', None)
                if feature_output_dir:
                    candidate_path = os.path.join(feature_output_dir, 'target_dimension_constraints_summary.txt')
                    if os.path.exists(candidate_path):
                        summary_file_path = candidate_path
                
                # 如果还是找不到，尝试在当前目录查找
                if summary_file_path is None or not os.path.exists(summary_file_path):
                    candidate_path = 'target_dimension_constraints_summary.txt'
                    if os.path.exists(candidate_path):
                        summary_file_path = candidate_path
            
            # 如果找到了汇总文件，尝试加载
            if summary_file_path and os.path.exists(summary_file_path):
                try:
                    from feature_extraction import load_target_dimension_constraints_from_summary
                    target_dimensions = load_target_dimension_constraints_from_summary(summary_file_path)
                    
                    if target_dimensions and 'height_length_ratio' in target_dimensions:
                        shadow_ratio = target_dimensions['height_length_ratio']
                        # 如果sar_params中没有指定point_height_length_ratio，使用阴影计算的比例
                        # 如果未设置或值为None，则使用阴影计算的比例
                        if 'point_height_length_ratio' not in self.sar_params or \
                           self.sar_params.get('point_height_length_ratio') is None:
                            self.sar_params['point_height_length_ratio'] = shadow_ratio
                            if self.verbose:
                                print(f"\n  ✅ 使用阴影计算的目标高度/长度比例: {shadow_ratio:.4f}")
                                print(f"     来源: {summary_file_path}")
                        else:
                            if self.verbose:
                                user_ratio = self.sar_params.get('point_height_length_ratio')
                                if user_ratio is None:
                                    user_ratio = "未设置"
                                print(f"\n  ℹ️ 检测到阴影计算的比例 ({shadow_ratio:.4f})，但使用用户指定的比例 ({user_ratio})")
                        
                        # 🔧 加载宽度约束：高度/宽度比例
                        if 'height_width_ratio' in target_dimensions:
                            shadow_width_ratio = target_dimensions['height_width_ratio']
                            # 如果sar_params中没有指定point_height_width_ratio，使用阴影计算的比例
                            if 'point_height_width_ratio' not in self.sar_params or \
                               self.sar_params.get('point_height_width_ratio') is None:
                                self.sar_params['point_height_width_ratio'] = shadow_width_ratio
                                if self.verbose:
                                    print(f"  ✅ 使用阴影计算的目标高度/宽度比例: {shadow_width_ratio:.4f}")
                                    print(f"     来源: {summary_file_path}")
                            else:
                                if self.verbose:
                                    user_width_ratio = self.sar_params.get('point_height_width_ratio')
                                    if user_width_ratio is None:
                                        user_width_ratio = "未设置"
                                    print(f"  ℹ️ 检测到阴影计算的宽度比例 ({shadow_width_ratio:.4f})，但使用用户指定的比例 ({user_width_ratio})")
                        
                        # 🔧 加载长度/宽度比例（如果存在）
                        if 'length_width_ratio' in target_dimensions:
                            shadow_l_w_ratio = target_dimensions['length_width_ratio']
                            # 如果sar_params中没有指定point_length_width_ratio，使用阴影计算的比例
                            if 'point_length_width_ratio' not in self.sar_params or \
                               self.sar_params.get('point_length_width_ratio') is None:
                                self.sar_params['point_length_width_ratio'] = shadow_l_w_ratio
                                if self.verbose:
                                    print(f"  ✅ 使用阴影计算的目标长度/宽度比例: {shadow_l_w_ratio:.4f}")
                                    print(f"     来源: {summary_file_path}")
                except ImportError:
                    if self.verbose:
                        print(f"\n  ⚠️ 无法导入 load_target_dimension_constraints_from_summary，跳过阴影比例加载")
                except Exception as e:
                    if self.verbose:
                        print(f"\n  ⚠️ 加载阴影计算比例时出错: {e}")
            else:
                if self.verbose:
                    user_ratio = self.sar_params.get('point_height_length_ratio')
                    if user_ratio is None:
                        print(f"\n  ℹ️ 未找到目标尺寸汇总文件，且未在config.py中设置point_height_length_ratio")
                    else:
                        print(f"\n  ℹ️ 未找到目标尺寸汇总文件，使用config.py中设置的高度/长度比例: {user_ratio:.4f}")
        except Exception as e:
            if self.verbose:
                print(f"\n  ⚠️ 加载阴影计算比例时出错: {e}")
    
    def compute_rd_projection(self, point3d, R_cam, t_cam, sar_params=None):
        """
        基于Range-Doppler模型计算SAR投影
        
        根据论文 "Keypoint-Based SAR Structure From Motion via Riemannian Optimization":
        - 使用精确的Range-Doppler (RD) 成像模型
        - 距离方程: R = |P_target - P_radar(t)|
        - 多普勒方程: f_d = -(2/λ) * (dR/dt)
        - 方位向位置: 雷达坐标系中的X坐标（方位向距离）
        
        Args:
            point3d: 3D点坐标 (3,) - 世界坐标系
            R_cam: 旋转矩阵 (3x3) - 从世界坐标系到雷达坐标系 (R_world_to_radar)
            t_cam: 平移向量 (3x1) - 从世界坐标系到雷达坐标系 (t = -R @ P_radar_world)
            sar_params: SAR系统参数（可选）
        
        Returns:
            range: 斜距（米）- 根据距离方程计算
            azimuth: 方位向位置（米）- 雷达坐标系中的X坐标
            doppler: 多普勒频率（Hz）- 根据多普勒方程计算
        """
        if sar_params is None:
            sar_params = self.sar_params
        
        # ========== 根据论文的RD投影模型计算 ==========
        
        # 1. 计算雷达位置（在世界坐标系中）
        # 根据论文：R_cam是从世界坐标系到雷达坐标系的旋转（R_world_to_radar）
        # t_cam = -R_cam @ P_radar_world，所以 P_radar_world = -R_cam.T @ t_cam
        P_radar = -R_cam.T @ t_cam.flatten()
        
        # 1.5. 异常值检测：如果3D点坐标异常大，可能是单位问题或优化发散
        # 检查3D点坐标的合理性（应该在场景中心附近，几百到几千米）
        point_norm = np.linalg.norm(point3d)
        radar_norm = np.linalg.norm(P_radar)
        camera_height = sar_params.get('camera_height', 1365.0)
        
        # 参考斜距R0 = camera_height / sin(俯视角)
        # 对于典型SAR场景，3D点应该在场景中心附近，距离雷达位置应该在R0的0.1-2倍范围内
        # 如果3D点距离雷达位置远大于R0的3倍，可能是异常值
        expected_max_range = camera_height * 3  # 保守估计：最大斜距应该是camera_height的3倍以内
        
        # 计算3D点到雷达的距离
        point_to_radar_distance = np.linalg.norm(point3d - P_radar)
        
        # 如果距离异常大，记录警告但不修正（让优化过程处理）
        if point_to_radar_distance > expected_max_range * 2:
            # 异常值：距离过大，可能是单位问题或优化发散
            # 返回一个大的误差值，但不抛出异常（让优化过程处理）
            if self.verbose and not hasattr(self, '_warned_large_range'):
                print(f"  ⚠️ 警告: 检测到异常大的投影斜距 ({point_to_radar_distance:.2f}米 > {expected_max_range*2:.2f}米)")
                print(f"      - 3D点坐标: {point3d}")
                print(f"      - 3D点范数: {point_norm:.2f}米")
                print(f"      - 雷达位置: {P_radar}")
                print(f"      - 雷达位置范数: {radar_norm:.2f}米")
                print(f"      - 投影斜距: {point_to_radar_distance:.2f}米")
                print(f"      - 可能原因: 3D点坐标单位异常或优化发散")
                self._warned_large_range = True
        
        # 2. 计算斜距（距离方程）
        # 根据论文：R = |P_target - P_radar(t)|
        range_val = np.linalg.norm(point3d - P_radar)
        
        # 3. 计算方位向位置
        # 根据论文：方位向位置是雷达坐标系中的X坐标
        # 将3D点转换到雷达坐标系
        # 雷达坐标系：X轴=方位向，Y轴=距离向，Z轴=波束指向
        point_cam = R_cam @ point3d.reshape(3, 1) + t_cam
        
        # 方位向位置：雷达坐标系中的X坐标（米）
        # 这表示目标点相对于雷达位置的方位向距离
        # 注意：图像中心对应雷达正下方的位置（方位向偏移为0）
        # 所以这里的azimuth是相对于雷达位置的绝对方位向距离
        # 
        # 重要：在SAR成像中，图像中心对应雷达正下方的位置
        # 雷达坐标系的原点在雷达位置，X轴指向方位向
        # 图像中心（x=Na/2）对应雷达正下方的位置，此时X坐标应该接近0
        # 但实际3D点可能在雷达的侧方，所以X坐标可能很大
        azimuth = point_cam[0, 0]
        
        # 诊断：如果方位向位置异常大，可能需要检查坐标系定义
        # 方位向位置应该在几百到几千米之间（取决于场景大小）
        if abs(azimuth) > 10000:
            # 方位向位置异常大，可能是坐标系定义问题
            # 但暂时不修正，让优化过程来处理
            pass
        
        # 4. 计算多普勒频率（多普勒方程）
        # 根据论文：f_d = -(2/λ) * (dR/dt)
        # 这里使用速度向量和方向向量的点积来近似 dR/dt
        Va = sar_params.get('Va', 755)  # 平台速度（米/秒）
        lmda = sar_params.get('lmda', 0.06)  # 波长（米）
        
        # 计算从雷达到点的单位方向向量
        direction = (point3d - P_radar) / (range_val + 1e-8)
        # 假设平台速度沿方位向（雷达坐标系的X轴方向）
        velocity = np.array([Va, 0, 0])
        # 计算多普勒频率：f_d = -(2/λ) * (V · direction)
        doppler = -(2.0 / lmda) * np.dot(velocity, direction)
        
        return range_val, azimuth, doppler
    
    def compute_rd_reprojection_error(self, point3d, R_cam, t_cam, image_point,
                                     depression_angle, sar_params=None):
        """
        计算基于RD模型的重投影误差
        
        根据论文 "Keypoint-Based SAR Structure From Motion via Riemannian Optimization":
        - 目标函数是所有重投影误差的总和，基于精确的RD成像模型建立
        - 重投影误差 = 投影值 - 观测值
        - 斜距误差: error_range = R_proj - R_obs
        - 方位向误差: error_azimuth = azimuth_proj - azimuth_obs
        - 总误差: total_error = error_range² + w * error_azimuth² (w为权重)
        
        Args:
            point3d: 3D点坐标 (3,) - 世界坐标系
            R_cam: 旋转矩阵 (3x3) - 从世界坐标系到雷达坐标系
            t_cam: 平移向量 (3x1) - 从世界坐标系到雷达坐标系
            image_point: 图像点坐标 (2,) - (x, y)，x=方位向，y=距离向
            depression_angle: 俯视角（度）- 用于计算参考斜距 R0 = camera_height / sin(俯视角)
            sar_params: SAR系统参数（可选）
        
        Returns:
            error_range: 斜距误差（米）
            error_azimuth: 方位向误差（米）
            total_error: 总误差（加权和）
        """
        # 如果使用GPU且输入是tensor，使用GPU版本
        if self.use_gpu and isinstance(point3d, torch.Tensor):
            return self._compute_rd_reprojection_error_gpu(
                point3d, R_cam, t_cam, image_point, depression_angle, sar_params
            )
        if sar_params is None:
            sar_params = self.sar_params
        
        # 计算投影的斜距和方位
        range_proj, azimuth_proj, _ = self.compute_rd_projection(
            point3d, R_cam, t_cam, sar_params
        )
        
        # ========== 根据论文的RD模型计算观测值 ==========
        
        # SAR系统参数
        Nr = sar_params.get('Nr', 512)  # 距离向采样点数
        Na = sar_params.get('Na', 512)  # 方位向采样点数
        fs = sar_params.get('fs', 1.1 * 240e6)  # 采样率（Hz）
        C = sar_params.get('C', 3e8)  # 光速（米/秒）
        camera_height = sar_params.get('camera_height', 1365.0)  # 相机高度（米）
        Va = sar_params.get('Va', 755)  # 平台速度（米/秒）
        prf = sar_params.get('prf', 2200)  # 脉冲重复频率（Hz）
        
        # 计算像素对应的物理尺寸（根据SAR成像原理）
        # 距离向：SAR图像的距离向像素对应回波时间，转换为斜距
        # range_pixel_size = C / (2 * fs) 是每个像素对应的斜距增量（米/像素）
        range_pixel_size = C / (2 * fs)
        
        # 方位向：SAR图像的方位向像素对应平台移动距离
        # azimuth_pixel_size = Va / prf 是每个像素对应的方位向距离（米/像素）
        azimuth_pixel_size = Va / prf
        
        # 🔧 重要修复：计算参考斜距R0
        # 问题：之前使用R0 = camera_height / sin(俯视角)，忽略了radius_scale
        # 解决：使用相机的实际位置（已应用radius_scale）
        # 
        # 相机位置已经通过compute_sar_camera_pose计算，并应用了统一的radius_scale
        # 所以R0应该是相机到原点的实际距离
        P_radar = -R_cam.T @ t_cam.flatten()
        R0 = np.linalg.norm(P_radar)  # 相机到原点的实际距离（已应用radius_scale）
        
        # 为了诊断，也计算理论R0
        dep_rad = np.deg2rad(depression_angle)
        R0_theory = camera_height / np.sin(dep_rad)  # 理论R0（未缩放）
        
        # 诊断：检查R0和3D点坐标的合理性（仅在第一次调用时）
        if self.verbose and not hasattr(self, '_diagnosed_R0_reprojection'):
            point_range = np.linalg.norm(point3d - P_radar)
            if abs(point_range - R0) > R0 * 0.5:  # 如果投影斜距与实际R0差异很大
                print(f"  ⚠️ 诊断: 检测到3D点距离相机较远")
                print(f"      - 3D点坐标: {point3d}")
                print(f"      - 雷达位置: {P_radar}")
                print(f"      - 投影斜距: {point_range:.2f}米")
                print(f"      - 实际R0（已应用radius_scale）: {R0:.2f}米 ✅")
                print(f"      - 理论R0（未缩放）: {R0_theory:.2f}米 (camera_height={camera_height:.1f}米, 俯视角={depression_angle:.1f}°)")
                print(f"      - radius_scale效果: {R0_theory:.0f}m → {R0:.0f}m (×{R0/R0_theory:.4f})")
                print(f"      - 差异: {abs(point_range - R0):.2f}米 ({abs(point_range - R0)/R0*100:.1f}%)")
                print(f"      ℹ️ 注意: 使用实际R0（已应用radius_scale），误差应该很小")
                self._diagnosed_R0_reprojection = True
        
        # ========== 根据论文计算重投影误差 ==========
        
        # 1. 将图像坐标转换为物理坐标
        y_image = image_point[1]  # 距离向坐标（图像坐标系，原点在左上角）
        x_image = image_point[0]  # 方位向坐标（图像坐标系，原点在左上角）
        
        # 2. 转换为相对于图像中心的坐标（像素）
        y_center = y_image - Nr / 2.0  # 距离向偏移（像素）
        x_center = x_image - Na / 2.0  # 方位向偏移（像素）
        
        # 3. 转换为物理坐标（米）
        y_norm = y_center * range_pixel_size    # 距离向偏移（米）
        x_norm = x_center * azimuth_pixel_size  # 方位向偏移（米）
        
        # 4. 计算观测的斜距和方位
        # 根据论文：SAR图像中心对应参考斜距R0，距离向像素对应斜距增量
        range_obs = R0 + y_norm  # 观测斜距（米）
        
        # 方位向：SAR图像的方位向中心对应雷达正下方的方位向位置（通常为0）
        # azimuth_proj是雷达坐标系中的X坐标（相对于雷达位置的绝对方位向距离）
        # azimuth_obs是从图像坐标转换的方位向偏移（相对于图像中心，即相对于雷达正下方）
        # 注意：两者都是相对于雷达位置的偏移，应该可以直接比较
        azimuth_obs = x_norm  # 观测方位向偏移（米，相对于图像中心/雷达正下方）
        
        # 5. 计算重投影误差（根据论文）
        # error_range = R_proj - R_obs
        # error_azimuth = azimuth_proj - azimuth_obs
        # 注意：如果方位误差过大，可能是坐标系定义不一致
        error_range = range_proj - range_obs
        error_azimuth = azimuth_proj - azimuth_obs
        
        # 诊断：如果方位误差异常大，可能需要检查坐标系定义
        # 方位误差应该与斜距误差在同一数量级（几百米到几千米）
        # 
        # 注意：如果方位误差过大（>1000米且>斜距误差的10倍），可能是：
        # 1. 雷达坐标系的X轴定义与图像坐标系的x轴定义不一致
        # 2. 3D点的位置确实在雷达的侧方（X方向上有很大偏移）
        # 3. 图像坐标到物理坐标的转换有问题
        #
        # 对于SO-RCG优化，大的初始误差是可以接受的，优化过程会逐步修正
        # 但如果误差持续增大，可能需要检查坐标系定义
        if abs(error_azimuth) > abs(error_range) * 10 and abs(error_azimuth) > 1000:
            # 记录诊断信息，但不修正（让优化过程来处理）
            # 如果优化过程中误差持续增大，可能需要检查：
            # 1. 雷达坐标系的定义是否正确
            # 2. 图像坐标到物理坐标的转换是否正确
            # 3. SAR参数（特别是Va和prf）是否匹配
            pass
        
        # 诊断：如果误差过大，输出详细信息（仅第一次）
        if self.verbose and not hasattr(self, '_diagnosed_reprojection'):
            if abs(error_range) > 1000:  # 如果斜距误差>1000米
                print(f"  ⚠️ 诊断: 检测到重投影误差过大")
                print(f"      - 图像坐标: ({x_image:.1f}, {y_image:.1f}) 像素")
                print(f"      - 图像中心偏移: ({x_center:.1f}, {y_center:.1f}) 像素")
                print(f"      - 物理偏移: ({x_norm:.2f}, {y_norm:.2f}) 米")
                print(f"      - 投影斜距: {range_proj:.2f}米")
                print(f"      - 观测斜距: {range_obs:.2f}米 (R0={R0:.2f}米 + y_norm={y_norm:.2f}米)")
                print(f"      - 斜距误差: {error_range:.2f}米")
                print(f"      - 投影方位: {azimuth_proj:.2f}米")
                print(f"      - 观测方位: {azimuth_obs:.2f}米")
                print(f"      - 方位误差: {error_azimuth:.2f}米")
                print(f"      - 可能原因:")
                print(f"        1. 坐标系不匹配（3D点坐标单位可能是像素而非米）")
                print(f"        2. SAR参数不匹配（camera_height, fs, prf等）")
                print(f"        3. 初始位姿不正确")
                print(f"        4. 图像坐标到物理坐标的转换错误")
                self._diagnosed_reprojection = True
        
        # 6. 计算总误差（根据论文：加权和）
        # 根据论文，斜距误差是主要误差源
        # 方位向误差权重较小，因为SAR的方位向分辨率通常较低
        total_error = error_range**2 + 0.05 * error_azimuth**2
        
        return error_range, error_azimuth, total_error
    
    def _compute_rd_reprojection_error_batch_gpu(self, points_3d, R_cam, t_cam, 
                                                  image_points, depression_angles, sar_params=None):
        """
        GPU批量计算重投影误差（高效版本）
        
        Args:
            points_3d: 3D点坐标 (N, 3) - torch.Tensor
            R_cam: 旋转矩阵 (3, 3) - torch.Tensor
            t_cam: 平移向量 (3, 1) - torch.Tensor
            image_points: 图像点坐标 (N, 2) - torch.Tensor
            depression_angles: 俯视角 (N,) - torch.Tensor（度）
            sar_params: SAR系统参数（可选）
        
        Returns:
            error_range: 斜距误差 (N,) - torch.Tensor
            error_azimuth: 方位向误差 (N,) - torch.Tensor
            total_error: 总误差 (N,) - torch.Tensor
        """
        if sar_params is None:
            sar_params = self.sar_params
        
        device = points_3d.device
        N = points_3d.shape[0]
        
        # 转换为tensor并移动到GPU
        R_cam_t = R_cam if isinstance(R_cam, torch.Tensor) else torch.from_numpy(R_cam).float().to(device)
        t_cam_t = t_cam if isinstance(t_cam, torch.Tensor) else torch.from_numpy(t_cam).float().to(device)
        image_points_t = image_points if isinstance(image_points, torch.Tensor) else torch.from_numpy(image_points).float().to(device)
        dep_angles_t = depression_angles if isinstance(depression_angles, torch.Tensor) else torch.from_numpy(np.array(depression_angles)).float().to(device)

        # 统一外参形状：R=(3,3)，t=(3,)；兼容 (3,1)/(1,3) 及调用方多余的 unsqueeze
        R_cam_t = R_cam_t.reshape(3, 3)
        t_vec = t_cam_t.reshape(-1)[:3]
        if t_vec.numel() != 3:
            raise ValueError(f"t_cam 元素数无效: {t_cam_t.shape}，期望 3")
        
        # SAR参数
        Nr = sar_params.get('Nr', 512)
        Na = sar_params.get('Na', 512)
        fs = sar_params.get('fs', 1.1 * 240e6)
        C = sar_params.get('C', 3e8)
        camera_height = sar_params.get('camera_height', 1365.0)
        Va = sar_params.get('Va', 755)
        prf = sar_params.get('prf', 2200)
        
        # 计算像素对应的物理尺寸
        range_pixel_size = C / (2 * fs)
        azimuth_pixel_size = Va / prf
        
        # 计算雷达位置（世界坐标）
        P_radar = -(R_cam_t.T @ t_vec)  # (3,)
        
        # 确保输入形状正确
        if points_3d.dim() == 1:
            points_3d = points_3d.unsqueeze(0)  # (1, 3)
        if image_points_t.dim() == 1:
            image_points_t = image_points_t.unsqueeze(0)  # (1, 2)
        if dep_angles_t.dim() == 0:
            dep_angles_t = dep_angles_t.unsqueeze(0)  # (1,)
        
        N = points_3d.shape[0]
        
        # 确保points_3d是(N, 3)形状 - 严格验证和修复
        if len(points_3d.shape) != 2:
            raise ValueError(f"points_3d维度不正确: {points_3d.shape}, 期望(N, 3)")
        
        if points_3d.shape[1] != 3:
            if points_3d.shape[1] > 3:
                print(f"⚠️ 警告: points_3d形状不正确: {points_3d.shape}, 只取前3列")
                points_3d = points_3d[:, :3]  # 只取前3列
            else:
                raise ValueError(f"points_3d形状不正确: {points_3d.shape}, 期望(N, 3), 列数不足")
        
        # 最终验证
        if points_3d.shape[1] != 3:
            raise ValueError(f"points_3d形状修复失败: {points_3d.shape}, 期望(N, 3)")
        
        # 确保image_points_t是(N, 2)形状
        if image_points_t.shape[1] != 2:
            if image_points_t.shape[1] > 2:
                image_points_t = image_points_t[:, :2]  # 只取前2列
            else:
                raise ValueError(f"image_points_t形状不正确: {image_points_t.shape}, 期望(N, 2)")
        
        # 确保所有张量的第一个维度匹配
        if image_points_t.shape[0] != N:
            if image_points_t.shape[0] == 1:
                image_points_t = image_points_t.expand(N, -1)
            else:
                image_points_t = image_points_t[:N]
        
        if dep_angles_t.shape[0] != N:
            if dep_angles_t.shape[0] == 1:
                dep_angles_t = dep_angles_t.expand(N)
            else:
                dep_angles_t = dep_angles_t[:N]
        
        # 批量计算斜距
        range_proj = torch.norm(points_3d - P_radar.unsqueeze(0), dim=1)  # (N,)
        
        # 批量计算方位向位置（世界 → 雷达/相机坐标）
        points_cam = points_3d @ R_cam_t.T + t_vec.unsqueeze(0)  # (N, 3)
        azimuth_proj = points_cam[:, 0]  # (N,)
        
        # 🔧 重要修复：计算观测的斜距和方位
        # 问题：之前使用R0 = camera_height / sin(depression)，忽略了radius_scale
        # 解决：使用相机的实际位置（已应用radius_scale）
        # 
        # 相机位置已经通过compute_sar_camera_pose计算，并应用了统一的radius_scale
        # 所以R0应该是相机到原点的实际距离，与俯视角无关（所有相机在同一球面上）
        R0_actual = torch.norm(P_radar)  # 相机到原点的实际距离（标量）
        R0 = R0_actual.expand(N)  # 扩展为(N,)，所有点使用相同的R0
        
        # 图像坐标转换
        y_image = image_points_t[:, 1]  # (N,)
        x_image = image_points_t[:, 0]  # (N,)
        y_center = y_image - Nr / 2.0
        x_center = x_image - Na / 2.0
        y_norm = y_center * range_pixel_size
        x_norm = x_center * azimuth_pixel_size
        
        # 观测值
        range_obs = R0 + y_norm  # (N,)
        azimuth_obs = x_norm  # (N,)
        
        # 计算误差
        error_range = range_proj - range_obs  # (N,)
        error_azimuth = azimuth_proj - azimuth_obs  # (N,)
        total_error = error_range**2 + 0.05 * error_azimuth**2  # (N,)
        
        # 确保返回值的形状正确
        if total_error.dim() == 0:
            total_error = total_error.unsqueeze(0)
        if error_range.dim() == 0:
            error_range = error_range.unsqueeze(0)
        if error_azimuth.dim() == 0:
            error_azimuth = error_azimuth.unsqueeze(0)
        
        return error_range, error_azimuth, total_error
    
    def _compute_rd_reprojection_error_gpu(self, point3d, R_cam, t_cam, image_point,
                                          depression_angle, sar_params=None):
        """
        GPU版本的单点重投影误差计算
        """
        # 转换为批量形式
        points_3d = point3d.unsqueeze(0) if point3d.dim() == 1 else point3d
        image_points = image_point.unsqueeze(0) if image_point.dim() == 1 else image_point
        dep_angles = torch.tensor([depression_angle], device=point3d.device) if isinstance(depression_angle, (int, float)) else depression_angle
        
        error_range, error_azimuth, total_error = self._compute_rd_reprojection_error_batch_gpu(
            points_3d, R_cam, t_cam, image_points, dep_angles, sar_params
        )
        
        # 返回标量
        return error_range[0].item(), error_azimuth[0].item(), total_error[0].item()
    
    def so3_log_map(self, R):
        """
        SO(3)群的对数映射：R -> so(3)
        
        将旋转矩阵映射到切空间（反对称矩阵）
        
        Args:
            R: 旋转矩阵 (3x3) ∈ SO(3)
        
        Returns:
            omega: 切空间向量 (3,)，对应反对称矩阵
        """
        # 使用scipy的logm函数
        log_R = logm(R)
        
        # 提取反对称矩阵的元素
        # [0 -w3  w2]
        # [w3  0 -w1]
        # [-w2 w1  0]
        omega = np.array([
            log_R[2, 1],  # w1
            log_R[0, 2],  # w2
            log_R[1, 0]   # w3
        ])
        
        return omega
    
    def so3_exp_map(self, omega):
        """
        SO(3)群的指数映射：so(3) -> SO(3)
        
        将切空间向量映射到旋转矩阵
        
        Args:
            omega: 切空间向量 (3,)
        
        Returns:
            R: 旋转矩阵 (3x3) ∈ SO(3)
        """
        # 检查输入是否有效
        if np.any(np.isnan(omega)) or np.any(np.isinf(omega)):
            if self.verbose:
                print(f"  ⚠️ 警告: so3_exp_map输入包含NaN或Inf，返回单位矩阵")
            return np.eye(3)
        
        # 限制omega的大小，避免数值不稳定
        omega_norm = np.linalg.norm(omega)
        if omega_norm > np.pi:
            # 如果omega太大，归一化到pi以内
            omega = omega / omega_norm * np.pi * 0.99
            if self.verbose and not hasattr(self, '_warned_omega_norm'):
                print(f"  ⚠️ 警告: omega范数过大 ({omega_norm:.2f})，已归一化")
                self._warned_omega_norm = True
        
        # 构建反对称矩阵
        omega_skew = np.array([
            [0, -omega[2], omega[1]],
            [omega[2], 0, -omega[0]],
            [-omega[1], omega[0], 0]
        ])
        
        # 指数映射
        try:
            R = expm(omega_skew)
        except Exception as e:
            if self.verbose:
                print(f"  ⚠️ 警告: expm失败 ({e})，返回单位矩阵")
            return np.eye(3)
        
        # 检查R是否有效
        if np.any(np.isnan(R)) or np.any(np.isinf(R)):
            if self.verbose:
                print(f"  ⚠️ 警告: expm结果包含NaN或Inf，返回单位矩阵")
            return np.eye(3)
        
        # 确保在SO(3)上（通过SVD修正）
        try:
            U, _, Vt = np.linalg.svd(R)
            R = U @ Vt
        except np.linalg.LinAlgError as e:
            # SVD失败，使用Rodrigues公式作为备选
            if self.verbose and not hasattr(self, '_warned_svd_failed'):
                print(f"  ⚠️ 警告: SVD失败，使用Rodrigues公式作为备选")
                self._warned_svd_failed = True
            
            # 使用Rodrigues公式：R = I + sin(θ)/θ * K + (1-cos(θ))/θ² * K²
            # 其中K是反对称矩阵，θ = ||omega||
            theta = omega_norm
            if theta < 1e-8:
                return np.eye(3)
            
            K = omega_skew
            R = (np.eye(3) + 
                 np.sin(theta) / theta * K + 
                 (1 - np.cos(theta)) / (theta**2) * K @ K)
            
            # 再次尝试SVD修正
            try:
                U, _, Vt = np.linalg.svd(R)
                R = U @ Vt
            except:
                # 如果还是失败，返回单位矩阵
                if self.verbose:
                    print(f"  ⚠️ 警告: Rodrigues公式后的SVD也失败，返回单位矩阵")
                return np.eye(3)
        
        # 确保行列式为1
        det = np.linalg.det(R)
        if abs(det - 1.0) > 0.1:
            if self.verbose and not hasattr(self, '_warned_det'):
                print(f"  ⚠️ 警告: 旋转矩阵行列式异常 ({det:.6f})，尝试修正")
                self._warned_det = True
        
        if det < 0:
            R[:, 2] = -R[:, 2]
        
        return R
    
    def compute_riemannian_gradient_so3(self, R, residual_func, epsilon=1e-6):
        """
        计算SO(3)群上的Riemannian梯度
        
        使用数值微分方法计算梯度
        
        Args:
            R: 当前旋转矩阵 (3x3)
            residual_func: 残差函数，输入为R，输出为残差向量
            epsilon: 数值微分的步长
        
        Returns:
            grad_R: Riemannian梯度（切空间中的向量）
        """
        # 如果使用GPU，使用GPU版本
        if self.use_gpu:
            return self._compute_riemannian_gradient_so3_gpu(R, residual_func, epsilon)
        
        # CPU版本
        # 计算当前残差
        residual_curr = residual_func(R)
        error_curr = np.sum(residual_curr**2)
        
        # 在切空间中计算梯度
        grad_omega = np.zeros(3)
        
        for i in range(3):
            # 在切空间中沿第i个方向移动
            omega_perturb = np.zeros(3)
            omega_perturb[i] = epsilon
            
            # 指数映射到SO(3)
            R_perturb = self.so3_exp_map(omega_perturb) @ R
            
            # 计算扰动后的残差
            residual_perturb = residual_func(R_perturb)
            error_perturb = np.sum(residual_perturb**2)
            
            # 计算梯度
            grad_omega[i] = (error_perturb - error_curr) / epsilon
        
        return grad_omega
    
    def _compute_riemannian_gradient_so3_gpu(self, R, residual_func, epsilon=1e-6):
        """
        GPU版本的Riemannian梯度计算（并行计算三个方向的梯度）
        """
        device = self.device
        
        # 转换为tensor
        R_t = R if isinstance(R, torch.Tensor) else torch.from_numpy(R).float().to(device)
        
        # 计算当前残差
        R_np = R_t.cpu().numpy() if isinstance(R_t, torch.Tensor) else R
        residual_curr = residual_func(R_np)
        if isinstance(residual_curr, torch.Tensor):
            error_curr = torch.sum(residual_curr**2).item()
        else:
            error_curr = np.sum(np.array(residual_curr)**2)
        
        # 并行计算三个方向的梯度
        grad_omega = torch.zeros(3, device=device)
        omega_perturbs = torch.eye(3, device=device) * epsilon  # (3, 3)
        
        for i in range(3):
            omega_perturb = omega_perturbs[i].cpu().numpy()
            R_perturb_np = self.so3_exp_map(omega_perturb) @ R_np
            
            residual_perturb = residual_func(R_perturb_np)
            if isinstance(residual_perturb, torch.Tensor):
                error_perturb = torch.sum(residual_perturb**2).item()
            else:
                error_perturb = np.sum(np.array(residual_perturb)**2)
            
            grad_omega[i] = (error_perturb - error_curr) / epsilon
        
        return grad_omega.cpu().numpy()
    
    def retract_so3(self, R, omega, step_size):
        """
        SO(3)群上的收缩（Retraction）
        
        将切空间中的点收缩回SO(3)流形
        
        Args:
            R: 当前旋转矩阵 (3x3)
            omega: 切空间中的方向向量 (3,)
            step_size: 步长
        
        Returns:
            R_new: 收缩后的旋转矩阵 (3x3)
        """
        # 在切空间中移动
        omega_new = step_size * omega
        
        # 指数映射回SO(3)
        R_delta = self.so3_exp_map(omega_new)
        R_new = R_delta @ R
        
        return R_new
    
    def vector_transport_so3(self, eta, R_prev, R_curr):
        """
        SO(3)群上的向量传输（Vector Transport）
        
        将前一个切空间中的向量传输到当前切空间
        
        Args:
            eta: 前一个切空间中的向量 (3,)
            R_prev: 前一个旋转矩阵 (3x3)
            R_curr: 当前旋转矩阵 (3x3)
        
        Returns:
            eta_transported: 传输后的向量 (3,)
        """
        # 计算相对旋转
        R_rel = R_curr @ R_prev.T
        
        # 将eta映射到SO(3)，然后通过相对旋转传输
        eta_matrix = self.so3_exp_map(eta)
        eta_transported_matrix = R_rel @ eta_matrix @ R_rel.T
        
        # 映射回切空间
        eta_transported = self.so3_log_map(eta_transported_matrix)
        
        return eta_transported
    
    def compute_beta_polak_ribiere(self, grad_curr, grad_prev, eta_prev):
        """
        计算Polak-Ribière系数
        
        Args:
            grad_curr: 当前梯度 (3,)
            grad_prev: 前一个梯度 (3,)
            eta_prev: 前一个共轭梯度方向 (3,)
        
        Returns:
            beta: Polak-Ribière系数
        """
        # 计算梯度差
        y = grad_curr - grad_prev
        
        # 计算内积
        numerator = np.dot(grad_curr, y)
        denominator = np.dot(grad_prev, grad_prev)
        
        if denominator < 1e-10:
            return 0.0
        
        beta = max(0.0, numerator / denominator)
        return beta
    
    def apply_5dof_constraint(self, R_matrix, t, img_name=None, image_angles=None):
        """
        应用5个自由度约束和高度约束
        
        根据论文，SAR成像结果只依赖于5个DoF，而不是6个。
        论文指出：方位向旋转（绕垂直轴）与平移在方位向的分量是耦合的。
        
        具体实现：
        1. 固定方位向旋转（Z轴旋转）为0或从初始位姿继承
        2. 相应地调整平移向量的方位向分量
        3. 应用高度约束，限制相机位置在合理范围内（符合SAR卫星拍摄位置）
        4. 应用俯视角约束和方位角约束
        
        Args:
            R_matrix: 旋转矩阵 (3x3) - numpy数组
            t: 平移向量 (3,)
            img_name: 图像名称（用于俯视角和方位角约束）
            image_angles: 图像角度信息字典（用于俯视角和方位角约束）
        
        Returns:
            R_constrained: 约束后的旋转矩阵
            t_constrained: 约束后的平移向量
        """
        if not self.use_5dof:
            # 即使不使用5DoF约束，也应用高度约束（同时调整旋转矩阵，确保指向场景中心）
            R_constrained, t_constrained = self._apply_height_constraint_with_rotation(R_matrix, t, img_name, image_angles)
            return R_constrained, t_constrained
        
        # 5个DoF约束的实现：
        # 根据论文，SAR的方位向旋转（绕垂直轴Z）与平移在方位向（X）的分量是耦合的
        # 这意味着：R_z(θ) * t_x 等价于 t_x'（其中t_x'是调整后的平移）
        
        # 提取欧拉角（ZYX顺序：Z=方位向旋转，Y=俯仰，X=横滚）
        rot_obj = Rot.from_matrix(R_matrix)
        euler = rot_obj.as_euler('ZYX', degrees=False)
        
        # 保存原始方位向旋转角度
        azimuth_rotation = euler[0]
        
        # 将方位向旋转设为0（固定这个DoF）
        euler[0] = 0.0
        
        # 重新构建旋转矩阵（只有俯仰和横滚）
        R_constrained = Rot.from_euler('ZYX', euler).as_matrix()
        
        # 调整平移向量：将方位向旋转的影响转移到平移
        # 如果原始旋转是R_z(θ)，新的旋转是I，那么平移需要补偿
        # t_new = R_z(θ) @ t_old（在水平面内旋转）
        R_z_compensation = Rot.from_euler('ZYX', [azimuth_rotation, 0, 0]).as_matrix()
        t_constrained = R_z_compensation @ t
        
        # 🔧 修复：传递img_name和image_angles参数，使俯视角约束和方位角约束能够正确应用
        R_constrained, t_constrained = self._apply_height_constraint_with_rotation(R_constrained, t_constrained, img_name, image_angles)
        
        return R_constrained, t_constrained
    
    def apply_sphere_constraint(self, R_cam, t, target_radius=None):
        """
        应用球面约束，确保相机位置在球面上
        
        对于球面分布模式，相机应该在以原点为中心的球面上。
        这个函数将相机位置投影到目标球面上，同时保持相机指向场景中心。
        
        Args:
            R_cam: 旋转矩阵 (3x3)
            t: 平移向量 (3,)
            target_radius: 目标球面半径（米），None则使用当前半径
        
        Returns:
            R_constrained: 约束后的旋转矩阵
            t_constrained: 约束后的平移向量
        """
        # 计算当前相机位置
        P_radar = -R_cam.T @ t.flatten()
        current_radius = np.linalg.norm(P_radar)
        
        # 如果未指定目标半径，使用当前半径（不调整）
        if target_radius is None:
            return R_cam, t
        
        # 如果当前半径与目标半径接近（误差<5%），不调整
        if abs(current_radius - target_radius) < target_radius * 0.05:
            return R_cam, t
        
        # 将相机位置投影到目标球面上（保持方向，只调整距离）
        P_radar_constrained = P_radar * (target_radius / current_radius)
        
        # 重新计算旋转矩阵，确保相机仍然指向场景中心
        to_scene_center = -P_radar_constrained
        to_scene_center = to_scene_center / np.linalg.norm(to_scene_center)
        
        # 计算方位角（保持原方位，COLMAP坐标系：XZ平面）
        azimuth_rad = np.arctan2(P_radar_constrained[2], P_radar_constrained[0])  # atan2(Z, X)
        
        # 构建新的坐标系（COLMAP约定）
        forward_dir_world = to_scene_center  # Z轴：指向场景中心
        # right_dir_world在XZ平面上（水平面），垂直于方位角方向
        right_dir_world = np.array([-np.sin(azimuth_rad), 0, np.cos(azimuth_rad)])  # XZ平面上的右方向
        right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
        
        # Y轴：下方向
        down_dir_world = np.cross(forward_dir_world, right_dir_world)
        down_dir_world = down_dir_world / np.linalg.norm(down_dir_world)
        
        # 重新计算X轴以确保正交性
        right_dir_world = np.cross(down_dir_world, forward_dir_world)
        right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
        
        # 构建新的旋转矩阵
        R_radar_to_world = np.column_stack([
            right_dir_world,
            down_dir_world,
            forward_dir_world
        ])
        
        # 确保正交性
        U, S, Vt = np.linalg.svd(R_radar_to_world)
        R_radar_to_world = U @ Vt
        
        if np.linalg.det(R_radar_to_world) < 0:
            R_radar_to_world[:, 2] = -R_radar_to_world[:, 2]
        
        # 从世界到雷达坐标系
        R_world_to_radar = R_radar_to_world.T
        
        # 重新计算平移向量
        t_constrained = -R_world_to_radar @ P_radar_constrained
        
        return R_world_to_radar, t_constrained
    
    def _apply_height_constraint_to_translation(self, R_cam, t):
        """
        应用高度约束到平移向量，使相机位置更符合现实SAR卫星拍摄位置
        
        SAR卫星应该在相对固定的高度（camera_height附近），高度变化应该在合理范围内。
        限制相机高度在 camera_height ± 20% 范围内，避免出现几万米的高度差异。
        
        重要：在调整高度的同时，保持相机指向场景中心（原点），确保旋转矩阵与位置一致。
        
        Args:
            R_cam: 旋转矩阵 (3x3)
            t: 平移向量 (3,)
        
        Returns:
            t_constrained: 约束后的平移向量
        """
        # 获取SAR参数
        camera_height = self.sar_params.get('camera_height', 12000.0)
        
        # 计算相机高度约束范围（COLMAP坐标系：Y轴负方向为高度）
        # 🔧 重要修改：球面分布模式下，相机Y坐标（高度）随俯视角变化，需要更宽松的约束
        # 对于球面分布（COLMAP坐标系）：
        #   - 15°: |Y| = R0*cos(15°) = 1280*0.966 = 1236米（Y为负值）
        #   - 30°: |Y| = R0*cos(30°) = 1280*0.866 = 1109米（Y为负值）
        #   - 45°: |Y| = R0*cos(45°) = 1280*0.707 = 905米（Y为负值）
        # Y坐标（高度）范围应该是 [905, 1236]米（绝对值，对于radius_scale=0.0533）
        # 但由于优化可能调整，放宽到 [500, 2000]米
        distribution_mode = self.sar_params.get('camera_distribution_mode', 'sphere')
        
        if distribution_mode == 'sphere':
            # 球面分布：使用基于球面半径的约束
            # 计算球面半径（应该约1280米）
            sphere_radius = np.linalg.norm(-R_cam.T @ t.flatten())
            min_height = max(500.0, sphere_radius * 0.5)  # 最小高度：球面半径的50%
            max_height = sphere_radius * 1.5  # 最大高度：球面半径的150%
        else:
            # 水平圆环分布：使用基于camera_height的约束
            height_tolerance = camera_height * 0.2  # ±20%
            min_height = camera_height - height_tolerance
            max_height = camera_height + height_tolerance
        
        # 计算雷达位置在世界坐标系中的Y坐标（高度）
        # P_radar = -R_cam.T @ t（雷达位置在世界坐标系中）
        # COLMAP坐标系：X=右，Y=下（高度在Y轴负方向），Z=前
        P_radar = -R_cam.T @ t.flatten()
        radar_y = P_radar[1]  # Y坐标对应高度（COLMAP约定：高度在Y轴负方向）
        
        # 如果高度超出范围，调整平移向量，同时保持相机指向场景中心
        # 注意：高度是负值，所以检查时需要取绝对值
        if abs(radar_y) < min_height or abs(radar_y) > max_height or radar_y >= 0:
            # 计算需要调整的高度（Y轴负方向）
            if abs(radar_y) < min_height or radar_y >= 0:
                target_y = -min_height  # 高度在Y轴负方向
            else:
                target_y = -max_height  # 高度在Y轴负方向
            
            # 调整P_radar的Y坐标（高度），但保持X和Z坐标不变
            # 这样相机位置在水平方向上保持不变，只是高度被限制
            P_radar_constrained = P_radar.copy()
            P_radar_constrained[1] = target_y
            
            # 重新计算旋转矩阵，使相机指向场景中心（原点）
            # 场景中心在原点 (0, 0, 0)，雷达位置是 P_radar_constrained
            to_scene_center = -P_radar_constrained  # 从雷达指向场景中心
            to_scene_center = to_scene_center / np.linalg.norm(to_scene_center)
            
            # 计算新的旋转矩阵，使Z轴（前方向）指向场景中心
            # 保持X轴（右方向）在水平面内，沿原方位角方向
            # 从原始旋转矩阵中提取方位角信息
            forward_dir_world = to_scene_center
            
            # 计算水平方向（保持原方位角方向，COLMAP坐标系：XZ平面）
            # 从原始P_radar计算方位角
            azimuth_rad = np.arctan2(P_radar[2], P_radar[0])  # atan2(Z, X)
            # right_dir_world在XZ平面上（水平面），垂直于方位角方向
            right_dir_world = np.array([-np.sin(azimuth_rad), 0, np.cos(azimuth_rad)])  # XZ平面上的右方向
            right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
            
            # 计算Y轴（下方向）
            down_dir_world = np.cross(forward_dir_world, right_dir_world)
            down_dir_world = down_dir_world / np.linalg.norm(down_dir_world)
            
            # 确保Y轴向下
            if down_dir_world[2] > 0:
                down_dir_world = -down_dir_world
            
            # 重新计算X轴以确保正交性
            right_dir_world = np.cross(down_dir_world, forward_dir_world)
            right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
            
            # 构建新的旋转矩阵（从雷达坐标系到世界坐标系）
            R_radar_to_world = np.column_stack([
                right_dir_world,    # X轴（右）
                down_dir_world,     # Y轴（下）
                forward_dir_world   # Z轴（前，指向场景中心）
            ])
            
            # 确保旋转矩阵是正交矩阵
            U, S, Vt = np.linalg.svd(R_radar_to_world)
            R_radar_to_world = U @ Vt
            
            # 确保行列式为1
            if np.linalg.det(R_radar_to_world) < 0:
                R_radar_to_world[:, 2] = -R_radar_to_world[:, 2]
            
            # 从世界坐标系到雷达坐标系的旋转
            R_world_to_radar = R_radar_to_world.T
            
            # 重新计算平移向量：t = -R @ P_radar
            t_constrained = -R_world_to_radar @ P_radar_constrained
            
            # 注意：这里我们只返回调整后的t，但R也需要更新
            # 由于在优化过程中R是优化变量，我们需要在调用处同时更新R
            # 为了保持接口一致性，我们暂时只返回t，但会在apply_5dof_constraint中处理R的更新
            
            return t_constrained
        else:
            return t
    
    def _apply_height_constraint_with_rotation(self, R_cam, t, img_name=None, image_angles=None):
        """
        应用约束，可选地包括高度约束和方位角约束
        
        🔧 重要修改：
        1. 高度约束：可选（默认禁用），确保相机在上半球
        2. 方位角约束：可选（默认启用），确保相机方位角与图像一致
        
        Args:
            R_cam: 旋转矩阵 (3x3)
            t: 平移向量 (3,)
            img_name: 图像名称（用于方位角约束）
            image_angles: 图像角度信息字典
        
        Returns:
            R_constrained: 约束后的旋转矩阵
            t_constrained: 约束后的平移向量
        """
        # 固定文件名俯仰/方位模式：位姿由 _optimize_poses_height_only 统一生成，不在此做软约束
        if self.sar_params.get('ba_fix_angles_optimize_height_only'):
            return R_cam, t

        # 获取约束配置（必须从config.py中设置，不提供默认值）
        enable_height_constraint = self.sar_params.get('enable_height_constraint')
        if enable_height_constraint is None:
            raise ValueError("enable_height_constraint 必须在config.py中设置（--sfm_enable_height_constraint）")
        enable_azimuth_constraint = self.sar_params.get('enable_azimuth_constraint')
        if enable_azimuth_constraint is None:
            raise ValueError("enable_azimuth_constraint 必须在config.py中设置（--sfm_enable_azimuth_constraint）")
        azimuth_tolerance = self.sar_params.get('azimuth_tolerance')
        if azimuth_tolerance is None:
            raise ValueError("azimuth_tolerance 必须在config.py中设置（--sfm_azimuth_tolerance）")
        
        # 计算当前相机位置
        P_radar = -R_cam.T @ t.flatten()
        
        # 🔧 俯视角约束（限制俯视角在合理范围内，必须从config.py中设置）
        enable_depression_constraint = self.sar_params.get('enable_depression_constraint')
        if enable_depression_constraint is None:
            raise ValueError("enable_depression_constraint 必须在config.py中设置（--sfm_enable_depression_constraint）")
        depression_min = self.sar_params.get('depression_min')
        if depression_min is None:
            raise ValueError("depression_min 必须在config.py中设置（--sfm_depression_min）")
        depression_max = self.sar_params.get('depression_max')
        if depression_max is None:
            raise ValueError("depression_max 必须在config.py中设置（--sfm_depression_max）")
        
        if enable_depression_constraint:
            # 计算当前俯视角（COLMAP坐标系：基于Y坐标）
            # 在球面分布模式下，相机位置为：
            #   x = R * sin(depression) * cos(azimuth)
            #   y = -R * cos(depression)  # 高度在Y轴负方向
            #   z = R * sin(depression) * sin(azimuth)
            # 因此，俯视角 depression = arcsin(xz_dist / R) = arccos(|Y| / R)
            # 或者：depression = arctan2(xz_dist, |Y|)
            sphere_radius = np.linalg.norm(P_radar)
            xz_dist = np.sqrt(P_radar[0]**2 + P_radar[2]**2)  # XZ平面距离（水平距离）
            # 使用 arcsin 计算俯视角：depression = arcsin(xz_dist / R)
            if sphere_radius > 1e-6:
                current_depression_rad = np.arcsin(xz_dist / sphere_radius)
            else:
                # 如果半径太小，使用 arctan2 作为备选
                current_depression_rad = np.arctan2(xz_dist, abs(P_radar[1]))
            current_depression = np.rad2deg(current_depression_rad)
            
            # 如果俯视角超出范围，调整相机位置
            if current_depression < depression_min or current_depression > depression_max:
                # 计算球面半径
                sphere_radius = np.linalg.norm(P_radar)
                
                # 计算目标俯视角（限制在范围内）
                if current_depression < depression_min:
                    target_depression = depression_min
                else:
                    target_depression = depression_max
                
                target_depression_rad = np.deg2rad(target_depression)
                
                # 保持方位角不变，只调整俯视角
                azimuth_rad = np.arctan2(P_radar[2], P_radar[0])
                
                # 重新计算相机位置（COLMAP坐标系：XZ平面是水平面，Y是高度）
                # 球面分布：x = R * sin(depression) * cos(azimuth)
                #          y = -R * cos(depression)  # 高度在Y轴负方向
                #          z = R * sin(depression) * sin(azimuth)
                P_radar = np.array([
                    sphere_radius * np.sin(target_depression_rad) * np.cos(azimuth_rad),
                    -sphere_radius * np.cos(target_depression_rad),  # Y坐标：高度在Y轴负方向
                    sphere_radius * np.sin(target_depression_rad) * np.sin(azimuth_rad)
                ])
                
                # 每个图像只打印一次警告（避免在优化迭代中重复打印）
                if self.verbose and img_name not in getattr(self, '_depression_warned', {}):
                    if not hasattr(self, '_depression_warned'):
                        self._depression_warned = {}
                    print(f"  🔧 俯视角约束: {img_name} 当前={current_depression:.1f}° 调整到={target_depression:.1f}°")
                    self._depression_warned[img_name] = True
        
        # 🔧 方位角约束（限制优化后的方位角在原始方位角的容差范围内）
        if enable_azimuth_constraint and img_name and image_angles:
            angles = image_angles.get(img_name, {})
            original_azimuth = angles.get('azimuth', None)
            
            if original_azimuth is not None:
                # 计算当前方位角（COLMAP坐标系：XZ平面是水平面）
                # COLMAP约定：X轴=右，Y轴=下（高度），Z轴=前
                # 方位角在XZ平面上：azimuth = atan2(Z, X)
                current_azimuth = np.rad2deg(np.arctan2(P_radar[2], P_radar[0]))
                
                # 🔧 诊断：检查是否存在180度偏差（可能是坐标系定义不一致导致的）
                # 如果偏差接近180度，可能是MSTAR数据集的方位角定义与COLMAP坐标系不一致
                raw_diff = current_azimuth - original_azimuth
                # 将偏差归一化到 [-180, 180] 范围
                azimuth_diff = raw_diff
                while azimuth_diff > 180:
                    azimuth_diff -= 360
                while azimuth_diff < -180:
                    azimuth_diff += 360
                
                # 🔧 关键修复：如果偏差接近±180度，自动应用180度偏移修正
                # 原因：MSTAR数据集的方位角定义可能与COLMAP坐标系相差180度
                # 例如：MSTAR的116°可能对应COLMAP的296°（116°+180°）
                if abs(abs(azimuth_diff) - 180) < 10.0:  # 偏差在170-190度范围内
                    # 检查：如果使用 original_azimuth + 180 作为目标，偏差是否更小
                    alt_original = (original_azimuth + 180) % 360
                    alt_diff = current_azimuth - alt_original
                    while alt_diff > 180:
                        alt_diff -= 360
                    while alt_diff < -180:
                        alt_diff += 360
                    
                    if abs(alt_diff) < abs(azimuth_diff):
                        # 使用 alternative 定义偏差更小，说明存在180度偏移
                        # 自动应用180度偏移修正
                        original_azimuth = alt_original
                        azimuth_diff = alt_diff
                        
                        if self.verbose and img_name not in getattr(self, '_azimuth_180deg_corrected', {}):
                            if not hasattr(self, '_azimuth_180deg_corrected'):
                                self._azimuth_180deg_corrected = {}
                            print(f"  🔧 方位角180°偏移修正: {img_name} 原始={angles.get('azimuth', None):.1f}° -> 修正为={original_azimuth:.1f}° (当前={current_azimuth:.1f}°, 偏差={abs(azimuth_diff):.1f}°)")
                            self._azimuth_180deg_corrected[img_name] = True
                
                # 如果方位角偏差超过容差，限制在容差范围内（而不是强制校正到原始值）
                if abs(azimuth_diff) > azimuth_tolerance:
                    # 计算限制后的方位角（在原始方位角的±容差范围内）
                    if azimuth_diff > 0:
                        # 当前方位角大于原始方位角，限制到原始方位角+容差
                        constrained_azimuth = original_azimuth + azimuth_tolerance
                    else:
                        # 当前方位角小于原始方位角，限制到原始方位角-容差
                        constrained_azimuth = original_azimuth - azimuth_tolerance
                    
                    # 归一化到 [0, 360) 范围
                    while constrained_azimuth < 0:
                        constrained_azimuth += 360
                    while constrained_azimuth >= 360:
                        constrained_azimuth -= 360
                    
                    # 每个图像只打印一次警告（避免在优化迭代中重复打印）
                    if self.verbose and img_name not in getattr(self, '_azimuth_warned', {}):
                        if not hasattr(self, '_azimuth_warned'):
                            self._azimuth_warned = {}
                        print(f"  🔧 方位角约束: {img_name} 当前={current_azimuth:.1f}° 原始={original_azimuth:.1f}° 偏差={abs(azimuth_diff):.1f}° 限制到={constrained_azimuth:.1f}°")
                        self._azimuth_warned[img_name] = True
                    
                    # 保持球面半径和俯视角，只限制方位角
                    sphere_radius = np.linalg.norm(P_radar)
                    constrained_azimuth_rad = np.deg2rad(constrained_azimuth)
                    
                    # 计算当前俯视角（保持不变，COLMAP坐标系：基于Y坐标）
                    # 在球面分布模式下，相机位置为：
                    #   x = R * sin(depression) * cos(azimuth)
                    #   y = -R * cos(depression)  # 高度在Y轴负方向
                    #   z = R * sin(depression) * sin(azimuth)
                    # 因此，俯视角 depression = arcsin(xz_dist / R) = arccos(|Y| / R)
                    xz_dist = np.sqrt(P_radar[0]**2 + P_radar[2]**2)  # XZ平面距离（水平距离）
                    if sphere_radius > 1e-6:
                        current_depression_rad = np.arcsin(xz_dist / sphere_radius)  # 俯视角：arcsin(xz_dist / R)
                    else:
                        # 如果半径太小，使用 arctan2 作为备选
                        current_depression_rad = np.arctan2(xz_dist, abs(P_radar[1]))  # 俯视角：arctan2(xz_dist, |Y|)
                    
                    # 重新计算相机位置（COLMAP坐标系：XZ平面是水平面，Y是高度）
                    # 球面坐标：x = R * sin(depression) * cos(azimuth)
                    #           y = -R * cos(depression)  # 高度在Y轴负方向
                    #           z = R * sin(depression) * sin(azimuth)
                    P_radar_new = np.array([
                        sphere_radius * np.sin(current_depression_rad) * np.cos(constrained_azimuth_rad),
                        -sphere_radius * np.cos(current_depression_rad),  # Y坐标：高度在Y轴负方向
                        sphere_radius * np.sin(current_depression_rad) * np.sin(constrained_azimuth_rad)
                    ])
                    P_radar = P_radar_new
        
        # 🔧 高度约束（默认禁用）
        if not enable_height_constraint:
            # 不应用高度约束，只确保相机指向场景中心
            # 重新计算旋转矩阵
            to_scene_center = -P_radar / np.linalg.norm(P_radar)
            # COLMAP坐标系：方位角在XZ平面上
            azimuth_rad = np.arctan2(P_radar[2], P_radar[0])  # atan2(Z, X)
            
            # right_dir_world在XZ平面上（水平面），垂直于方位角方向
            right_dir_world = np.array([-np.sin(azimuth_rad), 0, np.cos(azimuth_rad)])  # XZ平面上的右方向
            right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
            
            down_dir_world = np.cross(to_scene_center, right_dir_world)
            down_dir_world = down_dir_world / np.linalg.norm(down_dir_world)
            
            right_dir_world = np.cross(down_dir_world, to_scene_center)
            right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
            
            R_radar_to_world = np.column_stack([right_dir_world, down_dir_world, to_scene_center])
            U, S, Vt = np.linalg.svd(R_radar_to_world)
            R_radar_to_world = U @ Vt
            if np.linalg.det(R_radar_to_world) < 0:
                R_radar_to_world[:, 2] = -R_radar_to_world[:, 2]
            
            R_world_to_radar = R_radar_to_world.T
            t_constrained = -R_world_to_radar @ P_radar
            return R_world_to_radar, t_constrained
        
        # 以下是启用高度约束时的逻辑
        distribution_mode = self.sar_params.get('camera_distribution_mode', 'sphere')
        
        # 🔧 球面分布模式：确保相机在场景上方（COLMAP坐标系：Y轴负方向为高度）
        if distribution_mode == 'sphere':
            # 计算球面半径
            sphere_radius = np.linalg.norm(P_radar)
            # 使用 min_z_ratio 参数（默认0.1，即|Y| >= 球面半径的10%，高度在Y轴负方向）
            min_z_ratio = self.sar_params.get('min_z_ratio', 0.1)
            min_height = sphere_radius * min_z_ratio  # 最小高度
            
            # COLMAP约定：高度在Y轴负方向，所以Y应该是负值
            # 检查：|Y| >= min_height（即Y <= -min_height）
            if abs(P_radar[1]) >= min_height and P_radar[1] < 0:
                return R_cam, t  # Y坐标合理（高度足够），不调整
            
            # Y坐标不合理（高度不够或为正值），需要调整
            # 策略：保持相机在球面上，但将Y坐标调整到合理范围（Y轴负方向）
            sphere_radius = np.linalg.norm(P_radar)
            
            # 如果Y为正或高度不够，调整到合理范围
            if P_radar[1] >= 0 or abs(P_radar[1]) < min_height:
                # 🔧 重要：保持俯视角不变，只调整Y坐标（高度）
                # 首先计算当前的俯视角和方位角
                xz_dist = np.sqrt(P_radar[0]**2 + P_radar[2]**2)  # XZ平面距离
                if sphere_radius > 1e-6:
                    current_depression_rad = np.arcsin(xz_dist / sphere_radius)  # 当前俯视角
                else:
                    current_depression_rad = np.arctan2(xz_dist, abs(P_radar[1]))
                
                azimuth_rad = np.arctan2(P_radar[2], P_radar[0])  # 保持方位角不变
                
                # 确保俯视角在合理范围内（避免俯视角过大导致高度不足）
                # 如果当前俯视角太大，调整到最大允许的俯视角
                max_depression_rad = np.arccos(min_height / sphere_radius) if sphere_radius > min_height else np.deg2rad(45)
                if current_depression_rad > max_depression_rad:
                    current_depression_rad = max_depression_rad
                
                # 保持俯视角和方位角不变，重新计算相机位置（确保在球面上）
                P_radar_constrained = np.array([
                    sphere_radius * np.sin(current_depression_rad) * np.cos(azimuth_rad),
                    -sphere_radius * np.cos(current_depression_rad),  # Y坐标：高度在Y轴负方向
                    sphere_radius * np.sin(current_depression_rad) * np.sin(azimuth_rad)
                ])
            else:
                # Y坐标已经合理，不需要调整
                P_radar_constrained = P_radar.copy()
            
            # 重新计算旋转矩阵，确保相机指向场景中心
            to_scene_center = -P_radar_constrained
            to_scene_center = to_scene_center / np.linalg.norm(to_scene_center)
            
            # 计算方位角（保持原方位，COLMAP坐标系：XZ平面）
            azimuth_rad = np.arctan2(P_radar_constrained[2], P_radar_constrained[0])  # atan2(Z, X)
            
            # 构建新的坐标系
            forward_dir_world = to_scene_center
            # 🔧 修复：right_dir_world应该在XZ平面上，使用[cos(azimuth), 0, sin(azimuth)]
            right_dir_world = np.array([np.cos(azimuth_rad), 0, np.sin(azimuth_rad)])  # XZ平面上的单位向量
            right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
            
            down_dir_world = np.cross(forward_dir_world, right_dir_world)
            down_dir_world = down_dir_world / np.linalg.norm(down_dir_world)
            
            right_dir_world = np.cross(down_dir_world, forward_dir_world)
            right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
            
            R_radar_to_world = np.column_stack([right_dir_world, down_dir_world, forward_dir_world])
            
            # 确保正交性
            U, S, Vt = np.linalg.svd(R_radar_to_world)
            R_radar_to_world = U @ Vt
            
            if np.linalg.det(R_radar_to_world) < 0:
                R_radar_to_world[:, 2] = -R_radar_to_world[:, 2]
            
            R_world_to_radar = R_radar_to_world.T
            t_constrained = -R_world_to_radar @ P_radar_constrained
            
            return R_world_to_radar, t_constrained
        
        # 以下是水平圆环分布模式的高度约束（保留向后兼容）
        camera_height = self.sar_params.get('camera_height', 12000.0)
        
        # 计算相机高度约束范围
        height_tolerance = camera_height * 0.2  # ±20%
        min_height = camera_height - height_tolerance
        max_height = camera_height + height_tolerance
        
        # 计算雷达位置（COLMAP坐标系：Y轴负方向为高度）
        P_radar = -R_cam.T @ t.flatten()
        radar_y = P_radar[1]  # Y坐标对应高度（COLMAP约定：高度在Y轴负方向）
        
        # 如果高度在合理范围内，不需要调整
        # 注意：高度是负值，所以检查时需要取绝对值
        if min_height <= abs(radar_y) <= max_height and radar_y < 0:
            return R_cam, t
        
        # 调整高度（Y轴负方向）
        if abs(radar_y) < min_height or radar_y >= 0:
            target_y = -min_height  # 高度在Y轴负方向
        else:
            target_y = -max_height  # 高度在Y轴负方向
        
        # 调整P_radar的Y坐标（高度）
        P_radar_constrained = P_radar.copy()
        P_radar_constrained[1] = target_y
        
        # 重新计算旋转矩阵，使相机指向场景中心
        to_scene_center = -P_radar_constrained
        to_scene_center = to_scene_center / np.linalg.norm(to_scene_center)
        
        # 计算方位角（保持水平方向，COLMAP坐标系：XZ平面）
        # 注意：使用调整后的P_radar_constrained计算方位角，而不是原始的P_radar
        # 这样可以保持方位角与调整后的位置一致
        # 🔧 修复：方位角应该在XZ平面上，使用Z和X坐标，而不是Y和X
        azimuth_rad = np.arctan2(P_radar_constrained[2], P_radar_constrained[0])  # atan2(Z, X)
        right_dir_world = np.array([np.cos(azimuth_rad), 0, np.sin(azimuth_rad)])  # XZ平面上的单位向量
        right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
        
        # 计算Y轴（下方向）
        forward_dir_world = to_scene_center
        down_dir_world = np.cross(forward_dir_world, right_dir_world)
        down_dir_world = down_dir_world / np.linalg.norm(down_dir_world)
        
        if down_dir_world[2] > 0:
            down_dir_world = -down_dir_world
        
        # 重新计算X轴以确保正交性
        right_dir_world = np.cross(down_dir_world, forward_dir_world)
        right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
        
        # 构建新的旋转矩阵
        R_radar_to_world = np.column_stack([
            right_dir_world,
            down_dir_world,
            forward_dir_world
        ])
        
        # 确保旋转矩阵是正交矩阵
        U, S, Vt = np.linalg.svd(R_radar_to_world)
        R_radar_to_world = U @ Vt
        
        if np.linalg.det(R_radar_to_world) < 0:
            R_radar_to_world[:, 2] = -R_radar_to_world[:, 2]
        
        # 从世界坐标系到雷达坐标系的旋转
        R_world_to_radar = R_radar_to_world.T
        
        # 重新计算平移向量
        t_constrained = -R_world_to_radar @ P_radar_constrained
        
        return R_world_to_radar, t_constrained
    
    def _apply_position_constraint(self, R_cam, t, initial_position, img_name):
        """
        应用位置约束，限制相机位置不能偏离初始位置太远
        
        Args:
            R_cam: 旋转矩阵 (3x3)
            t: 平移向量 (3,)
            initial_position: 初始相机位置 (3,)
            img_name: 图像名称（用于诊断）
        
        Returns:
            R_constrained: 约束后的旋转矩阵
            t_constrained: 约束后的平移向量
        """
        # 获取位置约束配置（必须从config.py中设置）
        enable_position_constraint = self.sar_params.get('enable_position_constraint')
        if enable_position_constraint is None:
            raise ValueError("enable_position_constraint 必须在config.py中设置（--sfm_enable_position_constraint）")
        position_tolerance_ratio = self.sar_params.get('position_tolerance_ratio')
        if position_tolerance_ratio is None:
            raise ValueError("position_tolerance_ratio 必须在config.py中设置（--sfm_position_tolerance_ratio）")
        
        if not enable_position_constraint or initial_position is None:
            return R_cam, t
        
        # 计算当前相机位置
        P_radar = -R_cam.T @ t.flatten()
        
        # 计算位置偏离
        position_diff = P_radar - initial_position
        position_diff_norm = np.linalg.norm(position_diff)
        initial_norm = np.linalg.norm(initial_position)
        
        # 计算最大允许偏离距离
        max_deviation = initial_norm * position_tolerance_ratio
        
        # 如果偏离超过容差，将位置拉回
        if position_diff_norm > max_deviation:
            # 计算拉回后的位置（沿初始位置方向）
            direction_to_initial = position_diff / position_diff_norm
            P_radar_constrained = initial_position + direction_to_initial * max_deviation
            
            # 重新计算旋转矩阵，使相机指向场景中心
            to_scene_center = -P_radar_constrained
            to_scene_center = to_scene_center / np.linalg.norm(to_scene_center)
            
            # 计算方位角（COLMAP坐标系：XZ平面）
            azimuth_rad = np.arctan2(P_radar_constrained[2], P_radar_constrained[0])
            
            # 构建新的坐标系
            forward_dir_world = to_scene_center
            right_dir_world = np.array([-np.sin(azimuth_rad), 0, np.cos(azimuth_rad)])
            right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
            
            down_dir_world = np.cross(forward_dir_world, right_dir_world)
            down_dir_world = down_dir_world / np.linalg.norm(down_dir_world)
            
            right_dir_world = np.cross(down_dir_world, forward_dir_world)
            right_dir_world = right_dir_world / np.linalg.norm(right_dir_world)
            
            R_radar_to_world = np.column_stack([right_dir_world, down_dir_world, forward_dir_world])
            
            # 确保正交性
            U, S, Vt = np.linalg.svd(R_radar_to_world)
            R_radar_to_world = U @ Vt
            
            if np.linalg.det(R_radar_to_world) < 0:
                R_radar_to_world[:, 2] = -R_radar_to_world[:, 2]
            
            R_world_to_radar = R_radar_to_world.T
            t_constrained = -R_world_to_radar @ P_radar_constrained
            
            # 每个图像只打印一次警告（避免在优化迭代中重复打印）
            if self.verbose and img_name not in getattr(self, '_position_warned', {}):
                if not hasattr(self, '_position_warned'):
                    self._position_warned = {}
                print(f"  🔧 位置约束: {img_name} 偏离初始位置 {position_diff_norm:.2f}米 (容差: {max_deviation:.2f}米)")
                self._position_warned[img_name] = True
            
            return R_world_to_radar, t_constrained
        
        return R_cam, t
    
    def solve(self, keypoints_dict, matches_dict, initial_poses=None,
              image_angles=None):
        """
        求解SAR SfM问题
        
        使用SO-RCG算法在SO(3)群上优化旋转矩阵
        
        Args:
            keypoints_dict: 字典，key为图像名称，value为关键点列表
            matches_dict: 字典，key为(图像1名称, 图像2名称)，value为匹配列表
            initial_poses: 可选的初始位姿字典
            image_angles: 字典，key为图像名称，value为{'depression': deg, 'azimuth': deg}
        
        Returns:
            result: 字典，包含：
                - poses: 优化后的位姿字典
                - points_3d: 3D点云 (Nx3)
                - error_history: 误差历史
        """
        if self.verbose:
            print("="*60)
            print("开始SO-RCG SAR SfM求解...")
            print("="*60)

        self._height_only_poses_cached = None
        height_only = bool(self.sar_params.get('ba_fix_angles_optimize_height_only', False))
        if height_only:
            cap = int(self.sar_params.get('sorc_height_only_max_iterations', 20))
            if self.max_iterations > cap:
                if self.verbose:
                    print(
                        f"ℹ️ 固定俯仰/方位模式：外层迭代 {self.max_iterations} → {cap} "
                        f"（高度第 1 轮收敛后不再重复一维搜索；"
                        f"可用 --sfm_sorc_height_only_max_iterations 调整）"
                    )
                self.max_iterations = cap
            if self.use_gpu:
                if self.verbose:
                    print(
                        "ℹ️ SO-RCG GPU：总误差按图像批处理；"
                        "固定俯仰/方位时 3D 点优化仍走 CPU 多线程（GPU 逐点数值梯度更慢）"
                    )
            elif self.verbose:
                print(
                    "ℹ️ 固定角度模式较慢时请加 --sfm_sorc_use_gpu（CUDA 批处理点云/误差）"
                )
        
        # 初始化诊断计数器
        self._diagnostic_count = 0
        self._warned_R0 = False
        
        # 构建点跟踪（track）
        point_tracks = self._build_point_tracks(keypoints_dict, matches_dict)
        
        if len(point_tracks) == 0:
            raise ValueError("没有找到足够的点跟踪，无法进行求解")
        
        if self.verbose:
            print(f"构建了 {len(point_tracks)} 个3D点的track")
        
        # 初始化位姿
        image_names = sorted(set([img for track in point_tracks.values() 
                                  for img, _ in track]))
        
        # 确认使用的是循环俯视角模式生成的俯视角
        if self.verbose and image_angles:
            sample_depressions = []
            for img_name in image_names[:5]:  # 检查前5个图像
                if img_name in image_angles:
                    dep = image_angles[img_name].get('depression', 0)
                    sample_depressions.append((img_name, dep))
            if sample_depressions:
                print(f"\n  📊 使用的俯视角信息（前5个图像）:")
                for img_name, dep in sample_depressions:
                    print(f"    - {img_name}: {dep}°")
                # 检查俯视角是否多样化（循环模式的特征）
                dep_values = [dep for _, dep in sample_depressions]
                unique_deps = sorted(set(dep_values))
                if len(unique_deps) > 1:
                    print(f"  ✅ 检测到多样化的俯视角 ({unique_deps})，确认使用循环俯视角模式")
                else:
                    print(f"  ℹ️ 所有图像使用相同的俯视角 ({unique_deps[0]}°)，未使用循环俯视角模式")
                    print(f"  💡 提示: 如需启用循环俯视角模式，请在命令行中添加 --enable_cyclic_depression")
        
        poses = self._initialize_poses(image_names, initial_poses, image_angles)
        
        # 保存初始位置（用于位置约束）
        self._initial_positions = {}
        for img_name, pose in poses.items():
            R_init = pose['R']
            t_init = pose['t']
            P_radar_init = -R_init.T @ t_init.flatten()
            self._initial_positions[img_name] = P_radar_init.copy()
        
        # 初始化警告标志字典（每个图像一个标志，避免重复打印）
        self._azimuth_warned = {}
        self._depression_warned = {}
        self._position_warned = {}
        
        # 初始化3D点（使用三角化）
        # 根据论文，使用基于RD模型的三角化，而不是透视投影
        # 注意：三角化将使用image_angles中的俯视角（如果启用循环模式，则为循环俯视角）
        points_3d = self._initialize_points_3d(point_tracks, poses, 
                                               keypoints_dict, image_angles)
        
        # 验证初始点云的合理性
        if len(points_3d) > 0:
            # 检查点云是否集中在原点附近（SAR场景通常以原点为中心）
            points_centered = points_3d - np.mean(points_3d, axis=0)
            max_extent = np.max(np.abs(points_centered))
            
            # 获取SAR参数用于诊断
            camera_height = self.sar_params.get('camera_height', 1365.0)
            fs = self.sar_params.get('fs', 1.1 * 240e6)
            prf = self.sar_params.get('prf', 2200)
            Va = self.sar_params.get('Va', 755)
            C = self.sar_params.get('C', 3e8)
            range_pixel_size = C / (2 * fs)
            azimuth_pixel_size = Va / prf
            
            if self.verbose:
                print(f"\n初始点云统计:")
                print(f"  - 点数: {len(points_3d)}")
                print(f"  - 中心: {np.mean(points_3d, axis=0)}")
                print(f"  - 最大扩展: {max_extent:.2f} 米")
                print(f"  - 坐标范围: X[{points_3d[:, 0].min():.2f}, {points_3d[:, 0].max():.2f}], "
                      f"Y[{points_3d[:, 1].min():.2f}, {points_3d[:, 1].max():.2f}], "
                      f"Z[{points_3d[:, 2].min():.2f}, {points_3d[:, 2].max():.2f}]")
            
            # 如果点云过于分散或集中在Z方向，可能是初始化问题
            z_std = np.std(points_3d[:, 2])
            xy_std = np.std(np.sqrt(points_3d[:, 0]**2 + points_3d[:, 1]**2))
            
            if self.verbose:
                print(f"  - Z方向标准差: {z_std:.2f} 米")
                print(f"  - XY方向标准差: {xy_std:.2f} 米")
            
            # 检查点云尺度是否合理（相对于SAR参数）
            point_norms = np.linalg.norm(points_3d, axis=1)
            median_norm = np.median(point_norms)
            max_norm = np.max(point_norms)
            
            if self.verbose:
                print(f"  - 点云范数: 中位数={median_norm:.2f}米, 最大值={max_norm:.2f}米")
                print(f"  - SAR参数参考:")
                print(f"    * camera_height: {camera_height:.1f}米")
                print(f"    * range_pixel_size: {range_pixel_size:.6f}米/像素")
                print(f"    * azimuth_pixel_size: {azimuth_pixel_size:.6f}米/像素")
            
            # 检查点云尺度是否异常
            # SAR场景中，3D点应该在几百到几千米范围内
            if median_norm > 10000:
                if self.verbose:
                    print(f"\n  ⚠️ 警告: 点云尺度异常大（中位数范数={median_norm:.2f}米 > 10000米）")
                    print(f"     可能原因:")
                    print(f"       1. 坐标系单位不匹配（可能是像素而非米）")
                    print(f"       2. SAR参数不匹配（camera_height={camera_height}米可能不正确）")
                    print(f"       3. 三角化时使用的俯视角与SAR参数不匹配")
                    print(f"     建议:")
                    print(f"       1. 检查SAR参数是否与实际数据匹配")
                    print(f"       2. 检查3D点坐标是否应该归一化")
                    print(f"       3. 检查循环俯视角范围是否合理（当前: {getattr(self, '_cyclic_start', 'N/A')}°-{getattr(self, '_cyclic_end', 'N/A')}°）")
            
            # 如果Z方向扩展远大于XY方向，可能是"塔状"畸变的早期信号
            if z_std > 2 * xy_std and z_std > 10:
                if self.verbose:
                    print(f"  ⚠️ 警告: 检测到初始点云可能存在问题（Z方向扩展过大）")
        
        # 交替优化：优化位姿和3D点
        # 根据论文，需要先进行几次迭代来稳定初始估计
        prev_error = float('inf')
        best_error = float('inf')
        best_poses = None
        best_points_3d = None
        
        for iteration in range(self.max_iterations):
            if self.verbose:
                print(f"\n迭代 {iteration + 1}/{self.max_iterations}")
            
            # 在每次迭代开始时重置警告标志（每个迭代周期每个图像只打印一次警告）
            self._azimuth_warned = {}
            self._depression_warned = {}
            self._position_warned = {}
            # 设置当前迭代次数（用于点云高度约束的输出控制）
            self._point_height_constraint_iteration_count = iteration
            
            # 改进的优化策略：使用更小的步长和更保守的优化
            # 问题：交替优化位姿和3D点可能导致不协调，误差增加
            # 解决方案：
            # 1. 使用更小的优化步长（通过_step_size_scale控制）
            # 2. 如果误差持续增加，跳过优化（保持当前状态）
            # 3. 使用更保守的优化策略：只优化误差改善的部分
            
            # 检查是否应该跳过优化（如果误差持续增加）
            should_skip_optimization = False
            if iteration > 3 and hasattr(self, '_error_increase_count'):
                if self._error_increase_count > 5:
                    # 如果连续多次误差增加，跳过优化，保持当前状态
                    should_skip_optimization = True
                    if self.verbose:
                        print(f"  ⚠️ 连续{self._error_increase_count}次误差增加，跳过本次优化，保持当前状态")
            
            if not should_skip_optimization:
                # 优化位姿（使用SO-RCG）
                poses = self._optimize_poses_sorc(poses, points_3d, point_tracks,
                                                 keypoints_dict, image_angles)
                
                # 「仅优化共享高度」模式：位姿由文件名/数据给定俯仰+方位与共享 camera_height 完全决定，
                # 不得再施加方位/俯仰/位置约束，也不得用位姿反算覆盖 image_angles。
                height_only = self.sar_params.get('ba_fix_angles_optimize_height_only', False)
                from .geometry import compute_sar_camera_pose

                if height_only:
                    if getattr(self, '_height_only_poses_cached', None) is None or iteration == 0:
                        for img_name in poses.keys():
                            R_cam = poses[img_name]['R']
                            t_cam = poses[img_name]['t']
                            if not image_angles or img_name not in image_angles:
                                continue
                            dep_actual_deg = float(image_angles[img_name].get('depression', 31.57))
                            azi_actual_deg = float(image_angles[img_name].get('azimuth', 0.0))
                            P_radar = -R_cam.T @ t_cam.flatten()
                            R0_actual = np.linalg.norm(P_radar)
                            if R0_actual <= 1e-6 or np.any(np.isnan(P_radar)) or np.any(np.isinf(P_radar)):
                                continue
                            if hasattr(self, 'image_sizes') and img_name in self.image_sizes:
                                width, height = self.image_sizes[img_name]
                            else:
                                width = self.sar_params.get('Na', 128)
                                height = self.sar_params.get('Nr', 128)
                            temp_params = self.sar_params.copy()
                            temp_params['Na'] = width
                            temp_params['Nr'] = height
                            temp_params['depression_angle'] = dep_actual_deg
                            temp_params['actual_R0'] = R0_actual
                            temp_params['use_actual_R0_for_focal'] = True
                            if hasattr(self, 'unified_cx') and hasattr(self, 'unified_cy'):
                                temp_params['unified_cx'] = self.unified_cx
                                temp_params['unified_cy'] = self.unified_cy
                            try:
                                _, _, K_new = compute_sar_camera_pose(dep_actual_deg, azi_actual_deg, temp_params)
                                if hasattr(self, 'image_K'):
                                    self.image_K[img_name] = K_new
                            except Exception as e:
                                if self.verbose:
                                    print(f"    ⚠️ {img_name} 重新计算K矩阵失败: {e}")
                    elif self.verbose and iteration == 1:
                        print("  ℹ️ 固定高度位姿已缓存，跳过后续迭代的逐图 K 重算")
                else:
                    # 🔧 修复：在优化位姿后，再次应用约束确保所有位姿满足约束
                    # 虽然_optimize_poses_sorc内部已经应用了约束，但为了确保约束在每次迭代后都被正确应用，
                    # 在主循环中也应用一次约束
                    initial_positions = getattr(self, '_initial_positions', {})
                    
                    # 🔧 关键修复：每次迭代后立即更新SAR参数（包括焦距），使其与优化后的相机位置匹配
                    # 为每张图像应用约束并更新SAR参数
                    for img_name in poses.keys():
                        R_cam = poses[img_name]['R']
                        t_cam = poses[img_name]['t']
                        
                        # 🔧 修复：应用约束时，确保约束后的位姿仍然满足所有约束
                        # 应用俯视角约束和方位角约束（这会修正相机位置）
                        R_cam, t_cam = self._apply_height_constraint_with_rotation(R_cam, t_cam, img_name, image_angles)
                        # 应用位置约束（限制相机位置不能偏离初始位置太远）
                        initial_position = initial_positions.get(img_name, None)
                        if initial_position is not None:
                            R_cam, t_cam = self._apply_position_constraint(R_cam, t_cam, initial_position, img_name)
                        # 应用5DoF约束（包括再次应用俯视角约束）
                        R_cam, t_cam = self.apply_5dof_constraint(R_cam, t_cam, img_name, image_angles)
                        
                        # 🔧 修复：在应用所有约束后，再次验证俯视角是否在合理范围内
                        # 如果仍然超出范围，强制修正（这不应该发生，但作为安全检查）
                        P_radar_check = -R_cam.T @ t_cam.flatten()
                        sphere_radius_check = np.linalg.norm(P_radar_check)
                        if sphere_radius_check > 1e-6:
                            xz_dist_check = np.sqrt(P_radar_check[0]**2 + P_radar_check[2]**2)
                            dep_check_rad = np.arcsin(np.clip(xz_dist_check / sphere_radius_check, -1.0, 1.0))
                            dep_check_deg = np.rad2deg(dep_check_rad)
                            depression_min = self.sar_params.get('depression_min')
                            if depression_min is None:
                                raise ValueError("depression_min 必须在config.py中设置（--sfm_depression_min）")
                            depression_max = self.sar_params.get('depression_max')
                            if depression_max is None:
                                raise ValueError("depression_max 必须在config.py中设置（--sfm_depression_max）")
                            enable_depression_constraint = self.sar_params.get('enable_depression_constraint')
                            if enable_depression_constraint is None:
                                raise ValueError("enable_depression_constraint 必须在config.py中设置（--sfm_enable_depression_constraint）")
                            
                            if enable_depression_constraint and (dep_check_deg < depression_min or dep_check_deg > depression_max):
                                # 强制修正俯视角
                                if dep_check_deg < depression_min:
                                    target_dep = depression_min
                                else:
                                    target_dep = depression_max
                                target_dep_rad = np.deg2rad(target_dep)
                                azimuth_check_rad = np.arctan2(P_radar_check[2], P_radar_check[0])
                                P_radar_fixed = np.array([
                                    sphere_radius_check * np.sin(target_dep_rad) * np.cos(azimuth_check_rad),
                                    -sphere_radius_check * np.cos(target_dep_rad),
                                    sphere_radius_check * np.sin(target_dep_rad) * np.sin(azimuth_check_rad)
                                ])
                                # 重新计算旋转矩阵和平移向量
                                to_scene_center = -P_radar_fixed / np.linalg.norm(P_radar_fixed)
                                azimuth_fixed_rad = np.arctan2(P_radar_fixed[2], P_radar_fixed[0])
                                right_dir = np.array([-np.sin(azimuth_fixed_rad), 0, np.cos(azimuth_fixed_rad)])
                                right_dir = right_dir / np.linalg.norm(right_dir)
                                down_dir = np.cross(to_scene_center, right_dir)
                                down_dir = down_dir / np.linalg.norm(down_dir)
                                right_dir = np.cross(down_dir, to_scene_center)
                                right_dir = right_dir / np.linalg.norm(right_dir)
                                R_radar_to_world = np.column_stack([right_dir, down_dir, to_scene_center])
                                U, S, Vt = np.linalg.svd(R_radar_to_world)
                                R_radar_to_world = U @ Vt
                                if np.linalg.det(R_radar_to_world) < 0:
                                    R_radar_to_world[:, 2] = -R_radar_to_world[:, 2]
                                R_world_to_radar = R_radar_to_world.T
                                t_cam = -R_world_to_radar @ P_radar_fixed
                                R_cam = R_world_to_radar
                        
                        # 更新poses
                        poses[img_name]['R'] = R_cam
                        poses[img_name]['t'] = t_cam
                        
                        # 🔧 修复：从优化后的相机位置计算实际的SAR参数并更新焦距
                        if img_name in image_angles:
                            # 从新的相机位置计算实际的SAR参数
                            P_radar = -R_cam.T @ t_cam.flatten()
                            R0_actual = np.linalg.norm(P_radar)
                            
                            if R0_actual > 1e-6 and not (np.any(np.isnan(P_radar)) or np.any(np.isinf(P_radar))):
                                # 🔧 修复：从相机位置向量正确计算俯视角（COLMAP坐标系：Y轴负方向为高度）
                                xz_dist = np.sqrt(P_radar[0]**2 + P_radar[2]**2)  # XZ平面距离（水平距离）
                                if R0_actual > 1e-6:
                                    # 使用 arcsin 计算俯视角：depression = arcsin(xz_dist / R)
                                    sin_dep = np.clip(xz_dist / R0_actual, -1.0, 1.0)
                                    dep_actual_rad = np.arcsin(sin_dep)
                                else:
                                    # 如果半径太小，使用 arctan2 作为备选
                                    camera_y = abs(P_radar[1])  # Y坐标对应高度
                                    dep_actual_rad = np.arctan2(xz_dist, camera_y)
                                dep_actual_deg = np.rad2deg(dep_actual_rad)
                                
                                # 计算方位角（COLMAP坐标系：XZ平面是水平面）
                                if np.linalg.norm([P_radar[0], P_radar[2]]) > 1e-6:
                                    azi_actual_rad = np.arctan2(P_radar[2], P_radar[0])  # atan2(Z, X)
                                    azi_actual_deg = np.rad2deg(azi_actual_rad)
                                else:
                                    azi_actual_deg = image_angles[img_name].get('azimuth', 0.0)
                                
                                # 更新image_angles中的角度（用于后续计算）
                                image_angles[img_name]['depression'] = dep_actual_deg
                                image_angles[img_name]['azimuth'] = azi_actual_deg
                                
                                # 🔧 关键修复：重新计算K矩阵（基于实际R0），使焦距与优化后的相机位置匹配
                                # 获取图像尺寸
                                if hasattr(self, 'image_sizes') and img_name in self.image_sizes:
                                    width, height = self.image_sizes[img_name]
                                else:
                                    width = self.sar_params.get('Na', 128)
                                    height = self.sar_params.get('Nr', 128)
                                
                                # 准备SAR参数
                                temp_params = self.sar_params.copy()
                                temp_params['Na'] = width
                                temp_params['Nr'] = height
                                temp_params['depression_angle'] = dep_actual_deg
                                temp_params['actual_R0'] = R0_actual  # 传递实际R0
                                temp_params['use_actual_R0_for_focal'] = True  # 使用实际R0计算焦距
                                
                                # 保留统一的主点（如果存在）
                                if hasattr(self, 'unified_cx') and hasattr(self, 'unified_cy'):
                                    temp_params['unified_cx'] = self.unified_cx
                                    temp_params['unified_cy'] = self.unified_cy
                                
                                # 重新计算K矩阵
                                try:
                                    _, _, K_new = compute_sar_camera_pose(dep_actual_deg, azi_actual_deg, temp_params)
                                    # 更新K矩阵（如果存在存储位置）
                                    if hasattr(self, 'image_K'):
                                        self.image_K[img_name] = K_new
                                except Exception as e:
                                    if self.verbose:
                                        print(f"    ⚠️ {img_name} 重新计算K矩阵失败: {e}")
                
                if self.verbose and iteration > 0:
                    print(f"  ✅ SAR参数（包括焦距）已更新以匹配优化后的相机位置（第{iteration+1}次迭代）")
                
                # 优化3D点（使用最小二乘）
                points_3d = self._optimize_points_3d(poses, points_3d, point_tracks,
                                                     keypoints_dict, image_angles)
            
            # 优化后检查：限制异常大的3D点坐标
            # 防止优化过程中产生异常大的点（可能是单位问题或优化发散）
            if len(points_3d) > 0:
                camera_height = self.sar_params.get('camera_height', 1365.0)
                # 计算参考斜距范围（基于可能的俯视角范围）
                # 对于SAR场景，3D点应该在场景中心附近，距离雷达位置应该在合理范围内
                # 保守估计：最大斜距应该是camera_height的5倍以内
                max_allowed_range = camera_height * 5
                
                # 检查每个点是否异常大
                point_norms = np.linalg.norm(points_3d, axis=1)
                outlier_mask = point_norms > max_allowed_range
                
                if np.any(outlier_mask):
                    num_outliers = np.sum(outlier_mask)
                    if self.verbose and (iteration == 0 or num_outliers > len(points_3d) * 0.1):
                        print(f"  ⚠️ 警告: 检测到 {num_outliers} 个异常大的3D点（范数>{max_allowed_range:.0f}米），进行限制")
                    
                    # 限制异常点：将异常大的点缩放到合理范围
                    # 使用中位数作为参考中心
                    point_center = np.median(points_3d, axis=0)
                    
                    for i in np.where(outlier_mask)[0]:
                        point_dir = points_3d[i] - point_center
                        point_dir_norm = np.linalg.norm(point_dir)
                        if point_dir_norm > 0:
                            # 将异常点缩放到最大允许范围的0.8倍
                            new_norm = max_allowed_range * 0.8
                            points_3d[i] = point_center + point_dir / point_dir_norm * new_norm
                    
                    if self.verbose and (iteration == 0 or num_outliers > len(points_3d) * 0.1):
                        new_norms = np.linalg.norm(points_3d, axis=1)
                        print(f"  ✅ 已限制异常点，最大范数: {np.max(new_norms):.2f}米 (限制前: {np.max(point_norms):.2f}米)")
            
            # 计算总误差（每10次迭代输出详细统计）
            verbose_stats = (iteration + 1) % 10 == 0 or iteration == 0
            total_error = self._compute_total_error(poses, points_3d, point_tracks,
                                                    keypoints_dict, image_angles,
                                                    verbose_stats=verbose_stats)
            
            # 保存当前误差用于下次比较（在计算total_error之后）
            self._last_error = total_error
            
            # 保存当前误差用于自适应步长调整
            self._current_total_error = total_error
            
            # 诊断：如果初始误差过大，输出详细的诊断信息
            if iteration == 0 and total_error > 1e6:
                if self.verbose:
                    print(f"\n  ⚠️ 警告: 初始误差过大 ({total_error:.2e})")
                    
                    # 获取SAR参数用于诊断
                    camera_height = self.sar_params.get('camera_height', 1365.0)
                    fs = self.sar_params.get('fs', 1.1 * 240e6)
                    prf = self.sar_params.get('prf', 2200)
                    Va = self.sar_params.get('Va', 755)
                    C = self.sar_params.get('C', 3e8)
                    Na = self.sar_params.get('Na', 512)
                    Nr = self.sar_params.get('Nr', 512)
                    range_pixel_size = C / (2 * fs)
                    azimuth_pixel_size = Va / prf
                    
                    # 检查点云尺度
                    if len(points_3d) > 0:
                        point_norms = np.linalg.norm(points_3d, axis=1)
                        median_norm = np.median(point_norms)
                        max_norm = np.max(point_norms)
                        min_norm = np.min(point_norms)
                        
                        print(f"\n  🔍 详细诊断信息:")
                        print(f"    1. 点云尺度:")
                        print(f"       - 中位数范数: {median_norm:.2f}米")
                        print(f"       - 范围: [{min_norm:.2f}, {max_norm:.2f}]米")
                        print(f"       - 坐标范围: X[{points_3d[:, 0].min():.2f}, {points_3d[:, 0].max():.2f}], "
                              f"Y[{points_3d[:, 1].min():.2f}, {points_3d[:, 1].max():.2f}], "
                              f"Z[{points_3d[:, 2].min():.2f}, {points_3d[:, 2].max():.2f}]")
                        
                        if median_norm > 10000:
                            print(f"       ⚠️ 点云尺度异常大，可能是单位不匹配（像素而非米）")
                    
                    # 检查SAR参数
                    print(f"\n    2. SAR参数:")
                    print(f"       - camera_height: {camera_height:.1f}米")
                    print(f"       - fs: {fs:.0f} Hz")
                    print(f"       - prf: {prf:.1f} Hz")
                    print(f"       - Va: {Va:.1f} m/s")
                    print(f"       - 图像尺寸: {Na} x {Nr}")
                    print(f"       - range_pixel_size: {range_pixel_size:.6f}米/像素")
                    print(f"       - azimuth_pixel_size: {azimuth_pixel_size:.6f}米/像素")
                    
                    # 检查循环俯视角参数
                    if hasattr(self, '_cyclic_start') and hasattr(self, '_cyclic_end'):
                        print(f"\n    3. 循环俯视角参数:")
                        print(f"       - 起始角度: {self._cyclic_start}°")
                        print(f"       - 结束角度: {self._cyclic_end}°")
                        print(f"       - 步长: {getattr(self, '_cyclic_step', 'N/A')}°")
                    
                    # 检查雷达位置
                    if len(poses) > 0:
                        sample_pose = list(poses.values())[0]
                        sample_radar_pos = -sample_pose['R'].T @ sample_pose['t'].flatten()
                        radar_norm = np.linalg.norm(sample_radar_pos)
                        print(f"\n    4. 雷达位置:")
                        print(f"       - 示例雷达位置: {sample_radar_pos}")
                        print(f"       - 雷达位置范数: {radar_norm:.2f}米")
                        
                        # 计算参考斜距范围
                        if hasattr(self, '_cyclic_start') and hasattr(self, '_cyclic_end'):
                            dep_start = self._cyclic_start
                            dep_end = self._cyclic_end
                            R0_start = camera_height / np.sin(np.deg2rad(dep_start))
                            R0_end = camera_height / np.sin(np.deg2rad(dep_end))
                            print(f"       - 参考斜距范围: [{R0_start:.2f}, {R0_end:.2f}]米 (基于循环俯视角)")
                    
                    print(f"\n      - 可能原因:")
                    print(f"        1. 坐标系不匹配：3D点坐标单位可能是像素而非米")
                    print(f"        2. SAR参数不匹配：检查camera_height、fs、prf等参数")
                    print(f"        3. 初始位姿不正确：检查相机位姿初始化")
                    print(f"        4. 图像尺寸不匹配：检查Na和Nr是否与实际图像尺寸一致")
                    print(f"        5. 循环俯视角范围不合理：当前范围可能不适合数据")
                    print(f"\n      - 建议:")
                    print(f"        1. 检查3D点坐标范围（应该在几百到几千米之间）")
                    print(f"        2. 检查SAR参数是否与实际数据匹配（特别是camera_height）")
                    print(f"        3. 检查循环俯视角范围是否合理（当前: {getattr(self, '_cyclic_start', 'N/A')}°-{getattr(self, '_cyclic_end', 'N/A')}°）")
                    print(f"        4. 如果点云尺度异常大，考虑归一化点云坐标")
                    print(f"        5. 检查图像坐标到物理坐标的转换是否正确")
            self.error_history.append(total_error)
            
            # 保存最佳结果（避免局部最小值）
            if total_error < best_error:
                best_error = total_error
                best_poses = {k: {'R': v['R'].copy(), 't': v['t'].copy()} 
                             for k, v in poses.items()}
                best_points_3d = points_3d.copy()
            
            if self.verbose:
                # 计算平均误差（更易理解）
                avg_error = total_error
                # 计算误差改善率（相对于最佳误差）
                if best_error < float('inf') and best_error > 0:
                    # 相对于最佳误差的改善率（正值表示改善，负值表示变差）
                    error_improvement = (best_error - total_error) / best_error * 100
                    if error_improvement > 0:
                        print(f"  总误差: {total_error:.6e} (最佳: {best_error:.6e}, 改善: {error_improvement:.2f}%)")
                    else:
                        print(f"  总误差: {total_error:.6e} (最佳: {best_error:.6e}, 变差: {abs(error_improvement):.2f}%)")
                else:
                    print(f"  总误差: {total_error:.6e} (最佳: {best_error:.6e})")
            
            # 检查收敛（更严格的收敛条件）
            error_change = abs(prev_error - total_error)
            relative_change = error_change / max(prev_error, 1e-6)
            
            # 如果相对变化很小，认为收敛
            if relative_change < self.tolerance * 10:  # 放宽收敛条件
                if self.verbose:
                    print(f"\n收敛于迭代 {iteration + 1} (相对变化: {relative_change:.2e})")
                
                # 🔧 重要修复：恢复到最佳状态
                if best_poses is not None and best_points_3d is not None and best_error < total_error:
                    if self.verbose:
                        print(f"  ℹ️ 恢复到最佳状态（误差: {best_error:.6e}，相比当前误差改善: {(total_error - best_error) / total_error * 100:.2f}%）")
                    poses = {k: {'R': v['R'].copy(), 't': v['t'].copy()} 
                            for k, v in best_poses.items()}
                    points_3d = best_points_3d.copy()
                    total_error = best_error
                
                break
            
            # 改进的提前停止策略：更宽松的条件，允许优化继续
            # 如果误差没有改善且已经迭代足够多次，提前停止
            if iteration >= 10:  # 从第10次迭代开始检测（给优化更多机会）
                # 检查误差是否改善（放宽条件：改善至少0.05%即可）
                error_improvement = (prev_error - total_error) / prev_error if prev_error > 0 else 0
                
                if error_improvement < 0.0005:  # 改善小于0.05%（从0.1%放宽到0.05%）
                    no_improvement_count = getattr(self, '_no_improvement_count', 0)
                    no_improvement_count += 1
                    self._no_improvement_count = no_improvement_count
                    
                    # 更宽松的提前停止：连续10次没有改善才停止（从5次增加到10次）
                    if no_improvement_count >= 10:
                        if self.verbose:
                            print(f"\n提前停止: 连续{no_improvement_count}次迭代误差没有明显改善（改善<0.05%）")
                        
                        # 🔧 重要修复：恢复到最佳状态
                        if best_poses is not None and best_points_3d is not None:
                            if self.verbose:
                                print(f"  ℹ️ 恢复到最佳状态（误差: {best_error:.6e}，相比当前误差改善: {(total_error - best_error) / total_error * 100:.2f}%）")
                            poses = {k: {'R': v['R'].copy(), 't': v['t'].copy()} 
                                    for k, v in best_poses.items()}
                            points_3d = best_points_3d.copy()
                            total_error = best_error
                        
                        break
                else:
                    # 如果有改善，重置计数
                    self._no_improvement_count = 0
            else:
                self._no_improvement_count = 0
            
            # 简化的早停策略：只要比最佳结果差就计数，连续5次就停止
            if not hasattr(self, '_consecutive_worse_count'):
                self._consecutive_worse_count = 0
            
            if total_error > best_error and iteration > 2:
                # 比最佳结果差，计数+1
                self._consecutive_worse_count += 1
                worse_ratio = (total_error - best_error) / best_error * 100 if best_error > 0 else 0
                
                if self.verbose:
                    print(f"  ⚠️ 比最佳结果差 {worse_ratio:.2f}%，变差计数: {self._consecutive_worse_count}/5")
                
                # 连续5次比最佳结果差，使用最佳结果并停止迭代
                if self._consecutive_worse_count >= 5:
                    if self.verbose:
                        print(f"\n🛑 连续{self._consecutive_worse_count}次迭代比最佳结果差，使用最佳结果并停止优化")
                    
                    # 恢复到最佳结果
                    if best_poses is not None and best_points_3d is not None:
                        if self.verbose:
                            print(f"  ✅ 恢复到最佳状态（误差: {best_error:.6e}）")
                        poses = {k: {'R': v['R'].copy(), 't': v['t'].copy()} 
                                for k, v in best_poses.items()}
                        points_3d = best_points_3d.copy()
                        total_error = best_error
                    break
                
                # 误差增加时减小步长
                if worse_ratio > 10.0:
                    if not hasattr(self, '_step_size_scale'):
                        self._step_size_scale = 1.0
                    self._step_size_scale *= 0.8
            else:
                # 达到或优于最佳结果，重置计数
                self._consecutive_worse_count = 0
            
            prev_error = total_error
        
        # 使用最佳结果
        if best_poses is not None:
            poses = best_poses
            points_3d = best_points_3d
        
        # 🔧 重投影误差过滤：移除误差过大的异常点
        max_reproj_error = self.sar_params.get('max_reprojection_error', 50.0)
        filter_outliers = self.sar_params.get('filter_outlier_points', True)
        
        if filter_outliers and len(points_3d) > 0:
            points_3d, point_tracks = self._filter_by_reprojection_error(
                points_3d, poses, point_tracks, keypoints_dict, image_angles, 
                max_error=max_reproj_error
            )
        
        # 🔧 密集点云初始化：在稀疏点云基础上添加网格点
        dense_init = self.sar_params.get('dense_init', False)
        dense_grid_size = self.sar_params.get('dense_grid_size', 16)
        print(f"\n📋 密集初始化参数检查:")
        print(f"   - dense_init: {dense_init}")
        print(f"   - dense_grid_size: {dense_grid_size}")
        print(f"   - 当前点数: {len(points_3d)}")
        
        if dense_init and len(points_3d) > 0:
            print(f"   ✅ 执行密集初始化...")
            points_3d, point_tracks = self._add_dense_grid_points(
                points_3d, point_tracks, poses
            )
            print(f"   ✅ 密集初始化完成，新点数: {len(points_3d)}")
        else:
            if not dense_init:
                print(f"   ℹ️ 密集初始化未启用（需要 --sfm_dense_init 参数）")
            elif len(points_3d) == 0:
                print(f"   ⚠️ 点云为空，无法进行密集初始化")
        
        if self.verbose:
            print("="*60)
            print("SO-RCG SAR SfM求解完成")
            print("="*60)
        
        return {
            'poses': poses,
            'points_3d': points_3d,
            'point_tracks': point_tracks,
            'error_history': self.error_history
        }
    
    def _build_point_tracks(self, keypoints_dict, matches_dict):
        """构建点跟踪"""
        point_tracks = {}
        point_id = 0
        
        for (img1_name, img2_name), matches in matches_dict.items():
            kp1 = keypoints_dict.get(img1_name, [])
            kp2 = keypoints_dict.get(img2_name, [])
            
            if len(kp1) == 0 or len(kp2) == 0:
                continue
            
            for match in matches:
                if hasattr(match, 'queryIdx'):
                    idx1 = match.queryIdx
                    idx2 = match.trainIdx
                elif isinstance(match, (list, tuple)) and len(match) >= 2:
                    idx1 = match[0]
                    idx2 = match[1]
                else:
                    continue
                
                if idx1 < 0 or idx2 < 0 or idx1 >= len(kp1) or idx2 >= len(kp2):
                    continue
                
                # 检查是否已经存在track
                found_track = False
                for pid, track in point_tracks.items():
                    if (img1_name, idx1) in track:
                        if (img2_name, idx2) not in track:
                            track.append((img2_name, idx2))
                        found_track = True
                        break
                    elif (img2_name, idx2) in track:
                        if (img1_name, idx1) not in track:
                            track.append((img1_name, idx1))
                        found_track = True
                        break
                
                if not found_track:
                    point_tracks[point_id] = [(img1_name, idx1), (img2_name, idx2)]
                    point_id += 1
        
        return point_tracks
    
    def _initialize_poses(self, image_names, initial_poses, image_angles):
        """初始化位姿"""
        poses = {}
        
        # 尝试导入SAR几何模块
        try:
            from .geometry import compute_sar_camera_pose
            SAR_GEOMETRY_AVAILABLE = True
        except ImportError:
            SAR_GEOMETRY_AVAILABLE = False
        
        # 诊断：检查初始位姿的来源
        use_initial_poses_count = 0
        use_angle_init_count = 0
        
        for img_name in image_names:
            if initial_poses and img_name in initial_poses:
                R_init = np.array(initial_poses[img_name]['R'])
                t_init = np.array(initial_poses[img_name]['t']).flatten()
                use_initial_poses_count += 1
                
                # 诊断：检查初始位姿的合理性
                if self.verbose and use_initial_poses_count <= 3:
                    radar_pos = -R_init.T @ t_init.flatten()
                    radar_norm = np.linalg.norm(radar_pos)
                    print(f"  ℹ️ 初始位姿诊断 ({img_name}):")
                    print(f"    - 雷达位置: {radar_pos}")
                    print(f"    - 雷达位置范数: {radar_norm:.2f}米")
            else:
                # 使用角度信息初始化
                if image_angles and img_name in image_angles:
                    angles = image_angles[img_name]
                    dep = angles.get('depression', 31.57)
                    azi = angles.get('azimuth', 0)
                    use_angle_init_count += 1
                    
                    # 诊断：检查使用的俯视角
                    if self.verbose and use_angle_init_count <= 3:
                        print(f"  ℹ️ 从角度初始化位姿 ({img_name}):")
                        print(f"    - 俯视角: {dep}°")
                        print(f"    - 方位角: {azi}°")
                    
                    # 使用SAR几何模型初始化位姿
                    if SAR_GEOMETRY_AVAILABLE:
                        try:
                            R_init, t_init, _ = compute_sar_camera_pose(
                                dep, azi, self.sar_params
                            )
                            t_init = t_init.flatten()
                            
                            # 诊断：检查计算的位姿（在应用高度约束之前）
                            if self.verbose and use_angle_init_count <= 3:
                                radar_pos_before = -R_init.T @ t_init.flatten()
                                radar_norm_before = np.linalg.norm(radar_pos_before)
                                
                                # 🔧 修复：根据分布模式检查相应的值
                                distribution_mode = self.sar_params.get('camera_distribution_mode', 'sphere')
                                camera_height_param = self.sar_params.get('camera_height', 12000.0)
                                
                                print(f"    - 计算的雷达位置（应用高度约束前）: {radar_pos_before}")
                                print(f"    - 雷达位置范数: {radar_norm_before:.2f}米")
                                print(f"    - 分布模式: {distribution_mode}")
                                
                                if distribution_mode == 'sphere':
                                    # 球面分布：检查范数是否一致
                                    expected_radius = radar_norm_before  # 应该等于球面半径
                                    dep_rad = np.deg2rad(dep)  # 当前图像的俯视角（弧度）
                                    print(f"    - Y坐标（高度）: {radar_pos_before[1]:.2f}米 (COLMAP约定：高度在Y轴负方向)")
                                    print(f"    - Z坐标（深度）: {radar_pos_before[2]:.2f}米")
                                    print(f"    - 球面半径（实际）: {radar_norm_before:.2f}米")
                                    print(f"    - 理论球面半径（未缩放）: {camera_height_param / np.sin(dep_rad):.2f}米（基于俯视角{dep}°）")
                                    print(f"    ✅ 使用球面分布模式，Y坐标（高度）随俯视角变化（正常）")
                                else:
                                    # 水平圆环分布：检查Y坐标（高度）
                                    expected_y = -camera_height_param  # COLMAP约定：高度在Y轴负方向
                                    print(f"    - Y坐标（高度）: {radar_pos_before[1]:.2f}米 (期望: {expected_y:.2f}米)")
                                    if abs(radar_pos_before[1] - expected_y) > 100:
                                        print(f"    ⚠️ 警告: Y坐标（高度）与期望值差异较大 ({abs(radar_pos_before[1] - expected_y):.2f}米)")
                                        print(f"      可能原因: compute_sar_camera_pose计算错误")
                            
                            # 注意：compute_sar_camera_pose在ring模式下应该已经设置了Y坐标=-camera_height（COLMAP约定）
                            # 但为了确保一致性，仍然应用高度约束（只调整不在合理范围内的位姿）
                            # 高度约束会确保Y坐标（高度）在合理范围内，并调整旋转矩阵使相机指向场景中心
                            R_init_before_constraint = R_init.copy()
                            t_init_before_constraint = t_init.copy()
                            R_init, t_init = self._apply_height_constraint_with_rotation(R_init, t_init, img_name, image_angles)
                            
                            # 诊断：检查应用高度约束后的位姿
                            if self.verbose and use_angle_init_count <= 3:
                                radar_pos_after = -R_init.T @ t_init.flatten()
                                radar_norm_after = np.linalg.norm(radar_pos_after)
                                print(f"    - 计算的雷达位置（应用高度约束后）: {radar_pos_after}")
                                print(f"    - 雷达位置范数: {radar_norm_after:.2f}米")
                                print(f"    - Y坐标（高度）: {radar_pos_after[1]:.2f}米 (COLMAP约定：高度在Y轴负方向)")
                                print(f"    - Z坐标（深度）: {radar_pos_after[2]:.2f}米")
                                
                                # 检查高度约束是否改变了位姿
                                y_diff = abs(radar_pos_before[1] - radar_pos_after[1])
                                if y_diff > 1.0:
                                    camera_height = self.sar_params.get('camera_height', 12000.0)
                                    height_tolerance = camera_height * 0.2
                                    min_height = camera_height - height_tolerance
                                    max_height = camera_height + height_tolerance
                                    print(f"    ⚠️ 注意: Y坐标（高度）被高度约束调整了 {y_diff:.2f}米")
                                    print(f"      调整前Y坐标: {radar_pos_before[1]:.2f}米")
                                    print(f"      调整后Y坐标: {radar_pos_after[1]:.2f}米")
                                    print(f"      高度约束范围: [{min_height:.2f}, {max_height:.2f}]米（绝对值）")
                                    if abs(radar_pos_before[1]) < min_height or abs(radar_pos_before[1]) > max_height or radar_pos_before[1] >= 0:
                                        print(f"      原因: 调整前Y坐标（高度）不在合理范围内")
                                    else:
                                        print(f"      ⚠️ 警告: 调整前Y坐标（高度）在合理范围内，但高度约束仍然调整了它")
                                        print(f"      这可能是因为旋转矩阵被重新计算，导致雷达位置发生了变化")
                        except Exception as e:
                            if self.verbose:
                                print(f"  警告: 无法从角度初始化 {img_name} 的位姿: {e}")
                            R_init = np.eye(3)
                            t_init = np.zeros(3)
                    else:
                        # 如果没有SAR几何模块，使用简单的初始化
                        R_init = np.eye(3)
                        t_init = np.zeros(3)
                else:
                    R_init = np.eye(3)
                    t_init = np.zeros(3)
            
            # 注意：对于从角度初始化的位姿，高度约束已经在上面应用了
            # 这里只对从initial_poses加载的位姿应用高度约束（如果还没有应用）
            # 这样可以避免重复应用高度约束
            if initial_poses and img_name in initial_poses:
                # 只对从initial_poses加载的位姿应用约束（包括可选的方位角约束）
                R_init, t_init = self._apply_height_constraint_with_rotation(R_init, t_init, img_name, image_angles)
            # 对于从角度初始化的位姿，高度约束已经在上面应用了，不需要再次应用
            
            poses[img_name] = {
                'R': R_init,
                't': t_init
            }
        
        # 诊断：总结初始化方式
        if self.verbose:
            print(f"\n  📊 位姿初始化统计:")
            print(f"    - 使用初始位姿: {use_initial_poses_count}/{len(image_names)}")
            print(f"    - 从角度初始化: {use_angle_init_count}/{len(image_names)}")
        
        return poses
    
    def _initialize_points_3d(self, point_tracks, poses, keypoints_dict, image_angles):
        """初始化3D点（使用三角化）"""
        points_3d = []
        triangulation_stats = {
            'total_tracks': len(point_tracks),
            'successful': 0,
            'failed': 0,
            'failed_reasons': {
                'insufficient_observations': 0,
                'missing_poses': 0,
                'invalid_keypoints': 0,
                'triangulation_failed': 0
            }
        }
        
        for pid, track in point_tracks.items():
            if len(track) < 2:
                triangulation_stats['failed_reasons']['insufficient_observations'] += 1
                continue
            
            # 尝试使用所有可能的图像对进行三角化，选择最佳结果
            best_point_3d = None
            best_error = float('inf')
            
            # 尝试多个图像对（不只是前两个）
            max_pairs_to_try = min(20, len(track))  # 最多尝试20对
            for i in range(min(max_pairs_to_try, len(track))):
                for j in range(i + 1, min(max_pairs_to_try, len(track))):
                    img1_name, idx1 = track[i]
                    img2_name, idx2 = track[j]
                    
                    if img1_name not in poses or img2_name not in poses:
                        continue
                    
                    R1 = poses[img1_name]['R']
                    t1 = poses[img1_name]['t']
                    R2 = poses[img2_name]['R']
                    t2 = poses[img2_name]['t']
                    
                    kp1 = keypoints_dict.get(img1_name, [])
                    kp2 = keypoints_dict.get(img2_name, [])
                    
                    if idx1 >= len(kp1) or idx2 >= len(kp2):
                        continue
                    
                    pt1 = kp1[idx1].pt if hasattr(kp1[idx1], 'pt') else kp1[idx1]
                    pt2 = kp2[idx2].pt if hasattr(kp2[idx2], 'pt') else kp2[idx2]
                    
                    # 尝试三角化
                    # 使用image_angles中的俯视角（如果启用循环模式，则为循环俯视角）
                    angles1 = image_angles.get(img1_name, {})
                    angles2 = image_angles.get(img2_name, {})
                    point_3d = self._triangulate_point(pt1, pt2, R1, t1, R2, t2,
                                                      angles1, angles2)
                    
                    if point_3d is not None:
                        # 验证三角化点的质量（计算重投影误差）
                        try:
                            _, _, error1 = self.compute_rd_reprojection_error(
                                point_3d, R1, t1, pt1,
                                image_angles.get(img1_name, {}).get('depression', 31.57)
                            )
                            _, _, error2 = self.compute_rd_reprojection_error(
                                point_3d, R2, t2, pt2,
                                image_angles.get(img2_name, {}).get('depression', 31.57)
                            )
                            avg_error = (error1 + error2) / 2.0
                            
                            # 选择误差最小的点
                            if avg_error < best_error:
                                best_error = avg_error
                                best_point_3d = point_3d
                        except:
                            # 如果计算误差失败，仍然使用这个点
                            if best_point_3d is None:
                                best_point_3d = point_3d
            
            if best_point_3d is not None:
                # 立即检查三角化点的合理性，过滤异常点
                # 特别是Z方向异常大的点（可能是三角化错误）
                camera_height = self.sar_params.get('camera_height', 1365.0)
                point_norm = np.linalg.norm(best_point_3d)
                z_abs = abs(best_point_3d[2])
                
                # 检查点是否异常大
                # 1. Z坐标不应该超过camera_height的2倍（保守估计）
                # 2. 点的范数不应该超过camera_height的10倍（保守估计）
                max_z_allowed = camera_height * 2  # Z坐标上限
                max_norm_allowed = camera_height * 10  # 点范数上限
                
                # 如果点异常大，尝试修正或跳过
                if z_abs > max_z_allowed or point_norm > max_norm_allowed:
                    # 尝试修正：将Z坐标限制到合理范围
                    if z_abs > max_z_allowed:
                        # Z坐标异常大，可能是三角化错误
                        # 将Z坐标限制到合理范围（camera_height的0.5倍）
                        best_point_3d[2] = np.clip(best_point_3d[2], -camera_height * 0.5, camera_height * 0.5)
                    
                    # 如果修正后范数仍然异常大，跳过这个点
                    point_norm_after = np.linalg.norm(best_point_3d)
                    if point_norm_after > max_norm_allowed:
                        triangulation_stats['failed_reasons']['triangulation_failed'] += 1
                        triangulation_stats['failed'] += 1
                        continue  # 跳过这个异常点
                
                points_3d.append(best_point_3d)
                triangulation_stats['successful'] += 1
            else:
                # 如果所有尝试都失败，使用第一个图像对的结果（即使返回None）
                if len(track) >= 2:
                    img1_name, idx1 = track[0]
                    img2_name, idx2 = track[1]
                    
                    if img1_name in poses and img2_name in poses:
                        kp1 = keypoints_dict.get(img1_name, [])
                        kp2 = keypoints_dict.get(img2_name, [])
                        
                        if idx1 < len(kp1) and idx2 < len(kp2):
                            pt1 = kp1[idx1].pt if hasattr(kp1[idx1], 'pt') else kp1[idx1]
                            pt2 = kp2[idx2].pt if hasattr(kp2[idx2], 'pt') else kp2[idx2]
                            
                            point_3d = self._triangulate_point(pt1, pt2,
                                                              poses[img1_name]['R'], poses[img1_name]['t'],
                                                              poses[img2_name]['R'], poses[img2_name]['t'],
                                                              image_angles.get(img1_name, {}),
                                                              image_angles.get(img2_name, {}))
                            
                            if point_3d is not None:
                                # 检查三角化点的合理性
                                camera_height = self.sar_params.get('camera_height', 1365.0)
                                point_norm = np.linalg.norm(point_3d)
                                z_abs = abs(point_3d[2])
                                
                                max_z_allowed = camera_height * 2
                                max_norm_allowed = camera_height * 10
                                
                                # 如果点异常大，修正或跳过
                                if z_abs > max_z_allowed:
                                    point_3d[2] = np.clip(point_3d[2], -camera_height * 0.5, camera_height * 0.5)
                                
                                point_norm_after = np.linalg.norm(point_3d)
                                if point_norm_after > max_norm_allowed:
                                    triangulation_stats['failed_reasons']['triangulation_failed'] += 1
                                    triangulation_stats['failed'] += 1
                                    continue
                                
                                points_3d.append(point_3d)
                                triangulation_stats['successful'] += 1
                            else:
                                triangulation_stats['failed_reasons']['triangulation_failed'] += 1
                                # 不添加零向量，避免后续问题
                        else:
                            triangulation_stats['failed_reasons']['invalid_keypoints'] += 1
                    else:
                        triangulation_stats['failed_reasons']['missing_poses'] += 1
                else:
                    triangulation_stats['failed_reasons']['insufficient_observations'] += 1
        
        triangulation_stats['failed'] = triangulation_stats['total_tracks'] - triangulation_stats['successful']
        
        if self.verbose:
            print(f"\n📊 三角化统计:")
            print(f"  - 总track数: {triangulation_stats['total_tracks']}")
            print(f"  - 成功三角化: {triangulation_stats['successful']}")
            print(f"  - 失败: {triangulation_stats['failed']}")
            if triangulation_stats['failed'] > 0:
                print(f"  - 失败原因:")
                for reason, count in triangulation_stats['failed_reasons'].items():
                    if count > 0:
                        print(f"    - {reason}: {count}")
        
        points_3d_array = np.array(points_3d) if points_3d else np.zeros((0, 3))
        
        # 三角化后立即过滤异常点（特别是Z方向异常大的点）
        if len(points_3d_array) > 0:
            # 从实际相机位姿计算球面半径（更准确）
            camera_distances = []
            for img_name, pose_data in poses.items():
                R = pose_data['R']
                t = pose_data['t']
                P_radar = -R.T @ t.flatten()  # 世界坐标系中的相机位置
                camera_distances.append(np.linalg.norm(P_radar))
            
            # 使用相机距离的中位数作为球面半径参考
            if camera_distances:
                sphere_radius = np.median(camera_distances)
            else:
                sphere_radius = self.sar_params.get('sphere_radius', 12.8)
            
            scene_scale = self.sar_params.get('scene_scale', 0.1)
            
            # 计算统计信息
            z_values = points_3d_array[:, 2]
            z_median = np.median(z_values)
            z_mad = np.median(np.abs(z_values - z_median))  # Median Absolute Deviation
            
            # 使用MAD方法检测Z方向异常值（更严格：2.5倍MAD）
            z_threshold_low = z_median - 2.5 * z_mad
            z_threshold_high = z_median + 2.5 * z_mad
            
            # 使用实际球面半径作为参考（而不是未缩放的camera_height）
            # Z坐标应该在 [-3*sphere_radius, 3*sphere_radius] 范围内
            z_abs_threshold = sphere_radius * 3
            
            # 对于目标在地面附近的假设，负Z坐标应该有限制（目标通常在相机下方但不会太深）
            z_negative_threshold = -sphere_radius * 1.5  # 允许一定的负Z坐标
            
            # 过滤异常点
            valid_mask = np.ones(len(points_3d_array), dtype=bool)
            
            # 检查Z坐标异常值：
            # 1. 超出MAD阈值
            # 2. 绝对值过大
            # 3. 负Z坐标过深（可能是三角化错误）
            z_outlier_mask = (
                (z_values < z_threshold_low) | 
                (z_values > z_threshold_high) | 
                (z_values > z_abs_threshold) |
                (z_values < z_negative_threshold)
            )
            
            # 检查点范数异常值
            point_norms = np.linalg.norm(points_3d_array, axis=1)
            norm_median = np.median(point_norms)
            norm_mad = np.median(np.abs(point_norms - norm_median))
            norm_threshold = norm_median + 2.5 * norm_mad  # 更严格：2.5倍MAD
            norm_abs_threshold = sphere_radius * 3  # 点范数不应该超过球面半径的3倍
            
            norm_outlier_mask = (point_norms > norm_threshold) | (point_norms > norm_abs_threshold)
            
            # 🔧 点云高度约束：限制Y坐标（高度）范围，确保高度/长度比例合理（必须从config.py中设置）
            enable_point_height_constraint = self.sar_params.get('enable_point_height_constraint')
            if enable_point_height_constraint is None:
                raise ValueError("enable_point_height_constraint 必须在config.py中设置（--sfm_enable_point_height_constraint）")
            height_length_ratio = self.sar_params.get('point_height_length_ratio')
            if height_length_ratio is None:
                raise ValueError("point_height_length_ratio 必须在config.py中设置（--sfm_point_height_length_ratio）")
            constraint_mode = self.sar_params.get('point_height_constraint_mode')
            if constraint_mode is None:
                raise ValueError("point_height_constraint_mode 必须在config.py中设置（--sfm_point_height_constraint_mode）")
            
            y_outlier_mask = np.zeros(len(points_3d_array), dtype=bool)
            if enable_point_height_constraint and len(points_3d_array) > 0:
                # 计算X和Z方向的范围（水平方向，长度）
                x_range = np.max(points_3d_array[:, 0]) - np.min(points_3d_array[:, 0])
                z_range = np.max(points_3d_array[:, 2]) - np.min(points_3d_array[:, 2])
                # 使用较大的范围作为"长度"参考
                length_range = max(x_range, z_range)
                
                # 计算Y坐标（高度）范围
                y_range = np.max(points_3d_array[:, 1]) - np.min(points_3d_array[:, 1])
                
                # 计算当前高度/长度比例
                current_ratio = y_range / length_range if length_range > 1e-6 else 0.0
                
                # 如果高度/长度比例超过阈值，应用约束
                if current_ratio > height_length_ratio:
                    # 计算Y坐标的中心值
                    y_center = np.median(points_3d_array[:, 1])
                    # 计算允许的Y坐标范围（基于长度范围和比例阈值）
                    max_y_range = length_range * height_length_ratio
                    y_min_allowed = y_center - max_y_range / 2
                    y_max_allowed = y_center + max_y_range / 2
                    
                    if constraint_mode == 'scale':
                        # 🔧 缩放模式：直接缩小所有点的高度，而不是过滤
                        # 计算缩放因子：将当前Y范围缩放到允许的Y范围
                        scale_factor = max_y_range / y_range if y_range > 1e-6 else 1.0
                        
                        # 缩放所有点的Y坐标（相对于中心）
                        points_3d_array[:, 1] = y_center + (points_3d_array[:, 1] - y_center) * scale_factor
                        
                        if self.verbose:
                            print(f"\n  🔧 点云高度约束（缩放模式）:")
                            print(f"    - 当前高度/长度比例: {current_ratio:.4f} (阈值: {height_length_ratio:.4f})")
                            print(f"    - X范围: {x_range:.2f}米, Z范围: {z_range:.2f}米")
                            print(f"    - 原始Y范围: {y_range:.2f}米")
                            print(f"    - 缩放因子: {scale_factor:.4f}")
                            print(f"    - 缩放后Y范围: {np.max(points_3d_array[:, 1]) - np.min(points_3d_array[:, 1]):.2f}米")
                            print(f"    - Y坐标中心: {y_center:.2f}米")
                            print(f"    - ✅ 所有点的高度已缩放以符合约束（保留 {len(points_3d_array)} 个点）")
                    else:
                        # 过滤模式：标记超出范围的Y坐标
                        y_outlier_mask = (points_3d_array[:, 1] < y_min_allowed) | (points_3d_array[:, 1] > y_max_allowed)
                        
                        if self.verbose and np.any(y_outlier_mask):
                            num_y_outliers = np.sum(y_outlier_mask)
                            print(f"\n  🔧 点云高度约束（过滤模式）:")
                            print(f"    - 当前高度/长度比例: {current_ratio:.4f} (阈值: {height_length_ratio:.4f})")
                            print(f"    - X范围: {x_range:.2f}米, Z范围: {z_range:.2f}米, Y范围: {y_range:.2f}米")
                            print(f"    - Y坐标允许范围: [{y_min_allowed:.2f}, {y_max_allowed:.2f}]米")
                            print(f"    - 检测到 {num_y_outliers} 个Y坐标（高度）异常点（{num_y_outliers/len(points_3d_array)*100:.1f}%）")
                            print(f"    - Y坐标范围: [{np.min(points_3d_array[:, 1]):.2f}, {np.max(points_3d_array[:, 1]):.2f}]米")
            
            # 综合异常值检测（包括Z坐标、范数和Y坐标高度约束）
            # 注意：在缩放模式下，y_outlier_mask应该为空（所有点都被保留，只是高度被缩放）
            if constraint_mode == 'scale':
                # 缩放模式下，不将Y坐标异常点标记为异常（因为已经缩放过了）
                outlier_mask = z_outlier_mask | norm_outlier_mask
            else:
                # 过滤模式下，将Y坐标异常点标记为异常
                outlier_mask = z_outlier_mask | norm_outlier_mask | y_outlier_mask
            
            if np.any(outlier_mask):
                num_outliers = np.sum(outlier_mask)
                if self.verbose:
                    print(f"\n  ⚠️ 三角化后过滤异常点:")
                    print(f"    - 球面半径参考: {sphere_radius:.2f}米")
                    print(f"    - Z坐标（深度）阈值: [{z_negative_threshold:.2f}, {z_abs_threshold:.2f}]米")
                    print(f"    - 范数阈值: {norm_abs_threshold:.2f}米")
                    print(f"    - 检测到 {num_outliers} 个异常点（{num_outliers/len(points_3d_array)*100:.1f}%）")
                    print(f"    - Z坐标（深度）异常: {np.sum(z_outlier_mask)} 个")
                    print(f"    - 范数异常: {np.sum(norm_outlier_mask)} 个")
                    if enable_point_height_constraint and constraint_mode == 'filter':
                        print(f"    - Y坐标（高度）异常: {np.sum(y_outlier_mask)} 个")
                    elif enable_point_height_constraint and constraint_mode == 'scale':
                        print(f"    - Y坐标（高度）约束: 已使用缩放模式，所有点的高度已调整")
                    print(f"    - Z坐标（深度）范围: [{np.min(z_values):.2f}, {np.max(z_values):.2f}]米")
                    print(f"    - Z坐标（深度）中位数: {z_median:.2f}米, MAD: {z_mad:.2f}米")
                    print(f"    - 点范数范围: [{np.min(point_norms):.2f}, {np.max(point_norms):.2f}]米")
                    print(f"    - 点范数中位数: {norm_median:.2f}米, MAD: {norm_mad:.2f}米")
                
                # 过滤异常点
                points_3d_array = points_3d_array[~outlier_mask]
                
                if self.verbose:
                    if len(points_3d_array) > 0:
                        print(f"    ✅ 过滤后保留 {len(points_3d_array)} 个有效点")
                        print(f"    - 过滤后Z坐标（深度）范围: [{np.min(points_3d_array[:, 2]):.2f}, {np.max(points_3d_array[:, 2]):.2f}]米")
                        print(f"    - 过滤后Y坐标（高度）范围: [{np.min(points_3d_array[:, 1]):.2f}, {np.max(points_3d_array[:, 1]):.2f}]米")
                        print(f"    - 过滤后点范数范围: [{np.min(np.linalg.norm(points_3d_array, axis=1)):.2f}, {np.max(np.linalg.norm(points_3d_array, axis=1)):.2f}]米")
                    else:
                        print(f"    ⚠️ 警告: 过滤后没有剩余的点")
        
        # 🔧 点云高度约束：在最终过滤后再次检查高度/长度比例
        if len(points_3d_array) > 0:
            enable_point_height_constraint = self.sar_params.get('enable_point_height_constraint')
            if enable_point_height_constraint is None:
                raise ValueError("enable_point_height_constraint 必须在config.py中设置（--sfm_enable_point_height_constraint）")
            height_length_ratio = self.sar_params.get('point_height_length_ratio')
            if height_length_ratio is None:
                raise ValueError("point_height_length_ratio 必须在config.py中设置（--sfm_point_height_length_ratio）")
            constraint_mode = self.sar_params.get('point_height_constraint_mode')
            if constraint_mode is None:
                raise ValueError("point_height_constraint_mode 必须在config.py中设置（--sfm_point_height_constraint_mode）")
            
            if enable_point_height_constraint:
                # 计算X和Z方向的范围（水平方向，长度）
                x_range = np.max(points_3d_array[:, 0]) - np.min(points_3d_array[:, 0])
                z_range = np.max(points_3d_array[:, 2]) - np.min(points_3d_array[:, 2])
                length_range = max(x_range, z_range)
                
                # 计算Y坐标（高度）范围
                y_range = np.max(points_3d_array[:, 1]) - np.min(points_3d_array[:, 1])
                
                # 计算当前高度/长度比例
                current_ratio = y_range / length_range if length_range > 1e-6 else 0.0
                
                # 🔧 修复：如果使用缩放模式且比例超过阈值，再次应用缩放
                if constraint_mode == 'scale' and current_ratio > height_length_ratio:
                    # 计算Y坐标的中心值
                    y_center = np.median(points_3d_array[:, 1])
                    # 计算允许的Y坐标范围（基于长度范围和比例阈值）
                    max_y_range = length_range * height_length_ratio
                    # 计算缩放因子
                    scale_factor = max_y_range / y_range if y_range > 1e-6 else 1.0
                    # 缩放所有点的Y坐标（相对于中心）
                    points_3d_array[:, 1] = y_center + (points_3d_array[:, 1] - y_center) * scale_factor
                    
                    if self.verbose:
                        print(f"\n  🔧 点云高度约束（最终缩放）:")
                        print(f"    - 当前高度/长度比例: {current_ratio:.4f} (阈值: {height_length_ratio:.4f})")
                        print(f"    - 缩放因子: {scale_factor:.4f}")
                        print(f"    - 缩放后Y范围: {np.max(points_3d_array[:, 1]) - np.min(points_3d_array[:, 1]):.2f}米")
                
                if self.verbose:
                    # 重新计算比例（可能已经缩放）
                    y_range_final = np.max(points_3d_array[:, 1]) - np.min(points_3d_array[:, 1])
                    current_ratio_final = y_range_final / length_range if length_range > 1e-6 else 0.0
                    
                    print(f"\n  📊 点云高度/长度比例检查（最终）:")
                    print(f"    - X范围: {x_range:.2f}米")
                    print(f"    - Z范围: {z_range:.2f}米")
                    print(f"    - Y范围（高度）: {y_range_final:.2f}米")
                    print(f"    - 当前高度/长度比例: {current_ratio_final:.4f}")
                    print(f"    - 推荐高度/长度比例: {height_length_ratio:.4f}")
                    print(f"    - 约束模式: {constraint_mode}")
                    
                    if current_ratio_final > height_length_ratio:
                        if constraint_mode == 'filter':
                            print(f"    ⚠️ 警告: 高度/长度比例 ({current_ratio_final:.4f}) 超过推荐值 ({height_length_ratio:.4f})")
                            print(f"      点云高度约束已应用，已过滤超出范围的点")
                        else:
                            print(f"    ⚠️ 警告: 高度/长度比例 ({current_ratio_final:.4f}) 超过推荐值 ({height_length_ratio:.4f})")
                            print(f"      点云高度约束已应用，已缩放所有点的高度")
                    else:
                        print(f"    ✅ 高度/长度比例在合理范围内")
        
        # 检查3D点坐标的单位和尺度
        # 如果3D点坐标的尺度异常大（可能是像素单位），需要归一化
        if len(points_3d_array) > 0:
            # 获取SAR参数用于诊断
            sar_params = self.sar_params
            camera_height = sar_params.get('camera_height', 1365.0)
            
            # 诊断：检查3D点坐标的尺度
            point_norms = np.linalg.norm(points_3d_array, axis=1)
            median_norm = np.median(point_norms)
            max_norm = np.max(point_norms)
            min_norm = np.min(point_norms)
            
            if self.verbose:
                print(f"\n  📊 3D点坐标尺度诊断:")
                print(f"    - 点数: {len(points_3d_array)}")
                print(f"    - 坐标范围: [{points_3d_array.min(axis=0)}, {points_3d_array.max(axis=0)}]")
                print(f"    - 范数范围: [{min_norm:.2f}, {max_norm:.2f}]米")
                print(f"    - 中位数范数: {median_norm:.2f}米")
                
                # 检查是否异常大（可能是像素单位）
                if median_norm > 10000:
                    print(f"    ⚠️ 警告: 3D点坐标尺度异常大（中位数范数>{median_norm:.2f}米）")
                    print(f"      可能原因:")
                    print(f"        1. 坐标系单位不匹配（可能是像素而非米）")
                    print(f"        2. SAR参数不匹配（camera_height={camera_height}米, fs, prf等）")
                    print(f"        3. 三角化时使用的俯视角与SAR参数不匹配")
                    print(f"      建议: 检查SAR参数是否与实际数据匹配")
            
            # 计算3D点的统计信息（用于归一化）
            point_norms = np.linalg.norm(points_3d_array, axis=1)
            median_norm = np.median(point_norms)
            max_norm = np.max(point_norms)
            
            # 如果3D点的中位数范数远大于雷达位置（例如>10000米），可能是单位不匹配
            # 检查雷达位置的典型尺度（应该是几百到几千米）
            if len(poses) > 0:
                sample_pose = list(poses.values())[0]
                sample_radar_pos = -sample_pose['R'].T @ sample_pose['t'].flatten()
                radar_norm = np.linalg.norm(sample_radar_pos)
                
                # 归一化条件：如果3D点范数异常大（>10000米），或者明显大于雷达位置（>2倍），进行归一化
                # 放宽条件：从10倍改为2倍，因为即使2倍也可能表示单位不匹配
                should_normalize = False
                if median_norm > 10000:  # 如果3D点范数大于10000米，强制归一化
                    should_normalize = True
                    reason = f"3D点范数异常大（{median_norm:.2f}米 > 10000米）"
                elif median_norm > radar_norm * 2 and median_norm > 5000:  # 如果3D点范数是雷达位置的2倍以上且>5000米
                    should_normalize = True
                    reason = f"3D点范数是雷达位置的{median_norm/radar_norm:.2f}倍（>2倍）"
                
                if should_normalize:
                    if self.verbose:
                        print(f"\n  ⚠️ 检测到3D点坐标尺度异常: {reason}")
                        print(f"    - 3D点中位数范数: {median_norm:.2f}米")
                        print(f"    - 雷达位置范数: {radar_norm:.2f}米")
                        print(f"    - 比例: {median_norm/radar_norm:.2f}倍")
                        print(f"    - 尝试归一化3D点坐标...")
                        print(f"    - 可能原因:")
                        print(f"      1. SAR参数不匹配（camera_height={camera_height}米可能不正确）")
                        print(f"      2. 坐标系单位问题（可能是像素而非米）")
                        print(f"      3. 三角化时使用的俯视角与SAR参数不匹配")
                    
                    # 计算3D点的中心
                    point_center = np.median(points_3d_array, axis=0)
                    
                    # 计算3D点的尺度（使用中位数绝对偏差）
                    point_centered = points_3d_array - point_center
                    point_mad = np.median(np.abs(point_centered), axis=0)
                    point_scale = np.median(point_mad)
                    
                    # 如果尺度异常大，归一化到合理范围（例如，以雷达位置为参考）
                    # 放宽条件：从5倍改为2倍
                    if point_scale > radar_norm * 2 or median_norm > 10000:
                        # 归一化：将3D点缩放到与雷达位置相似的尺度
                        # 使用更合理的缩放因子：基于参考斜距R0，而不是雷达位置
                        # 对于SAR场景，参考斜距R0 = camera_height / sin(俯视角)
                        # 典型值：camera_height=12000米，俯视角=15°，R0≈46364米
                        # 但3D点应该在场景中心附近，所以应该比R0小得多（几百到几千米）
                        # 使用更合理的缩放：将3D点缩放到雷达位置尺度的0.1-1倍
                        if point_scale > 0:
                            # 计算缩放因子：目标是将3D点缩放到雷达位置尺度的0.3倍左右（更保守）
                            # 对于SAR场景，3D点应该在场景中心（原点附近），距离雷达位置应该在R0的0.1-0.5倍
                            target_scale = radar_norm * 0.3  # 目标尺度：雷达位置的0.3倍（更保守）
                            scale_factor = target_scale / point_scale
                            # 限制缩放因子范围，避免过度缩放，但允许更大的缩放（从0.01改为0.001）
                            scale_factor = max(0.001, min(1.0, scale_factor))
                        else:
                            scale_factor = 1.0
                        
                        points_3d_array_original = points_3d_array.copy()
                        points_3d_array = point_center + (points_3d_array - point_center) * scale_factor
                        
                        # 额外检查：如果归一化后仍有异常大的点，进行二次归一化
                        point_norms_after = np.linalg.norm(points_3d_array, axis=1)
                        max_norm_after = np.max(point_norms_after)
                        if max_norm_after > radar_norm * 3:
                            # 仍有异常大的点，进行更激进的归一化
                            # 将所有点限制在雷达位置范数的2倍以内
                            outlier_mask = point_norms_after > radar_norm * 2
                            if np.any(outlier_mask):
                                # 对异常点进行额外的缩放
                                for i in np.where(outlier_mask)[0]:
                                    point_dir = points_3d_array[i] - point_center
                                    point_dir_norm = np.linalg.norm(point_dir)
                                    if point_dir_norm > 0:
                                        # 将异常点缩放到雷达位置范数的1.5倍
                                        new_norm = radar_norm * 1.5
                                        points_3d_array[i] = point_center + point_dir / point_dir_norm * new_norm
                                
                                if self.verbose:
                                    print(f"    - 二次归一化: 将 {np.sum(outlier_mask)} 个异常点缩放到合理范围")
                                    print(f"    - 二次归一化后最大范数: {np.max(np.linalg.norm(points_3d_array, axis=1)):.2f}米")
                        
                        if self.verbose:
                            print(f"    - 归一化因子: {scale_factor:.6f}")
                            print(f"    - 归一化前中位数范数: {median_norm:.2f}米")
                            print(f"    - 归一化后中位数范数: {np.median(np.linalg.norm(points_3d_array, axis=1)):.2f}米")
                            print(f"    - 归一化后坐标范围: [{points_3d_array.min(axis=0)}, {points_3d_array.max(axis=0)}]")
                            
                            # 验证归一化后的合理性
                            normalized_norm = np.median(np.linalg.norm(points_3d_array, axis=1))
                            if normalized_norm < radar_norm * 0.01 or normalized_norm > radar_norm * 5:
                                print(f"    ⚠️ 警告: 归一化后尺度仍然异常（{normalized_norm:.2f}米），可能需要检查SAR参数")
                            else:
                                print(f"    ✅ 归一化成功，3D点尺度已调整到合理范围")
        
        return points_3d_array
    
    def _triangulate_point(self, pt1, pt2, R1, t1, R2, t2, angles1, angles2):
        """
        基于SAR几何的三角化
        
        根据论文 "Keypoint-Based SAR Structure From Motion via Riemannian Optimization":
        - 使用斜距方程进行三角化，而不是透视投影的DLT方法
        - SAR三角化的关键：
          1. 使用斜距方程：R = |P_target - P_radar(t)|
        2. 考虑两个视角的斜距约束
        3. 避免使用透视投影假设
        - 三角化方法：使用两个球面的交点
          - 球1：以P_radar1为中心，半径为R1_obs
          - 球2：以P_radar2为中心，半径为R2_obs
        - 根据论文，这是解决形状畸变的关键
        
        Args:
            pt1, pt2: 图像点坐标 (2,) - (x, y)，x=方位向，y=距离向
            R1, t1: 图像1的旋转和平移（从世界坐标系到雷达坐标系）
            R2, t2: 图像2的旋转和平移
            angles1, angles2: 图像1和2的角度信息（包含俯视角）
        
        Returns:
            point_3d: 3D点坐标 (3,) - 世界坐标系，如果三角化失败则返回None
        """
        # 获取SAR参数
        sar_params = self.sar_params
        
        # 计算雷达位置（在世界坐标系中）
        P_radar1 = -R1.T @ t1.flatten()
        P_radar2 = -R2.T @ t2.flatten()
        
        # 从图像坐标计算斜距
        # 图像坐标y对应距离向（斜距）
        Nr = sar_params.get('Nr', 512)
        fs = sar_params.get('fs', 1.1 * 240e6)
        C = sar_params.get('C', 3e8)
        camera_height = sar_params.get('camera_height', 1365.0)
        
        # 计算像素对应的物理尺寸
        range_pixel_size = C / (2 * fs)
        
        # 获取俯视角（用于显示和诊断）
        # 注意：如果启用了循环俯视角模式，angles1和angles2中的depression是循环俯视角
        dep1 = angles1.get('depression', 31.57) if angles1 else 31.57
        dep2 = angles2.get('depression', 31.57) if angles2 else 31.57
        dep1_rad = np.deg2rad(dep1)
        dep2_rad = np.deg2rad(dep2)
        
        # 🔧 重要修复：计算参考斜距R0
        # 问题：之前使用每个图像的俯视角单独计算R0，导致与相机位置不一致
        # 解决：使用相机的实际位置（已经应用了统一的radius_scale）
        # 
        # 相机位置已经通过compute_sar_camera_pose计算，并应用了统一的radius_scale
        # 所以R0应该是相机到原点的实际距离，而不是基于俯视角重新计算
        R0_1 = np.linalg.norm(P_radar1)  # 相机1到原点的实际距离
        R0_2 = np.linalg.norm(P_radar2)  # 相机2到原点的实际距离
        
        # 为了诊断，也计算理论R0（基于俯视角和camera_height）
        R0_1_theory = camera_height / np.sin(dep1_rad)
        R0_2_theory = camera_height / np.sin(dep2_rad)
        
        # 诊断：检查R0计算的合理性（仅前几次）
        if self.verbose and not hasattr(self, '_triangulate_R0_diagnostic'):
            self._triangulate_R0_diagnostic = True
            print(f"\n  🔍 三角化R0计算诊断（已修复）:")
            print(f"    - camera_height: {camera_height}米")
            print(f"    - 图像1俯视角: {dep1}° -> 理论R0: {R0_1_theory:.2f}米")
            print(f"    - 图像2俯视角: {dep2}° -> 理论R0: {R0_2_theory:.2f}米")
            print(f"    - 实际R0_1（相机1到原点距离）: {R0_1:.2f}米 ✅")
            print(f"    - 实际R0_2（相机2到原点距离）: {R0_2:.2f}米 ✅")
            print(f"    - radius_scale效果: 理论{R0_1_theory:.0f}m → 实际{R0_1:.0f}m (×{R0_1/R0_1_theory:.4f})")
            print(f"    - range_pixel_size: {range_pixel_size:.6f}米/像素")
            print(f"    ℹ️ 修复: 使用相机实际位置而非基于俯视角重新计算R0")
        
        # 从图像坐标计算观测的斜距
        # 注意：图像坐标y对应距离向（斜距），图像中心在(Nr/2, Na/2)
        y1_norm = (pt1[1] - Nr / 2.0) * range_pixel_size
        y2_norm = (pt2[1] - Nr / 2.0) * range_pixel_size
        
        R1_obs = R0_1 + y1_norm
        R2_obs = R0_2 + y2_norm
        
        # 诊断：检查斜距计算的合理性（仅前几次）
        if self.verbose and not hasattr(self, '_triangulate_diagnostic_count'):
            self._triangulate_diagnostic_count = 0
        
        if self.verbose and self._triangulate_diagnostic_count < 3:
            print(f"\n  🔍 三角化诊断 (第{self._triangulate_diagnostic_count+1}次):")
            print(f"    - 图像1坐标: ({pt1[0]:.1f}, {pt1[1]:.1f}) 像素")
            print(f"    - 图像2坐标: ({pt2[0]:.1f}, {pt2[1]:.1f}) 像素")
            print(f"    - 图像1俯视角: {dep1:.2f}°")
            print(f"    - 图像2俯视角: {dep2:.2f}°")
            print(f"    - R0_1: {R0_1:.2f}米")
            print(f"    - R0_2: {R0_2:.2f}米")
            print(f"    - y1_norm: {y1_norm:.2f}米")
            print(f"    - y2_norm: {y2_norm:.2f}米")
            print(f"    - R1_obs: {R1_obs:.2f}米")
            print(f"    - R2_obs: {R2_obs:.2f}米")
            print(f"    - 雷达1位置: {P_radar1}")
            print(f"    - 雷达2位置: {P_radar2}")
            self._triangulate_diagnostic_count += 1
        
        # ========== 根据论文的三角化方法：两个球面的交点（完整实现）==========
        
        # 根据论文：使用两个球面的交点进行三角化
        # 球1：以P_radar1为中心，半径为R1_obs
        # 球2：以P_radar2为中心，半径为R2_obs
        # 这是SAR三角化的核心方法，完全基于斜距约束，不使用透视投影假设
        
        # 计算两个雷达之间的距离
        d = np.linalg.norm(P_radar2 - P_radar1)
        
        if d < 1e-6:
            # 两个雷达位置太近，无法三角化
            if self.verbose and self._triangulate_diagnostic_count < 3:
                print(f"    ⚠️ 警告: 两个雷达位置太近（d={d:.6f}米），无法三角化")
            return None
        
        # 计算从P_radar1指向P_radar2的单位向量
        u = (P_radar2 - P_radar1) / d
        
        # 检查球面是否相交
        # 根据论文，两个球面相交的条件是：|R1 - R2| <= d <= R1 + R2
        min_range = min(R1_obs, R2_obs)
        max_range = max(R1_obs, R2_obs)
        spheres_intersect = (abs(max_range - min_range) <= d <= min_range + max_range)
        
        # 诊断：检查球面是否可能相交
        if self.verbose and self._triangulate_diagnostic_count < 3:
            if not spheres_intersect:
                if d > min_range + max_range:
                    print(f"    ⚠️ 警告: 两个球面不可能相交（d={d:.2f}米 > R1+R2={min_range+max_range:.2f}米）")
                elif d < abs(max_range - min_range):
                    print(f"    ⚠️ 警告: 一个球面完全包含另一个（d={d:.2f}米 < |R1-R2|={abs(max_range-min_range):.2f}米）")
        
        # 如果球面不相交，根据论文，这表示观测数据不一致或存在误差
        # 论文中的方法要求球面必须相交，如果不相交，应该返回None
        # 但在实际应用中，由于观测误差，可能需要处理这种情况
        # 这里我们使用严格的球面交点方法，如果球面不相交，返回None
        if not spheres_intersect:
            # 根据论文，如果球面不相交，说明观测数据不一致
            # 返回None，让调用者处理（可能尝试其他图像对）
            if self.verbose and not hasattr(self, '_warned_sphere_no_intersection'):
                print(f"  ⚠️ 警告: 球面不相交，观测数据可能不一致，跳过此三角化")
                self._warned_sphere_no_intersection = True
            return None
        
        # ========== 两个球面相交，使用标准的球面交点计算方法（完全符合论文）==========
        
        # 根据论文，两个球面的交点计算：
        # 设两个球面方程：
        #   |P - P_radar1|² = R1_obs²
        #   |P - P_radar2|² = R2_obs²
        # 
        # 交点位于两个球面的交圆上，该圆在垂直于u的平面上
        # 交点位置：P = P_radar1 + a*u + h*v，其中：
        #   - u是从P_radar1指向P_radar2的单位向量
        #   - a是交点到P_radar1沿u方向的距离
        #   - h是交点到u轴的距离（交圆的半径）
        #   - v是垂直于u的单位向量
        
        # 计算参数a（交点到P_radar1沿u方向的距离）
        a = (R1_obs**2 - R2_obs**2 + d**2) / (2 * d)
        
        # 计算h²（交圆半径的平方）
        h_sq = R1_obs**2 - a**2
        
        # 诊断：检查a和h_sq的合理性
        if self.verbose and self._triangulate_diagnostic_count < 3:
            print(f"    - 雷达间距离d: {d:.2f}米")
            print(f"    - 参数a: {a:.2f}米")
            print(f"    - h_sq: {h_sq:.2f}米²")
        
        # 检查h_sq是否有效（由于数值误差，可能略小于0）
        if h_sq < -1e-6:
            # 如果h_sq明显为负，说明球面不相交（数值误差过大）
            if self.verbose and self._triangulate_diagnostic_count < 3:
                print(f"    ⚠️ 警告: h_sq={h_sq:.6f} < 0，球面不相交（数值误差）")
            return None
        
        # 处理数值误差：如果h_sq略小于0，设为0（相切情况）
        h_sq = max(0, h_sq)
        h = np.sqrt(h_sq)
        
        # 计算垂直于u的向量v（用于确定交圆的方向）
        # 使用从P_radar1指向原点的方向作为参考（场景中心通常在原点附近）
        to_origin = -P_radar1
        if np.linalg.norm(to_origin) < 1e-6:
            # 如果P_radar1在原点，使用标准方向
            to_origin = np.array([1, 0, 0])
        
        # 计算v：垂直于u的向量
        v = to_origin - np.dot(to_origin, u) * u
        v_norm = np.linalg.norm(v)
        
        if v_norm < 1e-6:
            # 如果to_origin与u平行，使用另一个标准方向
            if abs(u[0]) < 0.9:
                v = np.array([1, 0, 0]) - np.dot([1, 0, 0], u) * u
            else:
                v = np.array([0, 1, 0]) - np.dot([0, 1, 0], u) * u
            v_norm = np.linalg.norm(v)
        
        if v_norm > 1e-6:
            v = v / v_norm
        else:
            # 如果仍然无法确定v，使用第三个标准方向
            v = np.array([0, 0, 1]) - np.dot([0, 0, 1], u) * u
            v = v / (np.linalg.norm(v) + 1e-8)
        
        # 计算两个交点（交圆上的两个点）
        point1 = P_radar1 + a * u + h * v
        point2 = P_radar1 + a * u - h * v
        
        # 验证两个交点的斜距（确保满足球面方程）
        R1_point1 = np.linalg.norm(point1 - P_radar1)
        R2_point1 = np.linalg.norm(point1 - P_radar2)
        R1_point2 = np.linalg.norm(point2 - P_radar1)
        R2_point2 = np.linalg.norm(point2 - P_radar2)
        
        # 计算相对误差
        error1_point1 = abs(R1_point1 - R1_obs) / max(R1_obs, 1e-6)
        error2_point1 = abs(R2_point1 - R2_obs) / max(R2_obs, 1e-6)
        error1_point2 = abs(R1_point2 - R1_obs) / max(R1_obs, 1e-6)
        error2_point2 = abs(R2_point2 - R2_obs) / max(R2_obs, 1e-6)
        
        # 选择斜距误差较小的交点（更符合观测数据）
        total_error1 = error1_point1 + error2_point1
        total_error2 = error1_point2 + error2_point2
        
        # 🔧 SAR几何约束：优先选择Z坐标更合理的点
        # SAR是斜视成像，目标通常在相机下方（Z < 相机Z），但不会太深
        # 对于地面目标，Z坐标应该在合理范围内（接近0或略负）
        radar1_z = P_radar1[2]
        radar2_z = P_radar2[2]
        min_radar_z = min(radar1_z, radar2_z)
        
        # 计算两个交点的Z坐标合理性
        # 对于SAR，目标通常在相机下方，Z坐标应该在 [min_radar_z - sphere_radius*0.5, min_radar_z] 范围内
        sphere_radius = max(R0_1, R0_2)
        z_reasonable_low = min_radar_z - sphere_radius * 0.3  # 允许目标在相机下方30%球面半径
        z_reasonable_high = min_radar_z + sphere_radius * 0.1  # 允许目标略高于最低相机
        
        # 计算Z坐标合理性得分（越接近合理范围得分越高）
        z1_score = 1.0 if z_reasonable_low <= point1[2] <= z_reasonable_high else 0.0
        z2_score = 1.0 if z_reasonable_low <= point2[2] <= z_reasonable_high else 0.0
        
        # 如果Z坐标都在合理范围内，选择斜距误差较小的
        # 如果只有一个在合理范围内，优先选择它
        # 如果都不在合理范围内，仍然选择斜距误差较小的（让优化过程修正）
        if z1_score > z2_score:
            point_3d = point1
            selected_error = total_error1
        elif z2_score > z1_score:
            point_3d = point2
            selected_error = total_error2
        else:
            # Z坐标合理性相同，选择斜距误差较小的
            if total_error1 < total_error2:
                point_3d = point1
                selected_error = total_error1
            else:
                point_3d = point2
                selected_error = total_error2
        
        # 如果两个交点的误差都很大（>10%），说明观测数据可能有问题
        # 根据论文，这种情况应该被标记或拒绝
        if selected_error > 0.1:
            if self.verbose and self._triangulate_diagnostic_count < 3:
                print(f"    ⚠️ 警告: 三角化点斜距误差较大（{selected_error*100:.1f}%），观测数据可能不一致")
            # 仍然返回点，但标记为可能有问题（后续优化会修正）
        
        # 诊断：检查三角化结果的合理性（仅前几次）
        if self.verbose and self._triangulate_diagnostic_count < 3:
            point_range1 = np.linalg.norm(point_3d - P_radar1)
            point_range2 = np.linalg.norm(point_3d - P_radar2)
            print(f"    - 三角化点坐标: {point_3d}")
            print(f"    - 点到雷达1的距离: {point_range1:.2f}米 (期望: {R1_obs:.2f}米)")
            print(f"    - 点到雷达2的距离: {point_range2:.2f}米 (期望: {R2_obs:.2f}米)")
            print(f"    - 距离误差1: {abs(point_range1 - R1_obs):.2f}米 ({abs(point_range1 - R1_obs)/R1_obs*100:.1f}%)")
            print(f"    - 距离误差2: {abs(point_range2 - R2_obs):.2f}米 ({abs(point_range2 - R2_obs)/R2_obs*100:.1f}%)")
            # SAR几何诊断：检查深度合理性（Z坐标是深度方向）
            print(f"    - SAR几何检查:")
            print(f"      - 雷达1 Y坐标（高度）: {P_radar1[1]:.2f}米, Z坐标（深度）: {P_radar1[2]:.2f}米")
            print(f"      - 雷达2 Y坐标（高度）: {P_radar2[1]:.2f}米, Z坐标（深度）: {P_radar2[2]:.2f}米")
            print(f"      - 三角化点Y坐标（高度）: {point_3d[1]:.2f}米, Z坐标（深度）: {point_3d[2]:.2f}米")
            print(f"      - Z坐标（深度）合理性范围: [{z_reasonable_low:.2f}, {z_reasonable_high:.2f}]米")
            if z_reasonable_low <= point_3d[2] <= z_reasonable_high:
                print(f"      ✅ Z坐标（深度）在合理范围内（SAR斜视几何）")
            else:
                print(f"      ⚠️ Z坐标（深度）超出合理范围，可能使用了透视投影假设")
            
            # 检查点坐标是否异常大
            point_norm = np.linalg.norm(point_3d)
            radar1_norm = np.linalg.norm(P_radar1)
            radar2_norm = np.linalg.norm(P_radar2)
            
            # 计算点到原点的距离（场景中心应该在原点附近）
            dist_to_origin = point_norm
            
            # 计算点到雷达的平均距离
            avg_dist_to_radars = (R1_obs + R2_obs) / 2.0
            
            if point_norm > 10000:
                print(f"    ⚠️ 警告: 三角化点坐标异常大（范数={point_norm:.2f}米）")
                print(f"      诊断信息:")
                print(f"        - 点到原点距离: {dist_to_origin:.2f}米")
                print(f"        - 雷达1位置范数: {radar1_norm:.2f}米 (R0_1={R0_1:.2f}米)")
                print(f"        - 雷达2位置范数: {radar2_norm:.2f}米 (R0_2={R0_2:.2f}米)")
                print(f"        - 点到雷达平均距离: {avg_dist_to_radars:.2f}米")
                print(f"        - 球面交点参数: a={a:.2f}米, h={h:.2f}米, d={d:.2f}米")
                print(f"      分析:")
                print(f"        - 雷达位置本身就在很远的地方（{radar1_norm:.0f}米和{radar2_norm:.0f}米）")
                print(f"        - 这是SAR几何的正常现象：雷达在远场，斜距很大（{R1_obs:.0f}米和{R2_obs:.0f}米）")
                print(f"        - 三角化点坐标大是正常的，因为雷达位置和斜距都很大")
                print(f"        - 如果距离误差为0，说明三角化计算是正确的")
                print(f"        - 后续优化过程会修正点云位置，使其更接近场景中心")
                print(f"      注意:")
                print(f"        - 这不是坐标系错用的问题，而是SAR远场几何的特点")
                print(f"        - 如果点云最终需要归一化到原点附近，可以在优化后进行")
        
        # 验证点的合理性（放宽约束以提高成功率）
        # 检查斜距是否匹配
        R1_calc = np.linalg.norm(point_3d - P_radar1)
        R2_calc = np.linalg.norm(point_3d - P_radar2)
        
        error1 = abs(R1_calc - R1_obs) / max(R1_obs, 1e-6)
        error2 = abs(R2_calc - R2_obs) / max(R2_obs, 1e-6)
        
        # 放宽误差阈值：从50%放宽到100%（允许更大的误差，后续优化会修正）
        max_error_threshold = 1.0  # 100%误差阈值
        
        # 如果误差过大，尝试修正点位置
        # 方法：将点投影到两个球面的平均位置
        if error1 > max_error_threshold or error2 > max_error_threshold:
            # 尝试第二个交点
            if abs(point2[2]) < abs(point1[2]):
                point_3d_candidate = point2
            else:
                point_3d_candidate = point1
            
            R1_calc_candidate = np.linalg.norm(point_3d_candidate - P_radar1)
            R2_calc_candidate = np.linalg.norm(point_3d_candidate - P_radar2)
            error1_candidate = abs(R1_calc_candidate - R1_obs) / max(R1_obs, 1e-6)
            error2_candidate = abs(R2_calc_candidate - R2_obs) / max(R2_obs, 1e-6)
            
            # 选择误差较小的交点
            if error1_candidate + error2_candidate < error1 + error2:
                point_3d = point_3d_candidate
                R1_calc = R1_calc_candidate
                R2_calc = R2_calc_candidate
                error1 = error1_candidate
                error2 = error2_candidate
            
            # 如果误差仍然很大，尝试修正点位置
            # 将点投影到两个球面的平均位置
            if error1 > max_error_threshold or error2 > max_error_threshold:
                # 计算从雷达到点的方向
                dir1 = (point_3d - P_radar1)
                dir1_norm = np.linalg.norm(dir1)
                if dir1_norm > 1e-6:
                    dir1 = dir1 / dir1_norm
                    # 将点投影到正确的斜距
                    point_3d_corrected1 = P_radar1 + R1_obs * dir1
                else:
                    point_3d_corrected1 = point_3d
                
                dir2 = (point_3d - P_radar2)
                dir2_norm = np.linalg.norm(dir2)
                if dir2_norm > 1e-6:
                    dir2 = dir2 / dir2_norm
                    point_3d_corrected2 = P_radar2 + R2_obs * dir2
                else:
                    point_3d_corrected2 = point_3d
                
                # 使用两个修正位置的平均值
                point_3d = (point_3d_corrected1 + point_3d_corrected2) / 2.0
                
                # 重新计算误差
                R1_calc = np.linalg.norm(point_3d - P_radar1)
                R2_calc = np.linalg.norm(point_3d - P_radar2)
                error1 = abs(R1_calc - R1_obs) / max(R1_obs, 1e-6)
                error2 = abs(R2_calc - R2_obs) / max(R2_obs, 1e-6)
                
                # 如果修正后误差仍然很大，记录警告
                if (error1 > max_error_threshold or error2 > max_error_threshold) and \
                   not hasattr(self, '_warned_triangulation_error'):
                    if self.verbose:
                        print(f"  ⚠️ 警告: 部分三角化点的斜距误差较大（>{max_error_threshold*100:.0f}%），但保留用于后续优化")
                        self._warned_triangulation_error = True
        
        # 放宽深度约束：使用可配置的深度因子（默认2.0，允许更大的深度变化）
        # 注意：Z坐标是深度方向（COLMAP约定：Z轴向前），不是高度
        camera_height = sar_params.get('camera_height', 1365.0)
        depth_factor = sar_params.get('point_cloud_depth_factor', 2.0)  # 默认2.0，可配置
        max_z = camera_height * depth_factor  # Z坐标（深度）范围：camera_height * depth_factor
        
        if abs(point_3d[2]) > max_z:
            # Z坐标（深度）过大，尝试另一个交点
            if abs(point2[2]) < abs(point1[2]):
                point_3d = point2
                # 再次检查Z坐标（深度）
                if abs(point_3d[2]) > max_z:
                    # 即使Z坐标（深度）过大，仍然返回点（后续优化会修正）
                    if self.verbose and not hasattr(self, '_warned_z_coordinate'):
                        print(f"  ⚠️ 警告: 部分三角化点的Z坐标（深度）较大（>{max_z:.1f}米），但保留用于后续优化")
                        self._warned_z_coordinate = True
        
        return point_3d
    
    def _optimize_poses_height_only(self, poses, points_3d, point_tracks,
                                    keypoints_dict, image_angles):
        """
        俯视角与方位角固定为 image_angles 中的数据；所有相机共享一个平台高度；
        仅对共享 camera_height 做一维优化，位姿由 sar_geometry.compute_sar_camera_pose 完全决定。
        """
        cached = getattr(self, '_height_only_poses_cached', None)
        if cached is not None:
            return cached

        if self.sar_params.get('mstar_view_match_height_applied') or self.sar_params.get(
            'sfm_mstar_view_match_height'
        ):
            if self.verbose:
                print(
                    "\n  [INFO] 已启用多视角高度闭合，跳过 SO-RCG height-only 一维搜索"
                )
            h0 = float(self.sar_params.get('camera_height', self.sar_params.get('mstar_init_camera_height_m', 5.0)))
            from sar.geometry import compute_sar_camera_pose
            out = {}
            for img_name in poses.keys():
                ang = image_angles.get(img_name, {}) if image_angles else {}
                dep = float(ang.get('depression', 31.57))
                azi = float(ang.get('azimuth', 0.0))
                R_cam, t_cam, _ = compute_sar_camera_pose(dep, azi, self.sar_params)
                out[img_name] = {'R': R_cam, 't': t_cam}
            self._height_only_poses_cached = out
            return out

        from scipy.optimize import minimize_scalar
        try:
            from .geometry import compute_sar_camera_pose
        except ImportError as e:
            raise ImportError("需要 sar_geometry.compute_sar_camera_pose") from e

        sp_base = dict(self.sar_params)
        h0 = float(sp_base.get('camera_height', 12000.0))

        # MSTAR 初值已被 DEFAULT 12000 / convert 物理高度污染时，强制回到闭合 H
        if sp_base.get('mstar_init_from_pixel_resolution'):
            h_mstar = float(sp_base.get('mstar_init_camera_height_m', 0.0) or 0.0)
            if h_mstar > 0 and h0 > max(50.0, h_mstar * 20.0):
                if self.verbose:
                    print(
                        f"  ⚠️ height_only 初值 {h0:.2g} m 疑似物理高度，"
                        f"回退 MSTAR 闭合 H={h_mstar:.4g} m"
                    )
                h0 = h_mstar
                sp_base['camera_height'] = h0

        search_ratio = float(sp_base.get('sorc_height_only_search_ratio', 0.35))
        search_ratio = float(np.clip(search_ratio, 0.05, 0.9))

        def pose_map(h):
            sp = dict(sp_base)
            sp['camera_height'] = float(h)
            out = {}
            for img_name in poses.keys():
                ang = image_angles.get(img_name, {}) if image_angles else {}
                dep = float(ang.get('depression', 31.57))
                azi = float(ang.get('azimuth', 0.0))
                R_cam, t_cam, _ = compute_sar_camera_pose(dep, azi, sp)
                out[img_name] = {'R': R_cam, 't': t_cam}
            return out

        def objective(h):
            if h <= 0:
                return 1e30
            ps = pose_map(h)
            sp_h = dict(sp_base)
            sp_h['camera_height'] = float(h)
            total = 0.0
            count = 0
            for img_name, pose in ps.items():
                R_cam = pose['R']
                t_cam = pose['t']
                for pid, track in point_tracks.items():
                    img_idx = None
                    for i, (track_img, track_kp_idx) in enumerate(track):
                        if track_img == img_name:
                            img_idx = i
                            break
                    if img_idx is None or pid >= len(points_3d):
                        continue
                    kp_idx = track[img_idx][1]
                    kp_list = keypoints_dict.get(img_name, [])
                    if kp_idx >= len(kp_list):
                        continue
                    pt = kp_list[kp_idx].pt if hasattr(kp_list[kp_idx], 'pt') else kp_list[kp_idx]
                    point3d = points_3d[pid]
                    angles = image_angles.get(img_name, {}) if image_angles else {}
                    dep = angles.get('depression', 31.57)
                    _, _, err = self.compute_rd_reprojection_error(
                        point3d, R_cam, t_cam.reshape(3, 1), pt, dep, sp_h
                    )
                    total += err
                    count += 1
            return total / max(count, 1)

        lo = max(1e-3, h0 * (1.0 - search_ratio))
        hi = h0 * (1.0 + search_ratio)
        if lo >= hi:
            hi = lo * 2.0

        if self.verbose:
            print(
                f"\n📌 SO-RCG 位姿优化：固定俯仰角/方位角（数据给定），"
                f"仅优化共享平台高度 [{lo:.4g}, {hi:.4g}] m（初值 {h0:.4g} m，±{search_ratio*100:.0f}% 微调）"
            )

        try:
            res = minimize_scalar(
                objective,
                bounds=(lo, hi),
                method='bounded',
                options={'xatol': 0.01, 'maxiter': 200},
            )
            h_opt = float(res.x)
        except Exception as e:
            if self.verbose:
                print(f"  ⚠️ 一维高度优化失败 ({e})，保持初始高度 {h0}")
            h_opt = h0

        self.sar_params['camera_height'] = h_opt
        if self.verbose:
            print(f"  ✅ 优化后共享 camera_height = {h_opt:.4f} m（初值 {h0:.4f} m）")

        out = pose_map(h_opt)
        self._height_only_poses_cached = out
        return out

    def _optimize_poses_sorc(self, poses, points_3d, point_tracks,
                             keypoints_dict, image_angles):
        """使用SO-RCG优化位姿"""
        if self.sar_params.get('ba_fix_angles_optimize_height_only'):
            return self._optimize_poses_height_only(
                poses, points_3d, point_tracks, keypoints_dict, image_angles
            )

        optimized_poses = {}
        
        # 获取初始位置（如果存在）
        initial_positions = getattr(self, '_initial_positions', {})
        
        for img_name, pose in poses.items():
            R = pose['R']
            t = pose['t']
            
            # 构建残差函数
            # 🔧 修复：在残差函数中应用约束，确保优化过程中始终满足俯视角约束
            def residual_func(R_cam):
                # 应用约束（包括俯视角约束和方位角约束）
                R_constrained, t_constrained = self._apply_height_constraint_with_rotation(
                    R_cam, t, img_name, image_angles
                )
                # 应用位置约束（如果存在）
                initial_position = initial_positions.get(img_name, None)
                if initial_position is not None:
                    R_constrained, t_constrained = self._apply_position_constraint(
                        R_constrained, t_constrained, initial_position, img_name
                    )
                
                residuals = []
                for pid, track in point_tracks.items():
                    # 找到该图像在该track中的观测
                    img_idx = None
                    for i, (track_img, track_kp_idx) in enumerate(track):
                        if track_img == img_name:
                            img_idx = i
                            break
                    
                    if img_idx is None:
                        continue
                    
                    kp_idx = track[img_idx][1]
                    kp_list = keypoints_dict.get(img_name, [])
                    if kp_idx >= len(kp_list):
                        continue
                    
                    pt = kp_list[kp_idx].pt if hasattr(kp_list[kp_idx], 'pt') else kp_list[kp_idx]
                    
                    if pid >= len(points_3d):
                        continue
                    
                    point3d = points_3d[pid]
                    # 使用image_angles中的俯视角（如果启用循环模式，则为循环俯视角）
                    angles = image_angles.get(img_name, {}) if image_angles else {}
                    dep = angles.get('depression', 31.57)
                    
                    _, _, error = self.compute_rd_reprojection_error(
                        point3d, R_constrained, t_constrained.reshape(3, 1), pt, dep
                    )
                    residuals.append(error)
                
                return np.array(residuals) if residuals else np.array([0.0])
            
            # SO-RCG优化旋转矩阵
            # 根据步长缩放因子调整最大迭代次数（步长越小，迭代次数越少，避免过度优化）
            max_iter_rotation = 20
            if hasattr(self, '_step_size_scale') and self._step_size_scale < 0.5:
                # 如果步长已经很小，减少迭代次数，避免过度优化
                max_iter_rotation = max(5, int(20 * self._step_size_scale))
            R_opt = self._sorc_update_rotation(R, residual_func, max_iter=max_iter_rotation)
            
            # 🔧 修复：在SO-RCG优化后立即应用约束，确保旋转矩阵满足俯视角约束
            # 虽然residual_func中已经应用了约束，但R_opt本身可能仍然不满足约束
            # 因为约束是在计算误差时应用的，但R本身没有被直接约束
            initial_position = initial_positions.get(img_name, None)
            R_opt, t_constrained = self._apply_height_constraint_with_rotation(R_opt, t, img_name, image_angles)
            if initial_position is not None:
                R_opt, t_constrained = self._apply_position_constraint(R_opt, t_constrained, initial_position, img_name)
            
            # 优化平移向量（使用梯度下降）
            # 优化平移向量（同时应用高度约束，确保指向场景中心）
            R_opt, t_opt = self._optimize_translation(R_opt, t_constrained, points_3d, point_tracks,
                                               keypoints_dict, image_angles, img_name, initial_position)
            
            # 🔧 修复：应用5个DoF约束，传递img_name和image_angles以启用俯视角约束和方位角约束
            R_opt, t_opt = self.apply_5dof_constraint(R_opt, t_opt, img_name, image_angles)
            
            optimized_poses[img_name] = {
                'R': R_opt,
                't': t_opt
            }
        
        return optimized_poses
    
    def _sorc_update_rotation(self, R_init, residual_func, max_iter=10):
        """SO-RCG更新旋转矩阵"""
        R = R_init.copy()
        grad_prev = None
        eta_prev = None
        R_prev = None
        
        for i in range(max_iter):
            # 计算Riemannian梯度
            grad_curr = self.compute_riemannian_gradient_so3(R, residual_func)
            
            # 检查收敛
            if np.linalg.norm(grad_curr) < self.tolerance:
                break
            
            # 计算共轭梯度方向
            if grad_prev is None:
                eta = -grad_curr
            else:
                # 向量传输
                eta_prev_transported = self.vector_transport_so3(eta_prev, R_prev, R)
                
                # Polak-Ribière系数
                beta = self.compute_beta_polak_ribiere(grad_curr, grad_prev, eta_prev_transported)
                
                # 共轭梯度方向
                eta = -grad_curr + beta * eta_prev_transported
            
            # 改进的线搜索（Armijo条件）
            # 使用更保守的初始步长策略，避免发散
            # 自适应步长：根据误差大小和优化历史调整
            base_step_size = 0.05  # 更保守的基础初始步长（从0.2减小到0.05，大幅减小步长以避免异常值影响）
            
            # 根据当前误差调整步长（误差越大，步长越小）
            if hasattr(self, '_current_total_error'):
                # 更保守的误差缩放：误差很大时使用更小的步长
                # 由于现在使用robust误差（过滤异常值），误差应该更小，所以可以适当增大步长
                error_scale = min(2.0, max(0.1, 1e5 / (self._current_total_error + 1e-6)))  # 调整缩放因子以适应robust误差
                base_step_size *= error_scale
            
            # 如果设置了步长缩放因子（由于误差增加），应用它
            if hasattr(self, '_step_size_scale'):
                step_size = base_step_size * self._step_size_scale
            else:
                step_size = base_step_size
            
            # 更保守的回溯参数
            alpha = 0.8  # 回溯因子（从0.7增加到0.8，减小步长更温和）
            beta = 0.03  # Armijo条件参数（从0.05减小到0.03，更容易满足条件）
            max_backtrack = 25  # 增加最大回溯次数（从20增加到25，给更多回溯机会）
            
            error_curr = np.sum(residual_func(R)**2)
            grad_norm = np.linalg.norm(grad_curr)
            
            # Armijo线搜索
            for backtrack_iter in range(max_backtrack):
                R_candidate = self.retract_so3(R, eta, step_size)
                error_candidate = np.sum(residual_func(R_candidate)**2)
                
                # Armijo条件：f(x + α*d) <= f(x) + β*α*<grad, d>
                # 对于最小化问题，d = -grad，所以 <grad, d> = -||grad||^2
                armijo_bound = error_curr - beta * step_size * grad_norm**2
                
                if error_candidate <= armijo_bound:
                    break  # 满足Armijo条件
                else:
                    step_size *= alpha  # 回溯
            
            # 如果回溯后步长太小，使用固定小步长
            if step_size < 1e-6:
                step_size = 1e-6
                R_candidate = self.retract_so3(R, eta, step_size)
            
            # 🔧 修复：限制旋转更新的最大步长，避免产生过大的位姿变化
            # 如果旋转角度太大，说明旋转更新步长太大，需要限制
            # 计算从R到R_candidate的旋转角度
            R_delta = R_candidate @ R.T
            # 使用Rodrigues公式计算旋转角度
            trace = np.trace(R_delta)
            rotation_angle = np.arccos(np.clip((trace - 1) / 2, -1, 1))
            max_rotation_angle = np.deg2rad(10.0)  # 限制每次旋转更新不超过10度
            
            if rotation_angle > max_rotation_angle:
                # 如果旋转角度太大，限制步长
                scale_factor = max_rotation_angle / rotation_angle
                # 重新计算R_candidate，使用更小的步长
                step_size = step_size * scale_factor
                R_candidate = self.retract_so3(R, eta, step_size)
            
            # 更新
            R_prev = R
            R = R_candidate
            grad_prev = grad_curr
            eta_prev = eta
        
        return R
    
    def _optimize_translation(self, R_cam, t_init, points_3d, point_tracks,
                              keypoints_dict, image_angles, img_name, initial_position=None):
        """
        优化平移向量
        
        使用梯度下降优化平移向量，以最小化重投影误差
        添加相机高度（Z坐标）约束，确保相机位置在合理范围内
        同时调整旋转矩阵，确保相机指向场景中心
        添加位置约束，限制相机位置不能偏离初始位置太远
        添加俯视角约束，限制俯视角在合理范围内
        
        Args:
            initial_position: 初始相机位置（用于位置约束），如果为None则不应用位置约束
        
        Returns:
            R_opt: 优化后的旋转矩阵（已应用高度约束）
            t_opt: 优化后的平移向量（已应用高度约束）
        """
        t = t_init.copy()
        
        # 初始应用高度约束（同时调整旋转矩阵，确保指向场景中心）
        R_cam, t = self._apply_height_constraint_with_rotation(R_cam, t, img_name, image_angles)
        
        # 构建误差函数（带高度约束）
        def error_func(t_vec):
            # 应用高度约束（同时调整旋转矩阵，确保指向场景中心）
            R_constrained, t_constrained = self._apply_height_constraint_with_rotation(R_cam, t_vec, img_name, image_angles)
            # 应用位置约束
            if initial_position is not None:
                R_constrained, t_constrained = self._apply_position_constraint(R_constrained, t_constrained, initial_position, img_name)
            
            total_error = 0.0
            count = 0
            for pid, track in point_tracks.items():
                # 找到该图像在该track中的观测
                img_idx = None
                for i, (track_img, track_kp_idx) in enumerate(track):
                    if track_img == img_name:
                        img_idx = i
                        break
                
                if img_idx is None or pid >= len(points_3d):
                    continue
                
                kp_idx = track[img_idx][1]
                kp_list = keypoints_dict.get(img_name, [])
                if kp_idx >= len(kp_list):
                    continue
                
                pt = kp_list[kp_idx].pt if hasattr(kp_list[kp_idx], 'pt') else kp_list[kp_idx]
                point3d = points_3d[pid]
                angles = image_angles.get(img_name, {}) if image_angles else {}
                dep = angles.get('depression', 31.57)
                
                _, _, error = self.compute_rd_reprojection_error(
                    point3d, R_constrained, t_constrained.reshape(3, 1), pt, dep
                )
                total_error += error
                count += 1
            
            return total_error / max(count, 1)
        
        # 梯度下降优化
        base_learning_rate = 0.02  # 更保守的学习率（从0.05减小到0.02，进一步减小学习率）
        
        # 如果设置了步长缩放因子（由于误差增加），应用它
        if hasattr(self, '_step_size_scale'):
            learning_rate = base_learning_rate * self._step_size_scale
        else:
            learning_rate = base_learning_rate
        
        for iter_idx in range(10):
            grad = np.zeros(3)
            epsilon = max(1e-5, np.linalg.norm(t) * 1e-6)
            
            error_curr = error_func(t)
            
            # 数值梯度
            for i in range(3):
                t_perturb = t.copy()
                t_perturb[i] += epsilon
                error_perturb = error_func(t_perturb)
                grad[i] = (error_perturb - error_curr) / epsilon
            
            # 梯度归一化
            grad_norm = np.linalg.norm(grad)
            if grad_norm > 1e-6:
                grad = grad / grad_norm * min(grad_norm, 10.0)
            
            # 更新
            current_lr = learning_rate / (1.0 + iter_idx * 0.1)
            t_new = t - current_lr * grad
            
            # 应用高度约束（同时调整旋转矩阵，确保指向场景中心）
            R_cam_new, t_new = self._apply_height_constraint_with_rotation(R_cam, t_new, img_name, image_angles)
            # 应用位置约束
            if initial_position is not None:
                R_cam_new, t_new = self._apply_position_constraint(R_cam_new, t_new, initial_position, img_name)
            
            # 线搜索
            error_new = error_func(t_new)
            if error_new < error_curr:
                t = t_new
                R_cam = R_cam_new  # 更新旋转矩阵
            else:
                t = t - current_lr * 0.5 * grad
                # 再次应用高度约束
                R_cam, t = self._apply_height_constraint_with_rotation(R_cam, t, img_name, image_angles)
                # 再次应用位置约束
                if initial_position is not None:
                    R_cam, t = self._apply_position_constraint(R_cam, t, initial_position, img_name)
            
            # 早停
            if error_curr < 1e-3:
                break
        
        # 最终应用高度约束，确保返回的旋转矩阵和平移向量满足约束
        R_cam, t = self._apply_height_constraint_with_rotation(R_cam, t, img_name, image_angles)
        
        # 最终应用位置约束
        if initial_position is not None:
            R_cam, t = self._apply_position_constraint(R_cam, t, initial_position, img_name)
        
        return R_cam, t
    
    def _optimize_points_3d(self, poses, points_3d, point_tracks,
                            keypoints_dict, image_angles):
        """优化3D点（使用最小二乘）"""
        height_only = bool(self.sar_params.get('ba_fix_angles_optimize_height_only', False))
        # 固定角度模式：GPU 路径逐点循环 + 数值梯度 + 频繁 .item() 同步，比 CPU 多线程更慢
        use_gpu_for_points = bool(self.use_gpu) and not height_only
        if use_gpu_for_points:
            return self._optimize_points_3d_gpu(poses, points_3d, point_tracks,
                                               keypoints_dict, image_angles)
        if self.use_gpu and height_only and self.verbose and not getattr(
            self, '_gpu_height_only_points_cpu_warned', False
        ):
            print(
                f"  ℹ️ 3D 点优化：固定角度模式使用 CPU 多线程（{self.num_threads} 线程），"
                "不用 GPU 逐点核（该路径 GPU 开销大于收益）"
            )
            self._gpu_height_only_points_cpu_warned = True

        # CPU版本（支持多线程）
        optimized_points = points_3d.copy()
        
        # 收集所有需要优化的点
        optimization_tasks = []
        for pid, track in point_tracks.items():
            if pid >= len(points_3d):
                continue
            
            # 收集所有观测
            observations = []
            for img_name, kp_idx in track:
                if img_name not in poses:
                    continue
                kp_list = keypoints_dict.get(img_name, [])
                if kp_idx >= len(kp_list):
                    continue
                
                pt = kp_list[kp_idx].pt if hasattr(kp_list[kp_idx], 'pt') else kp_list[kp_idx]
                R_cam = poses[img_name]['R']
                t_cam = poses[img_name]['t']
                angles = image_angles.get(img_name, {}) if image_angles else {}
                dep = angles.get('depression', 31.57)
                
                observations.append((R_cam, t_cam, pt, dep))
            
            if len(observations) >= 2:
                optimization_tasks.append((pid, points_3d[pid], observations))
        
        # 使用多线程并行优化
        if self.num_threads > 1 and len(optimization_tasks) > 50:  # 只有任务数量足够多时才使用多线程
            def optimize_point_task(args):
                pid, point_init, observations = args
                point_opt = self._optimize_single_point(point_init, observations)
                return pid, point_opt
            
            with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
                futures = {executor.submit(optimize_point_task, task): task for task in optimization_tasks}
                for future in as_completed(futures):
                    pid, point_opt = future.result()
                    optimized_points[pid] = point_opt
        else:
            # 单线程版本
            for pid, point_init, observations in optimization_tasks:
                point_opt = self._optimize_single_point(point_init, observations)
                optimized_points[pid] = point_opt
        
        # 🔧 在优化3D点后应用点云高度约束
        optimized_points = self._apply_point_height_constraint(optimized_points)
        
        return optimized_points
    
    def _apply_point_height_constraint(self, points_3d_array):
        """
        应用点云高度约束（在优化3D点后调用）
        
        根据高度/长度比例限制点云的高度范围，可以通过缩放或过滤的方式
        
        Args:
            points_3d_array: 3D点云数组 (Nx3) 或 numpy数组
            
        Returns:
            points_3d_array: 应用约束后的3D点云数组
        """
        if len(points_3d_array) == 0:
            return points_3d_array
        
        # 确保是numpy数组
        if not isinstance(points_3d_array, np.ndarray):
            points_3d_array = np.array(points_3d_array)
        
        # 🔧 点云高度约束：检查高度/长度比例
        enable_point_height_constraint = self.sar_params.get('enable_point_height_constraint')
        if enable_point_height_constraint is None:
            raise ValueError("enable_point_height_constraint 必须在config.py中设置（--sfm_enable_point_height_constraint）")
        height_length_ratio = self.sar_params.get('point_height_length_ratio')
        if height_length_ratio is None:
            raise ValueError("point_height_length_ratio 必须在config.py中设置（--sfm_point_height_length_ratio）")
        constraint_mode = self.sar_params.get('point_height_constraint_mode')
        if constraint_mode is None:
            raise ValueError("point_height_constraint_mode 必须在config.py中设置（--sfm_point_height_constraint_mode）")
        
        if enable_point_height_constraint and len(points_3d_array) > 0:
            # 计算X和Z方向的范围（水平方向，长度和宽度）
            x_range = np.max(points_3d_array[:, 0]) - np.min(points_3d_array[:, 0])
            z_range = np.max(points_3d_array[:, 2]) - np.min(points_3d_array[:, 2])
            length_range = max(x_range, z_range)  # 较大的范围作为长度
            width_range = min(x_range, z_range)    # 较小的范围作为宽度
            
            # 计算Y坐标（高度）范围
            y_range = np.max(points_3d_array[:, 1]) - np.min(points_3d_array[:, 1])
            
            # 计算当前高度/长度比例
            current_ratio = y_range / length_range if length_range > 1e-6 else 0.0
            
            # 🔧 应用高度/长度约束
            if current_ratio > height_length_ratio:
                # 计算Y坐标的中心值
                y_center = np.median(points_3d_array[:, 1])
                # 计算允许的Y坐标范围（基于长度范围和比例阈值）
                max_y_range = length_range * height_length_ratio
                
                if constraint_mode == 'scale':
                    # 缩放模式：缩放所有点的Y坐标
                    scale_factor = max_y_range / y_range if y_range > 1e-6 else 1.0
                    points_3d_array[:, 1] = y_center + (points_3d_array[:, 1] - y_center) * scale_factor
                    
                    # 每次应用约束时都打印信息（但限制频率，避免每迭代都打印）
                    if self.verbose:
                        # 获取当前迭代次数（在主循环中设置）
                        iteration_count = getattr(self, '_point_height_constraint_iteration_count', 0)
                        # 只在第一次或每5次迭代打印一次，避免输出过多
                        if iteration_count == 0 or (iteration_count % 5 == 0):
                            print(f"  🔧 点云高度约束（优化后缩放，迭代{iteration_count+1}）: 高度/长度比例 {current_ratio:.4f} -> {height_length_ratio:.4f}, 缩放因子={scale_factor:.4f}")
                else:
                    # 过滤模式：标记超出范围的点（但不在优化过程中过滤，只记录警告）
                    y_min_allowed = y_center - max_y_range / 2
                    y_max_allowed = y_center + max_y_range / 2
                    y_outlier_mask = (points_3d_array[:, 1] < y_min_allowed) | (points_3d_array[:, 1] > y_max_allowed)
                    
                    # 每次检查时都打印信息（但限制频率）
                    if self.verbose and np.any(y_outlier_mask):
                        # 获取当前迭代次数（在主循环中设置）
                        iteration_count = getattr(self, '_point_height_constraint_iteration_count', 0)
                        num_outliers = np.sum(y_outlier_mask)
                        if iteration_count == 0 or (iteration_count % 5 == 0):
                            print(f"  ⚠️ 点云高度约束（优化后，迭代{iteration_count+1}）: {num_outliers} 个点超出高度范围（将在最终过滤时移除）")
            
            # 🔧 应用宽度约束（如果启用了宽度约束）
            enable_width_constraint = self.sar_params.get('enable_point_width_constraint', False)
            if enable_width_constraint and len(points_3d_array) > 0:
                # 使用PCA找到点云在XZ平面上的主方向（长度和宽度方向）
                # 只使用X和Z坐标进行PCA分析（Y是高度方向）
                xz_points = points_3d_array[:, [0, 2]]  # 只取X和Z坐标
                xz_center = np.median(xz_points, axis=0)  # XZ平面的中心
                xz_centered = xz_points - xz_center  # 中心化
                
                # 进行PCA分析
                if xz_centered.shape[0] >= 2:
                    # 计算协方差矩阵
                    cov_matrix = np.cov(xz_centered.T)
                    # 特征值分解
                    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
                    # 按特征值降序排列
                    idx = eigenvalues.argsort()[::-1]
                    eigenvalues = eigenvalues[idx]
                    eigenvectors = eigenvectors[:, idx]
                    
                    # 第一主成分（主方向，对应长度）
                    length_dir = eigenvectors[:, 0]  # (2,) 形状，在XZ平面上的方向向量
                    # 第二主成分（次主方向，对应宽度）
                    width_dir = eigenvectors[:, 1]  # (2,) 形状，在XZ平面上的方向向量
                    
                    # 计算点云在主方向和次主方向上的投影
                    length_projections = xz_centered @ length_dir  # 每个点在主方向上的投影
                    width_projections = xz_centered @ width_dir    # 每个点在次主方向上的投影
                    
                    # 计算在主方向和次主方向上的范围
                    length_range = np.max(length_projections) - np.min(length_projections)
                    width_range = np.max(width_projections) - np.min(width_projections)
                    
                    y_range = np.max(points_3d_array[:, 1]) - np.min(points_3d_array[:, 1])
                    
                    # 检查是否有宽度比例参数
                    height_width_ratio = self.sar_params.get('point_height_width_ratio', None)
                    length_width_ratio = self.sar_params.get('point_length_width_ratio', None)
                    
                    # 优先使用长度/宽度比例，如果没有则使用高度/宽度比例
                    if length_width_ratio is not None and length_width_ratio > 0:
                        # 使用长度/宽度比例约束
                        current_l_w_ratio = length_range / width_range if width_range > 1e-6 else 0.0
                        
                        if current_l_w_ratio > length_width_ratio:
                            # 宽度过小，需要缩放宽度（沿宽度方向缩放）
                            target_width = length_range / length_width_ratio
                            width_scale_factor = target_width / width_range if width_range > 1e-6 else 1.0
                            
                            # 沿宽度方向缩放：将宽度方向的投影乘以缩放因子
                            # width_dir 是宽度方向的单位向量，width_projections 是投影值
                            # 缩放后的宽度投影
                            width_projections_scaled = width_projections * width_scale_factor
                            
                            # 重新计算XZ坐标：中心 + 长度投影 * 长度方向 + 缩放后的宽度投影 * 宽度方向
                            xz_scaled = xz_center + length_projections[:, np.newaxis] * length_dir + width_projections_scaled[:, np.newaxis] * width_dir
                            
                            # 更新点云的X和Z坐标
                            points_3d_array[:, 0] = xz_scaled[:, 0]
                            points_3d_array[:, 2] = xz_scaled[:, 1]
                            
                            if self.verbose:
                                iteration_count = getattr(self, '_point_height_constraint_iteration_count', 0)
                                if iteration_count == 0 or (iteration_count % 5 == 0):
                                    print(f"  🔧 点云宽度约束（优化后缩放，迭代{iteration_count+1}）: 长度/宽度比例 {current_l_w_ratio:.4f} -> {length_width_ratio:.4f}, 宽度缩放因子={width_scale_factor:.4f}")
                    
                    elif height_width_ratio is not None and height_width_ratio > 0:
                        # 使用高度/宽度比例约束
                        current_h_w_ratio = y_range / width_range if width_range > 1e-6 else 0.0
                        
                        if current_h_w_ratio > height_width_ratio:
                            # 宽度过小，需要缩放宽度（沿宽度方向缩放）
                            target_width = y_range / height_width_ratio
                            width_scale_factor = target_width / width_range if width_range > 1e-6 else 1.0
                            
                            # 沿宽度方向缩放：将宽度方向的投影乘以缩放因子
                            width_projections_scaled = width_projections * width_scale_factor
                            
                            # 重新计算XZ坐标
                            xz_scaled = xz_center + length_projections[:, np.newaxis] * length_dir + width_projections_scaled[:, np.newaxis] * width_dir
                            
                            # 更新点云的X和Z坐标
                            points_3d_array[:, 0] = xz_scaled[:, 0]
                            points_3d_array[:, 2] = xz_scaled[:, 1]
                            
                            if self.verbose:
                                iteration_count = getattr(self, '_point_height_constraint_iteration_count', 0)
                                if iteration_count == 0 or (iteration_count % 5 == 0):
                                    print(f"  🔧 点云宽度约束（优化后缩放，迭代{iteration_count+1}）: 高度/宽度比例 {current_h_w_ratio:.4f} -> {height_width_ratio:.4f}, 宽度缩放因子={width_scale_factor:.4f}")
        
        return points_3d_array
    
    def _optimize_points_3d_gpu(self, poses, points_3d, point_tracks,
                                keypoints_dict, image_angles):
        """GPU批量优化3D点"""
        device = self.device
        
        # 转换为tensor
        if isinstance(points_3d, np.ndarray):
            points_3d_t = torch.from_numpy(points_3d).float().to(device)
        else:
            points_3d_t = points_3d.to(device)
        
        # 批量收集所有观测
        batch_observations = []
        valid_pids = []
        
        for pid, track in point_tracks.items():
            if pid >= len(points_3d_t):
                continue
            
            observations = []
            for img_name, kp_idx in track:
                if img_name not in poses:
                    continue
                kp_list = keypoints_dict.get(img_name, [])
                if kp_idx >= len(kp_list):
                    continue
                
                pt = kp_list[kp_idx].pt if hasattr(kp_list[kp_idx], 'pt') else kp_list[kp_idx]
                R_cam = poses[img_name]['R']
                t_cam = poses[img_name]['t']
                angles = image_angles.get(img_name, {}) if image_angles else {}
                dep = angles.get('depression', 31.57)
                
                observations.append((R_cam, t_cam, pt, dep))
            
            if len(observations) >= 2:
                batch_observations.append((pid, observations))
                valid_pids.append(pid)
        
        # 批量优化（分批处理以避免内存溢出）
        # 增大批量大小以提高GPU利用率（根据GPU内存调整）
        batch_size = 500  # 每批处理500个点（增大批量以提高GPU利用率）
        optimized_points_t = points_3d_t.clone()
        
        for batch_start in range(0, len(batch_observations), batch_size):
            batch_end = min(batch_start + batch_size, len(batch_observations))
            batch = batch_observations[batch_start:batch_end]
            
            for pid, observations in batch:
                point_init = points_3d_t[pid]
                point_opt = self._optimize_single_point_gpu(point_init, observations)
                optimized_points_t[pid] = point_opt
        
        # 转换回numpy以应用约束
        if isinstance(points_3d, np.ndarray):
            optimized_points = optimized_points_t.cpu().numpy()
        else:
            optimized_points = optimized_points_t.cpu().numpy()
        
        # 🔧 在优化3D点后应用点云高度约束
        optimized_points = self._apply_point_height_constraint(optimized_points)
        
        # 如果原始输入是tensor，转换回tensor
        if not isinstance(points_3d, np.ndarray):
            optimized_points = torch.from_numpy(optimized_points).float().to(device)
        
        return optimized_points
    
    def _optimize_single_point_gpu(self, point_init, observations):
        """
        GPU版本的单个3D点优化
        """
        device = self.device
        
        # 转换为tensor
        if isinstance(point_init, np.ndarray):
            point = torch.from_numpy(point_init).float().to(device)
        else:
            point = point_init.to(device)
        
        # 获取SAR参数
        camera_height = self.sar_params.get('camera_height', 1365.0)
        depth_factor = self.sar_params.get('point_cloud_depth_factor', 2.0)  # 默认2.0，可配置
        max_z = camera_height * depth_factor  # 使用可配置的深度因子
        
        # 准备批量观测数据
        R_cams = []
        t_cams = []
        image_points = []
        dep_angles = []
        
        for R_cam, t_cam, image_point, dep in observations:
            R_cams.append(torch.from_numpy(R_cam).float().to(device))
            t_cams.append(torch.from_numpy(t_cam).float().to(device))
            # 确保image_point是(2,)形状的数组
            if isinstance(image_point, (list, tuple)):
                image_point = np.array(image_point, dtype=np.float32)
            elif isinstance(image_point, np.ndarray):
                image_point = image_point.astype(np.float32)
            # 如果image_point有超过2个元素，只取前2个
            if image_point.size > 2:
                image_point = image_point[:2]
            elif image_point.size < 2:
                raise ValueError(f"image_point元素数量不足: {image_point.size}, 期望2个")
            # 确保是1维数组
            image_point = image_point.flatten()[:2]
            image_points.append(torch.tensor(image_point, dtype=torch.float32).to(device))
            dep_angles.append(dep)
        
        # 计算初始误差
        initial_error = 0.0
        for i, (R_cam, t_cam, image_point, dep) in enumerate(observations):
            _, _, error = self.compute_rd_reprojection_error(
                point_init.cpu().numpy() if isinstance(point_init, torch.Tensor) else point_init,
                R_cam, t_cam, image_point, dep
            )
            initial_error += error
        
        # 更保守的自适应学习率（由于使用robust误差，初始误差应该更小，所以可以适当增大学习率）
        # 但为了更稳定，仍然使用较小的学习率
        base_learning_rate = min(0.3, max(0.01, 10.0 / (initial_error + 1e-6)))  # 更保守的学习率范围（上限从0.5减小到0.3，缩放因子从20.0减小到10.0）
        if hasattr(self, '_step_size_scale'):
            base_learning_rate *= self._step_size_scale
        
        # GPU优化循环
        for iter_idx in range(20):
            grad = torch.zeros(3, device=device)
            current_error = 0.0
            
            # 批量计算误差和梯度
            for i, (R_cam_t, t_cam_t, image_point_t, dep) in enumerate(zip(R_cams, t_cams, image_points, dep_angles)):
                # 确保image_point_t是(2,)形状，然后unsqueeze成(1,2)
                if image_point_t.dim() == 0:
                    image_point_t = image_point_t.unsqueeze(0)
                elif image_point_t.dim() == 1 and image_point_t.shape[0] != 2:
                    # 如果形状不对，尝试reshape
                    if image_point_t.numel() == 2:
                        image_point_t = image_point_t.view(2)
                    else:
                        raise ValueError(f"image_point_t形状不正确: {image_point_t.shape}, 期望(2,)")
                
                # 确保point是(1,3)形状
                point_batch = point.unsqueeze(0) if point.dim() == 1 else point
                if point_batch.shape[0] != 1:
                    point_batch = point_batch[:1]
                
                # 确保image_point_t是(1,2)形状
                image_point_batch = image_point_t.unsqueeze(0) if image_point_t.dim() == 1 else image_point_t
                if image_point_batch.shape[0] != 1:
                    image_point_batch = image_point_batch[:1]
                
                # 计算误差
                error_range, error_azimuth, error = self._compute_rd_reprojection_error_batch_gpu(
                    point_batch, R_cam_t, t_cam_t.unsqueeze(1),
                    image_point_batch, torch.tensor([dep], device=device)
                )
                # error应该是形状为(1,)的tensor，需要先索引或squeeze
                # 处理各种可能的形状
                try:
                    # 如果error是标量（0维）
                    if error.dim() == 0:
                        error_val = error.item()
                    # 如果error是1维张量
                    elif error.dim() == 1:
                        if error.shape[0] == 1:
                            # (1,) 形状
                            error_val = error[0].item()
                        elif error.shape[0] == 3:
                            # 可能是误返回了3D坐标，取第一个元素
                            error_val = error[0].item()
                        else:
                            # 多个元素，取第一个
                            error_val = error[0].item()
                    # 如果error是2维张量
                    elif error.dim() == 2:
                        if error.shape[0] == 1 and error.shape[1] == 1:
                            # (1, 1) 形状
                            error_val = error[0, 0].item()
                        elif error.shape[0] == 1:
                            # (1, N) 形状，取第一个元素
                            error_val = error[0, 0].item()
                        else:
                            # 其他情况，取第一个元素
                            error_val = error[0, 0].item()
                    else:
                        # 其他维度，尝试flatten后取第一个
                        error_val = error.flatten()[0].item()
                except Exception as e:
                    # 如果所有方法都失败，打印调试信息
                    print(f"⚠️ 警告: 无法提取error值，error形状: {error.shape}, error内容: {error}")
                    print(f"   point_batch形状: {point_batch.shape}")
                    print(f"   image_point_batch形状: {image_point_batch.shape}")
                    print(f"   error_range形状: {error_range.shape if hasattr(error_range, 'shape') else 'N/A'}")
                    print(f"   error_azimuth形状: {error_azimuth.shape if hasattr(error_azimuth, 'shape') else 'N/A'}")
                    # 尝试使用error_range或error_azimuth
                    if error_range.numel() == 1:
                        error_val = error_range.item()
                    elif error_azimuth.numel() == 1:
                        error_val = error_azimuth.item()
                    else:
                        error_val = 0.0
                current_error += error_val
                
                # 数值梯度
                epsilon = max(1e-5, torch.norm(point).item() * 1e-6)
                for j in range(3):
                    point_perturb = point.clone()
                    point_perturb[j] += epsilon
                    point_perturb_batch = point_perturb.unsqueeze(0) if point_perturb.dim() == 1 else point_perturb
                    if point_perturb_batch.shape[0] != 1:
                        point_perturb_batch = point_perturb_batch[:1]
                    
                    _, _, error_perturb = self._compute_rd_reprojection_error_batch_gpu(
                        point_perturb_batch, R_cam_t, t_cam_t.unsqueeze(1),
                        image_point_batch, torch.tensor([dep], device=device)
                    )
                    # 使用相同的错误值提取逻辑
                    try:
                        if error.dim() == 0:
                            error_val = error.item()
                        elif error.dim() == 1:
                            error_val = error[0].item() if error.shape[0] > 0 else 0.0
                        elif error.dim() == 2:
                            error_val = error[0, 0].item() if error.shape[0] > 0 and error.shape[1] > 0 else 0.0
                        else:
                            error_val = error.flatten()[0].item()
                    except:
                        error_val = 0.0
                    
                    try:
                        if error_perturb.dim() == 0:
                            error_perturb_val = error_perturb.item()
                        elif error_perturb.dim() == 1:
                            error_perturb_val = error_perturb[0].item() if error_perturb.shape[0] > 0 else 0.0
                        elif error_perturb.dim() == 2:
                            error_perturb_val = error_perturb[0, 0].item() if error_perturb.shape[0] > 0 and error_perturb.shape[1] > 0 else 0.0
                        else:
                            error_perturb_val = error_perturb.flatten()[0].item()
                    except:
                        error_perturb_val = 0.0
                    
                    grad[j] += (error_perturb_val - error_val) / epsilon
            
            # 梯度归一化
            grad_norm = torch.norm(grad)
            if grad_norm > 1e-6:
                grad = grad / grad_norm * min(grad_norm.item(), 100.0)
            
            # 形状约束
            if abs(point[2].item()) > max_z:
                grad[2] += 1.0 * torch.sign(point[2]) * (abs(point[2]) - max_z)
            
            # 更新
            current_lr = base_learning_rate / (1.0 + iter_idx * 0.2)
            point_new = point - current_lr * grad
            
            # 线搜索
            new_error = 0.0
            for i, (R_cam_t, t_cam_t, image_point_t, dep) in enumerate(zip(R_cams, t_cams, image_points, dep_angles)):
                # 确保image_point_t是(1,2)形状
                if image_point_t.dim() == 0:
                    image_point_t = image_point_t.unsqueeze(0)
                elif image_point_t.dim() == 1 and image_point_t.shape[0] != 2:
                    if image_point_t.numel() == 2:
                        image_point_t = image_point_t.view(2)
                
                point_new_batch = point_new.unsqueeze(0) if point_new.dim() == 1 else point_new
                if point_new_batch.shape[0] != 1:
                    point_new_batch = point_new_batch[:1]
                
                image_point_batch = image_point_t.unsqueeze(0) if image_point_t.dim() == 1 else image_point_t
                if image_point_batch.shape[0] != 1:
                    image_point_batch = image_point_batch[:1]
                
                _, _, error = self._compute_rd_reprojection_error_batch_gpu(
                    point_new_batch, R_cam_t, t_cam_t.unsqueeze(1),
                    image_point_batch, torch.tensor([dep], device=device)
                )
                # 使用相同的错误值提取逻辑
                try:
                    if error.dim() == 0:
                        error_val = error.item()
                    elif error.dim() == 1:
                        error_val = error[0].item() if error.shape[0] > 0 else 0.0
                    elif error.dim() == 2:
                        error_val = error[0, 0].item() if error.shape[0] > 0 and error.shape[1] > 0 else 0.0
                    else:
                        error_val = error.flatten()[0].item()
                except Exception as e:
                    # 如果提取失败，使用默认值
                    error_val = 0.0
                new_error += error_val
            
            if new_error < current_error:
                point = point_new
            else:
                point = point - current_lr * 0.5 * grad
            
            # Z坐标约束
            point[2] = torch.clamp(point[2], -max_z, max_z)
            
            # 早停
            if current_error < 1e-3:
                break
        
        return point
    
    def _optimize_single_point(self, point_init, observations):
        """
        优化单个3D点
        
        使用基于RD模型的重投影误差进行优化
        添加形状约束以避免"塔状"畸变
        """
        point = point_init.copy()
        
        # 获取SAR参数用于形状约束
        camera_height = self.sar_params.get('camera_height', 1365.0)
        depth_factor = self.sar_params.get('point_cloud_depth_factor', 2.0)  # 默认2.0，可配置
        max_z = camera_height * depth_factor  # Z坐标约束：使用可配置的深度因子
        
        # 使用改进的梯度下降优化
        # 计算初始误差
        initial_error = 0.0
        for R_cam, t_cam, image_point, dep in observations:
            _, _, error = self.compute_rd_reprojection_error(
                point, R_cam, t_cam.reshape(3, 1), image_point, dep
            )
            initial_error += error
        
        # 更保守的自适应学习率（基于初始误差）
        base_learning_rate = min(0.3, max(0.01, 10.0 / (initial_error + 1e-6)))  # 更保守的学习率范围（上限从0.5减小到0.3，缩放因子从20.0减小到10.0）
        
        # 如果设置了步长缩放因子（由于误差增加），应用它
        if hasattr(self, '_step_size_scale'):
            base_learning_rate *= self._step_size_scale
        
        for iter_idx in range(20):  # 增加迭代次数
            grad = np.zeros(3)
            current_error = 0.0
            
            for R_cam, t_cam, image_point, dep in observations:
                error_range, error_azimuth, error = self.compute_rd_reprojection_error(
                    point, R_cam, t_cam.reshape(3, 1), image_point, dep
                )
                current_error += error
                
                # 数值梯度（使用更大的epsilon以提高稳定性）
                epsilon = max(1e-5, np.linalg.norm(point) * 1e-6)
                for i in range(3):
                    point_perturb = point.copy()
                    point_perturb[i] += epsilon
                    error_range_perturb, _, error_perturb = self.compute_rd_reprojection_error(
                        point_perturb, R_cam, t_cam.reshape(3, 1), image_point, dep
                    )
                    grad[i] += (error_perturb - error) / epsilon
            
            # 梯度归一化（避免梯度爆炸）
            grad_norm = np.linalg.norm(grad)
            if grad_norm > 1e-6:
                grad = grad / grad_norm * min(grad_norm, 100.0)  # 限制梯度大小
            
            # 添加形状约束：惩罚Z方向过大的点
            if abs(point[2]) > max_z:
                # 添加Z方向的约束梯度（减小权重以避免过度约束）
                grad[2] += 1.0 * np.sign(point[2]) * (abs(point[2]) - max_z)
            
            # 自适应学习率（随误差减小而减小）
            current_lr = base_learning_rate / (1.0 + iter_idx * 0.2)
            
            # 线搜索：如果误差增加，减小步长
            point_new = point - current_lr * grad
            new_error = 0.0
            for R_cam, t_cam, image_point, dep in observations:
                _, _, error = self.compute_rd_reprojection_error(
                    point_new, R_cam, t_cam.reshape(3, 1), image_point, dep
                )
                new_error += error
            
            if new_error < current_error:
                point = point_new
            else:
                # 如果误差增加，使用更小的步长
                point = point - current_lr * 0.5 * grad
            
            # 应用Z坐标约束
            point[2] = np.clip(point[2], -max_z, max_z)
            
            # 早停：如果误差足够小
            if current_error < 1e-3:
                break
        
        return point
    
    def _compute_total_error(self, poses, points_3d, point_tracks,
                            keypoints_dict, image_angles, verbose_stats=False):
        """
        计算总误差
        
        Args:
            verbose_stats: 是否输出详细统计信息
        """
        # 如果使用GPU，使用GPU批量计算
        if self.use_gpu:
            return self._compute_total_error_gpu(poses, points_3d, point_tracks,
                                                keypoints_dict, image_angles, verbose_stats)
        
        # CPU版本（支持多线程）
        # 收集所有观测任务
        tasks = []
        for pid, track in point_tracks.items():
            if pid >= len(points_3d):
                continue
            
            point3d = points_3d[pid]
            
            for img_name, kp_idx in track:
                if img_name not in poses:
                    continue
                
                kp_list = keypoints_dict.get(img_name, [])
                if kp_idx >= len(kp_list):
                    continue
                
                pt = kp_list[kp_idx].pt if hasattr(kp_list[kp_idx], 'pt') else kp_list[kp_idx]
                R_cam = poses[img_name]['R']
                t_cam = poses[img_name]['t']
                angles = image_angles.get(img_name, {}) if image_angles else {}
                dep = angles.get('depression', 31.57)
                
                tasks.append((point3d, R_cam, t_cam, pt, dep))
        
        # 使用多线程并行计算误差
        if self.num_threads > 1 and len(tasks) > 100:  # 只有任务数量足够多时才使用多线程
            def compute_error_task(args):
                point3d, R_cam, t_cam, pt, dep = args
                error_range, error_azimuth, error = self.compute_rd_reprojection_error(
                    point3d, R_cam, t_cam.reshape(3, 1), pt, dep
                )
                return error, abs(error_range), abs(error_azimuth)
            
            total_error = 0.0
            total_range_error = 0.0
            total_azimuth_error = 0.0
            error_list = []
            range_error_list = []
            azimuth_error_list = []
            
            with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
                futures = [executor.submit(compute_error_task, task) for task in tasks]
                for future in as_completed(futures):
                    error, error_range, error_azimuth = future.result()
                    total_error += error
                    total_range_error += error_range
                    total_azimuth_error += error_azimuth
                    error_list.append(error)
                    range_error_list.append(error_range)
                    azimuth_error_list.append(error_azimuth)
            
            count = len(tasks)
        else:
            # 单线程版本（任务数量少时更高效）
            total_error = 0.0
            total_range_error = 0.0
            total_azimuth_error = 0.0
            count = 0
            error_list = []
            range_error_list = []
            azimuth_error_list = []
            
            for point3d, R_cam, t_cam, pt, dep in tasks:
                error_range, error_azimuth, error = self.compute_rd_reprojection_error(
                    point3d, R_cam, t_cam.reshape(3, 1), pt, dep
                )
                
                total_error += error
                total_range_error += abs(error_range)
                total_azimuth_error += abs(error_azimuth)
                error_list.append(error)
                range_error_list.append(abs(error_range))
                azimuth_error_list.append(abs(error_azimuth))
                count += 1
        
        # 使用robust统计方法：过滤异常值后计算平均值，或使用中位数
        if count > 0:
            error_array = np.array(error_list)
            range_array = np.array(range_error_list)
            azimuth_array = np.array(azimuth_error_list)
            
            # 方法1：使用中位数（最robust，但可能过于保守）
            # median_error = np.median(error_array)
            
            # 方法2：使用MAD过滤异常值后计算平均值（推荐）
            median_error = np.median(error_array)
            mad_error = np.median(np.abs(error_array - median_error))  # Median Absolute Deviation
            
            # 过滤阈值：median + 3 * MAD（保留99.7%的数据，假设正态分布）
            threshold = median_error + 3 * mad_error
            
            # 过滤异常值
            valid_mask = error_array <= threshold
            valid_errors = error_array[valid_mask]
            valid_range_errors = range_array[valid_mask]
            valid_azimuth_errors = azimuth_array[valid_mask]
            
            if len(valid_errors) > 0:
                # 使用过滤后的平均值
                avg_error = np.mean(valid_errors)
                avg_range_error = np.mean(valid_range_errors)
                avg_azimuth_error = np.mean(valid_azimuth_errors)
                num_outliers = count - len(valid_errors)
            else:
                # 如果没有有效数据，使用中位数作为fallback
                avg_error = median_error
                avg_range_error = np.median(range_array)
                avg_azimuth_error = np.median(azimuth_array)
                num_outliers = 0
        else:
            avg_error = 0.0
            avg_range_error = 0.0
            avg_azimuth_error = 0.0
            num_outliers = 0
        
        if verbose_stats and count > 0:
            error_array = np.array(error_list)
            range_array = np.array(range_error_list)
            azimuth_array = np.array(azimuth_error_list)
            
            print(f"    误差统计:")
            print(f"      - 观测数量: {count}")
            print(f"      - 平均总误差: {avg_error:.6e} (过滤异常值后)")
            print(f"      - 平均斜距误差: {avg_range_error:.2f} 米")
            print(f"      - 平均方位误差: {avg_azimuth_error:.2f} 米")
            print(f"      - 误差中位数: {np.median(error_array):.6e}")
            print(f"      - 误差最大值: {np.max(error_array):.6e}")
            print(f"      - 斜距误差中位数: {np.median(range_array):.2f} 米")
            print(f"      - 斜距误差最大值: {np.max(range_array):.2f} 米")
            if num_outliers > 0:
                print(f"      - 过滤的异常值数量: {num_outliers} ({num_outliers/count*100:.1f}%)")
        
        return avg_error
    
    def _compute_total_error_gpu(self, poses, points_3d, point_tracks,
                                 keypoints_dict, image_angles, verbose_stats=False):
        """
        GPU批量计算总误差（高效版本）
        """
        device = self.device
        
        # 收集所有观测（按图像分组）
        img_observations = {}  # {img_name: [(pid, point3d, kp_idx, pt, dep), ...]}
        
        for pid, track in point_tracks.items():
            if pid >= len(points_3d):
                continue
            
            point3d = points_3d[pid]
            # 确保point3d是(3,)形状，如果不是，只取前3个元素
            if isinstance(point3d, np.ndarray):
                point3d = point3d.flatten()[:3]  # 确保是1维数组，只取前3个元素
            elif isinstance(point3d, (list, tuple)):
                point3d = np.array(point3d)[:3]  # 只取前3个元素
            else:
                point3d = np.array([point3d])[:3]  # 尝试转换
            
            for img_name, kp_idx in track:
                if img_name not in poses:
                    continue
                
                kp_list = keypoints_dict.get(img_name, [])
                if kp_idx >= len(kp_list):
                    continue
                
                pt = kp_list[kp_idx].pt if hasattr(kp_list[kp_idx], 'pt') else kp_list[kp_idx]
                # 确保pt是(2,)形状
                if isinstance(pt, np.ndarray):
                    pt = pt.flatten()[:2]
                elif isinstance(pt, (list, tuple)):
                    pt = np.array(pt)[:2]
                else:
                    pt = np.array([pt])[:2]
                
                angles = image_angles.get(img_name, {}) if image_angles else {}
                dep = angles.get('depression', 31.57)
                
                if img_name not in img_observations:
                    img_observations[img_name] = []
                img_observations[img_name].append((pid, point3d, kp_idx, pt, dep))
        
        if len(img_observations) == 0:
            return 0.0
        
        # 按图像批量计算误差
        total_error = 0.0
        total_range_error = 0.0
        total_azimuth_error = 0.0
        count = 0
        error_list = []
        range_error_list = []
        azimuth_error_list = []
        
        for img_name, observations in img_observations.items():
            if img_name not in poses:
                continue
            
            R_cam = torch.from_numpy(poses[img_name]['R']).float().to(device)
            t_cam = torch.from_numpy(poses[img_name]['t']).float().to(device)
            
            # 准备批量数据（增大批量以提高GPU利用率）
            batch_points = []
            batch_image_points = []
            batch_dep_angles = []
            
            for pid, point3d, kp_idx, pt, dep in observations:
                # 确保point3d是(3,)形状，如果不是，只取前3个元素
                if isinstance(point3d, np.ndarray):
                    point3d_clean = point3d.flatten()[:3]  # 确保是1维数组，只取前3个元素
                elif isinstance(point3d, (list, tuple)):
                    point3d_clean = np.array(point3d)[:3]  # 只取前3个元素
                else:
                    point3d_clean = np.array([point3d])[:3]  # 尝试转换
                
                # 确保pt是(2,)形状
                if isinstance(pt, np.ndarray):
                    pt_clean = pt.flatten()[:2]
                elif isinstance(pt, (list, tuple)):
                    pt_clean = np.array(pt)[:2]
                else:
                    pt_clean = np.array([pt])[:2]
                
                batch_points.append(point3d_clean)
                batch_image_points.append(pt_clean)
                batch_dep_angles.append(dep)
            
            if len(batch_points) == 0:
                continue
            
            # 转换为tensor（批量转换以提高效率）
            # 使用更大的批量大小以提高GPU利用率
            # 先检查每个点的形状，确保都是(3,)形状
            for i, pt in enumerate(batch_points):
                if isinstance(pt, np.ndarray):
                    if pt.shape != (3,):
                        if pt.size > 3:
                            batch_points[i] = pt.flatten()[:3]
                        elif pt.size < 3:
                            raise ValueError(f"点{i}元素数量不足: {pt.size}, 期望3个")
                elif isinstance(pt, (list, tuple)):
                    if len(pt) != 3:
                        if len(pt) > 3:
                            batch_points[i] = np.array(pt)[:3]
                        else:
                            raise ValueError(f"点{i}元素数量不足: {len(pt)}, 期望3个")
            
            points_array = np.array(batch_points)
            # 确保points_array是(N, 3)形状
            if len(points_array.shape) != 2 or points_array.shape[1] != 3:
                # 如果形状不正确，尝试修复
                if len(points_array.shape) == 1:
                    # 如果是一维数组，可能是对象数组，需要逐个处理
                    points_array = np.array([np.array(pt).flatten()[:3] for pt in batch_points])
                elif points_array.shape[1] > 3:
                    points_array = points_array[:, :3]  # 只取前3列
                elif points_array.shape[1] < 3:
                    raise ValueError(f"points_array形状不正确: {points_array.shape}, 期望(N, 3)")
            
            # 最终验证
            if points_array.shape[1] != 3:
                print(f"⚠️ 警告: points_array形状仍然不正确: {points_array.shape}")
                print(f"   第一个点的形状: {batch_points[0].shape if hasattr(batch_points[0], 'shape') else 'N/A'}")
                print(f"   第一个点的类型: {type(batch_points[0])}")
                print(f"   第一个点的内容: {batch_points[0]}")
                # 强制修复
                points_array = np.array([np.array(pt).flatten()[:3] for pt in batch_points])
            
            image_points_array = np.array(batch_image_points)
            # 确保image_points_array是(N, 2)形状
            if image_points_array.shape[1] != 2:
                if image_points_array.shape[1] > 2:
                    image_points_array = image_points_array[:, :2]  # 只取前2列
                else:
                    raise ValueError(f"image_points_array形状不正确: {image_points_array.shape}, 期望(N, 2)")
            
            # 最终验证points_array形状
            if points_array.shape[1] != 3:
                raise ValueError(f"points_array形状不正确: {points_array.shape}, 期望(N, 3)")
            
            points_t = torch.from_numpy(points_array).float().to(device, non_blocking=True)
            image_points_t = torch.from_numpy(image_points_array).float().to(device, non_blocking=True)
            dep_angles_t = torch.tensor(batch_dep_angles, dtype=torch.float32, device=device)
            
            # 在调用GPU函数前再次验证tensor形状
            if points_t.shape[1] != 3:
                print(f"⚠️ 警告: points_t形状不正确: {points_t.shape}, 强制修复")
                points_t = points_t[:, :3]
            
            # 批量计算误差（GPU并行计算）
            error_range, error_azimuth, total_error_batch = self._compute_rd_reprojection_error_batch_gpu(
                points_t, R_cam, t_cam.unsqueeze(1),
                image_points_t, dep_angles_t
            )
            
            total_error += total_error_batch.sum().item()
            total_range_error += error_range.abs().sum().item()
            total_azimuth_error += error_azimuth.abs().sum().item()
            count += len(batch_points)
            
            error_list.extend(total_error_batch.cpu().numpy())
            range_error_list.extend(error_range.abs().cpu().numpy())
            azimuth_error_list.extend(error_azimuth.abs().cpu().numpy())
        
        # 使用robust统计方法：过滤异常值后计算平均值，或使用中位数
        if count > 0:
            error_array = np.array(error_list)
            range_array = np.array(range_error_list)
            azimuth_array = np.array(azimuth_error_list)
            
            # 使用MAD过滤异常值后计算平均值（推荐）
            median_error = np.median(error_array)
            mad_error = np.median(np.abs(error_array - median_error))  # Median Absolute Deviation
            
            # 过滤阈值：median + 3 * MAD（保留99.7%的数据，假设正态分布）
            threshold = median_error + 3 * mad_error
            
            # 过滤异常值
            valid_mask = error_array <= threshold
            valid_errors = error_array[valid_mask]
            valid_range_errors = range_array[valid_mask]
            valid_azimuth_errors = azimuth_array[valid_mask]
            
            if len(valid_errors) > 0:
                # 使用过滤后的平均值
                avg_error = np.mean(valid_errors)
                avg_range_error = np.mean(valid_range_errors)
                avg_azimuth_error = np.mean(valid_azimuth_errors)
                num_outliers = count - len(valid_errors)
            else:
                # 如果没有有效数据，使用中位数作为fallback
                avg_error = median_error
                avg_range_error = np.median(range_array)
                avg_azimuth_error = np.median(azimuth_array)
                num_outliers = 0
        else:
            avg_error = 0.0
            avg_range_error = 0.0
            avg_azimuth_error = 0.0
            num_outliers = 0
        
        if verbose_stats and count > 0:
            error_array = np.array(error_list)
            range_array = np.array(range_error_list)
            azimuth_array = np.array(azimuth_error_list)
            
            print(f"    误差统计 (GPU加速):")
            print(f"      - 观测数量: {count}")
            print(f"      - 平均总误差: {avg_error:.6e} (过滤异常值后)")
            print(f"      - 平均斜距误差: {avg_range_error:.2f} 米")
            print(f"      - 平均方位误差: {avg_azimuth_error:.2f} 米")
            print(f"      - 误差中位数: {np.median(error_array):.6e}")
            print(f"      - 误差最大值: {np.max(error_array):.6e}")
            print(f"      - 斜距误差中位数: {np.median(range_array):.2f} 米")
            print(f"      - 斜距误差最大值: {np.max(range_array):.2f} 米")
            if num_outliers > 0:
                print(f"      - 过滤的异常值数量: {num_outliers} ({num_outliers/count*100:.1f}%)")
        
        return avg_error
    
    def handle_ambiguity(self, poses, points_3d, point_tracks, keypoints_dict, image_angles):
        """
        处理多视图SAR观测的歧义问题
        
        根据论文，多视图SAR观测可能导致局部最小值。
        这里实现一些策略来避免歧义：
        1. 检查点云的几何一致性
        2. 使用RANSAC过滤异常值
        3. 检查重投影误差的分布
        4. 检查点云的形状合理性（避免"塔状"畸变）
        
        Args:
            poses: 位姿字典
            points_3d: 3D点云
            point_tracks: 点跟踪
            keypoints_dict: 关键点字典
            image_angles: 图像角度信息
        
        Returns:
            poses_filtered: 过滤后的位姿
            points_3d_filtered: 过滤后的3D点
        """
        if self.verbose:
            print("处理多视图SAR观测歧义...")
        
        # 计算每个点的重投影误差
        point_errors = []
        for pid, track in point_tracks.items():
            if pid >= len(points_3d):
                continue
            
            point3d = points_3d[pid]
            errors = []
            
            for img_name, kp_idx in track:
                if img_name not in poses:
                    continue
                
                kp_list = keypoints_dict.get(img_name, [])
                if kp_idx >= len(kp_list):
                    continue
                
                pt = kp_list[kp_idx].pt if hasattr(kp_list[kp_idx], 'pt') else kp_list[kp_idx]
                R_cam = poses[img_name]['R']
                t_cam = poses[img_name]['t']
                angles = image_angles.get(img_name, {}) if image_angles else {}
                dep = angles.get('depression', 31.57)
                
                error_range, _, _ = self.compute_rd_reprojection_error(
                    point3d, R_cam, t_cam.reshape(3, 1), pt, dep
                )
                errors.append(abs(error_range))
            
            if errors:
                point_errors.append((pid, np.mean(errors)))
        
        if len(point_errors) == 0:
            return poses, points_3d
        
        # 使用RANSAC思想过滤异常点
        errors_array = np.array([e for _, e in point_errors])
        median_error = np.median(errors_array)
        mad_error = np.median(np.abs(errors_array - median_error))  # Median Absolute Deviation
        
        # 过滤阈值：median + 3 * MAD
        threshold = median_error + 3 * mad_error
        
        # 检查点云的形状合理性（避免"塔状"畸变）
        # 计算点云的主成分分析
        if len(points_3d) > 3:
            points_centered = points_3d - np.mean(points_3d, axis=0)
            cov_matrix = np.cov(points_centered.T)
            eigenvals, eigenvecs = np.linalg.eigh(cov_matrix)
            
            # 如果第一个主成分（最大方差）在Z方向（垂直方向）占主导，
            # 且方差比例过大，可能是"塔状"畸变
            eigenvals_sorted = np.sort(eigenvals)[::-1]
            variance_ratio = eigenvals_sorted[0] / (np.sum(eigenvals_sorted) + 1e-8)
            
            # 检查主方向
            max_eigenvec = eigenvecs[:, np.argmax(eigenvals)]
            z_component = abs(max_eigenvec[2])  # Z方向分量
            
            if self.verbose:
                print(f"  点云主成分分析:")
                print(f"    - 最大方差比例: {variance_ratio:.3f}")
                print(f"    - 主方向Z分量: {z_component:.3f}")
            
            # 如果检测到"塔状"畸变（主方向在Z方向，且方差比例>0.7）
            if variance_ratio > 0.7 and z_component > 0.7:
                if self.verbose:
                    print(f"  ⚠️ 检测到可能的'塔状'畸变，应用形状约束")
                
                # 应用形状约束：限制Z方向的扩展
                # 计算Z方向的合理范围（基于SAR几何）
                z_values = points_3d[:, 2]
                z_median = np.median(z_values)
                z_mad = np.median(np.abs(z_values - z_median))
                z_threshold = z_median + 2 * z_mad  # 更严格的阈值
                
                # 过滤Z方向异常的点
                valid_pids_shape = [pid for pid, _ in point_errors 
                                   if abs(points_3d[pid, 2] - z_median) < z_threshold]
                
                # 结合重投影误差和形状约束
                valid_pids = [pid for pid in valid_pids_shape 
                             if pid in [p for p, e in point_errors if e < threshold]]
            else:
                valid_pids = [pid for pid, e in point_errors if e < threshold]
        else:
            valid_pids = [pid for pid, e in point_errors if e < threshold]
        
        if self.verbose:
            print(f"  过滤前点数: {len(points_3d)}")
            print(f"  过滤后点数: {len(valid_pids)}")
            print(f"  过滤阈值: {threshold:.4f} 米")
        
        # 创建过滤后的点云
        pid_to_new_idx = {pid: i for i, pid in enumerate(valid_pids)}
        points_3d_filtered = points_3d[valid_pids]
        
        # 更新point_tracks（只保留有效点）
        point_tracks_filtered = {pid_to_new_idx[pid]: track 
                                 for pid, track in point_tracks.items() 
                                 if pid in valid_pids}
        
        return poses, points_3d_filtered

    def _filter_by_reprojection_error(self, points_3d, poses, point_tracks, 
                                       keypoints_dict, image_angles, max_error=50.0):
        """
        根据重投影误差过滤3D点
        
        Args:
            points_3d: 3D点数组
            poses: 相机位姿字典
            point_tracks: 点跟踪信息
            keypoints_dict: 关键点字典
            image_angles: 图像角度信息
            max_error: 最大允许的重投影误差（像素）
        
        Returns:
            points_3d_filtered: 过滤后的3D点
            point_tracks_filtered: 过滤后的点跟踪
        """
        if self.verbose:
            print(f"\n🔍 重投影误差过滤（阈值: {max_error:.1f}像素）...")
        
        valid_indices = []
        point_errors = []
        
        for pid, track in point_tracks.items():
            if pid >= len(points_3d):
                continue
            
            point3d = points_3d[pid]
            errors = []
            
            for img_name, kp_idx in track:
                if img_name not in poses or img_name not in keypoints_dict:
                    continue
                
                pose = poses[img_name]
                R_cam = pose['R']
                t_cam = pose['t']
                
                kps = keypoints_dict[img_name]
                if kp_idx >= len(kps):
                    continue
                
                kp = kps[kp_idx]
                if hasattr(kp, 'pt'):
                    pt = np.array(kp.pt)
                else:
                    pt = np.array(kp[:2])
                
                angles = image_angles.get(img_name, {}) if image_angles else {}
                dep = angles.get('depression', 31.57)
                
                try:
                    _, _, error = self.compute_rd_reprojection_error(
                        point3d, R_cam, t_cam.reshape(3, 1), pt, dep
                    )
                    errors.append(error)
                except:
                    pass
            
            if len(errors) > 0:
                avg_error = np.mean(errors)
                point_errors.append((pid, avg_error))
                
                # 保留误差小于阈值的点
                if avg_error < max_error:
                    valid_indices.append(pid)
        
        # 统计
        if self.verbose and len(point_errors) > 0:
            all_errors = [e for _, e in point_errors]
            print(f"  原始点数: {len(points_3d)}")
            print(f"  平均重投影误差: {np.mean(all_errors):.2f}像素")
            print(f"  误差中位数: {np.median(all_errors):.2f}像素")
            print(f"  误差 > {max_error}像素的点数: {len(points_3d) - len(valid_indices)}")
            print(f"  过滤后点数: {len(valid_indices)}")
        
        if len(valid_indices) == 0:
            if self.verbose:
                print("  ⚠️ 警告: 所有点都被过滤，返回原始点云")
            return points_3d, point_tracks
        
        # 创建过滤后的点云
        valid_indices = sorted(valid_indices)
        pid_to_new_idx = {pid: i for i, pid in enumerate(valid_indices)}
        points_3d_filtered = points_3d[valid_indices]
        
        # 更新point_tracks
        point_tracks_filtered = {}
        for pid, track in point_tracks.items():
            if pid in pid_to_new_idx:
                point_tracks_filtered[pid_to_new_idx[pid]] = track
        
        return points_3d_filtered, point_tracks_filtered

    def _add_dense_grid_points(self, points_3d, point_tracks, poses):
        """
        在稀疏点云基础上添加密集网格点
        
        Args:
            points_3d: 稀疏3D点数组
            point_tracks: 点跟踪信息
            poses: 相机位姿
        
        Returns:
            points_3d_dense: 密集点云
            point_tracks_dense: 更新的点跟踪
        """
        grid_size = self.sar_params.get('dense_grid_size', 16)
        
        if self.verbose:
            print(f"\n🔧 密集点云初始化（网格: {grid_size}x{grid_size}）...")
        
        # 计算稀疏点云的边界
        if len(points_3d) == 0:
            return points_3d, point_tracks
        
        min_coords = np.min(points_3d, axis=0)
        max_coords = np.max(points_3d, axis=0)
        center = (min_coords + max_coords) / 2
        
        # 扩展范围（增加20%边界）
        extent = (max_coords - min_coords) * 1.2
        extent = np.maximum(extent, 1.0)  # 确保最小范围
        
        # 生成规则网格点
        x_range = np.linspace(center[0] - extent[0]/2, center[0] + extent[0]/2, grid_size)
        y_range = np.linspace(center[1] - extent[1]/2, center[1] + extent[1]/2, grid_size)
        
        # Z坐标：使用稀疏点云的平均Z坐标附近
        z_mean = np.mean(points_3d[:, 2])
        z_std = max(np.std(points_3d[:, 2]), 0.5)
        z_range = np.linspace(z_mean - z_std, z_mean + z_std, max(3, grid_size // 4))
        
        # 生成网格点
        grid_points = []
        for x in x_range:
            for y in y_range:
                for z in z_range:
                    grid_points.append([x, y, z])
        
        grid_points = np.array(grid_points)
        
        # 过滤掉与现有点太近的网格点
        min_dist = 0.5  # 最小距离阈值
        valid_grid_points = []
        for gp in grid_points:
            dists = np.linalg.norm(points_3d - gp, axis=1)
            if np.min(dists) > min_dist:
                valid_grid_points.append(gp)
        
        if len(valid_grid_points) == 0:
            if self.verbose:
                print("  ⚠️ 没有有效的网格点可添加")
            return points_3d, point_tracks
        
        valid_grid_points = np.array(valid_grid_points)
        
        # 合并稀疏点和网格点
        points_3d_dense = np.vstack([points_3d, valid_grid_points])
        
        # 更新point_tracks（网格点没有track信息）
        point_tracks_dense = point_tracks.copy()
        # 为网格点创建空的track
        start_idx = len(points_3d)
        for i in range(len(valid_grid_points)):
            point_tracks_dense[start_idx + i] = []  # 空track
        
        if self.verbose:
            print(f"  原始点数: {len(points_3d)}")
            print(f"  添加网格点: {len(valid_grid_points)}")
            print(f"  总点数: {len(points_3d_dense)}")
            print(f"  点云范围: X=[{min_coords[0]:.2f}, {max_coords[0]:.2f}], "
                  f"Y=[{min_coords[1]:.2f}, {max_coords[1]:.2f}], "
                  f"Z=[{min_coords[2]:.2f}, {max_coords[2]:.2f}]")
        
        return points_3d_dense, point_tracks_dense

