"""
完整MPA（Mapping and Projection Algorithm）散射强度计算
基于SAR-GS论文公式3的完整实现

论文公式3:
S_{i,j} = ∫∫ S(x, r) dxdr
        = ∫∫ exp[-∫_{0}^{r} k_e(r') dr'] × P(x, r, θ) × exp[-∫_{0}^{r} k_e(r') dr'] × r dθ dr dx

其中:
- S_{i,j}: 像素(i,j)的SAR散射强度
- k_e(r'): 沿传播路径的衰减系数
- P(x, r, θ): 高斯原语的散射模式函数
- r: 斜距
- θ: 方位角
- x: 方位向坐标
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Optional, Tuple


class MPAScatteringIntensity(nn.Module):
    """
    完整MPA散射强度计算模块
    """
    
    def __init__(self,
                 k_e: float = 0.01,
                 use_path_integration: bool = True,
                 use_angular_dependence: bool = True,
                 use_range_weighting: bool = True,
                 num_integration_samples: int = 10):
        """
        初始化MPA散射计算
        
        Args:
            k_e: 衰减系数（默认0.01，可根据SAR波段调整）
            use_path_integration: 是否使用路径积分（完整模型需要）
            use_angular_dependence: 是否考虑角度依赖
            use_range_weighting: 是否使用距离加权
            num_integration_samples: 路径积分采样点数
        """
        super().__init__()
        
        self.k_e = k_e
        self.use_path_integration = use_path_integration
        self.use_angular_dependence = use_angular_dependence
        self.use_range_weighting = use_range_weighting
        self.num_integration_samples = num_integration_samples
        
        print(f"初始化完整MPA散射计算模块:")
        print(f"  衰减系数 k_e = {k_e}")
        print(f"  路径积分: {use_path_integration}")
        print(f"  角度依赖: {use_angular_dependence}")
        print(f"  距离加权: {use_range_weighting}")
    
    def compute_gaussian_scattering_pattern(self,
                                           delta: torch.Tensor,
                                           cov2D: torch.Tensor,
                                           incident_angle: Optional[torch.Tensor] = None,
                                           azimuth_angle: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        计算高斯散射模式 P(x, r, θ)
        
        这是高斯原语在给定位置和角度的散射概率密度
        
        Args:
            delta: 像素位置相对于高斯中心的偏移 (N, 2)
            cov2D: 2D协方差矩阵 (N, 2, 2)
            incident_angle: 入射角（弧度） (N,) 或标量
            azimuth_angle: 方位角（弧度） (N,) 或标量
        
        Returns:
            散射模式值 P (N,)
        """
        N = delta.shape[0]
        device = delta.device
        
        # 1. 基础高斯分布（空间依赖）
        # P(x, r) = exp(-0.5 * δ^T Σ^{-1} δ)
        
        # 计算协方差逆矩阵
        det = cov2D[:, 0, 0] * cov2D[:, 1, 1] - cov2D[:, 0, 1] * cov2D[:, 1, 0]
        det = torch.clamp(det, min=1e-6)
        
        inv_00 = cov2D[:, 1, 1] / det
        inv_01 = -cov2D[:, 0, 1] / det
        inv_11 = cov2D[:, 0, 0] / det
        
        # 计算Mahalanobis距离
        # δ^T Σ^{-1} δ = δ_x² * inv_00 + 2*δ_x*δ_y*inv_01 + δ_y² * inv_11
        mahalanobis_sq = (
            delta[:, 0] ** 2 * inv_00 +
            2.0 * delta[:, 0] * delta[:, 1] * inv_01 +
            delta[:, 1] ** 2 * inv_11
        )
        
        # 基础高斯模式
        P_spatial = torch.exp(-0.5 * mahalanobis_sq)
        
        # 归一化常数（2D高斯）
        normalization = 1.0 / (2.0 * np.pi * torch.sqrt(det))
        P_spatial = P_spatial * normalization
        
        # 2. 角度依赖（如果启用）
        if self.use_angular_dependence and incident_angle is not None:
            # 角度响应模型（简化的余弦模型）
            # 正入射（θ=0）散射最强，掠射（θ→90°）散射减弱
            angle_response = torch.cos(incident_angle) ** 2
            P_angular = angle_response
        else:
            P_angular = torch.ones(N, device=device)
        
        # 3. 方位角依赖（可选）
        if self.use_angular_dependence and azimuth_angle is not None:
            # 方位角各向异性（某些方向散射更强）
            # 这里使用简化模型，实际可以更复杂
            azimuth_response = 1.0 + 0.2 * torch.cos(2.0 * azimuth_angle)
            P_azimuth = azimuth_response
        else:
            P_azimuth = torch.ones(N, device=device)
        
        # 组合散射模式
        P = P_spatial * P_angular * P_azimuth
        
        return P
    
    def compute_path_attenuation(self,
                                 start_positions: torch.Tensor,
                                 end_positions: torch.Tensor,
                                 k_e_field: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        计算沿传播路径的衰减积分 exp[-∫_{0}^{r} k_e(r') dr']
        
        Args:
            start_positions: 起始位置（雷达） (N, 3)
            end_positions: 结束位置（散射点） (N, 3)
            k_e_field: 3D衰减场（可选，如果为None使用常数k_e）
        
        Returns:
            衰减因子 (N,)
        """
        N = start_positions.shape[0]
        device = start_positions.device
        
        if not self.use_path_integration:
            # 简化：直接使用距离衰减
            distances = torch.norm(end_positions - start_positions, dim=1)
            attenuation = torch.exp(-self.k_e * distances)
            return attenuation
        
        # 完整路径积分
        # 沿路径采样多个点进行数值积分
        attenuation_integral = torch.zeros(N, device=device)
        
        for i in range(self.num_integration_samples):
            # 线性插值获得路径上的采样点
            t = i / (self.num_integration_samples - 1)  # [0, 1]
            sample_positions = start_positions + t * (end_positions - start_positions)
            
            # 获取该位置的衰减系数
            if k_e_field is not None:
                # 从3D衰减场中采样（需要实现3D插值）
                k_e_sample = self._sample_k_e_field(sample_positions, k_e_field)
            else:
                # 使用常数衰减系数
                k_e_sample = torch.ones(N, device=device) * self.k_e
            
            # 计算路径段长度
            if i > 0:
                segment_length = torch.norm(
                    sample_positions - prev_positions, dim=1
                )
                attenuation_integral += k_e_sample * segment_length
            
            prev_positions = sample_positions
        
        # exp[-∫k_e dr']
        attenuation = torch.exp(-attenuation_integral)
        
        return attenuation
    
    def _sample_k_e_field(self, positions: torch.Tensor, k_e_field: torch.Tensor) -> torch.Tensor:
        """
        从3D衰减场中采样（简化实现）
        
        Args:
            positions: 采样位置 (N, 3)
            k_e_field: 3D衰减场
        
        Returns:
            衰减系数 (N,)
        """
        # TODO: 实现3D三线性插值
        # 这里返回常数作为占位
        return torch.ones(positions.shape[0], device=positions.device) * self.k_e
    
    def forward(self,
                gaussian_means3D: torch.Tensor,
                gaussian_cov3D: torch.Tensor,
                gaussian_intensity: torch.Tensor,
                radar_position: torch.Tensor,
                pixel_positions: torch.Tensor,
                R_world_to_radar: torch.Tensor,
                incident_angles: Optional[torch.Tensor] = None,
                azimuth_angles: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        完整MPA散射强度计算（论文公式3）
        
        S_{i,j} = ∫∫ exp[-∫k_e dr'] · P(x,r,θ) · exp[-∫k_e dr'] · r dθ dr dx
        
        Args:
            gaussian_means3D: 高斯3D中心位置 (N, 3)
            gaussian_cov3D: 高斯3D协方差 (N, 3, 3)
            gaussian_intensity: 高斯基础散射强度 (N,)
            radar_position: 雷达位置 (3,)
            pixel_positions: 像素位置（用于计算delta） (N, 2)
            R_world_to_radar: 世界到雷达坐标系旋转矩阵 (3, 3)
            incident_angles: 入射角 (N,) 可选
            azimuth_angles: 方位角 (N,) 可选
        
        Returns:
            完整散射强度 (N,)
        """
        N = gaussian_means3D.shape[0]
        device = gaussian_means3D.device
        
        # ========== 1. 计算传播路径衰减（双向） ==========
        # exp[-∫_{0}^{r} k_e(r') dr'] （发射路径）
        radar_pos_expanded = radar_position.unsqueeze(0).expand(N, -1)
        forward_attenuation = self.compute_path_attenuation(
            radar_pos_expanded,
            gaussian_means3D,
            k_e_field=None  # 简化：使用常数k_e
        )
        
        # exp[-∫_{0}^{r} k_e(r') dr'] （接收路径，往返相同）
        backward_attenuation = forward_attenuation
        
        # 双向衰减
        path_attenuation = forward_attenuation * backward_attenuation
        
        # ========== 2. 计算高斯散射模式 P(x, r, θ) ==========
        # 投影3D协方差到2D
        cov2D = self._project_covariance_3d_to_2d(gaussian_cov3D, R_world_to_radar)
        
        # 计算高斯中心投影到2D
        means3D_radar = torch.matmul(gaussian_means3D, R_world_to_radar.T)
        means2D_radar = means3D_radar[:, :2]  # 取前两维
        
        # 计算像素到高斯中心的偏移
        delta = pixel_positions - means2D_radar
        
        # 计算散射模式
        P = self.compute_gaussian_scattering_pattern(
            delta, 
            cov2D,
            incident_angle=incident_angles,
            azimuth_angle=azimuth_angles
        )
        
        # ========== 3. 距离加权 r ==========
        if self.use_range_weighting:
            # 计算斜距
            r = torch.norm(gaussian_means3D - radar_pos_expanded, dim=1)
            range_weight = r
        else:
            range_weight = torch.ones(N, device=device)
        
        # ========== 4. 组合完整散射强度 ==========
        # S = 基础强度 × 路径衰减 × 散射模式 × 距离权重
        S = gaussian_intensity * path_attenuation * P * range_weight
        
        return S
    
    def _project_covariance_3d_to_2d(self,
                                    cov3D: torch.Tensor,
                                    R_world_to_radar: torch.Tensor) -> torch.Tensor:
        """
        将3D协方差投影到2D SAR图像平面
        
        Args:
            cov3D: 3D协方差矩阵 (N, 3, 3)
            R_world_to_radar: 旋转矩阵 (3, 3)
        
        Returns:
            2D协方差矩阵 (N, 2, 2)
        """
        N = cov3D.shape[0]
        device = cov3D.device
        
        # 转换到雷达坐标系
        R = R_world_to_radar.unsqueeze(0).expand(N, -1, -1)
        cov3D_radar = torch.bmm(torch.bmm(R.transpose(1, 2), cov3D), R)
        
        # 投影到2D（取前2x2子矩阵）
        cov2D = cov3D_radar[:, :2, :2]
        
        # 添加正则化确保正定
        epsilon = 1e-4
        eye = torch.eye(2, device=device).unsqueeze(0).expand(N, -1, -1)
        cov2D = cov2D + epsilon * eye
        
        return cov2D


class MPAScatteringRenderer(nn.Module):
    """
    基于MPA的SAR渲染器（完整版本）
    """
    
    def __init__(self,
                 image_height: int,
                 image_width: int,
                 k_e: float = 0.01,
                 use_full_mpa: bool = True):
        """
        Args:
            image_height: 图像高度
            image_width: 图像宽度
            k_e: 衰减系数
            use_full_mpa: 是否使用完整MPA（False则使用简化版）
        """
        super().__init__()
        
        self.image_height = image_height
        self.image_width = image_width
        self.use_full_mpa = use_full_mpa
        
        if use_full_mpa:
            self.mpa_scattering = MPAScatteringIntensity(
                k_e=k_e,
                use_path_integration=True,
                use_angular_dependence=True,
                use_range_weighting=True
            )
        else:
            # 简化版本（当前实现）
            self.mpa_scattering = MPAScatteringIntensity(
                k_e=k_e,
                use_path_integration=False,
                use_angular_dependence=False,
                use_range_weighting=False
            )
    
    def compute_incident_angles(self,
                               gaussian_positions: torch.Tensor,
                               gaussian_normals: torch.Tensor,
                               radar_position: torch.Tensor) -> torch.Tensor:
        """
        计算入射角
        
        Args:
            gaussian_positions: 高斯位置 (N, 3)
            gaussian_normals: 高斯法向量 (N, 3)
            radar_position: 雷达位置 (3,)
        
        Returns:
            入射角（弧度） (N,)
        """
        N = gaussian_positions.shape[0]
        
        # 计算雷达到高斯的方向
        radar_to_gaussian = gaussian_positions - radar_position.unsqueeze(0).expand(N, -1)
        radar_direction = radar_to_gaussian / (torch.norm(radar_to_gaussian, dim=1, keepdim=True) + 1e-8)
        
        # 入射角 = arccos(|n · d|)
        cos_angle = torch.abs(torch.sum(gaussian_normals * radar_direction, dim=1))
        cos_angle = torch.clamp(cos_angle, 0.0, 1.0)
        incident_angles = torch.acos(cos_angle)
        
        return incident_angles
    
    def compute_azimuth_angles(self,
                              gaussian_positions: torch.Tensor,
                              radar_position: torch.Tensor,
                              reference_direction: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        计算方位角
        
        Args:
            gaussian_positions: 高斯位置 (N, 3)
            radar_position: 雷达位置 (3,)
            reference_direction: 参考方向（可选）
        
        Returns:
            方位角（弧度） (N,)
        """
        N = gaussian_positions.shape[0]
        device = gaussian_positions.device
        
        # 计算相对位置
        relative_pos = gaussian_positions - radar_position.unsqueeze(0).expand(N, -1)
        
        # 方位角（在XZ平面上）
        azimuth_angles = torch.atan2(relative_pos[:, 2], relative_pos[:, 0])
        
        return azimuth_angles
    
    def extract_gaussian_normals(self, rotations: torch.Tensor) -> torch.Tensor:
        """
        从高斯旋转提取法向量（主轴方向）
        
        Args:
            rotations: 四元数旋转 (N, 4) [w, x, y, z]
        
        Returns:
            法向量 (N, 3)
        """
        N = rotations.shape[0]
        device = rotations.device
        
        # 归一化四元数
        q = rotations / (torch.norm(rotations, dim=1, keepdim=True) + 1e-8)
        w, x, y, z = q[:, 0], q[:, 1], q[:, 2], q[:, 3]
        
        # 提取旋转矩阵的第三列（Z轴方向，通常是法向量）
        normal_x = 2*x*z + 2*w*y
        normal_y = 2*y*z - 2*w*x
        normal_z = 1 - 2*x*x - 2*y*y
        
        normals = torch.stack([normal_x, normal_y, normal_z], dim=1)
        normals = normals / (torch.norm(normals, dim=1, keepdim=True) + 1e-8)
        
        return normals


class MPAScatteringSimplified(nn.Module):
    """
    简化版MPA散射计算（当前实现的增强版）
    在简化模型基础上添加部分完整特性
    """
    
    def __init__(self, k_e: float = 0.01):
        super().__init__()
        self.k_e = k_e
    
    def forward(self,
                gaussian_intensity: torch.Tensor,
                depths: torch.Tensor,
                incident_angles: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        简化的MPA散射强度计算
        
        在简化模型基础上添加：
        1. ✅ 双向衰减
        2. ✅ 角度依赖（可选）
        3. ❌ 路径积分（简化为距离）
        4. ❌ 距离权重（简化）
        
        Args:
            gaussian_intensity: 基础散射强度 (N,)
            depths: 深度/斜距 (N,)
            incident_angles: 入射角（可选） (N,)
        
        Returns:
            散射强度 (N,)
        """
        # 1. 路径衰减（简化：exp(-k_e * distance)）
        forward_attenuation = torch.exp(-self.k_e * depths)
        backward_attenuation = forward_attenuation
        path_attenuation = forward_attenuation * backward_attenuation
        
        # 2. 角度依赖（如果提供）
        if incident_angles is not None:
            angle_response = torch.cos(incident_angles) ** 2
        else:
            angle_response = torch.ones_like(gaussian_intensity)
        
        # 3. 组合散射强度
        scattering = gaussian_intensity * path_attenuation * angle_response
        
        return scattering


# ============================================================================
# 对比：当前简化版 vs 完整MPA版本
# ============================================================================

def compare_scattering_methods():
    """
    对比简化散射计算和完整MPA计算的差异
    """
    print("\n" + "="*70)
    print("对比：简化散射 vs 完整MPA散射")
    print("="*70)
    
    # 测试数据
    N = 1000
    gaussian_intensity = torch.rand(N).cuda() * 0.5 + 0.5
    depths = torch.rand(N).cuda() * 10.0 + 5.0
    incident_angles = torch.rand(N).cuda() * np.pi / 4  # 0-45度
    
    # 1. 当前简化实现
    k_e = 0.01
    simple_attenuation = torch.exp(-k_e * depths)
    simple_scattering = gaussian_intensity * simple_attenuation ** 2
    
    # 2. 增强简化版（添加角度依赖）
    simplified_mpa = MPAScatteringSimplified(k_e=k_e)
    enhanced_scattering = simplified_mpa(
        gaussian_intensity, 
        depths, 
        incident_angles=incident_angles
    )
    
    # 统计
    print(f"\n【简化版散射强度】")
    print(f"  平均值: {simple_scattering.mean().item():.4f}")
    print(f"  标准差: {simple_scattering.std().item():.4f}")
    print(f"  范围: [{simple_scattering.min().item():.4f}, {simple_scattering.max().item():.4f}]")
    
    print(f"\n【增强版散射强度（添加角度依赖）】")
    print(f"  平均值: {enhanced_scattering.mean().item():.4f}")
    print(f"  标准差: {enhanced_scattering.std().item():.4f}")
    print(f"  范围: [{enhanced_scattering.min().item():.4f}, {enhanced_scattering.max().item():.4f}]")
    
    # 差异
    diff = torch.abs(enhanced_scattering - simple_scattering)
    print(f"\n【差异统计】")
    print(f"  平均差异: {diff.mean().item():.4f}")
    print(f"  最大差异: {diff.max().item():.4f}")
    print(f"  相对差异: {(diff / simple_scattering).mean().item() * 100:.2f}%")
    
    print("\n" + "="*70)
    print("结论:")
    print("  添加角度依赖后，散射强度更符合物理规律")
    print("  特别是对于掠射角度的高斯，散射会明显减弱")
    print("="*70 + "\n")


if __name__ == "__main__":
    print("\n" + "="*70)
    print("完整MPA散射强度计算模块测试")
    print("="*70)
    
    if torch.cuda.is_available():
        compare_scattering_methods()
    else:
        print("警告: CUDA不可用，跳过测试")
    
    print("\n使用方法:")
    print("  from sar_mpa_scattering import MPAScatteringIntensity")
    print("  mpa = MPAScatteringIntensity(k_e=0.01)")
    print("  scattering = mpa(...)")

