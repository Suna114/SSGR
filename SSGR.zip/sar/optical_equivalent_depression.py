"""
SAR 文件名俯视角 → 光学透视初始化用的等效俯视角（horizon 惯例，度）。

用于 SfM（SO-RCG / SAR BA）在 compute_sar_camera_pose 之前的初始俯仰角，
使水平圆环 + 针孔近似下的相机朝向/地面距离与 SAR 斜距几何更一致。

约定（与 sar.geometry.normalize_mstar_filename_depression_to_incidence_from_nadir_deg 一致）：
  - horizon：文件名第二段 φ_sar = 相对水平向下的俯角；
  - 内部与天底入射角 θ = 90° - φ_sar（horizon 时）。
"""

from __future__ import annotations

import math
from typing import Any, Optional, Tuple

import numpy as np

from sar.geometry import (
    DEFAULT_SAR_PARAMS,
    normalize_mstar_filename_depression_to_incidence_from_nadir_deg,
)


def _sar_incidence_from_nadir_deg(phi_horizon_deg: float, sar_params: Optional[dict]) -> float:
    return float(
        normalize_mstar_filename_depression_to_incidence_from_nadir_deg(
            float(phi_horizon_deg), sar_params
        )
    )


def compute_optical_equivalent_depression_horizon_deg(
    phi_sar_horizon_deg: float,
    sar_params: Optional[dict] = None,
    method: str = "ring_look_direction",
    *,
    empirical_scale: float = 1.0,
    fixed_horizon_deg: Optional[float] = None,
) -> Tuple[float, str]:
    """
    由 MSTAR/SAR 俯视角（horizon 惯例）计算 GS/COLMAP 渲染用俯视角。

    Returns:
        (phi_opt_horizon_deg, note_zh)
    """
    sp = dict(DEFAULT_SAR_PARAMS)
    if sar_params:
        sp.update(sar_params)

    phi_sar = float(phi_sar_horizon_deg)
    if fixed_horizon_deg is not None:
        fixed = float(fixed_horizon_deg)
        if math.isfinite(fixed) and fixed > 0:
            phi_opt = float(np.clip(fixed, 1.0, 89.0))
            return (
                phi_opt,
                f"fixed_horizon: φ_render={phi_opt:.2f}°（文件名 φ_sar={phi_sar:.2f}° 不变）",
            )

    method = (method or "ring_look_direction").strip().lower()
    empirical_scale = float(empirical_scale)
    if empirical_scale <= 0:
        empirical_scale = 1.0

    theta = math.radians(_sar_incidence_from_nadir_deg(phi_sar, sp))
    phi_sar_rad = math.radians(phi_sar)

    if method in (
        "complement_overhead",
        "gs_overhead_complement",
        "nadir_complement",
        "optical_overhead",
    ):
        # 光学 3DGS/COLMAP 俯视：φ_render = 90° - φ_sar（15° SAR 侧视 → 75° 光学俯视）
        phi_opt = 90.0 - phi_sar
        note = (
            f"complement_overhead: φ_sar={phi_sar:.2f}° → φ_render={phi_opt:.2f}° "
            f"(horizon 补角，≈天底 {90.0 - phi_opt:.1f}°)"
        )

    elif method in ("identity", "ring_look_direction", "perspective_ring_match"):
        # 水平圆环：视线相对水平面的俯角 = φ_sar；地面距 R_g = H·cot(θ) = H·tan(φ_sar)
        phi_opt = phi_sar
        note = (
            f"ring_look_direction: 光学圆环视线俯角与 SAR horizon 俯角一致 "
            f"(φ_sar={phi_sar:.2f}° → φ_opt={phi_opt:.2f}°)"
        )

    elif method == "pixel_spacing_anisotropy":
        # 按方位/距离向像素间距比修正初始俯角（斜距轴 vs 方位轴采样不等效于透视）
        va = float(sp.get("Va", 250.0))
        prf = float(sp.get("prf", 2500.0))
        fs = float(sp.get("fs", 500e6))
        c = float(sp.get("C", 3e8))
        d_az = va / prf
        d_rng = c / (2.0 * fs)
        if d_rng < 1e-12:
            w = 1.0
        else:
            w = d_az / d_rng
        phi_opt_rad = math.atan(empirical_scale * w * math.tan(phi_sar_rad))
        phi_opt = math.degrees(phi_opt_rad)
        note = (
            f"pixel_spacing_anisotropy: w=d_az/d_rng={w:.4f}, scale={empirical_scale}, "
            f"φ_sar={phi_sar:.2f}° → φ_opt={phi_opt:.2f}°"
        )

    elif method == "slant_range_view_distance":
        # 使圆环相机到场景中心的欧氏距离 = SAR 斜距 R_s = H/sin(θ)（horizon 下等价于 φ_opt=φ_sar）
        phi_opt = phi_sar
        note = (
            f"slant_range_view_distance: 圆环视距与斜距一致时 φ_opt=φ_sar ({phi_opt:.2f}°)"
        )

    elif method == "empirical_scale":
        phi_opt_rad = math.atan(empirical_scale * math.tan(phi_sar_rad))
        phi_opt = math.degrees(phi_opt_rad)
        note = (
            f"empirical_scale: tan(φ_opt)=scale·tan(φ_sar), scale={empirical_scale}, "
            f"φ_sar={phi_sar:.2f}° → φ_opt={phi_opt:.2f}°"
        )

    elif method == "sphere_to_ring_elevation":
        # 球面分布相机俯角与圆环俯角在视线仰角上对齐（horizon 下仍为 φ_sar）
        phi_opt = math.degrees(math.atan(math.tan(theta)))
        if abs(phi_opt - phi_sar) > 0.01:
            note = (
                f"sphere_to_ring_elevation: θ={math.degrees(theta):.2f}° → φ_opt={phi_opt:.2f}°"
            )
        else:
            phi_opt = phi_sar
            note = f"sphere_to_ring_elevation: 与 φ_sar 一致 ({phi_opt:.2f}°)"

    else:
        raise ValueError(
            f"未知 sfm_optical_equivalent_depression_method={method!r}；"
            "可选: complement_overhead, ring_look_direction, pixel_spacing_anisotropy, "
            "slant_range_view_distance, empirical_scale, sphere_to_ring_elevation, identity"
        )

    phi_opt = float(np.clip(phi_opt, 1.0, 89.0))
    return phi_opt, note


def gs_render_depression_settings_from_args(args: Any) -> dict:
    """从 convert/SfM CLI args 读取 GS 光学渲染俯角配置。"""
    cli = getattr(args, "_full_cli_args", None) or args
    fixed = getattr(cli, "sfm_gs_optical_depression_horizon_deg", None)
    if fixed is not None:
        try:
            fixed = float(fixed)
            if not math.isfinite(fixed) or fixed <= 0:
                fixed = None
        except (TypeError, ValueError):
            fixed = None
    return {
        "use_optical_equiv": bool(getattr(cli, "sfm_use_optical_equivalent_depression", False)),
        "method": str(
            getattr(cli, "sfm_optical_equivalent_depression_method", "ring_look_direction")
        ),
        "empirical_scale": float(
            getattr(cli, "sfm_optical_equivalent_depression_scale", 1.0) or 1.0
        ),
        "fixed_horizon_deg": fixed,
    }


def resolve_gs_render_depression_horizon_deg(
    phi_sar_horizon_deg: float,
    *,
    sar_params: Optional[dict] = None,
    args: Any = None,
    use_optical_equiv: Optional[bool] = None,
    method: Optional[str] = None,
    empirical_scale: Optional[float] = None,
    fixed_horizon_deg: Optional[float] = None,
    render_depression_deg: Optional[float] = None,
) -> Tuple[float, float, str]:
    """
    解析 COLMAP/GS 位姿与光学投影用的 horizon 俯角；文件名 φ_sar 仅作记录。

    Returns:
        (phi_render, phi_sar, note)
    """
    phi_sar = float(phi_sar_horizon_deg)
    if render_depression_deg is not None:
        rd = float(render_depression_deg)
        if math.isfinite(rd) and rd > 0:
            phi_r = float(np.clip(rd, 1.0, 89.0))
            return (
                phi_r,
                phi_sar,
                f"override: φ_render={phi_r:.2f}°（φ_sar={phi_sar:.2f}°）",
            )

    if args is not None:
        cfg = gs_render_depression_settings_from_args(args)
        if use_optical_equiv is None:
            use_optical_equiv = cfg["use_optical_equiv"]
        if method is None:
            method = cfg["method"]
        if empirical_scale is None:
            empirical_scale = cfg["empirical_scale"]
        if fixed_horizon_deg is None:
            fixed_horizon_deg = cfg["fixed_horizon_deg"]

    if not use_optical_equiv:
        return phi_sar, phi_sar, f"sar_filename: φ={phi_sar:.2f}°"

    phi_opt, note = compute_optical_equivalent_depression_horizon_deg(
        phi_sar,
        sar_params,
        str(method or "ring_look_direction"),
        empirical_scale=float(empirical_scale or 1.0),
        fixed_horizon_deg=fixed_horizon_deg,
    )
    return phi_opt, phi_sar, note


def apply_optical_equivalent_depression_to_sfm_angles(
    image_angles: dict,
    sar_params: dict,
    method: str,
    empirical_scale: float = 1.0,
    *,
    fixed_horizon_deg: Optional[float] = None,
) -> dict:
    """
    就地更新 image_angles[name]['depression']，并写入 depression_sar、depression_opt_note。
    返回 {image_name: phi_opt} 供写 mapping JSON。
    """
    mapping = {}
    for name, ang in image_angles.items():
        dep_sar = float(ang.get("depression_sar", ang["depression"]))
        if "depression_sar" not in ang:
            ang["depression_sar"] = dep_sar
        phi_opt, note = compute_optical_equivalent_depression_horizon_deg(
            dep_sar,
            sar_params,
            method,
            empirical_scale=empirical_scale,
            fixed_horizon_deg=fixed_horizon_deg,
        )
        ang["depression"] = phi_opt
        ang["depression_opt_note"] = note
        mapping[name] = phi_opt
    return mapping
