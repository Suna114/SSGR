"""
SAR 高斯泼溅光栅化器

以 submodules/diff-gaussian-rasterization 的 CUDA 光栅化为蓝本，
SAR 投影在 Python 中完成，光栅化（alpha 混合）由 diff-sar-rasterization CUDA 扩展完成。

流程：
1. Python: means3D, scales, rotations → SAR 斜距/方位向投影 → means2D, depths
2. Python: cov3D → 雷达系 2D 协方差 → conics
3. CUDA: means2D, conics, opacities, colors, depths → alpha 混合 → 图像

当 diff-sar-rasterization 未安装时，回退到 Python alpha 混合。
"""

import os
import torch
import torch.nn as nn
import numpy as np
from typing import Optional, Tuple, NamedTuple

from utils.general_utils import build_scaling_rotation

# 尝试导入 diff-sar-rasterization CUDA 扩展
try:
    from diff_sar_rasterization import rasterize_sar_gaussians, SAR_RASTERIZATION_AVAILABLE
except ImportError:
    try:
        import sys
        _path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'submodules', 'diff-sar-rasterization')
        if os.path.exists(_path) and _path not in sys.path:
            sys.path.insert(0, _path)
        from diff_sar_rasterization import rasterize_sar_gaussians, SAR_RASTERIZATION_AVAILABLE
    except ImportError:
        SAR_RASTERIZATION_AVAILABLE = False
        rasterize_sar_gaussians = None

_SAR_CUDA_DISABLED = False
_SAR_CUDA_FAIL_LOGGED = False
_SAR_CUDA_UNSTABLE_COUNT = 0


def sar_cuda_rasterization_enabled() -> bool:
    """本会话是否仍使用 diff-sar-rasterization CUDA（失败后自动降级 Python）。"""
    if _SAR_CUDA_DISABLED:
        return False
    if os.environ.get("SAR_SDGR_FORCE_PYTHON", "").strip().lower() in ("1", "true", "yes"):
        return False
    return bool(SAR_RASTERIZATION_AVAILABLE and rasterize_sar_gaussians is not None)


def _disable_sar_cuda_raster(reason: str) -> None:
    global _SAR_CUDA_DISABLED, _SAR_CUDA_FAIL_LOGGED
    _SAR_CUDA_DISABLED = True
    if not _SAR_CUDA_FAIL_LOGGED:
        _SAR_CUDA_FAIL_LOGGED = True
        print(f"[SAR SDGR] CUDA 光栅化已禁用: {reason}；本会话改用 Python 光栅化（较慢但稳定）")


def sar_mark_cuda_unstable(reason: str, *, auto_disable_after: int = 1) -> None:
    """非有限参数/CUDA 同步失败时累计；达到阈值后本会话禁用 CUDA 光栅化。"""
    global _SAR_CUDA_UNSTABLE_COUNT
    _SAR_CUDA_UNSTABLE_COUNT += 1
    if _SAR_CUDA_UNSTABLE_COUNT >= int(auto_disable_after):
        _disable_sar_cuda_raster(reason)


def sar_cuda_is_healthy() -> bool:
    """最近一次 sync 是否通过（不触发同步本身）。"""
    return not _SAR_CUDA_DISABLED


def sar_cuda_sync_check(tag: str, *, fatal: bool = False) -> bool:
    """同步 CUDA 并返回是否健康（用于定位异步 kernel 错误）。"""
    if not torch.cuda.is_available():
        return True
    try:
        torch.cuda.synchronize()
        return True
    except RuntimeError as e:
        _disable_sar_cuda_raster(f"{tag}: {e}")
        if fatal:
            raise
        return False

DEFAULT_SAR_PARAMS = {
    'range_pixel_spacing': 0.2021,
    'azimuth_pixel_spacing': 0.2031,
    'Na': 128,
    'Nr': 128,
}


# ==================== 3D 协方差 ====================

def _cov3d_from_scale_rot(scales: torch.Tensor, rotations: torch.Tensor, scale_modifier: float = 1.0) -> torch.Tensor:
    L = build_scaling_rotation(scale_modifier * scales, rotations)
    return torch.bmm(L, L.transpose(-1, -2))


# ==================== SAR 斜距/方位向投影 ====================

def _project_sar(
    means3D: torch.Tensor,
    R_world_to_radar: torch.Tensor,
    camera_center_world: torch.Tensor,
    image_width: int,
    image_height: int,
    range_pixel_spacing: float,
    azimuth_pixel_spacing: float,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    SAR 斜距/方位向投影（与 sar_sdgr_renderer 一致）
    雷达系：X=方位向, Y=距离向, Z=高度
    """
    device = means3D.device
    N = means3D.shape[0]
    R = R_world_to_radar.to(device)
    cam = camera_center_world.to(device).flatten()

    means3D_radar = torch.matmul(means3D, R.T)
    x_az = means3D_radar[:, 0]
    y_rng = means3D_radar[:, 1]
    z_height = means3D_radar[:, 2]

    platform_pos = torch.matmul(R, cam.unsqueeze(1)).squeeze(1)
    point_pos = torch.stack([x_az, y_rng, z_height], dim=1)
    slant_range = torch.norm(point_pos - platform_pos.unsqueeze(0), dim=1)

    platform_z = platform_pos[2]
    height_diff = platform_z - z_height
    ground_range = torch.sqrt(torch.clamp(slant_range**2 - height_diff**2, min=0.0))

    ref_gr = torch.median(ground_range) if N > 0 else torch.tensor(0.0, device=device)
    delta_rng = range_pixel_spacing
    delta_az = azimuth_pixel_spacing
    N_az, N_rng = image_width, image_height

    az_pixel = x_az / delta_az
    rng_pixel = (ground_range - ref_gr) / delta_rng
    x_image = az_pixel + N_az / 2.0
    y_image = rng_pixel + N_rng / 2.0

    means2D = torch.stack([x_image, y_image], dim=1)
    depths = ground_range
    return means2D, depths


# ==================== 2D 协方差 → conic ====================

def _cov2d_from_cov3d_sar(
    cov3D: torch.Tensor,
    R_world_to_radar: torch.Tensor,
    range_pixel_spacing: float,
    azimuth_pixel_spacing: float,
) -> torch.Tensor:
    """Σ' = J R Σ R^T J^T，取方位×距离向 2×2"""
    N = cov3D.shape[0]
    device = cov3D.device
    R = R_world_to_radar.to(device)
    cov3D_radar = torch.bmm(
        torch.bmm(R.unsqueeze(0).expand(N, -1, -1).transpose(1, 2), cov3D),
        R.unsqueeze(0).expand(N, -1, -1),
    )
    cov2d = cov3D_radar[:, :2, :2]
    jac = torch.tensor([
        [1.0 / azimuth_pixel_spacing, 0],
        [0, 1.0 / range_pixel_spacing],
    ], device=device, dtype=cov2d.dtype)
    J = jac.unsqueeze(0).expand(N, -1, -1)
    cov2d = torch.bmm(torch.bmm(J.transpose(1, 2), cov2d), J)
    cov2d = cov2d + 1e-6 * torch.eye(2, device=device, dtype=cov2d.dtype).unsqueeze(0).expand(N, -1, -1)
    return cov2d


# 与 optical forward.cu 一致：2D 协方差对角加 h_var 再求 conic
SAR_SCREEN_H_VAR = 0.3


def _cov2d_to_conic(cov2d: torch.Tensor, h_var: float = SAR_SCREEN_H_VAR) -> torch.Tensor:
    cov = cov2d.clone()
    if h_var > 0:
        cov[:, 0, 0] = cov[:, 0, 0] + h_var
        cov[:, 1, 1] = cov[:, 1, 1] + h_var
    det = cov[:, 0, 0] * cov[:, 1, 1] - cov[:, 0, 1] * cov[:, 1, 0]
    det = det.clamp(min=1e-8)
    return torch.stack([
        cov[:, 1, 1] / det,
        -cov[:, 0, 1] / det,
        cov[:, 0, 0] / det,
    ], dim=-1)


def _clamp_cov2d_footprint(cov2d: torch.Tensor, max_radius: float) -> torch.Tensor:
    """限制 3σ 屏幕半径，避免 CUDA tile 列表溢出或 int 半径回绕。"""
    if cov2d.numel() == 0:
        return cov2d
    # 与 CUDA sar_cap_radius 一致：相对短边比例上限
    max_var = (float(max_radius) / 3.0) ** 2
    a, b, c = cov2d[:, 0, 0], cov2d[:, 0, 1], cov2d[:, 1, 1]
    mid = 0.5 * (a + c)
    det = (a * c - b * b).clamp(min=1e-12)
    disc = torch.clamp(mid * mid - det, min=1e-12)
    sqrt_disc = torch.sqrt(disc)
    lam_max = mid + sqrt_disc
    scale = torch.where(lam_max > max_var, max_var / lam_max, torch.ones_like(lam_max))
    return cov2d * scale.view(-1, 1, 1)


def _sanitize_sar_raster_inputs(
    means2D: torch.Tensor,
    cov2d: torch.Tensor,
    opacities: torch.Tensor,
    H: int,
    W: int,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """送入 CUDA 光栅化前清理 NaN/Inf 并限制 splat 尺寸。"""
    short_side = float(min(H, W, 4096))
    max_radius = max(8.0, short_side * 0.48)
    pad = max_radius * 4.0
    means2D = torch.nan_to_num(means2D, nan=0.0, posinf=pad, neginf=-pad)
    # 勿对 requires_grad 的 view 做列赋值（AsStridedBackward）；全程 out-of-place
    means2D = torch.stack(
        (
            means2D[:, 0].clamp(-pad, float(W) + pad),
            means2D[:, 1].clamp(-pad, float(H) + pad),
        ),
        dim=1,
    )
    cov2d = torch.nan_to_num(cov2d, nan=1e-4, posinf=1e6, neginf=1e-4)
    cov2d = _clamp_cov2d_footprint(cov2d, max_radius)
    if opacities.dim() == 1:
        opacities = opacities.unsqueeze(1)
    opacities = torch.nan_to_num(opacities, nan=0.0, posinf=0.99, neginf=0.0).clamp(0.0, 0.99)
    return means2D, cov2d, opacities


def _sanitize_conics(conics: torch.Tensor, H: int, W: int) -> torch.Tensor:
    """清理 conic（precomp 路径）；无效行列式置零使 splat 不可见。"""
    c = torch.nan_to_num(conics, nan=0.0, posinf=0.0, neginf=0.0)
    det = c[:, 0] * c[:, 2] - c[:, 1] * c[:, 1]
    short_side = float(min(H, W, 4096))
    max_conic = max(1.0, (3.0 / (max(8.0, short_side * 0.48) / 3.0)) ** 2)
    c = torch.stack((
        c[:, 0].clamp(-max_conic, max_conic),
        c[:, 1].clamp(-max_conic, max_conic),
        c[:, 2].clamp(-max_conic, max_conic),
    ), dim=1)
    bad = det <= 1e-8
    if bad.any():
        c = c.clone()
        c[bad] = 0.0
    return c


def _conics_for_raster(
    cov2d: torch.Tensor,
    conics_precomp: Optional[torch.Tensor],
    H: int,
    W: int,
) -> torch.Tensor:
    """光栅化用 conic：优先从已 sanitize 的 cov2d 重建（与 h_var 一致）。"""
    if cov2d is not None and cov2d.numel() > 0 and bool((cov2d.abs().sum() > 0).detach().item()):
        return _cov2d_to_conic(cov2d)
    if conics_precomp is not None:
        return _sanitize_conics(conics_precomp, H, W)
    return _cov2d_to_conic(cov2d)


def _cov2d_to_radii(cov2d: torch.Tensor) -> torch.Tensor:
    a, b, c = cov2d[:, 0, 0], cov2d[:, 0, 1], cov2d[:, 1, 1]
    mid = 0.5 * (a + c)
    det = a * c - b * b
    lam = mid + torch.sqrt(torch.clamp(mid * mid - det, min=0.1))
    return torch.ceil(3.0 * torch.sqrt(torch.maximum(lam, torch.ones_like(lam) * 1e-6)))


# ==================== Python 回退：alpha 混合 ====================

def _alpha_blend_python(
    means2D: torch.Tensor,
    conics: torch.Tensor,
    opacities: torch.Tensor,
    colors: torch.Tensor,
    depths: torch.Tensor,
    bg: torch.Tensor,
    H: int,
    W: int,
    margin: float = 3.0,
    far_first: bool = True,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Alpha 混合；far_first=True 远→近（散射），False 近→远（阴影透射）。"""
    device = means2D.device
    sorted_idx = torch.argsort(depths, descending=far_first)
    radii_float = _cov2d_to_radii_from_conic(conics)
    in_frustum = (
        (means2D[:, 0] >= -margin * radii_float) & (means2D[:, 0] < W + margin * radii_float) &
        (means2D[:, 1] >= -margin * radii_float) & (means2D[:, 1] < H + margin * radii_float)
    )
    radii = torch.where(in_frustum, radii_float, torch.zeros_like(radii_float))

    bg_dev = bg.to(device)
    image = bg_dev.view(3, 1).expand(3, H * W).clone().reshape(3, H, W)
    depth_acc = torch.zeros(H, W, device=device)
    weight_sum = torch.zeros(H, W, device=device)
    T = torch.ones(H, W, device=device)

    for i in sorted_idx:
        k = i.item()
        if not in_frustum[k]:
            continue
        mu = means2D[k]
        conic = conics[k]
        alpha_val = opacities[k, 0]
        color = colors[k]
        depth_val = depths[k]
        r = radii_float[k].item() * margin
        x0 = max(0, int(mu[0].item() - r))
        x1 = min(W, int(mu[0].item() + r) + 1)
        y0 = max(0, int(mu[1].item() - r))
        y1 = min(H, int(mu[1].item() + r) + 1)
        if x0 >= x1 or y0 >= y1:
            continue

        yy = torch.arange(y0, y1, device=device, dtype=torch.float32)
        xx = torch.arange(x0, x1, device=device, dtype=torch.float32)
        gy, gx = torch.meshgrid(yy, xx, indexing='ij')
        dx = gx.reshape(-1) - mu[0]
        dy = gy.reshape(-1) - mu[1]
        power = -0.5 * (conic[0] * dx * dx + 2.0 * conic[1] * dx * dy + conic[2] * dy * dy)
        alpha = (alpha_val * torch.exp(torch.clamp(power, max=0))).clamp(0.0, 0.99)

        T_roi = T[y0:y1, x0:x1].clone().reshape(-1)
        weight = alpha * T_roi
        T[y0:y1, x0:x1] = (T_roi * (1.0 - alpha)).reshape(y1 - y0, x1 - x0)
        image[:, y0:y1, x0:x1] = image[:, y0:y1, x0:x1] + (color.unsqueeze(1) * weight.unsqueeze(0)).reshape(3, y1 - y0, x1 - x0)
        depth_acc[y0:y1, x0:x1] = depth_acc[y0:y1, x0:x1] + (depth_val * weight).reshape(y1 - y0, x1 - x0)
        weight_sum[y0:y1, x0:x1] = weight_sum[y0:y1, x0:x1] + weight.reshape(y1 - y0, x1 - x0)
        if T.max() < 1e-4:
            break

    depth_map = torch.where(weight_sum > 1e-6, depth_acc / weight_sum, torch.zeros_like(depth_acc))
    return image, radii, depth_map


def _cov2d_to_radii_from_conic(conics: torch.Tensor) -> torch.Tensor:
    """从 conic [a,b,c] 估算 3σ 半径（conic 为协方差逆）"""
    a, b, c = conics[:, 0], conics[:, 1], conics[:, 2]
    mid = 0.5 * (a + c)
    det = a * c - b * b
    lam_min = mid - torch.sqrt(torch.clamp(mid * mid - det, min=0.1))
    return 3.0 * torch.sqrt(torch.maximum(1.0 / (lam_min + 1e-8), torch.ones_like(lam_min) * 1e-6))


def _alpha_blend_backward(
    grad_image: torch.Tensor,
    means2D: torch.Tensor,
    conics: torch.Tensor,
    opacities: torch.Tensor,
    colors: torch.Tensor,
    depths: torch.Tensor,
    H: int,
    W: int,
    chunk_size: int = 256,
    far_first: bool = True,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Python alpha 混合的反向传播（far_first 须与 forward 一致）。"""
    device = means2D.device
    N = means2D.shape[0]
    P = H * W
    y_grid = torch.arange(H, device=device, dtype=torch.float32)
    x_grid = torch.arange(W, device=device, dtype=torch.float32)
    yy, xx = torch.meshgrid(y_grid, x_grid, indexing='ij')
    pixels = torch.stack([xx, yy], dim=-1).reshape(-1, 2)

    grad_colors = torch.zeros_like(colors)
    grad_opacities = torch.zeros_like(opacities)
    grad_means2D = torch.zeros_like(means2D)
    grad_conics = torch.zeros_like(conics)

    grad_flat = grad_image.reshape(3, -1)
    sorted_idx = torch.argsort(depths, descending=far_first)
    transmittance = torch.ones(P, device=device)

    for chunk_start in range(0, N, chunk_size):
        chunk_end = min(chunk_start + chunk_size, N)
        idx_slice = sorted_idx[chunk_start:chunk_end]
        m2d = means2D[idx_slice]
        con = conics[idx_slice]
        op = opacities[idx_slice, 0:1]
        col = colors[idx_slice]

        delta = pixels.unsqueeze(0) - m2d.unsqueeze(1)
        power = -0.5 * (
            con[:, 0:1] * delta[:, :, 0] ** 2 +
            2.0 * con[:, 1:2] * delta[:, :, 0] * delta[:, :, 1] +
            con[:, 2:3] * delta[:, :, 1] ** 2
        )
        gw = torch.exp(torch.clamp(power, max=0))
        alpha = (op * gw).clamp(0.0, 0.99)

        prefix = torch.cat([torch.ones(1, P, device=device), torch.cumprod(1.0 - alpha, dim=0)[:-1]], dim=0)
        T_before = transmittance.unsqueeze(0) * prefix
        weight = T_before * alpha

        grad_colors[idx_slice] = (grad_flat.unsqueeze(0) * weight.unsqueeze(1)).sum(dim=2)
        grad_opacities[idx_slice, 0] = (gw * T_before * (grad_flat.unsqueeze(0) * col.unsqueeze(2)).sum(dim=1)).sum(dim=1)
        grad_alpha = (grad_flat.unsqueeze(0) * T_before.unsqueeze(1) * col.unsqueeze(2)).sum(dim=1)
        M = torch.stack([con[:, 0], con[:, 1], con[:, 1], con[:, 2]], dim=1).reshape(-1, 2, 2)
        dM = torch.einsum('kpj,kji->kpi', delta, M)
        grad_means2D[idx_slice] = ((grad_alpha * alpha).unsqueeze(-1) * dM).sum(dim=1)
        dgw_da = -0.5 * delta[:, :, 0] ** 2 * gw
        dgw_db = -delta[:, :, 0] * delta[:, :, 1] * gw
        dgw_dc = -0.5 * delta[:, :, 1] ** 2 * gw
        grad_conics[idx_slice, 0] = (grad_alpha * alpha * dgw_da).sum(dim=1)
        grad_conics[idx_slice, 1] = (grad_alpha * alpha * dgw_db).sum(dim=1)
        grad_conics[idx_slice, 2] = (grad_alpha * alpha * dgw_dc).sum(dim=1)

        transmittance = transmittance * (1.0 - alpha).prod(dim=0)
        if transmittance.max() < 0.001:
            break

    return grad_colors, grad_opacities, grad_means2D, grad_conics


def alpha_blend_sar(
    means2D: torch.Tensor,
    cov2d: torch.Tensor,
    opacities: torch.Tensor,
    colors: torch.Tensor,
    depths: torch.Tensor,
    background: torch.Tensor,
    H: int,
    W: int,
    prefer_cuda: bool = True,
    far_first: bool = True,
    return_depth: bool = False,
    conics_precomp: Optional[torch.Tensor] = None,
):
    """
    SAR alpha 混合：优先 diff-sar-rasterization CUDA tile 光栅化，失败则回退 Python。
    depths 越大表示越远。
    far_first=True：远→近（散射）；False：近→远（阴影透射率）。
    return_depth=True 时返回 (image, depth_map)，depth_map 为 (H,W)。
    """
    means2D, cov2d, opacities = _sanitize_sar_raster_inputs(means2D, cov2d, opacities, H, W)
    conics = _conics_for_raster(cov2d, conics_precomp, H, W)
    if colors.dim() == 1:
        colors = colors.unsqueeze(-1).expand(-1, 3)
    if colors.shape[-1] == 1:
        colors = colors.expand(-1, 3)
    bg = background.reshape(3).to(means2D.device)
    sort_depths = (-depths if far_first else depths).contiguous()

    if prefer_cuda and sar_cuda_rasterization_enabled():
        try:
            out_color, _, out_invdepth = rasterize_sar_gaussians(
                means2D.contiguous(),
                conics.contiguous(),
                opacities.contiguous(),
                colors.contiguous(),
                sort_depths,
                bg.contiguous(),
                W,
                H,
            )
            if not sar_cuda_sync_check("alpha_blend_sar forward"):
                raise RuntimeError("CUDA sync failed after forward")
            if return_depth:
                inv = out_invdepth.squeeze(0)
                depth_map = torch.where(inv.abs() > 1e-6, 1.0 / inv.clamp(min=1e-6), torch.zeros_like(inv))
                return out_color, depth_map
            return out_color
        except Exception as e:
            _disable_sar_cuda_raster(str(e))

    out_device = means2D.device
    image, _, depth_map = _AlphaBlendSARPython.apply(
        means2D, conics, opacities, colors, depths, bg, H, W, far_first,
    )
    if image.device != out_device:
        image = image.to(out_device)
        depth_map = depth_map.to(out_device)
    if return_depth:
        return image, depth_map
    return image


class _AlphaBlendSARPython(torch.autograd.Function):
    """Python alpha 混合的可微包装"""

    @staticmethod
    def forward(ctx, means2D, conics, opacities, colors, depths, bg, H, W, far_first=True):
        image, radii, depth_map = _alpha_blend_python(
            means2D, conics, opacities, colors, depths, bg, H, W, far_first=far_first,
        )
        ctx.save_for_backward(means2D, conics, opacities, colors, depths)
        ctx.H, ctx.W = H, W
        ctx.far_first = far_first
        return image, radii, depth_map

    @staticmethod
    def backward(ctx, grad_image, grad_radii, grad_depth_map):
        if grad_image is None:
            return (None,) * 9
        means2D, conics, opacities, colors, depths = ctx.saved_tensors
        H, W = ctx.H, ctx.W
        grad_colors, grad_opacities, grad_means2D, grad_conics = _alpha_blend_backward(
            grad_image, means2D, conics, opacities, colors, depths, H, W,
            far_first=ctx.far_first,
        )
        return grad_means2D, grad_conics, grad_opacities, grad_colors, None, None, None, None, None


# ==================== 设置与光栅化器 ====================

class SARGaussianRasterizationSettings(NamedTuple):
    image_height: int
    image_width: int
    bg: torch.Tensor
    scale_modifier: float
    sh_degree: int
    R_world_to_radar: torch.Tensor
    camera_center_world: torch.Tensor
    range_pixel_spacing: float
    azimuth_pixel_spacing: float
    scene_scale: float
    prefiltered: bool
    debug: bool
    use_bbox_culling: bool = True
    prefer_cuda: bool = False


class SARGaussianRasterizer(nn.Module):
    """
    SAR 高斯光栅化器
    接口与 GaussianRasterizer 一致，内部使用 SAR 投影 + diff-sar-rasterization CUDA
    """

    def __init__(self, raster_settings: SARGaussianRasterizationSettings):
        super().__init__()
        self.raster_settings = raster_settings

    def forward(
        self,
        means3D: torch.Tensor,
        means2D: torch.Tensor,
        opacities: torch.Tensor,
        shs: Optional[torch.Tensor] = None,
        colors_precomp: Optional[torch.Tensor] = None,
        scales: Optional[torch.Tensor] = None,
        rotations: Optional[torch.Tensor] = None,
        cov3D_precomp: Optional[torch.Tensor] = None,
        means2D_precomp: Optional[torch.Tensor] = None,
        depths_precomp: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        if colors_precomp is None and shs is None:
            raise ValueError('需提供 colors_precomp 或 shs 之一')
        if colors_precomp is None:
            colors_precomp = torch.zeros(means3D.shape[0], 3, device=means3D.device)
        if colors_precomp.shape[-1] == 1:
            colors_precomp = colors_precomp.expand(-1, 3)
        if opacities.dim() == 1:
            opacities = opacities.unsqueeze(1)

        rs = self.raster_settings
        H, W = rs.image_height, rs.image_width
        device = means3D.device

        if cov3D_precomp is None or (isinstance(cov3D_precomp, torch.Tensor) and cov3D_precomp.numel() == 0):
            if scales is None or rotations is None:
                raise ValueError('需提供 scales+rotations 或 cov3D_precomp')
            cov3D = _cov3d_from_scale_rot(scales, rotations, rs.scale_modifier)
        else:
            cov3D = cov3D_precomp * (rs.scale_modifier ** 2)

        if means2D_precomp is not None and depths_precomp is not None:
            means2D_proj = means2D_precomp
            depths = depths_precomp
        else:
            means2D_proj, depths = _project_sar(
                means3D, rs.R_world_to_radar, rs.camera_center_world,
                W, H, rs.range_pixel_spacing, rs.azimuth_pixel_spacing,
            )
        cov2d = _cov2d_from_cov3d_sar(
            cov3D, rs.R_world_to_radar,
            rs.range_pixel_spacing, rs.azimuth_pixel_spacing,
        )
        conics = _cov2d_to_conic(cov2d)
        radii = _cov2d_to_radii(cov2d)
        bg = rs.bg.to(device)

        use_cuda = bool(getattr(rs, "prefer_cuda", False)) and sar_cuda_rasterization_enabled()
        if use_cuda and rasterize_sar_gaussians is not None:
            try:
                out_color, radii_out, out_invdepth = rasterize_sar_gaussians(
                    means2D_proj.contiguous(),
                    conics.contiguous(),
                    opacities.contiguous(),
                    colors_precomp.contiguous(),
                    -depths.contiguous(),
                    bg.contiguous(),
                    W, H,
                )
                visible = (radii > 0)
                radii = torch.where(visible, radii_out, torch.zeros_like(radii_out))
                viewspace_points = torch.cat([means2D_proj, torch.zeros(means2D_proj.shape[0], 1, device=device, dtype=means2D_proj.dtype)], dim=1)
                return out_color, radii, out_invdepth, viewspace_points
            except Exception as e:
                import warnings
                warnings.warn(f"SAR CUDA 光栅化失败，回退 Python: {e}", UserWarning, stacklevel=2)

        out_color, radii, depth_map = _AlphaBlendSARPython.apply(
            means2D_proj, conics, opacities, colors_precomp, depths, bg, H, W, True,
        )
        visible = (radii > 0)
        radii = torch.where(visible, radii, torch.zeros_like(radii))
        viewspace_points = torch.cat([means2D_proj, torch.zeros(means2D_proj.shape[0], 1, device=device, dtype=means2D_proj.dtype)], dim=1)
        return out_color, radii, depth_map, viewspace_points


def get_sar_raster_settings_from_camera(
    viewpoint_camera,
    bg_color: torch.Tensor,
    scale_modifier: float = 1.0,
    prefer_cuda: bool = False,
):
    """从相机构建 SARGaussianRasterizationSettings"""
    R = viewpoint_camera.R_world_to_radar
    R_t = R.float().cuda() if hasattr(R, 'cpu') else torch.from_numpy(np.array(R, dtype=np.float32)).cuda()
    cam = viewpoint_camera.camera_center
    if hasattr(cam, 'cpu'):
        cam_t = cam.float().cuda() if cam.dim() == 1 else cam.flatten().float().cuda()
    else:
        cam_t = torch.from_numpy(np.array(cam, dtype=np.float32)).cuda()
    sp = getattr(viewpoint_camera, 'sar_params', None) or {}
    return SARGaussianRasterizationSettings(
        image_height=int(viewpoint_camera.image_height),
        image_width=int(viewpoint_camera.image_width),
        bg=bg_color,
        scale_modifier=scale_modifier,
        sh_degree=0,
        R_world_to_radar=R_t,
        camera_center_world=cam_t,
        range_pixel_spacing=float(sp.get('range_pixel_spacing', DEFAULT_SAR_PARAMS['range_pixel_spacing'])),
        azimuth_pixel_spacing=float(sp.get('azimuth_pixel_spacing', DEFAULT_SAR_PARAMS['azimuth_pixel_spacing'])),
        scene_scale=float(sp.get('scene_scale', 0.1)),
        prefiltered=False,
        debug=False,
        use_bbox_culling=True,
        prefer_cuda=bool(prefer_cuda),
    )
