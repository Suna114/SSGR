"""SfM / convert 成像模式：光学透视圆环 vs SAR 斜视斜距（互斥）。"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Optional, Sequence


def _cli_flag_specified(argv: Optional[Sequence[str]], option_names: Sequence[str]) -> bool:
    if not argv:
        return False
    for tok in argv:
        for name in option_names:
            if tok == name or tok.startswith(f"{name}="):
                return True
    return False


def gs_optical_perspective_only_enabled(args: Any) -> bool:
    """
    ``--geometry_prior_gs_model`` 默认 True：MSTAR 图按俯视光学透视理解，
    不用 SAR 斜距投影闭合尺度；尺度由 optical verify 闭合。
    """
    cli_args = getattr(args, "_full_cli_args", None) or args
    argv = getattr(cli_args, "_argv", None) or sys.argv
    if _cli_flag_specified(
        argv, ("--no_sfm_gs_optical_perspective_only", "--sfm_gs_sar_slant_imaging")
    ):
        return False
    if _cli_flag_specified(argv, ("--sfm_gs_optical_perspective_only",)):
        return True
    if bool(getattr(cli_args, "sfm_gs_optical_perspective_only", False)):
        return True
    if bool(getattr(cli_args, "geometry_prior_gs_model", False)):
        return True
    full = getattr(args, "_full_cli_args", None)
    if full is not None and bool(getattr(full, "geometry_prior_gs_model", False)):
        return True
    return False


def sar_slant_imaging_enabled(args: Any) -> bool:
    """SAR 斜距成像 / auto_image_fill（rough_model 或未开 gs 光学专用）。"""
    return not gs_optical_perspective_only_enabled(args)


def resolve_gs_optical_ring_azimuth_sign(
    args: Any,
    scale: Optional[dict] = None,
) -> int:
    """
    水平圆环方位：光学透视下默认 -1，使模拟目标随 φ 的旋转与 MSTAR 训练图一致。
    SAR 斜距路径保持 +1。
    """
    cli_args = getattr(args, "_full_cli_args", None) or args
    argv = getattr(cli_args, "_argv", None) or sys.argv
    raw = getattr(cli_args, "sfm_gs_optical_ring_azimuth_sign", None)
    if raw is not None and _cli_flag_specified(argv, ("--sfm_gs_optical_ring_azimuth_sign",)):
        try:
            s = int(raw)
            if s in (-1, 1):
                return s
        except (TypeError, ValueError):
            pass
    conv = load_dataset_convention_probe(_resolve_source_path(cli_args))
    if conv is None and scale is not None:
        conv = scale.get("dataset_convention") if isinstance(scale.get("dataset_convention"), dict) else None
    if conv is not None:
        try:
            confidence = float(conv.get("rotation_confidence", 0.0) or 0.0)
            s = int(conv.get("gs_optical_ring_azimuth_sign", 0) or 0)
            if s in (-1, 1) and confidence >= 0.35:
                return s
        except (TypeError, ValueError):
            pass
    if gs_optical_perspective_only_enabled(cli_args):
        return -1
    if scale is not None:
        try:
            cached = int(scale.get("gs_optical_ring_azimuth_sign", 0))
            if cached in (-1, 1):
                return cached
        except (TypeError, ValueError):
            pass
    return 1


def _resolve_source_path(args: Any) -> Optional[str]:
    if isinstance(args, str):
        return args
    for key in ("source_path", "data_dir", "sfm_data_dir"):
        val = getattr(args, key, None)
        if val:
            return str(val)
    full = getattr(args, "_full_cli_args", None)
    if full is not None and full is not args:
        return _resolve_source_path(full)
    return None


def dataset_convention_from_source_or_scale(
    source_path: Optional[str],
    scale: Optional[dict] = None,
) -> Optional[dict]:
    conv = load_dataset_convention_probe(source_path)
    if conv is None and isinstance(scale, dict):
        cached = scale.get("dataset_convention")
        if isinstance(cached, dict):
            conv = cached
    return conv


def resolve_dataset_world_yaw_deg(
    args_or_source: Any,
    scale: Optional[dict] = None,
    *,
    default_yaw_deg: float = -90.0,
) -> float:
    """
    Resolve the mesh/nominal-box yaw from the dataset convention probe.

    The manual CLI flag wins only when it was really specified by the user. Preset
    defaults are deliberately treated as fallbacks so global image statistics can
    drive 360-1 vs 360-10 style datasets.
    """
    cli_args = getattr(args_or_source, "_full_cli_args", None) or args_or_source
    argv = getattr(cli_args, "_argv", None) or sys.argv
    raw = getattr(cli_args, "sfm_mesh_prior_extra_world_yaw_deg", None)
    if raw is not None and _cli_flag_specified(argv, ("--sfm_mesh_prior_extra_world_yaw_deg",)):
        try:
            return float(raw)
        except (TypeError, ValueError):
            pass

    source_path = _resolve_source_path(cli_args)
    conv = dataset_convention_from_source_or_scale(source_path, scale)
    axis = str((conv or {}).get("zero_azimuth_long_axis") or "").strip().lower()
    mapping = str((conv or {}).get("zero_azimuth_axis_mapping") or "").strip().replace(" ", "").lower()
    try:
        confidence = float((conv or {}).get("zero_azimuth_axis_confidence", 0.0) or 0.0)
    except (TypeError, ValueError):
        confidence = 0.0
    if confidence >= 0.35:
        if axis == "y" or "y=length" in mapping:
            return 0.0
        if axis == "x" or "x=length" in mapping:
            return -90.0

    if isinstance(scale, dict):
        try:
            return float(scale.get("sfm_mesh_prior_extra_world_yaw_deg", default_yaw_deg))
        except (TypeError, ValueError):
            pass
    return float(default_yaw_deg)


def dataset_convention_debug_summary(
    source_path: Optional[str],
    scale: Optional[dict] = None,
) -> str:
    conv = dataset_convention_from_source_or_scale(source_path, scale)
    if not conv:
        return "dataset convention: not found"
    return (
        "dataset convention: "
        f"shadow={conv.get('shadow_side', 'unknown')} "
        f"(conf={float(conv.get('shadow_side_confidence', 0.0) or 0.0):.2f}), "
        f"az0={conv.get('zero_azimuth_axis_mapping', 'unknown')} "
        f"(conf={float(conv.get('zero_azimuth_axis_confidence', 0.0) or 0.0):.2f}), "
        f"rotation={conv.get('rotation_direction', 'unknown')} "
        f"(conf={float(conv.get('rotation_confidence', 0.0) or 0.0):.2f}), "
        f"gs_sign={conv.get('gs_optical_ring_azimuth_sign', 'unknown')}"
    )


def load_dataset_convention_probe(source_path: Optional[str]) -> Optional[dict]:
    if not source_path:
        return None
    path = os.path.join(
        str(source_path),
        "adaptive_threshold_visualization",
        "dataset_convention_probe.json",
    )
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return None
    return data if isinstance(data, dict) else None
