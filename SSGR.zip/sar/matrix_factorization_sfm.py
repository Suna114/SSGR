# sar_matrix_factorization_sfm.py
"""
基于矩阵分解的SAR Structure-from-Motion实现
参考论文: "SAR Structure-from-Motion via Matrix Factorization"

核心思想：
1. 将SAR SfM问题转化为矩阵分解问题
2. 使用Riemannian共轭梯度算法在Stiefel流形上优化
3. 交替优化雷达位姿矩阵M_k和场景结构S
"""

import numpy as np
from scipy.linalg import qr
from scipy.spatial.transform import Rotation as R


class SARMatrixFactorizationSfM:
    """
    基于矩阵分解的SAR SfM求解器
    
    目标函数：
        min_{M_k, S} (1/2) * sum_k ||D_k - M_k * S||_F^2
        s.t. M_k * M_k^T = I_2
    
    其中：
        - D_k: 2xN矩阵，第k个雷达观测的2D散射点分布（零均值处理后）
        - M_k: 2x3矩阵，从场景坐标系到传感器坐标系的旋转矩阵的前两行
        - S: 3xN矩阵，包含所有散射点的3D坐标
    """
    
    def __init__(self, max_iterations=100, tolerance=1e-6, verbose=True):
        """
        初始化SAR矩阵分解SfM求解器
        
        Args:
            max_iterations: 最大迭代次数
            tolerance: 收敛容差
            verbose: 是否输出详细信息
        """
        self.max_iterations = max_iterations
        self.tolerance = tolerance
        self.verbose = verbose
        self.error_history = []
    
    def prepare_data_matrices(self, keypoints_dict, matches_dict):
        """
        准备数据矩阵D_k
        
        根据论文，需要：
        1. 提取匹配的2D点
        2. 进行零均值处理
        3. 构建D_k矩阵（2xN）
        
        Args:
            keypoints_dict: 字典，key为图像名称，value为关键点列表
            matches_dict: 字典，key为(图像1名称, 图像2名称)，value为匹配列表
        
        Returns:
            D_dict: 字典，key为图像名称，value为2xN的数据矩阵
            point_tracks: 字典，key为3D点索引，value为观测该点的图像和2D点索引列表
        """
        if self.verbose:
            print("准备数据矩阵...")
        
        # 构建点跟踪（track）
        point_tracks = {}  # {point_id: [(img_name, kp_idx), ...]}
        point_id = 0
        
        # 遍历所有匹配对，构建track
        for (img1_name, img2_name), matches in matches_dict.items():
            kp1 = keypoints_dict.get(img1_name, [])
            kp2 = keypoints_dict.get(img2_name, [])
            
            if len(kp1) == 0 or len(kp2) == 0:
                continue
            
            for match in matches:
                # 处理不同的匹配格式
                if hasattr(match, 'queryIdx'):
                    idx1 = match.queryIdx
                    idx2 = match.trainIdx
                elif isinstance(match, (list, tuple)) and len(match) >= 2:
                    idx1 = match[0]
                    idx2 = match[1]
                elif isinstance(match, dict):
                    idx1 = match.get('queryIdx', match.get('idx1', -1))
                    idx2 = match.get('trainIdx', match.get('idx2', -1))
                else:
                    continue
                
                if idx1 < 0 or idx2 < 0 or idx1 >= len(kp1) or idx2 >= len(kp2):
                    continue
                
                # 检查是否已经存在track
                found_track = False
                for pid, track in point_tracks.items():
                    # 检查img1中的点是否已经在track中
                    if (img1_name, idx1) in track:
                        # 将img2中的点添加到同一个track
                        if (img2_name, idx2) not in track:
                            track.append((img2_name, idx2))
                        found_track = True
                        break
                    # 检查img2中的点是否已经在track中
                    elif (img2_name, idx2) in track:
                        # 将img1中的点添加到同一个track
                        if (img1_name, idx1) not in track:
                            track.append((img1_name, idx1))
                        found_track = True
                        break
                
                if not found_track:
                    # 创建新的track
                    point_tracks[point_id] = [(img1_name, idx1), (img2_name, idx2)]
                    point_id += 1
        
        if self.verbose:
            print(f"  构建了 {len(point_tracks)} 个3D点的track")
        
        # 为每个图像构建数据矩阵D_k
        D_dict = {}
        image_point_indices = {}  # {img_name: {point_id: kp_idx}}
        
        for img_name in keypoints_dict.keys():
            # 找出该图像观测到的所有3D点
            img_points = {}  # {point_id: kp_idx}
            for pid, track in point_tracks.items():
                for track_img_name, kp_idx in track:
                    if track_img_name == img_name:
                        img_points[pid] = kp_idx
                        break
            
            if len(img_points) == 0:
                continue
            
            # 提取2D坐标
            kp_list = keypoints_dict[img_name]
            points_2d = []
            point_ids = []
            
            for pid, kp_idx in img_points.items():
                if kp_idx < len(kp_list):
                    kp = kp_list[kp_idx]
                    pt = kp.pt if hasattr(kp, 'pt') else kp
                    points_2d.append([pt[0], pt[1]])
                    point_ids.append(pid)
            
            if len(points_2d) == 0:
                continue
            
            points_2d = np.array(points_2d).T  # 2xN
            
            # 零均值处理（论文要求）
            mean = np.mean(points_2d, axis=1, keepdims=True)
            points_2d_centered = points_2d - mean
            
            D_dict[img_name] = points_2d_centered
            image_point_indices[img_name] = dict(zip(point_ids, range(len(point_ids))))
        
        if self.verbose:
            print(f"  为 {len(D_dict)} 个图像构建了数据矩阵")
        
        return D_dict, point_tracks, image_point_indices
    
    def compute_riemannian_gradient(self, M_k_T, S, D_k):
        """
        计算Riemannian梯度
        
        根据论文公式(7)：
        Rg(M_k^T) = g(M_k^T) - M_k^T * sym(M_k * g(M_k^T))
        
        其中：
        g(M_k^T) = S * (M_k * S - D_k)^T
        
        Args:
            M_k_T: 3x2矩阵，M_k的转置
            S: 3xN矩阵，场景结构
            D_k: 2xN矩阵，观测数据
        
        Returns:
            Rg: 3x2矩阵，Riemannian梯度
        """
        M_k = M_k_T.T  # 2x3
        
        # 计算欧氏梯度
        residual = M_k @ S - D_k  # 2xN
        g = S @ residual.T  # 3x2
        
        # 计算Riemannian梯度
        sym_term = M_k @ g  # 2x2
        sym_term = 0.5 * (sym_term + sym_term.T)  # 对称化
        Rg = g - M_k_T @ sym_term  # 3x2
        
        return Rg
    
    def vector_transport(self, eta_prev, M_k_T_prev, M_k_T_curr):
        """
        向量传输（Vector Transport）
        
        将前一个切空间中的向量传输到当前切空间
        使用正交投影
        
        Args:
            eta_prev: 前一个切空间中的向量（3x2）
            M_k_T_prev: 前一个Stiefel流形上的点（3x2）
            M_k_T_curr: 当前Stiefel流形上的点（3x2）
        
        Returns:
            eta_transported: 传输后的向量（3x2）
        """
        # 正交投影到当前切空间
        M_k_curr = M_k_T_curr.T  # 2x3
        sym_term = M_k_curr @ eta_prev  # 2x2
        sym_term = 0.5 * (sym_term + sym_term.T)
        eta_transported = eta_prev - M_k_T_curr @ sym_term
        
        return eta_transported
    
    def retract_to_stiefel(self, M_k_T, eta, step_size):
        """
        QR收缩（Retraction）到Stiefel流形
        
        将切空间中的点收缩回Stiefel流形
        
        Args:
            M_k_T: 当前Stiefel流形上的点（3x2）
            eta: 切空间中的方向向量（3x2）
            step_size: 步长
        
        Returns:
            M_k_T_new: 收缩后的点（3x2）
        """
        # 沿着方向移动
        M_k_T_new = M_k_T + step_size * eta
        
        # QR分解进行收缩
        Q, R_qr = qr(M_k_T_new)
        
        # 取前两列（因为M_k是2x3，所以M_k^T是3x2）
        M_k_T_new = Q[:, :2]
        
        return M_k_T_new
    
    def compute_beta_polak_ribiere(self, Rg_curr, Rg_prev, eta_prev):
        """
        计算Polak-Ribière系数
        
        Args:
            Rg_curr: 当前Riemannian梯度（3x2）
            Rg_prev: 前一个Riemannian梯度（3x2）
            eta_prev: 前一个共轭梯度方向（3x2）
        
        Returns:
            beta: Polak-Ribière系数
        """
        # 计算梯度差
        y = Rg_curr - Rg_prev
        
        # 计算内积
        numerator = np.trace(Rg_curr.T @ y)
        denominator = np.trace(Rg_prev.T @ Rg_prev)
        
        if denominator < 1e-10:
            return 0.0
        
        beta = max(0.0, numerator / denominator)
        return beta
    
    def update_M_k(self, M_k_T_init, S, D_k, max_iter=50):
        """
        使用Riemannian共轭梯度算法更新M_k
        
        Args:
            M_k_T_init: 初始M_k^T（3x2）
            S: 场景结构（3xN）
            D_k: 观测数据（2xN）
            max_iter: 最大迭代次数
        
        Returns:
            M_k_T_opt: 优化后的M_k^T（3x2）
            error_history: 误差历史
        """
        M_k_T = M_k_T_init.copy()
        error_history = []
        
        # 初始化
        Rg_prev = None
        eta_prev = None
        
        for i in range(max_iter):
            # 计算Riemannian梯度
            Rg = self.compute_riemannian_gradient(M_k_T, S, D_k)
            
            # 计算目标函数值
            M_k = M_k_T.T
            residual = M_k @ S - D_k
            error = 0.5 * np.sum(residual ** 2)
            error_history.append(error)
            
            # 检查收敛
            grad_norm = np.linalg.norm(Rg)
            if grad_norm < self.tolerance:
                if self.verbose:
                    print(f"    M_k更新收敛于迭代 {i+1}，梯度范数: {grad_norm:.6e}")
                break
            
            # 计算共轭梯度方向
            if Rg_prev is None:
                # 第一次迭代，使用负梯度方向
                eta = -Rg
            else:
                # 向量传输
                eta_prev_transported = self.vector_transport(eta_prev, M_k_T_prev, M_k_T)
                
                # 计算Polak-Ribière系数
                beta = self.compute_beta_polak_ribiere(Rg, Rg_prev, eta_prev_transported)
                
                # 共轭梯度方向
                eta = -Rg + beta * eta_prev_transported
            
            # 线搜索（简化版：使用固定步长，可以改进为Wolfe条件）
            step_size = 0.1 / (1.0 + i * 0.01)  # 自适应步长
            
            # 尝试步长
            M_k_T_candidate = self.retract_to_stiefel(M_k_T, eta, step_size)
            M_k_candidate = M_k_T_candidate.T
            residual_candidate = M_k_candidate @ S - D_k
            error_candidate = 0.5 * np.sum(residual_candidate ** 2)
            
            # 如果误差增加，减小步长
            if error_candidate > error:
                step_size *= 0.5
                M_k_T_candidate = self.retract_to_stiefel(M_k_T, eta, step_size)
            
            # 更新
            M_k_T_prev = M_k_T
            M_k_T = M_k_T_candidate
            Rg_prev = Rg
            eta_prev = eta
        
        return M_k_T, error_history
    
    def update_S(self, M_dict, D_dict, point_tracks, image_point_indices):
        """
        更新场景结构S
        
        根据论文公式(11)：
        S = (M^T * M)^(-1) * M^T * D
        
        其中M是所有M_k堆叠而成的矩阵
        
        Args:
            M_dict: 字典，key为图像名称，value为M_k（2x3）
            D_dict: 字典，key为图像名称，value为D_k（2xN_k）
            point_tracks: 点跟踪字典
            image_point_indices: 图像点索引字典
        
        Returns:
            S: 3xN矩阵，更新后的场景结构
        """
        # 构建所有观测的矩阵
        M_list = []
        D_list = []
        point_id_to_col = {}  # 将point_id映射到S矩阵的列索引
        col_to_point_id = []
        
        # 为每个3D点分配列索引
        for pid in sorted(point_tracks.keys()):
            point_id_to_col[pid] = len(col_to_point_id)
            col_to_point_id.append(pid)
        
        N = len(point_tracks)
        
        # 构建M和D矩阵
        for img_name in M_dict.keys():
            if img_name not in D_dict:
                continue
            
            M_k = M_dict[img_name]  # 2x3
            D_k = D_dict[img_name]  # 2xN_k
            
            # 找出该图像观测到的点
            img_point_indices = image_point_indices.get(img_name, {})
            
            for pid, local_idx in img_point_indices.items():
                if pid not in point_id_to_col:
                    continue
                
                col_idx = point_id_to_col[pid]
                
                # 添加M_k的行（每行对应一个观测）
                M_row = M_k[0, :]  # 第一行（u坐标）
                M_list.append((M_row, col_idx, 0))  # (行向量, 列索引, 观测索引)
                
                M_row = M_k[1, :]  # 第二行（v坐标）
                M_list.append((M_row, col_idx, 1))
                
                # 添加D_k的值
                D_val_u = D_k[0, local_idx]
                D_val_v = D_k[1, local_idx]
                D_list.append((D_val_u, 0))
                D_list.append((D_val_v, 1))
        
        # 构建矩阵M和向量D
        num_observations = len(M_list) // 2  # 每个点有两个观测（u和v）
        M_full = np.zeros((num_observations * 2, 3))
        D_full = np.zeros(num_observations * 2)
        
        obs_idx = 0
        for pid in sorted(point_tracks.keys()):
            col_idx = point_id_to_col[pid]
            
            # 找出所有观测该点的图像
            for img_name in M_dict.keys():
                if img_name not in image_point_indices:
                    continue
                if pid not in image_point_indices[img_name]:
                    continue
                
                M_k = M_dict[img_name]
                D_k = D_dict[img_name]
                local_idx = image_point_indices[img_name][pid]
                
                # 添加u坐标观测
                M_full[obs_idx, :] = M_k[0, :]
                D_full[obs_idx] = D_k[0, local_idx]
                obs_idx += 1
                
                # 添加v坐标观测
                M_full[obs_idx, :] = M_k[1, :]
                D_full[obs_idx] = D_k[1, local_idx]
                obs_idx += 1
        
        # 截断到实际观测数
        M_full = M_full[:obs_idx, :]
        D_full = D_full[:obs_idx]
        
        # 最小二乘求解
        # S = (M^T * M)^(-1) * M^T * D
        M_T_M = M_full.T @ M_full
        M_T_D = M_full.T @ D_full
        
        # 检查M^T*M是否可逆
        if np.linalg.cond(M_T_M) > 1e12:
            # 条件数太大，使用伪逆
            S_flat = np.linalg.pinv(M_T_M) @ M_T_D
        else:
            S_flat = np.linalg.solve(M_T_M, M_T_D)
        
        # 重塑为3xN矩阵（但这里S是3x1的向量，需要重新组织）
        # 实际上，我们需要为每个3D点求解3D坐标
        S = np.zeros((3, N))
        
        # 为每个点单独求解（更稳定的方法）
        for pid in sorted(point_tracks.keys()):
            col_idx = point_id_to_col[pid]
            
            # 找出所有观测该点的图像
            M_rows = []
            D_vals = []
            
            for img_name in M_dict.keys():
                if img_name not in image_point_indices:
                    continue
                if pid not in image_point_indices[img_name]:
                    continue
                
                M_k = M_dict[img_name]
                D_k = D_dict[img_name]
                local_idx = image_point_indices[img_name][pid]
                
                M_rows.append(M_k[0, :])  # u坐标
                M_rows.append(M_k[1, :])  # v坐标
                D_vals.append(D_k[0, local_idx])
                D_vals.append(D_k[1, local_idx])
            
            if len(M_rows) < 2:  # 至少需要2个观测
                continue
            
            M_point = np.array(M_rows)
            D_point = np.array(D_vals)
            
            # 最小二乘求解
            M_T_M_point = M_point.T @ M_point
            M_T_D_point = M_point.T @ D_point
            
            if np.linalg.cond(M_T_M_point) > 1e12:
                S_point = np.linalg.pinv(M_T_M_point) @ M_T_D_point
            else:
                S_point = np.linalg.solve(M_T_M_point, M_T_D_point)
            
            S[:, col_idx] = S_point
        
        return S, point_id_to_col, col_to_point_id
    
    def initialize_M_k(self, num_images):
        """
        初始化M_k矩阵
        
        使用随机初始化，然后投影到Stiefel流形
        
        Args:
            num_images: 图像数量
        
        Returns:
            M_dict: 字典，key为图像索引，value为M_k（2x3）
        """
        M_dict = {}
        
        for k in range(num_images):
            # 随机初始化3x2矩阵
            M_k_T = np.random.randn(3, 2)
            
            # QR分解投影到Stiefel流形
            Q, _ = qr(M_k_T)
            M_k_T = Q[:, :2]
            
            M_k = M_k_T.T  # 2x3
            M_dict[k] = M_k
        
        return M_dict
    
    def solve(self, keypoints_dict, matches_dict, initial_poses=None):
        """
        求解SAR SfM问题
        
        使用交替优化方法：
        1. 固定S，优化M_k（使用Riemannian共轭梯度）
        2. 固定M_k，优化S（使用最小二乘）
        
        Args:
            keypoints_dict: 字典，key为图像名称，value为关键点列表
            matches_dict: 字典，key为(图像1名称, 图像2名称)，value为匹配列表
            initial_poses: 可选的初始位姿字典（用于初始化M_k）
        
        Returns:
            result: 字典，包含：
                - M_dict: 优化后的M_k字典
                - S: 3D场景结构（3xN）
                - point_tracks: 点跟踪信息
                - error_history: 误差历史
        """
        if self.verbose:
            print("="*60)
            print("开始SAR矩阵分解SfM求解...")
            print("="*60)
        
        # 准备数据矩阵
        D_dict, point_tracks, image_point_indices = self.prepare_data_matrices(
            keypoints_dict, matches_dict
        )
        
        if len(D_dict) == 0:
            raise ValueError("没有足够的数据矩阵，无法进行求解")
        
        # 初始化M_k
        image_names = sorted(D_dict.keys())
        num_images = len(image_names)
        
        if initial_poses is not None:
            # 使用初始位姿初始化M_k
            M_dict = {}
            for img_name in image_names:
                if img_name in initial_poses:
                    # 从位姿中提取旋转矩阵的前两行
                    pose = initial_poses[img_name]
                    if 'R' in pose:
                        R_full = np.array(pose['R'])
                        M_k = R_full[:2, :]  # 取前两行
                    else:
                        # 如果没有R，使用随机初始化
                        M_k_T = np.random.randn(3, 2)
                        Q, _ = qr(M_k_T)
                        M_k = Q[:, :2].T
                    M_dict[img_name] = M_k
                else:
                    # 随机初始化
                    M_k_T = np.random.randn(3, 2)
                    Q, _ = qr(M_k_T)
                    M_k = Q[:, :2].T
                    M_dict[img_name] = M_k
        else:
            # 随机初始化
            M_dict_init = self.initialize_M_k(num_images)
            M_dict = {}
            for i, img_name in enumerate(image_names):
                M_dict[img_name] = M_dict_init[i]
        
        # 初始化S（使用最小二乘）
        S, point_id_to_col, col_to_point_id = self.update_S(
            M_dict, D_dict, point_tracks, image_point_indices
        )
        
        # 交替优化
        prev_error = float('inf')
        
        for iteration in range(self.max_iterations):
            # 更新M_k
            if self.verbose:
                print(f"\n迭代 {iteration + 1}/{self.max_iterations}")
            
            for img_name in image_names:
                M_k = M_dict[img_name]
                D_k = D_dict[img_name]
                M_k_T = M_k.T
                
                # 更新M_k（只使用该图像观测到的点）
                # 提取当前图像观测到的点对应的S子集
                img_point_indices = image_point_indices.get(img_name, {})
                if len(img_point_indices) == 0:
                    continue
                
                # 构建S_k：只包含当前图像观测到的点
                # D_k的列顺序由image_point_indices的local_idx决定（local_idx是D_k的列索引）
                # 需要按照local_idx从小到大排序来提取S_k，确保列顺序与D_k一致
                sorted_pids = sorted(img_point_indices.items(), key=lambda x: x[1])  # 按local_idx排序
                S_k_cols = []
                for pid, local_idx in sorted_pids:
                    if pid in point_id_to_col:
                        col_idx = point_id_to_col[pid]
                        S_k_cols.append(col_idx)
                    else:
                        # 如果point_id不在point_id_to_col中，说明该点不在S中，跳过
                        if self.verbose:
                            print(f"  警告: 图像 {img_name} 的点 {pid} 不在S中")
                        continue
                
                if len(S_k_cols) == 0:
                    continue
                
                # 提取S的子集，确保列顺序与D_k一致
                S_k = S[:, S_k_cols]  # 3xN_k
                
                # 验证形状匹配
                if S_k.shape[1] != D_k.shape[1]:
                    if self.verbose:
                        print(f"  警告: 图像 {img_name} 的S_k形状 {S_k.shape} 与D_k形状 {D_k.shape} 不匹配，跳过")
                    continue
                
                M_k_T_new, _ = self.update_M_k(M_k_T, S_k, D_k, max_iter=10)
                M_dict[img_name] = M_k_T_new.T
            
            # 更新S
            S, point_id_to_col, col_to_point_id = self.update_S(
                M_dict, D_dict, point_tracks, image_point_indices
            )
            
            # 计算总误差
            total_error = 0.0
            for img_name in image_names:
                M_k = M_dict[img_name]
                D_k = D_dict[img_name]
                
                # 提取当前图像观测到的点对应的S子集
                img_point_indices = image_point_indices.get(img_name, {})
                if len(img_point_indices) == 0:
                    continue
                
                # 构建S_k：只包含当前图像观测到的点
                sorted_pids = sorted(img_point_indices.items(), key=lambda x: x[1])
                S_k_cols = []
                for pid, local_idx in sorted_pids:
                    if pid in point_id_to_col:
                        S_k_cols.append(point_id_to_col[pid])
                
                if len(S_k_cols) == 0:
                    continue
                
                S_k = S[:, S_k_cols]  # 3xN_k
                
                # 确保形状匹配
                if S_k.shape[1] != D_k.shape[1]:
                    continue
                
                residual = M_k @ S_k - D_k
                total_error += 0.5 * np.sum(residual ** 2)
            
            self.error_history.append(total_error)
            
            if self.verbose:
                print(f"  总误差: {total_error:.6e}")
            
            # 检查收敛
            if abs(prev_error - total_error) < self.tolerance:
                if self.verbose:
                    print(f"\n收敛于迭代 {iteration + 1}")
                break
            
            prev_error = total_error
        
        if self.verbose:
            print("="*60)
            print("SAR矩阵分解SfM求解完成")
            print("="*60)
        
        return {
            'M_dict': M_dict,
            'S': S,
            'point_tracks': point_tracks,
            'point_id_to_col': point_id_to_col,
            'col_to_point_id': col_to_point_id,
            'image_point_indices': image_point_indices,
            'error_history': self.error_history,
            'D_dict': D_dict
        }
    
    def convert_to_poses_and_points(self, result, initial_poses=None, image_angles=None, sar_params=None):
        """
        将矩阵分解结果转换为位姿和3D点
        
        Args:
            result: solve()方法的返回结果
            initial_poses: 可选的初始位姿字典（用于恢复平移向量）
            image_angles: 可选的图像角度信息（用于从SAR几何计算平移向量）
            sar_params: 可选的SAR参数（用于从SAR几何计算平移向量）
        
        Returns:
            poses_dict: 字典，key为图像名称，value为位姿字典（包含R, t）
            points_3d: Nx3数组，3D点坐标
        """
        M_dict = result['M_dict']
        S = result['S']
        col_to_point_id = result['col_to_point_id']
        
        # 转换3D点
        points_3d = S.T  # Nx3
        
        # 转换位姿
        poses_dict = {}
        for img_name, M_k in M_dict.items():
            # M_k是2x3矩阵，是旋转矩阵的前两行
            # 需要补充第三行使其成为完整的旋转矩阵
            
            # 使用Gram-Schmidt过程补充第三行
            row1 = M_k[0, :] / np.linalg.norm(M_k[0, :])
            row2 = M_k[1, :] - np.dot(M_k[1, :], row1) * row1
            row2 = row2 / np.linalg.norm(row2)
            row3 = np.cross(row1, row2)
            
            R_full = np.vstack([row1, row2, row3])
            
            # 确保R是正交矩阵（通过SVD）
            U, _, Vt = np.linalg.svd(R_full)
            R_full = U @ Vt
            
            # 恢复平移向量
            # 优先使用初始位姿的平移向量，否则从SAR几何计算
            t = np.zeros(3)
            if initial_poses is not None and img_name in initial_poses:
                # 使用初始位姿的平移向量
                pose = initial_poses[img_name]
                if 't' in pose:
                    t_init = np.array(pose['t'])
                    if t_init.size == 3:
                        t = t_init.flatten()
            elif image_angles is not None and sar_params is not None and img_name in image_angles:
                # 从SAR几何计算平移向量
                try:
                    from .geometry import compute_sar_camera_pose
                    angles = image_angles[img_name]
                    dep = angles.get('depression', 31.57)
                    azi = angles.get('azimuth', 0)
                    _, t_sar, _ = compute_sar_camera_pose(dep, azi, sar_params)
                    t = t_sar.flatten()
                except Exception as e:
                    if self.verbose:
                        print(f"  警告: 无法从SAR几何计算 {img_name} 的平移向量: {e}")
                    t = np.zeros(3)
            
            poses_dict[img_name] = {
                'R': R_full.tolist(),
                't': t.tolist()
            }
        
        return poses_dict, points_3d

