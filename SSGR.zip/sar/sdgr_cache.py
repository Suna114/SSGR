"""SDGR 光栅化器实例缓存（按相机几何与图像尺寸复用，避免每帧重建）。"""
from __future__ import annotations

from typing import Callable, Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn


class SDGRRasterizerCache:
    """进程内单例缓存 SARGaussianRasterizer 模块。"""

    _instance: Optional["SDGRRasterizerCache"] = None

    @classmethod
    def global_cache(cls) -> "SDGRRasterizerCache":
        if cls._instance is None:
            cls._instance = SDGRRasterizerCache()
        return cls._instance

    @classmethod
    def clear_global(cls) -> None:
        if cls._instance is not None:
            cls._instance.clear()

    def __init__(self) -> None:
        self._rasterizers: Dict[Tuple, nn.Module] = {}

    def clear(self) -> None:
        self._rasterizers.clear()

    def get(self, key: Tuple, build_fn: Callable[[], nn.Module]) -> nn.Module:
        if key not in self._rasterizers:
            self._rasterizers[key] = build_fn()
        return self._rasterizers[key]


def sdgr_rasterizer_cache_key(
    image_height: int,
    image_width: int,
    R_world_to_radar,
    camera_center_world,
    range_pixel_spacing: float,
    azimuth_pixel_spacing: float,
    use_sig3dgs_visibility: bool,
    scene_scale: Optional[float],
    device: torch.device,
    prefer_cuda: bool = False,
) -> Tuple:
    R = R_world_to_radar
    if isinstance(R, torch.Tensor):
        R = R.detach().cpu().numpy()
    R = np.asarray(R, dtype=np.float32)

    cc = camera_center_world
    if cc is None:
        cc_arr = np.zeros(3, dtype=np.float32)
    else:
        if isinstance(cc, torch.Tensor):
            cc = cc.detach().cpu().numpy()
        cc_arr = np.asarray(cc, dtype=np.float32).reshape(-1)

    return (
        int(image_height),
        int(image_width),
        R.tobytes(),
        tuple(float(x) for x in cc_arr.tolist()),
        float(range_pixel_spacing),
        float(azimuth_pixel_spacing),
        bool(use_sig3dgs_visibility),
        float(scene_scale) if scene_scale is not None else None,
        str(device),
        bool(prefer_cuda),
    )
