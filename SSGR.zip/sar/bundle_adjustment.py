# sar_bundle_adjustment.py
"""
SAR专用的Bundle Adjustment实现
使用SAR的重投影误差（斜距误差）而不是像素误差
"""
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation as R
import warnings

try:
    from .geometry import compute_sar_camera_pose
except ImportError:
    compute_sar_camera_pose = None


def compute_sar_range_from_image_coord(y_image, sar_params, depression_angle):
    """
    从SAR图像坐标计算斜距
    
    Args:
        y_image: 图像坐标y（距离向坐标）
        sar_params: SAR系统参数
        depression_angle: 俯视角（度）
    
    Returns:
        R: 斜距（米）
    """
    # 获取SAR参数
    Nr = sar_params.get('Nr', 512)  # 距离向采样点数
    camera_height = sar_params.get('camera_height', 1365.0)
    fs = sar_params.get('fs', 1.1 * 240e6)  # 采样率
    C = sar_params.get('C', 3e8)  # 光速
    
    # 计算像素对应的物理尺寸
    range_pixel_size = C / (2 * fs)  # 每个像素对应的斜距增量
    
    # 计算参考斜距（从俯视角）
    dep_rad = np.deg2rad(depression_angle)
    R0 = camera_height / np.sin(dep_rad)  # 参考斜距
    
    # 将图像坐标转换为物理坐标
    # 图像坐标原点在左上角，需要转换到中心
    y_norm = (y_image - Nr / 2.0) * range_pixel_size
    
    # 计算从平台到点的斜距
    R_point = R0 + y_norm
    
    return R_point


def compute_sar_reprojection_error_range(point3d, R_cam, t_cam, image_point, 
                                         depression_angle, sar_params):
    """
    计算SAR重投影误差（斜距误差）
    
    Args:
        point3d: 3D点坐标 (3,) - 世界坐标系
        R_cam: 旋转矩阵 (3x3) - 从世界坐标系到相机坐标系
        t_cam: 平移向量 (3x1) - 从世界坐标系到相机坐标系
        image_point: 图像点坐标 (2,) - (x, y)，x=方位向，y=距离向
        depression_angle: 俯视角（度）
        sar_params: SAR系统参数
    
    Returns:
        error_range: 斜距误差（米）
        error_azimuth: 方位向误差（米）
    """
    # 计算雷达位置（在世界坐标系中）
    # t = -R @ P_radar，所以 P_radar = -R.T @ t
    P_radar = -R_cam.T @ t_cam.flatten()
    
    # 计算从雷达到3D点的斜距（投影的斜距）
    R_projected = np.linalg.norm(point3d - P_radar)
    
    # 从图像坐标计算观测的斜距
    y_image = image_point[1]  # 距离向坐标
    R_observed = compute_sar_range_from_image_coord(y_image, sar_params, depression_angle)
    
    # 计算斜距误差
    error_range = R_projected - R_observed
    
    # 计算方位向误差（可选，用于更完整的误差度量）
    # 这里简化处理，主要关注斜距误差
    error_azimuth = 0.0  # 可以后续实现
    
    return error_range, error_azimuth


def _poses_from_shared_camera_height(camera_height, image_names, image_angles, sar_params_base):
    """
    由给定俯视角/方位角与共享平台高度，按几何模型生成各相机 R,t（所有相机同高度）。
    """
    if compute_sar_camera_pose is None:
        raise ImportError("sar_geometry.compute_sar_camera_pose 不可用，无法使用固定角度+仅高度 BA")
    sp = dict(sar_params_base)
    sp['camera_height'] = float(camera_height)
    poses = {}
    for img_name in image_names:
        ang = image_angles.get(img_name, {})
        dep = float(ang.get('depression', 31.57))
        azi = float(ang.get('azimuth', 0.0))
        R_cam, t_cam, _ = compute_sar_camera_pose(dep, azi, sp)
        poses[img_name] = (R_cam, t_cam.reshape(3, 1))
    return poses


def _sar_bundle_adjustment_height_only(
    reconstruction_data, sar_params, point_cloud, image_data, image_K,
    image_angles, observations, max_iterations, ftol, xtol, verbose
):
    """
    俯视角与方位角固定为 image_angles 中的数据；所有相机共享一个 camera_height；优化该高度与三维点。
    """
    image_names = list(image_data.keys())
    num_images = len(image_names)
    num_points = len(point_cloud)
    h0 = float(sar_params.get('camera_height', 12000.0))
    num_point_params = num_points * 3
    total_params = 1 + num_point_params

    pts_flat = np.asarray(point_cloud, dtype=np.float64).flatten()
    if not np.all(np.isfinite(pts_flat)):
        pts_flat = np.nan_to_num(pts_flat, nan=0.0, posinf=0.0, neginf=0.0)

    # 与 SO-RCG 尺度一致：场景米级时 sar_params['camera_height'] 可能仍为物理 12000，用点云范围约束初值
    extent = float(np.max(np.abs(pts_flat))) if pts_flat.size else 1.0
    h_lo = max(1e-3, extent * 0.1)
    h_hi = min(1e9, max(extent * 1e4, 1e3))
    h0 = float(np.clip(h0, h_lo, h_hi))

    params = np.zeros(total_params)
    params[0] = h0
    params[1:] = pts_flat

    image_name_to_idx = {name: i for i, name in enumerate(image_names)}

    def residual_function(params_vec):
        h = float(params_vec[0])
        if h <= 0:
            return np.full(len(observations), 1e12)
        point_params = params_vec[1:].reshape(num_points, 3)
        poses = _poses_from_shared_camera_height(h, image_names, image_angles, sar_params)
        sp_range = dict(sar_params)
        sp_range['camera_height'] = h
        residuals = []
        for img_name, point2d_idx, point3d_idx in observations:
            if point3d_idx < 0 or point3d_idx >= num_points:
                continue
            img_idx = image_name_to_idx.get(img_name, -1)
            if img_idx < 0:
                continue
            R_cam, t_cam = poses[img_name]
            point3d = point_params[point3d_idx]
            if 'keypoints' in reconstruction_data and img_name in reconstruction_data['keypoints']:
                kp = reconstruction_data['keypoints'][img_name]
                if point2d_idx < len(kp):
                    if hasattr(kp[point2d_idx], 'pt'):
                        image_point = np.array([kp[point2d_idx].pt[0], kp[point2d_idx].pt[1]])
                    else:
                        image_point = np.array(kp[point2d_idx][:2])
                else:
                    continue
            else:
                continue
            angles = image_angles.get(img_name, {})
            depression_angle = angles.get('depression', 31.57)
            error_range, _ = compute_sar_reprojection_error_range(
                point3d, R_cam, t_cam.reshape(3, 1), image_point,
                depression_angle, sp_range
            )
            residuals.append(error_range)
        return np.array(residuals)

    if verbose:
        print(f"🔧 SAR BA（固定俯仰/方位，仅优化共享高度 + 三维点）")
        print(f"   - 图像数量: {num_images}")
        print(f"   - 3D点数量: {num_points}")
        print(f"   - 观测数量: {len(observations)}")
        print(f"   - 参数: 1 个共享高度 + {num_point_params} 个点坐标")

    initial_residuals = residual_function(params)
    initial_error = np.sqrt(np.mean(initial_residuals**2)) if len(initial_residuals) else 0.0
    if verbose:
        print(f"   - 初始斜距误差 RMS: {initial_error:.4f} 米")

    # trf 需要有限边界；点坐标用场景范围放大，避免 ±inf 导致初值校验失败
    ext = max(extent, 1.0)
    p_lo = -1e7 * ext
    p_hi = 1e7 * ext
    bounds_lower = np.concatenate([[h_lo], np.full(num_point_params, p_lo)])
    bounds_upper = np.concatenate([[h_hi], np.full(num_point_params, p_hi)])

    try:
        result = least_squares(
            residual_function,
            params,
            method='trf',
            bounds=(bounds_lower, bounds_upper),
            max_nfev=max_iterations * max(len(observations), 1),
            verbose=2 if verbose else 0,
            ftol=ftol,
            xtol=xtol,
        )
        opt = result.x
        h_opt = float(opt[0])
        optimized_point_cloud = opt[1:].reshape(num_points, 3)
        poses = _poses_from_shared_camera_height(h_opt, image_names, image_angles, sar_params)

        optimized_image_data = {}
        for img_name in image_names:
            R_cam, t_cam = poses[img_name]
            _, _, ref = image_data[img_name]
            optimized_image_data[img_name] = (R_cam, t_cam, ref)

        final_residuals = residual_function(opt)
        final_error = np.sqrt(np.mean(final_residuals**2)) if len(final_residuals) else 0.0

        if verbose:
            print(f"✅ SAR BA（固定角度）完成")
            print(f"   - 优化后共享 camera_height: {h_opt:.4f} m")
            print(f"   - 最终斜距误差 RMS: {final_error:.4f} 米")

        optimized_data = {
            'point_cloud': optimized_point_cloud,
            'image_data': optimized_image_data,
            'image_K': image_K,
            'image_angles': image_angles,
            'observations': observations,
        }
        error_history = {
            'initial_error': initial_error,
            'final_error': final_error,
            'iterations': result.nfev,
            'optimized_camera_height': h_opt,
        }
        return optimized_data, error_history
    except Exception as e:
        if verbose:
            print(f"⚠️ SAR BA（固定角度）失败: {e}")
        warnings.warn(str(e))
        return (
            {
                'point_cloud': point_cloud,
                'image_data': image_data,
                'image_K': image_K,
                'image_angles': image_angles,
                'observations': observations,
            },
            {'initial_error': initial_error, 'final_error': initial_error, 'iterations': 0},
        )


def sar_bundle_adjustment(reconstruction_data, sar_params, max_iterations=50,
                         ftol=1e-6, xtol=1e-8, verbose=True):
    """
    SAR专用的Bundle Adjustment
    
    Args:
        reconstruction_data: 重建数据字典，包含：
            - point_cloud: 3D点云 (Nx3)
            - image_data: 字典，key为图像名，value为(R, t, ref)
            - image_K: 字典，key为图像名，value为K矩阵
            - image_angles: 字典，key为图像名，value为{'depression': deg, 'azimuth': deg}
            - observations: 观测列表，每个元素为(image_name, point2d_idx, point3d_idx)
        sar_params: SAR系统参数
        max_iterations: 最大迭代次数
        verbose: 是否打印详细信息
    
    Returns:
        optimized_data: 优化后的数据，格式与reconstruction_data相同
        error_history: 误差历史记录
    """
    # 提取数据
    point_cloud = reconstruction_data['point_cloud'].copy()
    image_data = reconstruction_data['image_data'].copy()
    image_K = reconstruction_data['image_K'].copy()
    image_angles = reconstruction_data['image_angles'].copy()
    observations = reconstruction_data['observations']

    # ---------- 模式：俯视角/方位角固定为数据给定值，仅优化共享 camera_height + 三维点 ----------
    if sar_params.get('ba_fix_angles_optimize_height_only'):
        return _sar_bundle_adjustment_height_only(
            reconstruction_data, sar_params, point_cloud, image_data, image_K,
            image_angles, observations, max_iterations, ftol, xtol, verbose
        )
    
    # 构建参数向量
    # 参数顺序：[R1, t1, R2, t2, ..., X1, Y1, Z1, X2, Y2, Z2, ...]
    # R用四元数表示（4个参数），t用3个参数，每个3D点用3个参数
    
    # 获取图像列表
    image_names = list(image_data.keys())
    num_images = len(image_names)
    num_points = len(point_cloud)
    
    # 初始化参数向量
    # 每个相机：4（四元数）+ 3（平移）= 7个参数
    # 每个3D点：3个参数
    num_camera_params = num_images * 7
    num_point_params = num_points * 3
    total_params = num_camera_params + num_point_params
    
    # 构建参数向量
    params = np.zeros(total_params)
    
    # 填充相机参数
    for i, img_name in enumerate(image_names):
        R_cam, t_cam, _ = image_data[img_name]
        # 将旋转矩阵转换为四元数
        r = R.from_matrix(R_cam)
        quat = r.as_quat()  # [x, y, z, w]
        # 存储四元数（w在前，用于优化稳定性）
        params[i*7:i*7+4] = quat[[3, 0, 1, 2]]  # [w, x, y, z]
        params[i*7+4:i*7+7] = t_cam.flatten()
    
    # 填充3D点参数
    params[num_camera_params:] = point_cloud.flatten()
    
    # 构建观测索引映射
    image_name_to_idx = {name: i for i, name in enumerate(image_names)}
    
    def residual_function(params_vec):
        """
        计算残差函数
        """
        residuals = []
        
        # 解析参数
        camera_params = params_vec[:num_camera_params].reshape(num_images, 7)
        point_params = params_vec[num_camera_params:].reshape(num_points, 3)
        
        # 遍历所有观测
        for img_name, point2d_idx, point3d_idx in observations:
            if point3d_idx < 0 or point3d_idx >= num_points:
                continue
            
            # 获取相机参数
            img_idx = image_name_to_idx.get(img_name, -1)
            if img_idx < 0:
                continue
            
            quat = camera_params[img_idx, :4]  # [w, x, y, z]
            t_cam = camera_params[img_idx, 4:7]
            
            # 将四元数转换为旋转矩阵
            r = R.from_quat([quat[1], quat[2], quat[3], quat[0]])  # [x, y, z, w]
            R_cam = r.as_matrix()
            
            # 获取3D点
            point3d = point_params[point3d_idx]
            
            # 获取图像点坐标
            # 从keypoints中获取
            if 'keypoints' in reconstruction_data and img_name in reconstruction_data['keypoints']:
                kp = reconstruction_data['keypoints'][img_name]
                if point2d_idx < len(kp):
                    # OpenCV KeyPoint对象
                    if hasattr(kp[point2d_idx], 'pt'):
                        image_point = np.array([kp[point2d_idx].pt[0], kp[point2d_idx].pt[1]])
                    else:
                        # 如果是numpy数组
                        image_point = np.array(kp[point2d_idx][:2])
                else:
                    continue
            else:
                # 如果没有keypoints，跳过
                continue
            
            # 获取俯视角
            angles = image_angles.get(img_name, {})
            depression_angle = angles.get('depression', 31.57)
            
            # 计算SAR重投影误差
            error_range, _ = compute_sar_reprojection_error_range(
                point3d, R_cam, t_cam.reshape(3, 1), image_point,
                depression_angle, sar_params
            )
            
            # 添加残差（使用斜距误差）
            residuals.append(error_range)
        
        return np.array(residuals)
    
    # 运行优化
    if verbose:
        print(f"🔧 开始SAR Bundle Adjustment优化...")
        print(f"   - 图像数量: {num_images}")
        print(f"   - 3D点数量: {num_points}")
        print(f"   - 观测数量: {len(observations)}")
        print(f"   - 参数总数: {total_params}")
    
    # 初始误差
    initial_residuals = residual_function(params)
    initial_error = np.sqrt(np.mean(initial_residuals**2))
    if verbose:
        print(f"   - 初始斜距误差: {initial_error:.4f} 米")
    
    # 运行优化
    try:
        result = least_squares(
            residual_function,
            params,
            method='lm',  # Levenberg-Marquardt算法
            max_nfev=max_iterations * len(observations),  # 最大函数评估次数
            verbose=2 if verbose else 0,
            ftol=ftol,  # 函数容差
            xtol=xtol,  # 参数容差
        )
        
        optimized_params = result.x
        
        # 解析优化后的参数
        optimized_camera_params = optimized_params[:num_camera_params].reshape(num_images, 7)
        optimized_point_params = optimized_params[num_camera_params:].reshape(num_points, 3)
        
        # 更新image_data
        optimized_image_data = {}
        for i, img_name in enumerate(image_names):
            quat = optimized_camera_params[i, :4]
            t_cam = optimized_camera_params[i, 4:7]
            r = R.from_quat([quat[1], quat[2], quat[3], quat[0]])
            R_cam = r.as_matrix()
            # 保持原有的ref
            _, _, ref = image_data[img_name]
            optimized_image_data[img_name] = (R_cam, t_cam.reshape(3, 1), ref)
        
        # 更新点云
        optimized_point_cloud = optimized_point_params
        
        # 最终误差
        final_residuals = residual_function(optimized_params)
        final_error = np.sqrt(np.mean(final_residuals**2))
        
        if verbose:
            print(f"✅ SAR Bundle Adjustment完成")
            print(f"   - 最终斜距误差: {final_error:.4f} 米")
            print(f"   - 误差改善: {initial_error - final_error:.4f} 米 ({((initial_error - final_error) / initial_error * 100):.2f}%)")
        
        # 构建优化后的数据
        optimized_data = {
            'point_cloud': optimized_point_cloud,
            'image_data': optimized_image_data,
            'image_K': image_K,
            'image_angles': image_angles,
            'observations': observations,
        }
        
        error_history = {
            'initial_error': initial_error,
            'final_error': final_error,
            'iterations': result.nfev,
        }
        
        return optimized_data, error_history
        
    except Exception as e:
        if verbose:
            print(f"⚠️ SAR Bundle Adjustment优化失败: {e}")
        warnings.warn(f"SAR Bundle Adjustment优化失败: {e}")
        return reconstruction_data, {'initial_error': initial_error, 'final_error': initial_error, 'iterations': 0}


def prepare_sar_ba_data(sfm_instance):
    """
    从SFM实例准备SAR BA所需的数据
    
    Args:
        sfm_instance: SFM类的实例
    
    Returns:
        reconstruction_data: 重建数据字典
    """
    # 构建观测列表
    observations = []
    
    # 遍历所有图像和它们的ref
    for img_name, (R_cam, t_cam, ref) in sfm_instance.image_data.items():
        # 加载特征点
        try:
            kp, desc = sfm_instance._LoadFeatures(img_name)
        except:
            continue
        
        # 遍历ref，找到所有有效的3D点关联
        for point2d_idx, point3d_idx in enumerate(ref):
            if point3d_idx >= 0 and point3d_idx < len(sfm_instance.point_cloud):
                observations.append((img_name, point2d_idx, int(point3d_idx)))
    
    # 构建重建数据
    reconstruction_data = {
        'point_cloud': sfm_instance.point_cloud,
        'image_data': sfm_instance.image_data,
        'image_K': sfm_instance.image_K,
        'image_angles': sfm_instance.image_angles,
        'observations': observations,
    }
    
    # 添加keypoints（如果可用）
    keypoints_dict = {}
    for img_name in sfm_instance.image_data.keys():
        try:
            kp, desc = sfm_instance._LoadFeatures(img_name)
            keypoints_dict[img_name] = kp
        except:
            pass
    
    if keypoints_dict:
        reconstruction_data['keypoints'] = keypoints_dict
    
    return reconstruction_data

