"""SAR 3D→2D 投影 + 协方差 CUDA preprocess（diff-sar-rasterization）。"""
from __future__ import annotations

import torch
from typing import Dict, Optional, Tuple

_PREPROCESS_CUDA_LOGGED = False


def sar_preprocess_cuda_available() -> bool:
    try:
        from diff_sar_rasterization import SAR_PREPROCESS_CUDA_AVAILABLE
        return bool(SAR_PREPROCESS_CUDA_AVAILABLE)
    except ImportError:
        return False


class _PreprocessSAR3DScatter(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        means3D,
        scales,
        rotations,
        R_world_to_radar,
        camera_center,
        W,
        H,
        scale_modifier,
        delta_az,
        delta_rng,
        mode,
    ):
        from diff_sar_rasterization._C import preprocess_sar3d_forward
        (
            means2D, depths, conics, cov2d,
            means_radar, slant_range, radii,
        ) = preprocess_sar3d_forward(
            means3D.contiguous(),
            scales.contiguous(),
            rotations.contiguous(),
            R_world_to_radar.contiguous().reshape(3, 3),
            camera_center.contiguous().reshape(3),
            int(W), int(H), int(mode),
            float(scale_modifier), float(delta_az), float(delta_rng),
        )
        r0 = 0.0
        if int(mode) == 0 and means_radar.numel() > 0:
            r_plane = torch.sqrt(
                means_radar[:, 1] * means_radar[:, 1]
                + means_radar[:, 2] * means_radar[:, 2] + 1e-8
            )
            r0 = float(torch.median(r_plane).item())
        ctx.save_for_backward(
            means3D, scales, rotations, R_world_to_radar, camera_center,
            means_radar, cov2d,
        )
        ctx.W, ctx.H = int(W), int(H)
        ctx.mode = int(mode)
        ctx.scale_modifier = float(scale_modifier)
        ctx.delta_az = float(delta_az)
        ctx.delta_rng = float(delta_rng)
        ctx.r0 = float(r0)
        return means2D, depths, conics, cov2d, means_radar, slant_range, radii

    @staticmethod
    def backward(ctx, grad_means2D, grad_depths, grad_conics, grad_cov2d, *rest):
        if grad_means2D is None and grad_conics is None:
            return (None,) * 11
        from diff_sar_rasterization._C import preprocess_sar3d_backward
        means3D, scales, rotations, R_wr, cam, means_radar, cov2d = ctx.saved_tensors
        gm2d = grad_means2D if grad_means2D is not None else torch.zeros_like(means_radar[:, :2])
        gc = grad_conics if grad_conics is not None else torch.zeros(means3D.shape[0], 3, device=means3D.device)
        dL_dmeans3D, dL_dscales, dL_drotations = preprocess_sar3d_backward(
            means3D, scales, rotations, R_wr.reshape(3, 3), cam.reshape(3),
            means_radar, cov2d, gm2d.contiguous(), gc.contiguous(),
            ctx.W, ctx.H, ctx.mode, ctx.scale_modifier,
            ctx.delta_az, ctx.delta_rng, ctx.r0,
        )
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        return (
            dL_dmeans3D, dL_dscales, dL_drotations,
            None, None, None, None, None, None, None, None,
        )


def preprocess_sar3d(
    means3D: torch.Tensor,
    scales: torch.Tensor,
    rotations: torch.Tensor,
    R_world_to_radar: torch.Tensor,
    camera_center: torch.Tensor,
    image_width: int,
    image_height: int,
    *,
    mode: int = 0,
    scale_modifier: float = 1.0,
    delta_azimuth: float,
    delta_range: float,
) -> Tuple[torch.Tensor, ...]:
    """
    mode: 0=scatter OZX, 1=shadow OXY
    Returns: means2D, depths, conics, cov2d, means_radar, slant_range, radii
    """
    R = R_world_to_radar.to(device=means3D.device, dtype=means3D.dtype)
    cam = camera_center.to(device=means3D.device, dtype=means3D.dtype)
    return _PreprocessSAR3DScatter.apply(
        means3D, scales, rotations, R, cam,
        int(image_width), int(image_height),
        float(scale_modifier), float(delta_azimuth), float(delta_range),
        int(mode),
    )


def project_gaussians_sdgr_cuda(
    means3D: torch.Tensor,
    scales: torch.Tensor,
    rotations: torch.Tensor,
    R_world_to_radar: torch.Tensor,
    camera_center: torch.Tensor,
    image_width: int,
    image_height: int,
    delta_azimuth: float,
    delta_range: float,
    scale_modifier: float = 1.0,
) -> Dict[str, torch.Tensor]:
    """散射 pass 完整 CUDA preprocess，对齐 project_gaussians_to_2d 输出。"""
    global _PREPROCESS_CUDA_LOGGED
    if not _PREPROCESS_CUDA_LOGGED:
        print("[SAR SDGR] preprocess_sar3d CUDA 已启用（3D→2D 投影+协方差 fused kernel）")
        _PREPROCESS_CUDA_LOGGED = True
    (
        means2D, depths, conics, cov2d,
        means_radar, slant_range, radii,
    ) = preprocess_sar3d(
        means3D, scales, rotations, R_world_to_radar, camera_center,
        image_width, image_height,
        mode=0,
        scale_modifier=scale_modifier,
        delta_azimuth=delta_azimuth,
        delta_range=delta_range,
    )
    N = means3D.shape[0]
    cov2D = cov2d.new_zeros(N, 2, 2)
    cov2D[:, 0, 0] = cov2d[:, 0]
    cov2D[:, 0, 1] = cov2d[:, 1]
    cov2D[:, 1, 0] = cov2d[:, 1]
    cov2D[:, 1, 1] = cov2d[:, 2]
    return {
        "means2D": means2D,
        "depths": depths,
        "conics": conics,
        "cov2D": cov2D,
        "means_radar": means_radar,
        "slant_range": slant_range,
        "radii": radii.float(),
    }


def project_shadow_sdgr_cuda(
    means3D: torch.Tensor,
    scales: torch.Tensor,
    rotations: torch.Tensor,
    R_world_to_radar: torch.Tensor,
    camera_center: torch.Tensor,
    image_width: int,
    image_height: int,
    delta_azimuth: float,
    delta_range: float,
    scale_modifier: float = 1.0,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """阴影 pass：means2D_shadow, slant_range, conics, cov2D(2x2)。"""
    means2D, depths, conics, cov2d, _, slant_range, _ = preprocess_sar3d(
        means3D, scales, rotations, R_world_to_radar, camera_center,
        image_width, image_height,
        mode=1,
        scale_modifier=scale_modifier,
        delta_azimuth=delta_azimuth,
        delta_range=delta_range,
    )
    N = means3D.shape[0]
    cov2D = cov2d.new_zeros(N, 2, 2)
    cov2D[:, 0, 0] = cov2d[:, 0]
    cov2D[:, 0, 1] = cov2d[:, 1]
    cov2D[:, 1, 0] = cov2d[:, 1]
    cov2D[:, 1, 1] = cov2d[:, 2]
    return means2D, slant_range, conics, cov2D
