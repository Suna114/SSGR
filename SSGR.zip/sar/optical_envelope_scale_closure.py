"""在 gs_satellite_poses 之后，用 optical verify 的 ru/rv 自动闭合 sfm_mstar_camera_height_scale。"""

from __future__ import annotations

import importlib.util
import json
import math
import os
import sys
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from sar.imaging_mode import dataset_convention_debug_summary, resolve_dataset_world_yaw_deg
from sar.scene_scale_closure import _cli_flag_specified


@dataclass
class OpticalEnvelopeScaleResult:
    camera_height_scale: float
    median_ratio_u: float
    median_ratio_v: float
    num_views: int
    iterations: int
    converged: bool
    mesh_uniform_scale: float = 1.0

    def format_summary(self) -> str:
        status = "已收敛" if self.converged else "未完全收敛（已达最大迭代）"
        mesh_line = ""
        if abs(self.mesh_uniform_scale - 1.0) > 0.01:
            mesh_line = (
                f"\n  → 同时建议: --sfm_mesh_prior_final_uniform_scale "
                f"{self.mesh_uniform_scale:.4f}"
            )
        return (
            f"\n[mstar_optical_envelope_scale] {status}\n"
            f"  全角度中位 ratio_u={self.median_ratio_u:.3f}  ratio_v={self.median_ratio_v:.3f}  "
            f"({self.num_views} 视角, {self.iterations} 轮)\n"
            f"  → 训练/verify 用: --sfm_mstar_camera_height_scale {self.camera_height_scale:.4f}"
            f"{mesh_line}\n"
            f"  verify: python scripts/verify_sar_imaging_envelope_match.py -s <数据> "
            f"--projection_mode optical\n"
        )


def optical_envelope_auto_scale_enabled(args: Any) -> bool:
    return bool(getattr(args, "sfm_mstar_optical_envelope_auto_scale", False))


def _load_scale_json(path: str) -> Dict[str, Any]:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return data if isinstance(data, dict) else {}


def _formula_camera_height_m(scale: Dict[str, Any]) -> float:
    formula = float(scale.get("mstar_formula_camera_height_m", 0.0) or 0.0)
    if formula > 1e-6:
        return formula
    cur_scale = float(scale.get("mstar_camera_height_scale", 1.0) or 1.0)
    cur_h = float(
        scale.get("mstar_init_camera_height_m", scale.get("camera_height", 0.0)) or 0.0
    )
    if cur_h > 1e-6 and cur_scale > 1e-6:
        return float(cur_h / cur_scale)
    return cur_h if cur_h > 1e-6 else 0.0


def apply_mstar_camera_height_scale_to_json(
    scale: Dict[str, Any],
    new_scale: float,
) -> Dict[str, Any]:
    """按 formula_H × scale 更新 sar_scale_params 中的 H / scene_scale / R0 等。"""
    s = float(new_scale)
    if not math.isfinite(s) or s <= 0:
        raise ValueError(f"invalid camera_height_scale={new_scale!r}")

    formula_h = _formula_camera_height_m(scale)
    old_h = float(
        scale.get("mstar_init_camera_height_m", scale.get("camera_height", 0.0)) or 0.0
    )
    if formula_h <= 1e-6 and old_h > 1e-6:
        formula_h = old_h
    if formula_h <= 1e-6:
        raise RuntimeError("sar_scale_params 缺少 mstar_formula_camera_height_m / camera_height")

    new_h = float(formula_h * s)
    ratio = new_h / max(old_h, 1e-9)

    scale["mstar_formula_camera_height_m"] = float(formula_h)
    scale["mstar_camera_height_scale"] = s
    scale["mstar_init_camera_height_m"] = new_h
    scale["camera_height"] = new_h
    scale["scaled_camera_height"] = new_h

    for key in ("scene_scale", "mstar_init_scene_scale"):
        if key in scale:
            scale[key] = float(scale[key]) * ratio
    for key in ("mstar_init_slant_range_m", "mstar_init_ground_range_m", "median_slant_range_m"):
        if key in scale:
            scale[key] = float(scale[key]) * ratio

    scale["mstar_optical_envelope_scale_applied"] = True
    scale["mstar_optical_envelope_scale_value"] = s
    return scale


def _import_verify_module():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    scripts = os.path.join(root, "scripts")
    data_prep = os.path.join(root, "scripts", "data_prep")
    for p in (root, scripts, data_prep):
        if p not in sys.path:
            sys.path.insert(0, p)
    spec = importlib.util.spec_from_file_location(
        "verify_sar_imaging_envelope_match",
        os.path.join(scripts, "verify_sar_imaging_envelope_match.py"),
    )
    if spec is None or spec.loader is None:
        raise ImportError("无法加载 scripts/verify_sar_imaging_envelope_match.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def _import_verify_evaluate_views():
    return _import_verify_module().evaluate_views


def _sparse_pointcloud_usable_for_verify(source_path: str, *, min_pts: int = 64) -> bool:
    sparse_dir = os.path.join(source_path, "sparse", "0")
    try:
        mod = _import_verify_module()
        pts = mod._load_points3d_world(sparse_dir)
        return int(getattr(pts, "shape", (0,))[0]) >= int(min_pts)
    except Exception:
        return False


def _resolve_optical_verify_use_nominal_box(
    source_path: str,
    *,
    use_nominal_box: Optional[bool] = None,
) -> bool:
    """gs_model replace 后优先用实际 points3D 闭合/验证；显式 use_nominal_box 可覆盖。"""
    if use_nominal_box is not None:
        return bool(use_nominal_box)
    return not _sparse_pointcloud_usable_for_verify(source_path)


def measure_optical_verify_ratios(
    source_path: str,
    *,
    use_nominal_box: Optional[bool] = None,
    world_yaw_deg: float = -90.0,
) -> Tuple[float, float, int]:
    """返回 (median_ru, median_rv, n_views)。"""
    evaluate_views = _import_verify_evaluate_views()
    use_box = _resolve_optical_verify_use_nominal_box(
        source_path, use_nominal_box=use_nominal_box
    )
    views, _, _, _ = evaluate_views(
        source_path,
        camera_height_scale=1.0,
        use_nominal_box=use_box,
        projection_mode="optical",
        world_yaw_deg=world_yaw_deg,
    )
    if not views:
        raise RuntimeError("optical verify 无有效视角（需 sparse/0 + shadow_diagnostic bbox）")
    ru = float(np.median([v.ratio_u for v in views]))
    rv = float(np.median([v.ratio_v for v in views]))
    return ru, rv, len(views)


def _ratio_cost(ru: float, rv: float) -> float:
    """ru/rv 同等重要；用 hypot 避免只优化 ru 而牺牲 rv。"""
    return float(
        math.hypot(
            math.log(max(float(ru), 1e-6)),
            math.log(max(float(rv), 1e-6)),
        )
    )


def _ratio_cost(
    ru: float,
    rv: float,
    *,
    target_ratio: float = 1.0,
    min_ratio: float = 0.0,
    undersize_weight: float = 2.5,
) -> float:
    """Score envelope fit, with extra cost when the simulated target is undersized."""
    tgt = max(float(target_ratio), 1e-6)
    min_r = max(float(min_ratio), 0.0)
    under_w = max(float(undersize_weight), 1.0)
    err2 = 0.0
    for ratio in (float(ru), float(rv)):
        r = max(ratio, 1e-6)
        e = math.log(r / tgt)
        if min_r > 0.0 and r < min_r:
            e *= under_w
        err2 += e * e
    return float(math.sqrt(err2))


def _optical_closure_side_views_only(source_path: str, args: Any) -> bool:
    """mstar_axis_split 汇总时侧视 L/W 更可靠，优先用侧视闭合 rv。"""
    mode = str(
        getattr(args, "target_dimension_summary_azimuth_mode", "")
        or getattr(args, "shadow_geometry_azimuth_mode", "")
        or ""
    ).strip().lower()
    if mode == "mstar_axis_split":
        return True
    summary_path = os.path.join(
        source_path,
        "adaptive_threshold_visualization",
        "target_dimension_constraints_summary.txt",
    )
    if not os.path.isfile(summary_path):
        return False
    try:
        with open(summary_path, encoding="utf-8", errors="ignore") as f:
            text = f.read()
    except OSError:
        return False
    return "mstar_axis_split" in text or "L=Tr、W=Taz" in text


def _within_tolerance(ru: float, rv: float, tol: float) -> bool:
    lim = math.log(max(1.0 + float(tol), 1.0001))
    return abs(math.log(max(float(ru), 1e-6))) <= lim and abs(math.log(max(float(rv), 1e-6))) <= lim


def _meets_envelope_goal(
    ru: float,
    rv: float,
    *,
    tol: float,
    target_ratio: float,
    min_ratio: float,
) -> bool:
    min_r = max(float(min_ratio), 0.0)
    tgt = max(float(target_ratio), 1e-6)
    hi = tgt * max(1.0 + float(tol), 1.0001)
    return float(ru) >= min_r and float(rv) >= min_r and float(ru) <= hi and float(rv) <= hi


def _within_abs_ratio_u_tolerance(ru: float, tol: float) -> bool:
    return abs(float(ru) - 1.0) <= float(max(tol, 0.0))


def optimize_mstar_camera_height_scale_for_optical_verify(
    source_path: str,
    args: Any,
    *,
    scale_min: float = 0.35,
    scale_max: float = 1.5,
    ratio_tol: float = 0.05,
    max_iterations: int = 12,
    use_nominal_box: Optional[bool] = None,
    world_yaw_deg: float = -90.0,
    tune_mesh: bool = True,
    mesh_min: float = 0.85,
    mesh_max: float = 2.5,
    target_ratio: float = 1.02,
    min_ratio: float = 1.0,
    undersize_weight: float = 2.5,
    side_views_only: bool = False,
    side_views_for_mesh: bool = False,
    side_tol_deg: float = 5.0,
    side_u_refine: bool = False,
    side_u_tol: float = 0.01,
    verbose: bool = True,
) -> Optional[OpticalEnvelopeScaleResult]:
    """
    迭代调整 mstar_camera_height_scale、重写 gs_satellite_poses，直到 optical ru/rv≈1。

    ru/rv < 1 → 模拟偏小 → 减小 scale（相机拉近）；
    ru/rv > 1 → 模拟偏大 → 增大 scale。
    """
    from sar.gs_satellite_poses import apply_gs_satellite_poses_to_sparse
    from sar.sfm_scale_params import merge_scale_params_file

    scale_path = os.path.join(source_path, "sar_scale_params.json")
    if not os.path.isfile(scale_path):
        if verbose:
            print("⚠️ [mstar_optical_envelope_scale] 跳过：无 sar_scale_params.json")
        return None

    evaluate_views = _import_verify_evaluate_views()
    use_box = _resolve_optical_verify_use_nominal_box(
        source_path, use_nominal_box=use_nominal_box
    )
    if verbose and not use_box:
        print(
            "  [mstar_optical_envelope_scale] 使用 sparse/0 points3D 评估 ru/rv"
            "（与 replace 后实际几何一致）"
        )
    if verbose and side_views_for_mesh:
        print(
            "  [mstar_optical_envelope_scale] mesh 阶段用侧视 rv 闭合"
            f"（±{side_tol_deg:.0f}° 方位，mstar_axis_split 口径）"
        )
    scale = _load_scale_json(scale_path)
    formula_h = _formula_camera_height_m(scale)
    if formula_h <= 1e-6:
        if verbose:
            print("⚠️ [mstar_optical_envelope_scale] 跳过：无法解析 formula camera height")
        return None

    lo = float(min(scale_min, scale_max))
    hi = float(max(scale_min, scale_max))
    cur = float(scale.get("mstar_camera_height_scale", 1.0) or 1.0)
    cur = float(np.clip(cur, lo, hi))

    cache: Dict[float, Tuple[float, float, int, float]] = {}

    def _median_ratios(views: Sequence[Any]) -> Tuple[float, float]:
        if not views:
            return 1.0, 1.0
        return (
            float(np.median([v.ratio_u for v in views])),
            float(np.median([v.ratio_v for v in views])),
        )

    def _eval_views(
        *,
        side_only: Optional[bool] = None,
        **kwargs: Any,
    ) -> Tuple[float, float, int, float]:
        use_side = side_views_only if side_only is None else bool(side_only)
        views, _, _, _ = evaluate_views(
            source_path,
            camera_height_scale=1.0,
            use_nominal_box=use_box,
            projection_mode="optical",
            world_yaw_deg=world_yaw_deg,
            side_views_only=use_side,
            side_tol_deg=side_tol_deg,
            **kwargs,
        )
        if not views:
            raise RuntimeError("optical verify 无有效视角")
        ru, rv = _median_ratios(views)
        return ru, rv, len(views), _ratio_cost(
            ru,
            rv,
            target_ratio=target_ratio,
            min_ratio=min_ratio,
            undersize_weight=undersize_weight,
        )

    def _eval_h(s: float) -> Tuple[float, float, int, float]:
        s = float(np.clip(s, lo, hi))
        key = round(s, 6)
        if key in cache:
            ru, rv, n, cost = cache[key]
            return ru, rv, n, cost
        apply_mstar_camera_height_scale_to_json(scale, s)
        merge_scale_params_file(scale_path, scale)
        apply_gs_satellite_poses_to_sparse(
            source_path, args, transform_points=False
        )
        ru, rv, n, cost = _eval_views(side_only=False)
        cache[key] = (ru, rv, n, cost)
        if verbose:
            print(
                f"  [mstar_optical_envelope_scale] scale={s:.4f}  "
                f"ru={ru:.3f}  rv={rv:.3f}  cost={cost:.4f}"
            )
        return ru, rv, n, cost

    ru, rv, n_views, _ = _eval_h(cur)
    if _meets_envelope_goal(
        ru,
        rv,
        tol=ratio_tol,
        target_ratio=target_ratio,
        min_ratio=min_ratio,
    ) and not (side_u_refine and side_views_for_mesh):
        result = OpticalEnvelopeScaleResult(
            camera_height_scale=cur,
            median_ratio_u=ru,
            median_ratio_v=rv,
            num_views=n_views,
            iterations=1,
            converged=True,
        )
        if verbose:
            print(result.format_summary())
        return result

    # scale↑ → 相机拉远 → sim 变小 → ru↓（与 verify 注释一致）
    ru_lo, _, _, _ = _eval_h(lo)
    ru_hi, _, _, _ = _eval_h(hi)
    if not (ru_lo >= ru_hi):
        if verbose:
            print(
                "⚠️ [mstar_optical_envelope_scale] ru 未随 scale 单调下降，"
                f"仍尝试二分 (ru@{lo:.2f}={ru_lo:.3f}, ru@{hi:.2f}={ru_hi:.3f})"
            )

    best_s = cur
    best_ru, best_rv = ru, rv
    best_cost = _ratio_cost(
        ru,
        rv,
        target_ratio=target_ratio,
        min_ratio=min_ratio,
        undersize_weight=undersize_weight,
    )
    iterations = 2

    for _ in range(int(max_iterations)):
        mid = 0.5 * (lo + hi)
        ru_m, rv_m, n_m, cost_m = _eval_h(mid)
        iterations += 1
        if cost_m < best_cost:
            best_s, best_ru, best_rv, best_cost, n_views = mid, ru_m, rv_m, cost_m, n_m
        if _meets_envelope_goal(
            ru_m,
            rv_m,
            tol=ratio_tol,
            target_ratio=target_ratio,
            min_ratio=min_ratio,
        ):
            best_s, best_ru, best_rv, n_views = mid, ru_m, rv_m, n_m
            break
        # ru < 1 → 模拟偏小 → 减小 scale；ru > 1 → 增大 scale
        if ru_m < float(target_ratio):
            hi = mid
        else:
            lo = mid
        if abs(hi - lo) < 0.005:
            break

    converged = _meets_envelope_goal(
        best_ru,
        best_rv,
        tol=ratio_tol,
        target_ratio=target_ratio,
        min_ratio=min_ratio,
    )
    best_mesh = float(scale.get("mstar_computed_mesh_uniform_scale", 1.0) or 1.0)

    def _eval_mesh_only(ms: float) -> Tuple[float, float, int, float]:
        side_only = bool(side_views_for_mesh)
        return _eval_views(
            side_only=side_only,
            mesh_uniform_scale=float(ms),
        )

    if tune_mesh and not converged:
        mesh_lo = float(min(mesh_min, mesh_max))
        mesh_hi = float(max(mesh_min, mesh_max))
        mesh_best = best_mesh
        mesh_cost = 1e18
        apply_mstar_camera_height_scale_to_json(scale, float(best_s))
        merge_scale_params_file(scale_path, scale)
        apply_gs_satellite_poses_to_sparse(
            source_path, args, transform_points=False
        )
        for ms in np.linspace(mesh_lo, mesh_hi, 9):
            ru_m, rv_m, n_m, cost_m = _eval_mesh_only(float(ms))
            iterations += 1
            if verbose:
                tag = "side" if side_views_for_mesh else "all"
                print(
                    f"  [mstar_optical_envelope_scale] h_scale={best_s:.4f} "
                    f"mesh={ms:.4f} ({tag})  "
                    f"ru={ru_m:.3f}  rv={rv_m:.3f}  cost={cost_m:.4f}"
                )
            if cost_m < mesh_cost:
                mesh_best, best_ru, best_rv, mesh_cost, n_views = (
                    float(ms),
                    ru_m,
                    rv_m,
                    cost_m,
                    n_m,
                )
        best_mesh = mesh_best
        scale["mstar_computed_mesh_uniform_scale"] = float(best_mesh)
        converged = _meets_envelope_goal(
            best_ru,
            best_rv,
            tol=ratio_tol,
            target_ratio=target_ratio,
            min_ratio=min_ratio,
        )

    apply_mstar_camera_height_scale_to_json(scale, best_s)
    scale["mstar_computed_mesh_uniform_scale"] = float(best_mesh)
    merge_scale_params_file(scale_path, scale)
    apply_gs_satellite_poses_to_sparse(source_path, args, transform_points=False)

    if abs(best_mesh - 1.0) > 0.01:
        from sar.scene_scale_closure import (
            scale_sparse_points3d_uniform,
            sync_target_envelope_from_sparse_points3d,
        )

        n_scaled = scale_sparse_points3d_uniform(source_path, best_mesh)
        if n_scaled > 0:
            sync_target_envelope_from_sparse_points3d(
                source_path, args, verbose=verbose
            )
            scale["mstar_computed_mesh_uniform_scale"] = 1.0
            scale["mstar_optical_envelope_mesh_baked"] = float(best_mesh)
            merge_scale_params_file(scale_path, scale)
            if verbose:
                print(
                    f"  [mstar_optical_envelope_scale] mesh x{best_mesh:.4f} "
                    f"已烘焙至 sparse points3D（{n_scaled} 点），包络已回写"
                )
            best_mesh = 1.0

    if side_u_refine and side_views_for_mesh:
        from sar.scene_scale_closure import (
            scale_sparse_points3d_uniform,
            sync_target_envelope_from_sparse_points3d,
        )

        try:
            side_ru0, side_rv0, side_n0, _ = _eval_views(side_only=True)
        except Exception:
            side_ru0, side_rv0, side_n0 = 1.0, 1.0, 0

        if side_n0 > 0 and abs(float(side_ru0) - float(target_ratio)) > float(side_u_tol):
            q_floor = max(
                float(min_ratio) / max(float(side_ru0), 1e-6),
                float(min_ratio) / max(float(side_rv0), 1e-6),
            )
            q = float(np.clip(max(float(target_ratio) / max(side_ru0, 1e-6), q_floor), 0.75, 1.75))
            best_q = q
            best_side_ru = float(side_ru0)
            best_side_rv = float(side_rv0)
            best_side_err = abs(float(side_ru0) - float(target_ratio))

            for _ in range(5):
                ru_q, rv_q, _, _ = _eval_views(side_only=True, mesh_uniform_scale=q)
                err_q = abs(float(ru_q) - float(target_ratio))
                if err_q < best_side_err:
                    best_q = float(q)
                    best_side_ru = float(ru_q)
                    best_side_rv = float(rv_q)
                    best_side_err = float(err_q)
                if abs(float(ru_q) - float(target_ratio)) <= float(side_u_tol):
                    break
                q_floor = max(
                    q * float(min_ratio) / max(float(ru_q), 1e-6),
                    q * float(min_ratio) / max(float(rv_q), 1e-6),
                )
                q_next = q * float(target_ratio) / max(float(ru_q), 1e-6)
                q = float(np.clip(max(q_next, q_floor), 0.75, 1.75))
                # 小幅平面尺度与投影包络近似线性；反复乘 1/ru 可快速收敛。
                q = float(np.clip(q / max(float(ru_q), 1e-6), 0.75, 1.35))

            if abs(best_q - 1.0) > 1e-4:
                n_scaled = scale_sparse_points3d_uniform(source_path, best_q)
                if n_scaled > 0:
                    sync_target_envelope_from_sparse_points3d(
                        source_path, args, verbose=verbose
                    )
                    scale = _load_scale_json(scale_path)
                    scale["mstar_optical_side_u_refine_applied"] = True
                    scale["mstar_optical_side_u_refine_factor"] = float(best_q)
                    scale["mstar_optical_side_u_refine_before_ru"] = float(side_ru0)
                    scale["mstar_optical_side_u_refine_before_rv"] = float(side_rv0)
                    scale["mstar_optical_side_u_refine_after_ru"] = float(best_side_ru)
                    scale["mstar_optical_side_u_refine_after_rv"] = float(best_side_rv)
                    scale["mstar_optical_side_u_refine_tol"] = float(side_u_tol)
                    merge_scale_params_file(scale_path, scale)
                    if verbose:
                        status = (
                            "达标"
                            if abs(float(best_side_ru) - float(target_ratio)) <= float(side_u_tol)
                            else "未完全达标"
                        )
                        print(
                            "  [mstar_optical_envelope_scale] side ratio_u 精修 "
                            f"x{best_q:.6f}（{n_scaled} 点）: "
                            f"ru {side_ru0:.3f}→{best_side_ru:.3f}, "
                            f"rv {side_rv0:.3f}→{best_side_rv:.3f}，{status}"
                        )

    try:
        report_ru, report_rv, n_views, _ = _eval_views(side_only=False)
        best_ru, best_rv = report_ru, report_rv
    except Exception:
        pass

    setattr(args, "sfm_mstar_camera_height_scale", float(best_s))
    setattr(args, "sfm_mesh_prior_final_uniform_scale", float(best_mesh))
    full = getattr(args, "_full_cli_args", None)
    if full is not None and full is not args:
        setattr(full, "sfm_mstar_camera_height_scale", float(best_s))
        setattr(full, "sfm_mesh_prior_final_uniform_scale", float(best_mesh))

    result = OpticalEnvelopeScaleResult(
        camera_height_scale=float(best_s),
        median_ratio_u=float(best_ru),
        median_ratio_v=float(best_rv),
        num_views=int(n_views),
        iterations=int(iterations),
        converged=bool(converged),
        mesh_uniform_scale=float(best_mesh),
    )
    if verbose:
        print(result.format_summary())
    return result


def maybe_optical_envelope_scale_closure(
    source_path: str,
    args: Any,
    *,
    verbose: bool = True,
) -> Optional[OpticalEnvelopeScaleResult]:
    """convert 在 gs_satellite_poses 之后调用。"""
    from sar.gs_satellite_poses import gs_satellite_poses_enabled

    if not optical_envelope_auto_scale_enabled(args):
        return None
    if not gs_satellite_poses_enabled(args):
        return None

    argv = getattr(getattr(args, "_full_cli_args", None) or args, "_argv", None) or sys.argv
    if _cli_flag_specified(argv, ("--sfm_mstar_camera_height_scale",)):
        if verbose:
            print(
                "[mstar_optical_envelope_scale] 跳过：已显式指定 --sfm_mstar_camera_height_scale"
            )
        return None

    scale_path = os.path.join(source_path, "sar_scale_params.json")
    scale = _load_scale_json(scale_path) if os.path.isfile(scale_path) else {}
    if not scale.get("gs_satellite_poses_applied"):
        if verbose:
            print(
                "[mstar_optical_envelope_scale] 跳过：gs_satellite_poses 尚未写入 sparse"
            )
        return None

    tol = float(getattr(args, "sfm_mstar_optical_envelope_scale_tol", 0.05) or 0.05)
    s_min = float(getattr(args, "sfm_mstar_optical_envelope_scale_min", 0.35) or 0.35)
    s_max = float(getattr(args, "sfm_mstar_optical_envelope_scale_max", 1.5) or 1.5)
    max_iter = int(getattr(args, "sfm_mstar_optical_envelope_scale_max_iter", 12) or 12)
    yaw = float(resolve_dataset_world_yaw_deg(args, scale, default_yaw_deg=-90.0))
    tune_mesh = bool(getattr(args, "sfm_mstar_optical_envelope_tune_mesh", True))
    target_ratio = float(getattr(args, "sfm_mstar_optical_envelope_target_ratio", 1.02) or 1.02)
    min_ratio = float(getattr(args, "sfm_mstar_optical_envelope_min_ratio", 1.0) or 1.0)
    mesh_min = float(getattr(args, "sfm_mstar_optical_envelope_mesh_min", 0.85) or 0.85)
    mesh_max = float(getattr(args, "sfm_mstar_optical_envelope_mesh_max", 2.5) or 2.5)
    undersize_weight = float(getattr(args, "sfm_mstar_optical_envelope_undersize_weight", 2.5) or 2.5)
    side_u_refine = bool(getattr(args, "sfm_mstar_optical_side_u_refine", False))
    side_u_tol = float(getattr(args, "sfm_mstar_optical_side_u_tol", 0.01) or 0.01)
    side_only = _optical_closure_side_views_only(source_path, args)

    if verbose:
        print(
            "\n[mstar_optical_envelope_scale] 开始 optical verify 尺度闭合 "
            f"(目标 ru/rv≈1±{100.0 * tol:.0f}%, scale∈[{s_min}, {s_max}])"
        )
        print(f"  {dataset_convention_debug_summary(source_path, scale)}; world_yaw={yaw:.1f} deg")
        print(
            f"  envelope target={target_ratio:.3f}, min={min_ratio:.3f}, "
            f"mesh_search=[{mesh_min:.3f}, {mesh_max:.3f}]"
        )
        if scale.get("gs_target_envelope_from_sparse"):
            print(
                "  gs_target_envelope_from_sparse：全视角闭合 H，"
                "侧视闭合 mesh rv，闭合后烘焙至 points3D"
            )

    return optimize_mstar_camera_height_scale_for_optical_verify(
        source_path,
        args,
        scale_min=s_min,
        scale_max=s_max,
        ratio_tol=tol,
        max_iterations=max_iter,
        world_yaw_deg=yaw,
        tune_mesh=tune_mesh,
        mesh_min=mesh_min,
        mesh_max=mesh_max,
        target_ratio=target_ratio,
        min_ratio=min_ratio,
        undersize_weight=undersize_weight,
        side_views_for_mesh=side_only,
        side_u_refine=side_u_refine,
        side_u_tol=side_u_tol,
        verbose=verbose,
    )
