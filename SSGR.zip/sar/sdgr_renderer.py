"""
SAR Differentiable Gaussian Splatting Rasterizer (SDGR)

对齐 SAR-3DGS 论文 (Zhang et al., IEEE JSTARS 2026)：
- 散射 splatting：斜距投影到成像平面 OZX（式 7–10）
- 阴影 splatting：阴影平面 OXY 上正射投影 + 透射率累积（式 12–15）
- 最终渲染：I_render = I_intensity ⊙ I_shadow（式 16–18）
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
from typing import Dict, Optional, Tuple

from utils.general_utils import build_scaling_rotation

from .gaussian_projection import SARScatteringIntensity
from .rasterizer import (
    DEFAULT_SAR_PARAMS,
    SAR_RASTERIZATION_AVAILABLE,
    alpha_blend_sar,
    _clamp_cov2d_footprint,
    _sanitize_sar_raster_inputs,
    sar_cuda_rasterization_enabled,
)

from .sdgr_cache import SDGRRasterizerCache, sdgr_rasterizer_cache_key

try:
    from .cuda_preprocess import project_gaussians_sdgr_cuda, project_shadow_sdgr_cuda, sar_preprocess_cuda_available
except ImportError:
    project_gaussians_sdgr_cuda = None
    project_shadow_sdgr_cuda = None
    sar_preprocess_cuda_available = lambda: False

_SDGR_BACKEND_LOGGED = False


def get_cached_sdgr_rasterizer(
    image_height: int,
    image_width: int,
    R_world_to_radar: np.ndarray,
    camera_center_world=None,
    scene_scale: Optional[float] = None,
    use_attenuation: bool = True,
    use_sig3dgs_visibility: bool = True,
    shadow_detach_grad: bool = True,
    prefer_cuda: bool = False,
    range_pixel_spacing: Optional[float] = None,
    azimuth_pixel_spacing: Optional[float] = None,
    device: Optional[torch.device] = None,
) -> "SARGaussianRasterizer":
    """按相机几何缓存 SDGR 模块，避免每帧重建。"""
    dev = device or torch.device("cuda")
    key = sdgr_rasterizer_cache_key(
        image_height, image_width, R_world_to_radar, camera_center_world,
        float(range_pixel_spacing or DEFAULT_SAR_PARAMS["range_pixel_spacing"]),
        float(azimuth_pixel_spacing or DEFAULT_SAR_PARAMS["azimuth_pixel_spacing"]),
        use_sig3dgs_visibility, scene_scale, dev, bool(prefer_cuda),
    )

    def _build():
        return SARGaussianRasterizer(
            image_height=image_height,
            image_width=image_width,
            R_world_to_radar=R_world_to_radar,
            camera_center_world=camera_center_world,
            scene_scale=scene_scale,
            use_attenuation=use_attenuation,
            use_sig3dgs_visibility=use_sig3dgs_visibility,
            shadow_detach_grad=shadow_detach_grad,
            prefer_cuda=prefer_cuda,
            range_pixel_spacing=range_pixel_spacing,
            azimuth_pixel_spacing=azimuth_pixel_spacing,
        ).to(dev)

    return SDGRRasterizerCache.global_cache().get(key, _build)


def _world_to_radar(
    means3D: torch.Tensor,
    R_world_to_radar: torch.Tensor,
    camera_center_world: torch.Tensor,
) -> torch.Tensor:
    """论文式 (5)：μ = Q^T (μ_w − T_p)，此处 R 即 Q^T。"""
    rel = means3D - camera_center_world.reshape(1, 3)
    return torch.matmul(rel, R_world_to_radar.T)


def _cov3d_from_scale_rot(
    scales: torch.Tensor,
    rotations: torch.Tensor,
    scale_modifier: float = 1.0,
) -> torch.Tensor:
    L = build_scaling_rotation(scale_modifier * scales, rotations)
    return torch.bmm(L, L.transpose(-1, -2))


def _cov3d_to_radar(
    cov3D_world: torch.Tensor,
    R_world_to_radar: torch.Tensor,
) -> torch.Tensor:
    """论文式 (6)：Σ = Q^T Σ_w Q。"""
    R = R_world_to_radar
    return torch.bmm(torch.bmm(R.T.unsqueeze(0).expand(cov3D_world.shape[0], -1, -1), cov3D_world),
                     R.unsqueeze(0).expand(cov3D_world.shape[0], -1, -1))


def _project_scattering_sar3dgs(
    means_radar: torch.Tensor,
    delta_az: float,
    delta_rng: float,
    image_width: int,
    image_height: int,
    eps: float = 1e-4,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    散射 splatting：成像平面 OZX（论文式 8）。
    x' = x_r，r' = sqrt(y_r^2 + z_r^2) − r_0。
    """
    xr = means_radar[:, 0]
    yr = means_radar[:, 1]
    zr = means_radar[:, 2]
    r_plane = torch.sqrt(yr * yr + zr * zr + eps * eps)
    r0 = torch.median(r_plane) if r_plane.numel() > 0 else torch.zeros((), device=means_radar.device)

    x_pix = xr / delta_az + image_width * 0.5
    y_pix = (r_plane - r0) / delta_rng + image_height * 0.5
    means2D = torch.stack([x_pix, y_pix], dim=1)
    depths = r_plane
    return means2D, depths, yr, zr, r_plane


def _project_shadow_plane_sar3dgs(
    means_radar: torch.Tensor,
    delta_az: float,
    delta_rng: float,
    image_width: int,
    image_height: int,
) -> torch.Tensor:
    """
    阴影 splatting：阴影平面 OXY 正射投影（论文式 12–13）。
    x' = x_r / δ_az，y' = y_r / δ_rng（相对图像中心）。
    """
    xr = means_radar[:, 0]
    yr = means_radar[:, 1]
    x_pix = xr / delta_az + image_width * 0.5
    y_pix = yr / delta_rng + image_height * 0.5
    return torch.stack([x_pix, y_pix], dim=1)


def _cov2d_scattering_jacobian(
    cov3D_radar: torch.Tensor,
    yr: torch.Tensor,
    zr: torch.Tensor,
    r_plane: torch.Tensor,
    delta_az: float,
    delta_rng: float,
    eps: float = 1e-6,
) -> torch.Tensor:
    """论文式 (9–10)：Σ' = J Σ J^T，再换算到像素尺度。"""
    N = cov3D_radar.shape[0]
    device = cov3D_radar.device
    denom = torch.clamp(r_plane, min=max(eps, delta_rng * 0.25))
    J = torch.zeros(N, 2, 3, device=device, dtype=cov3D_radar.dtype)
    J[:, 0, 0] = 1.0 / delta_az
    j_yr = (yr / denom / delta_rng).clamp(-512.0, 512.0)
    j_zr = (zr / denom / delta_rng).clamp(-512.0, 512.0)
    J[:, 1, 1] = j_yr
    J[:, 1, 2] = j_zr
    cov2d = torch.bmm(torch.bmm(J, cov3D_radar), J.transpose(1, 2))
    eye = torch.eye(2, device=device, dtype=cov3D_radar.dtype).unsqueeze(0).expand(N, -1, -1)
    return cov2d + eps * eye


def _cov2d_shadow_jacobian(
    cov3D_radar: torch.Tensor,
    delta_az: float,
    delta_rng: float,
    eps: float = 1e-6,
) -> torch.Tensor:
    """阴影平面 OXY 正射 Jacobian：diag(1/δ_az, 1/δ_rng)。"""
    N = cov3D_radar.shape[0]
    device = cov3D_radar.device
    J = torch.zeros(N, 2, 3, device=device, dtype=cov3D_radar.dtype)
    J[:, 0, 0] = 1.0 / delta_az
    J[:, 1, 1] = 1.0 / delta_rng
    cov2d = torch.bmm(torch.bmm(J, cov3D_radar), J.transpose(1, 2))
    eye = torch.eye(2, device=device, dtype=cov3D_radar.dtype).unsqueeze(0).expand(N, -1, -1)
    return cov2d + eps * eye


def _cov2d_shadow_plane(cov3D_radar: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """阴影平面 OXY 正射投影（论文式 13 中 P 取前两维）。"""
    cov2d = cov3D_radar[:, :2, :2].clone()
    eye = torch.eye(2, device=cov3D_radar.device, dtype=cov3D_radar.dtype).unsqueeze(0).expand(cov2d.shape[0], -1, -1)
    return cov2d + eps * eye


def _compute_occlusion_degrees(
    means_radar: torch.Tensor,
    opacities: torch.Tensor,
    slant_range: torch.Tensor,
) -> torch.Tensor:
    """
    已弃用：全局 per-Gaussian 遮挡度（旧简化版）。
    当前 SDGR 使用阴影平面 OXY 上的 per-pixel 透射率 splatting（见 forward）。
    """
    if opacities.dim() == 2:
        alpha = opacities[:, 0].clamp(0.0, 0.99)
    else:
        alpha = opacities.clamp(0.0, 0.99)

    N = alpha.shape[0]
    device = alpha.device
    if N == 0:
        return torch.ones(0, device=device, dtype=alpha.dtype)

    order = torch.argsort(slant_range, descending=False)
    sorted_alpha = alpha[order]
    one_minus = 1.0 - sorted_alpha
    trans_before = torch.cumprod(
        torch.cat([torch.ones(1, device=device, dtype=alpha.dtype), one_minus[:-1]]),
        dim=0,
    )
    occlusion = torch.zeros(N, device=device, dtype=alpha.dtype)
    occlusion[order] = (1.0 - trans_before).clamp(0.0, 1.0)
    return occlusion


def _alpha_blend(
    means2D: torch.Tensor,
    cov2d: torch.Tensor,
    opacities: torch.Tensor,
    colors: torch.Tensor,
    depths: torch.Tensor,
    background: torch.Tensor,
    H: int,
    W: int,
    prefer_cuda: bool = True,
    far_first: bool = True,
    return_depth: bool = False,
    conics_precomp: Optional[torch.Tensor] = None,
):
    return alpha_blend_sar(
        means2D, cov2d, opacities, colors, depths, background, H, W,
        prefer_cuda=prefer_cuda, far_first=far_first, return_depth=return_depth,
        conics_precomp=conics_precomp,
    )


class SARGaussianRasterizer(nn.Module):
    """
    SAR-3DGS 可微渲染器（--no_sar_fast_mode 路径）。
    """

    def __init__(
        self,
        image_height: int,
        image_width: int,
        R_world_to_radar: np.ndarray,
        camera_center_world=None,
        scene_scale: Optional[float] = None,
        use_attenuation: bool = True,
        use_full_mpa: bool = False,
        use_sig3dgs_visibility: bool = True,
        shadow_detach_grad: bool = True,
        range_pixel_spacing: Optional[float] = None,
        azimuth_pixel_spacing: Optional[float] = None,
        k_e: float = 0.01,
        prefer_cuda: bool = True,
        **_ignored,
    ):
        super().__init__()
        self.image_height = int(image_height)
        self.image_width = int(image_width)
        self.prefer_cuda = bool(prefer_cuda)
        self.use_sig3dgs_visibility = bool(use_sig3dgs_visibility)
        self.shadow_detach_grad = bool(shadow_detach_grad)
        self.scene_scale = float(scene_scale) if scene_scale is not None else 10.0
        self.range_pixel_spacing = float(
            range_pixel_spacing if range_pixel_spacing is not None else DEFAULT_SAR_PARAMS["range_pixel_spacing"]
        )
        self.azimuth_pixel_spacing = float(
            azimuth_pixel_spacing if azimuth_pixel_spacing is not None else DEFAULT_SAR_PARAMS["azimuth_pixel_spacing"]
        )

        self.scattering_calc = SARScatteringIntensity(use_attenuation=use_attenuation)

        R = np.asarray(R_world_to_radar, dtype=np.float32)
        self.register_buffer("R_world_to_radar", torch.from_numpy(R))
        cc = camera_center_world
        if cc is None:
            cc = np.zeros(3, dtype=np.float32)
        self.register_buffer("camera_center_world", torch.tensor(np.asarray(cc, dtype=np.float32).reshape(3)))

        global _SDGR_BACKEND_LOGGED
        if not _SDGR_BACKEND_LOGGED:
            if self.prefer_cuda and sar_cuda_rasterization_enabled():
                print("[SAR SDGR] diff-sar-rasterization CUDA 光栅化已启用（散射+阴影；失败自动降级 Python）")
            elif self.prefer_cuda and SAR_RASTERIZATION_AVAILABLE:
                print("[SAR SDGR] diff-sar-rasterization 已安装但本会话未启用 CUDA（见 SAR_SDGR_FORCE_PYTHON 或先前失败降级）")
            elif self.prefer_cuda:
                print("[SAR SDGR] 未检测到 diff_sar_rasterization，使用 Python 光栅化（较慢）")
                print("           安装: pip install -e submodules/diff-sar-rasterization --no-build-isolation")
            else:
                print("[SAR SDGR] Python alpha 混合（--no_sar_sdgr_cuda 或 SAR_SDGR_FORCE_PYTHON=1）")
            _SDGR_BACKEND_LOGGED = True

    def project_gaussians_to_2d(
        self,
        means3D: torch.Tensor,
        scales: torch.Tensor,
        rotations: torch.Tensor,
        scale_modifier: float = 1.0,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, Optional[torch.Tensor]]:
        device = means3D.device
        R = self.R_world_to_radar.to(device)
        cam = self.camera_center_world.to(device)
        use_cuda_pre = (
            self.prefer_cuda
            and sar_cuda_rasterization_enabled()
            and sar_preprocess_cuda_available()
            and project_gaussians_sdgr_cuda is not None
        )
        if use_cuda_pre:
            out = project_gaussians_sdgr_cuda(
                means3D, scales, rotations, R, cam,
                self.image_width, self.image_height,
                self.azimuth_pixel_spacing, self.range_pixel_spacing,
                scale_modifier=scale_modifier,
            )
            cov3D_world = _cov3d_from_scale_rot(scales, rotations, scale_modifier)
            cov3D_radar = _cov3d_to_radar(cov3D_world, R)
            return (
                out["means2D"], out["cov2D"], out["depths"],
                out["means_radar"], cov3D_radar, out["slant_range"], out["conics"],
            )

        means_radar = _world_to_radar(means3D, R, cam)
        slant_range = torch.norm(means_radar, dim=1)

        means2D, depths, yr, zr, r_plane = _project_scattering_sar3dgs(
            means_radar,
            self.azimuth_pixel_spacing,
            self.range_pixel_spacing,
            self.image_width,
            self.image_height,
        )

        cov3D_world = _cov3d_from_scale_rot(scales, rotations, scale_modifier)
        cov3D_radar = _cov3d_to_radar(cov3D_world, R)
        cov2D = _cov2d_scattering_jacobian(
            cov3D_radar, yr, zr, r_plane,
            self.azimuth_pixel_spacing, self.range_pixel_spacing,
        )
        max_r = float(max(self.image_width, self.image_height, 16))
        cov2D = _clamp_cov2d_footprint(cov2D, max_r)
        return means2D, cov2D, depths, means_radar, cov3D_radar, slant_range, None

    def forward(
        self,
        means3D: torch.Tensor,
        scales: torch.Tensor,
        rotations: torch.Tensor,
        opacities: torch.Tensor,
        colors: torch.Tensor,
        background: torch.Tensor,
        scale_modifier: float = 1.0,
        viewspace_points: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        H, W = self.image_height, self.image_width
        device = means3D.device

        means2D_proj, cov2D, depths, means_radar, cov3D_radar, slant_range, conics_pre = self.project_gaussians_to_2d(
            means3D, scales, rotations, scale_modifier,
        )

        if viewspace_points is None:
            viewspace_points = torch.zeros(
                means3D.shape[0], 3, device=device, dtype=means3D.dtype, requires_grad=True,
            )
            try:
                viewspace_points.retain_grad()
            except Exception:
                pass
        # 前向用投影坐标 means2D_proj；反传梯度写入 viewspace_points[:, :2]
        means2D = means2D_proj + (viewspace_points[:, :2] - viewspace_points[:, :2].detach())
        means2D, cov2D, opacities_scatter = _sanitize_sar_raster_inputs(
            means2D, cov2D, opacities, H, W,
        )

        if colors.dim() == 3:
            scatter_base = colors[:, :, 0].mean(dim=-1)
        elif colors.dim() == 2 and colors.shape[-1] >= 3:
            scatter_base = 0.299 * colors[:, 0] + 0.587 * colors[:, 1] + 0.114 * colors[:, 2]
        elif colors.dim() == 2:
            scatter_base = colors.mean(dim=-1)
        else:
            scatter_base = colors.squeeze(-1)
        scatter_base = torch.clamp(torch.nan_to_num(scatter_base, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)

        scatter = self.scattering_calc.compute_scattering_intensity_batch(scatter_base, depths)
        scatter = torch.clamp(torch.nan_to_num(scatter, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        colors_intensity = scatter.unsqueeze(-1).expand(-1, 3)

        cuda = self.prefer_cuda and sar_cuda_rasterization_enabled()
        I_intensity, depth_map = _alpha_blend(
            means2D, cov2D, opacities_scatter, colors_intensity, depths, background, H, W,
            prefer_cuda=cuda, far_first=True, return_depth=True,
        )
        I_intensity = torch.clamp(torch.nan_to_num(I_intensity, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        depth_map = torch.nan_to_num(depth_map, nan=0.0, posinf=0.0, neginf=0.0)
        depth_map = depth_map.clamp(min=0.0, max=1e6)

        if self.use_sig3dgs_visibility:
            # 阴影 pass 不参与反传（I_shadow 已 detach）；与散射 pass 同用 CUDA（失败自动降级 Python）
            with torch.no_grad():
                if (
                    cuda and sar_preprocess_cuda_available()
                    and project_shadow_sdgr_cuda is not None
                ):
                    means2D_shadow, slant_range_safe, _, cov2D_shadow = project_shadow_sdgr_cuda(
                        means3D, scales, rotations,
                        self.R_world_to_radar.to(device),
                        self.camera_center_world.to(device),
                        W, H,
                        self.azimuth_pixel_spacing, self.range_pixel_spacing,
                        scale_modifier=scale_modifier,
                    )
                else:
                    means2D_shadow = _project_shadow_plane_sar3dgs(
                        means_radar, self.azimuth_pixel_spacing, self.range_pixel_spacing, W, H,
                    )
                    cov2D_shadow = _clamp_cov2d_footprint(
                        _cov2d_shadow_jacobian(cov3D_radar, self.azimuth_pixel_spacing, self.range_pixel_spacing),
                        float(max(W, H, 16)),
                    )
                slant_range_safe = torch.nan_to_num(slant_range, nan=1.0, posinf=1e6, neginf=1e-6).clamp(min=1e-6)
                means2D_shadow, cov2D_shadow, opacities_shadow = _sanitize_sar_raster_inputs(
                    means2D_shadow, cov2D_shadow, opacities, H, W,
                )
                colors_one = torch.ones(means3D.shape[0], 3, device=device, dtype=means3D.dtype)
                bg_zero = torch.zeros(3, device=device, dtype=means3D.dtype)
                I_occ = _alpha_blend(
                    means2D_shadow, cov2D_shadow, opacities_shadow, colors_one, slant_range_safe, bg_zero, H, W,
                    prefer_cuda=cuda, far_first=False, return_depth=False,
                )
            I_occ = torch.clamp(torch.nan_to_num(I_occ, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
            I_shadow = (1.0 - I_occ[0:1]).clamp(1e-3, 1.0).expand(3, -1, -1)
            if self.shadow_detach_grad:
                I_shadow = I_shadow.detach()
            rendered = (I_intensity * I_shadow).clamp(0.0, 1.0)
            rendered = torch.nan_to_num(rendered, nan=0.0, posinf=1.0, neginf=0.0)
        else:
            rendered = I_intensity.clamp(0.0, 1.0)

        return {
            "render": rendered,
            "means2D": means2D,
            "viewspace_points": viewspace_points,
            "depths": depths,
            "depth": depth_map,
            "cov2D": cov2D,
        }


class SARGaussianRasterizerSettings:
    """兼容旧接口的设置容器。"""

    def __init__(
        self,
        image_height: int,
        image_width: int,
        R_world_to_radar: np.ndarray,
        use_attenuation: bool = True,
        bg_color: Optional[torch.Tensor] = None,
    ):
        self.image_height = image_height
        self.image_width = image_width
        self.R_world_to_radar = R_world_to_radar
        self.use_attenuation = use_attenuation
        self.bg_color = bg_color if bg_color is not None else torch.tensor([0.0, 0.0, 0.0])


def render_sar(viewpoint_camera, pc, pipe, bg_color: torch.Tensor, sar_mode: bool = True) -> Dict[str, torch.Tensor]:
    """SAR 渲染入口（兼容 gaussian_renderer.render_sar 回退路径）。"""
    if not sar_mode:
        from gaussian_renderer import render
        return render(viewpoint_camera, pc, pipe, bg_color)

    if not hasattr(viewpoint_camera, "R_world_to_radar") or viewpoint_camera.R_world_to_radar is None:
        raise ValueError("相机缺少 SAR 几何参数 R_world_to_radar")

    camera_center = getattr(viewpoint_camera, "camera_center", None)
    if camera_center is not None and isinstance(camera_center, torch.Tensor):
        camera_center = camera_center.detach().cpu().numpy()

    sar_params = getattr(viewpoint_camera, "sar_params", None) or {}
    range_ps = float(sar_params.get("range_pixel_spacing", DEFAULT_SAR_PARAMS["range_pixel_spacing"]))
    azimuth_ps = float(sar_params.get("azimuth_pixel_spacing", DEFAULT_SAR_PARAMS["azimuth_pixel_spacing"]))
    scene_scale = sar_params.get("scene_scale", None)

    rasterizer = get_cached_sdgr_rasterizer(
        image_height=int(viewpoint_camera.image_height),
        image_width=int(viewpoint_camera.image_width),
        R_world_to_radar=viewpoint_camera.R_world_to_radar,
        camera_center_world=camera_center,
        scene_scale=scene_scale,
        use_attenuation=True,
        use_sig3dgs_visibility=getattr(pipe, "sar_sig3dgs_visibility", True),
        shadow_detach_grad=getattr(pipe, "sar_shadow_detach_grad", True),
        prefer_cuda=bool(getattr(pipe, "sar_sdgr_cuda", True)),
        range_pixel_spacing=range_ps,
        azimuth_pixel_spacing=azimuth_ps,
        device=pc.get_xyz.device,
    )

    means3D = pc.get_xyz
    output = rasterizer(
        means3D=means3D,
        scales=pc.get_scaling,
        rotations=pc.get_rotation,
        opacities=pc.get_opacity,
        colors=_colors_from_pc(pc, viewpoint_camera),
        background=bg_color,
    )
    return output


def _colors_from_pc(pc, viewpoint_camera) -> torch.Tensor:
    from utils.sh_utils import eval_sh

    shs_view = pc.get_features.transpose(1, 2).view(-1, 3, (pc.max_sh_degree + 1) ** 2)
    dir_pp = pc.get_xyz - viewpoint_camera.camera_center.repeat(pc.get_features.shape[0], 1)
    dir_pp_normalized = dir_pp / (dir_pp.norm(dim=1, keepdim=True) + 1e-8)
    sh2rgb = eval_sh(pc.active_sh_degree, shs_view, dir_pp_normalized)
    return torch.clamp_min(sh2rgb + 0.5, 0.0)
