"""将 sparse/0 外参替换为与 3DGS 训练一致的 SAR 水平圆环（卫星）理论位姿。"""

from __future__ import annotations

import json
import os
import struct
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from sar.utils import parse_mstar_filename


def _load_colmap_loader():
    """避免 ``import scene.colmap_loader`` 触发 scene/__init__ → simple_knn。"""
    import importlib.util

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path = os.path.join(root, "scene", "colmap_loader.py")
    spec = importlib.util.spec_from_file_location("gs_colmap_loader", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"无法加载 {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _cli_specified(argv: Optional[Sequence[str]], option_names: Sequence[str]) -> bool:
    if not argv:
        return False
    for tok in argv:
        for name in option_names:
            if tok == name or tok.startswith(f"{name}="):
                return True
    return False


def gs_satellite_poses_enabled(args: Any) -> bool:
    """是否用 75° 光学圆环重写 sparse 外参（与 geometry_prior_gs_model 预设联动）。"""
    return bool(getattr(args, "sfm_export_gs_satellite_poses", False))


def _load_sar_scale_params(source_path: str) -> Dict[str, Any]:
    path = os.path.join(source_path, "sar_scale_params.json")
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _hydrate_sp_from_mstar_scale_json(sp: Dict[str, Any], scale: Dict[str, Any]) -> bool:
    """若 sar_scale_params 已有 MSTAR 闭合结果，直接灌入 sp，避免重复 SAR auto_fill。"""
    if not scale.get("mstar_init_from_pixel_resolution"):
        return False
    h = float(scale.get("mstar_init_camera_height_m", scale.get("camera_height", 0.0)) or 0.0)
    if h <= 1e-6:
        return False
    sp["mstar_init_from_pixel_resolution"] = True
    sp["camera_height"] = h
    sp["mstar_init_camera_height_m"] = h
    if "scene_scale" in scale:
        sp["scene_scale"] = float(scale["scene_scale"])
    if "mstar_init_scene_scale" in scale:
        sp["mstar_init_scene_scale"] = float(scale["mstar_init_scene_scale"])
    if "mstar_formula_camera_height_m" in scale:
        sp["mstar_formula_camera_height_m"] = float(scale["mstar_formula_camera_height_m"])
    if "mstar_camera_height_scale" in scale:
        sp["mstar_camera_height_scale"] = float(scale["mstar_camera_height_scale"])
    if "mstar_init_slant_range_m" in scale:
        sp["mstar_init_slant_range_m"] = float(scale["mstar_init_slant_range_m"])
    if "mstar_init_ground_range_m" in scale:
        sp["mstar_init_ground_range_m"] = float(scale["mstar_init_ground_range_m"])
    fp = float(scale.get("mstar_init_focal_px", scale.get("unified_focal_azimuth", 0.0)) or 0.0)
    if fp > 0:
        sp["mstar_init_focal_px"] = fp
    rs = scale.get("unified_radius_scale", scale.get("estimated_radius_scale", scale.get("radius_scale")))
    if rs is not None:
        sp["radius_scale"] = float(rs)
    return True


def build_gs_training_sar_params(
    source_path: str,
    args: Any,
    *,
    width: int,
    height: int,
    image_names: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    from sar.geometry import DEFAULT_SAR_PARAMS

    sp = DEFAULT_SAR_PARAMS.copy()
    sp["Na"] = int(width)
    sp["Nr"] = int(height)
    sp["camera_distribution_mode"] = "ring"

    if hasattr(args, "sar_mstar_filename_depression_convention"):
        sp["mstar_filename_depression_convention"] = (
            args.sar_mstar_filename_depression_convention
        )

    scale = _load_sar_scale_params(source_path)
    hydrated_from_json = _hydrate_sp_from_mstar_scale_json(sp, scale)

    image_angles: Dict[str, Dict[str, float]] = {}
    names = list(image_names or [])
    if not names and isinstance(scale.get("cameras"), dict):
        names = list(scale["cameras"].keys())
    for name in names:
        try:
            dep, azi = parse_mstar_filename(name)
            image_angles[name] = {"depression": float(dep), "azimuth": float(azi)}
        except Exception:
            pass

    from sar.scene_scale_closure import ensure_mstar_initial_sar_params

    cli_args = getattr(args, "_full_cli_args", None) or args
    ensure_mstar_initial_sar_params(
        sp,
        cli_args,
        ref_width=width,
        ref_height=height,
        image_angles=image_angles or None,
        source_path=source_path,
    )

    from sar.sfm_scale_params import resolve_gs_training_camera_height

    merged_scale = dict(scale)
    if sp.get("mstar_init_from_pixel_resolution") and hydrated_from_json:
        sp["camera_height"] = resolve_gs_training_camera_height(merged_scale, cli_args)
        if "scene_scale" in scale:
            sp["scene_scale"] = float(scale["scene_scale"])
        fp = float(scale.get("mstar_init_focal_px", scale.get("unified_focal_azimuth", 0.0)) or 0.0)
        if fp > 0:
            sp["unified_focal_azimuth"] = fp
            sp["unified_focal_range"] = fp
    elif sp.get("mstar_init_from_pixel_resolution"):
        from sar.scene_scale_closure import mstar_scale_fields_from_sar_params

        merged_scale.update(mstar_scale_fields_from_sar_params(sp))
        sp["camera_height"] = resolve_gs_training_camera_height(merged_scale, cli_args)
        sp["scene_scale"] = float(sp.get("scene_scale", merged_scale.get("scene_scale", 0.05)))
        fp = float(sp.get("mstar_init_focal_px", 0.0))
        if fp > 0:
            sp["unified_focal_azimuth"] = fp
            sp["unified_focal_range"] = fp
    else:
        if hasattr(args, "sar_scene_scale") and args.sar_scene_scale is not None:
            if not getattr(args, "sfm_mstar_init_from_pixel_resolution", False):
                sp["scene_scale"] = float(args.sar_scene_scale)
        if "scene_scale" in scale:
            sp["scene_scale"] = float(scale["scene_scale"])

    rs = scale.get("unified_radius_scale", scale.get("estimated_radius_scale", None))
    if rs is not None:
        sp["radius_scale"] = float(rs)
    elif sp.get("radius_scale") is not None:
        pass
    elif hasattr(args, "sar_radius_scale") and args.sar_radius_scale is not None:
        sp["radius_scale"] = float(args.sar_radius_scale)

    if "unified_focal_azimuth" not in sp and "unified_focal_azimuth" in scale:
        sp["unified_focal_azimuth"] = float(scale["unified_focal_azimuth"])
    if "unified_focal_range" not in sp and "unified_focal_range" in scale:
        sp["unified_focal_range"] = float(scale["unified_focal_range"])

    return sp


def _resolve_depression_azimuth(image_name: str, args: Any, sar_params: Optional[dict] = None):
    from sar.optical_equivalent_depression import resolve_gs_render_depression_horizon_deg

    dep_sar, azi = parse_mstar_filename(image_name)
    dep_render, _, note = resolve_gs_render_depression_horizon_deg(
        float(dep_sar),
        sar_params=sar_params,
        args=args,
    )
    return float(dep_render), float(azi), float(dep_sar), note


def _umeyama_similarity(src: np.ndarray, dst: np.ndarray) -> Tuple[float, np.ndarray, np.ndarray]:
    """dst ≈ s * R @ src + t（最小二乘，src/dst: N×3）。"""
    src = np.asarray(src, dtype=np.float64)
    dst = np.asarray(dst, dtype=np.float64)
    n = src.shape[0]
    if n < 1:
        return 1.0, np.eye(3), np.zeros(3)
    if n == 1:
        return 1.0, np.eye(3), (dst[0] - src[0]).astype(np.float64)

    mu_s = src.mean(0)
    mu_d = dst.mean(0)
    xs = src - mu_s
    xd = dst - mu_d
    var_s = float((xs ** 2).sum() / n)
    cov = (xd.T @ xs) / n
    u, d, vt = np.linalg.svd(cov)
    s_mat = np.eye(3)
    if np.linalg.det(u) * np.linalg.det(vt) < 0:
        s_mat[-1, -1] = -1.0
    r = u @ s_mat @ vt
    s = float(np.trace(np.diag(d) @ s_mat) / max(var_s, 1e-12))
    if not np.isfinite(s) or s <= 0:
        s = 1.0
    t = mu_d - s * (r @ mu_s)
    return s, r, t


def _camera_center_from_w2c(R: np.ndarray, t: np.ndarray) -> np.ndarray:
    t = np.asarray(t, dtype=np.float64).reshape(3)
    R = np.asarray(R, dtype=np.float64).reshape(3, 3)
    return (-R.T @ t).astype(np.float64)


def _write_extrinsics_binary(path: str, images: dict) -> None:
    with open(path, "wb") as fid:
        fid.write(struct.pack("<Q", len(images)))
        for im in images.values():
            q = np.asarray(im.qvec, dtype=np.float64).reshape(4)
            t = np.asarray(im.tvec, dtype=np.float64).reshape(3)
            fid.write(struct.pack("<i", int(im.id)))
            fid.write(struct.pack("<ddddddd", *q, *t))
            fid.write(struct.pack("<i", int(im.camera_id)))
            name_bytes = im.name.encode("utf-8") + b"\x00"
            fid.write(name_bytes)
            n2d = im.xys.shape[0]
            fid.write(struct.pack("<Q", n2d))
            for j in range(n2d):
                x, y = float(im.xys[j, 0]), float(im.xys[j, 1])
                pid = int(im.point3D_ids[j])
                fid.write(struct.pack("<ddq", x, y, pid))


def _write_extrinsics_text(path: str, images: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Image list with two lines of data per image:\n")
        f.write("#   IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n")
        f.write("#   POINTS2D[] as (X, Y, POINT3D_ID)\n")
        f.write(f"# Number of images: {len(images)}\n")
        for im in images.values():
            q = np.asarray(im.qvec, dtype=np.float64).reshape(4)
            t = np.asarray(im.tvec, dtype=np.float64).reshape(3)
            f.write(
                f"{im.id} {q[0]:.17g} {q[1]:.17g} {q[2]:.17g} {q[3]:.17g} "
                f"{t[0]:.17g} {t[1]:.17g} {t[2]:.17g} {im.camera_id} {im.name}\n"
            )
            if im.xys.shape[0] == 0:
                f.write("\n")
                continue
            parts = []
            for j in range(im.xys.shape[0]):
                parts.append(
                    f"{im.xys[j, 0]:.6f} {im.xys[j, 1]:.6f} {int(im.point3D_ids[j])}"
                )
            f.write(" ".join(parts) + "\n")


def _transform_points3d(
    sparse_dir: str,
    s: float,
    R: np.ndarray,
    t: np.ndarray,
) -> int:
    from post_sfm.colmap_points import read_points3d_binary_full, sync_colmap_point_outputs

    bin_path = os.path.join(sparse_dir, "points3D.bin")
    if not os.path.isfile(bin_path):
        return 0
    records = read_points3d_binary_full(bin_path)
    if not records:
        return 0
    R = np.asarray(R, dtype=np.float64).reshape(3, 3)
    t = np.asarray(t, dtype=np.float64).reshape(3)
    for rec in records:
        rec.xyz = (s * (R @ rec.xyz.reshape(3)) + t).astype(np.float64)
    sync_colmap_point_outputs(sparse_dir, records)
    return len(records)


def apply_gs_satellite_poses_to_sparse(
    source_path: str,
    args: Any,
    *,
    transform_points: bool = True,
) -> Dict[str, Any]:
    """
    用 compute_sar_camera_pose（ring + sar_scale_params 尺度）重写 sparse/0 外参；
    若 transform_points 且相机中心整体偏移，对 points3D 做相似变换以保持相对几何。
    """
    from sar.geometry import compute_sar_camera_pose

    _cl = _load_colmap_loader()
    read_extrinsics_binary = _cl.read_extrinsics_binary
    read_extrinsics_text = _cl.read_extrinsics_text
    read_intrinsics_binary = _cl.read_intrinsics_binary
    read_intrinsics_text = _cl.read_intrinsics_text
    rotmat2qvec = _cl.rotmat2qvec

    sparse_dir = os.path.join(source_path, "sparse", "0")
    if not os.path.isdir(sparse_dir):
        return {"applied": False, "reason": "no_sparse_dir"}

    img_bin = os.path.join(sparse_dir, "images.bin")
    img_txt = os.path.join(sparse_dir, "images.txt")
    if os.path.isfile(img_bin):
        images = read_extrinsics_binary(img_bin)
    elif os.path.isfile(img_txt):
        images = read_extrinsics_text(img_txt)
    else:
        return {"applied": False, "reason": "no_images"}

    if not images:
        return {"applied": False, "reason": "empty_images"}

    first = next(iter(images.values()))
    cam_txt = os.path.join(sparse_dir, "cameras.txt")
    cam_bin = os.path.join(sparse_dir, "cameras.bin")
    width, height = 512, 512
    try:
        if os.path.isfile(cam_bin):
            cams = read_intrinsics_binary(cam_bin)
        else:
            cams = read_intrinsics_text(cam_txt)
        cam = cams.get(first.camera_id)
        if cam is not None:
            width, height = int(cam.width), int(cam.height)
    except Exception:
        pass

    sar_params = build_gs_training_sar_params(
        source_path,
        args,
        width=width,
        height=height,
        image_names=[im.name for im in images.values()],
    )

    scale_pre = _load_sar_scale_params(source_path)
    from sar.imaging_mode import load_dataset_convention_probe, resolve_gs_optical_ring_azimuth_sign

    azi_sign = resolve_gs_optical_ring_azimuth_sign(args, scale_pre)
    dataset_convention = load_dataset_convention_probe(source_path)

    old_centers: List[np.ndarray] = []
    new_centers: List[np.ndarray] = []
    updated = 0
    dep_note_once: Optional[str] = None
    dep_render_vals: List[float] = []
    dep_sar_vals: List[float] = []

    for im in images.values():
        try:
            dep, azi, dep_sar, dep_note = _resolve_depression_azimuth(
                im.name, args, sar_params
            )
            dep_render_vals.append(float(dep))
            dep_sar_vals.append(float(dep_sar))
            if dep_note_once is None:
                dep_note_once = dep_note
        except Exception:
            continue

        azi_ring = float(azi) * float(azi_sign)
        # 光学透视 gs_model：环上 sign·φ 对齐 MSTAR 图旋转；SAR 斜距路径 sign=+1。
        R_w2c, t_w2c, _K = compute_sar_camera_pose(dep, azi_ring, sar_params)
        R_w2c = np.asarray(R_w2c, dtype=np.float64).reshape(3, 3)
        t_w2c = np.asarray(t_w2c, dtype=np.float64).reshape(3)

        old_R = im.qvec2rotmat()
        old_centers.append(_camera_center_from_w2c(old_R, im.tvec))
        new_centers.append(_camera_center_from_w2c(R_w2c, t_w2c))

        qvec = rotmat2qvec(R_w2c)
        im = im._replace(qvec=qvec, tvec=t_w2c)
        images[im.id] = im
        updated += 1

    if updated == 0:
        return {"applied": False, "reason": "no_mstar_filenames"}

    _write_extrinsics_binary(img_bin, images)
    _write_extrinsics_text(img_txt, images)

    n_pts = 0
    if transform_points and len(old_centers) >= 2:
        src = np.stack(old_centers, axis=0)
        dst = np.stack(new_centers, axis=0)
        shift = float(np.linalg.norm(dst.mean(0) - src.mean(0)))
        if shift > 1e-4:
            s, R, t = _umeyama_similarity(src, dst)
            n_pts = _transform_points3d(sparse_dir, s, R, t)

    scale_path = os.path.join(source_path, "sar_scale_params.json")
    scale = _load_sar_scale_params(source_path)
    dst_arr = np.stack(new_centers, axis=0)
    auth_h = float(sar_params.get("camera_height", 0.0))
    from sar.scene_scale_closure import mstar_scale_fields_from_sar_params
    from sar.sfm_scale_params import merge_scale_params_file
    from sar.optical_equivalent_depression import gs_render_depression_settings_from_args

    from sar.imaging_mode import gs_optical_perspective_only_enabled

    render_cfg = gs_render_depression_settings_from_args(args)

    scale.update(mstar_scale_fields_from_sar_params(sar_params))
    dep_render_med = float(np.median(dep_render_vals)) if dep_render_vals else 15.0
    dep_sar_med = float(np.median(dep_sar_vals)) if dep_sar_vals else 15.0
    scale.update(
        {
            "camera_distribution_mode": "ring",
            "gs_satellite_poses_applied": True,
            "gs_optical_render_depression_horizon_deg": dep_render_med,
            "gs_sar_filename_depression_horizon_deg": dep_sar_med,
            "gs_optical_render_depression_note": str(dep_note_once or ""),
            "sfm_use_optical_equivalent_depression": bool(render_cfg["use_optical_equiv"]),
            "sfm_optical_equivalent_depression_method": str(render_cfg["method"]),
            "camera_height": auth_h,
            "scaled_camera_height": auth_h,
            "median_slant_range_m": float(np.median(np.linalg.norm(dst_arr, axis=1))),
            "median_platform_height_m": float(np.abs(auth_h)),
            "scale_reference": "gs_satellite_ring_poses+mstar_scene_h",
            "gs_transform_points": bool(transform_points),
            "gs_optical_ring_azimuth_sign": int(azi_sign),
            "sfm_gs_optical_perspective_only": bool(gs_optical_perspective_only_enabled(args)),
        }
    )
    if dataset_convention is not None:
        scale["dataset_convention"] = dataset_convention
    if render_cfg.get("fixed_horizon_deg") is not None:
        scale["sfm_gs_optical_depression_horizon_deg"] = float(render_cfg["fixed_horizon_deg"])
    merge_scale_params_file(scale_path, scale)

    from sar.colmap_pose_sync import sync_sar_scale_params_cameras_from_sparse

    sync_sar_scale_params_cameras_from_sparse(
        source_path, args=args, verbose=True
    )

    print(
        f"\n[gs_satellite_poses] 已将 {updated} 个 COLMAP 外参替换为 SAR 水平圆环理论位姿\n"
        f"  ring + sar_scale_params 尺度；points3D 相似变换 {n_pts} 点"
        f"（transform_points={transform_points}）\n"
        f"  光学渲染俯角: {dep_note_once or 'sar_filename'}\n"
        f"  sar_scale_params.json 已更新 camera_distribution_mode=ring\n"
    )
    return {"applied": True, "num_cameras": updated, "num_points_transformed": n_pts}


def maybe_apply_gs_satellite_poses_to_sparse(
    source_path: str,
    args: Any,
    *,
    transform_points: bool = True,
) -> None:
    if not gs_satellite_poses_enabled(args):
        return
    try:
        apply_gs_satellite_poses_to_sparse(
            source_path, args, transform_points=transform_points
        )
    except Exception as e:
        print(f"⚠️ gs_satellite_poses 应用失败（继续 convert）: {e}")
