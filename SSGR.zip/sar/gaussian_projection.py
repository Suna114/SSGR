"""
SAR Gaussian Splatting投影模块
实现SAR-GS论文中的映射投影算法和散射强度计算

参考论文中的：
- 映射投影算法（Mapping Projection Algorithm）
- 3D高斯协方差矩阵投影
- 散射强度计算（Scattering Intensities Computation）
"""
import numpy as np
import torch
from typing import Optional, Tuple


class SARProjectionMatrices:
    """
    SAR投影矩阵计算类
    实现论文中的P_C（计算平面）和P_I（成像平面）投影矩阵
    """
    
    def __init__(self, 
                 delta_A: float,      # 方位向分辨率
                 delta_R: float,      # 距离向分辨率
                 N_A: int,            # 方位向像素数
                 N_R: int,            # 距离向像素数
                 theta: float,        # 擦地角（grazing angle，弧度）
                 h: float = 0.0):     # 高度参数
        """
        初始化SAR投影矩阵参数
        
        Args:
            delta_A: 方位向分辨率（米/像素）
            delta_R: 距离向分辨率（米/像素）
            N_A: 方位向像素数
            N_R: 距离向像素数
            theta: 擦地角（弧度）
            h: 高度参数（米）
        """
        self.delta_A = delta_A
        self.delta_R = delta_R
        self.N_A = N_A
        self.N_R = N_R
        self.theta = theta
        self.h = h
        
        # 计算投影矩阵
        self.P_C = self._compute_P_C()
        self.P_I = self._compute_P_I()
    
    def _compute_P_C(self) -> np.ndarray:
        """
        计算计算平面投影矩阵P_C（论文公式9）
        
        Returns:
            4x4投影矩阵
        """
        P_C = np.zeros((4, 4))
        
        # 第一行
        P_C[0, 0] = 2.0 / (self.delta_A * self.N_A)
        
        # 第二行
        P_C[1, 1] = 2.0
        
        # 第三行
        P_C[2, 2] = self.delta_R * self.N_R * np.tan(self.theta)
        
        # 第四行（齐次坐标）
        P_C[3, 3] = 1.0
        
        return P_C
    
    def _compute_P_I(self) -> np.ndarray:
        """
        计算成像平面投影矩阵P_I（论文公式10）
        
        P_I = [
            [2/(δ_A·N_A),    0,               2h                  ],
            [0,              2,               δ_R·N_R·sin(θ)      ],
            [0,              0,               δ_R·N_R·tan(θ)      ],
            [0,              0,               1                   ]
        ]
        
        其中：
        - δ_A: 方位向分辨率（米/像素）
        - δ_R: 距离向分辨率（米/像素）
        - N_A: 方位向像素数
        - N_R: 距离向像素数
        - θ: 擦地角（grazing angle，弧度）
        - h: 参考高度（米）
        
        Returns:
            4x4投影矩阵
        """
        P_I = np.zeros((4, 4))
        
        # 第一行：方位向投影
        P_I[0, 0] = 2.0 / (self.delta_A * self.N_A)
        P_I[0, 3] = 2.0 * self.h
        
        # 第二行：垂直投影
        P_I[1, 1] = 2.0
        P_I[1, 3] = self.delta_R * self.N_R * np.sin(self.theta)
        
        # 第三行：距离向投影
        P_I[2, 2] = self.delta_R * self.N_R * np.tan(self.theta)
        
        # 第四行：齐次坐标
        P_I[3, 3] = 1.0
        
        return P_I
    
    def project_to_computation_plane(self, points_3d: np.ndarray) -> np.ndarray:
        """
        将3D点投影到计算平面
        
        Args:
            points_3d: Nx3或Nx4的3D点（如果是Nx3，会自动添加齐次坐标）
        
        Returns:
            投影后的2D点（Nx2）
        """
        if points_3d.shape[1] == 3:
            points_hom = np.hstack([points_3d, np.ones((points_3d.shape[0], 1))])
        else:
            points_hom = points_3d
        
        # 投影
        projected = (self.P_C @ points_hom.T).T
        
        # 归一化并提取前两维
        projected_2d = projected[:, :2] / (projected[:, 3:4] + 1e-8)
        
        return projected_2d
    
    def project_to_imaging_plane(self, points_3d: np.ndarray) -> np.ndarray:
        """
        将3D点投影到成像平面
        
        Args:
            points_3d: Nx3或Nx4的3D点
        
        Returns:
            投影后的2D点（Nx2）
        """
        if points_3d.shape[1] == 3:
            points_hom = np.hstack([points_3d, np.ones((points_3d.shape[0], 1))])
        else:
            points_hom = points_3d
        
        # 投影
        projected = (self.P_I @ points_hom.T).T
        
        # 归一化并提取前两维
        projected_2d = projected[:, :2] / (projected[:, 3:4] + 1e-8)
        
        return projected_2d


class SARGaussianProjection:
    """
    SAR高斯投影类
    实现3D高斯协方差矩阵在SAR图像平面上的投影（论文公式7）
    """
    
    def __init__(self, R_r: np.ndarray):
        """
        初始化SAR高斯投影
        
        Args:
            R_r: 从世界坐标系到雷达坐标系的旋转矩阵（3x3）
        """
        self.R_r = R_r
        self._compute_jacobian()
    
    def _compute_jacobian(self):
        """
        计算雅可比矩阵J（用于正交投影近似）
        对于SAR投影，J通常是单位矩阵或简单的缩放矩阵
        """
        # 简化版本：使用单位矩阵（可以根据实际SAR几何调整）
        self.J = np.eye(2, 3)  # 2x3矩阵，用于从3D投影到2D
    
    def project_covariance(self, Sigma_3d: np.ndarray) -> np.ndarray:
        """
        投影3D高斯协方差矩阵到SAR图像平面（论文公式7）
        
        Σ' = J R_r^T Σ R_r J^T
        
        Args:
            Sigma_3d: 3D协方差矩阵（3x3）
        
        Returns:
            投影后的2D协方差矩阵（2x2）
        """
        # 将协方差矩阵转换到雷达坐标系
        Sigma_radar = self.R_r.T @ Sigma_3d @ self.R_r
        
        # 投影到2D平面
        Sigma_2d = self.J @ Sigma_radar @ self.J.T
        
        return Sigma_2d
    
    def project_covariance_batch(self, Sigma_3d_batch: torch.Tensor) -> torch.Tensor:
        """
        批量投影3D高斯协方差矩阵（PyTorch版本）
        
        Args:
            Sigma_3d_batch: 批量3D协方差矩阵 (N, 3, 3)
        
        Returns:
            批量2D协方差矩阵 (N, 2, 2)
        """
        device = Sigma_3d_batch.device
        R_r_tensor = torch.from_numpy(self.R_r).float().to(device)
        J_tensor = torch.from_numpy(self.J).float().to(device)
        
        # 转换到雷达坐标系
        Sigma_radar = torch.bmm(
            torch.bmm(R_r_tensor.T.unsqueeze(0).expand(Sigma_3d_batch.shape[0], -1, -1),
                     Sigma_3d_batch),
            R_r_tensor.unsqueeze(0).expand(Sigma_3d_batch.shape[0], -1, -1)
        )
        
        # 投影到2D平面
        Sigma_2d = torch.bmm(
            torch.bmm(J_tensor.unsqueeze(0).expand(Sigma_3d_batch.shape[0], -1, -1),
                     Sigma_radar),
            J_tensor.T.unsqueeze(0).expand(Sigma_3d_batch.shape[0], -1, -1)
        )
        
        return Sigma_2d


class SARScatteringIntensity:
    """
    SAR散射强度计算类
    实现论文中的散射强度计算（考虑雷达波束衰减和MPA方法）
    """
    
    def __init__(self,
                 k_e: Optional[np.ndarray] = None,
                 use_attenuation: bool = True):
        """
        初始化散射强度计算
        
        Args:
            k_e: 衰减系数（可选）
            use_attenuation: 是否使用衰减模型
        """
        self.k_e = k_e
        self.use_attenuation = use_attenuation
    
    def compute_scattering_intensity(self,
                                   gaussian_intensity: np.ndarray,
                                   depth: np.ndarray,
                                   attenuation_factor: Optional[np.ndarray] = None) -> np.ndarray:
        """
        计算SAR散射强度
        
        参考论文公式3：
        S_{i,j} = ∫∫ S(x, r) dxdr
                 = ∫∫ exp[-∫k_e dr'] P(x, r, θ) exp[-∫k_e dr'] rdθdrdx
        
        Args:
            gaussian_intensity: 高斯原语的强度（基础散射强度）
            depth: 深度信息（用于计算衰减）
            attenuation_factor: 预计算的衰减因子（可选）
        
        Returns:
            散射强度
        """
        if not self.use_attenuation:
            return gaussian_intensity
        
        # 计算衰减因子
        if attenuation_factor is None:
            attenuation_factor = self._compute_attenuation(depth)
        
        # 应用衰减（双向衰减：发射和接收）
        scattering_intensity = gaussian_intensity * attenuation_factor * attenuation_factor
        
        return scattering_intensity
    
    def _compute_attenuation(self, depth: np.ndarray) -> np.ndarray:
        """
        计算雷达波束衰减因子
        
        Args:
            depth: 深度信息
        
        Returns:
            衰减因子
        """
        if self.k_e is None:
            # 默认衰减系数（可以根据实际SAR参数调整）
            k_e_default = 0.01  # 示例值
        else:
            k_e_default = self.k_e
        
        # 简化的衰减模型：exp(-k_e * depth)
        attenuation = np.exp(-k_e_default * depth)
        
        return attenuation
    
    def compute_scattering_intensity_batch(self,
                                          gaussian_intensity: torch.Tensor,
                                          depth: torch.Tensor,
                                          attenuation_factor: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        批量计算SAR散射强度（PyTorch版本）
        
        Args:
            gaussian_intensity: 高斯强度 (N,)
            depth: 深度 (N,)
            attenuation_factor: 衰减因子 (N,)（可选）
        
        Returns:
            散射强度 (N,)
        """
        if not self.use_attenuation:
            return torch.clamp(torch.nan_to_num(gaussian_intensity, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        
        if attenuation_factor is None:
            if self.k_e is None:
                k_e_default = 0.01
            else:
                k_e_default = self.k_e
            
            depth = depth.clamp(min=0.0, max=1e4)
            attenuation_factor = torch.exp(-k_e_default * depth).clamp(min=1e-6, max=1.0)
        
        gi = torch.clamp(torch.nan_to_num(gaussian_intensity, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
        scattering_intensity = (gi * attenuation_factor * attenuation_factor).clamp(0.0, 1.0)
        
        return scattering_intensity


class SARCoordinateConverter:
    """
    SAR坐标转换类
    将投影坐标转换为像素坐标
    """
    
    def __init__(self, image_width: int, image_height: int):
        """
        初始化坐标转换器
        
        Args:
            image_width: 图像宽度（像素）
            image_height: 图像高度（像素）
        """
        self.image_width = image_width
        self.image_height = image_height
    
    def ndc_to_pixel(self, points_ndc: torch.Tensor) -> torch.Tensor:
        """
        将归一化设备坐标(NDC)转换为像素坐标
        
        Args:
            points_ndc: NDC坐标 (N, 2)，范围[-1, 1]
        
        Returns:
            像素坐标 (N, 2)
        """
        pixel_x = (points_ndc[:, 0] + 1.0) * 0.5 * self.image_width
        pixel_y = (points_ndc[:, 1] + 1.0) * 0.5 * self.image_height
        return torch.stack([pixel_x, pixel_y], dim=-1)
    
    def pixel_to_ndc(self, points_pixel: torch.Tensor) -> torch.Tensor:
        """
        将像素坐标转换为归一化设备坐标(NDC)
        
        Args:
            points_pixel: 像素坐标 (N, 2)
        
        Returns:
            NDC坐标 (N, 2)，范围[-1, 1]
        """
        ndc_x = (points_pixel[:, 0] / self.image_width) * 2.0 - 1.0
        ndc_y = (points_pixel[:, 1] / self.image_height) * 2.0 - 1.0
        return torch.stack([ndc_x, ndc_y], dim=-1)


class SARConicComputer:
    """
    计算SAR 2D高斯的conic矩阵
    用于快速渲染
    """
    
    @staticmethod
    def compute_conic_from_covariance(cov2d: torch.Tensor) -> torch.Tensor:
        """
        从2D协方差矩阵计算conic矩阵（协方差的逆）
        
        Args:
            cov2d: 2D协方差矩阵 (N, 2, 2)
        
        Returns:
            conic矩阵 (N, 3)，格式为[conic.x, conic.y, conic.z]
            对应 [[conic.x, conic.y], [conic.y, conic.z]]
        """
        # 计算行列式
        det = cov2d[:, 0, 0] * cov2d[:, 1, 1] - cov2d[:, 0, 1] * cov2d[:, 1, 0]
        det = torch.clamp(det, min=1e-6)  # 防止除零
        
        # 计算逆矩阵（conic矩阵）
        det_inv = 1.0 / det
        conic_x = cov2d[:, 1, 1] * det_inv  # 右下角元素
        conic_y = -cov2d[:, 0, 1] * det_inv  # 负的非对角元素
        conic_z = cov2d[:, 0, 0] * det_inv  # 左上角元素
        
        return torch.stack([conic_x, conic_y, conic_z], dim=-1)


def create_sar_projection_from_params(sar_params: dict, 
                                     depression_angle: float,
                                     azimuth_angle: float) -> Tuple[SARProjectionMatrices, SARGaussianProjection]:
    """
    从SAR参数创建投影对象
    
    Args:
        sar_params: SAR参数字典（包含delta_A, delta_R, N_A, N_R等）
        depression_angle: 俯视角（度）
        azimuth_angle: 方位角（度）
    
    Returns:
        (投影矩阵对象, 高斯投影对象)
    """
    from .geometry import compute_sar_camera_pose
    
    # 计算SAR相机位姿
    R_world_to_radar, t, K = compute_sar_camera_pose(
        depression_angle, azimuth_angle, sar_params
    )
    
    # 计算擦地角（从俯视角转换）
    theta = np.deg2rad(90 - depression_angle)  # 擦地角 = 90° - 俯视角
    
    # 获取SAR参数
    delta_A = sar_params.get('azimuth_pixel_size', sar_params.get('Va', 755) / sar_params.get('prf', 2200))
    delta_R = sar_params.get('range_pixel_size', 3e8 / (2 * sar_params.get('fs', 1.1 * 240e6)))
    N_A = sar_params.get('Na', 512)
    N_R = sar_params.get('Nr', 512)
    h = sar_params.get('camera_height', 1365.0)
    
    # 创建投影矩阵对象
    proj_matrices = SARProjectionMatrices(
        delta_A=delta_A,
        delta_R=delta_R,
        N_A=N_A,
        N_R=N_R,
        theta=theta,
        h=h
    )
    
    # 创建高斯投影对象
    gaussian_proj = SARGaussianProjection(R_r=R_world_to_radar)
    
    return proj_matrices, gaussian_proj

