"""将 sparse/0 COLMAP 外参同步写入 sar_scale_params.json 的 cameras 字段。"""

from __future__ import annotations

import importlib.util
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from sar.utils import parse_mstar_filename

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
_cl = None


def _colmap_loader():
    global _cl
    if _cl is None:
        path = os.path.join(_REPO_ROOT, "scene", "colmap_loader.py")
        spec = importlib.util.spec_from_file_location("sar_colmap_loader_sync", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"无法加载 COLMAP 读取模块: {path}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _cl = mod
    return _cl


def _camera_center_from_w2c(R_w2c: np.ndarray, t_w2c: np.ndarray) -> np.ndarray:
    R = np.asarray(R_w2c, dtype=np.float64).reshape(3, 3)
    t = np.asarray(t_w2c, dtype=np.float64).reshape(3)
    return (-R.T @ t).astype(np.float64)


def _depression_azimuth_from_center(center: np.ndarray) -> Tuple[float, float]:
    """由光心位置估计 horizon 俯角与方位角（度，与 ring 几何一致）。"""
    p = np.asarray(center, dtype=np.float64).reshape(3)
    r = float(np.linalg.norm(p))
    if r < 1e-9:
        return 0.0, 0.0
    xz = float(np.hypot(p[0], p[2]))
    dep = float(np.degrees(np.arctan2(xz, max(abs(p[1]), 1e-12))))
    azi = float(np.degrees(np.arctan2(p[2], p[0])))
    return dep, azi


def build_camera_info_from_w2c(
    image_name: str,
    R_w2c: np.ndarray,
    t_w2c: np.ndarray,
    *,
    K: Optional[np.ndarray] = None,
    image_size: Optional[Tuple[int, int]] = None,
    dep_render: Optional[float] = None,
    dep_sar: Optional[float] = None,
) -> Dict[str, Any]:
    """构造与 SfM ``_CollectCameraData`` 相同结构的单相机条目。"""
    from scipy.spatial.transform import Rotation as Rot

    R = np.asarray(R_w2c, dtype=np.float64).reshape(3, 3)
    t = np.asarray(t_w2c, dtype=np.float64).reshape(3)

    U, _, Vt = np.linalg.svd(R)
    R_fix = U @ Vt
    if np.linalg.det(R_fix) < 0:
        R_fix[:, 2] = -R_fix[:, 2]
    R = R_fix

    t_col = t.reshape(3, 1)
    center = _camera_center_from_w2c(R, t)
    quat = Rot.from_matrix(R).as_quat()

    stem = os.path.splitext(os.path.basename(str(image_name)))[0]
    if dep_sar is None:
        try:
            dep_sar, azi_fn = parse_mstar_filename(stem)
            dep_sar = float(dep_sar)
        except Exception:
            dep_sar, azi_fn = None, None
    else:
        dep_sar = float(dep_sar)
        azi_fn = None

    if dep_render is None:
        dep_render = dep_sar
    dep_render = float(dep_render)

    dep_geo, azi_geo = _depression_azimuth_from_center(center)
    azi = float(azi_fn) if azi_fn is not None else azi_geo

    info: Dict[str, Any] = {
        "qw": float(quat[3]),
        "qx": float(quat[0]),
        "qy": float(quat[1]),
        "qz": float(quat[2]),
        "tx": float(center[0]),
        "ty": float(center[1]),
        "tz": float(center[2]),
        "t_camera_frame": t_col.tolist(),
        "R": R.tolist(),
        "t": t.reshape(3).tolist(),
        "depression_angle": dep_render,
        "azimuth_angle": azi,
    }
    if dep_sar is not None:
        info["original_depression"] = float(dep_sar)
        info["original_azimuth"] = azi
    if K is not None:
        info["K"] = np.asarray(K, dtype=np.float64).reshape(3, 3).tolist()
    if image_size is not None:
        info["image_size"] = [int(image_size[0]), int(image_size[1])]
    info["depression_from_position_deg"] = float(dep_geo)
    return info


def _load_sparse_extrinsics(sparse_dir: str):
    cl = _colmap_loader()

    img_bin = os.path.join(sparse_dir, "images.bin")
    img_txt = os.path.join(sparse_dir, "images.txt")
    cam_bin = os.path.join(sparse_dir, "cameras.bin")
    cam_txt = os.path.join(sparse_dir, "cameras.txt")

    if os.path.isfile(img_bin):
        images = cl.read_extrinsics_binary(img_bin)
    elif os.path.isfile(img_txt):
        images = cl.read_extrinsics_text(img_txt)
    else:
        raise FileNotFoundError(f"sparse 缺少 images: {sparse_dir}")

    cams = {}
    if os.path.isfile(cam_bin):
        cams = cl.read_intrinsics_binary(cam_bin)
    elif os.path.isfile(cam_txt):
        cams = cl.read_intrinsics_text(cam_txt)

    return images, cams


def _pinhole_K_from_colmap_cam(cam) -> Tuple[np.ndarray, int, int]:
    w, h = int(cam.width), int(cam.height)
    if cam.model == "SIMPLE_PINHOLE":
        f, cx, cy = cam.params[0], cam.params[1], cam.params[2]
        K = np.array([[f, 0, cx], [0, f, cy], [0, 0, 1.0]], dtype=np.float64)
    elif cam.model == "PINHOLE":
        fx, fy, cx, cy = cam.params[0], cam.params[1], cam.params[2], cam.params[3]
        K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.0]], dtype=np.float64)
    else:
        K = np.eye(3, dtype=np.float64)
        K[0, 0] = K[1, 1] = float(max(w, h))
        K[0, 2] = w * 0.5
        K[1, 2] = h * 0.5
    return K, w, h


def _resolve_dep_angles_for_image(
    stem: str,
    scale: Dict[str, Any],
    args: Any = None,
) -> Tuple[Optional[float], Optional[float]]:
    dep_sar: Optional[float] = None
    dep_render: Optional[float] = None
    try:
        dep_sar, _ = parse_mstar_filename(stem)
        dep_sar = float(dep_sar)
    except Exception:
        return None, None

    if args is not None:
        from sar.optical_equivalent_depression import resolve_gs_render_depression_horizon_deg

        dep_render, _, _ = resolve_gs_render_depression_horizon_deg(
            dep_sar,
            args=args,
            fixed_horizon_deg=scale.get("sfm_gs_optical_depression_horizon_deg"),
            use_optical_equiv=bool(
                scale.get("sfm_use_optical_equivalent_depression")
                or scale.get("gs_satellite_poses_applied")
            ),
            method=str(
                scale.get(
                    "sfm_optical_equivalent_depression_method",
                    "complement_overhead",
                )
            ),
        )
        return dep_sar, float(dep_render)

    cached_r = scale.get("gs_optical_render_depression_horizon_deg")
    cached_s = scale.get("gs_sar_filename_depression_horizon_deg")
    if cached_r is not None:
        try:
            dep_render = float(cached_r)
        except (TypeError, ValueError):
            dep_render = dep_sar
    else:
        dep_render = dep_sar
    if cached_s is not None:
        try:
            dep_sar = float(cached_s)
        except (TypeError, ValueError):
            pass
    return dep_sar, dep_render


def cameras_dict_from_sparse(
    source_path: str,
    *,
    sparse_dir: Optional[str] = None,
    args: Any = None,
    scale: Optional[Dict[str, Any]] = None,
) -> Dict[str, Dict[str, Any]]:
    sparse_dir = sparse_dir or os.path.join(source_path, "sparse", "0")
    if scale is None:
        from sar.gs_satellite_poses import _load_sar_scale_params

        scale = _load_sar_scale_params(source_path)

    images, cams = _load_sparse_extrinsics(sparse_dir)
    cl = _colmap_loader()
    out: Dict[str, Dict[str, Any]] = {}
    for im in images.values():
        stem = os.path.splitext(os.path.basename(im.name))[0]
        R_w2c = np.transpose(cl.qvec2rotmat(im.qvec)).astype(np.float64).reshape(3, 3)
        t_w2c = np.asarray(im.tvec, dtype=np.float64).reshape(3)

        K = None
        wh: Optional[Tuple[int, int]] = None
        cam = cams.get(im.camera_id)
        if cam is not None:
            K, w, h = _pinhole_K_from_colmap_cam(cam)
            wh = (w, h)

        dep_sar, dep_render = _resolve_dep_angles_for_image(stem, scale, args)
        out[stem] = build_camera_info_from_w2c(
            im.name,
            R_w2c,
            t_w2c,
            K=K,
            image_size=wh,
            dep_render=dep_render,
            dep_sar=dep_sar,
        )
    return out


def _max_center_delta(
    old_cameras: Dict[str, Any],
    new_cameras: Dict[str, Any],
) -> float:
    deltas: List[float] = []
    for name, nc in new_cameras.items():
        oc = old_cameras.get(name)
        if not isinstance(oc, dict):
            continue
        try:
            old_c = np.array([oc["tx"], oc["ty"], oc["tz"]], dtype=np.float64)
            new_c = np.array([nc["tx"], nc["ty"], nc["tz"]], dtype=np.float64)
            deltas.append(float(np.linalg.norm(new_c - old_c)))
        except (KeyError, TypeError, ValueError):
            continue
    return float(max(deltas)) if deltas else 0.0


def sync_sar_scale_params_cameras_from_sparse(
    source_path: str,
    *,
    sparse_dir: Optional[str] = None,
    args: Any = None,
    verbose: bool = True,
) -> Dict[str, Any]:
    """
    用 sparse/0 当前外参覆盖 sar_scale_params.json['cameras']，保证与 verify / 3DGS 读取一致。
    """
    from sar.gs_satellite_poses import _load_sar_scale_params
    from sar.sfm_scale_params import merge_scale_params_file

    sparse_dir = sparse_dir or os.path.join(source_path, "sparse", "0")
    scale_path = os.path.join(source_path, "sar_scale_params.json")
    old_scale = _load_sar_scale_params(source_path)
    old_cameras = dict(old_scale.get("cameras") or {})

    new_cameras = cameras_dict_from_sparse(
        source_path, sparse_dir=sparse_dir, args=args, scale=old_scale
    )
    if not new_cameras:
        return {"synced": False, "reason": "no_cameras"}

    delta = _max_center_delta(old_cameras, new_cameras)
    merge_scale_params_file(
        scale_path,
        {
            "cameras": new_cameras,
            "sparse_pose_sync_applied": True,
            "sparse_pose_sync_max_center_delta_m": delta,
        },
    )
    if verbose:
        print(
            f"[colmap_pose_sync] sar_scale_params.json ← sparse/0："
            f" {len(new_cameras)} 相机"
            + (f"（相对旧 json 最大光心差 {delta:.4f} m）" if old_cameras else "")
        )
    return {
        "synced": True,
        "num_cameras": len(new_cameras),
        "max_center_delta_m": delta,
    }


def verify_sparse_json_pose_consistency(
    source_path: str,
    *,
    sparse_dir: Optional[str] = None,
    tol_m: float = 1e-3,
) -> Tuple[bool, float, int]:
    """检查 sparse 与 sar_scale_params cameras 光心是否一致。"""
    from sar.gs_satellite_poses import _load_sar_scale_params

    sparse_dir = sparse_dir or os.path.join(source_path, "sparse", "0")
    json_cameras = (_load_sar_scale_params(source_path).get("cameras") or {})
    sparse_cameras = cameras_dict_from_sparse(source_path, sparse_dir=sparse_dir)
    max_d = _max_center_delta(json_cameras, sparse_cameras)
    n = len(sparse_cameras)
    return max_d <= tol_m, max_d, n
