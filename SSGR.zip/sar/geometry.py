# sar_geometry.py
"""
SAR几何模型工具模块
用于SAR图像的SfM重建，考虑SAR特有的几何特性
"""
import numpy as np
import cv2
from scipy.spatial.transform import Rotation as R
from .utils import parse_mstar_filename
import os
from typing import Optional

# SAR系统参数（可以从config或args传入）
# MSTAR数据集参数：X波段SAR，中心频率9.6GHz，平台高度12km，速度250m/s
# 分辨率：距离向/方位向均为 0.3 m/px（128×128 MSTAR 场景尺度闭合默认）
DEFAULT_SAR_PARAMS = {
    'f0': 9.6e9,  # 雷达中心频率 (Hz) - MSTAR X波段
    'lmda': 3e8 / 9.6e9,  # 波长 (m) ≈ 0.03125m ≈ 3.1cm
    'C': 3e8,  # 光速 (m/s)
    'camera_height': 12000.0,  # 相机/平台高度 (m) - MSTAR数据集约12km
    'Va': 250,  # 平台速度 (m/s) - MSTAR数据集约250m/s
    'bita': 3.6 * np.pi / 180,  # 波束宽度 (弧度) - 保持默认值
    'D': (3e8 / 9.6e9) / (3.6 * np.pi / 180),  # 天线孔径 (m) - 基于波长和波束宽度
    'tao': 3.5 * 1e-7,  # 脉冲宽度 (s) - 保持默认值
    'B': 500e6,  # 带宽 (Hz) - 基于距离向分辨率0.3m计算：B = C/(2*0.3) ≈ 500MHz
    'fs': 500e6,  # 采样率 (Hz) - 等于带宽（奈奎斯特采样）
    'kr': 500e6 / (3.5 * 1e-7),  # 调频率 (Hz/s) - 基于带宽和脉冲宽度
    'prf': 2500,  # 脉冲重复频率 (Hz) - MSTAR 典型值
    'range_pixel_spacing': 0.3,  # 距离向像素间距 (m/px)，与 sfm_mstar_range_resolution_m 默认一致
    'azimuth_pixel_spacing': 0.3,  # 方位向像素间距 (m/px)，与 sfm_mstar_azimuth_resolution_m 默认一致
    'Na': 512,  # 方位向采样点数
    'Nr': 512,  # 距离向采样点数
    'camera_distribution_mode': 'sphere',  # 使用球面分布（推荐，改善垂直形状恢复，与train.py保持一致）
    # 文件名俯视角约定：horizon（默认）— 文件名为相对水平俯角 φ，内换乘 θ=90°−φ；
    # zenith — 传入值已是与天底夹角 θ（与球面公式直接一致）。
    'mstar_filename_depression_convention': 'horizon',  # 默认：文件名为相对水平的俯角 φ，内换乘 θ
}


def normalize_mstar_filename_depression_to_incidence_from_nadir_deg(
    depression_deg: float, sar_params: Optional[dict]
) -> float:
    """
    将文件名/配置文件中的俯视角（度）转为 compute_sar_camera_pose 内部使用的
    「波束与天底（局部竖直向下）夹角」（度）。

    - convention == 'zenith'：入射角即为 depression_deg。
    - convention == 'horizon'：文件名值为相对水平向下的俯角 φ，与天底夹角 θ = 90° - φ。
    """
    conv = DEFAULT_SAR_PARAMS.get("mstar_filename_depression_convention", "horizon")
    if sar_params is not None:
        conv = sar_params.get("mstar_filename_depression_convention", conv)
    if conv is None:
        conv = "horizon"
    conv = str(conv).strip().lower()
    if conv in ("", "none"):
        conv = "horizon"
    d = float(depression_deg)
    if conv == "zenith":
        return d
    if conv == "horizon":
        inc = 90.0 - d
        # 避免退化：与天底太近或太近水平
        if inc <= 1.0:
            raise ValueError(
                f"MSTAR horizon 惯例下与天底夹角过小 ({inc:.2f}°, 文件名俯角 φ={d}°)："
                "请核对文件名或为该数据集改用 --sar_mstar_filename_depression_convention zenith"
            )
        if inc >= 89.0:
            raise ValueError(
                f"MSTAR horizon 惯例下与天底夹角过大 ({inc:.2f}°, 文件名俯角 φ={d}°)，请核对角度。"
            )
        return inc
    raise ValueError(
        f"未知 mstar_filename_depression_convention={conv!r}，应为 'zenith' 或 'horizon'"
    )


def _slant_range_from_nadir_incidence(camera_height: float, nadir_incidence_rad: float) -> float:
    """
    天底入射角 θ（弧度，normalize 之后 dep_rad 即为此角）→ 斜距 R = H / cos(θ)。
    等价于 MSTAR horizon 俯角 φ 下 R = H / sin(φ)。
    """
    c = float(np.cos(nadir_incidence_rad))
    if abs(c) < 1e-9:
        raise ValueError("天底入射角接近 90°，斜距发散")
    return float(camera_height) / c


def _ground_range_ring_from_nadir_incidence(
    camera_height: float, nadir_incidence_rad: float
) -> float:
    """水平圆环：平台高度固定为 H，地面距离 g = H · tan(θ)。"""
    return float(camera_height) * float(np.tan(nadir_incidence_rad))


def compute_sar_camera_pose(depression_angle, azimuth_angle, sar_params=None):
    """
    根据俯视角和方位角计算SAR雷达天线相位中心的位姿
    
    注意：SAR与光学相机的根本区别：
    1. SAR使用斜距投影（slant range projection），不是中心投影
    2. SAR的几何关系由距离方程和多普勒方程描述：
       - 距离方程: R = |P_target - P_radar(t)|
       - 多普勒方程: f_d = -(2/λ) * (dR/dt)
    3. SAR的"位姿"是雷达天线相位中心的位置和波束指向
    4. SAR的姿态影响波束照射区和多普勒参数
    
    Args:
        depression_angle: 俯视角（度）。若 sar_params['mstar_filename_depression_convention']=='horizon'
            （MSTAR 文件名惯例），此为相对水平向下的俯角，函数内会先换算为与天底的夹角。
            若为 'zenith'，则已为与天底的夹角（与原先数学约定一致）。
        azimuth_angle: 方位角（度）- 雷达平台在水平面上的位置角度
        sar_params: SAR系统参数字典
    
    Returns:
        R: (3x3) 世界 → 雷达/相机坐标系旋转 R_world_to_radar（与 OpenCV/COLMAP 外参一致）
        t: (3x1) 同上外参的平移，X_cam = R @ X_world + t（OpenCV 相机坐标系 Z 为前向）
        K: (3x3) SAR 用近似针孔内参（管线兼容用；物理上仍为斜距模型）
    """
    if sar_params is None:
        sar_params = DEFAULT_SAR_PARAMS

    depression_angle = normalize_mstar_filename_depression_to_incidence_from_nadir_deg(
        float(depression_angle), sar_params
    )
    # 转换为弧度（与天底的入射角）
    dep_rad = np.deg2rad(depression_angle)
    azi_rad = np.deg2rad(azimuth_angle)
    
    # ========== SAR平台位置计算（支持水平圆环和球面分布）==========
    # 问题：水平圆环分布（所有相机在同一高度）导致垂直方向几何信息不足，
    #      点云塌陷成圆饼状，无法恢复目标形状（如T72坦克的长方体形状）
    # 
    # 解决方案：提供两种分布模式
    # 1. 水平圆环分布（默认，向后兼容）：Y坐标固定为-camera_height（COLMAP约定：高度在Y轴负方向）
    # 2. 球面分布（推荐，改善形状恢复）：相机在球面上，Y坐标随俯视角变化（COLMAP约定）
    # 
    # 相机位置计算方式（COLMAP坐标系：X=右，Y=下（高度在Y轴负方向），Z=前）：
    # - 水平圆环：Y坐标固定为-camera_height，X、Z坐标在水平面上按方位角分布
    # - 球面分布：相机在球面上，提供垂直方向的几何信息，改善形状恢复
    
    camera_height = sar_params['camera_height']  # 相机/平台高度（参考高度）
    
    # 获取分布模式：'ring'（水平圆环）或 'sphere'（球面分布）
    # 默认使用球面分布以改善形状恢复
    distribution_mode = sar_params.get('camera_distribution_mode', 'sphere')  # 默认球面分布
    
    # 如果提供了unified_sita0_for_radius，使用它来计算半径（保持相机位置不变）
    # 否则使用当前图像的俯视角（depression_angle）作为中心下视角
    unified_sita0_for_radius = sar_params.get('unified_sita0_for_radius', None)
    if unified_sita0_for_radius is not None:
        # 使用统一的sita0计算半径（保持相机位置不变）
        sita0_for_radius = unified_sita0_for_radius
    else:
        # 使用当前图像的俯视角作为中心下视角（替代原来的sita0）
        sita0_for_radius = dep_rad
    
    # 计算统一的参考斜距（用于球面半径 / radius_scale 基准）
    # dep_rad / sita0_for_radius 均为 normalize 后的天底入射角 θ；R = H/cos(θ)
    R0 = _slant_range_from_nadir_incidence(camera_height, sita0_for_radius)

    # 水平圆环地面距离：固定 Y=-H，g = H·tan(θ)（horizon 俯角 φ 时 g = H/tan(φ)）
    ground_range = _ground_range_ring_from_nadir_incidence(camera_height, dep_rad)
    
    # 获取半径缩放因子（如果存在，用于调整相机半径）
    # 注意：如果焦距使用图像尺寸的倍数（而不是物理单位），
    # 相机位置也需要相应缩放，以避免点云分散和相机位置异常
    # 默认使用一个合理的缩放因子，使相机位置与焦距匹配
    # 支持任意图像尺寸（如128x128, 256x256, 512x512等）的自适应调整
    default_radius_scale = sar_params.get('default_radius_scale', None)
    if default_radius_scale is None:
        # 自动计算合理的缩放因子：使相机半径与图像尺寸匹配
        # 假设场景大小约为图像尺寸的倍数（比如10-20倍）
        # 这样相机位置不会太远，点云也不会太分散
        # 注意：这里需要先获取Na和Nr，它们会在后面用于计算K矩阵
        # 但为了计算半径缩放，我们需要提前获取它们
        Na = sar_params.get('Na', 512)  # 方位向采样点数（从实际图像尺寸获取）
        Nr = sar_params.get('Nr', 512)  # 距离向采样点数（从实际图像尺寸获取）
        scene_scale = sar_params.get('scene_scale', 0.1)  # 场景缩放因子（统一默认值0.1，可通过--sar_scene_scale设置）
        image_size = max(Na, Nr)  # 使用较大的图像尺寸作为参考
        # 使用统一参考斜距R0作为基准来计算缩放因子
        default_radius_scale = (image_size * scene_scale) / R0 if R0 > 0 else 1.0
    
    radius_scale = sar_params.get('radius_scale', default_radius_scale)
    ground_range = ground_range * radius_scale  # 应用缩放后的地面距离（圆环半径）
    
    # 根据分布模式计算相机位置
    # COLMAP坐标系约定：X轴=右，Y轴=下（高度正方向在Y轴负方向），Z轴=前
    if distribution_mode == 'sphere':
        # 球面分布：相机在球面上，提供垂直方向的几何信息
        # 球面半径：使用统一的参考斜距
        sphere_radius = R0 * radius_scale  # 球面半径（缩放后）
        
        # 在球面上计算相机位置（符合COLMAP坐标系约定）
        # COLMAP约定：高度正方向在Y轴负方向，所以：
        # - X轴：水平方向（方位角）
        # - Y轴：高度方向（俯视角，负值表示高度）
        # - Z轴：水平方向（方位角）
        # x = sphere_radius * sin(depression) * cos(azimuth)
        # y = -sphere_radius * cos(depression)  # 高度在Y轴负方向（COLMAP约定）
        # z = sphere_radius * sin(depression) * sin(azimuth)
        radar_x = sphere_radius * np.sin(dep_rad) * np.cos(azi_rad)
        radar_y = -sphere_radius * np.cos(dep_rad)  # Y坐标随俯视角变化，高度在Y轴负方向
        radar_z = sphere_radius * np.sin(dep_rad) * np.sin(azi_rad)
    else:
        # 水平圆环分布（向后兼容）：Y坐标固定为-camera_height（COLMAP约定）
        # x = ground_range * cos(azimuth)
        # y = -camera_height  # 高度在Y轴负方向（COLMAP约定）
        # z = ground_range * sin(azimuth)
        radar_x = ground_range * np.cos(azi_rad)
        radar_y = -camera_height  # 高度在Y轴负方向（COLMAP约定）
        radar_z = ground_range * np.sin(azi_rad)
    
    # 雷达天线相位中心在世界坐标系中的位置
    P_radar = np.array([[radar_x], [radar_y], [radar_z]])
    
    # ========== SAR雷达坐标系定义（符合OpenCV/SfM约定）==========
    # OpenCV/SfM相机坐标系约定：
    # - X轴：右（right）
    # - Y轴：下（down）
    # - Z轴：前（forward，指向场景）
    #
    # 重要：相机应该指向场景中心（原点）
    
    # 计算从雷达指向场景中心的方向（这是相机的"前"方向，Z轴）
    # 场景中心在原点 (0, 0, 0)，雷达位置是 P_radar
    to_scene_center = -P_radar.flatten()  # 从雷达指向场景中心
    to_scene_center = to_scene_center / np.linalg.norm(to_scene_center)
    
    # 1. Z轴（前方向）：指向场景中心的方向
    forward_dir_world = to_scene_center
    
    # 2. 计算X轴（右方向）
    # COLMAP坐标系约定：Y轴向下，Z轴向前，高度正值在Y轴负方向
    # 世界"上"方向：Y轴负方向（符合COLMAP约定）
    world_up = np.array([0, -1, 0])
    
    # X轴 = 世界上方向 × Z轴（前方向）
    # 这确保X轴在垂直于前方向和世界上方向的平面内
    right_dir_world = np.cross(world_up, forward_dir_world)
    right_norm = np.linalg.norm(right_dir_world)
    
    # 特殊情况：如果相机直接在场景正上方或正下方，forward_dir与world_up共线
    # 此时使用方位角方向作为备选（COLMAP坐标系：方位角在XZ平面上）
    if right_norm < 1e-6:
        # 使用方位角方向作为右方向（XZ平面）
        # COLMAP坐标系：XZ平面是水平面，方位角 = atan2(Z, X)
        # right方向在XZ平面上，垂直于方位角方向
        right_dir_world = np.array([-np.sin(azi_rad), 0, np.cos(azi_rad)])  # XZ平面上的右方向
    else:
        right_dir_world = right_dir_world / right_norm
    
    # 3. Y轴（下方向）：使用叉积 Y = Z × X（右手坐标系）
    #    确保Y轴垂直于Z轴和X轴
    down_dir_world = np.cross(forward_dir_world, right_dir_world)
    down_dir_world = down_dir_world / np.linalg.norm(down_dir_world)
    
    # 构建旋转矩阵：从雷达坐标系到世界坐标系
    # 雷达坐标系的三个轴在世界坐标系中的表示（符合OpenCV约定）
    # 改进：使用世界"上"方向构建坐标系，确保在球面分布模式下相机姿态一致
    R_radar_to_world = np.column_stack([
        right_dir_world,    # X轴（右）
        down_dir_world,     # Y轴（下）
        forward_dir_world   # Z轴（前，指向场景中心）
    ])
    
    # 🔧 修复SVD错误：检查旋转矩阵的有效性
    # 检查是否有NaN或Inf值
    if np.any(np.isnan(R_radar_to_world)) or np.any(np.isinf(R_radar_to_world)):
        # 如果矩阵无效，使用单位矩阵作为备选
        print(f"⚠️ 警告: 旋转矩阵包含NaN或Inf，使用单位矩阵")
        R_radar_to_world = np.eye(3)
    else:
        # 确保旋转矩阵是正交矩阵（R @ R.T = I）且行列式为1（右手坐标系）
        # 使用SVD分解来修正旋转矩阵
        try:
            U, S, Vt = np.linalg.svd(R_radar_to_world)
            R_radar_to_world = U @ Vt
        except np.linalg.LinAlgError as e:
            # 如果SVD失败，尝试使用Gram-Schmidt正交化
            print(f"⚠️ 警告: SVD失败 ({e})，使用Gram-Schmidt正交化")
            # 归一化三个向量
            right_dir_world = right_dir_world / (np.linalg.norm(right_dir_world) + 1e-8)
            down_dir_world = down_dir_world / (np.linalg.norm(down_dir_world) + 1e-8)
            forward_dir_world = forward_dir_world / (np.linalg.norm(forward_dir_world) + 1e-8)
            # 重新构建矩阵
            R_radar_to_world = np.column_stack([right_dir_world, down_dir_world, forward_dir_world])
            # 再次尝试SVD
            try:
                U, S, Vt = np.linalg.svd(R_radar_to_world)
                R_radar_to_world = U @ Vt
            except:
                # 如果还是失败，使用单位矩阵
                print(f"⚠️ 警告: 多次SVD失败，使用单位矩阵")
                R_radar_to_world = np.eye(3)
    
    # 确保行列式为1（如果是-1，则取反最后一列）
    det = np.linalg.det(R_radar_to_world)
    if det < 0:
        R_radar_to_world[:, 2] = -R_radar_to_world[:, 2]
    
    # 从世界坐标系到雷达坐标系的旋转（用于投影）
    # 在OpenCV/SfM中，R是从世界坐标系到相机坐标系的旋转
    R_world_to_radar = R_radar_to_world.T
    
    # ========== 平移向量计算 ==========
    # 在OpenCV/SfM框架中，P = K[R|t]，其中：
    # - R是从世界坐标系到相机坐标系的旋转
    # - t是从世界坐标系到相机坐标系的平移
    # 对于SAR：t = -R @ P_radar（雷达位置在雷达坐标系中的表示）
    t = -R_world_to_radar @ P_radar
    
    # ========== SAR投影矩阵（基于斜距方程）==========
    # SAR图像使用距离-多普勒坐标系，不是像平面坐标系
    # 图像坐标(x, y)对应：
    # - x: 方位向位置（azimuth position）
    # - y: 距离向位置（range position，对应斜距）
    
    Na = sar_params['Na']  # 方位向采样点数
    Nr = sar_params['Nr']  # 距离向采样点数
    Va = sar_params['Va']  # 平台速度
    prf = sar_params['prf']  # 脉冲重复频率
    fs = sar_params['fs']  # 采样率
    C = sar_params['C']  # 光速
    
    # SAR图像像素到物理坐标的转换
    # 方位向：基于平台速度和PRF（多普勒参数相关）
    azimuth_pixel_size = Va / prf  # 每个像素对应的方位向距离
    
    # 距离向：基于斜距和采样率（距离方程相关）
    range_pixel_size = C / (2 * fs)  # 每个像素对应的斜距增量
    
    # SAR投影矩阵（将图像坐标转换为物理坐标）
    # 注意：这不是透视投影，而是基于斜距方程的映射
    # 对于兼容性，我们仍然使用K矩阵形式，但其物理意义不同
    # K矩阵将图像坐标(x, y)转换为雷达坐标系中的物理坐标
    
    # 计算等效"焦距" - 支持基于实际R0的动态计算
    # 🔧 关键修复：当R0改变时，焦距必须相应改变，以确保投影正确
    # 
    # 焦距计算策略：
    # 1. 如果提供了实际R0（优化后），基于R0计算焦距（与R0成比例）
    # 2. 否则，使用图像尺寸的倍数（初始化和向后兼容）
    # 
    # 焦距与R0的关系：f ≈ R0 / pixel_size（物理单位）
    # 但需要转换为像素单位，并考虑缩放因子
    
    use_actual_R0 = sar_params.get('use_actual_R0_for_focal', False)
    actual_R0 = sar_params.get('actual_R0', None)
    
    if use_actual_R0 and actual_R0 is not None and actual_R0 > 1e-6:
        # 🔧 基于实际R0计算焦距（确保投影正确）
        # 物理焦距：f_physical = R0 / pixel_size
        # 转换为像素单位：f_pixel = f_physical * scale_factor
        # scale_factor用于保持合理的像素值范围
        
        # 计算像素尺寸
        azimuth_pixel_size = Va / prf  # 方位向像素尺寸（米/像素）
        range_pixel_size = C / (2 * fs)  # 距离向像素尺寸（米/像素）
        
        # 物理焦距（米）
        physical_focal_azimuth = actual_R0 / azimuth_pixel_size
        physical_focal_range = actual_R0 / range_pixel_size
        
        # 转换为像素单位：使用缩放因子，使焦距在合理范围内
        # 参考焦距：使用图像尺寸的倍数作为基准
        reference_focal_azimuth = Na * sar_params.get('focal_scale', 1.5)
        reference_focal_range = Nr * sar_params.get('focal_scale', 1.5)
        
        # 参考R0：使用理论R0（基于camera_height和天底入射角）
        reference_R0 = _slant_range_from_nadir_incidence(camera_height, dep_rad)
        
        # 缩放因子：使焦距与R0成比例，但保持在合理范围
        # focal = reference_focal * (actual_R0 / reference_R0)
        if reference_R0 > 1e-6:
            focal_scale_ratio = actual_R0 / reference_R0
            focal_azimuth = reference_focal_azimuth * focal_scale_ratio
            focal_range = reference_focal_range * focal_scale_ratio
        else:
            # 如果参考R0无效，使用图像尺寸的倍数
            focal_scale = sar_params.get('focal_scale', 1.5)
            focal_azimuth = Na * focal_scale
            focal_range = Nr * focal_scale
        
        # 确保焦距在合理范围内（不小于图像尺寸的0.5倍，不大于5倍）
        focal_azimuth = np.clip(focal_azimuth, Na * 0.5, Na * 5.0)
        focal_range = np.clip(focal_range, Nr * 0.5, Nr * 5.0)
        
    else:
        # 使用统一的焦距值（如果存在，用于初始化）
        unified_focal_azimuth = sar_params.get('unified_focal_azimuth', None)
        unified_focal_range = sar_params.get('unified_focal_range', None)
        
        if unified_focal_azimuth is not None and unified_focal_range is not None:
            # 使用统一的焦距值（初始化阶段）
            focal_azimuth = unified_focal_azimuth
            focal_range = unified_focal_range
        else:
            # 方法1：使用图像尺寸的倍数（默认，向后兼容）
            # 焦距 = 图像尺寸 * 缩放因子，缩放因子通常在1-2之间
            # 对于128x128图像：焦距 ≈ 128 * 1.5 = 192像素
            # 对于512x512图像：焦距 ≈ 512 * 1.5 = 768像素
            focal_scale = sar_params.get('focal_scale', 1.5)  # 默认1.5倍图像尺寸
            focal_azimuth = Na * focal_scale  # 方位向等效焦距（自适应图像尺寸）
            focal_range = Nr * focal_scale    # 距离向等效焦距（自适应图像尺寸）
    
    # 构建SAR投影矩阵
    # 注意：这个K矩阵的含义与光学相机不同
    # 它表示从图像坐标到雷达坐标系中物理坐标的线性映射
    # 如果提供了统一的中心点，使用它们（确保所有图像K矩阵完全一致）
    unified_cx = sar_params.get('unified_cx', None)
    unified_cy = sar_params.get('unified_cy', None)
    if unified_cx is not None and unified_cy is not None:
        cx = unified_cx
        cy = unified_cy
    else:
        cx = Na / 2.0
        cy = Nr / 2.0
    K = np.array([
        [focal_azimuth, 0, cx],  # 方位向
        [0, focal_range, cy],    # 距离向
        [0, 0, 1]
    ])
    
    # 返回的R和t用于兼容SfM框架
    # 但需要注意：SAR的投影关系不是P = K[R|t] * X，而是基于斜距方程
    return R_world_to_radar, t, K


def pradar_to_world_to_camera_rt(P_radar, azi_rad):
    """
    给定世界系下雷达相位中心位置 P_radar（3x1 或 shape (3,)）与方位角 azi_rad（弧度，
    用于 forward 与 world_up 共线时的回退），计算与 compute_sar_camera_pose 相同的
    R_world_to_radar 与 t（COLMAP/OpenCV 约定）。

    用于从 COLMAP 尺度下的环上位置直接构造相机外参，而不经过物理 sar_params 距离公式。
    """
    P_radar = np.asarray(P_radar, dtype=np.float64).reshape(3, 1)
    to_scene_center = -P_radar.flatten()
    to_scene_center = to_scene_center / (np.linalg.norm(to_scene_center) + 1e-12)
    forward_dir_world = to_scene_center
    world_up = np.array([0, -1, 0])
    right_dir_world = np.cross(world_up, forward_dir_world)
    right_norm = np.linalg.norm(right_dir_world)
    if right_norm < 1e-6:
        right_dir_world = np.array([-np.sin(azi_rad), 0, np.cos(azi_rad)])
    else:
        right_dir_world = right_dir_world / right_norm
    down_dir_world = np.cross(forward_dir_world, right_dir_world)
    down_dir_world = down_dir_world / (np.linalg.norm(down_dir_world) + 1e-12)
    R_radar_to_world = np.column_stack([
        right_dir_world,
        down_dir_world,
        forward_dir_world,
    ])
    if np.any(np.isnan(R_radar_to_world)) or np.any(np.isinf(R_radar_to_world)):
        R_radar_to_world = np.eye(3)
    else:
        try:
            U, S, Vt = np.linalg.svd(R_radar_to_world)
            R_radar_to_world = U @ Vt
        except np.linalg.LinAlgError:
            R_radar_to_world = np.eye(3)
    det = np.linalg.det(R_radar_to_world)
    if det < 0:
        R_radar_to_world[:, 2] = -R_radar_to_world[:, 2]
    R_world_to_radar = R_radar_to_world.T
    t = -R_world_to_radar @ P_radar
    return R_world_to_radar, t


def sar_stereo_triangulation(img1_pts, img2_pts, R1, t1, R2, t2, K1, K2, 
                             dep1, azi1, dep2, azi2, sar_params=None):
    """
    SAR立体视觉三角化 - 基于斜距方程和多普勒方程
    
    注意：SAR三角化与光学相机的根本区别：
    1. SAR使用斜距方程：R = |P_target - P_radar(t)|
    2. SAR需要考虑多普勒参数：f_d = -(2/λ) * (dR/dt)
    3. SAR的三角化基于两个视角的斜距信息，不是透视投影的交点
    
    Args:
        img1_pts: 图像1中的点 (Nx2) - 图像坐标(x, y)，x=方位向，y=距离向
        img2_pts: 图像2中的点 (Nx2)
        R1, t1: 图像1 外参（世界 → 相机，与 compute_sar_camera_pose 返回值一致）
        R2, t2: 图像2 外参
        K1, K2: 图像1和2的投影矩阵（图像坐标到雷达坐标系物理坐标）
        dep1, azi1: 图像1的俯视角和方位角
        dep2, azi2: 图像2的俯视角和方位角
        sar_params: SAR系统参数
    
    Returns:
        pts3d: 3D点云 (Nx3) - 世界坐标系中的3D点
    """
    if sar_params is None:
        sar_params = DEFAULT_SAR_PARAMS

    n = len(img1_pts)
    if n == 0:
        return np.zeros((0, 3), dtype=np.float64)

    R1 = np.asarray(R1, dtype=np.float64)
    R2 = np.asarray(R2, dtype=np.float64)
    t1 = np.asarray(t1, dtype=np.float64).reshape(3, 1)
    t2 = np.asarray(t2, dtype=np.float64).reshape(3, 1)
    K1 = np.asarray(K1, dtype=np.float64)
    K2 = np.asarray(K2, dtype=np.float64)

    P1 = K1 @ np.hstack([R1, t1])
    P2 = K2 @ np.hstack([R2, t2])

    pts_h = cv2.triangulatePoints(
        P1,
        P2,
        img1_pts.astype(np.float64).T,
        img2_pts.astype(np.float64).T,
    )
    w = pts_h[3, :].copy()
    w = np.where(np.abs(w) < 1e-12, 1e-12 * np.sign(w + (w >= 0) - 0.5), w)
    pts3d = (pts_h[:3] / w).T.astype(np.float64)

    def _in_front_both(X: np.ndarray) -> float:
        z1 = (R1 @ X.T + t1)[2, :]
        z2 = (R2 @ X.T + t2)[2, :]
        return float(np.mean((z1 > 0) & (z2 > 0)))

    # 针孔/近似 P 下 X 与 -X 可能都满足弱约束；选在两相机前向深度均为正的占比更高者
    if _in_front_both(-pts3d) > _in_front_both(pts3d):
        pts3d = -pts3d

    return pts3d


def compute_sar_fundamental_matrix(R1, t1, R2, t2, K1, K2):
    """
    计算SAR图像对的基础矩阵
    注意：SAR的基础矩阵计算与光学图像类似，但需要考虑SAR几何
    
    Args:
        R1, t1: 图像1的旋转和平移
        R2, t2: 图像2的旋转和平移
        K1, K2: 图像1和2的内参矩阵
    
    Returns:
        F: 基础矩阵 (3x3)
    """
    # 计算相对旋转和平移
    R_rel = R2 @ R1.T
    t_rel = t2 - R_rel @ t1
    
    # 计算本质矩阵
    t_skew = np.array([
        [0, -t_rel[2, 0], t_rel[1, 0]],
        [t_rel[2, 0], 0, -t_rel[0, 0]],
        [-t_rel[1, 0], t_rel[0, 0], 0]
    ])
    
    E = t_skew @ R_rel
    
    # 计算基础矩阵
    F = np.linalg.inv(K2).T @ E @ np.linalg.inv(K1)
    
    return F


def sar_pose_from_angles_and_matches(img1_pts, img2_pts, dep1, azi1, dep2, azi2, 
                                     sar_params=None, use_optimization=True):
    """
    从角度信息和匹配点估计SAR相机姿态
    
    Args:
        img1_pts: 图像1中的匹配点
        img2_pts: 图像2中的匹配点
        dep1, azi1: 图像1的俯视角和方位角
        dep2, azi2: 图像2的俯视角和方位角
        sar_params: SAR系统参数
        use_optimization: 是否使用优化来细化姿态
    
    Returns:
        R1, t1: 图像1的旋转和平移
        R2, t2: 图像2的旋转和平移
        K1, K2: 图像1和2的内参矩阵
    """
    if sar_params is None:
        sar_params = DEFAULT_SAR_PARAMS
    
    # 从角度计算初始姿态
    R1, t1, K1 = compute_sar_camera_pose(dep1, azi1, sar_params)
    R2, t2, K2 = compute_sar_camera_pose(dep2, azi2, sar_params)
    
    # 如果需要，可以使用匹配点优化姿态
    if use_optimization and len(img1_pts) >= 8:
        try:
            # 使用RANSAC估计基础矩阵
            F, mask = cv2.findFundamentalMat(
                img1_pts, img2_pts,
                method=cv2.FM_RANSAC,
                ransacReprojThreshold=1.0,
                confidence=0.99
            )
            
            if F is not None and mask is not None:
                # 从基础矩阵恢复姿态（作为初始估计的细化）
                # 注意：对于SAR，这可能不如直接从角度计算准确
                # 但可以用来验证和微调
                mask = mask.astype(bool).flatten()
                if np.sum(mask) >= 8:
                    E = K2.T @ F @ K1
                    _, R_est, t_est, _ = cv2.recoverPose(
                        E, img1_pts[mask], img2_pts[mask], K1
                    )
                    # 可以选择性地使用估计的旋转来微调
                    # 但保持从角度计算的主要姿态
        except:
            pass  # 如果优化失败，使用从角度计算的姿态
    
    return R1, t1, R2, t2, K1, K2

