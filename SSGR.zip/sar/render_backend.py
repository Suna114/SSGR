"""训练/渲染时 SAR 后端路径诊断（一次打印，避免 tqdm 刷屏）。"""
from __future__ import annotations

from typing import Any, Iterable, Optional


def _cuda_ext_available() -> bool:
    try:
        from diff_sar_rasterization import SAR_RASTERIZATION_AVAILABLE
        return bool(SAR_RASTERIZATION_AVAILABLE)
    except ImportError:
        return False


def resolve_sar_render_backend(
    dataset,
    pipe,
    train_cameras: Optional[Iterable[Any]] = None,
    use_sar_rendering_config: bool = True,
) -> str:
    """
    返回当前迭代将使用的渲染后端标识：
    - sar3dgs_sdgr_cuda   : --no_sar_fast_mode + 相机 SAR 几何 + diff_sar_rasterization
    - sar3dgs_sdgr_python : 同上但无 CUDA 扩展
    - optical_cuda_fast   : 默认 sar_fast_mode（diff-gaussian-rasterization 光学近似）
    - standard_3dgs       : 非 SAR 或相机无 SAR 几何
    """
    sar_mode = bool(getattr(dataset, "sar_mode", False))
    sar_fast = bool(getattr(pipe, "sar_fast_mode", True))

    cam_sar_ready = 0
    n_cams = 0
    if train_cameras is not None:
        for cam in train_cameras:
            n_cams += 1
            if (
                getattr(cam, "use_sar_rendering", False)
                and getattr(cam, "R_world_to_radar", None) is not None
            ):
                cam_sar_ready += 1

    if not sar_mode or not use_sar_rendering_config or cam_sar_ready == 0:
        return "standard_3dgs"
    if sar_fast:
        return "optical_cuda_fast"
    use_cuda = bool(getattr(pipe, "sar_sdgr_cuda", True)) and _cuda_ext_available()
    return "sar3dgs_sdgr_cuda" if use_cuda else "sar3dgs_sdgr_python"


_BACKEND_LABELS = {
    "sar3dgs_sdgr_cuda": "SAR-3DGS SDGR（斜距投影 PyTorch-GPU + 散射/阴影 diff-sar-rasterization CUDA，默认）",
    "sar3dgs_sdgr_python": "SAR-3DGS SDGR + Python alpha 混合（--no_sar_sdgr_cuda 或 CUDA 失败后降级）",
    "optical_cuda_fast": "SAR 快速模式：diff-gaussian-rasterization 光学 CUDA 近似（非论文 SDGR）",
    "standard_3dgs": "标准 3DGS 光学光栅（SAR 几何未就绪或未启用）",
}


def print_sar_render_backend(
    dataset,
    pipe,
    train_cameras: Optional[Iterable[Any]] = None,
    use_sar_rendering_config: bool = True,
) -> str:
    backend = resolve_sar_render_backend(
        dataset, pipe, train_cameras, use_sar_rendering_config=use_sar_rendering_config,
    )
    sar_fast = bool(getattr(pipe, "sar_fast_mode", True))
    n_ready = 0
    n_total = 0
    if train_cameras is not None:
        for cam in train_cameras:
            n_total += 1
            if (
                getattr(cam, "use_sar_rendering", False)
                and getattr(cam, "R_world_to_radar", None) is not None
            ):
                n_ready += 1

    print("\n[SAR 渲染后端]")
    print(f"  sar_fast_mode: {sar_fast}  (--no_sar_fast_mode 时为 False)")
    print(f"  diff_sar_rasterization CUDA 扩展: {_cuda_ext_available()}")
    if not sar_fast and backend == "sar3dgs_sdgr_python":
        print(
            f"  sar_sdgr_cuda: False  (Python alpha；加 --sar_sdgr_cuda 或去掉 --no_sar_sdgr_cuda 启用 CUDA)"
        )
    elif not sar_fast and backend == "sar3dgs_sdgr_cuda":
        print(f"  sar_sdgr_cuda: True  (散射+阴影 pass 使用 diff-sar-rasterization CUDA；失败自动降级 Python)")
    if n_total:
        print(f"  训练相机 SAR 几何就绪: {n_ready}/{n_total}")
    print(f"  实际后端: {_BACKEND_LABELS.get(backend, backend)}")
    if backend == "standard_3dgs" and not sar_fast and n_total and n_ready == 0:
        print("  说明: --no_sar_fast_mode 已开，但相机缺少 use_sar_rendering/R_world_to_radar；")
        print("        已回退光学 3DGS。请确认 scene 在 sar_mode 下加载了 sar_params（见上方 [SAR] 行）。")
    elif backend == "optical_cuda_fast" and not sar_fast:
        print("  注意: sar_fast_mode=False 但 SAR 几何未就绪，已回退光学路径。")
    return backend
