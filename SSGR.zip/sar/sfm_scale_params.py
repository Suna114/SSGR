"""
SfM / SO-RCG 场景尺度与 camera_height 的单一事实来源。

规则摘要
--------
- ``sar_camera_height``（config 默认 12000 m）= MSTAR **物理平台高度**，仅作对照，**不是** COLMAP 场景单位 H。
- MSTAR 闭合（``sfm_mstar_init_from_pixel_resolution``）在 SO-RCG 前写入场景 H / scene_scale。
- height-only / MSTAR 路径：**禁止**用重建位姿中位 |Y| 覆盖 ``camera_height``。
- 全自由度 SO-RCG（无 MSTAR）：才允许 pose 中位 |Y| 作为场景 H 估计。
"""

from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

import numpy as np

from sar.scene_scale_closure import (
    mstar_authoritative_height_m,
    mstar_height_search_ratio,
    mstar_init_enabled,
    solver_height_polluted,
)


@dataclass
class SceneHeightResolution:
    """写入 sar_scale_params.json 的 camera_height / R0 决议。"""

    camera_height_m: float
    slant_range_m: float
    source: str
    use_pose_median: bool


def finite_json_float(
    value: Any,
    *,
    fallback: float,
    lo: float = 1e-9,
    hi: float = 1e12,
) -> float:
    try:
        v = float(value)
        if not math.isfinite(v):
            return float(fallback)
        return float(min(hi, max(lo, v)))
    except (TypeError, ValueError):
        return float(fallback)


def pose_geometry_stats(image_data: Mapping[str, Any]) -> Optional[Dict[str, float]]:
    """从 image_data[name] = [R, t, ref] 估计中位斜距与中位 |Y|。"""
    if not image_data:
        return None
    ranges: list[float] = []
    heights: list[float] = []
    for _, (R_cam, t_cam, _) in image_data.items():
        R = np.asarray(R_cam, dtype=np.float64)
        t = np.asarray(t_cam, dtype=np.float64).reshape(3, 1)
        P = (-R.T @ t).flatten()
        if not np.all(np.isfinite(P)):
            continue
        ranges.append(float(np.linalg.norm(P)))
        heights.append(float(abs(P[1])))
    if not ranges:
        return None
    return {
        "median_slant_range_m": float(np.median(ranges)),
        "median_platform_height_m": float(np.median(heights)),
        "num_cameras": float(len(ranges)),
    }


def _mstar_authoritative_height_m(sar_params: Mapping[str, Any]) -> float:
    return mstar_authoritative_height_m(sar_params)


def _mstar_height_search_ratio(sar_params: Mapping[str, Any]) -> float:
    return mstar_height_search_ratio(sar_params)


def _solver_height_polluted(
    ch_solver: float,
    ch_authoritative: float,
    *,
    search_ratio: float,
) -> bool:
    return solver_height_polluted(
        ch_solver, ch_authoritative, search_ratio=search_ratio
    )


def resolve_authoritative_scene_height(
    sar_params: Dict[str, Any],
    *,
    pose_stats: Optional[Mapping[str, float]] = None,
    physical_platform_height_m: float = 12000.0,
    point_max_extent: float = 1.0,
    avg_depression_deg: float = 30.0,
) -> SceneHeightResolution:
    """
    决定写入 sar_scale_params.json 的 **场景单位** camera_height 与 R0。

    优先级
    1. MSTAR 初值 + SO-RCG 共享高度微调 → ``sar_params['camera_height']``
    2. height-only（无 MSTAR 标记但已优化）→ ``sar_params['camera_height']``
    3. 全自由度 SO-RCG → pose 中位 |Y| / 中位斜距
    4. 回退 → 物理高度 / sin(俯角)（最后手段，并 clamp）
    """
    mstar = bool(sar_params.get("mstar_init_from_pixel_resolution"))
    height_only = bool(sar_params.get("ba_fix_angles_optimize_height_only"))

    if mstar or height_only:
        ch_solver = float(sar_params.get("camera_height", 0.0) or 0.0)
        ch_mstar = _mstar_authoritative_height_m(sar_params)
        search_ratio = _mstar_height_search_ratio(sar_params)
        src_suffix = ""
        if mstar and ch_mstar > 0 and _solver_height_polluted(
            ch_solver, ch_mstar, search_ratio=search_ratio
        ):
            ch = ch_mstar
            if ch_solver > max(50.0, ch_mstar * 20.0):
                src_suffix = " (reject km-scale solver H)"
            elif ch_solver < ch_mstar * max(0.02, 1.0 - search_ratio):
                src_suffix = " (reject sub-scale solver H)"
            else:
                src_suffix = " (reject out-of-band solver H)"
        else:
            ch = ch_solver if ch_solver > 0 else (ch_mstar or 1.0)
        ch = finite_json_float(ch, fallback=ch_mstar or 1.0, lo=1e-6, hi=1e4)
        if mstar:
            r0 = finite_json_float(
                sar_params.get("mstar_init_slant_range_m", 0.0),
                fallback=ch / max(float(np.cos(np.deg2rad(avg_depression_deg))), 1e-6),
                lo=1e-6,
                hi=1e4,
            )
            src = "mstar_init + sorc_shared_height" + src_suffix
        else:
            if pose_stats is not None:
                r0 = finite_json_float(
                    pose_stats.get("median_slant_range_m", 0.0),
                    fallback=max(point_max_extent * 5.0, 1.0),
                    lo=1e-6,
                    hi=1e4,
                )
            else:
                r0 = max(point_max_extent * 5.0, ch * 2.0)
            src = "sorc_height_only_optimized" + src_suffix
        return SceneHeightResolution(
            camera_height_m=ch,
            slant_range_m=r0,
            source=src,
            use_pose_median=False,
        )

    if pose_stats is not None:
        r0 = finite_json_float(
            pose_stats.get("median_slant_range_m", 0.0),
            fallback=max(point_max_extent * 5.0, 1.0),
            lo=1e-6,
            hi=1e9,
        )
        ch = finite_json_float(
            pose_stats.get("median_platform_height_m", 0.0),
            fallback=max(r0 * 0.5, 1e-3),
            lo=1e-6,
            hi=1e9,
        )
        return SceneHeightResolution(
            camera_height_m=ch,
            slant_range_m=r0,
            source="median_platform_height_from_reconstructed_poses",
            use_pose_median=True,
        )

    sin_dep = max(float(np.sin(np.deg2rad(avg_depression_deg))), 1e-6)
    r0 = physical_platform_height_m / sin_dep
    if not math.isfinite(r0) or r0 > 1e12:
        r0 = max(point_max_extent * 10.0, 1.0)
    ch = finite_json_float(
        sar_params.get("camera_height", physical_platform_height_m),
        fallback=r0 * 0.5,
        lo=1e-6,
        hi=1e12,
    )
    return SceneHeightResolution(
        camera_height_m=ch,
        slant_range_m=float(r0),
        source="fallback_physical_camera_height_over_sin",
        use_pose_median=False,
    )


def build_initial_scale_params(
    *,
    unified_radius_scale: float,
    scene_scale: float,
    unified_focal_azimuth: float,
    unified_focal_range: float,
    unified_cx: float,
    unified_cy: float,
    camera_height: float,
    ref_width: int,
    ref_height: int,
    R0: float,
    sita0_deg: float,
    sar_params: Dict[str, Any],
) -> Dict[str, Any]:
    """MSTAR 初值 / 统一焦距阶段写入 sar_scale_params.json（SO-RCG 之前）。"""
    image_size = int(max(ref_width, ref_height))
    out: Dict[str, Any] = {
        "unified_radius_scale": float(unified_radius_scale),
        "scene_scale": float(scene_scale),
        "unified_focal_azimuth": float(unified_focal_azimuth),
        "unified_focal_range": float(unified_focal_range),
        "unified_cx": float(unified_cx),
        "unified_cy": float(unified_cy),
        "camera_height": float(camera_height),
        "reference_image_size": [int(ref_width), int(ref_height)],
        "radius_scale_calculation": {
            "R0": float(R0),
            "unified_sita0_deg": float(sita0_deg),
            "image_size": image_size,
            "sphere_radius": float(R0 * unified_radius_scale),
            "formula": "(image_size × scene_scale) / R0",
            "note": "radius_scale基于实际图像尺寸和统一俯视角自动计算",
        },
        "scale_reference": "mstar_init_before_sorc" if sar_params.get("mstar_init_from_pixel_resolution") else "unified_init_before_sorc",
    }
    if sar_params.get("mstar_init_from_pixel_resolution"):
        out.update({
            "mstar_init_from_pixel_resolution": True,
            "mstar_init_camera_height_m": float(
                sar_params.get("mstar_init_camera_height_m", camera_height)
            ),
            "mstar_init_scene_scale": float(
                sar_params.get("mstar_init_scene_scale", scene_scale)
            ),
            "mstar_init_slant_range_m": float(
                sar_params.get("mstar_init_slant_range_m", R0)
            ),
            "mstar_init_focal_px": float(
                sar_params.get("mstar_init_focal_px", unified_focal_azimuth)
            ),
        })
    return out


def build_sorc_final_scale_update(
    *,
    sar_params: Dict[str, Any],
    pose_stats: Optional[Mapping[str, float]],
    physical_platform_height_m: float,
    point_max_extent: float,
    avg_depression_deg: float,
    estimated_radius_scale: float,
    camera_distribution_mode: str,
    args: Any = None,
) -> Tuple[Dict[str, Any], SceneHeightResolution]:
    """SO-RCG 结束后合并进 sar_scale_params.json 的字段（不覆盖 MSTAR 权威 H）。"""
    if args is not None and mstar_init_enabled(args):
        from sar.scene_scale_closure import ensure_mstar_initial_sar_params

        ref = sar_params.get("reference_image_size")
        rw, rh = int(sar_params.get("Na", 128)), int(sar_params.get("Nr", 128))
        if isinstance(ref, (list, tuple)) and len(ref) >= 2:
            rw, rh = int(ref[0]), int(ref[1])
        src = getattr(args, "source_path", None) or getattr(args, "sfm_data_dir", None)
        ensure_mstar_initial_sar_params(
            sar_params,
            args,
            ref_width=rw,
            ref_height=rh,
            image_angles=None,
            source_path=src,
        )

    resolved = resolve_authoritative_scene_height(
        sar_params,
        pose_stats=pose_stats,
        physical_platform_height_m=physical_platform_height_m,
        point_max_extent=point_max_extent,
        avg_depression_deg=avg_depression_deg,
    )
    mstar = bool(sar_params.get("mstar_init_from_pixel_resolution"))
    height_only = bool(sar_params.get("ba_fix_angles_optimize_height_only"))

    update: Dict[str, Any] = {
        "estimated_radius_scale": float(estimated_radius_scale),
        "point_cloud_max_extent": float(point_max_extent),
        "average_depression_angle": float(avg_depression_deg),
        "camera_distribution_mode": str(camera_distribution_mode),
        "camera_height": float(resolved.camera_height_m),
        "scaled_camera_height": float(resolved.camera_height_m),
        "physical_platform_height_m": float(physical_platform_height_m),
        "median_slant_range_m": float(resolved.slant_range_m),
        "scale_reference": resolved.source,
        "method": "SO-RCG",
        "height_resolution_used_pose_median": bool(resolved.use_pose_median),
        "note": (
            "camera_height 为场景单位（非 sar_camera_height 物理 12km）；"
            "physical_platform_height_m 为 MSTAR 物理口径对照"
        ),
    }

    if mstar:
        h_preserved = _mstar_authoritative_height_m(sar_params)
        if h_preserved <= 0:
            h_preserved = float(resolved.camera_height_m)
        update.update({
            "mstar_init_from_pixel_resolution": True,
            "mstar_init_camera_height_m": float(h_preserved),
            "mstar_init_scene_scale": float(
                sar_params.get("mstar_init_scene_scale", sar_params.get("scene_scale", 1.0))
            ),
            "mstar_init_slant_range_m": float(
                sar_params.get("mstar_init_slant_range_m", resolved.slant_range_m)
            ),
            "scene_scale": float(
                sar_params.get("scene_scale", sar_params.get("mstar_init_scene_scale", 1.0))
            ),
        })
        fp = sar_params.get("mstar_init_focal_px")
        if fp is not None:
            update["unified_focal_azimuth"] = float(fp)
            update["unified_focal_range"] = float(fp)
        h_formula = float(sar_params.get("mstar_formula_camera_height_m", 0.0) or 0.0)
        if h_formula > 0:
            update["mstar_formula_camera_height_m"] = h_formula
        hr = float(sar_params.get("mstar_height_search_ratio", 0.0) or 0.0)
        if hr > 0:
            update["mstar_height_search_ratio"] = hr
    elif height_only:
        update["scale_reference"] = "sorc_height_only_optimized"

    return update, resolved


def load_scale_params_json(path: str) -> Dict[str, Any]:
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_scale_params_json(path: str, data: Dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def merge_scale_params_file(path: str, update: Dict[str, Any]) -> Dict[str, Any]:
    existing = load_scale_params_json(path)
    existing.update(update)
    save_scale_params_json(path, existing)
    return existing


def resolve_gs_training_camera_height(
    scale: Mapping[str, Any],
    args: Any,
    *,
    default_physical: float = 12000.0,
) -> float:
    """gs_satellite_poses：读取训练用场景 H，拒绝被 km 级中位 |Y| 污染的值。"""
    mstar_h = float(scale.get("mstar_init_camera_height_m", 0.0) or 0.0)
    ch: Optional[float] = None
    if "camera_height" in scale:
        ch = float(scale["camera_height"])
    if scale.get("mstar_init_from_pixel_resolution") or mstar_init_enabled(args):
        if mstar_h <= 0:
            mstar_h = float(scale.get("mstar_formula_camera_height_m", 0.0) or 0.0)
        if mstar_h <= 0 and scale.get("mstar_init_from_pixel_resolution"):
            mstar_h = ch if ch is not None and 0 < ch < 50 else 0.0
        if mstar_h > 0 and ch is not None and ch > 0:
            ratio = float(scale.get("mstar_height_search_ratio", 0.35) or 0.35)
            if _solver_height_polluted(float(ch), float(mstar_h), search_ratio=ratio):
                ch = mstar_h
        elif mstar_h > 0 and (ch is None or ch <= 0):
            ch = mstar_h
    if mstar_init_enabled(args) and (ch is None or ch > 2000.0):
        if mstar_h > 0:
            return mstar_h
        return 5.0
    if ch is not None and ch > 0 and ch < 2000.0:
        return ch
    if hasattr(args, "sar_camera_height") and args.sar_camera_height is not None:
        if not mstar_init_enabled(args) and not scale.get("mstar_init_from_pixel_resolution"):
            return float(args.sar_camera_height)
    return float(mstar_h if mstar_h > 0 else 5.0)


def should_skip_physical_height_for_sar_params(args: Any) -> bool:
    """convert / SFMOptions：MSTAR 或 GS 预设启用时勿把 sar_camera_height 写入 sar_params。"""
    return mstar_init_enabled(args)
