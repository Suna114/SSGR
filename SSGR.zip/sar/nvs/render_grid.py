#!/usr/bin/env python3
"""
0–360° 方位网格渲染，输出 MSTAR 风格 BMP：目标-俯视角-方位角.bmp

示例：
    python -m sar.nvs.render_grid -m output/360-2-full360 -i 30000 \\
        -o output/360-2-full360/renders_bmp --step 1

等价于 render_novel_sar_views.py + mstar/bmp/flat/colmap_track。
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def _repo_root() -> Path:
    p = Path(__file__).resolve()
    for parent in p.parents:
        if (parent / "train.py").is_file():
            return parent
    raise RuntimeError("无法定位仓库根目录")


def build_render_argv(args: argparse.Namespace) -> list[str]:
    root = _repo_root()
    script = root / "scripts" / "rendering" / "render_novel_sar_views.py"
    az_end = float(args.azimuth_end)
    if az_end <= 0 or az_end > 360:
        az_end = 360.0
    cmd = [
        sys.executable,
        str(script),
        "-m", str(args.model_path),
        "--iteration", str(int(args.iteration)),
        "--output_dir", str(args.output_dir),
        "--novel_pose_mode", str(args.pose_mode),
        "--colmap_track_azimuth_space", str(args.azimuth_space),
        "--output_filename_style", "mstar",
        "--output_image_ext", "bmp",
        "--output_layout", "flat",
        "--azimuth_start", str(float(args.azimuth_start)),
        "--azimuth_end", str(az_end),
        "--azimuth_step", str(float(args.step)),
    ]
    if args.target_name:
        cmd.extend(["--novel_target_name", str(args.target_name)])
    if args.same_depression_only:
        cmd.append("--same_depression_only")
    if args.depression_angles:
        cmd.extend(["--depression_angles", args.depression_angles])
    if args.quiet:
        cmd.append("--quiet")
    return cmd


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="SAR 全周新视角：MSTAR 命名 BMP（目标-俯视角-方位角）",
    )
    parser.add_argument("-m", "--model_path", required=True, help="训练输出目录")
    parser.add_argument("-i", "--iteration", type=int, default=-1, help="checkpoint 迭代；-1=最新")
    parser.add_argument(
        "-o", "--output_dir", required=True,
        help="BMP 输出目录（平铺，如 BMP2-15-000.bmp …）",
    )
    parser.add_argument("--step", type=float, default=1.0, help="方位角步长（度），默认 1")
    parser.add_argument("--azimuth_start", type=float, default=0.0)
    parser.add_argument("--azimuth_end", type=float, default=360.0, help="不含上界，360=整周")
    parser.add_argument(
        "--pose_mode", default="colmap_track",
        choices=["colmap_track", "colmap_ring", "sar"],
        help="默认 colmap_track（训练轨迹内插）",
    )
    parser.add_argument(
        "--azimuth_space", default="filename",
        choices=["filename", "geom"],
    )
    parser.add_argument("--target_name", default=None, help="如 BMP2；默认从训练图解析")
    parser.add_argument(
        "--same_depression_only", action="store_true", default=True,
        help="仅渲染训练俯角（默认开）",
    )
    parser.add_argument(
        "--no_same_depression_only", dest="same_depression_only", action="store_false",
    )
    parser.add_argument(
        "--depression_angles", type=str, default=None,
        help='多俯角时用空格字符串，如 "15 17 25"',
    )
    parser.add_argument("--quiet", action="store_true")
    ns = parser.parse_args(argv)

    out = Path(ns.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    cmd = build_render_argv(ns)
    if not ns.quiet:
        print("[sar.nvs.render_grid] 命令:")
        print(" ", " ".join(cmd))
    return subprocess.call(cmd)


if __name__ == "__main__":
    raise SystemExit(main())
