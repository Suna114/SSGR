"""python -m sar.nvs train | render"""
from __future__ import annotations

import sys


def main() -> int:
    if len(sys.argv) < 2:
        print(
            "用法:\n"
            "  python -m sar.nvs train -s data/360-2 -m output/xxx\n"
            "  python -m sar.nvs render -m output/xxx -i 30000 -o output/xxx/bmp --step 1\n"
            "  python -m sar.nvs eval -m output/xxx -i 30000 -o output/xxx/interp_eval"
        )
        return 1
    sub = sys.argv[1].lower()
    rest = sys.argv[2:]
    if sub in ("train", "train_full360"):
        from .train_full360 import main as train_main
        return train_main(rest)
    if sub in ("render", "render_grid"):
        from .render_grid import main as render_main
        return render_main(rest)
    if sub in ("eval", "eval_interp", "eval_interpolation"):
        from .eval_interpolation import main as eval_main
        return eval_main(rest)
    print(f"未知子命令: {sub}（可用 train / render / eval）")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
