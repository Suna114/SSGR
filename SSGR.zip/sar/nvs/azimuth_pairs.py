"""相邻训练方位弧段与中值角（用于 NVS 内插评估）。"""
from __future__ import annotations

import os
import re
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

_AZI_RE = re.compile(r"^([A-Za-z0-9]+)-(\d+)-(\d+)", re.IGNORECASE)


def camera_azimuth_deg(cam) -> Optional[float]:
    if hasattr(cam, "azimuth_angle") and cam.azimuth_angle is not None:
        return float(cam.azimuth_angle) % 360.0
    name = getattr(cam, "image_name", None) or ""
    stem = str(name).rsplit(".", 1)[0]
    m = _AZI_RE.search(stem)
    if m:
        return float(m.group(3)) % 360.0
    return None


def camera_depression_deg(cam, default: float = 15.0) -> float:
    if hasattr(cam, "depression_angle") and cam.depression_angle is not None:
        return float(cam.depression_angle)
    name = getattr(cam, "image_name", None) or ""
    stem = str(name).rsplit(".", 1)[0]
    m = _AZI_RE.search(stem)
    if m:
        return float(m.group(2))
    sp = getattr(cam, "sar_params", None) or {}
    return float(sp.get("depression_angle", default))


def sorted_azimuth_ring(train_cameras: Sequence) -> List[Tuple[float, object]]:
    pairs: List[Tuple[float, object]] = []
    for c in train_cameras:
        a = camera_azimuth_deg(c)
        if a is not None:
            pairs.append((a, c))
    pairs.sort(key=lambda p: (p[0], getattr(p[1], "image_name", "")))
    return pairs


def arc_span_deg(a0: float, a1: float) -> float:
    return float((a1 - a0) % 360.0)


def midpoint_on_arc(a0: float, a1: float, t: float = 0.5) -> Tuple[float, float, float]:
    """沿 a0→a1 短弧插值；返回 (mid_azimuth, w0, w1)。"""
    span = arc_span_deg(a0, a1)
    if span < 1e-6:
        return a0 % 360.0, 0.5, 0.5
    mid = (a0 + span * float(t)) % 360.0
    w1 = float(t)
    w0 = 1.0 - w1
    return mid, w0, w1


def adjacent_midpoint_pairs(
    train_cameras: Sequence,
    t: float = 0.5,
) -> List[Dict]:
    """
    对排序环上每一对相邻训练方位 (a_i, a_{i+1})，生成中值角评估项。
    含首尾环绕：最后一帧 → 第一帧。
    """
    ring = sorted_azimuth_ring(train_cameras)
    if len(ring) < 2:
        return []
    out: List[Dict] = []
    n = len(ring)
    for i in range(n):
        a0, cam0 = ring[i]
        a1, cam1 = ring[(i + 1) % n]
        mid, w0, w1 = midpoint_on_arc(a0, a1, t=t)
        out.append(
            {
                "index": i,
                "a0": float(a0),
                "a1": float(a1),
                "mid": float(mid),
                "w0": float(w0),
                "w1": float(w1),
                "span_deg": arc_span_deg(a0, a1),
                "cam0": cam0,
                "cam1": cam1,
                "name0": getattr(cam0, "image_name", ""),
                "name1": getattr(cam1, "image_name", ""),
            }
        )
    return out


def find_camera_near_azimuth(
    train_cameras: Sequence,
    azimuth_deg: float,
    tolerance_deg: float = 0.51,
) -> Optional[object]:
    """若数据集中存在与该方位（文件名解析）一致的 GT 相机，则返回。"""
    target = float(azimuth_deg) % 360.0
    best = None
    best_d = 1e9
    for c in train_cameras:
        a = camera_azimuth_deg(c)
        if a is None:
            continue
        d = abs(a - target) % 360.0
        d = min(d, 360.0 - d)
        if d < best_d:
            best_d = d
            best = c
    if best is not None and best_d <= float(tolerance_deg):
        return best
    return None


def find_gt_image_path(
    source_path: str,
    target_name: str,
    depression: int,
    azimuth: int,
    extensions: Sequence[str] = (".bmp", ".jpg", ".jpeg", ".png", ".tif"),
) -> Optional[str]:
    """在 source_path/images 下查找 MSTAR 命名 GT（若存在非训练集角）。"""
    if not source_path:
        return None
    img_dir = os.path.join(source_path, "images")
    if not os.path.isdir(img_dir):
        return None
    base = f"{target_name}-{int(depression)}-{int(azimuth):03d}"
    for ext in extensions:
        p = os.path.join(img_dir, base + ext)
        if os.path.isfile(p):
            return p
    return None
