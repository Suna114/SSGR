#!/usr/bin/env python3
"""
全周 0–360° 内插友好训练预设（稀疏训练角 + 插值软监督 + SDGR CUDA 默认）。

示例：
    python -m sar.nvs.train_full360 -s data/360-2 -m output/360-2-full360
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def _repo_root() -> Path:
    p = Path(__file__).resolve()
    for parent in p.parents:
        if (parent / "train_sar_complete.py").is_file():
            return parent
    raise RuntimeError("无法定位仓库根目录")


FULL360_TRAIN_EXTRA = [
    "--no_sar_fast_mode",
    "--no_auto_novel_render",
    "--sar_interp_soft_supervision",
    "--sar_interp_soft_every", "200",
    "--sar_interp_soft_weight", "0.25",
    "--sar_interp_soft_start_iter", "500",
    "--sar_interp_soft_t_values", "0.1,0.25,0.5,0.75,0.9",
    "--sar_interp_soft_samples_per_step", "2",
]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="SAR 全周 NVS 训练（exp15-5 + 插值软监督 + 默认 SDGR CUDA）",
    )
    parser.add_argument("-s", "--source_path", required=True)
    parser.add_argument("-m", "--model_path", required=True)
    parser.add_argument("--iterations", type=int, default=30000)
    parser.add_argument(
        "--sar_sdgr_cuda", action="store_true",
        help="散射 pass 使用 diff-sar-rasterization CUDA（默认关，更稳）",
    )
    parser.add_argument("extra", nargs=argparse.REMAINDER, help="传给 train_sar_complete 的额外参数")
    ns = parser.parse_args(argv)

    root = _repo_root()
    script = root / "train_sar_complete.py"
    cmd = [
        sys.executable,
        str(script),
        "-s", str(ns.source_path),
        "-m", str(ns.model_path),
        "--iterations", str(int(ns.iterations)),
        *FULL360_TRAIN_EXTRA,
    ]
    if ns.sar_sdgr_cuda:
        cmd.append("--sar_sdgr_cuda")
    extra = list(ns.extra or [])
    if extra and extra[0] == "--":
        extra = extra[1:]
    cmd.extend(extra)

    print("[sar.nvs.train_full360] 命令:")
    print(" ", " ".join(cmd))
    return subprocess.call(cmd)


if __name__ == "__main__":
    raise SystemExit(main())
