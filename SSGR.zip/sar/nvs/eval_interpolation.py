#!/usr/bin/env python3
"""
相邻训练方位弧段的中值角内插评估：PSNR（有 GT 时）+ anti-blend 指标 + 对比图。

MSTAR 通常只有离散训练角（如每 10°），无真实 15° GT；本脚本对每对 (a0,a1) 取中值角 mid，
用 colmap_track 渲染 mid，并与 I_a0、I_a1、0.5*(I_a0+I_a1) 对比。

示例：
    python -m sar.nvs.eval -m output/360-2-nvs -i 30000 \\
        -o output/360-2-nvs/interp_eval
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch
import torchvision
from PIL import Image

_REPO = Path(__file__).resolve().parents[2]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from arguments import ModelParams, PipelineParams, get_combined_args
from gaussian_renderer import render
from scene import Scene, GaussianModel
from utils.general_utils import safe_state
from utils.image_utils import psnr
from utils.system_utils import searchForMaxIteration

from sar.nvs.azimuth_pairs import (
    adjacent_midpoint_pairs,
    camera_depression_deg,
    find_camera_near_azimuth,
    find_gt_image_path,
)
from sar.nvs.naming import mstar_output_basename, parse_target_name_from_dataset

try:
    from diff_gaussian_rasterization import SparseGaussianAdam
    SPARSE_ADAM_AVAILABLE = True
except Exception:
    SPARSE_ADAM_AVAILABLE = False


def _import_render_novel():
    import importlib.util
    mod_path = _REPO / "scripts" / "rendering" / "render_novel_sar_views.py"
    spec = importlib.util.spec_from_file_location("_render_novel_sar_views", mod_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _resolve_iteration(model_path: str, iteration: int) -> int:
    if iteration >= 0:
        return iteration
    pc = os.path.join(model_path, "point_cloud")
    return searchForMaxIteration(pc)


def _load_image_tensor(path: str, hw: tuple[int, int], device: torch.device) -> torch.Tensor:
    img = Image.open(path).convert("L")
    if img.size != (hw[1], hw[0]):
        img = img.resize((hw[1], hw[0]), Image.BILINEAR)
    arr = np.asarray(img, dtype=np.float32) / 255.0
    t = torch.from_numpy(arr).to(device=device).unsqueeze(0).expand(3, -1, -1)
    return t.clamp(0.0, 1.0)


def _to_gray_chw(t: torch.Tensor) -> torch.Tensor:
    if t.shape[0] == 3:
        return (0.299 * t[0] + 0.587 * t[1] + 0.114 * t[2]).unsqueeze(0)
    return t[:1]


def _l1(a: torch.Tensor, b: torch.Tensor, roi: Optional[torch.Tensor] = None) -> float:
    d = (a - b).abs()
    if roi is not None and roi.any():
        m = roi.float().unsqueeze(0)
        return float((d * m).sum() / (m.sum() * d.shape[0] + 1e-8))
    return float(d.mean())


def _target_roi(cam0, cam1, hw: tuple[int, int], device: torch.device) -> torch.Tensor:
    import torch.nn.functional as F

    def _one(cam):
        sm = getattr(cam, "scattering_mask", None)
        if sm is None:
            return torch.ones(hw, device=device, dtype=torch.bool)
        if isinstance(sm, np.ndarray):
            t = torch.from_numpy(sm).to(device=device).float()
        else:
            t = sm.to(device=device).float()
        if t.shape != hw:
            t = F.interpolate(t.unsqueeze(0).unsqueeze(0), size=hw, mode="nearest").squeeze()
        return (t == 1) | (t == 2)

    return _one(cam0) | _one(cam1)


def _save_panel(
    path: Path,
    i0: torch.Tensor,
    mid: torch.Tensor,
    i1: torch.Tensor,
    blend: torch.Tensor,
    title: str,
) -> None:
    diff = (mid - blend).abs()
    panels = [_to_gray_chw(x).cpu() for x in (i0, mid, i1, blend, diff)]
    grid = torchvision.utils.make_grid(panels, nrow=5, padding=2, normalize=False)
    torchvision.utils.save_image(grid, str(path))
    with open(path.with_suffix(".txt"), "w", encoding="utf-8") as f:
        f.write(title + "\n")
        f.write("列: I_a0 | render_mid | I_a1 | blend | |render-blend|\n")


def evaluate_pair(
    pair: Dict,
    *,
    gaussians,
    pipe,
    background: torch.Tensor,
    ref_cam,
    train_cameras: list,
    source_path: str,
    render_mod,
    sar_params: dict,
    use_sar_mode: bool,
    azimuth_space: str,
    target_name: str,
    gt_tol_deg: float,
    out_dir: Path,
) -> Dict:
    cam0, cam1 = pair["cam0"], pair["cam1"]
    a0, a1, mid = pair["a0"], pair["a1"], pair["mid"]
    dep = camera_depression_deg(ref_cam)

    filt = render_mod.filter_train_cameras_by_nearest_depression(
        list(train_cameras), float(dep), source_path,
    )
    novel_cam = render_mod.create_novel_camera_colmap_track(
        float(dep),
        float(mid),
        ref_cam,
        sar_params,
        filt,
        use_interp=True,
        uid=800000 + int(pair["index"]),
        azimuth_pose_deg=float(mid),
        azimuth_space=azimuth_space,
        source_path=source_path,
    )

    use_sar_render = use_sar_mode and getattr(novel_cam, "use_sar_rendering", False)
    with torch.inference_mode():
        pkg = render(
            novel_cam, gaussians, pipe, background,
            use_trained_exp=False,
            separate_sh=SPARSE_ADAM_AVAILABLE,
            sar_mode=use_sar_render,
        )
    pred = pkg["render"].clamp(0.0, 1.0)

    i0 = cam0.original_image.cuda().clamp(0.0, 1.0)
    i1 = cam1.original_image.cuda().clamp(0.0, 1.0)
    if pred.shape != i0.shape:
        import torch.nn.functional as F
        pred = F.interpolate(
            pred.unsqueeze(0), size=i0.shape[1:], mode="bilinear", align_corners=False,
        ).squeeze(0)
    blend = (0.5 * i0 + 0.5 * i1).clamp(0.0, 1.0)
    hw = (i0.shape[1], i0.shape[2])
    roi = _target_roi(cam0, cam1, hw, pred.device)

    l1_a0 = _l1(pred, i0, roi)
    l1_a1 = _l1(pred, i1, roi)
    l1_blend = _l1(pred, blend, roi)
    l1_nb_mean = 0.5 * (l1_a0 + l1_a1)
    anti_blend_ratio = l1_blend / (l1_nb_mean + 1e-8)
    anti_blend_delta = l1_blend - l1_nb_mean

    rec: Dict = {
        "a0": a0,
        "a1": a1,
        "mid": mid,
        "span_deg": pair["span_deg"],
        "name0": pair["name0"],
        "name1": pair["name1"],
        "l1_to_a0": l1_a0,
        "l1_to_a1": l1_a1,
        "l1_to_blend": l1_blend,
        "l1_neighbor_mean": l1_nb_mean,
        "anti_blend_ratio": anti_blend_ratio,
        "anti_blend_delta": anti_blend_delta,
        "psnr_gt": None,
        "gt_source": None,
    }

    gt_cam = find_camera_near_azimuth(train_cameras, mid, tolerance_deg=gt_tol_deg)
    gt_t = None
    if gt_cam is not None and gt_cam is not cam0 and gt_cam is not cam1:
        gt_t = gt_cam.original_image.cuda().clamp(0.0, 1.0)
        rec["gt_source"] = f"camera:{getattr(gt_cam, 'image_name', '')}"
    else:
        gt_path = find_gt_image_path(
            source_path, target_name, int(round(dep)), int(round(mid)) % 360,
        )
        if gt_path:
            gt_t = _load_image_tensor(gt_path, hw, pred.device)
            rec["gt_source"] = gt_path

    if gt_t is not None:
        if gt_t.shape != pred.shape:
            import torch.nn.functional as F
            gt_t = F.interpolate(
                gt_t.unsqueeze(0), size=pred.shape[1:], mode="bilinear", align_corners=False,
            ).squeeze(0)
        rec["psnr_gt"] = float(psnr(pred.unsqueeze(0), gt_t.unsqueeze(0)).mean().item())
        rec["l1_gt"] = _l1(pred, gt_t, roi)

    tag = f"a0_{int(round(a0)):03d}_mid_{int(round(mid)):03d}_a1_{int(round(a1)):03d}"
    panel_path = out_dir / "panels" / f"{tag}.png"
    panel_path.parent.mkdir(parents=True, exist_ok=True)
    title = (
        f"arc {a0:.0f}°–{a1:.0f}° mid={mid:.1f}° | "
        f"L1 blend={l1_blend:.4f} nb_mean={l1_nb_mean:.4f} ratio={anti_blend_ratio:.3f}"
    )
    if rec["psnr_gt"] is not None:
        title += f" | PSNR_gt={rec['psnr_gt']:.2f}"
    _save_panel(panel_path, i0, pred, i1, blend, title)

    bmp_name = mstar_output_basename(target_name, dep, mid, ext="bmp")
    torchvision.utils.save_image(_to_gray_chw(pred).cpu(), str(out_dir / "renders" / bmp_name))
    return rec


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="SAR NVS 相邻弧段中值角内插评估")
    model = ModelParams(parser, sentinel=True)
    pipeline = PipelineParams(parser)
    parser.add_argument("--iteration", type=int, default=-1)
    parser.add_argument(
        "-o", "--output_dir", default=None,
        help="评估输出（panels/、renders/、summary.json）；默认 model_path/interp_eval",
    )
    parser.add_argument("--mid_t", type=float, default=0.5, help="弧段内插系数，0.5=中点")
    parser.add_argument("--gt_tolerance_deg", type=float, default=0.51)
    parser.add_argument("--colmap_track_azimuth_space", default="filename", choices=["filename", "geom"])
    parser.add_argument("--target_name", default=None)
    parser.add_argument("--quiet", action="store_true")
    args = get_combined_args(parser)
    safe_state(args.quiet)

    if not getattr(args, "model_path", None):
        print("❌ 需要 -m / --model_path")
        return 1

    render_mod = _import_render_novel()
    model_params = model.extract(args)
    pipe_params = pipeline.extract(args)
    if not getattr(model_params, "sar_mode", False):
        print("❌ 需要 SAR 模式训练的模型")
        return 1

    iteration = _resolve_iteration(model_params.model_path, int(args.iteration))
    gaussians = GaussianModel(model_params.sh_degree)
    scene = Scene(model_params, gaussians, load_iteration=iteration, shuffle=False)
    train_cams = scene.getTrainCameras()
    if len(train_cams) < 2:
        print("❌ 训练相机不足 2")
        return 1

    ref_cam = train_cams[0]
    source_path = getattr(model_params, "source_path", "") or ""
    sar_params = dict(getattr(ref_cam, "sar_params", None) or {})
    if source_path:
        sar_params = render_mod.merge_sfm_scale_params(
            sar_params, source_path=source_path,
            mstar_nosfm=bool(getattr(model_params, "mstar_nosfm", False)),
        )

    target_name = (args.target_name or "").strip() or parse_target_name_from_dataset(
        source_path, [getattr(c, "image_name", "") for c in train_cams],
    )

    out_dir = Path(args.output_dir or os.path.join(model_params.model_path, "interp_eval"))
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "renders").mkdir(exist_ok=True)

    pairs = adjacent_midpoint_pairs(train_cams, t=float(args.mid_t))
    bg_color = [1, 1, 1] if getattr(model_params, "white_background", False) else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device="cuda")

    results: List[Dict] = []
    print(f"[sar.nvs.eval] {len(pairs)} 条弧段中值角 (t={args.mid_t})，迭代 {iteration}")
    for pair in pairs:
        rec = evaluate_pair(
            pair,
            gaussians=gaussians,
            pipe=pipe_params,
            background=background,
            ref_cam=ref_cam,
            train_cameras=train_cams,
            source_path=source_path,
            render_mod=render_mod,
            sar_params=sar_params,
            use_sar_mode=True,
            azimuth_space=str(args.colmap_track_azimuth_space),
            target_name=target_name,
            gt_tol_deg=float(args.gt_tolerance_deg),
            out_dir=out_dir,
        )
        results.append(rec)
        psnr_s = f"{rec['psnr_gt']:.2f}" if rec["psnr_gt"] is not None else "n/a"
        print(
            f"  {rec['name0']} ↔ {rec['name1']} mid={rec['mid']:.1f}° "
            f"L1_blend={rec['l1_to_blend']:.4f} ratio={rec['anti_blend_ratio']:.3f} PSNR_gt={psnr_s}"
        )

    psnr_vals = [r["psnr_gt"] for r in results if r["psnr_gt"] is not None]
    summary = {
        "model_path": model_params.model_path,
        "iteration": iteration,
        "source_path": source_path,
        "target_name": target_name,
        "mid_t": float(args.mid_t),
        "n_arcs": len(results),
        "n_with_gt": len(psnr_vals),
        "mean_psnr_gt": float(np.mean(psnr_vals)) if psnr_vals else None,
        "mean_l1_blend": float(np.mean([r["l1_to_blend"] for r in results])),
        "mean_anti_blend_ratio": float(np.mean([r["anti_blend_ratio"] for r in results])),
        "mean_anti_blend_delta": float(np.mean([r["anti_blend_delta"] for r in results])),
        "pairs": results,
    }
    summary_path = out_dir / "summary.json"
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print(f"\n✅ 评估完成: {summary_path}")
    print(
        f"   平均 anti_blend_ratio={summary['mean_anti_blend_ratio']:.3f} "
        f"(>1 表示相对邻角均值更不像 2D blend)"
    )
    if summary["mean_psnr_gt"] is not None:
        print(f"   有 GT 的弧段 {summary['n_with_gt']} 条，平均 PSNR={summary['mean_psnr_gt']:.2f} dB")
    print(f"   对比图: {out_dir / 'panels'}")
    print(f"   中值渲染 BMP: {out_dir / 'renders'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
