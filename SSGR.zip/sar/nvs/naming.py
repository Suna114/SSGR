"""MSTAR 风格输出命名：目标-俯视角-方位角.bmp"""
from __future__ import annotations

import os
import re
from typing import Optional, Sequence


def mstar_output_basename(
    target_name: str,
    depression_deg: float,
    azimuth_deg: float,
    ext: str = "bmp",
) -> str:
    """例如 BMP2-15-015.bmp（方位角三位补零）。"""
    d = int(round(float(depression_deg)))
    a = int(round(float(azimuth_deg))) % 360
    suffix = ext.lstrip(".").lower()
    return f"{target_name}-{d}-{a:03d}.{suffix}"


def parse_target_name_from_dataset(
    source_path: str,
    image_names: Optional[Sequence[str]] = None,
) -> str:
    """从 images/ 或训练相机名解析目标名（如 BMP2）。"""
    names = list(image_names or [])
    if not names and source_path:
        img_dir = os.path.join(source_path, "images")
        if os.path.isdir(img_dir):
            names = sorted(os.listdir(img_dir))
    pattern = re.compile(r"^([A-Za-z0-9]+)-(\d+)-(\d+)", re.IGNORECASE)
    for n in names:
        stem = os.path.splitext(str(n))[0]
        m = pattern.match(stem)
        if m:
            return m.group(1)
    return "TARGET"
