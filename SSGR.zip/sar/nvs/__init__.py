"""
SAR 新视角合成（NVS）：0–360° 方位内插渲染 + 全周训练预设。

输出默认 MSTAR 命名：<目标>-<俯视角>-<方位角三位>.bmp
"""

from .naming import mstar_output_basename, parse_target_name_from_dataset

__all__ = [
    "mstar_output_basename",
    "parse_target_name_from_dataset",
]
