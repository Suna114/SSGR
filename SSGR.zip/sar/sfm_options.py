"""convert.py → sfm.SFM 的 opts 构建（集中转发 config CLI）。"""

from __future__ import annotations

import os
import importlib.util
import sys
from typing import Any

from config import SFM_OPTS_ATTR_NAMES
from sar.scene_scale_closure import mstar_init_enabled
from sar.sfm_scale_params import should_skip_physical_height_for_sar_params


def _summary_has_valid_height_length_ratio(summary_path: str) -> bool:
    if not os.path.exists(summary_path):
        return False
    try:
        parser_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "scripts",
            "data_prep",
            "post_sfm",
            "summary_parser.py",
        )
        spec = importlib.util.spec_from_file_location("_ssgr_summary_parser", parser_path)
        if spec is None or spec.loader is None:
            return False
        mod = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = mod
        spec.loader.exec_module(mod)

        stats = mod.parse_target_dimension_summary(summary_path)
        if stats is None or stats.hl_ratio is None:
            return False
        return float(stats.hl_ratio) > 0
    except Exception:
        return False


def build_sfm_options(args: Any) -> "SFMOptions":
    return SFMOptions(args)


class SFMOptions:
    """sfm.py 使用的配置容器；``_full_cli_args`` 始终指向完整 argparse Namespace。"""

    def __init__(self, args: Any):
        self._full_cli_args = args

        self.data_dir = args.sfm_data_dir or args.source_path
        self.dataset = args.sfm_dataset or os.path.basename(os.path.normpath(args.source_path))
        self.ext = (args.sfm_ext or "jpg,jpeg,png,tif,tiff").split(",")
        self.out_dir = args.sfm_out_dir or os.path.join(args.source_path, "sfm_results")
        self.features = args.sfm_features or "SAR_SIFT"
        self.matcher = args.sfm_matcher or "BFMatcher"
        self.cross_check = getattr(args, "sfm_cross_check", True)
        self.calibration_mat = "sar"
        self.use_sar_geometry = True

        self._init_sar_params(args)
        self._init_sfm_pipeline_args(args)

    def _init_sar_params(self, args: Any) -> None:
        from sar_geometry import DEFAULT_SAR_PARAMS

        self.sar_params = DEFAULT_SAR_PARAMS.copy()
        skip_phys_h = should_skip_physical_height_for_sar_params(args)

        if not skip_phys_h and getattr(args, "sar_camera_height", None) is not None:
            self.sar_params["camera_height"] = float(args.sar_camera_height)

        if getattr(args, "sar_radius_scale", None) is not None:
            self.sar_params["radius_scale"] = args.sar_radius_scale

        for src, dst in (
            ("sar_platform_velocity", "Va"),
            ("sar_prf", "prf"),
            ("sar_image_size_azimuth", "Na"),
            ("sar_image_size_range", "Nr"),
        ):
            if getattr(args, src, None) is not None:
                self.sar_params[dst] = getattr(args, src)

        if getattr(args, "sar_bandwidth", None) is not None:
            self.sar_params["B"] = args.sar_bandwidth
            self.sar_params["fs"] = 1.1 * args.sar_bandwidth
            self.sar_params["kr"] = args.sar_bandwidth / self.sar_params["tao"]

        if getattr(args, "sar_scene_scale", None) is not None and not skip_phys_h:
            self.sar_params["scene_scale"] = args.sar_scene_scale

        self.sar_params["mstar_filename_depression_convention"] = (
            args.sar_mstar_filename_depression_convention
        )
        if getattr(args, "sar_camera_distribution_mode", None):
            self.sar_params["camera_distribution_mode"] = str(
                args.sar_camera_distribution_mode
            ).strip().lower()

        if getattr(args, "sfm_ba_fix_angles_height_only", False):
            self.sar_params["ba_fix_angles_optimize_height_only"] = True

        if getattr(args, "sfm_mstar_view_match_height", False):
            self.sar_params["sfm_mstar_view_match_height"] = True
            self.sar_params["ba_fix_angles_optimize_height_only"] = False

        _sar_map = {
            "sfm_max_reprojection_error": "max_reprojection_error",
            "sfm_filter_outlier_points": "filter_outlier_points",
            "sfm_enable_height_constraint": "enable_height_constraint",
            "sfm_min_z_ratio": "min_z_ratio",
            "sfm_enable_azimuth_constraint": "enable_azimuth_constraint",
            "sfm_azimuth_tolerance": "azimuth_tolerance",
            "sfm_dense_init": "dense_init",
            "sfm_dense_grid_size": "dense_grid_size",
        }
        for arg_key, sp_key in _sar_map.items():
            if hasattr(args, arg_key):
                self.sar_params[sp_key] = getattr(args, arg_key)

        self.sar_params.setdefault(
            "point_cloud_depth_factor",
            float(getattr(args, "point_cloud_depth_factor", 2.0)),
        )

        if skip_phys_h:
            # 勿留 DEFAULT 12 km；MSTAR 公式会在读图尺寸后立即写入 scene H
            self.sar_params.pop("camera_height", None)
            self.sar_params.pop("scene_scale", None)
            print(
                "MSTAR/GS preset: scene H from pixel-resolution closure; "
                f"ignoring sar_camera_height={getattr(args, 'sar_camera_height', 12000)} m"
            )

    def _init_sfm_pipeline_args(self, args: Any) -> None:
        for name in SFM_OPTS_ATTR_NAMES:
            if hasattr(args, name):
                setattr(self, name, getattr(args, name))

        self.fund_method = getattr(args, "sfm_fund_method", "FM_RANSAC")
        self.outlier_thres = getattr(args, "sfm_outlier_thres", 0.9)
        self.fund_prob = getattr(args, "sfm_fund_prob", 0.9)
        self.pnp_method = getattr(args, "sfm_pnp_method", "SOLVEPNP_DLS")
        self.pnp_prob = getattr(args, "sfm_pnp_prob", 0.99)
        self.reprojection_thres = getattr(args, "sfm_reprojection_thres", 8.0)
        self.plot_error = getattr(args, "sfm_plot_error", False)
        self.min_matches_for_triangulation = getattr(args, "sfm_min_matches_for_triangulation", 1)
        self.min_inliers_for_triangulation = getattr(args, "sfm_min_inliers_for_triangulation", 1)
        self.filter_behind_camera = getattr(args, "sfm_filter_behind_camera", True)
        self.merge_point_threshold = getattr(args, "sfm_merge_point_threshold", 1.0)
        self.dense_init = getattr(args, "sfm_dense_init", False)
        self.dense_grid_size = getattr(args, "sfm_dense_grid_size", 16)

        for name, default in (
            ("sfm_use_sorc", True),
            ("sfm_sorc_max_iterations", 100),
            ("sfm_sorc_height_only_max_iterations", 20),
            ("sfm_sorc_tolerance", 1e-6),
            ("sfm_sorc_use_5dof", True),
            ("sfm_matrix_factorization_max_iterations", 100),
            ("sfm_matrix_factorization_tolerance", 1e-6),
            ("sfm_use_sar_ba", False),
            ("sfm_sar_ba_max_iterations", 150),
            ("sfm_sar_ba_ftol", 1e-6),
            ("sfm_sar_ba_xtol", 1e-8),
            ("sfm_enable_position_constraint", True),
            ("sfm_position_tolerance_ratio", 0.3),
            ("sfm_enable_depression_constraint", True),
            ("sfm_depression_min", 10.0),
            ("sfm_depression_max", 80.0),
            ("sfm_enable_point_height_constraint", True),
            ("sfm_point_height_constraint_mode", "scale"),
            ("sfm_enable_point_width_constraint", True),
            ("sfm_sorc_use_gpu", False),
            ("sfm_sorc_gpu_batch_size", 1000),
            ("disable_cyclic_depression", False),
            ("sfm_disable_auto_height_only", False),
            ("sfm_center_scene_after_prior_replace", True),
            ("sfm_mesh_prior_skip_icp", True),
            ("sfm_mesh_prior_poisson_disk", True),
            ("sfm_mesh_prior_final_uniform_scale", 0.5),
            ("sfm_mesh_prior_sar_imaging_scale_match", False),
            ("sfm_mesh_prior_sar_imaging_ref_azimuth_deg", 90.0),
            ("sfm_mstar_optical_envelope_target_ratio", 1.02),
            ("sfm_mstar_optical_envelope_min_ratio", 1.0),
            ("sfm_mstar_optical_envelope_mesh_min", 0.85),
            ("sfm_mstar_optical_envelope_mesh_max", 2.5),
            ("sfm_mstar_optical_envelope_undersize_weight", 2.5),
        ):
            if not hasattr(self, name):
                setattr(self, name, getattr(args, name, default))

        self.visualization_dir = getattr(args, "visualization_dir", "adaptive_threshold_visualization") or "adaptive_threshold_visualization"
        self.feature_output_dir = (
            args.feature_output_dir
            if getattr(args, "feature_output_dir", None)
            else os.path.join(args.source_path, self.visualization_dir)
        )
        self.target_dimension_summary_file = os.path.join(
            args.source_path, self.visualization_dir, "target_dimension_constraints_summary.txt"
        )

        fixed_height_length_ratio = getattr(args, "sfm_point_height_length_ratio", 0.3)
        if getattr(args, "sfm_ignore_target_dimension_summary_ratios", False):
            self.sfm_point_height_length_ratio = fixed_height_length_ratio
        elif _summary_has_valid_height_length_ratio(self.target_dimension_summary_file):
            # Keep None so SORCSFM can inject the ratio parsed from the summary file.
            self.sfm_point_height_length_ratio = None
        else:
            # New/weak datasets may write a summary that has L/W but no valid H/L.
            # Keep SO-RCG usable by falling back to the normal config/CLI ratio.
            self.sfm_point_height_length_ratio = fixed_height_length_ratio

        if mstar_init_enabled(args):
            self.sfm_mstar_init_from_pixel_resolution = True
