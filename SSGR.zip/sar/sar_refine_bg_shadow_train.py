"""
SAR refine：仅训练背景/阴影、冻结目标、限制新增高斯亮度（≤目标中位散射的一半），
并抑制阴影在目标区的过度叠掩。

由 sar_refine_target_bg.apply_sar_refine_target_bg_preset 写入对应 OptimizationParams 字段；
train.py 在损失、densify、backward 后调用本模块辅助函数。
"""
from __future__ import annotations

from typing import Any, Mapping, Optional, Tuple

import torch


def refine_frozen_target_count(gaussians: Any, opt: Mapping[str, Any]) -> int:
    if not bool(getattr(opt, "sar_refine_freeze_target_gaussians", False)):
        return 0
    n0 = int(getattr(gaussians, "_refine_brightness_n0", 0) or 0)
    if n0 <= 0 and getattr(gaussians, "_refine_brightness_snapshotted", False):
        n0 = int(getattr(gaussians, "_refine_brightness_n0", 0))
    return max(0, n0)


def maybe_snapshot_refine_target_luma(
    gaussians: Any,
    opt: Mapping[str, Any],
    *,
    fresh_start: bool,
) -> None:
    """记录初始目标点数与中位 DC 亮度，供冻结索引与新增点亮度上限。"""
    if not fresh_start:
        return
    if not bool(getattr(opt, "sar_refine_target_bg", False)):
        return
    if getattr(gaussians, "_refine_brightness_snapshotted", False):
        return
    with torch.no_grad():
        n0 = int(gaussians.get_xyz.shape[0])
        if n0 < 1:
            return
        luma = gaussians.get_dc_luminosity()
        med = torch.median(luma[:n0])
        gaussians._refine_brightness_snapshotted = True  # noqa: SLF001
        gaussians._refine_brightness_n0 = n0  # noqa: SLF001
        gaussians._refine_brightness_cap_median = med.detach()  # noqa: SLF001
        frac = float(getattr(opt, "sar_refine_new_point_max_luma_fraction", 0.0) or 0.0)
        if frac > 1e-6:
            gaussians._refine_new_point_luma_limit = (med * frac).detach().clamp(min=1e-5)  # noqa: SLF001
        print(
            f"[SAR refine BG/SH] 目标快照：n0={n0}，DC 中位亮度≈{float(med):.4f}"
            + (
                f"；新增点亮度上限≈{float(gaussians._refine_new_point_luma_limit):.4f} "
                f"({frac:.2f}×中位)"
                if frac > 1e-6
                else ""
            )
        )


def new_point_luma_limit(gaussians: Any, opt: Mapping[str, Any]) -> Optional[torch.Tensor]:
    if not getattr(gaussians, "_refine_brightness_snapshotted", False):
        return None
    lim = getattr(gaussians, "_refine_new_point_luma_limit", None)
    if lim is not None:
        return lim
    frac = float(getattr(opt, "sar_refine_new_point_max_luma_fraction", 0.0) or 0.0)
    if frac <= 1e-6:
        return None
    med = getattr(gaussians, "_refine_brightness_cap_median", None)
    if med is None:
        return None
    return (med.to(med.device) * frac).clamp(min=1e-5)


def compute_new_point_luma_cap_loss(gaussians: Any, opt: Mapping[str, Any]) -> torch.Tensor:
    """惩罚 densify/种子 新增高斯 DC 亮度超过「目标中位×fraction」。"""
    w = float(getattr(opt, "sar_refine_new_point_luma_cap_weight", 0.0) or 0.0)
    if w <= 0.0:
        return gaussians.get_xyz.new_zeros(())
    n0 = refine_frozen_target_count(gaussians, opt)
    limit = new_point_luma_limit(gaussians, opt)
    if limit is None or n0 <= 0 or gaussians.get_xyz.shape[0] <= n0:
        return gaussians.get_xyz.new_zeros(())
    luma_new = gaussians.get_dc_luminosity()[n0:]
    excess = torch.relu(luma_new - limit.to(luma_new.device))
    if excess.numel() == 0:
        return gaussians.get_xyz.new_zeros(())
    return w * (excess ** 2).mean()


def clamp_new_point_luma_inplace(gaussians: Any, opt: Mapping[str, Any]) -> int:
    """densify 后将过亮新增点的 DC 颜色压到上限（防倾斜高亮成像平面）。"""
    n0 = refine_frozen_target_count(gaussians, opt)
    limit = new_point_luma_limit(gaussians, opt)
    if limit is None or n0 <= 0 or gaussians.get_xyz.shape[0] <= n0:
        return 0
    with torch.no_grad():
        from utils.sh_utils import RGB2SH, SH2RGB

        idx = slice(n0, None)
        dc = gaussians._features_dc[idx, 0, :]  # noqa: SLF001
        rgb = torch.clamp(SH2RGB(dc), 0.0, 1.0)
        lum = 0.299 * rgb[:, 0] + 0.587 * rgb[:, 1] + 0.114 * rgb[:, 2]
        lim = float(limit.item())
        over = lum > lim
        n_fix = int(over.sum().item())
        if n_fix == 0:
            return 0
        scale = (lim / (lum[over] + 1e-8)).clamp(max=1.0)
        rgb_new = rgb.clone()
        rgb_new[over] = rgb_new[over] * scale.unsqueeze(-1)
        gaussians._features_dc.data[n0:, 0, :][over] = RGB2SH(
            rgb_new[over].clamp(0.0, 1.0)
        )
        return n_fix


def mask_frozen_target_densify_accum(gaussians: Any, opt: Mapping[str, Any]) -> None:
    """冻结目标不参与 clone/split。"""
    n0 = refine_frozen_target_count(gaussians, opt)
    if n0 <= 0:
        return
    n = int(gaussians.get_xyz.shape[0])
    n0 = min(n0, n)
    if n0 <= 0:
        return
    with torch.no_grad():
        if gaussians.xyz_gradient_accum.shape[0] >= n0:
            gaussians.xyz_gradient_accum[:n0] = 0.0
            gaussians.denom[:n0] = 0.0


def zero_frozen_target_gradients(gaussians: Any, opt: Mapping[str, Any]) -> None:
    n0 = refine_frozen_target_count(gaussians, opt)
    if n0 <= 0:
        return
    n = int(gaussians.get_xyz.shape[0])
    n0 = min(n0, n)
    with torch.no_grad():
        for group in gaussians.optimizer.param_groups:
            p = group["params"][0]
            if p.grad is None or p.grad.shape[0] < n0:
                continue
            p.grad[:n0] = 0.0


def apply_bg_shadow_only_loss_weights(
    scattering_mask: torch.Tensor,
    opt: Mapping[str, Any],
    *,
    bg_w: float,
    sh_w: float,
) -> torch.Tensor:
    """
    仅背景(0)+阴影(3) 参与 L1；目标/边缘权重置 0。
    可选 sar_refine_bg_shadow_target_anchor_weight：极小目标锚定，防整体漂移。
    """
    loss_weight = torch.zeros_like(scattering_mask)
    loss_weight[scattering_mask == 0] = bg_w
    loss_weight[scattering_mask == 3] = sh_w
    anchor = float(getattr(opt, "sar_refine_bg_shadow_target_anchor_weight", 0.0) or 0.0)
    if anchor > 0.0:
        tgt = (scattering_mask == 1) | (scattering_mask == 2)
        loss_weight[tgt] = anchor
    active = loss_weight > 0
    if int(active.sum().item()) < 64:
        return torch.ones_like(scattering_mask)
    scale = loss_weight[active].mean()
    return loss_weight / (scale + 1e-8)


def compute_shadow_over_occlusion_loss(
    image: torch.Tensor,
    gt_image: torch.Tensor,
    scattering_mask: torch.Tensor,
    opt: Mapping[str, Any],
) -> torch.Tensor:
    """
    目标区：惩罚渲染比 GT 更暗（阴影过度叠掩目标）。
    阴影区：惩罚渲染比 GT 更亮（阴影不足）。
    """
    w_over = float(getattr(opt, "sar_refine_shadow_over_occlusion_weight", 0.0) or 0.0)
    w_under = float(getattr(opt, "sar_refine_shadow_under_occlusion_weight", 0.0) or 0.0)
    if w_over <= 0.0 and w_under <= 0.0:
        return image.new_zeros(())
    margin = float(getattr(opt, "sar_refine_shadow_occlusion_margin", 0.04) or 0.0)
    tgt = ((scattering_mask == 1) | (scattering_mask == 2)).float()
    sh = (scattering_mask == 3).float()
    diff = gt_image.detach() - image
    loss = image.new_zeros(())
    if w_over > 0.0 and tgt.sum() > 32:
        # GT 更亮 → 渲染过暗
        loss = loss + w_over * (torch.relu(diff) * tgt.unsqueeze(0)).sum() / (tgt.sum() * 3.0 + 1e-8)
    if w_under > 0.0 and sh.sum() > 32:
        # 阴影区渲染比 GT 亮 → 阴影不够
        loss = loss + w_under * (torch.relu(-diff - margin) * sh.unsqueeze(0)).sum() / (sh.sum() * 3.0 + 1e-8)
    return loss


def compute_bg_ground_plane_loss(gaussians: Any, opt: Mapping[str, Any]) -> torch.Tensor:
    """
    软约束：背景（暗）高斯应落在目标底面水平面附近，防多视角下背景纠缠成锥。
    仅当 sar_refine_bg_ground_plane_weight > 0。
    """
    from utils.sh_utils import SH2RGB

    w = float(getattr(opt, "sar_refine_bg_ground_plane_weight", 0.0) or 0.0)
    if w <= 0.0:
        return gaussians.get_xyz.new_zeros(())
    n0 = refine_frozen_target_count(gaussians, opt)
    xyz = gaussians.get_xyz
    if xyz.shape[0] <= max(n0, 1):
        return xyz.new_zeros(())
    g_axis = str(getattr(opt, "sar_refine_seed_ground_axis", "z") or "z").lower().strip()
    ax = {"x": 0, "y": 1, "z": 2}.get(g_axis, 2)
    q = float(getattr(opt, "sar_refine_seed_ground_bottom_quantile", 0.12) or 0.12)
    q = min(0.45, max(0.01, q))
    with torch.no_grad():
        tgt = xyz[:n0] if n0 > 0 else xyz
        plane_z = torch.quantile(tgt[:, ax].detach(), q)
    idx = slice(n0, None) if n0 > 0 else slice(None)
    f_dc = gaussians._features_dc[idx, 0, :]  # noqa: SLF001
    rgb = SH2RGB(f_dc)
    lum = (0.299 * rgb[:, 0] + 0.587 * rgb[:, 1] + 0.114 * rgb[:, 2]).clamp(0.0, 1.0)
    lum_thr = float(getattr(opt, "sar_background_brightness_threshold", 0.2))
    bg_m = lum < lum_thr
    if int(bg_m.sum().item()) < 16:
        return xyz.new_zeros(())
    z_bg = xyz[idx][bg_m, ax]
    tol = float(getattr(opt, "sar_refine_bg_ground_plane_tol_frac", 0.04) or 0.04)
    if n0 > 0:
        diag = torch.norm(
            xyz[:n0].max(dim=0).values - xyz[:n0].min(dim=0).values
        ).detach()
    else:
        diag = (xyz.max() - xyz.min()).detach()
    if float(diag.item()) < 1e-8:
        diag = xyz.new_tensor(1.0)
    band = tol * diag
    return w * ((z_bg - plane_z) / (band + 1e-6)).pow(2).mean()
