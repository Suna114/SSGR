"""
训练期：在相邻训练方位之间的插值相机位姿上，用双邻域加权 L1 软监督。

不旋转训练图像；w0·L1(render,I0)+w1·L1(render,I1)，可选仅在目标 ROI (mask 1∪2)。
位姿与 render_novel_sar_views 的 colmap_track 一致。
"""

from __future__ import annotations

import random
import sys
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn.functional as F

_REPO = Path(__file__).resolve().parents[1]


def _get_camera_azimuth_deg(cam) -> Optional[float]:
    if hasattr(cam, "azimuth_angle") and cam.azimuth_angle is not None:
        return float(cam.azimuth_angle) % 360.0
    name = getattr(cam, "image_name", None) or ""
    stem = str(name).rsplit(".", 1)[0]
    import re

    m = re.search(r"([A-Za-z0-9]+)-(\d+)-(\d+)", stem)
    if m:
        return float(m.group(3)) % 360.0
    return None


def _sorted_azimuth_ring(train_cameras: list) -> List[Tuple[float, object]]:
    pairs: List[Tuple[float, object]] = []
    for c in train_cameras:
        a = _get_camera_azimuth_deg(c)
        if a is not None:
            pairs.append((a, c))
    if len(pairs) < 2:
        return []
    pairs.sort(key=lambda p: (p[0], getattr(p[1], "image_name", "")))
    return pairs


def _arc_span_deg(a0: float, a1: float) -> float:
    return float((a1 - a0) % 360.0)


def _interp_azimuth_on_arc(a0: float, a1: float, t: float) -> Tuple[float, float, float]:
    """t∈[0,1] 沿 a0→a1 短弧插值；返回 (phi, w0, w1)。"""
    span = _arc_span_deg(a0, a1)
    if span < 1e-6:
        return a0 % 360.0, 0.5, 0.5
    phi = (a0 + span * float(t)) % 360.0
    w1 = float(t)
    w0 = 1.0 - w1
    return phi, w0, w1


def _import_colmap_track_helpers():
    render_mod = _REPO / "scripts" / "rendering" / "render_novel_sar_views.py"
    if str(_REPO) not in sys.path:
        sys.path.insert(0, str(_REPO))
    import importlib.util

    spec = importlib.util.spec_from_file_location("_render_novel_sar_views", render_mod)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _target_roi_mask_tensor(cam, hw: Tuple[int, int], device: torch.device) -> torch.Tensor:
    sm = getattr(cam, "scattering_mask", None)
    if sm is None:
        return torch.ones(hw, device=device, dtype=torch.bool)
    if isinstance(sm, np.ndarray):
        t = torch.from_numpy(sm).to(device=device)
    else:
        t = sm.to(device=device).float()
    if t.shape != hw:
        t = F.interpolate(
            t.unsqueeze(0).unsqueeze(0),
            size=hw,
            mode="nearest",
        ).squeeze()
    return (t == 1) | (t == 2)


def _masked_mean_l1(pred: torch.Tensor, gt: torch.Tensor, roi: torch.Tensor) -> torch.Tensor:
    if roi.sum() < 64:
        return torch.abs(pred - gt).mean()
    m = roi.float().unsqueeze(0)
    denom = m.sum() + 1e-8
    return (torch.abs(pred - gt) * m).sum() / denom


def compute_interp_soft_supervision_loss(
    *,
    train_cameras: list,
    source_path: str,
    gaussians,
    pipe,
    background: torch.Tensor,
    opt,
    dataset,
    render_fn,
    separate_sh: bool,
    iteration: int,
) -> Tuple[torch.Tensor, dict]:
    """
    返回 (loss, info_dict)。loss 为 0 维张量，已含 opt.sar_interp_soft_weight。
    """
    ring = _sorted_azimuth_ring(train_cameras)
    if len(ring) < 2:
        return torch.zeros((), device="cuda"), {"skipped": "too_few_cameras"}

    mod = _import_colmap_track_helpers()
    ref_cam = train_cameras[0]
    dep = float(getattr(ref_cam, "depression_angle", None) or 15.0)
    if getattr(ref_cam, "sar_params", None):
        dep = float(ref_cam.sar_params.get("depression_angle", dep))

    filt = mod.filter_train_cameras_by_nearest_depression(
        list(train_cameras), dep, source_path
    )
    if len(filt) < 2:
        filt = list(train_cameras)

    sar_params = dict(getattr(ref_cam, "sar_params", None) or {})
    azimuth_space = str(getattr(opt, "sar_interp_soft_azimuth_space", "filename"))

    alphas_str = str(getattr(opt, "sar_interp_soft_t_values", "0.25,0.5,0.75"))
    t_values = [float(x.strip()) for x in alphas_str.split(",") if x.strip()]
    if not t_values:
        t_values = [0.5]
    n_samples = max(1, int(getattr(opt, "sar_interp_soft_samples_per_step", 1)))
    t_values = [random.choice(t_values) for _ in range(n_samples)]

    i_pair = random.randint(0, len(ring) - 1)
    a0, cam0 = ring[i_pair]
    a1, cam1 = ring[(i_pair + 1) % len(ring)]

    use_blend = bool(getattr(opt, "sar_interp_soft_use_blend_target", False))
    use_sar_mode = bool(
        getattr(dataset, "sar_mode", False)
        and getattr(ref_cam, "use_sar_rendering", False)
    )

    total = torch.zeros((), device="cuda")
    n_ok = 0
    notes = []

    gt0 = cam0.original_image.cuda()
    gt1 = cam1.original_image.cuda()
    hw = (gt0.shape[1], gt0.shape[2])

    for t in t_values:
        phi, w0, w1 = _interp_azimuth_on_arc(a0, a1, t)
        try:
            interp_cam = mod.create_novel_camera_colmap_track(
                dep,
                phi,
                ref_cam,
                sar_params,
                filt,
                use_interp=True,
                uid=900000 + iteration,
                azimuth_pose_deg=phi,
                azimuth_space=azimuth_space,
                source_path=source_path,
            )
        except Exception as e:
            notes.append(f"cam_fail:{e}")
            continue

        render_pkg = render_fn(
            interp_cam,
            gaussians,
            pipe,
            background,
            use_trained_exp=getattr(dataset, "train_test_exp", False),
            separate_sh=separate_sh,
            sar_mode=use_sar_mode,
        )
        pred = render_pkg["render"]
        if pred.shape != gt0.shape:
            pred = F.interpolate(
                pred.unsqueeze(0),
                size=hw,
                mode="bilinear",
                align_corners=False,
            ).squeeze(0)

        roi0 = _target_roi_mask_tensor(cam0, hw, pred.device)
        roi1 = _target_roi_mask_tensor(cam1, hw, pred.device)
        roi = roi0 | roi1

        if use_blend:
            blend = w0 * gt0 + w1 * gt1
            L = _masked_mean_l1(pred, blend, roi)
        else:
            L = w0 * _masked_mean_l1(pred, gt0, roi) + w1 * _masked_mean_l1(pred, gt1, roi)

        total = total + L
        n_ok += 1
        notes.append(f"φ={phi:.1f} t={t:.2f} w=({w0:.2f},{w1:.2f})")

    if n_ok == 0:
        return torch.zeros((), device="cuda"), {"skipped": "no_render", "notes": notes}

    total = total / n_ok
    w_global = float(getattr(opt, "sar_interp_soft_weight", 0.2))
    return total * w_global, {
        "n": n_ok,
        "a0": a0,
        "a1": a1,
        "notes": notes,
        "loss_item": float((total * w_global).detach().item()),
    }


def should_run_interp_soft(iteration: int, opt, dataset) -> bool:
    if not bool(getattr(opt, "sar_interp_soft_supervision", False)):
        return False
    if not bool(getattr(dataset, "sar_mode", False)):
        return False
    start = int(getattr(opt, "sar_interp_soft_start_iter", 500))
    if iteration < start:
        return False
    end = int(getattr(opt, "sar_interp_soft_end_iter", 0) or 0)
    if end > 0 and iteration > end:
        return False
    every = max(1, int(getattr(opt, "sar_interp_soft_every", 500)))
    return iteration % every == 0
