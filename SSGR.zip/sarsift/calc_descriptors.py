# calc_descriptors.py
from __future__ import print_function, division
import numpy as np

# 修复相对导入
try:
    from sarsift.calc_log_polar_descriptor import calc_log_polar_descriptor
except ImportError:
    # 备用导入方式
    from calc_log_polar_descriptor import calc_log_polar_descriptor
def calc_descriptors(gradient, angle, key_point_array):
    circle_bin = 8
    LOG_DESC_HIST_BINS = 8

    M = key_point_array.shape[0]
    descriptors = np.zeros((M, 128))  # 128维描述符
    locs = key_point_array

    for i in range(M):
        x = int(key_point_array[i, 0])
        y = int(key_point_array[i, 1])
        scale = key_point_array[i, 2]
        layer = int(key_point_array[i, 3])
        main_angle = key_point_array[i, 4]
        current_gradient = gradient[:, :, layer]
        current_angle = angle[:, :, layer]

        # 调用128维描述符计算函数
        descriptors[i, :] = calc_log_polar_descriptor.calc_log_polar_descriptor(
            current_gradient, current_angle, x, y, scale, main_angle, circle_bin, LOG_DESC_HIST_BINS)

    return descriptors, locs