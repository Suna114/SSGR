# sarsift/__init__.py
"""
SAR-SIFT 特征提取和匹配包
基于论文: Dellinger F, Delon J, Gousseau Y, et al. SAR-SIFT: a SIFT-like algorithm for SAR images
"""
# sarsift/__init__.py
from .build_scale import build_scale
from .find_scale_extreme import find_scale_extreme
from .calc_descriptors import calc_descriptors
from .calc_log_polar_descriptor import calc_log_polar_descriptor
from .calculate_oritation_hist import calculate_oritation_hist
from .match import deep_match, delete_duplications
from .ransac import ransac
from .display import display, display1, show_image
from .image_fusion import image_fusion, common_region
from .MI import MI
# 包版本信息
__version__ = "1.0.0"
__author__ = "Original Author (Python2.7), Adapted for Python3"
__description__ = "SAR-SIFT implementation for SAR images"

# 导出主要功能
__all__ = [
    'build_scale',
    'find_scale_extreme',
    'calc_descriptors',
    'calc_log_polar_descriptor',
    'calculate_oritation_hist',
    'deep_match',
    'delete_duplications',
    'ransac',
    'display',
    'display1',
    'show_image',
    'image_fusion',
    'common_region',
    'MI'
]