
from __future__ import print_function, division, absolute_import
import numpy as np
import math

def calc_log_polar_descriptor(gradient, angle, x, y, scale, main_angle, d, n):
    """
    计算128维SIFT描述子
    """
    # 参数设置
    desc_width = 4  # 描述子网格宽度
    desc_hist_bins = 8  # 每个网格的方向直方图bin数
    desc_mag_thr = 0.2  # 描述子归一化阈值

    M, N = gradient.shape
    radius = int(round(8 * scale))  # 描述子区域半径

    # 旋转主方向
    cos_t = math.cos(-main_angle / 180. * math.pi)
    sin_t = math.sin(-main_angle / 180. * math.pi)

    # 初始化描述子
    descriptor = np.zeros(desc_width * desc_width * desc_hist_bins)

    # 计算描述子区域边界
    x_min = max(0, x - radius)
    x_max = min(N, x + radius + 1)
    y_min = max(0, y - radius)
    y_max = min(M, y + radius + 1)

    # 遍历描述子区域
    for i in range(y_min, y_max):
        for j in range(x_min, x_max):
            # 计算相对于关键点的坐标
            dx = j - x
            dy = i - y

            # 旋转到主方向
            rot_x = dx * cos_t - dy * sin_t
            rot_y = dx * sin_t + dy * cos_t

            # 检查是否在描述子区域内
            if abs(rot_x) < radius and abs(rot_y) < radius:
                # 计算网格坐标 (0-3)
                grid_x = int((rot_x + radius) * desc_width / (2.0 * radius))
                grid_y = int((rot_y + radius) * desc_width / (2.0 * radius))

                if 0 <= grid_x < desc_width and 0 <= grid_y < desc_width:
                    # 计算梯度方向（相对主方向）
                    grad_angle = angle[i, j] - main_angle
                    if grad_angle < 0:
                        grad_angle += 360
                    if grad_angle >= 360:
                        grad_angle -= 360

                    # 计算方向bin
                    angle_bin = int(grad_angle * desc_hist_bins / 360.0)
                    if angle_bin >= desc_hist_bins:
                        angle_bin = desc_hist_bins - 1

                    # 计算权重（高斯加权）
                    gaussian_weight = math.exp(-(rot_x * rot_x + rot_y * rot_y) / (2 * (0.5 * radius) ** 2))
                    weighted_mag = gradient[i, j] * gaussian_weight

                    # 添加到描述子
                    desc_index = (grid_y * desc_width + grid_x) * desc_hist_bins + angle_bin
                    descriptor[desc_index] += weighted_mag

    # 归一化描述子
    norm = np.linalg.norm(descriptor)
    if norm > 0:
        descriptor /= norm

    # 阈值截断
    descriptor = np.minimum(descriptor, desc_mag_thr)

    # 重新归一化
    norm = np.linalg.norm(descriptor)
    if norm > 0:
        descriptor /= norm

    return descriptor