"""
兼容别名：历史目录名保留。新代码请使用 `sfm` 包。

  from sfm import SFM
"""
from sfm import Camera, Match, PostprocessArgs, SFM, SetArguments
from sfm.deps import (
    MATRIX_FACTORIZATION_AVAILABLE,
    SAR_GEOMETRY_AVAILABLE,
    SORCG_AVAILABLE,
)

__all__ = [
    "SFM",
    "Camera",
    "Match",
    "SetArguments",
    "PostprocessArgs",
    "SAR_GEOMETRY_AVAILABLE",
    "MATRIX_FACTORIZATION_AVAILABLE",
    "SORCG_AVAILABLE",
]
