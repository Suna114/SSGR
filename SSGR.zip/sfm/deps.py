# SAR SfM 可选依赖：统一探测，避免 pipeline 内重复 try/except
SAR_GEOMETRY_AVAILABLE = False
DEFAULT_SAR_PARAMS = None
compute_sar_camera_pose = None
sar_stereo_triangulation = None
compute_sar_fundamental_matrix = None
sar_pose_from_angles_and_matches = None
parse_mstar_filename = None

try:
    from sar_geometry import (
        compute_sar_camera_pose,
        normalize_mstar_filename_depression_to_incidence_from_nadir_deg,
        sar_stereo_triangulation,
        compute_sar_fundamental_matrix,
        sar_pose_from_angles_and_matches,
        DEFAULT_SAR_PARAMS,
    )
    from sar_utils import parse_mstar_filename

    SAR_GEOMETRY_AVAILABLE = True
except ImportError:
    normalize_mstar_filename_depression_to_incidence_from_nadir_deg = None  # type: ignore

    print("⚠️ 警告: sar_geometry模块未找到，将使用标准光学相机模型")

MATRIX_FACTORIZATION_AVAILABLE = False
SARMatrixFactorizationSfM = None
try:
    from sar_matrix_factorization_sfm import SARMatrixFactorizationSfM

    MATRIX_FACTORIZATION_AVAILABLE = True
except ImportError:
    print("⚠️ 警告: sar_matrix_factorization_sfm模块未找到，矩阵分解方法不可用")

SORCG_AVAILABLE = False
SORCG_SAR_SfM = None
try:
    from sar_sorc_sfm import SORCG_SAR_SfM

    SORCG_AVAILABLE = True
except ImportError as e:
    import traceback

    print(f"⚠️ 警告: sar_sorc_sfm模块未找到，SO-RCG方法不可用: {e}")
    print("   详细错误信息:")
    traceback.print_exc()
except Exception as e:
    import traceback

    print(f"⚠️ 警告: 加载sar_sorc_sfm模块时出错，SO-RCG方法不可用: {e}")
    print("   详细错误信息:")
    traceback.print_exc()
