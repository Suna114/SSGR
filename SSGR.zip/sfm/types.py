"""SAR SfM 轻量数据结构。"""


class Camera(object):
    def __init__(self, R, t, ref):
        self.R = R
        self.t = t
        self.ref = ref


class Match(object):
    def __init__(self, matches, img1pts, img2pts, img1idx, img2idx, mask):
        self.matches = matches
        self.img1pts, self.img2pts = img1pts, img2pts
        self.img1idx, self.img2idx = img1idx, img2idx
        self.mask = mask
