"""允许 `python -m sfm` 直接运行 SfM。"""
from sfm.cli import main

if __name__ == "__main__":
    main()
