"""
SAR Structure-from-Motion 官方入口。

推荐：`from sfm import SFM`
命令行：`python -m sfm`（等价于运行 `sfm.cli` 的 __main__ 块）
"""
from sfm.cli import PostprocessArgs, SetArguments
from sfm.deps import (
    MATRIX_FACTORIZATION_AVAILABLE,
    SAR_GEOMETRY_AVAILABLE,
    SORCG_AVAILABLE,
)
from sfm.pipeline import SFM
from sfm.types import Camera, Match

__all__ = [
    "SFM",
    "Camera",
    "Match",
    "SetArguments",
    "PostprocessArgs",
    "SAR_GEOMETRY_AVAILABLE",
    "MATRIX_FACTORIZATION_AVAILABLE",
    "SORCG_AVAILABLE",
]
