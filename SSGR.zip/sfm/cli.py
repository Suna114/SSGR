"""命令行参数定义与后处理（与 convert / 独立运行 sfm 模块共用）。"""
import cv2


def SetArguments(parser):
    # directory stuff
    parser.add_argument(
        "--data_dir",
        action="store",
        type=str,
        default="../data/",
        dest="data_dir",
        help="root directory containing input data (default: ../data/)",
    )
    parser.add_argument(
        "--dataset",
        action="store",
        type=str,
        default="fountain-P11",
        dest="dataset",
        help="name of dataset (default: fountain-P11)",
    )
    parser.add_argument(
        "--ext",
        action="store",
        type=str,
        default="jpg,png",
        dest="ext",
        help="comma seperated string of allowed image extensions \
                        (default: jpg,png)",
    )
    parser.add_argument(
        "--out_dir",
        action="store",
        type=str,
        default="../results/",
        dest="out_dir",
        help="root directory to store results in (default: ../results/)",
    )

    # matching parameters
    parser.add_argument(
        "--features",
        action="store",
        type=str,
        default="SURF",
        dest="features",
        help="[SIFT|SURF] Feature algorithm to use (default: SURF)",
    )
    parser.add_argument(
        "--matcher",
        action="store",
        type=str,
        default="BFMatcher",
        dest="matcher",
        help="[BFMatcher|FlannBasedMatcher] Matching algorithm to use \
                        (default: BFMatcher)",
    )
    parser.add_argument(
        "--cross_check",
        action="store",
        type=bool,
        default=True,
        dest="cross_check",
        help="[True|False] Whether to cross check feature matching or not \
                        (default: True)",
    )

    # epipolar geometry parameters（SAR图像使用SAR几何模型）
    parser.add_argument(
        "--calibration_mat",
        action="store",
        type=str,
        default="sar",
        dest="calibration_mat",
        help="SAR图像固定使用sar几何模型",
    )
    parser.add_argument(
        "--fund_method",
        action="store",
        type=str,
        default="FM_RANSAC",
        dest="fund_method",
        help="method to estimate fundamental matrix \
                        (default: FM_RANSAC)",
    )
    parser.add_argument(
        "--outlier_thres",
        action="store",
        type=float,
        default=0.9,
        dest="outlier_thres",
        help="threhold value of outlier to be used in\
                         fundamental matrix estimation (default: 0.9)",
    )
    parser.add_argument(
        "--fund_prob",
        action="store",
        type=float,
        default=0.9,
        dest="fund_prob",
        help="confidence in fundamental matrix estimation required (default: 0.9)",
    )

    # PnP parameters
    parser.add_argument(
        "--pnp_method",
        action="store",
        type=str,
        default="SOLVEPNP_DLS",
        dest="pnp_method",
        help="[SOLVEPNP_DLS|SOLVEPNP_EPNP|..] method used for\
                        PnP estimation, see OpenCV doc for more options (default: SOLVEPNP_DLS",
    )
    parser.add_argument(
        "--pnp_prob",
        action="store",
        type=float,
        default=0.99,
        dest="pnp_prob",
        help="confidence in PnP estimation required (default: 0.99)",
    )
    parser.add_argument(
        "--reprojection_thres",
        action="store",
        type=float,
        default=8.0,
        dest="reprojection_thres",
        help="reprojection threshold in PnP estimation \
                        (default: 8.)",
    )

    # misc
    parser.add_argument("--plot_error", action="store", type=bool, default=False, dest="plot_error")

    # 矩阵分解方法参数
    parser.add_argument(
        "--sfm_matrix_factorization_max_iterations",
        action="store",
        type=int,
        default=100,
        dest="sfm_matrix_factorization_max_iterations",
        help="矩阵分解方法的最大迭代次数（默认: 100）",
    )
    parser.add_argument(
        "--sfm_matrix_factorization_tolerance",
        action="store",
        type=float,
        default=1e-6,
        dest="sfm_matrix_factorization_tolerance",
        help="矩阵分解方法的收敛容差（默认: 1e-6）",
    )


def PostprocessArgs(opts):
    opts.fund_method = getattr(cv2, opts.fund_method)
    opts.ext = opts.ext.split(",")


def main():
    import argparse

    from sfm.pipeline import SFM

    parser = argparse.ArgumentParser()
    SetArguments(parser)
    opts = parser.parse_args()
    PostprocessArgs(opts)

    sfm = SFM(opts)

    print("=" * 60)
    print("使用矩阵分解方法进行SAR SfM重建")
    print("（增量式方法已被移除，现在只支持矩阵分解方法）")
    print("=" * 60)
    sfm.Run()


if __name__ == "__main__":
    main()
