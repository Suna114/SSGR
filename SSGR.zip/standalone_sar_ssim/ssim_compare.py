"""
SSIM 对比：支持可选掩膜（弱化边缘杂波/饱和区对指标的支配）。
"""

from __future__ import annotations

import numpy as np
from skimage.metrics import structural_similarity as ssim_func


def _to_gray_u01(img: np.ndarray) -> np.ndarray:
    x = np.asarray(img, dtype=np.float64)
    if x.ndim == 3:
        x = 0.299 * x[..., 0] + 0.587 * x[..., 1] + 0.114 * x[..., 2]
    mn, mx = float(np.min(x)), float(np.max(x))
    if mx <= mn:
        return np.zeros_like(x, dtype=np.float64)
    return (x - mn) / (mx - mn)


def ssim_masked(
    pred: np.ndarray,
    ref: np.ndarray,
    mask: np.ndarray | None = None,
    *,
    win_size: int = 7,
    data_range: float = 1.0,
) -> float:
    """
    计算 SSIM。

    若提供 mask：对 skimage 返回的逐像素 SSIM 图，仅在 mask 的有效邻域内取平均
    （向内收缩半窗宽，避免边界窗口含掩膜外像素），使指标更反映 ROI 内结构一致性。
    """
    g1 = _to_gray_u01(pred)
    g2 = _to_gray_u01(ref)
    if g1.shape != g2.shape:
        raise ValueError(f"形状不一致: {g1.shape} vs {g2.shape}")

    half = win_size // 2

    if mask is None:
        return float(ssim_func(g1, g2, data_range=data_range, win_size=win_size))

    m = np.asarray(mask, dtype=bool)
    if m.shape != g1.shape:
        raise ValueError(f"mask 形状应为 {g1.shape}")
    if not np.any(m):
        raise ValueError("mask 全 False")

    _, sim_map = ssim_func(
        g1, g2, data_range=data_range, win_size=win_size, full=True
    )

    inner = np.zeros_like(m, dtype=bool)
    inner[half : m.shape[0] - half, half : m.shape[1] - half] = True
    valid = m & inner
    if not np.any(valid):
        raise ValueError("mask 在收缩边界后无有效像素，请增大图像或缩小 win_size")
    return float(np.mean(sim_map[valid]))
