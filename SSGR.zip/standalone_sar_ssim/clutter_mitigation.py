"""
星载 SAR 幅度/强度图的相干斑抑制（Lee 滤波）与简单预处理。
用于在与风格迁移后的机载 SAR 做 SSIM 前削弱乘性斑噪与均匀杂波起伏带来的伪结构。
"""

from __future__ import annotations

import numpy as np
from scipy.ndimage import uniform_filter


def lee_filter_amplitude(
    image: np.ndarray,
    window: int = 7,
    enl: float | None = None,
) -> np.ndarray:
    """
    Lee 滤波（幅度图像，乘性相干斑模型）。

    Args:
        image: 2D 幅度或强度，非负 float。
        window: 局部窗口边长（奇数）。
        enl: 等效视数 L；若为 None，则用全局 Ci² 估计（粗糙默认值）。

    Returns:
        与 image 同形状的滤波结果。
    """
    if image.ndim != 2:
        raise ValueError("期望二维 SAR 幅度/强度图")
    if window % 2 == 0 or window < 3:
        raise ValueError("window 应为不小于 3 的奇数")

    x = np.asarray(image, dtype=np.float64)
    x = np.maximum(x, 1e-12)

    mean = uniform_filter(x, size=window, mode="nearest")
    mean_sq = uniform_filter(x * x, size=window, mode="nearest")
    var = np.maximum(mean_sq - mean * mean, 0.0)

    ci_sq = var / (mean * mean + 1e-18)

    if enl is not None and enl > 0:
        cu_sq = 1.0 / enl
    else:
        cu_sq = float(np.median(ci_sq[np.isfinite(ci_sq)]))
        cu_sq = max(cu_sq, 1e-6)

    w = np.zeros_like(mean)
    mask = ci_sq > cu_sq
    w[mask] = (1.0 - cu_sq / (ci_sq[mask] + 1e-18)) / (1.0 + cu_sq + 1e-18)

    out = mean + w * (x - mean)
    return np.asarray(out, dtype=np.float32)


def log_compress(image: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    """动态范围压缩（可选，便于目视或与某些风格迁移输入对齐）。"""
    x = np.maximum(np.asarray(image, dtype=np.float64), eps)
    return np.asarray(np.log10(x), dtype=np.float32)


def percentile_background_mask(
    image: np.ndarray,
    low_pct: float = 25.0,
    high_pct: float = 92.0,
) -> np.ndarray:
    """
    粗略抑制极低/极高散射区域对 SSIM 的影响：返回 [low_pct, high_pct] 分位内的像素为 True。
    不属于相干斑滤波，用于 ROI SSIM。
    """
    flat = np.asarray(image, dtype=np.float64).ravel()
    lo, hi = np.percentile(flat, [low_pct, high_pct])
    m = (image >= lo) & (image <= hi)
    return m.astype(np.bool_)
