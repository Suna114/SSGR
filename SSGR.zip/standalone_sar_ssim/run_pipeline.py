"""
示例流程：星载 SAR → Lee 滤波 → （可选）风格迁移 → 与参考机载 SAR 计算 SSIM。

用法:
  python run_pipeline.py --spaceborne path/to/sat.tif --airborne path/to/air.tif
  python run_pipeline.py --spaceborne sat.png --airborne air.png --lee-window 9 --roi-mask

依赖: numpy scipy scikit-image pillow (tifffile 可选，用于部分 GeoTIFF)
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# 允许直接 `python run_pipeline.py` 运行本目录下的模块
_ROOT = Path(__file__).resolve().parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import numpy as np
from skimage.transform import resize

from clutter_mitigation import lee_filter_amplitude, percentile_background_mask
from ssim_compare import ssim_masked
from style_transfer_stub import apply_style_transfer


def load_gray(path: Path) -> np.ndarray:
    suf = path.suffix.lower()
    if suf in {".tif", ".tiff"}:
        try:
            import tifffile

            arr = tifffile.imread(path)
        except ImportError:
            from PIL import Image

            arr = np.array(Image.open(path))
    else:
        from PIL import Image

        arr = np.array(Image.open(path))

    if arr.ndim == 3:
        arr = np.mean(arr.astype(np.float64), axis=-1)
    return np.asarray(arr, dtype=np.float32)


def align_shapes(sat: np.ndarray, air: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """将二者对齐到同一分辨率（以机载图为目标形状）。"""
    if sat.shape == air.shape:
        return sat, air
    sat_r = resize(sat, air.shape, preserve_range=True, anti_aliasing=True)
    return np.asarray(sat_r, dtype=np.float32), air


def main() -> int:
    p = argparse.ArgumentParser(description="星载 SAR 杂波抑制 + SSIM（独立小工具）")
    p.add_argument("--spaceborne", type=Path, required=True, help="星载 SAR 图像路径")
    p.add_argument("--airborne", type=Path, required=True, help="机载 SAR（风格迁移后）参考图像")
    p.add_argument("--lee-window", type=int, default=7, help="Lee 滤波窗口（奇数）")
    p.add_argument("--enl", type=float, default=None, help="等效视数 L；默认自动估计")
    p.add_argument("--roi-mask", action="store_true", help="用分位数生成 ROI，弱化极端散射区")
    p.add_argument("--low-pct", type=float, default=25.0)
    p.add_argument("--high-pct", type=float, default=92.0)
    args = p.parse_args()

    sat = load_gray(args.spaceborne)
    air = load_gray(args.airborne)
    sat, air = align_shapes(sat, air)

    sat_f = lee_filter_amplitude(sat, window=args.lee_window, enl=args.enl)
    sat_styled = apply_style_transfer(sat_f)

    mask = None
    if args.roi_mask:
        mask = percentile_background_mask(sat_f, args.low_pct, args.high_pct)
        mask &= percentile_background_mask(air, args.low_pct, args.high_pct)

    score = ssim_masked(sat_styled, air, mask=mask)
    print(f"SSIM = {score:.6f}")
    if mask is not None:
        print(f"ROI 像素占比: {100.0 * np.mean(mask):.2f}%")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
