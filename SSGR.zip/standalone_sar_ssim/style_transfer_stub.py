"""
风格迁移占位：将你的星载→机载域对齐模型接在 apply_style_transfer 即可。
"""

from __future__ import annotations

import numpy as np


def apply_style_transfer(
    image: np.ndarray,
    *,
    model_path: str | None = None,
    device: str = "cpu",
) -> np.ndarray:
    """
    默认恒等映射；替换为实现（CycleGAN、AdaIN、自定义 CNN 等）。

    Args:
        image: HW 或 HWC，float32，动态范围按你的训练约定。
        model_path: 权重路径。
        device: torch device 字符串。
    """
    del model_path, device
    return np.asarray(image, dtype=np.float32)
