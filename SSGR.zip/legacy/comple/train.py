#
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use 
# under the terms of the LICENSE.md file.
#
# For inquiries contact  george.drettakis@inria.fr
#

import os
import torch
import numpy as np
from random import randint
from utils.loss_utils import l1_loss, ssim
from gaussian_renderer import render, network_gui
import sys
from scene import Scene, GaussianModel
from utils.general_utils import safe_state, get_expon_lr_func
import uuid
from tqdm import tqdm
from utils.image_utils import psnr
from argparse import ArgumentParser, Namespace
from arguments import ModelParams, PipelineParams, OptimizationParams
try:
    from torch.utils.tensorboard import SummaryWriter
    TENSORBOARD_FOUND = True
except ImportError:
    TENSORBOARD_FOUND = False

try:
    from fused_ssim import fused_ssim
    FUSED_SSIM_AVAILABLE = True
except:
    FUSED_SSIM_AVAILABLE = False

try:
    from diff_gaussian_rasterization import SparseGaussianAdam
    SPARSE_ADAM_AVAILABLE = True
except:
    SPARSE_ADAM_AVAILABLE = False

def training(dataset, opt, pipe, testing_iterations, saving_iterations, checkpoint_iterations, checkpoint, debug_from):

    if not SPARSE_ADAM_AVAILABLE and opt.optimizer_type == "sparse_adam":
        sys.exit(f"Trying to use sparse adam but it is not installed, please install the correct rasterizer using pip install [3dgs_accel].")

    first_iter = 0
    tb_writer = prepare_output_and_logger(dataset)
    gaussians = GaussianModel(dataset.sh_degree, opt.optimizer_type)
    scene = Scene(dataset, gaussians)
    gaussians.training_setup(opt)
    if checkpoint:
        (model_params, first_iter) = torch.load(checkpoint)
        gaussians.restore(model_params, opt)

    bg_color = [1, 1, 1] if dataset.white_background else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device="cuda")
    
    # 🔧 关键修复：在训练开始时固定地面高度，确保所有约束使用一致的地面高度
    # 方法1：优先使用dataset中的background_height（如果可用）
    fixed_ground_height = None
    if hasattr(dataset, 'background_height'):
        fixed_ground_height = dataset.background_height
        print(f"🔧 使用dataset中的地面高度: {fixed_ground_height:.4f}")
    else:
        # 方法2：从初始点云计算一次地面高度（使用最低5%的点）
        with torch.no_grad():
            initial_xyz = gaussians.get_xyz
            initial_y_coords = initial_xyz[:, 1]
            y_percentile_5 = torch.quantile(initial_y_coords, 0.05)
            lowest_points_mask = initial_y_coords <= y_percentile_5
            if torch.sum(lowest_points_mask) > 0:
                lowest_y_values = initial_y_coords[lowest_points_mask]
                fixed_ground_height = torch.median(lowest_y_values).item()
            else:
                fixed_ground_height = torch.max(initial_y_coords).item()
        print(f"🔧 从初始点云计算地面高度: {fixed_ground_height:.4f} (使用最低5%点的中位数)")
    
    # 确保地面高度是固定的，不会改变
    print(f"🔧 固定地面高度: {fixed_ground_height:.4f} (训练过程中保持不变)")

    iter_start = torch.cuda.Event(enable_timing = True)
    iter_end = torch.cuda.Event(enable_timing = True)

    use_sparse_adam = opt.optimizer_type == "sparse_adam" and SPARSE_ADAM_AVAILABLE 
    depth_l1_weight = get_expon_lr_func(opt.depth_l1_weight_init, opt.depth_l1_weight_final, max_steps=opt.iterations)

    viewpoint_stack = scene.getTrainCameras().copy()
    viewpoint_indices = list(range(len(viewpoint_stack)))
    ema_loss_for_log = 0.0
    ema_Ll1depth_for_log = 0.0

    progress_bar = tqdm(range(first_iter, opt.iterations), desc="Training progress")
    first_iter += 1
    for iteration in range(first_iter, opt.iterations + 1):
        if network_gui.conn == None:
            network_gui.try_connect()
        while network_gui.conn != None:
            try:
                net_image_bytes = None
                custom_cam, do_training, pipe.convert_SHs_python, pipe.compute_cov3D_python, keep_alive, scaling_modifer = network_gui.receive()
                if custom_cam != None:
                    net_image = render(custom_cam, gaussians, pipe, background, scaling_modifier=scaling_modifer, use_trained_exp=dataset.train_test_exp, separate_sh=SPARSE_ADAM_AVAILABLE)["render"]
                    net_image_bytes = memoryview((torch.clamp(net_image, min=0, max=1.0) * 255).byte().permute(1, 2, 0).contiguous().cpu().numpy())
                network_gui.send(net_image_bytes, dataset.source_path)
                if do_training and ((iteration < int(opt.iterations)) or not keep_alive):
                    break
            except Exception as e:
                network_gui.conn = None

        iter_start.record()

        gaussians.update_learning_rate(iteration)

        # Every 1000 its we increase the levels of SH up to a maximum degree
        if iteration % 1000 == 0:
            gaussians.oneupSHdegree()

        # Pick a random Camera
        if not viewpoint_stack:
            viewpoint_stack = scene.getTrainCameras().copy()
            viewpoint_indices = list(range(len(viewpoint_stack)))
        rand_idx = randint(0, len(viewpoint_indices) - 1)
        viewpoint_cam = viewpoint_stack.pop(rand_idx)
        vind = viewpoint_indices.pop(rand_idx)

        # Render
        if (iteration - 1) == debug_from:
            pipe.debug = True

        bg = torch.rand((3), device="cuda") if opt.random_background else background

        render_pkg = render(viewpoint_cam, gaussians, pipe, bg, use_trained_exp=dataset.train_test_exp, separate_sh=SPARSE_ADAM_AVAILABLE)
        image, viewspace_point_tensor, visibility_filter, radii = render_pkg["render"], render_pkg["viewspace_points"], render_pkg["visibility_filter"], render_pkg["radii"]

        if viewpoint_cam.alpha_mask is not None:
            alpha_mask = viewpoint_cam.alpha_mask.cuda()
            image *= alpha_mask

        # Loss
        gt_image = viewpoint_cam.original_image.cuda()
        Ll1 = l1_loss(image, gt_image)
        if FUSED_SSIM_AVAILABLE:
            ssim_value = fused_ssim(image.unsqueeze(0), gt_image.unsqueeze(0))
        else:
            ssim_value = ssim(image, gt_image)

        loss = (1.0 - opt.lambda_dssim) * Ll1 + opt.lambda_dssim * (1.0 - ssim_value)

        # Depth regularization
        Ll1depth_pure = 0.0
        if depth_l1_weight(iteration) > 0 and viewpoint_cam.depth_reliable:
            invDepth = render_pkg["depth"]
            mono_invdepth = viewpoint_cam.invdepthmap.cuda()
            depth_mask = viewpoint_cam.depth_mask.cuda()

            Ll1depth_pure = torch.abs((invDepth  - mono_invdepth) * depth_mask).mean()
            Ll1depth = depth_l1_weight(iteration) * Ll1depth_pure 
            loss += Ll1depth
            Ll1depth = Ll1depth.item()
        else:
            Ll1depth = 0

        # 方案2：地面铺开正则化项（修复碗状点云问题）- 铺开策略版
        # 问题分析：
        # 1. 碗状点云：地面点被定位到不同高度，形成碗状结构
        # 2. 原因：SAR几何特性导致深度歧义，为了拟合不同视角的投影，点被移动到不同位置
        # 3. 关键洞察：碗状结构是为了拟合不同视角的渲染结果，背景点云背后的高亮点透过背景点云模拟背景中的高亮点
        # 4. 这些碗状点云离目标点云很近，直接压制高度不合理，更好的方法是将其铺开
        # 解决方案（铺开策略）：
        # - 不强制所有点在同一高度，而是鼓励水平分散
        # - 对于离目标近的点，增加水平分散度
        # - 使用距离加权的铺开策略，减少垂直约束强度
        
        ground_flatness_loss = 0.0
        ground_flatness_weight = 0.0
        
        if iteration > 0:  # 从第一次迭代开始应用
            xyz = gaussians.get_xyz
            y_coords = xyz[:, 1]
            
            # 🔧 使用固定的地面高度
            ground_height = fixed_ground_height
            
            # 地面点识别（与之前相同）
            y_percentile_10 = torch.quantile(y_coords, 0.10)
            ground_mask_low = y_coords >= y_percentile_10
            
            bright_ground_mask = torch.zeros(xyz.shape[0], dtype=torch.bool, device=xyz.device)
            try:
                features_dc = gaussians.get_features_dc
                rgb = features_dc.squeeze(1)
                brightness = 0.299 * rgb[:, 0] + 0.587 * rgb[:, 1] + 0.114 * rgb[:, 2]
                brightness_threshold = torch.quantile(brightness, 0.75)
                bright_mask = brightness >= brightness_threshold
                bright_ground_mask = bright_mask & (y_coords >= y_percentile_10)
            except:
                pass
            
            ground_mask = ground_mask_low | bright_ground_mask
            
            scene_center = torch.mean(xyz, dim=0)
            distances_to_center = torch.norm(xyz - scene_center, dim=1)
            center_threshold = torch.quantile(distances_to_center, 0.3)
            ground_mask = ground_mask & (distances_to_center > center_threshold)
            ground_mask = ground_mask & (y_coords >= ground_height - 1.0)
            
            if torch.sum(ground_mask) == 0:
                ground_mask = y_coords >= y_percentile_10
                ground_mask = ground_mask & (y_coords >= ground_height - 2.0)
            
            if torch.sum(ground_mask) > 0:
                ground_xyz = xyz[ground_mask]
                ground_y = ground_xyz[:, 1]
                ground_x = ground_xyz[:, 0]
                ground_z = ground_xyz[:, 2]
                
                # 🔧 铺开策略1：水平分散正则化（鼓励点云在水平方向铺开）
                # 计算到场景中心的距离（用于识别离目标近的点）
                ground_distances_to_center = distances_to_center[ground_mask]
                center_threshold_ground = torch.quantile(ground_distances_to_center, 0.5)  # 距离中心最近的50%
                near_target_mask = ground_distances_to_center < center_threshold_ground
                
                horizontal_spread_penalty = torch.tensor(0.0, device=ground_y.device)
                near_ground_x = None
                near_ground_z = None
                horizontal_spread_x_val = 0.0
                horizontal_spread_z_val = 0.0
                
                if torch.sum(near_target_mask) > 10:  # 至少需要10个点
                    near_ground_xyz = ground_xyz[near_target_mask]
                    near_ground_x = near_ground_xyz[:, 0]
                    near_ground_z = near_ground_xyz[:, 2]
                    
                    # 计算水平方向的分散度（标准差）
                    if near_ground_x.shape[0] > 1:
                        horizontal_spread_x = torch.std(near_ground_x)
                        horizontal_spread_z = torch.std(near_ground_z)
                        horizontal_spread_x_val = horizontal_spread_x.item()
                        horizontal_spread_z_val = horizontal_spread_z.item()
                    else:
                        horizontal_spread_x = torch.tensor(0.0, device=ground_y.device)
                        horizontal_spread_z = torch.tensor(0.0, device=ground_y.device)
                    horizontal_spread = (horizontal_spread_x + horizontal_spread_z) / 2.0
                    
                    # 鼓励水平分散：如果水平分散度太小，增加惩罚
                    # 目标水平分散度：至少是目标尺寸的1.5倍
                    target_horizontal_spread = 10.0  # 默认值
                    if hasattr(dataset, 'target_length'):
                        target_horizontal_spread = max(dataset.target_length, getattr(dataset, 'target_width', 3.0)) * 1.5
                    elif hasattr(dataset, 'target_height'):
                        target_horizontal_spread = getattr(dataset, 'target_height', 2.5) * 4.0
                    
                    # 如果水平分散度小于目标值，增加惩罚
                    horizontal_spread_penalty = torch.clamp(target_horizontal_spread - horizontal_spread, min=0.0) ** 2
                
                # 🔧 铺开策略2：垂直约束（仍然需要，但权重降低）
                # 方差正则化：使地面点适度聚集在同一高度（但权重降低）
                if ground_y.shape[0] > 1:
                    y_variance = torch.var(ground_y)
                else:
                    # 单点时，使用一个小的默认方差值，保持约束强度
                    y_variance = torch.tensor(0.01, device=ground_y.device)
                # L2正则化：明确约束到ground_height（但权重降低）
                y_mean_deviation = torch.mean((ground_y - ground_height) ** 2)
                
                # 🔧 铺开策略3：组合正则化项
                # 水平分散正则化：鼓励铺开（权重0.6）
                horizontal_term = horizontal_spread_penalty
                # 垂直约束正则化：适度约束高度（权重0.4，比之前降低）
                vertical_term = 0.6 * y_variance + 0.4 * y_mean_deviation
                
                # 组合：水平分散更重要（0.6），垂直约束次要（0.4）
                regularization_term = 0.6 * horizontal_term + 0.4 * vertical_term
                
                # 🔧 铺开策略4：自适应权重策略
                progress = iteration / opt.iterations
                # 基础权重从0.05增长到0.3（增加基础权重，确保高度约束有效）
                lambda_flatness = 0.05 * (1.0 + progress * 5.0)  # 从0.05增长到0.3
                
                # 如果水平分散度太小（点聚集），增加权重
                if horizontal_spread_penalty.item() > 1.0:
                    lambda_flatness *= 2.0  # 权重翻倍
                
                # 如果垂直方差很大，增加权重（确保高度约束有效）
                if y_variance.item() > 0.2:  # 如果方差超过0.2，说明地面很不平
                    lambda_flatness *= 2.0  # 权重翻倍（增强约束）
                elif y_variance.item() > 0.1:
                    lambda_flatness *= 1.5  # 权重增加50%
                elif y_mean_deviation.item() > 0.5:  # 如果平均偏差很大，也需要增强约束
                    lambda_flatness *= 1.3  # 权重增加30%
                
                # 计算正则化损失
                ground_flatness_loss = lambda_flatness * regularization_term
                ground_flatness_weight = lambda_flatness
                
                # 监控和日志（每100次迭代打印一次）
                if iteration % 100 == 0:
                    y_mean = torch.mean(ground_y).item()
                    if ground_y.shape[0] > 1:
                        y_std = torch.std(ground_y).item()
                    else:
                        y_std = 0.0
                    y_min = torch.min(ground_y).item()
                    y_max = torch.max(ground_y).item()
                    num_bright_points = torch.sum(bright_ground_mask).item()
                    
                    # 复用已计算的水平分散度（避免重复计算）
                    if near_ground_x is not None and near_ground_z is not None:
                        horizontal_spread_val = (horizontal_spread_x_val + horizontal_spread_z_val) / 2.0
                    else:
                        horizontal_spread_val = 0.0
                    
                    print(f"[ITER {iteration}] 🔧 地面铺开正则化（铺开策略）:")
                    print(f"  固定地面高度: {ground_height:.4f}")
                    print(f"  地面点数量: {torch.sum(ground_mask).item()} (低点: {torch.sum(ground_mask_low).item()}, 高亮点: {num_bright_points})")
                    print(f"  离目标近的点数: {torch.sum(near_target_mask).item() if torch.sum(near_target_mask) > 10 else 0}")
                    print(f"  水平分散度: {horizontal_spread_val:.4f} (X标准差: {horizontal_spread_x_val:.4f}, Z标准差: {horizontal_spread_z_val:.4f})")
                    print(f"  水平分散惩罚: {horizontal_spread_penalty.item():.6f}")
                    print(f"  平均高度: {y_mean:.4f} (目标: {ground_height:.4f}, 偏差: {abs(y_mean - ground_height):.4f})")
                    print(f"  高度标准差: {y_std:.4f}")
                    print(f"  高度范围: [{y_min:.4f}, {y_max:.4f}], 范围: {y_max - y_min:.4f}")
                    print(f"  Y坐标方差: {y_variance.item():.6f}")
                    print(f"  平均偏差平方: {y_mean_deviation.item():.6f}")
                    print(f"  正则化损失: {ground_flatness_loss.item():.6f} (水平: {0.6 * lambda_flatness * horizontal_spread_penalty.item():.6f}, 垂直: {0.4 * lambda_flatness * vertical_term.item():.6f})")
                    print(f"  权重: {lambda_flatness:.6f}")
                    
                    # TensorBoard记录（如果可用）
                    if TENSORBOARD_FOUND and tb_writer:
                        tb_writer.add_scalar('train/ground_flatness_loss', ground_flatness_loss.item(), iteration)
                        tb_writer.add_scalar('train/ground_y_variance', y_variance.item(), iteration)
                        tb_writer.add_scalar('train/ground_y_mean_deviation', y_mean_deviation.item(), iteration)
                        tb_writer.add_scalar('train/ground_y_mean', y_mean, iteration)
                        tb_writer.add_scalar('train/ground_y_std', y_std, iteration)
                        tb_writer.add_scalar('train/ground_point_count', torch.sum(ground_mask).item(), iteration)
                        tb_writer.add_scalar('train/ground_bright_point_count', num_bright_points, iteration)
                        tb_writer.add_scalar('train/ground_flatness_weight', lambda_flatness, iteration)
                        tb_writer.add_scalar('train/ground_height_dynamic', ground_height, iteration)
            else:
                # 如果没有识别到地面点，也打印警告
                if iteration % 100 == 0:
                    print(f"[ITER {iteration}] ⚠️  警告：未识别到地面点（ground_mask为空）")
        
        # 添加到总损失
        loss = loss + ground_flatness_loss
        
        # 注意：target_height_loss 已经在上面添加到 loss 中了

        loss.backward()

        iter_end.record()

        with torch.no_grad():
            # 方案1：位置约束（修复碗状点云问题）- 铺开策略版
            # 更频繁的约束（每50次迭代约束一次），但使用铺开策略而不是压制策略
            if iteration % 50 == 0 and iteration > 0:
                xyz = gaussians.get_xyz
                y_coords = xyz[:, 1]
                
                # 使用固定的地面高度
                ground_height = fixed_ground_height
                
                # 复用正则化部分已计算的scene_center和distances_to_center（如果可用）
                # 注意：这里需要重新计算，因为xyz可能在正则化后发生了变化
                scene_center = torch.mean(xyz, dim=0)
                distances_to_center = torch.norm(xyz - scene_center, dim=1)
                
                # 使用与正则化项相同的地面点识别方法
                y_percentile_10 = torch.quantile(y_coords, 0.10)
                ground_mask_low = y_coords >= y_percentile_10
                
                bright_ground_mask = torch.zeros(xyz.shape[0], dtype=torch.bool, device=xyz.device)
                try:
                    features_dc = gaussians.get_features_dc
                    rgb = features_dc.squeeze(1)
                    brightness = 0.299 * rgb[:, 0] + 0.587 * rgb[:, 1] + 0.114 * rgb[:, 2]
                    brightness_threshold = torch.quantile(brightness, 0.75)
                    bright_mask = brightness >= brightness_threshold
                    bright_ground_mask = bright_mask & (y_coords >= y_percentile_10)
                except:
                    pass
                
                ground_mask = ground_mask_low | bright_ground_mask
                
                # 排除目标点
                center_threshold = torch.quantile(distances_to_center, 0.3)
                ground_mask = ground_mask & (distances_to_center > center_threshold)
                ground_mask = ground_mask & (y_coords >= ground_height - 1.0)
                
                if torch.sum(ground_mask) > 0:
                    ground_xyz = gaussians._xyz.data[ground_mask]
                    current_y = ground_xyz[:, 1]
                    current_x = ground_xyz[:, 0]
                    current_z = ground_xyz[:, 2]
                    
                    # 🔧 铺开策略：对于离目标近的点，在水平方向铺开，而不是强制到同一高度
                    distances_to_center_ground = distances_to_center[ground_mask]
                    center_threshold_ground = torch.quantile(distances_to_center_ground, 0.5)
                    near_target_mask_ground = distances_to_center_ground < center_threshold_ground
                    
                    # 对于离目标近的点：在水平方向铺开
                    if torch.sum(near_target_mask_ground) > 10:
                        near_ground_xyz = ground_xyz[near_target_mask_ground]
                        near_ground_x = near_ground_xyz[:, 0]
                        near_ground_z = near_ground_xyz[:, 2]
                        
                        # 计算水平方向的中心
                        center_x = torch.mean(near_ground_x)
                        center_z = torch.mean(near_ground_z)
                        
                        # 计算到中心的距离
                        dist_to_center_horizontal = torch.sqrt((near_ground_x - center_x)**2 + (near_ground_z - center_z)**2)
                        mean_dist = torch.mean(dist_to_center_horizontal)
                        
                        # 如果水平分散度太小，向外推
                        target_spread = 8.0  # 目标水平分散度（米）
                        if mean_dist < target_spread and mean_dist > 1e-6:  # 避免除零和数值不稳定
                            # 计算角度
                            angles = torch.atan2(near_ground_z - center_z, near_ground_x - center_x)
                            # 向外推：增加水平距离，限制push_factor避免数值爆炸
                            push_factor = torch.clamp(target_spread / mean_dist, min=1.0, max=10.0)
                            new_x = center_x + (near_ground_x - center_x) * push_factor
                            new_z = center_z + (near_ground_z - center_z) * push_factor
                            
                            # 更新位置（只更新水平方向）
                            ground_xyz[near_target_mask_ground, 0] = new_x
                            ground_xyz[near_target_mask_ground, 2] = new_z
                    
                    # 对于所有地面点：适度约束高度（不强制）
                    target_y = torch.full_like(current_y, ground_height)
                    
                    # 计算当前偏差
                    deviation = torch.abs(current_y - target_y)
                    
                    # 🔧 改进：对于离目标近的点，高度约束更宽松
                    # 对于离目标远的点，高度约束更严格
                    move_ratio = torch.where(
                        near_target_mask_ground,
                        torch.where(deviation > 0.3, 0.5, 0.3),  # 离目标近：移动30-50%
                        torch.where(deviation > 0.2, 0.7, 0.5)   # 离目标远：移动50-70%
                    )
                    new_y = current_y + move_ratio * (target_y - current_y)
                    
                    ground_xyz[:, 1] = new_y
                    gaussians._xyz.data[ground_mask] = ground_xyz
                
                # 🔧 添加目标点高度约束：使用软约束（通过损失函数）而不是硬约束
                # 这样可以避免突然的位置跳跃，提高训练稳定性
                target_height_loss = 0.0
                if hasattr(dataset, 'target_height') and hasattr(dataset, 'background_height'):
                    target_max_height = getattr(dataset, 'target_height', 3.0)
                    ground_height = fixed_ground_height
                    
                    # 识别目标点（高亮点，通常在场景中心附近）
                    try:
                        features_dc = gaussians.get_features_dc
                        rgb = features_dc.squeeze(1)
                        brightness = 0.299 * rgb[:, 0] + 0.587 * rgb[:, 1] + 0.114 * rgb[:, 2]
                        brightness_threshold = torch.quantile(brightness, 0.90)  # 使用90%分位数识别目标点
                        target_mask = brightness >= brightness_threshold
                        
                        # 进一步过滤：目标点应该在场景中心附近
                        center_threshold_target = torch.quantile(distances_to_center, 0.5)  # 距离中心最近的50%
                        target_mask = target_mask & (distances_to_center < center_threshold_target)
                        
                        if torch.sum(target_mask) > 0:
                            target_xyz = gaussians.get_xyz[target_mask]  # 使用get_xyz而不是data，保持梯度
                            target_y = target_xyz[:, 1]
                            
                            # 软约束1：目标点高度应该在合理范围内（使用平滑的惩罚函数）
                            min_target_y = ground_height
                            max_target_y = ground_height + target_max_height
                            
                            # 使用平滑的惩罚函数：超出范围的点会有惩罚，但不会突然截断
                            # 对于低于最小值的点：使用平滑的二次惩罚
                            below_min_mask = target_y < min_target_y
                            below_min_penalty = torch.sum(torch.clamp(min_target_y - target_y, min=0.0) ** 2)
                            
                            # 对于高于最大值的点：使用平滑的二次惩罚
                            above_max_mask = target_y > max_target_y
                            above_max_penalty = torch.sum(torch.clamp(target_y - max_target_y, min=0.0) ** 2)
                            
                            # 软约束2：目标点高度方差（鼓励目标点在同一高度）
                            if target_y.shape[0] > 1:
                                target_y_variance = torch.var(target_y)
                            else:
                                target_y_variance = torch.tensor(0.0, device=target_y.device)
                            
                            # 渐进式权重：训练初期权重小，后期逐渐增大
                            progress = iteration / opt.iterations
                            target_height_weight = 0.01 * (1.0 + progress * 9.0)  # 从0.01增长到0.1
                            
                            # 如果偏差很大，增加权重
                            if below_min_penalty.item() > 1.0 or above_max_penalty.item() > 1.0:
                                target_height_weight *= 2.0
                            
                            # 计算目标点高度约束损失
                            target_height_loss = target_height_weight * (
                                0.5 * below_min_penalty + 
                                0.5 * above_max_penalty + 
                                0.2 * target_y_variance
                            )
                            
                            # 只在偏差很大时才进行硬约束（作为安全网）
                            # 这样可以避免极端情况，但不会影响正常训练
                            if iteration > opt.iterations * 0.5:  # 训练后半段才启用硬约束
                                large_deviation_mask = (target_y < ground_height - 1.0) | (target_y > ground_height + target_max_height + 1.0)
                                if torch.sum(large_deviation_mask) > 0:
                                    # 只对偏差很大的点进行硬约束，且使用平滑过渡
                                    target_xyz_hard = gaussians._xyz.data[target_mask]
                                    target_y_hard = target_xyz_hard[:, 1]
                                    
                                    # 平滑过渡：只移动50%，避免突然跳跃
                                    target_y_clamped = torch.clamp(target_y_hard, min=min_target_y, max=max_target_y)
                                    target_xyz_hard[:, 1] = target_y_hard + 0.5 * (target_y_clamped - target_y_hard)
                                    gaussians._xyz.data[target_mask] = target_xyz_hard
                    except Exception as e:
                        # 如果识别目标点失败，跳过
                        pass
                
                # 将目标点高度约束损失添加到总损失
                loss = loss + target_height_loss
                
                # 打印统计信息（每500次迭代打印一次）
                if iteration % 500 == 0 and torch.sum(ground_mask) > 0:
                    num_ground_points = torch.sum(ground_mask).item()
                    y_mean_before = current_y.mean().item()
                    y_mean_after = new_y.mean().item()
                    if new_y.shape[0] > 1:
                        y_std_after = new_y.std().item()
                    else:
                        y_std_after = 0.0
                    num_near_target = torch.sum(near_target_mask_ground).item() if torch.sum(near_target_mask_ground) > 10 else 0
                    print(f"[ITER {iteration}] 🔧 位置约束（铺开策略）:")
                    print(f"  固定地面高度: {ground_height:.4f}")
                    print(f"  约束了 {num_ground_points} 个地面点 (离目标近: {num_near_target})")
                    print(f"  约束前平均高度: {y_mean_before:.4f}")
                    print(f"  约束后平均高度: {y_mean_after:.4f} (目标: {ground_height:.4f}, 偏差: {abs(y_mean_after - ground_height):.4f})")
                    print(f"  约束后标准差: {y_std_after:.4f}")
                    if target_height_loss > 0:
                        print(f"  目标点高度约束损失: {target_height_loss.item():.6f}")
            
            # Progress bar
            ema_loss_for_log = 0.4 * loss.item() + 0.6 * ema_loss_for_log
            ema_Ll1depth_for_log = 0.4 * Ll1depth + 0.6 * ema_Ll1depth_for_log

            if iteration % 10 == 0:
                progress_bar.set_postfix({"Loss": f"{ema_loss_for_log:.{7}f}", "Depth Loss": f"{ema_Ll1depth_for_log:.{7}f}"})
                progress_bar.update(10)
            if iteration == opt.iterations:
                progress_bar.close()
                
                # 训练完成前的点云分布统计
                print("\n" + "="*70)
                print("📊 训练完成 - 点云分布统计")
                print("="*70)
                
                with torch.no_grad():
                    xyz = gaussians.get_xyz
                    y_coords = xyz[:, 1]
                    x_coords = xyz[:, 0]
                    z_coords = xyz[:, 2]
                    
                    # Y坐标统计（高度分布）
                    y_min = torch.min(y_coords).item()
                    y_max = torch.max(y_coords).item()
                    y_mean = torch.mean(y_coords).item()
                    y_std = torch.std(y_coords).item()
                    y_median = torch.median(y_coords).item()
                    y_percentile_5 = torch.quantile(y_coords, 0.05).item()
                    y_percentile_10 = torch.quantile(y_coords, 0.10).item()
                    y_percentile_25 = torch.quantile(y_coords, 0.25).item()
                    y_percentile_50 = torch.quantile(y_coords, 0.50).item()
                    y_percentile_75 = torch.quantile(y_coords, 0.75).item()
                    y_percentile_90 = torch.quantile(y_coords, 0.90).item()
                    y_percentile_95 = torch.quantile(y_coords, 0.95).item()
                    
                    # 使用固定的地面高度
                    ground_height = fixed_ground_height if fixed_ground_height is not None else torch.max(y_coords).item()
                    
                    y_percentile_10_val = torch.quantile(y_coords, 0.10).item()
                    ground_mask_low = y_coords >= y_percentile_10_val
                    
                    # 基于亮度识别高亮点
                    bright_ground_mask = torch.zeros(xyz.shape[0], dtype=torch.bool, device=xyz.device)
                    try:
                        features_dc = gaussians.get_features_dc
                        rgb = features_dc.squeeze(1)
                        brightness = 0.299 * rgb[:, 0] + 0.587 * rgb[:, 1] + 0.114 * rgb[:, 2]
                        brightness_threshold = torch.quantile(brightness, 0.75)
                        bright_mask = brightness >= brightness_threshold
                        bright_ground_mask = bright_mask & (y_coords >= y_percentile_10_val)
                    except:
                        pass
                    
                    ground_mask = ground_mask_low | bright_ground_mask
                    scene_center = torch.mean(xyz, dim=0)
                    distances_to_center = torch.norm(xyz - scene_center, dim=1)
                    center_threshold = torch.quantile(distances_to_center, 0.3)
                    ground_mask = ground_mask & (distances_to_center > center_threshold)
                    ground_mask = ground_mask & (y_coords >= ground_height - 1.0)
                    
                    num_ground_points = torch.sum(ground_mask).item()
                    num_total_points = xyz.shape[0]
                    
                    if num_ground_points > 0:
                        ground_y = y_coords[ground_mask]
                        ground_y_mean = torch.mean(ground_y).item()
                        ground_y_std = torch.std(ground_y).item()
                        ground_y_min = torch.min(ground_y).item()
                        ground_y_max = torch.max(ground_y).item()
                        ground_y_variance = torch.var(ground_y).item()
                        ground_y_range = ground_y_max - ground_y_min
                    else:
                        ground_y_mean = ground_y_std = ground_y_min = ground_y_max = ground_y_variance = ground_y_range = 0.0
                    
                    # X和Z坐标统计（水平分布）
                    x_min, x_max = torch.min(x_coords).item(), torch.max(x_coords).item()
                    z_min, z_max = torch.min(z_coords).item(), torch.max(z_coords).item()
                    x_range = x_max - x_min
                    z_range = z_max - z_min
                    y_range = y_max - y_min
                    
                    # 场景中心
                    scene_center_x = scene_center[0].item()
                    scene_center_y = scene_center[1].item()
                    scene_center_z = scene_center[2].item()
                    
                    print(f"\n📈 总体统计:")
                    print(f"  总点数: {num_total_points:,}")
                    print(f"  场景中心: ({scene_center_x:.2f}, {scene_center_y:.2f}, {scene_center_z:.2f})")
                    print(f"  空间范围: X=[{x_min:.2f}, {x_max:.2f}] ({x_range:.2f}m), "
                          f"Y=[{y_min:.2f}, {y_max:.2f}] ({y_range:.2f}m), "
                          f"Z=[{z_min:.2f}, {z_max:.2f}] ({z_range:.2f}m)")
                    
                    print(f"\n📏 Y坐标（高度）分布统计:")
                    print(f"  最小值: {y_min:.4f}")
                    print(f"  最大值: {y_max:.4f}")
                    print(f"  平均值: {y_mean:.4f}")
                    print(f"  中位数: {y_median:.4f}")
                    print(f"  标准差: {y_std:.4f}")
                    print(f"  分位数: 5%={y_percentile_5:.4f}, 10%={y_percentile_10:.4f}, "
                          f"25%={y_percentile_25:.4f}, 50%={y_percentile_50:.4f}, "
                          f"75%={y_percentile_75:.4f}, 90%={y_percentile_90:.4f}, 95%={y_percentile_95:.4f}")
                    
                    # 🔧 新增：背景点云和目标点云分布统计
                    # 使用亮度阈值分离目标点和背景点（与保存point_cloud_target_only.ply的方法一致）
                    try:
                        features_dc = gaussians.get_features_dc
                        rgb = features_dc.squeeze(1).detach().cpu().numpy()
                        # 计算亮度：Y = 0.299*R + 0.587*G + 0.114*B
                        brightness = 0.299 * rgb[:, 0] + 0.587 * rgb[:, 1] + 0.114 * rgb[:, 2]
                        # 使用90%分位数作为目标阈值（与保存point_cloud_target_only.ply一致）
                        target_percentile = 90.0
                        target_brightness_threshold = np.percentile(brightness, target_percentile)
                        target_mask = brightness >= target_brightness_threshold
                        background_mask = ~target_mask
                        
                        num_target_points = np.sum(target_mask)
                        num_background_points = np.sum(background_mask)
                        
                        # 目标点云统计
                        if num_target_points > 0:
                            target_xyz = xyz[target_mask]
                            target_y = y_coords[target_mask]
                            target_x = x_coords[target_mask]
                            target_z = z_coords[target_mask]
                            target_distances = distances_to_center[target_mask]
                            
                            target_y_min = torch.min(target_y).item()
                            target_y_max = torch.max(target_y).item()
                            target_y_mean = torch.mean(target_y).item()
                            target_y_std = torch.std(target_y).item()
                            target_y_range = target_y_max - target_y_min
                            
                            target_x_range = torch.max(target_x).item() - torch.min(target_x).item()
                            target_z_range = torch.max(target_z).item() - torch.min(target_z).item()
                            target_dist_mean = torch.mean(target_distances).item()
                            target_dist_std = torch.std(target_distances).item()
                            
                            target_brightness_mean = np.mean(brightness[target_mask])
                            target_brightness_std = np.std(brightness[target_mask])
                        else:
                            target_y_min = target_y_max = target_y_mean = target_y_std = target_y_range = 0.0
                            target_x_range = target_z_range = target_dist_mean = target_dist_std = 0.0
                            target_brightness_mean = target_brightness_std = 0.0
                        
                        # 背景点云统计
                        if num_background_points > 0:
                            background_xyz = xyz[background_mask]
                            background_y = y_coords[background_mask]
                            background_x = x_coords[background_mask]
                            background_z = z_coords[background_mask]
                            background_distances = distances_to_center[background_mask]
                            
                            background_y_min = torch.min(background_y).item()
                            background_y_max = torch.max(background_y).item()
                            background_y_mean = torch.mean(background_y).item()
                            background_y_std = torch.std(background_y).item()
                            background_y_range = background_y_max - background_y_min
                            
                            background_x_range = torch.max(background_x).item() - torch.min(background_x).item()
                            background_z_range = torch.max(background_z).item() - torch.min(background_z).item()
                            background_dist_mean = torch.mean(background_distances).item()
                            background_dist_std = torch.std(background_distances).item()
                            
                            background_brightness_mean = np.mean(brightness[background_mask])
                            background_brightness_std = np.std(brightness[background_mask])
                            
                            # 🔧 分析碗状结构：检查背景点云的高度分布
                            # 计算背景点云在不同高度区间的分布
                            background_y_percentile_10 = torch.quantile(background_y, 0.10).item()
                            background_y_percentile_25 = torch.quantile(background_y, 0.25).item()
                            background_y_percentile_50 = torch.quantile(background_y, 0.50).item()
                            background_y_percentile_75 = torch.quantile(background_y, 0.75).item()
                            background_y_percentile_90 = torch.quantile(background_y, 0.90).item()
                            
                            # 计算背景点云与目标点云的距离（用于判断是否离目标很近）
                            if num_target_points > 0:
                                target_center = torch.mean(target_xyz, dim=0)
                                background_to_target_distances = torch.norm(background_xyz - target_center, dim=1)
                                background_to_target_dist_mean = torch.mean(background_to_target_distances).item()
                                background_to_target_dist_std = torch.std(background_to_target_distances).item()
                                background_to_target_dist_min = torch.min(background_to_target_distances).item()
                            else:
                                background_to_target_dist_mean = background_to_target_dist_std = background_to_target_dist_min = 0.0
                        else:
                            background_y_min = background_y_max = background_y_mean = background_y_std = background_y_range = 0.0
                            background_x_range = background_z_range = background_dist_mean = background_dist_std = 0.0
                            background_brightness_mean = background_brightness_std = 0.0
                            background_y_percentile_10 = background_y_percentile_25 = background_y_percentile_50 = 0.0
                            background_y_percentile_75 = background_y_percentile_90 = 0.0
                            background_to_target_dist_mean = background_to_target_dist_std = background_to_target_dist_min = 0.0
                    except Exception as e:
                        print(f"  ⚠️  计算背景/目标点云统计时出错: {e}")
                        num_target_points = num_background_points = 0
                        target_y_mean = target_y_std = target_y_range = 0.0
                        background_y_mean = background_y_std = background_y_range = 0.0
                        background_to_target_dist_mean = 0.0
                    
                    print(f"\n🎯 目标点云统计（亮度阈值: {target_percentile}% = {target_brightness_threshold:.4f}）:")
                    print(f"  目标点数: {num_target_points:,} ({100*num_target_points/num_total_points:.1f}%)")
                    if num_target_points > 0:
                        print(f"  高度分布: 最小值={target_y_min:.4f}, 最大值={target_y_max:.4f}, "
                              f"平均值={target_y_mean:.4f}, 标准差={target_y_std:.4f}, 范围={target_y_range:.4f}")
                        print(f"  空间分布: X范围={target_x_range:.2f}m, Z范围={target_z_range:.2f}m")
                        print(f"  距离场景中心: 平均={target_dist_mean:.2f}m, 标准差={target_dist_std:.2f}m")
                        print(f"  亮度: 平均值={target_brightness_mean:.4f}, 标准差={target_brightness_std:.4f}")
                    
                    print(f"\n🌍 背景点云统计（亮度 < {target_brightness_threshold:.4f}）:")
                    print(f"  背景点数: {num_background_points:,} ({100*num_background_points/num_total_points:.1f}%)")
                    if num_background_points > 0:
                        print(f"  高度分布: 最小值={background_y_min:.4f}, 最大值={background_y_max:.4f}, "
                              f"平均值={background_y_mean:.4f}, 标准差={background_y_std:.4f}, 范围={background_y_range:.4f}")
                        print(f"  高度分位数: 10%={background_y_percentile_10:.4f}, 25%={background_y_percentile_25:.4f}, "
                              f"50%={background_y_percentile_50:.4f}, 75%={background_y_percentile_75:.4f}, "
                              f"90%={background_y_percentile_90:.4f}")
                        print(f"  空间分布: X范围={background_x_range:.2f}m, Z范围={background_z_range:.2f}m")
                        print(f"  距离场景中心: 平均={background_dist_mean:.2f}m, 标准差={background_dist_std:.2f}m")
                        if num_target_points > 0:
                            print(f"  距离目标中心: 平均={background_to_target_dist_mean:.2f}m, "
                                  f"标准差={background_to_target_dist_std:.2f}m, 最小={background_to_target_dist_min:.2f}m")
                        print(f"  亮度: 平均值={background_brightness_mean:.4f}, 标准差={background_brightness_std:.4f}")
                        
                        # 🔧 碗状结构分析
                        print(f"\n🥣 碗状结构分析:")
                        # 判断是否有碗状结构：背景点云高度范围大，且标准差大
                        bowl_score = 0.0
                        bowl_indicators = []
                        
                        if background_y_range > 5.0:
                            bowl_score += 1.0
                            bowl_indicators.append(f"高度范围大 ({background_y_range:.2f}m > 5m)")
                        if background_y_std > 2.0:
                            bowl_score += 1.0
                            bowl_indicators.append(f"高度标准差大 ({background_y_std:.2f}m > 2m)")
                        if num_target_points > 0 and background_to_target_dist_min < 5.0:
                            bowl_score += 1.0
                            bowl_indicators.append(f"离目标很近 (最小距离={background_to_target_dist_min:.2f}m < 5m)")
                        
                        # 检查高度分布是否呈现碗状（中间低，两边高）
                        height_mid = (background_y_min + background_y_max) / 2.0
                        lower_half_mask = background_y <= height_mid
                        upper_half_mask = background_y > height_mid
                        if torch.sum(lower_half_mask) > 0 and torch.sum(upper_half_mask) > 0:
                            lower_half_mean = torch.mean(background_y[lower_half_mask]).item()
                            upper_half_mean = torch.mean(background_y[upper_half_mask]).item()
                            # 如果下半部分平均高度接近最小值，上半部分接近最大值，可能是碗状
                            if abs(lower_half_mean - background_y_min) < 1.0 and abs(upper_half_mean - background_y_max) < 1.0:
                                bowl_score += 0.5
                                bowl_indicators.append("高度分布呈现中间低、两边高的特征")
                        
                        if bowl_score >= 2.0:
                            print(f"  ⚠️  检测到明显的碗状结构 (评分: {bowl_score:.1f}/3.5)")
                            for indicator in bowl_indicators:
                                print(f"     - {indicator}")
                            print(f"  💡 原因分析:")
                            print(f"     - 碗状结构可能是为了拟合不同视角的渲染结果")
                            print(f"     - 背景点云背后的高亮点透过背景点云模拟背景中的高亮点")
                            print(f"     - 这些碗状点云离目标点云很近，直接压制高度可能不合理")
                            print(f"  💡 建议:")
                            print(f"     - 考虑将点云铺开（spread out），而不是强制到同一高度")
                            print(f"     - 可以尝试增加水平方向的分散度，减少垂直方向的约束")
                        elif bowl_score >= 1.0:
                            print(f"  ⚠️  可能存在轻微碗状结构 (评分: {bowl_score:.1f}/3.5)")
                            for indicator in bowl_indicators:
                                print(f"     - {indicator}")
                        else:
                            print(f"  ✅ 未检测到明显的碗状结构 (评分: {bowl_score:.1f}/3.5)")
                    
                    print(f"\n🌍 地面点统计（识别方法：最低10%点 + 高亮点，排除目标点）:")
                    print(f"  识别到的地面点数: {num_ground_points:,} ({100*num_ground_points/num_total_points:.1f}%)")
                    if num_ground_points > 0:
                        print(f"  固定地面高度: {ground_height:.4f} (训练开始时确定，保持不变)")
                        print(f"  地面点平均高度: {ground_y_mean:.4f} (偏差: {abs(ground_y_mean - ground_height):.4f})")
                        print(f"  地面点高度标准差: {ground_y_std:.4f}")
                        print(f"  地面点高度范围: [{ground_y_min:.4f}, {ground_y_max:.4f}] (范围: {ground_y_range:.4f})")
                        print(f"  地面点高度方差: {ground_y_variance:.6f}")
                        
                        # 判断是否还有碗状结构
                        if ground_y_range > 2.0:  # 如果地面点高度范围超过2米，可能还有碗状结构
                            print(f"  ⚠️  警告：地面点高度范围较大 ({ground_y_range:.2f}m)，可能存在碗状结构")
                        elif ground_y_std > 0.5:
                            print(f"  ⚠️  警告：地面点高度标准差较大 ({ground_y_std:.2f}m)，地面可能不平整")
                        else:
                            print(f"  ✅ 地面点高度分布较为集中，碗状结构问题可能已改善")
                    else:
                        print(f"  ⚠️  警告：未识别到地面点，可能需要调整识别参数")
                    
                    print(f"\n💡 综合分析:")
                    if num_background_points > 0 and background_y_range > 5.0:
                        print(f"  - 背景点云高度范围较大 ({background_y_range:.2f}m)，呈现碗状分布")
                        print(f"  - 这可能是为了拟合不同视角的渲染结果")
                        print(f"  - 建议：考虑将点云铺开而不是压制高度，以改善渲染质量")
                    elif num_ground_points > 0 and ground_y_range > 2.0:
                        print(f"  - 地面点高度范围较大，建议增加正则化项权重")
                        print(f"  - 建议检查位置约束是否生效（每50次迭代约束一次）")
                    elif num_ground_points == 0:
                        print(f"  - 未识别到地面点，建议放宽地面点识别条件")
                        print(f"  - 检查 center_threshold 和 ground_height 容差设置")
                    else:
                        print(f"  - 点云分布正常，碗状结构问题可能已解决")
                    
                    print("="*70 + "\n")

            # Log and save
            training_report(tb_writer, iteration, Ll1, loss, l1_loss, iter_start.elapsed_time(iter_end), testing_iterations, scene, render, (pipe, background, 1., SPARSE_ADAM_AVAILABLE, None, dataset.train_test_exp), dataset.train_test_exp)
            if (iteration in saving_iterations):
                print("\n[ITER {}] Saving Gaussians".format(iteration))
                scene.save(iteration)

            # Densification
            if iteration < opt.densify_until_iter:
                # Keep track of max radii in image-space for pruning
                gaussians.max_radii2D[visibility_filter] = torch.max(gaussians.max_radii2D[visibility_filter], radii[visibility_filter])
                gaussians.add_densification_stats(viewspace_point_tensor, visibility_filter)

                if iteration > opt.densify_from_iter and iteration % opt.densification_interval == 0:
                    size_threshold = 20 if iteration > opt.opacity_reset_interval else None
                    gaussians.densify_and_prune(opt.densify_grad_threshold, 0.005, scene.cameras_extent, size_threshold, radii)
                
                if iteration % opt.opacity_reset_interval == 0 or (dataset.white_background and iteration == opt.densify_from_iter):
                    gaussians.reset_opacity()

            # Optimizer step
            if iteration < opt.iterations:
                gaussians.exposure_optimizer.step()
                gaussians.exposure_optimizer.zero_grad(set_to_none = True)
                if use_sparse_adam:
                    visible = radii > 0
                    gaussians.optimizer.step(visible, radii.shape[0])
                    gaussians.optimizer.zero_grad(set_to_none = True)
                else:
                    gaussians.optimizer.step()
                    gaussians.optimizer.zero_grad(set_to_none = True)

            if (iteration in checkpoint_iterations):
                print("\n[ITER {}] Saving Checkpoint".format(iteration))
                torch.save((gaussians.capture(), iteration), scene.model_path + "/chkpnt" + str(iteration) + ".pth")

def prepare_output_and_logger(args):    
    if not args.model_path:
        if os.getenv('OAR_JOB_ID'):
            unique_str=os.getenv('OAR_JOB_ID')
        else:
            unique_str = str(uuid.uuid4())
        args.model_path = os.path.join("./output/", unique_str[0:10])
        
    # Set up output folder
    print("Output folder: {}".format(args.model_path))
    os.makedirs(args.model_path, exist_ok = True)
    with open(os.path.join(args.model_path, "cfg_args"), 'w') as cfg_log_f:
        cfg_log_f.write(str(Namespace(**vars(args))))

    # Create Tensorboard writer
    tb_writer = None
    if TENSORBOARD_FOUND:
        tb_writer = SummaryWriter(args.model_path)
    else:
        print("Tensorboard not available: not logging progress")
    return tb_writer

def training_report(tb_writer, iteration, Ll1, loss, l1_loss, elapsed, testing_iterations, scene : Scene, renderFunc, renderArgs, train_test_exp):
    if tb_writer:
        tb_writer.add_scalar('train_loss_patches/l1_loss', Ll1.item(), iteration)
        tb_writer.add_scalar('train_loss_patches/total_loss', loss.item(), iteration)
        tb_writer.add_scalar('iter_time', elapsed, iteration)

    # Report test and samples of training set
    if iteration in testing_iterations:
        torch.cuda.empty_cache()
        validation_configs = ({'name': 'test', 'cameras' : scene.getTestCameras()}, 
                              {'name': 'train', 'cameras' : [scene.getTrainCameras()[idx % len(scene.getTrainCameras())] for idx in range(5, 30, 5)]})

        for config in validation_configs:
            if config['cameras'] and len(config['cameras']) > 0:
                l1_test = 0.0
                psnr_test = 0.0
                for idx, viewpoint in enumerate(config['cameras']):
                    image = torch.clamp(renderFunc(viewpoint, scene.gaussians, *renderArgs)["render"], 0.0, 1.0)
                    gt_image = torch.clamp(viewpoint.original_image.to("cuda"), 0.0, 1.0)
                    if train_test_exp:
                        image = image[..., image.shape[-1] // 2:]
                        gt_image = gt_image[..., gt_image.shape[-1] // 2:]
                    if tb_writer and (idx < 5):
                        tb_writer.add_images(config['name'] + "_view_{}/render".format(viewpoint.image_name), image[None], global_step=iteration)
                        if iteration == testing_iterations[0]:
                            tb_writer.add_images(config['name'] + "_view_{}/ground_truth".format(viewpoint.image_name), gt_image[None], global_step=iteration)
                    l1_test += l1_loss(image, gt_image).mean().double()
                    psnr_test += psnr(image, gt_image).mean().double()
                psnr_test /= len(config['cameras'])
                l1_test /= len(config['cameras'])          
                print("\n[ITER {}] Evaluating {}: L1 {} PSNR {}".format(iteration, config['name'], l1_test, psnr_test))
                if tb_writer:
                    tb_writer.add_scalar(config['name'] + '/loss_viewpoint - l1_loss', l1_test, iteration)
                    tb_writer.add_scalar(config['name'] + '/loss_viewpoint - psnr', psnr_test, iteration)

        if tb_writer:
            tb_writer.add_histogram("scene/opacity_histogram", scene.gaussians.get_opacity, iteration)
            tb_writer.add_scalar('total_points', scene.gaussians.get_xyz.shape[0], iteration)
        torch.cuda.empty_cache()

if __name__ == "__main__":
    # Set up command line argument parser
    parser = ArgumentParser(description="Training script parameters")
    lp = ModelParams(parser)
    op = OptimizationParams(parser)
    pp = PipelineParams(parser)
    parser.add_argument('--ip', type=str, default="127.0.0.1")
    parser.add_argument('--port', type=int, default=6009)
    parser.add_argument('--debug_from', type=int, default=-1)
    parser.add_argument('--detect_anomaly', action='store_true', default=False)
    parser.add_argument("--test_iterations", nargs="+", type=int, default=[7_000, 30_000])
    parser.add_argument("--save_iterations", nargs="+", type=int, default=[7_000, 30_000])
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument('--disable_viewer', action='store_true', default=False)
    parser.add_argument("--checkpoint_iterations", nargs="+", type=int, default=[])
    parser.add_argument("--start_checkpoint", type=str, default = None)
    args = parser.parse_args(sys.argv[1:])
    args.save_iterations.append(args.iterations)
    
    print("Optimizing " + args.model_path)

    # Initialize system state (RNG)
    safe_state(args.quiet)

    # Start GUI server, configure and run training
    if not args.disable_viewer:
        network_gui.init(args.ip, args.port)
    torch.autograd.set_detect_anomaly(args.detect_anomaly)
    training(lp.extract(args), op.extract(args), pp.extract(args), args.test_iterations, args.save_iterations, args.checkpoint_iterations, args.start_checkpoint, args.debug_from)

    # All done
    print("\nTraining complete.")
