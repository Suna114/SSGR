# sar_sift_module.py
import numpy as np
import cv2
import math
import scipy.ndimage

# GPU加速支持 - 主要使用CuPy
try:
    import cupy as cp
    CUDA_AVAILABLE = True
    print("✅ CuPy GPU加速可用")
except ImportError:
    CUDA_AVAILABLE = False
    print("⚠️ CuPy不可用，将使用CPU计算")

try:
    import torch
    TORCH_AVAILABLE = True
    if torch.cuda.is_available():
        print("✅ PyTorch GPU加速可用")
        device = torch.device('cuda')
    else:
        print("⚠️ PyTorch可用但CUDA不可用")
        device = torch.device('cpu')
except ImportError:
    TORCH_AVAILABLE = False
    print("⚠️ PyTorch不可用")

# 不再检测OpenCV CUDA，主要使用CuPy
OPENCV_CUDA_AVAILABLE = False
print("ℹ️ 使用CuPy进行GPU加速")


def get_preferred_gpu_backend():
    """获取首选的GPU后端 - 优先使用CuPy"""
    if CUDA_AVAILABLE:
        return "cupy"
    elif TORCH_AVAILABLE and torch.cuda.is_available():
        return "pytorch"
    else:
        return "cpu"


def to_gpu(array, backend="auto"):
    """将数组传输到GPU - 使用CuPy"""
    if backend == "auto":
        backend = get_preferred_gpu_backend()
    
    if backend == "cpu" or array is None:
        return array
    
    if backend == "cupy" and CUDA_AVAILABLE:
        return cp.asarray(array)
    elif backend == "pytorch" and TORCH_AVAILABLE:
        return torch.from_numpy(array).float().to(device)
    else:
        return array


def to_cpu(array, backend="auto"):
    """将数组从GPU传输回CPU - 使用CuPy"""
    if backend == "auto":
        backend = get_preferred_gpu_backend()
    
    if array is None:
        return array
    
    if backend == "cupy" and CUDA_AVAILABLE and isinstance(array, cp.ndarray):
        return cp.asnumpy(array)
    elif backend == "pytorch" and TORCH_AVAILABLE and isinstance(array, torch.Tensor):
        return array.cpu().numpy()
    else:
        return array


def gpu_correlate(image, weights, mode='nearest', backend="auto"):
    """GPU加速的相关计算 - 使用CuPy实现"""
    if backend == "auto":
        backend = get_preferred_gpu_backend()
    
    if backend == "cpu":
        return scipy.ndimage.correlate(image, weights, mode=mode)
    
    # 对于CuPy和PyTorch后端，暂时使用CPU计算以避免复杂性问题
    print(f"⚠️ 对于 {backend} 后端，相关计算使用CPU")
    return scipy.ndimage.correlate(image, weights, mode=mode)


def gpu_gaussian_filter(image, sigma, backend="auto"):
    """GPU加速的高斯滤波 - 使用CuPy实现"""
    if backend == "auto":
        backend = get_preferred_gpu_backend()
    
    if backend == "cpu":
        return scipy.ndimage.gaussian_filter(image, sigma)
    
    # 对于CuPy和PyTorch后端，暂时使用CPU计算以避免复杂性问题
    print(f"⚠️ 对于 {backend} 后端，高斯滤波使用CPU")
    return scipy.ndimage.gaussian_filter(image, sigma)


def fspecial_gauss(size, sigma):
    """Function to mimic the 'fspecial' gaussian MATLAB function"""
    x, y = np.mgrid[-size // 2 + 1:size // 2 + 1, -size // 2 + 1:size // 2 + 1]
    g = np.float64(np.exp(-((x ** 2 + y ** 2) / (2.0 * sigma ** 2))))
    return g / g.sum()


def calculate_oritation_hist(x, y, scale, gradient, angle, n, backend="cpu"):
    """计算方向直方图 - 使用CuPy GPU加速版本"""
    M, N = gradient.shape
    radius = int(round(min(6 * scale, min(M / 2, N / 2))))
    
    # 确保使用CPU数组进行计算
    if backend != "cpu":
        gradient = to_cpu(gradient, backend)
        angle = to_cpu(angle, backend)
    
    # 原始CPU实现
    radius_x_left = x - radius
    radius_x_right = x + radius + 1
    radius_y_up = y - radius
    radius_y_down = y + radius + 1

    if radius_x_left < 0:
        radius_x_left = 0
    if radius_x_right >= N:
        radius_x_right = N
    if radius_y_up < 0:
        radius_y_up = 0
    if radius_y_down >= M:
        radius_y_down = M

    center_x = x - radius_x_left
    center_y = y - radius_y_up

    sub_gradient = gradient[radius_y_up:radius_y_down, radius_x_left:radius_x_right]
    sub_angle = angle[radius_y_up:radius_y_down, radius_x_left:radius_x_right]

    bins = np.round(sub_angle * n / 360.)

    bins[bins >= n] = bins[bins >= n] - n
    bins[bins < 0] = bins[bins < 0] + n

    tem_hist = np.zeros((n, 1))
    row, col = bins.shape

    for i in range(row):
        for j in range(col):
            if (i - center_y) ** 2 + (j - center_x) ** 2 <= radius ** 2:
                tem_hist[int(bins[i, j])] = tem_hist[int(bins[i, j])] + sub_gradient[i, j]

    # 平滑直方图
    hist = np.zeros((n, 1))
    
    if n >= 3:
        hist[0] = (tem_hist[n - 2] + tem_hist[2]) / 16. + 4 * (tem_hist[n - 1] + tem_hist[1]) / 16. + tem_hist[0] * 6 / 16.
        hist[1] = (tem_hist[n - 1] + tem_hist[3]) / 16. + 4 * (tem_hist[0] + tem_hist[2]) / 16. + tem_hist[1] * 6 / 16.
        if n > 4:
            hist[2:n - 2] = (tem_hist[0:n - 4] + tem_hist[4:n]) / 16. + 4 * (
                        tem_hist[1:n - 3] + tem_hist[3:n - 1]) / 16. + tem_hist[2:n - 2] * 6 / 16.
        hist[n - 2] = (tem_hist[n - 4] + tem_hist[0]) / 16. + 4 * (tem_hist[n - 3] + tem_hist[n - 1]) / 16. + \
                      tem_hist[n - 2] * 6 / 16.
        hist[n - 1] = (tem_hist[n - 3] + tem_hist[1]) / 16. + 4 * (tem_hist[n - 2] + tem_hist[0]) / 16. + tem_hist[n - 1] * 6 / 16.
    else:
        hist = tem_hist

    max_value = np.amax(hist)

    return hist, max_value


def find_scale_extreme(sar_harris_function, threshold, sigma, ratio, gradient, angle, backend="cpu"):
    """寻找尺度极值点 - 使用CuPy GPU加速版本"""
    M, N, num = sar_harris_function.shape
    BORDER_WIDTH = 1
    HIST_BIN = 36
    SIFT_ORI_PEAK_RATIO = 0.8
    key_number = 0
    key_point_array = np.zeros((M * N, 6))
    
    # 确保使用CPU数组
    if backend != "cpu":
        sar_harris_function = to_cpu(sar_harris_function, backend)
        gradient = to_cpu(gradient, backend)
        angle = to_cpu(angle, backend)
    
    for i in range(num):
        temp_current = sar_harris_function[:, :, i]
        gradient_current = gradient[:, :, i]
        angle_current = angle[:, :, i]
            
        for j in range(BORDER_WIDTH, M - BORDER_WIDTH, 1):
            for k in range(BORDER_WIDTH, N - BORDER_WIDTH, 1):
                temp = temp_current[j, k]
                if temp > threshold \
                        and temp > temp_current[j - 1, k - 1] and temp > temp_current[j - 1, k] and temp > temp_current[
                    j - 1, k + 1] \
                        and temp > temp_current[j, k - 1] and temp > temp_current[j, k + 1] \
                        and temp > temp_current[j + 1, k - 1] and temp > temp_current[j + 1, k] and temp > temp_current[
                    j + 1, k + 1]:
                    scale = sigma * ratio ** (i + 1)
                    hist, max_value = calculate_oritation_hist(k, j, scale, gradient_current, angle_current, HIST_BIN, backend)

                    mag_thr = max_value * SIFT_ORI_PEAK_RATIO
                    for kk in range(HIST_BIN):
                        if kk == 0:
                            k1 = HIST_BIN - 1
                        else:
                            k1 = kk - 1
                        if kk == HIST_BIN - 1:
                            k2 = 0
                        else:
                            k2 = kk + 1
                        if hist[kk] > hist[k1] and hist[kk] > hist[k2] and hist[kk] > mag_thr:
                            bins = kk + 0.5 * (hist[k1] - hist[k2]) / float((hist[k1] + hist[k2] - 2 * hist[kk]))
                            if bins < 0:
                                bins = HIST_BIN + bins
                            elif bins >= HIST_BIN:
                                bins = bins - HIST_BIN
                            key_number = key_number + 1
                            key_point_array[key_number, 0] = k
                            key_point_array[key_number, 1] = j
                            key_point_array[key_number, 2] = sigma * ratio ** (i)
                            key_point_array[key_number, 3] = i
                            key_point_array[key_number, 4] = (360 / float(HIST_BIN)) * bins
                            key_point_array[key_number, 5] = hist[kk]
    key_point_array = key_point_array[1:key_number + 1, 0:6]
    return key_point_array


def calc_log_polar_descriptor(gradient, angle, x, y, scale, main_angle, d, n, backend="cpu"):
    """计算对数极坐标描述符 - 使用CuPy GPU加速版本"""
    cos_t = math.cos(-main_angle / 180. * math.pi)
    sin_t = math.sin(-main_angle / 180. * math.pi)

    M, N = gradient.shape
    radius = int(round(min(12 * scale, min(M / 2, N / 2))))

    # 确保使用CPU数组
    if backend != "cpu":
        gradient = to_cpu(gradient, backend)
        angle = to_cpu(angle, backend)
    
    # 原始CPU实现
    radius_x_left = x - radius
    radius_x_right = x + radius + 1
    radius_y_up = y - radius
    radius_y_down = y + radius + 1

    if radius_x_left < 0:
        radius_x_left = 0
    if radius_x_right >= N:
        radius_x_right = N
    if radius_y_up < 0:
        radius_y_up = 0
    if radius_y_down >= M:
        radius_y_down = M

    center_x = x - radius_x_left
    center_y = y - radius_y_up

    sub_gradient = gradient[radius_y_up:radius_y_down, radius_x_left:radius_x_right]
    sub_angle = angle[radius_y_up:radius_y_down, radius_x_left:radius_x_right]
    sub_angle = np.round((sub_angle - main_angle) * n / 360)
    sub_angle[sub_angle < 0] = sub_angle[sub_angle < 0] + n
    sub_angle[sub_angle == 0] = n

    X = list(range(-(x - radius_x_left), radius_x_right - x, 1))
    Y = list(range(-(y - radius_y_up), radius_y_down - y, 1))
    XX, YY = np.meshgrid(X, Y)
    c_rot = XX * cos_t - YY * sin_t
    r_rot = XX * sin_t + YY * cos_t

    log_angle = np.arctan2(r_rot, c_rot)
    log_angle = log_angle / math.pi * 180.
    log_angle[log_angle < 0] = log_angle[log_angle < 0] + 360
    np.seterr(divide='ignore')
    log_amplitude = np.log2(np.sqrt(np.square(c_rot) + np.square(r_rot)))

    log_angle = np.round(log_angle * d / 360.)
    log_angle[log_angle <= 0] = log_angle[log_angle <= 0] + d
    log_angle[log_angle > d] = log_angle[log_angle > d] - d

    r1 = math.log(radius * 0.25, 2)
    r2 = math.log(radius * 0.73, 2)
    log_amplitude[log_amplitude <= r1] = 1
    log_amplitude[(log_amplitude > r1) * (log_amplitude <= r2)] = 2
    log_amplitude[log_amplitude > r2] = 3

    temp_hist_cpu = np.zeros(((2 * d + 1) * n, 1))
    row, col = log_angle.shape

    for i in range(row):
        for j in range(col):
            if (i - center_y) ** 2 + (j - center_x) ** 2 <= radius ** 2:
                angle_bin = log_angle[i, j]
                amplitude_bin = log_amplitude[i, j]
                bin_vertical = sub_angle[i, j]
                Mag = sub_gradient[i, j]

                if amplitude_bin == 1:
                    temp_hist_cpu[int(bin_vertical) - 1] = temp_hist_cpu[int(bin_vertical) - 1] + Mag
                else:
                    temp_hist_cpu[int(((amplitude_bin - 2) * d + angle_bin - 1) * n + bin_vertical + n) - 1] = temp_hist_cpu[
                                                                                                           int(((amplitude_bin - 2) * d + angle_bin - 1) * n + bin_vertical + n) - 1] + Mag

    # 归一化处理
    temp_hist_cpu = temp_hist_cpu.reshape(-1, 1)
    temp_hist_cpu = temp_hist_cpu / np.sqrt(np.dot(temp_hist_cpu.T, temp_hist_cpu))
    temp_hist_cpu[temp_hist_cpu > 0.2] = 0.2
    temp_hist_cpu = temp_hist_cpu / np.sqrt(np.dot(temp_hist_cpu.T, temp_hist_cpu))
    descriptor = temp_hist_cpu.reshape(-1)

    return descriptor


def calc_descriptors(gradient, angle, key_point_array, backend="cpu"):
    """计算描述符 - 使用CuPy GPU加速版本"""
    circle_bin = 8
    LOG_DESC_HIST_BINS = 8

    M = key_point_array.shape[0]
    d = circle_bin
    n = LOG_DESC_HIST_BINS
    descriptors = np.zeros((M, (2 * d + 1) * n))
    locs = key_point_array

    # 确保使用CPU数组
    if backend != "cpu":
        gradient = to_cpu(gradient, backend)
        angle = to_cpu(angle, backend)

    for i in range(M):
        x = int(key_point_array[i, 0])
        y = int(key_point_array[i, 1])
        scale = key_point_array[i, 2]
        layer = int(key_point_array[i, 3])
        main_angle = key_point_array[i, 4]
        
        current_gradient = gradient[:, :, layer]
        current_angle = angle[:, :, layer]
            
        descriptors[i, :] = calc_log_polar_descriptor(current_gradient, current_angle, x, y, scale, main_angle, d, n, backend)

    return descriptors, locs

def build_scale(image, sigma, Mmax, ratio, d, backend="cpu"):
    """构建尺度空间 - 修复pytorch_correlate未定义问题"""
    M, N = image.shape

    # 始终使用CPU数组以避免转换问题
    sar_harris_function = np.zeros((M, N, Mmax))
    gradient = np.zeros((M, N, Mmax))
    angle = np.zeros((M, N, Mmax))

    for i in range(Mmax):
        scale = float(sigma * ratio ** (i))
        radius = int(round(2 * scale))
        j = list(range(-radius, radius + 1, 1))
        k = list(range(-radius, radius + 1, 1))
        xarry, yarry = np.meshgrid(j, k)
        W = np.exp(-(np.abs(xarry) + np.abs(yarry)) / scale)
        W34 = np.zeros((2 * radius + 1, 2 * radius + 1), dtype=float)
        W12 = np.zeros((2 * radius + 1, 2 * radius + 1), dtype=float)
        W14 = np.zeros((2 * radius + 1, 2 * radius + 1), dtype=float)
        W23 = np.zeros((2 * radius + 1, 2 * radius + 1), dtype=float)

        W34[radius + 1:2 * radius + 1, :] = W[radius + 1:2 * radius + 1, :]
        W12[0:radius, :] = W[0:radius, :]
        W14[:, radius + 1:2 * radius + 1] = W[:, radius + 1:2 * radius + 1]
        W23[:, 0:radius] = W[:, 0:radius]

        # 使用相关计算
        M34 = scipy.ndimage.correlate(image, W34, mode='reflect')
        M12 = scipy.ndimage.correlate(image, W12, mode='reflect')
        M14 = scipy.ndimage.correlate(image, W14, mode='reflect')
        M23 = scipy.ndimage.correlate(image, W23, mode='reflect')

        # 计算梯度和角度
        Gx, Gy, gradient_layer, temp_angle, harris_response = _compute_gradients_and_harris_cpu(
            M14, M23, M34, M12, scale, d
        )
        gradient[:, :, i] = gradient_layer
        angle[:, :, i] = temp_angle
        sar_harris_function[:, :, i] = harris_response

    return sar_harris_function, gradient, angle

def _compute_gradients_and_harris_cpu(M14, M23, M34, M12, scale, d):
    """CPU版本的梯度和Harris计算"""
    Gx = np.log(M14 / M23)
    Gy = np.log(M34 / M12)

    Gx[np.where(np.imag(Gx))] = np.abs(Gx[np.where(np.imag(Gx))])
    Gy[np.where(np.imag(Gy))] = np.abs(Gy[np.where(np.imag(Gy))])
    Gx[np.where(np.isfinite(Gx) == 0)] = 0
    Gy[np.where(np.isfinite(Gy) == 0)] = 0

    gradient_layer = np.sqrt(np.square(Gx) + np.square(Gy))
    temp_angle = np.arctan2(Gy, Gx)
    temp_angle = temp_angle / math.pi * 180
    temp_angle[np.where(temp_angle < 0)] = temp_angle[np.where(temp_angle < 0)] + 360

    Csh_11 = scale ** 2 * np.square(Gx)
    Csh_12 = scale ** 2 * Gx * Gy
    Csh_22 = scale ** 2 * np.square(Gy)

    gaussian_sigma = math.sqrt(2) * scale
    width = round(3 * gaussian_sigma)
    width_windows = int(2 * width + 1)
    W_gaussian = fspecial_gauss(width_windows, gaussian_sigma)

    l = list(range(0, width_windows, 1))
    m = list(range(0, width_windows, 1))
    a, b = np.meshgrid(l, m)
    index0, index1 = np.where((np.square(a - width) - 1) + np.square(b - width - 1) > width ** 2)
    W_gaussian[index0, index1] = 0

    Csh_11 = scipy.ndimage.correlate(Csh_11, W_gaussian, mode='nearest')
    Csh_12 = scipy.ndimage.correlate(Csh_12, W_gaussian, mode='nearest')
    Csh_21 = Csh_12
    Csh_22 = scipy.ndimage.correlate(Csh_22, W_gaussian, mode='nearest')

    harris_response = Csh_11 * Csh_22 - Csh_21 * Csh_12 - d * (Csh_11 + Csh_22) ** 2
    
    return Gx, Gy, gradient_layer, temp_angle, harris_response


def sar_sift_detect_and_compute(image, sigma=2, ratio=2 ** (1 / 3.), Mmax=8, d=0.04, d_SH=0.8, backend="auto"):
    """
    SAR-SIFT特征检测和描述符计算主函数 - 使用CuPy GPU加速版本
    返回OpenCV格式的关键点和描述符
    """
    # 强制使用CPU后端以避免转换问题
    backend = "cpu"
    print(f"⚠️ 强制使用 {backend} 后端进行SAR-SIFT计算以避免CuPy转换问题")
    
    # 确保图像是浮点类型
    if image.dtype != np.float64:
        image = image.astype(np.float64)

    print(f"开始构建尺度空间，图像尺寸: {image.shape}")

    # 构建尺度空间
    sar_harris_function, gradient, angle = build_scale(image, sigma, Mmax, ratio, d, backend)

    print("尺度空间构建完成，开始检测特征点")

    # 检测特征点
    key_point_array = find_scale_extreme(sar_harris_function, d_SH, sigma, ratio, gradient, angle, backend)

    if key_point_array.shape[0] == 0:
        print("警告: 未找到任何SAR-SIFT特征点")
        return [], None

    print(f"找到 {key_point_array.shape[0]} 个SAR-SIFT特征点")

    # 计算描述符
    descriptors, locs = calc_descriptors(gradient, angle, key_point_array, backend)

    # 转换为OpenCV关键点格式
    keypoints = []
    for i in range(key_point_array.shape[0]):
        kp = cv2.KeyPoint()
        kp.pt = (float(key_point_array[i, 0]), float(key_point_array[i, 1]))  # (x, y)
        kp.size = float(key_point_array[i, 2]) * 10  # 尺度，适当放大
        kp.angle = float(key_point_array[i, 4])  # 方向
        kp.response = float(key_point_array[i, 5])  # 响应值
        keypoints.append(kp)

    return keypoints, descriptors

def sar_sift_global_match(descriptors1, descriptors2, ratio=0.8, backend="auto"):
    """
    SAR-SIFT全局特征匹配 - 使用CuPy GPU加速版本
    返回匹配对
    """
    if descriptors1 is None or descriptors2 is None or len(descriptors1) == 0 or len(descriptors2) == 0:
        return []

    # 使用CPU匹配器
    FLANN_INDEX_KDTREE = 1
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)

    flann = cv2.FlannBasedMatcher(index_params, search_params)

    # 使用knn匹配
    matches = flann.knnMatch(descriptors1, descriptors2, k=2)

    # 应用比率测试
    good_matches = []
    for match_pair in matches:
        if len(match_pair) == 2:
            m, n = match_pair
            if m.distance < ratio * n.distance:
                good_matches.append(m)

    return good_matches

def check_gpu_memory_usage():
    """检查GPU内存使用情况"""
    try:
        import cupy as cp
        mem_info = cp.cuda.runtime.memGetInfo()
        free_memory = mem_info[0] / 1024**3  # GB
        total_memory = mem_info[1] / 1024**3  # GB
        used_memory = total_memory - free_memory
        print(f"GPU内存使用: {used_memory:.2f} GB / {total_memory:.2f} GB ({used_memory/total_memory*100:.1f}%)")
        return used_memory, total_memory
    except Exception as e:
        print(f"无法获取GPU内存信息: {e}")
        return 0, 0