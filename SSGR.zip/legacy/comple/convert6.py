import os
import numpy as np
from scipy.spatial.transform import Rotation as R
from argparse import ArgumentParser
import shutil
import glob
import sqlite3
import cv2
from PIL import Image
import math  # 添加这行
import re
from sar_sift_module import sar_sift_detect_and_compute
from custom_matcher import CustomMatcher  # 导入自定义匹配器
import subprocess
import multiprocessing as mp
from multiprocessing import Pool, Manager, cpu_count

# SAR图像专用转换器
parser = ArgumentParser("SAR Image converter")
parser.add_argument("--no_gpu", action='store_true',
                    help="完全禁用GPU（包括特征提取和COLMAP）")
parser.add_argument("--use_cpu", action='store_true', help="强制使用CPU（默认自动使用GPU加速）")
parser.add_argument("--skip_matching", action='store_true')
parser.add_argument("--source_path", "-s", required=True, type=str)
parser.add_argument("--camera", default="OPENCV", type=str)
parser.add_argument("--colmap_executable", default="", type=str)
parser.add_argument("--resize", action="store_true")
parser.add_argument("--magick_executable", default="", type=str)
parser.add_argument("--sar_height", type=float, default=10.0, help="SAR图像飞行高度（米）")
parser.add_argument("--target_height", type=float, default=3.0, help="目标高度（米）")
parser.add_argument("--target_base_height", type=float, default=0.0, help="目标基础高度（米）")
parser.add_argument("--shadow_height", type=float, default=0.0, help="阴影高度（米）- 现在视为地面")
parser.add_argument("--background_height", type=float, default=0.0, help="背景高度（米）")
parser.add_argument("--target_density", type=float, default=1.5, help="目标点云密度（0-1）")
parser.add_argument("--background_density", type=float, default=0.5, help="背景点云密度（0-1）")
parser.add_argument("--feature_type", type=str, default="SAR_SIFT",
                    choices=["SAR_SIFT"],  # 只保留SAR_SIFT
                    help="特征提取器类型")
parser.add_argument("--preprocess_sar", action="store_true", help="对SAR图像进行预处理（去噪、增强）")
parser.add_argument("--speckle_filter", action="store_true", help="应用斑点噪声滤波")
parser.add_argument("--contrast_enhance", action="store_true", help="应用对比度增强")
parser.add_argument("--point_cloud_scale", type=float, default=3.0, help="点云缩放因子")
parser.add_argument("--depression_angle_scale", type=float, default=1.0, help="俯视角缩放因子")
parser.add_argument("--force_sfm", action="store_true", help="强制使用SfM，即使特征匹配失败")
parser.add_argument("--max_features", type=int, default=50000, help="最大特征点数量")
parser.add_argument("--peak_threshold", type=float, default=0.001, help="SIFT峰值阈值")
parser.add_argument("--edge_threshold", type=float, default=2.0, help="SIFT边缘阈值")
parser.add_argument("--min_scale", type=float, default=0.3, help="最小尺度")
parser.add_argument("--max_ratio", type=float, default=0.8, help="匹配最大比率")
parser.add_argument("--clean_database", action="store_true", help="清理现有数据库重新开始")
parser.add_argument("--use_spatial_matching", action="store_true", help="使用空间匹配（知道相机大致位置）")
parser.add_argument("--image_scale", type=float, default=4.0, help="图像缩放因子，用于放大低分辨率图像")
parser.add_argument("--sar_sift_sigma", type=float, default=2.0, help="SAR-SIFT初始尺度")
parser.add_argument("--sar_sift_ratio", type=float, default=2 ** (1 / 3.), help="SAR-SIFT尺度比率")
parser.add_argument("--sar_sift_layers", type=int, default=8, help="SAR-SIFT尺度层数")
parser.add_argument("--sar_sift_d", type=float, default=0.04, help="SAR-SIFT Harris参数")
parser.add_argument("--sar_sift_harris_threshold", type=float, default=0.8, help="SAR-SIFT Harris函数阈值")
# 可视化参数 - 通过反向逻辑实现默认保存
parser.add_argument("--no_save_feature_images", action="store_true",
                    help="不保存特征点可视化图像")
parser.add_argument("--no_save_match_images", action="store_true",
                    help="不保存特征点匹配可视化图像")
parser.add_argument("--max_feature_images", type=int, default=20,
                    help="最多保存的特征点图像数量，默认20")
parser.add_argument("--max_match_pairs", type=int, default=15,
                    help="最多保存的匹配图像对数，默认15")
parser.add_argument("--ransac_iterations", type=int, default=800, help="RANSAC迭代次数")
parser.add_argument("--ransac_error_threshold", type=float, default=1.0, help="RANSAC误差阈值")
parser.add_argument("--gpu_backend", type=str, default="cupy",
                    choices=["cupy", "pytorch"],
                    help="GPU加速后端，默认cupy")
parser.add_argument("--num_threads", type=int, default=-1,
                    help="特征提取线程数，-1=自动设置，0=单线程，>0=指定线程数")
parser.add_argument("--max_pairs_per_image", type=int, default=30,
                    help="每张图像最多匹配的图像数")
parser.add_argument("--max_azimuth_diff", type=int, default=60,
                    help="最大方位角差异（度）")
parser.add_argument("--use_parallel_match", action="store_true",
                    help="使用并行匹配")
parser.add_argument("--parallel_workers", type=int, default=4,
                    help="并行匹配工作线程数")
parser.add_argument("--use_processes", action="store_true",
                    help="使用进程而不是线程进行并行匹配")
args = parser.parse_args()

# 在参数解析后设置正向标志
args.save_feature_images = not args.no_save_feature_images
args.save_match_images = not args.no_save_match_images

# 创建自定义匹配器实例
custom_matcher = CustomMatcher(
    max_ratio=args.max_ratio,
    ransac_iterations=args.ransac_iterations,
    ransac_error_threshold=args.ransac_error_threshold,
    use_gpu=not args.use_cpu  # 使用统一的GPU设置
)

# 打印可视化设置
print(f"可视化设置: 保存特征点图 = {args.save_feature_images}, 保存匹配图 = {args.save_match_images}")
# 在参数解析后立即添加
if args.gpu_backend == "cupy":
    print("⚠️ 检测到CuPy后端，由于已知的内存问题，自动切换到PyTorch后端")
    args.gpu_backend = "pytorch"


def sar_aware_triangulation(keypoints, matches_dict, camera_poses, sar_height, angle_info):
    """
    SAR感知的三角化方法 - 考虑SAR几何特性
    """
    print("执行SAR感知三角化...")

    all_points_3d = []
    all_colors = []

    # 收集所有匹配信息
    triangulated_points = {}
    point_tracks = {}

    successful_triangulations = 0
    failed_triangulations = 0

    for (img1, img2), matches in matches_dict.items():
        if img1 not in camera_poses or img2 not in camera_poses:
            continue

        pose1 = camera_poses[img1]
        pose2 = camera_poses[img2]

        # 构建投影矩阵 - 修复：使用正确的旋转和平移
        R1 = R.from_quat([pose1['qx'], pose1['qy'], pose1['qz'], pose1['qw']]).as_matrix()
        t1 = np.array([pose1['tx'], pose1['ty'], pose1['tz']])
        # 正确的投影矩阵构建：P = K [R|t]
        P1 = np.hstack([R1, t1.reshape(-1, 1)])

        R2 = R.from_quat([pose2['qx'], pose2['qy'], pose2['qz'], pose2['qw']]).as_matrix()
        t2 = np.array([pose2['tx'], pose2['ty'], pose2['tz']])
        P2 = np.hstack([R2, t2.reshape(-1, 1)])

        # 获取关键点位置
        kp1 = keypoints[img1]
        kp2 = keypoints[img2]

        # 对每个匹配点进行三角化
        for match in matches:
            if len(match) < 2:
                continue

            idx1, idx2 = match[0], match[1]

            # 检查索引是否有效
            if idx1 >= len(kp1) or idx2 >= len(kp2):
                continue

            # 获取像素坐标（考虑图像缩放）
            try:
                x1, y1 = kp1[idx1][0], kp1[idx1][1]
                x2, y2 = kp2[idx2][0], kp2[idx2][1]
            except IndexError:
                continue

            # 应用SAR几何约束
            point_3d = triangulate_sar_point(x1, y1, x2, y2, P1, P2, sar_height,
                                             angle_info.get(img1, {'depression_angle': 15, 'azimuth_angle': 0}),
                                             angle_info.get(img2, {'depression_angle': 15, 'azimuth_angle': 0}))

            if point_3d is not None:
                point_id = len(all_points_3d)
                all_points_3d.append(point_3d)
                successful_triangulations += 1

                # 为点云分配颜色（基于响应值）
                try:
                    response1 = kp1[idx1][2] if len(kp1[idx1]) > 2 else 1.0
                    response2 = kp2[idx2][2] if len(kp2[idx2]) > 2 else 1.0
                    avg_response = (response1 + response2) / 2
                except:
                    avg_response = 1.0

                # 根据响应值生成颜色
                if avg_response > 0.1:
                    color = [255, 200, 150]  # 高响应 - 暖色
                elif avg_response > 0.05:
                    color = [200, 200, 200]  # 中响应 - 灰色
                else:
                    color = [150, 150, 200]  # 低响应 - 冷色

                all_colors.append(color)
            else:
                failed_triangulations += 1

    print(f"三角化统计: 成功 {successful_triangulations} 个, 失败 {failed_triangulations} 个")

    if all_points_3d:
        points_3d = np.array(all_points_3d).T
        print(f"SAR三角化成功: 生成 {len(all_points_3d)} 个3D点")
        return points_3d, all_colors
    else:
        print("SAR三角化失败: 未生成任何3D点")
        return np.zeros((3, 0)), []


def triangulate_sar_point(x1, y1, x2, y2, P1, P2, sar_height, angle_info1, angle_info2):
    """
    使用SAR几何约束进行三角化 - 改进版本
    """
    try:
        # 使用OpenCV的三角化方法
        points_4d = cv2.triangulatePoints(P1, P2, (x1, y1), (x2, y2))

        # 转换为3D坐标
        point_3d = points_4d[:3] / points_4d[3]
        point_3d = point_3d.flatten()

        # 基本的合理性检查
        if (np.any(np.isnan(point_3d)) or np.any(np.isinf(point_3d)) or
                point_3d[2] <= 0 or point_3d[2] > 1000):  # 深度应该在合理范围内
            return None

        # SAR几何约束 - 放宽条件
        depression1 = angle_info1.get('depression_angle', 15)
        depression2 = angle_info2.get('depression_angle', 15)

        # 计算预期的地面位置
        expected_ground_range1 = sar_height / np.tan(np.radians(depression1))
        expected_ground_range2 = sar_height / np.tan(np.radians(depression2))

        # 验证三角化点的合理性 - 使用更宽松的条件
        ground_range1 = np.sqrt(point_3d[0] ** 2 + point_3d[2] ** 2)
        ground_range2 = np.sqrt((point_3d[0]) ** 2 + (point_3d[2]) ** 2)  # 简化计算

        # 放宽约束条件，从0.5倍到0.8倍
        if (abs(ground_range1 - expected_ground_range1) < expected_ground_range1 * 0.8 and
                abs(ground_range2 - expected_ground_range2) < expected_ground_range2 * 0.8):
            return point_3d
        else:
            # 即使不满足SAR约束，也返回点（但标记为需要进一步优化）
            return point_3d

    except Exception as e:
        print(f"三角化错误: {e}")
        return None
def run_sar_sparse_reconstruction(db_path, image_dir, keypoints, matches_dict, angle_info):
    """
    SAR优化的稀疏重建流程 - 使用自定义三角化和BA
    """
    print("运行SAR优化的稀疏重建...")

    # 第一步：基于匹配和角度信息生成初始相机位姿
    print("生成初始相机位姿...")
    initial_poses = generate_initial_camera_poses(angle_info, args.sar_height, args.point_cloud_scale)

    # 第二步：SAR感知三角化
    print("执行SAR感知三角化...")
    points_3d, point_colors = sar_aware_triangulation(
        keypoints, matches_dict, initial_poses, args.sar_height, angle_info
    )

    # 第三步：光束法平差优化
    print("执行SAR优化的光束法平差...")
    optimized_poses, optimized_points = sar_bundle_adjustment(
        initial_poses, points_3d, matches_dict, args.sar_height, angle_info
    )

    # 第四步：保存重建结果
    print("保存重建结果...")
    save_sar_reconstruction(optimized_poses, optimized_points, point_colors,
                            os.path.join(args.source_path, "sparse", "0"))

    return len(optimized_poses) > 0


def generate_initial_camera_poses(angle_info, sar_height, scale_factor=1.0):
    """
    基于SAR几何生成初始相机位姿
    """
    camera_poses = {}

    for img_name, angles in angle_info.items():
        depression_angle = angles['depression_angle']
        azimuth_angle = angles['azimuth_angle']

        # SAR几何计算
        slant_range = sar_height / np.sin(np.radians(depression_angle))
        ground_range = np.sqrt(slant_range ** 2 - sar_height ** 2)

        # 应用缩放因子
        ground_range *= scale_factor

        # 计算相机位置（圆形轨道）
        # COLMAP坐标系约定：Y轴向下，Z轴向前，高度正值在Y轴负方向
        x = ground_range * np.cos(np.radians(azimuth_angle))
        z = ground_range * np.sin(np.radians(azimuth_angle))
        y = -sar_height  # 飞行高度在Y轴负方向（COLMAP约定）

        # 计算朝向目标的旋转
        # 相机看向原点 (0, 0, 0)
        forward = np.array([-x, -y, -z])
        forward = forward / np.linalg.norm(forward)

        # 计算右向量（COLMAP坐标系：Y轴向下）
        # COLMAP坐标系：Y轴向下，所以"上"方向是Y轴负方向
        world_up = np.array([0, -1, 0])  # COLMAP约定：高度正值在Y轴负方向
        right = np.cross(forward, world_up)
        right = right / np.linalg.norm(right)

        # 计算下向量（COLMAP坐标系：相机坐标系的Y轴是"下"方向）
        # down = cross(forward, right) 给出"下"方向（右手坐标系）
        down = np.cross(forward, right)
        down = down / np.linalg.norm(down)

        # 构建旋转矩阵（COLMAP约定：X=右，Y=下，Z=前）
        rotation_matrix = np.column_stack([right, down, -forward])

        # 转换为四元数
        rotation = R.from_matrix(rotation_matrix)
        quat = rotation.as_quat()  # [x, y, z, w]

        camera_poses[img_name] = {
            'qw': quat[3], 'qx': quat[0], 'qy': quat[1], 'qz': quat[2],
            'tx': x, 'ty': y, 'tz': z,
            'depression_angle': depression_angle,
            'azimuth_angle': azimuth_angle
        }

    print(f"生成 {len(camera_poses)} 个初始相机位姿")
    return camera_poses

# 统一的GPU检测和设置
def check_gpu_availability():
    """
    检测GPU可用性，返回最佳可用的后端
    """
    gpu_info = {
        'cupy_available': False,
        'pytorch_available': False,
        'best_backend': 'cpu'
    }

    # 检测CuPy GPU
    try:
        import cupy as cp
        gpu_info['cupy_available'] = True
        gpu_info['best_backend'] = 'cupy'
        print(f"✓ CuPy GPU可用")
        # 测试CuPy功能
        test_array = cp.array([1, 2, 3])
        print(f"  CuPy测试成功: {cp.asnumpy(test_array)}")
    except ImportError:
        print("✗ CuPy未安装")
    except Exception as e:
        print(f"✗ CuPy测试失败: {e}")

    # 检测PyTorch GPU
    try:
        import torch
        if torch.cuda.is_available():
            gpu_info['pytorch_available'] = True
            if gpu_info['best_backend'] == 'cpu':  # 如果CuPy不可用，但PyTorch可用
                gpu_info['best_backend'] = 'pytorch'
            print(f"✓ PyTorch GPU可用: {torch.cuda.get_device_name(0)}")
            print(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024 ** 3:.1f} GB")
    except ImportError:
        print("✗ PyTorch未安装")

    if gpu_info['best_backend'] == 'cpu':
        print("ℹ 将使用CPU进行计算")

    return gpu_info


# 检测GPU可用性
gpu_info = check_gpu_availability()

# 统一的GPU使用设置
args.use_gpu = not args.use_cpu and gpu_info['best_backend'] != 'cpu'

# 自动选择最佳后端
if args.use_gpu and args.gpu_backend == "auto":
    args.gpu_backend = gpu_info['best_backend']

# 设置COLMAP GPU使用
use_gpu_colmap = 1 if args.use_gpu else 0

# 打印GPU设置
if args.use_gpu:
    print(f"🚀 启用GPU加速 (后端: {args.gpu_backend})")
else:
    print("💻 使用CPU模式")

# 设置默认的可视化选项
if not hasattr(args, 'save_feature_images'):
    args.save_feature_images = True
if not hasattr(args, 'save_match_images'):
    args.save_match_images = True

# 如果用户明确指定了不保存，则覆盖默认值
if args.no_save_feature_images:
    args.save_feature_images = False
if args.no_save_match_images:
    args.save_match_images = False

colmap_command = '"{}"'.format(args.colmap_executable) if len(args.colmap_executable) > 0 else "colmap"
magick_command = '"{}"'.format(args.magick_executable) if len(args.magick_executable) > 0 else "magick"
# 统一GPU设置逻辑
use_gpu = not (args.no_gpu or args.use_cpu)


def parse_mstar_filename(filename):
    """
    解析MSTAR数据集文件名，提取俯视角和方位角
    格式: T72-15-007 或类似
    """
    # 移除文件扩展名
    basename = os.path.splitext(filename)[0]

    # 使用正则表达式匹配模式: 目标名-俯视角-方位角
    pattern = r'([A-Za-z0-9]+)-(\d+)-(\d+)'
    match = re.search(pattern, basename)

    if match:
        target_name = match.group(1)  # 目标名，如T72
        depression_angle = int(match.group(2))  # 俯视角，如15度
        azimuth_angle = int(match.group(3))  # 方位角，如007度

        print(f"解析文件名: {filename} -> 目标: {target_name}, 俯视角: {depression_angle}°, 方位角: {azimuth_angle}°")
        return depression_angle, azimuth_angle
    else:
        # 如果无法解析，使用默认值
        print(f"警告: 无法解析文件名 {filename}，使用默认角度")
        return 15, 0  # 默认15度俯视角，0度方位角


def preprocess_sar_image(image):
    """
    SAR图像预处理 - 与原始SAR-SIFT代码保持一致
    """
    # 确保图像是合适的类型
    if image.dtype != np.float64:
        image = image.astype(np.float64)

    # 归一化到0-1范围（与原始SAR-SIFT代码一致）
    if image.max() > 1.0:
        image = image / 255.0

    # 应用预处理（如果启用）
    if args.preprocess_sar:
        # 应用斑点噪声滤波
        if args.speckle_filter:
            # 使用中值滤波减少斑点噪声
            temp_img = (image * 255).astype(np.uint8)
            temp_img = cv2.medianBlur(temp_img, 3)
            image = temp_img.astype(np.float64) / 255.0

        # 应用对比度增强
        if args.contrast_enhance:
            # 直方图均衡化
            temp_img = (image * 255).astype(np.uint8)
            temp_img = cv2.equalizeHist(temp_img)
            image = temp_img.astype(np.float64) / 255.0

    return image


def extract_single_image_features(img_path, feature_type, backend):
    """
    单张图像的特征提取函数 - 返回可序列化的数据
    """
    img_name = os.path.basename(img_path)

    # 读取图像
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"❌ 无法读取图像: {img_path}")
        return img_name, None, None, None

    # SAR图像预处理
    img = preprocess_sar_image(img)

    # 确保图像是合适的类型和范围
    if img.dtype != np.float32:
        img = img.astype(np.float32)

    if img.max() > 1.0:
        img = img / 255.0

    # 使用SAR-SIFT，强制使用CPU后端
    try:
        keypoints, descriptors = sar_sift_detect_and_compute(
            img,
            sigma=args.sar_sift_sigma,
            ratio=args.sar_sift_ratio,
            Mmax=args.sar_sift_layers,
            d=args.sar_sift_d,
            d_SH=args.sar_sift_harris_threshold,
            backend=backend
        )
    except Exception as e:
        print(f"❌ SAR-SIFT处理图像 {img_name} 时出错: {e}")
        return img_name, None, None, None

    if keypoints is None or descriptors is None or len(keypoints) == 0:
        print(f"⚠️ 在 {img_name} 中未找到SAR-SIFT特征点")
        return img_name, None, None, None

    # 将关键点转换为可序列化的字典格式
    keypoints_serializable = [safe_keypoint_to_dict(kp) for kp in keypoints]
    for kp in keypoints:
        kp_dict = {
            'pt': (float(kp.pt[0]), float(kp.pt[1])),
            'size': float(kp.size) if hasattr(kp, 'size') and kp.size > 0 else 1.0,
            'angle': float(kp.angle) if hasattr(kp, 'angle') else 0.0,
            'response': float(kp.response) if hasattr(kp, 'response') else 1.0,
            'octave': int(kp.octave) if hasattr(kp, 'octave') else 0
        }
        keypoints_serializable.append(kp_dict)

    # 转换为COLMAP格式
    colmap_keypoints = []
    for kp in keypoints:
        x = kp.pt[0]
        y = kp.pt[1]
        response = kp.response if hasattr(kp, 'response') else 1.0
        size = kp.size if hasattr(kp, 'size') else 1.0
        angle = kp.angle if hasattr(kp, 'angle') else 0.0

        colmap_kp = [x, y, response, size, angle, 0.0]
        colmap_keypoints.append(colmap_kp)

    colmap_keypoints_array = np.array(colmap_keypoints, dtype=np.float32)
    descriptors_array = descriptors.astype(np.float32)

    print(f"✅ 图像 {img_name}: 找到 {len(keypoints)} 个SAR-SIFT特征点")

    return img_name, keypoints_serializable, colmap_keypoints_array, descriptors_array


def extract_single_image_features_wrapper(args):
    """
    包装函数，用于多进程池
    """
    img_path, feature_type, backend = args
    return extract_single_image_features(img_path, feature_type, backend)


def extract_features_multiprocess(image_paths, feature_type="SAR_SIFT"):
    """
    使用多进程提取特征 - 处理可序列化的关键点数据
    """
    print(f"🎯 使用多进程提取 {feature_type} 特征...")

    if feature_type != "SAR_SIFT":
        print(f"⚠️ 只支持SAR_SIFT特征提取器，但收到 {feature_type}，将使用SAR_SIFT")
        feature_type = "SAR_SIFT"

    print("🔧 SAR-SIFT参数:")
    print(f"   sigma={args.sar_sift_sigma}, ratio={args.sar_sift_ratio}")
    print(f"   layers={args.sar_sift_layers}, d={args.sar_sift_d}")
    print(f"   harris_threshold={args.sar_sift_harris_threshold}")

    # 强制使用CPU后端
    backend = "cpu"
    print("💻 使用多进程CPU后端")

    # 清空全局字典
    all_keypoints = {}
    all_descriptors = {}
    all_original_keypoints = {}

    # ========== 进程数配置逻辑 ==========
    if args.num_threads == 0:
        # 单进程模式（用于调试）
        print("🔧 使用单进程模式（调试）")
        num_processes = 1
    elif args.num_threads > 0:
        # 用户指定进程数
        num_processes = min(args.num_threads, len(image_paths), cpu_count())
        print(f"🔧 使用用户指定进程数: {num_processes}")
    else:
        # 自动设置进程数
        available_cpus = cpu_count()

        # 根据图像数量和系统资源自动调整
        if len(image_paths) <= 4:
            num_processes = min(len(image_paths), available_cpus)
        elif len(image_paths) <= 16:
            num_processes = min(available_cpus, 8)
        else:
            num_processes = min(available_cpus, 12)  # 限制最大进程数

        print(f"🔧 自动设置进程数: {num_processes} (CPU核心数: {available_cpus}, 图像数: {len(image_paths)})")

    # 如果只有1张图像，强制单进程
    if len(image_paths) <= 1:
        num_processes = 1
        print("🔧 只有1张图像，使用单进程")

    # 准备任务参数
    task_args = [(img_path, feature_type, backend) for img_path in image_paths]

    processed_count = 0
    total_count = len(image_paths)

    # 使用多进程池并行处理
    print(f"🚀 启动 {num_processes} 个进程处理 {total_count} 张图像...")

    try:
        with Pool(processes=num_processes) as pool:
            # 使用imap_unordered获取完成的任务（更高效）
            for i, result in enumerate(pool.imap_unordered(extract_single_image_features_wrapper, task_args)):
                img_name, keypoints_serializable, colmap_kp, descriptors = result

                if img_name and keypoints_serializable is not None:
                    # 将序列化的关键点数据转换回 cv2.KeyPoint 对象
                    original_keypoints = []
                    for kp_dict in keypoints_serializable:
                        kp = cv2.KeyPoint()
                        kp.pt = kp_dict['pt']
                        kp.size = kp_dict['size']
                        kp.angle = kp_dict['angle']
                        kp.response = kp_dict['response']
                        kp.octave = kp_dict['octave']
                        original_keypoints.append(kp)

                    all_original_keypoints[img_name] = original_keypoints
                    all_keypoints[img_name] = colmap_kp
                    all_descriptors[img_name] = descriptors

                processed_count += 1
                if processed_count % max(1, total_count // 10) == 0:  # 每10%进度报告一次
                    print(f"📊 进度: {processed_count}/{total_count} ({processed_count / total_count * 100:.1f}%)")

    except Exception as e:
        print(f"❌ 多进程处理失败: {e}")
        # 回退到单进程处理
        print("🔄 回退到单进程处理...")
        for task_arg in task_args:
            result = extract_single_image_features_wrapper(task_arg)
            img_name, keypoints_serializable, colmap_kp, descriptors = result
            if img_name and keypoints_serializable is not None:
                # 将序列化的关键点数据转换回 cv2.KeyPoint 对象
                original_keypoints = [dict_to_keypoint(kp_dict) for kp_dict in keypoints_serializable]
                for kp_dict in keypoints_serializable:
                    kp = cv2.KeyPoint()
                    kp.pt = kp_dict['pt']
                    kp.size = kp_dict['size']
                    kp.angle = kp_dict['angle']
                    kp.response = kp_dict['response']
                    kp.octave = kp_dict['octave']
                    original_keypoints.append(kp)

                all_original_keypoints[img_name] = original_keypoints
                all_keypoints[img_name] = colmap_kp
                all_descriptors[img_name] = descriptors

    print(f"✅ 特征提取完成: 成功处理 {len(all_keypoints)}/{total_count} 张图像")

    return all_keypoints, all_descriptors, all_original_keypoints


def visualize_and_save_keypoints(image_paths, original_keypoints, output_dir, max_images=None):
    """
    可视化并保存特征点图像

    Args:
        image_paths: 图像路径列表
        original_keypoints: 原始关键点字典
        output_dir: 输出目录
        max_images: 最多保存的图像数量
    """
    if max_images is None:
        max_images = args.max_feature_images

    print(f"🎨 保存特征点可视化图像 (最多 {max_images} 张)...")
    os.makedirs(output_dir, exist_ok=True)

    saved_count = 0
    for img_path in image_paths:
        if saved_count >= max_images:
            break

        img_name = os.path.basename(img_path)
        if img_name not in original_keypoints or not original_keypoints[img_name]:
            continue

        # 读取图像
        img = cv2.imread(img_path)
        if img is None:
            continue

        # 绘制特征点
        kp_img = img.copy()
        keypoints = original_keypoints[img_name]

        # 使用不同颜色绘制特征点
        for i, kp in enumerate(keypoints):
            x, y = int(kp.pt[0]), int(kp.pt[1])
            size = int(kp.size) if kp.size > 0 else 5

            # 根据响应值选择颜色
            if hasattr(kp, 'response'):
                if kp.response > 0.1:
                    color = (0, 255, 0)  # 高响应 - 绿色
                elif kp.response > 0.05:
                    color = (0, 255, 255)  # 中响应 - 黄色
                else:
                    color = (0, 0, 255)  # 低响应 - 红色
            else:
                color = (255, 255, 255)  # 默认白色

            # 绘制关键点
            cv2.circle(kp_img, (x, y), size, color, 1)

            # 绘制方向（如果有）
            if hasattr(kp, 'angle') and kp.angle != -1:
                angle_rad = np.radians(kp.angle)
                end_x = int(x + size * np.cos(angle_rad))
                end_y = int(y + size * np.sin(angle_rad))
                cv2.line(kp_img, (x, y), (end_x, end_y), color, 1)

        # 添加文本信息
        text = f"Keypoints: {len(keypoints)}"
        cv2.putText(kp_img, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(kp_img, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 1)

        # 保存图像
        output_path = os.path.join(output_dir, f"keypoints_{saved_count:04d}_{img_name}")
        cv2.imwrite(output_path, kp_img)

        print(f"  保存特征点图: {output_path} (特征点数: {len(keypoints)})")
        saved_count += 1

    print(f"✅ 特征点图保存完成: 共保存 {saved_count} 张图像")


def create_colmap_database_from_features(source_path, keypoints, descriptors, camera_model="OPENCV",
                                         feature_type="SAR_SIFT"):
    """
    从OpenCV提取的特征创建COLMAP数据库 - 完全兼容COLMAP标准格式
    """
    print("创建COLMAP标准格式数据库...")

    # 确保distorted目录存在
    distorted_dir = os.path.join(source_path, "distorted")
    os.makedirs(distorted_dir, exist_ok=True)

    db_path = os.path.join(distorted_dir, "database.db")

    print(f"数据库路径: {db_path}")  # 添加调试信息

    # 清理现有数据库
    if os.path.exists(db_path):
        try:
            os.remove(db_path)
            print("已删除现有数据库文件")
        except Exception as e:
            print(f"删除现有数据库失败: {e}")

    # 连接数据库
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        print("数据库连接成功")
    except Exception as e:
        print(f"数据库连接失败: {e}")
        # 尝试使用绝对路径
        try:
            db_path = os.path.abspath(db_path)
            print(f"尝试使用绝对路径: {db_path}")
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            print("使用绝对路径连接成功")
        except Exception as e2:
            print(f"绝对路径连接也失败: {e2}")
            # 尝试在当前目录创建数据库
            try:
                db_path = "temp_database.db"
                print(f"尝试在当前目录创建数据库: {db_path}")
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                print("当前目录数据库创建成功")
            except Exception as e3:
                print(f"所有数据库连接尝试都失败: {e3}")
                return None, {}

    # 创建表 - 使用COLMAP标准表结构
    try:
        cursor.execute('''
                       CREATE TABLE cameras
                       (
                           camera_id          INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                           model              INTEGER NOT NULL,
                           width              INTEGER NOT NULL,
                           height             INTEGER NOT NULL,
                           params             BLOB,
                           prior_focal_length INTEGER NOT NULL
                       )
                       ''')

        cursor.execute('''
                       CREATE TABLE images
                       (
                           image_id  INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                           name      TEXT    NOT NULL UNIQUE,
                           camera_id INTEGER NOT NULL,
                           prior_qw  REAL,
                           prior_qx  REAL,
                           prior_qy  REAL,
                           prior_qz  REAL,
                           prior_tx  REAL,
                           prior_ty  REAL,
                           prior_tz  REAL,
                           timestamp INTEGER,
                           CONSTRAINT images_id_key UNIQUE (image_id),
                           FOREIGN KEY (camera_id) REFERENCES cameras (camera_id)
                       )
                       ''')

        cursor.execute('''
                       CREATE TABLE keypoints
                       (
                           image_id INTEGER NOT NULL,
                           rows     INTEGER NOT NULL,
                           cols     INTEGER NOT NULL,
                           data     BLOB,
                           FOREIGN KEY (image_id) REFERENCES images (image_id) ON DELETE CASCADE
                       )
                       ''')

        cursor.execute('''
                       CREATE TABLE descriptors
                       (
                           image_id INTEGER NOT NULL,
                           rows     INTEGER NOT NULL,
                           cols     INTEGER NOT NULL,
                           data     BLOB,
                           FOREIGN KEY (image_id) REFERENCES images (image_id) ON DELETE CASCADE
                       )
                       ''')

        cursor.execute('''
                       CREATE TABLE matches
                       (
                           pair_id INTEGER PRIMARY KEY NOT NULL,
                           rows    INTEGER             NOT NULL,
                           cols    INTEGER             NOT NULL,
                           data    BLOB
                       )
                       ''')

        cursor.execute('''
                       CREATE TABLE two_view_geometries
                       (
                           pair_id INTEGER PRIMARY KEY NOT NULL,
                           rows    INTEGER             NOT NULL,
                           cols    INTEGER             NOT NULL,
                           data    BLOB,
                           config  INTEGER             NOT NULL,
                           F       BLOB,
                           E       BLOB,
                           H       BLOB
                       )
                       ''')

        # 创建索引以提高查询性能
        cursor.execute('CREATE INDEX IF NOT EXISTS keypoints_image_id_idx ON keypoints(image_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS descriptors_image_id_idx ON descriptors(image_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS matches_pair_id_idx ON matches(pair_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS two_view_geometries_pair_id_idx ON two_view_geometries(pair_id)')

        # 添加COLMAP需要的额外索引
        cursor.execute('CREATE INDEX IF NOT EXISTS images_name_idx ON images(name)')
        cursor.execute('CREATE INDEX IF NOT EXISTS images_camera_id_idx ON images(camera_id)')

        print("数据库表创建成功")

    except Exception as e:
        print(f"创建数据库表失败: {e}")
        conn.close()
        return None, {}

    # SAR专用相机参数 - 使用简单针孔模型但调整参数适应SAR几何
    original_width, original_height = 128, 128  # MSTAR图像原始尺寸
    upscaled_width = int(original_width * args.image_scale)
    upscaled_height = int(original_height * args.image_scale)

    # SAR图像通常有较大的焦距和较小的畸变
    # 使用SIMPLE_PINHOLE模型，参数: [f, cx, cy]
    focal_length = 800.0 * args.image_scale  # SAR图像通常焦距较大
    camera_params = np.array([
        focal_length,  # f
        upscaled_width / 2,  # cx
        upscaled_height / 2  # cy
    ], dtype=np.float64)
    model_id = 0  # SIMPLE_PINHOLE模型ID，需要3个参数

    try:
        cursor.execute(
            "INSERT INTO cameras (model, width, height, params, prior_focal_length) VALUES (?, ?, ?, ?, ?)",
            (model_id, upscaled_width, upscaled_height, camera_params.tobytes(), 1)
        )
        camera_id = cursor.lastrowid
        print(f"相机参数插入成功，相机ID: {camera_id}")
    except Exception as e:
        print(f"插入相机参数失败: {e}")
        conn.close()
        return None, {}

    # 添加图像和特征点
    image_ids = {}
    successful_images = 0

    for img_name in keypoints.keys():
        try:
            # 添加图像
            cursor.execute(
                "INSERT INTO images (name, camera_id, timestamp) VALUES (?, ?, ?)",
                (img_name, camera_id, 0)  # timestamp设为0
            )
            image_id = cursor.lastrowid
            image_ids[img_name] = image_id

            # 添加关键点
            kp_data = keypoints[img_name]
            rows, cols = kp_data.shape
            kp_data = kp_data.astype(np.float32)

            cursor.execute(
                "INSERT INTO keypoints (image_id, rows, cols, data) VALUES (?, ?, ?, ?)",
                (image_id, rows, cols, kp_data.tobytes())
            )

            # 添加描述符 - 检查维度
            desc_data = descriptors[img_name]
            rows, cols = desc_data.shape

            # 检查描述符维度，如果不是128维则调整
            if cols != 128:
                print(f"调整描述符维度: {img_name} 从 {cols} 维调整为 128 维")
                if cols > 128:
                    # 截断到128维
                    desc_data = desc_data[:, :128]
                else:
                    # 填充到128维
                    padding = np.zeros((rows, 128 - cols), dtype=desc_data.dtype)
                    desc_data = np.hstack([desc_data, padding])

                rows, cols = desc_data.shape  # 更新维度

            desc_data = desc_data.astype(np.float32)

            cursor.execute(
                "INSERT INTO descriptors (image_id, rows, cols, data) VALUES (?, ?, ?, ?)",
                (image_id, rows, cols, desc_data.tobytes())
            )

            successful_images += 1

        except Exception as e:
            print(f"处理图像 {img_name} 时出错: {e}")
            continue

    try:
        conn.commit()
        conn.close()
        print(f"数据库创建完成: {db_path}")
        print(f"成功添加了 {successful_images} 张图像的特征点")
    except Exception as e:
        print(f"提交数据库更改失败: {e}")
        return None, {}

    return db_path, image_ids


def save_matches_to_database(db_path, matches_dict, image_ids):
    """将匹配结果保存到数据库 - 使用COLMAP标准格式"""
    print("保存匹配结果到数据库...")

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 获取图像总数
    cursor.execute("SELECT COUNT(*) FROM images")
    num_images = cursor.fetchone()[0]
    print(f"图像总数: {num_images}")

    match_count = 0
    for (img1_name, img2_name), match_data in matches_dict.items():
        if img1_name not in image_ids or img2_name not in image_ids:
            continue

        image_id1 = image_ids[img1_name]
        image_id2 = image_ids[img2_name]

        # COLMAP标准的pair_id计算方式: 2147483647 * min_id + max_id
        if image_id1 > image_id2:
            image_id1, image_id2 = image_id2, image_id1
            # 注意：如果交换了图像ID，也需要交换匹配索引
            match_data = match_data[:, [1, 0]]  # 交换列顺序

        pair_id = 2147483647 * image_id1 + image_id2

        if match_data.size > 0:
            rows, cols = match_data.shape

            # 确保匹配数据是uint32类型
            match_data = match_data.astype(np.uint32)

            cursor.execute(
                "INSERT OR REPLACE INTO matches (pair_id, rows, cols, data) VALUES (?, ?, ?, ?)",
                (pair_id, rows, cols, match_data.tobytes())
            )
            match_count += 1

            print(
                f"保存匹配对: {img1_name}({image_id1}) - {img2_name}({image_id2}) -> pair_id: {pair_id}, 匹配数: {rows}")

    conn.commit()
    conn.close()

    print(f"总共保存了 {match_count} 组匹配到数据库")


def create_synthetic_camera_poses(image_files, sar_height, depression_scale=1.0, point_cloud_scale=1.0):
    """
    创建合成的相机位姿（当SfM失败时使用）
    基于SAR几何生成合理的相机位姿
    """
    print("创建基于SAR几何的合成相机位姿...")

    camera_poses = {}

    for i, img_path in enumerate(image_files):
        img_name = os.path.basename(img_path)

        # 从文件名解析俯视角和方位角
        depression_angle_deg, azimuth_angle_deg = parse_mstar_filename(img_name)

        # 转换为弧度并应用缩放
        depression_angle = np.radians(depression_angle_deg) * depression_scale
        azimuth_angle = np.radians(azimuth_angle_deg)

        # SAR几何计算
        slant_range = sar_height / np.sin(depression_angle)
        ground_range = np.sqrt(slant_range ** 2 - sar_height ** 2)

        # 计算相机位置（在XZ平面上的圆环分布）
        # COLMAP坐标系约定：Y轴向下，Z轴向前，高度正值在Y轴负方向
        radius = ground_range * point_cloud_scale
        x = radius * np.cos(azimuth_angle)
        z = radius * np.sin(azimuth_angle)
        y = -sar_height  # 飞行高度在Y轴负方向（COLMAP约定）

        # 计算看向原点的旋转
        # 简化版本：假设相机始终看向原点
        forward = np.array([-x, -y, -z])
        forward = forward / np.linalg.norm(forward)

        # 计算右向量
        # COLMAP坐标系：Y轴向下，所以"上"方向是Y轴负方向
        right = np.cross(forward, np.array([0, -1, 0]))  # COLMAP约定：高度正值在Y轴负方向
        right = right / np.linalg.norm(right)

        # 计算上向量
        up = np.cross(right, forward)

        # 构建旋转矩阵
        rotation_matrix = np.column_stack([right, up, -forward])

        # 转换为四元数
        rotation = R.from_matrix(rotation_matrix)
        quat = rotation.as_quat()  # [x, y, z, w]

        camera_poses[img_name] = {
            'qw': quat[3], 'qx': quat[0], 'qy': quat[1], 'qz': quat[2],
            'tx': x, 'ty': y, 'tz': z,
            'depression_angle': depression_angle_deg,
            'azimuth_angle': azimuth_angle_deg
        }

    print(f"生成了 {len(camera_poses)} 个合成相机位姿")
    return camera_poses


def generate_sar_point_cloud(image_files, sar_height, target_height, target_base_height,
                             shadow_height, background_height, target_density, background_density,
                             scale_factor=1.0):
    """
    生成SAR专用的点云 - 基于SAR几何和图像信息
    """
    print("生成SAR专用点云...")

    all_points = []
    all_colors = []

    # 目标尺寸（米）- 应用缩放
    target_length = 8.0 * scale_factor
    target_width = 3.0 * scale_factor
    target_height_val = 2.5 * scale_factor

    # 生成目标点云
    target_samples = int(target_length * target_width * target_density * 50)
    print(f"生成 {target_samples} 个目标点")

    for i in range(target_samples):
        # 在目标体积内随机生成点
        x = np.random.uniform(-target_length / 2, target_length / 2)
        z = np.random.uniform(-target_width / 2, target_width / 2)
        y = np.random.uniform(target_base_height, target_base_height + target_height_val)

        # 根据位置调整高度 - 模拟目标形状
        norm_x = x / (target_length / 2)
        norm_z = z / (target_width / 2)
        distance = np.sqrt(norm_x ** 2 + norm_z ** 2)

        base_y = target_base_height

        if distance < 0.7:  # 中心区域
            height_factor = 1.0 - distance
            y = base_y + target_height_val * height_factor
        else:  # 边缘区域
            height_factor = 0.5 * (1.0 - min(distance, 1.0))
            y = base_y + target_height_val * 0.3 * height_factor

        # 添加随机微小变化
        y += np.random.normal(0, 0.03 * scale_factor)

        # 目标颜色
        if y > target_base_height + target_height_val * 0.6:
            base_r, base_g, base_b = 200, 100, 80  # 上部 - 偏红
        else:
            base_r, base_g, base_b = 160, 140, 100  # 下部 - 偏黄

        # 颜色变化
        color_variation = np.random.randint(-15, 15, 3)
        color_r = max(0, min(255, base_r + color_variation[0]))
        color_g = max(0, min(255, base_g + color_variation[1]))
        color_b = max(0, min(255, base_b + color_variation[2]))

        all_points.append([x, y, z])
        all_colors.append([color_r, color_g, color_b])

    # 生成地面点云
    # 🔧 改进生成策略：考虑SAR视角，生成更合理的水平分散分布
    # 问题分析：
    # - 碗状结构是因为高斯泼溅需要拟合不同视角的渲染结果
    # - 背景点云背后的高亮点透过背景点云模拟背景中的高亮点
    # - 这些碗状点云离目标点云很近，直接压制高度不合理
    # 解决方案：
    # - 在生成阶段就考虑水平分散，避免在目标附近生成过于密集的点
    # - 使用分层生成策略：目标附近稀疏，远离目标处密集
    # - 确保初始分布就是铺开的，而不是聚集的
    
    ground_size = max(target_length * 4, 50.0) * scale_factor
    ground_samples = int(ground_size * ground_size * background_density * 3)

    print(f"生成 {ground_samples} 个地面点，地面大小: {ground_size:.1f}米")

    # 计算目标区域的范围
    target_x_range = (-target_length / 2, target_length / 2)
    target_z_range = (-target_width / 2, target_width / 2)
    target_center = (0.0, 0.0)  # 目标中心在原点
    
    # 地面点的高度应该严格限制在background_height附近
    ground_height_tolerance = 0.05 * scale_factor  # 减小容差，确保地面点更平整
    
    # 🔧 改进1：分层生成策略
    # 将地面分为三个区域：
    # 1. 目标附近区域（0-1.5倍目标尺寸）：稀疏生成，避免聚集
    # 2. 中间区域（1.5-3倍目标尺寸）：中等密度
    # 3. 外围区域（3倍目标尺寸以外）：正常密度
    
    target_radius = max(target_length, target_width) / 2.0  # 目标半径
    inner_radius = target_radius * 1.5  # 内层半径
    middle_radius = target_radius * 3.0  # 中层半径
    
    inner_samples = int(ground_samples * 0.2)  # 内层20%的点（稀疏）
    middle_samples = int(ground_samples * 0.3)  # 中层30%的点（中等）
    outer_samples = ground_samples - inner_samples - middle_samples  # 外层50%的点（正常）
    
    for i in range(ground_samples):
        # 根据区域分配采样
        if i < inner_samples:
            # 内层：稀疏生成，使用更大的随机范围，避免聚集
            # 使用极坐标生成，确保均匀分布
            angle = np.random.uniform(0, 2 * np.pi)
            # 半径在target_radius到inner_radius之间，但更倾向于外层
            r = np.random.uniform(target_radius * 1.2, inner_radius)
            x = r * np.cos(angle)
            z = r * np.sin(angle)
            # 添加一些随机扰动，增加分散度
            x += np.random.normal(0, target_radius * 0.3)
            z += np.random.normal(0, target_radius * 0.3)
        elif i < inner_samples + middle_samples:
            # 中层：中等密度
            angle = np.random.uniform(0, 2 * np.pi)
            r = np.random.uniform(inner_radius, middle_radius)
            x = r * np.cos(angle)
            z = r * np.sin(angle)
        else:
            # 外层：正常密度，均匀分布
            x = np.random.uniform(-ground_size / 2, ground_size / 2)
            z = np.random.uniform(-ground_size / 2, ground_size / 2)
        
        # 确保点在有效范围内
        x = np.clip(x, -ground_size / 2, ground_size / 2)
        z = np.clip(z, -ground_size / 2, ground_size / 2)
        
        # 🔧 改进2：高度严格限制在background_height附近
        # 使用更小的随机变化，确保地面是平的
        y = background_height + np.random.normal(0, ground_height_tolerance)
        
        # 额外检查：如果点在目标区域正下方，确保高度不会超过background_height
        # （在COLMAP坐标系中，Y向下，所以目标在ground_height以下）
        if (target_x_range[0] <= x <= target_x_range[1] and 
            target_z_range[0] <= z <= target_z_range[1]):
            # 在目标区域正下方的点，高度应该严格等于background_height
            y = background_height

        # 地面颜色（偏灰）
        base_intensity = np.random.randint(100, 180)
        color_variation = np.random.randint(-10, 10, 3)
        color_r = max(0, min(255, base_intensity + color_variation[0]))
        color_g = max(0, min(255, base_intensity + color_variation[1]))
        color_b = max(0, min(255, base_intensity + color_variation[2]))

        all_points.append([x, y, z])
        all_colors.append([color_r, color_g, color_b])

    # 转换为numpy数组
    if all_points:
        points_3d = np.array(all_points).T
        print(f"总点数: {len(all_points)}")
        print(f"点云范围: X[{np.min(points_3d[0]):.2f}, {np.max(points_3d[0]):.2f}], "
              f"Y[{np.min(points_3d[1]):.2f}, {np.max(points_3d[1]):.2f}], "
              f"Z[{np.min(points_3d[2]):.2f}, {np.max(points_3d[2]):.2f}]")

        return points_3d, all_colors
    else:
        print("错误: 未能生成任何点")
        return np.zeros((3, 0)), []


def save_point_cloud_ply(points_3d, point_colors, filename):
    """
    将点云保存为PLY格式
    """
    if points_3d.size == 0:
        print(f"警告: 没有点云数据可保存到 {filename}")
        return

    if points_3d.shape[0] != 3:
        points_3d = points_3d.T

    num_points = points_3d.shape[1]

    if len(point_colors) != num_points:
        print(f"警告: 点云颜色数量 ({len(point_colors)}) 与点数量 ({num_points}) 不匹配")
        point_colors = [[255, 255, 255] for _ in range(num_points)]

    with open(filename, 'w') as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"element vertex {num_points}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        f.write("property uchar red\n")
        f.write("property uchar green\n")
        f.write("property uchar blue\n")
        f.write("end_header\n")

        for i in range(num_points):
            x, y, z = points_3d[:, i]
            r, g, b = point_colors[i] if i < len(point_colors) else (255, 255, 255)
            f.write(f"{x:.6f} {y:.6f} {z:.6f} {int(r)} {int(g)} {int(b)}\n")

    print(f"点云已保存为PLY格式: {filename} (包含 {num_points} 个点)")




def select_promising_pairs(image_paths, max_pairs_per_image=None, max_azimuth_diff=None):
    """
    基于方位角信息选择有希望匹配的图像对
    避免O(n²)的全局匹配，大幅减少匹配时间
    """
    # 使用args中的参数，如果没有传入则使用args的默认值
    if max_pairs_per_image is None:
        max_pairs_per_image = args.max_pairs_per_image
    if max_azimuth_diff is None:
        max_azimuth_diff = args.max_azimuth_diff

    print(f"🔍 基于方位角选择有希望的图像对...")
    print(f"   每张图像最多匹配 {max_pairs_per_image} 个相邻图像")
    print(f"   最大方位角差异: {max_azimuth_diff}°")

    # 解析所有图像的方位角
    image_angles = {}

    for img_path in image_paths:
        img_name = os.path.basename(img_path)
        _, azimuth_angle = parse_mstar_filename(img_name)
        image_angles[img_name] = azimuth_angle

    # 获取所有角度并排序
    all_angles = sorted(image_angles.values())
    print(f"   图像方位角范围: {min(all_angles)}° - {max(all_angles)}°")

    promising_pairs = set()

    # 为每张图像选择角度相近的图像进行匹配
    for img_name, current_angle in image_angles.items():
        # 找到角度相近的图像
        candidate_images = []

        # 检查当前角度附近的范围
        for candidate_name, candidate_angle in image_angles.items():
            if candidate_name == img_name:
                continue

            angle_diff = min(
                abs(candidate_angle - current_angle),
                360 - abs(candidate_angle - current_angle)  # 处理360°环绕
            )

            if angle_diff <= max_azimuth_diff:
                candidate_images.append((candidate_name, angle_diff))

        # 按角度差排序，选择最接近的几个
        candidate_images.sort(key=lambda x: x[1])
        selected_candidates = candidate_images[:max_pairs_per_image]

        # 添加到匹配对（确保不重复）
        for candidate_img, angle_diff in selected_candidates:
            pair = tuple(sorted([img_name, candidate_img]))  # 排序确保唯一性
            promising_pairs.add(pair)

    # 转换为列表
    promising_pairs = list(promising_pairs)

    # 计算减少的比例
    total_possible_pairs = len(image_paths) * (len(image_paths) - 1) // 2
    reduction_ratio = (total_possible_pairs - len(promising_pairs)) / total_possible_pairs * 100

    print(f"✅ 图像对选择完成:")
    print(f"   总图像数: {len(image_paths)}")
    print(f"   可能的总匹配对数: {total_possible_pairs}")
    print(f"   选定的匹配对数: {len(promising_pairs)}")
    print(f"   匹配对数减少: {reduction_ratio:.1f}%")

    return promising_pairs


# 在 select_promising_pairs 函数后添加：
def apply_sar_geometric_constraints(matches_dict, image_angles, max_azimuth_diff, min_depression_diff=0):
    """
    应用SAR几何约束过滤匹配对
    """
    print("应用SAR几何约束过滤匹配对...")

    filtered_matches = {}

    for (img1, img2), matches in matches_dict.items():
        if img1 not in image_angles or img2 not in image_angles:
            continue

        dep1, azi1 = image_angles[img1]
        dep2, azi2 = image_angles[img2]

        # 计算方位角差异（考虑360度环绕）
        azimuth_diff = min(abs(azi1 - azi2), 360 - abs(azi1 - azi2))
        depression_diff = abs(dep1 - dep2)

        # SAR几何约束：方位角差异小，俯视角差异适中
        if (azimuth_diff <= max_azimuth_diff and
                min_depression_diff <= depression_diff <= 45):  # 俯视角差异在合理范围内

            # 进一步根据匹配数量过滤
            if len(matches) >= 8:  # SAR图像需要更多匹配点
                filtered_matches[(img1, img2)] = matches
                print(f"  保留 {img1}-{img2}: 方位角差{azimuth_diff}°, 俯角差{depression_diff}°, 匹配点{len(matches)}")
            else:
                print(f"  丢弃 {img1}-{img2}: 匹配点不足 ({len(matches)})")
        else:
            print(f"  丢弃 {img1}-{img2}: 几何约束不满足 (方位角差{azimuth_diff}°, 俯角差{depression_diff}°)")

    print(f"几何约束过滤: {len(matches_dict)} -> {len(filtered_matches)} 对匹配")
    return filtered_matches


def match_selected_pairs_custom(keypoints, descriptors, original_keypoints,
                                image_paths, selected_pairs, feature_type="SAR_SIFT"):
    """
    只对选定的图像对进行匹配
    """
    print(f"🎯 对选定的 {len(selected_pairs)} 个图像对进行特征匹配...")

    matches_dir = os.path.join(args.source_path, "feature_matches")
    if args.save_match_images:
        os.makedirs(matches_dir, exist_ok=True)
        print(f"   特征匹配图将保存到: {matches_dir}")

    # 创建图像路径映射
    img_path_map = {}
    for img_path in image_paths:
        img_name = os.path.basename(img_path)
        img_path_map[img_name] = img_path

    matches_dict = {}
    saved_pairs = 0  # 修复：这里应该用 saved_pairs 而不是 saved_count

    # 只匹配选定的图像对
    for img1_name, img2_name in selected_pairs:
        # 检查两个图像都有特征点
        if img1_name not in descriptors or img2_name not in descriptors:
            continue

        desc1 = descriptors[img1_name]
        desc2 = descriptors[img2_name]

        # 获取关键点位置
        kp1_locations = []
        kp2_locations = []

        for kp in original_keypoints[img1_name]:
            kp1_locations.append([kp.pt[0], kp.pt[1]])

        for kp in original_keypoints[img2_name]:
            kp2_locations.append([kp.pt[0], kp.pt[1]])

        kp1_locations = np.array(kp1_locations)
        kp2_locations = np.array(kp2_locations)

        try:
            # 使用深度匹配进行初始匹配
            good_kp1, good_kp2 = custom_matcher.deep_match(
                kp1_locations, kp2_locations, desc1, desc2, args.max_ratio
            )

            if len(good_kp1) > 0:
                # 使用RANSAC进一步优化匹配
                better_kp1, better_kp2 = custom_matcher.ransac_matching(good_kp1, good_kp2)

                if len(better_kp1) > 0:
                    # 转换为COLMAP格式: [idx1, idx2] 对
                    match_pairs = []

                    # 查找匹配点在原始关键点列表中的索引
                    for kp1, kp2 in zip(better_kp1, better_kp2):
                        # 在kp1_locations中查找kp1的索引
                        idx1 = -1
                        for idx, loc in enumerate(kp1_locations):
                            if abs(loc[0] - kp1[0]) < 1e-5 and abs(loc[1] - kp1[1]) < 1e-5:
                                idx1 = idx
                                break

                        # 在kp2_locations中查找kp2的索引
                        idx2 = -1
                        for idx, loc in enumerate(kp2_locations):
                            if abs(loc[0] - kp2[0]) < 1e-5 and abs(loc[1] - kp2[1]) < 1e-5:
                                idx2 = idx
                                break

                        if idx1 != -1 and idx2 != -1:
                            match_pairs.append([idx1, idx2])

                    if len(match_pairs) > 0:
                        pair_key = (img1_name, img2_name)
                        matches_dict[pair_key] = np.array(match_pairs, dtype=np.uint32)

                        print(
                            f"   ✅ {img1_name} - {img2_name}: 初始匹配 {len(good_kp1)} 个, RANSAC后 {len(better_kp1)} 个")

                        # 保存匹配可视化图像
                        if args.save_match_images and matches_dir is not None and saved_pairs < args.max_match_pairs:
                            img1_path = img_path_map[img1_name]
                            img2_path = img_path_map[img2_name]
                            kp1 = original_keypoints[img1_name]
                            kp2 = original_keypoints[img2_name]

                            # 将匹配点转换为OpenCV格式
                            opencv_matches = []
                            for match_pair in match_pairs[:50]:  # 限制显示数量
                                match_obj = cv2.DMatch()
                                match_obj.queryIdx = match_pair[0]
                                match_obj.trainIdx = match_pair[1]
                                opencv_matches.append(match_obj)

                            # 使用自定义匹配器的可视化功能
                            output_path = custom_matcher.visualize_and_save_matches(
                                img1_path, img2_path, kp1, kp2, opencv_matches, matches_dir, saved_pairs
                            )
                            if output_path:
                                print(f"   📸 保存匹配图: {os.path.basename(output_path)}")
                            saved_pairs += 1  # 在这里递增
                else:
                    print(f"   ⚠️ {img1_name} - {img2_name}: RANSAC后无有效匹配")
            else:
                print(f"   ❌ {img1_name} - {img2_name}: 无初始匹配")

        except Exception as e:
            print(f"   💥 匹配 {img1_name} - {img2_name} 时出错: {e}")
            continue

    print(f"🎯 匹配完成: 总共找到 {len(matches_dict)} 对有效图像匹配")
    print(f"📸 匹配图保存: 共保存 {saved_pairs} 张匹配图像")  # 修复：这里使用 saved_pairs
    return matches_dict


# 在匹配函数中添加SAR专用优化：
def match_features_sar_optimized(keypoints, descriptors, original_keypoints, image_paths, feature_type="SAR_SIFT"):
    """
    SAR优化的特征匹配
    """
    print("使用SAR优化特征匹配...")

    # 收集图像角度信息
    image_angles = {}
    for img_path in image_paths:
        img_name = os.path.basename(img_path)
        depression_angle, azimuth_angle = parse_mstar_filename(img_name)
        image_angles[img_name] = (depression_angle, azimuth_angle)

    # 选择有希望的图像对
    selected_pairs = select_promising_pairs(image_paths)

    matches_dict = match_selected_pairs_custom(
        keypoints, descriptors, original_keypoints, image_paths, selected_pairs, feature_type
    )

    # 应用SAR几何约束
    matches_dict = apply_sar_geometric_constraints(
        matches_dict,
        image_angles,
        args.max_azimuth_diff  # 添加这个参数
    )
    return matches_dict


def safe_keypoint_to_dict(kp):
    """将关键点安全转换为字典"""
    return {
        'pt': (float(kp.pt[0]), float(kp.pt[1])) if hasattr(kp, 'pt') else (0.0, 0.0),
        'size': float(kp.size) if hasattr(kp, 'size') and kp.size > 0 else 1.0,
        'angle': float(kp.angle) if hasattr(kp, 'angle') and kp.angle != -1 else 0.0,
        'response': float(kp.response) if hasattr(kp, 'response') else 1.0,
        'octave': int(kp.octave) if hasattr(kp, 'octave') else 0,
        'class_id': int(kp.class_id) if hasattr(kp, 'class_id') else -1
    }


def dict_to_keypoint(kp_dict):
    """将字典转换回关键点"""
    kp = cv2.KeyPoint()
    kp.pt = kp_dict['pt']
    kp.size = kp_dict['size']
    kp.angle = kp_dict['angle']
    kp.response = kp_dict['response']
    kp.octave = kp_dict['octave']
    kp.class_id = kp_dict['class_id']
    return kp


def analyze_match_statistics(matches_dict, min_matches_threshold=5):
    """
    分析匹配统计信息
    显示有多少张不同的图片具有指定数目以上的相同特征点

    Args:
        matches_dict: 匹配字典
        min_matches_threshold: 最小匹配数阈值
    """
    print(f"\n🔍 匹配统计分析 (最小匹配数阈值: {min_matches_threshold})")
    print("=" * 60)

    # 统计每张图像的匹配连接数
    image_connections = {}
    image_match_counts = {}

    for (img1, img2), matches in matches_dict.items():
        match_count = len(matches)

        # 统计满足阈值的匹配对
        if match_count >= min_matches_threshold:
            # 更新图像连接数
            image_connections[img1] = image_connections.get(img1, 0) + 1
            image_connections[img2] = image_connections.get(img2, 0) + 1

            # 记录匹配数量
            if img1 not in image_match_counts:
                image_match_counts[img1] = []
            if img2 not in image_match_counts:
                image_match_counts[img2] = []

            image_match_counts[img1].append((img2, match_count))
            image_match_counts[img2].append((img1, match_count))

    # 统计结果
    total_images = len(image_connections)
    total_pairs = sum(image_connections.values()) // 2  # 因为每对计算了两次

    print(f"📊 总体统计:")
    print(f"   - 具有至少{min_matches_threshold}个匹配点的图像数量: {total_images}")
    print(f"   - 满足条件的图像对数量: {total_pairs}")
    print(f"   - 总匹配对数: {len(matches_dict)}")

    # 显示连接最多的图像
    if image_connections:
        print(f"\n🏆 连接最多的图像 (前10名):")
        sorted_images = sorted(image_connections.items(), key=lambda x: x[1], reverse=True)[:10]

        for i, (img_name, connection_count) in enumerate(sorted_images, 1):
            # 计算平均匹配数
            matches_with_this_image = image_match_counts.get(img_name, [])
            avg_matches = sum(match_count for _, match_count in matches_with_this_image) / len(
                matches_with_this_image) if matches_with_this_image else 0

            print(f"   {i:2d}. {img_name}: {connection_count}个连接, 平均{avg_matches:.1f}个匹配点")

    # 显示最强的匹配对
    print(f"\n💪 最强的匹配对 (前15名):")
    strong_pairs = []

    for (img1, img2), matches in matches_dict.items():
        match_count = len(matches)
        if match_count >= min_matches_threshold:
            strong_pairs.append((img1, img2, match_count))

    # 按匹配数排序
    strong_pairs.sort(key=lambda x: x[2], reverse=True)

    for i, (img1, img2, match_count) in enumerate(strong_pairs[:15], 1):
        print(f"   {i:2d}. {img1} ↔ {img2}: {match_count}个匹配点")

    # 连接性分析
    print(f"\n📈 连接性分析:")
    if total_images > 0:
        connection_counts = list(image_connections.values())
        max_connections = max(connection_counts)
        min_connections = min(connection_counts)
        avg_connections = sum(connection_counts) / len(connection_counts)

        print(f"   - 最大连接数: {max_connections}")
        print(f"   - 最小连接数: {min_connections}")
        print(f"   - 平均连接数: {avg_connections:.1f}")

        # 连接分布
        connection_ranges = {
            "1-2个连接": 0,
            "3-5个连接": 0,
            "6-10个连接": 0,
            "10+个连接": 0
        }

        for count in connection_counts:
            if count <= 2:
                connection_ranges["1-2个连接"] += 1
            elif count <= 5:
                connection_ranges["3-5个连接"] += 1
            elif count <= 10:
                connection_ranges["6-10个连接"] += 1
            else:
                connection_ranges["10+个连接"] += 1

        print(f"   - 连接分布:")
        for range_name, count in connection_ranges.items():
            percentage = (count / total_images) * 100
            print(f"     * {range_name}: {count}张图像 ({percentage:.1f}%)")

    print("=" * 60)

    return {
        'total_images': total_images,
        'total_pairs': total_pairs,
        'image_connections': image_connections,
        'strong_pairs': strong_pairs
    }


print("开始处理MSTAR SAR图像...")
print(f"使用SAR-SIFT特征提取器")
print(f"SAR-SIFT参数: sigma={args.sar_sift_sigma}, ratio={args.sar_sift_ratio}, "
      f"layers={args.sar_sift_layers}, d={args.sar_sift_d}, "
      f"harris_threshold={args.sar_sift_harris_threshold}")
print(
    f"匹配参数: 最大比率={args.max_ratio}, RANSAC迭代={args.ransac_iterations}, RANSAC误差阈值={args.ransac_error_threshold}")
print(f"图像缩放因子: {args.image_scale}")
print(f"GPU设置: 使用GPU={args.use_gpu}, 后端={args.gpu_backend}")  # 添加这一行


def compute_point_error_gradient(point_3d, optimized_poses, matches_dict, keypoints, image_size=(512, 512)):
    """
    计算3D点误差梯度 - 完整版本
    基于重投影误差计算梯度
    """
    gradient = np.zeros(3)
    error_count = 0

    # 相机内参
    focal_length = 600.0 * args.image_scale
    cx, cy = image_size[0] / 2, image_size[1] / 2
    K = np.array([
        [focal_length, 0, cx],
        [0, focal_length, cy],
        [0, 0, 1]
    ])

    # 遍历所有可能观测到这个点的相机
    for (img1, img2), matches in matches_dict.items():
        for match in matches:
            if len(match) < 2:
                continue

            idx1, idx2 = match[0], match[1]

            # 检查两个图像是否都有位姿
            if img1 not in optimized_poses or img2 not in optimized_poses:
                continue

            # 对每个相机计算重投影误差
            for img_name, idx in [(img1, idx1), (img2, idx2)]:
                pose = optimized_poses[img_name]

                # 构建投影矩阵
                R_mat = R.from_quat([pose['qx'], pose['qy'], pose['qz'], pose['qw']]).as_matrix()
                t_vec = np.array([pose['tx'], pose['ty'], pose['tz']])

                # 投影3D点到图像平面
                point_camera = R_mat @ point_3d + t_vec

                # 检查深度
                if point_camera[2] <= 0:
                    continue

                # 投影到图像坐标
                x_proj = focal_length * point_camera[0] / point_camera[2] + cx
                y_proj = focal_length * point_camera[1] / point_camera[2] + cy

                # 获取观测位置
                try:
                    if img_name in keypoints and idx < len(keypoints[img_name]):
                        kp = keypoints[img_name][idx]
                        x_obs, y_obs = kp[0], kp[1]

                        # 计算误差
                        error_x = x_proj - x_obs
                        error_y = y_proj - y_obs

                        # 计算雅可比矩阵（简化版本）
                        # ∂error/∂point = ∂error/∂proj * ∂proj/∂point_camera * ∂point_camera/∂point
                        # ∂proj/∂point_camera = [f/Z, 0, -f*X/Z²; 0, f/Z, -f*Y/Z²]
                        Z = point_camera[2]
                        if Z > 0:
                            jacobian = np.array([
                                [focal_length / Z, 0, -focal_length * point_camera[0] / (Z * Z)],
                                [0, focal_length / Z, -focal_length * point_camera[1] / (Z * Z)]
                            ])

                            # ∂point_camera/∂point = R
                            jacobian_full = jacobian @ R_mat

                            # 梯度 = 2 * error^T * jacobian
                            error = np.array([error_x, error_y])
                            point_gradient = 2 * error @ jacobian_full

                            gradient += point_gradient
                            error_count += 1
                except Exception as e:
                    continue

    # 平均梯度
    if error_count > 0:
        gradient /= error_count

    return gradient


def save_optimized_reconstruction(optimized_poses, optimized_points, point_colors, output_path, matches_dict=None,
                                  keypoints=None):
    """
    保存优化后的重建结果 - 完整版本
    包含详细的2D-3D对应关系
    """
    print(f"保存优化后的重建结果到: {output_path}")
    os.makedirs(output_path, exist_ok=True)

    # 生成合理的点云颜色（如果未提供）
    if not point_colors or len(point_colors) != optimized_points.shape[1]:
        print("生成点云颜色...")
        point_colors = []
        for i in range(optimized_points.shape[1]):
            # 基于点的高度生成颜色
            height = optimized_points[1, i]
            if height > args.target_base_height + args.target_height * 0.6:
                color = [255, 150, 100]  # 高部位 - 偏红
            elif height > args.target_base_height:
                color = [200, 200, 150]  # 中部 - 偏黄
            else:
                color = [150, 200, 255]  # 低部位 - 偏蓝
            point_colors.append(color)

    # 保存相机文件
    cameras_file = os.path.join(output_path, "cameras.txt")
    with open(cameras_file, 'w') as f:
        f.write("# Camera list with one line of data per camera:\n")
        f.write("#   CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]\n")
        f.write("# Number of cameras: 1\n")

        upscaled_width = int(128 * args.image_scale)
        upscaled_height = int(128 * args.image_scale)
        focal_length = 600.0 * args.image_scale

        f.write(
            f"1 PINHOLE {upscaled_width} {upscaled_height} {focal_length} {focal_length} {upscaled_width / 2} {upscaled_height / 2}\n")

    # 保存图像位姿和2D-3D对应关系
    images_file = os.path.join(output_path, "images.txt")
    with open(images_file, 'w') as f:
        f.write("# Image list with two lines of data per image:\n")
        f.write("#   IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n")
        f.write("#   POINTS2D[] as (X, Y, POINT3D_ID)\n")
        f.write(f"# Number of images: {len(optimized_poses)}\n")

        # 创建图像ID映射
        image_id_map = {}
        image_id = 1
        for img_name in optimized_poses.keys():
            image_id_map[img_name] = image_id
            image_id += 1

        # 创建点跟踪信息
        point_tracks = {}
        if matches_dict is not None and keypoints is not None:
            point_tracks = build_point_tracks(optimized_points, optimized_poses, matches_dict, keypoints)

        # 写入每个图像的位姿和观测
        for img_name, pose in optimized_poses.items():
            image_id = image_id_map[img_name]

            # 写入位姿
            f.write(f"{image_id} {pose['qw']:.6f} {pose['qx']:.6f} {pose['qy']:.6f} {pose['qz']:.6f} "
                    f"{pose['tx']:.6f} {pose['ty']:.6f} {pose['tz']:.6f} 1 {img_name}\n")

            # 写入2D观测
            observations = []
            if img_name in point_tracks:
                for point2d_idx, point3d_id in point_tracks[img_name]:
                    # 获取2D点坐标
                    if img_name in keypoints and point2d_idx < len(keypoints[img_name]):
                        kp = keypoints[img_name][point2d_idx]
                        x, y = kp[0], kp[1]
                        observations.append(f"{x:.2f} {y:.2f} {point3d_id}")

            if observations:
                f.write(" ".join(observations) + "\n")
            else:
                f.write("\n")  # 空行

    # 保存3D点
    points_file = os.path.join(output_path, "points3D.txt")
    with open(points_file, 'w') as f:
        f.write("# 3D point list with one line of data per point:\n")
        f.write("#   POINT3D_ID, X, Y, Z, R, G, B, ERROR, TRACK[] as (IMAGE_ID, POINT2D_IDX)\n")

        if optimized_points.shape[1] > 0:
            f.write(f"# Number of points: {optimized_points.shape[1]}\n")

            # 创建点跟踪信息（反向映射）
            point_observations = {}
            if point_tracks:
                for img_name, tracks in point_tracks.items():
                    image_id = image_id_map[img_name]
                    for point2d_idx, point3d_id in tracks:
                        if point3d_id not in point_observations:
                            point_observations[point3d_id] = []
                        point_observations[point3d_id].append((image_id, point2d_idx))

            for i in range(optimized_points.shape[1]):
                x, y, z = optimized_points[:, i]
                r, g, b = point_colors[i] if i < len(point_colors) else (255, 200, 150)

                # 构建跟踪信息
                track_info = ""
                if i in point_observations:
                    tracks = []
                    for image_id, point2d_idx in point_observations[i]:
                        tracks.append(f"{image_id} {point2d_idx}")
                    track_info = " ".join(tracks)

                f.write(f"{i + 1} {x:.6f} {y:.6f} {z:.6f} {r} {g} {b} 0 {track_info}\n")
        else:
            f.write("# Number of points: 0\n")

    # 保存PLY格式点云
    ply_file = os.path.join(output_path, "optimized_point_cloud.ply")
    save_point_cloud_ply(optimized_points, point_colors, ply_file)

    print(f"优化重建结果已保存: {len(optimized_poses)} 相机, {optimized_points.shape[1]} 3D点")
    
    # 打印优化后的相机位置
    print_camera_positions(optimized_poses, "SAR优化后的相机位置")


def build_point_tracks(points_3d, camera_poses, matches_dict, keypoints, reprojection_threshold=5.0):
    """
    构建2D-3D点对应关系跟踪
    """
    point_tracks = {}  # {image_name: [(point2d_idx, point3d_id), ...]}

    # 相机内参
    focal_length = 600.0 * args.image_scale
    cx, cy = 256 * args.image_scale, 256 * args.image_scale

    # 遍历所有匹配对
    point3d_id = 0
    for (img1, img2), matches in matches_dict.items():
        if img1 not in camera_poses or img2 not in camera_poses:
            continue

        pose1 = camera_poses[img1]
        pose2 = camera_poses[img2]

        # 构建投影矩阵
        R1 = R.from_quat([pose1['qx'], pose1['qy'], pose1['qz'], pose1['qw']]).as_matrix()
        t1 = np.array([pose1['tx'], pose1['ty'], pose1['tz']])
        R2 = R.from_quat([pose2['qx'], pose2['qy'], pose2['qz'], pose2['qw']]).as_matrix()
        t2 = np.array([pose2['tx'], pose2['ty'], pose2['tz']])

        for match in matches:
            if len(match) < 2:
                continue

            idx1, idx2 = match[0], match[1]

            # 检查点索引是否有效
            if (img1 not in keypoints or idx1 >= len(keypoints[img1]) or
                    img2 not in keypoints or idx2 >= len(keypoints[img2])):
                continue

            # 如果还有3D点，检查重投影误差
            if points_3d.shape[1] > point3d_id:
                point_3d = points_3d[:, point3d_id]

                # 计算在两个视图中的重投影误差
                error1 = compute_reprojection_error(point_3d, R1, t1, keypoints[img1][idx1], focal_length, cx, cy)
                error2 = compute_reprojection_error(point_3d, R2, t2, keypoints[img2][idx2], focal_length, cx, cy)

                # 如果重投影误差在阈值内，建立跟踪
                if error1 < reprojection_threshold and error2 < reprojection_threshold:
                    if img1 not in point_tracks:
                        point_tracks[img1] = []
                    if img2 not in point_tracks:
                        point_tracks[img2] = []

                    point_tracks[img1].append((idx1, point3d_id))
                    point_tracks[img2].append((idx2, point3d_id))

                    point3d_id += 1

    return point_tracks


def compute_reprojection_error(point_3d, R, t, keypoint, focal_length, cx, cy):
    """
    计算重投影误差
    """
    # 变换到相机坐标系
    point_camera = R @ point_3d + t

    if point_camera[2] <= 0:
        return float('inf')

    # 投影到图像平面
    x_proj = focal_length * point_camera[0] / point_camera[2] + cx
    y_proj = focal_length * point_camera[1] / point_camera[2] + cy

    # 计算误差
    error = np.sqrt((x_proj - keypoint[0]) ** 2 + (y_proj - keypoint[1]) ** 2)

    return error
def sar_bundle_adjustment(camera_poses, points_3d, matches_dict, sar_height, angle_info, max_iterations=50):
    """
    SAR优化的光束法平差 - 考虑SAR几何约束
    """
    print("执行SAR优化的光束法平差...")

    if points_3d.shape[1] == 0:
        print("警告: 没有3D点可供优化")
        return camera_poses, points_3d

    # ========== 新增：计算每个相机的理论高度（基于俯视角） ==========
    print("  计算自适应高度约束...")
    expected_heights = {}
    for img_name, pose in camera_poses.items():
        if img_name in angle_info:
            dep_angle = angle_info[img_name]['depression_angle']
            dep_rad = np.deg2rad(dep_angle)
            
            # Sphere模式的理论高度计算
            # R = sar_height / sin(depression_angle)
            # z = R * cos(depression_angle)
            R0 = sar_height / np.sin(dep_rad)
            expected_z = R0 * np.cos(dep_rad)
            expected_heights[img_name] = expected_z
            
            if len(expected_heights) == 1:  # 只打印一次示例
                print(f"    示例: 俯视角{dep_angle:.1f}° → 理论高度 {expected_z:.1f}m")
        else:
            expected_heights[img_name] = sar_height
    
    if expected_heights:
        heights = list(expected_heights.values())
        print(f"  ✅ 理论高度范围: {min(heights):.1f}m ~ {max(heights):.1f}m")
        print(f"     (原固定约束: {sar_height * 0.8:.1f}m ~ {sar_height * 1.2:.1f}m)")
    # ========== 新增结束 ==========

    # 转换为合适的格式
    optimized_poses = camera_poses.copy()

    # 确保points_3d是正确形状
    if points_3d.shape[0] != 3:
        points_3d = points_3d.T

    optimized_points = points_3d.copy()

    # 简单的梯度下降优化
    learning_rate_pose = 0.01
    learning_rate_point = 0.001

    for iteration in range(max_iterations):
        total_error = 0
        point_count = 0

        # 优化相机位姿
        for img_name, pose in optimized_poses.items():
            if img_name not in matches_dict:
                continue

            # 获取该图像的所有匹配点
            image_matches = []
            for (img1, img2), matches in matches_dict.items():
                if img1 == img_name or img2 == img_name:
                    image_matches.extend(matches)

            if not image_matches:
                continue

            # 计算重投影误差梯度
            error_gradient = compute_reprojection_error_gradient(
                pose, optimized_points, image_matches, keypoints, img_name
            )

            # 更新位姿（使用自适应约束）
            pose['tx'] -= learning_rate_pose * error_gradient[0]
            pose['ty'] -= learning_rate_pose * error_gradient[1]  # ✅ 移除0.5系数，允许高度自由变化
            pose['tz'] -= learning_rate_pose * error_gradient[2]

            # ✅ 自适应高度约束（基于理论高度，允许±40%变化）
            if img_name in expected_heights:
                expected_height = expected_heights[img_name]
                min_height = expected_height * 0.6  # 允许-40%
                max_height = expected_height * 1.4  # 允许+40%
                pose['ty'] = max(min_height, min(pose['ty'], max_height))
                
                # 调试输出（第一次迭代时打印前3个相机）
                if iteration == 0 and list(optimized_poses.keys()).index(img_name) < 3:
                    print(f"      {img_name}: 理论={expected_height:.0f}m, 约束[{min_height:.0f}, {max_height:.0f}]m")
            else:
                # 回退到宽松的固定约束（如果没有角度信息）
                pose['ty'] = max(sar_height * 0.3, min(pose['ty'], sar_height * 3.0))

        # 优化3D点
        for i in range(optimized_points.shape[1]):
            point_gradient = compute_point_error_gradient(
                optimized_points[:, i], optimized_poses, matches_dict, keypoints
            )

            optimized_points[0, i] -= learning_rate_point * point_gradient[0]
            optimized_points[1, i] -= learning_rate_point * point_gradient[1]  # ✅ 移除0.3系数
            optimized_points[2, i] -= learning_rate_point * point_gradient[2]

            # ✅ 合理的点云高度约束
            # 假设：目标在地面(y=0)附近，高度不超过100m
            # 允许轻微的地下点（如-10m）来容忍误差
            optimized_points[1, i] = max(-10, min(optimized_points[1, i], 100))

        # 应用方位角平滑约束
        optimized_poses = apply_azimuth_smoothing(optimized_poses, angle_info)

        if iteration % 10 == 0:
            avg_error = total_error / max(point_count, 1)
            print(f"  迭代 {iteration}: 平均误差 = {avg_error:.6f}")

    print(f"SAR BA完成: 优化了 {len(optimized_poses)} 个位姿和 {optimized_points.shape[1]} 个3D点")
    return optimized_poses, optimized_points


def compute_reprojection_error_gradient(pose, points_3d, matches, keypoints, image_name):
    """
    计算重投影误差梯度
    """
    # 简化的梯度计算
    gradient = np.zeros(3)

    # 构建投影矩阵
    R_mat = R.from_quat([pose['qx'], pose['qy'], pose['qz'], pose['qw']]).as_matrix()
    t_vec = np.array([pose['tx'], pose['ty'], pose['tz']])

    # 相机内参（使用升采样后的尺寸）
    focal_length = 600.0 * args.image_scale
    cx = 256 * args.image_scale
    cy = 256 * args.image_scale

    for match in matches[:10]:  # 使用部分匹配点计算梯度
        try:
            # 获取3D点
            point_3d = points_3d[:, match[1] if image_name in match[0] else match[0]]

            # 投影到图像平面
            point_camera = R_mat @ point_3d + t_vec
            if point_camera[2] <= 0:  # 点在相机后面
                continue

            x_proj = focal_length * point_camera[0] / point_camera[2] + cx
            y_proj = focal_length * point_camera[1] / point_camera[2] + cy

            # 获取实际观测位置
            if image_name in keypoints:
                kp = keypoints[image_name][match[0] if image_name == match[0] else match[1]]
                x_obs, y_obs = kp[0], kp[1]

                # 计算误差
                error_x = x_proj - x_obs
                error_y = y_proj - y_obs

                # 简化的梯度近似
                gradient[0] += error_x * 0.01
                gradient[1] += error_y * 0.01
                gradient[2] += (error_x + error_y) * 0.005

        except Exception as e:
            continue

    return gradient


def apply_azimuth_smoothing(poses, angle_info):
    """
    应用方位角平滑约束
    """
    # 按方位角排序
    sorted_images = sorted(poses.keys(),
                           key=lambda x: angle_info[x]['azimuth_angle'])

    if len(sorted_images) < 3:
        return poses

    # 对位置进行平滑
    for i in range(1, len(sorted_images) - 1):
        prev_img = sorted_images[i - 1]
        curr_img = sorted_images[i]
        next_img = sorted_images[i + 1]

        prev_pose = poses[prev_img]
        curr_pose = poses[curr_img]
        next_pose = poses[next_img]

        # 位置平滑
        curr_pose['tx'] = (prev_pose['tx'] + curr_pose['tx'] + next_pose['tx']) / 3
        curr_pose['tz'] = (prev_pose['tz'] + curr_pose['tz'] + next_pose['tz']) / 3

        # 保持圆形轨道约束
        radius = np.sqrt(curr_pose['tx'] ** 2 + curr_pose['tz'] ** 2)
        expected_radius = args.sar_height / np.tan(np.radians(angle_info[curr_img]['depression_angle']))

        # 调整到期望半径
        if radius > 0:
            scale = expected_radius / radius
            curr_pose['tx'] *= scale
            curr_pose['tz'] *= scale

    return poses

def load_reconstruction(reconstruction_path):
    """
    加载COLMAP重建结果
    """
    print(f"加载重建结果: {reconstruction_path}")

    reconstruction = {
        'cameras': {},
        'images': {},
        'points': {},
        'observations': {}
    }

    # 加载相机参数
    cameras_file = os.path.join(reconstruction_path, "cameras.txt")
    if os.path.exists(cameras_file):
        with open(cameras_file, 'r') as f:
            for line in f:
                if line.startswith('#'):
                    continue
                parts = line.strip().split()
                if len(parts) >= 4:
                    camera_id = int(parts[0])
                    model = parts[1]
                    width = int(parts[2])
                    height = int(parts[3])
                    params = list(map(float, parts[4:]))
                    reconstruction['cameras'][camera_id] = {
                        'model': model,
                        'width': width,
                        'height': height,
                        'params': params
                    }

    # 加载图像位姿
    images_file = os.path.join(reconstruction_path, "images.txt")
    if os.path.exists(images_file):
        with open(images_file, 'r') as f:
            lines = f.readlines()
            i = 0
            while i < len(lines):
                line = lines[i].strip()
                if line.startswith('#') or not line:
                    i += 1
                    continue

                parts = line.split()
                if len(parts) >= 10:
                    image_id = int(parts[0])
                    qw, qx, qy, qz = map(float, parts[1:5])
                    tx, ty, tz = map(float, parts[5:8])
                    camera_id = int(parts[8])
                    image_name = parts[9]

                    reconstruction['images'][image_name] = {
                        'image_id': image_id,
                        'qw': qw, 'qx': qx, 'qy': qy, 'qz': qz,
                        'tx': tx, 'ty': ty, 'tz': tz,
                        'camera_id': camera_id
                    }

                i += 1

    # 加载3D点
    points_file = os.path.join(reconstruction_path, "points3D.txt")
    if os.path.exists(points_file):
        with open(points_file, 'r') as f:
            for line in f:
                if line.startswith('#'):
                    continue
                parts = line.strip().split()
                if len(parts) >= 7:
                    point_id = int(parts[0])
                    x, y, z = map(float, parts[1:4])
                    r, g, b = map(int, parts[4:7])
                    reconstruction['points'][point_id] = {
                        'x': x, 'y': y, 'z': z,
                        'r': r, 'g': g, 'b': b
                    }

    print(f"重建结果: {len(reconstruction['cameras'])} 相机, "
          f"{len(reconstruction['images'])} 图像, "
          f"{len(reconstruction['points'])} 3D点")

    return reconstruction


def print_camera_positions(camera_poses, title="相机位置信息"):
    """
    打印所有相机位置信息
    
    Args:
        camera_poses: 相机位姿字典，包含 'qw', 'qx', 'qy', 'qz', 'tx', 'ty', 'tz'
        title: 打印标题
    """
    print("\n" + "="*80)
    print(f"{title} (COLMAP坐标系: X=右, Y=下, Z=前, 高度正值在Y轴负方向)")
    print("="*80)
    
    for i, (img_name, pose) in enumerate(camera_poses.items()):
        # 从四元数和平移向量计算相机位置
        # COLMAP格式：qvec = [qw, qx, qy, qz], tvec = [tx, ty, tz]
        # 相机位置 = -R.T @ t，其中R是从四元数计算的旋转矩阵
        
        # 构建四元数 [w, x, y, z]
        qw, qx, qy, qz = pose['qw'], pose['qx'], pose['qy'], pose['qz']
        qvec = np.array([qw, qx, qy, qz])
        
        # 从四元数计算旋转矩阵
        # 使用scipy的Rotation类
        rotation = R.from_quat([qx, qy, qz, qw])  # scipy使用[x,y,z,w]格式
        R_matrix = rotation.as_matrix()
        
        # 平移向量
        tvec = np.array([pose['tx'], pose['ty'], pose['tz']])
        
        # 计算相机位置：P_camera = -R.T @ t
        camera_position = -R_matrix.T @ tvec
        camera_position = camera_position.flatten()
        
        # 计算高度
        # COLMAP坐标系：Y轴向下，高度正值在Y轴负方向
        # 如果Y坐标是负数，说明相机在Y轴负方向（上方），高度应该是正数
        # 如果Y坐标是正数，说明相机在Y轴正方向（下方），高度应该是负数
        # 所以：高度 = -Y（这样Y为负时高度为正，Y为正时高度为负）
        height = -camera_position[1]
        
        print(f"相机 {i+1:3d}/{len(camera_poses)}: {img_name}")
        print(f"  位置: X={camera_position[0]:12.2f}, Y={camera_position[1]:12.2f}, Z={camera_position[2]:12.2f}")
        if height >= 0:
            print(f"  高度: {height:12.2f} (Y轴负方向，相机在上方)")
        else:
            print(f"  高度: {abs(height):12.2f} (Y轴正方向，相机在下方)")
        print(f"  距离原点: {np.linalg.norm(camera_position):12.2f}")
    
    print("="*80 + "\n")


def save_sar_reconstruction(optimized_poses, optimized_points, point_colors, output_path):
    """
    保存SAR优化的重建结果
    """
    print(f"保存SAR重建结果到: {output_path}")
    os.makedirs(output_path, exist_ok=True)

    # 保存相机文件
    cameras_file = os.path.join(output_path, "cameras.txt")
    with open(cameras_file, 'w') as f:
        f.write("# Camera list with one line of data per camera:\n")
        f.write("#   CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]\n")
        f.write("# Number of cameras: 1\n")

        # 使用升采样后的图像尺寸
        upscaled_width = int(128 * args.image_scale)
        upscaled_height = int(128 * args.image_scale)
        focal_length = 600.0 * args.image_scale

        f.write(
            f"1 PINHOLE {upscaled_width} {upscaled_height} {focal_length} {focal_length} {upscaled_width / 2} {upscaled_height / 2}\n")

    # 保存图像位姿
    images_file = os.path.join(output_path, "images.txt")
    with open(images_file, 'w') as f:
        f.write("# Image list with two lines of data per image:\n")
        f.write("#   IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n")
        f.write("#   POINTS2D[] as (X, Y, POINT3D_ID)\n")
        f.write(f"# Number of images: {len(optimized_poses)}\n")

        image_id = 1
        for img_name, pose in optimized_poses.items():
            f.write(f"{image_id} {pose['qw']:.6f} {pose['qx']:.6f} {pose['qy']:.6f} {pose['qz']:.6f} "
                    f"{pose['tx']:.6f} {pose['ty']:.6f} {pose['tz']:.6f} 1 {img_name}\n")

            # 这里可以添加2D-3D对应关系（需要从匹配中提取）
            f.write("\n")  # 空的特征点行
            image_id += 1

    # 保存3D点
    points_file = os.path.join(output_path, "points3D.txt")
    with open(points_file, 'w') as f:
        f.write("# 3D point list with one line of data per point:\n")
        f.write("#   POINT3D_ID, X, Y, Z, R, G, B, ERROR, TRACK[] as (IMAGE_ID, POINT2D_IDX)\n")

        if optimized_points.shape[1] > 0:
            f.write(f"# Number of points: {optimized_points.shape[1]}\n")
            for i in range(optimized_points.shape[1]):
                x, y, z = optimized_points[:, i]
                r, g, b = point_colors[i] if i < len(point_colors) else (255, 200, 150)
                f.write(f"{i + 1} {x:.6f} {y:.6f} {z:.6f} {r} {g} {b} 0\n")
        else:
            f.write("# Number of points: 0\n")

    # 同时保存PLY格式点云
    ply_file = os.path.join(output_path, "sparse_point_cloud.ply")
    save_point_cloud_ply(optimized_points, point_colors, ply_file)

    print(f"SAR重建结果已保存: {len(optimized_poses)} 相机, {optimized_points.shape[1]} 3D点")
    
    # 打印所有相机位置
    print_camera_positions(optimized_poses, "SFM重建后的相机位置")

if __name__ == "__main__":
    # 多进程保护 - 必须放在最外层
    mp.freeze_support()  # 对于Windows平台很重要

    print("开始处理MSTAR SAR图像...")
    print(f"使用多进程SAR-SIFT特征提取器")

    # 创建必要的目录结构
    os.makedirs(args.source_path + "/sparse/0", exist_ok=True)
    os.makedirs(args.source_path + "/images", exist_ok=True)
    os.makedirs(args.source_path + "/input", exist_ok=True)

    # 将输入图像复制到input目录
    input_dir = args.source_path + "/input_images"  # 假设原始图像在这里
    if os.path.exists(input_dir):
        for img_file in os.listdir(input_dir):
            if img_file.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.tif')):
                shutil.copy2(os.path.join(input_dir, img_file),
                             os.path.join(args.source_path, "input", img_file))
                # 同时复制到images目录
                shutil.copy2(os.path.join(input_dir, img_file),
                             os.path.join(args.source_path, "images", img_file))

    # 收集所有图像文件并解析角度信息
    image_files = []
    angle_info = {}
    for ext in ['*.jpg', '*.jpeg', '*.png', '*.tif', '*.tiff']:
        for img_path in glob.glob(os.path.join(args.source_path, "input", ext)):
            image_files.append(img_path)
            img_name = os.path.basename(img_path)
            depression_angle, azimuth_angle = parse_mstar_filename(img_name)
            angle_info[img_name] = {
                'depression_angle': depression_angle,
                'azimuth_angle': azimuth_angle
            }

    print(f"找到 {len(image_files)} 张SAR图像")

    # 第一步：尝试使用自定义特征运行COLMAP SfM流程
    sfm_success = False
    camera_poses = {}  # 在这里初始化 camera_poses
    if not args.skip_matching:
        # 使用多进程提取特征
        keypoints, descriptors, original_keypoints = extract_features_multiprocess(image_files, "SAR_SIFT")

        # 保存特征点可视化图像
        if args.save_feature_images and original_keypoints:
            keypoints_dir = os.path.join(args.source_path, "feature_keypoints")
            visualize_and_save_keypoints(image_files, original_keypoints, keypoints_dir, args.max_feature_images)

        # 如果特征提取成功，进行匹配
        if len(keypoints) > 0:
            # 选择有希望的图像对进行匹配
            selected_pairs = select_promising_pairs(image_files)
            # 使用自定义匹配器进行匹配
            matches_dict = match_features_sar_optimized(keypoints, descriptors, original_keypoints, image_files,
                                                        "SAR_SIFT")

            # 添加匹配统计分析
            if matches_dict:
                match_stats = analyze_match_statistics(matches_dict, min_matches_threshold=5)
            else:
                print("❌ 没有找到任何匹配对")
                match_stats = None

            # 在调用 create_colmap_database_from_features 后添加检查
            db_path, image_ids = create_colmap_database_from_features(args.source_path, keypoints, descriptors,
                                                                      args.camera, "SAR_SIFT")

            angle_info = {}
            for img_path in image_files:
                img_name = os.path.basename(img_path)
                depression_angle, azimuth_angle = parse_mstar_filename(img_name)
                angle_info[img_name] = {
                    'depression_angle': depression_angle,
                    'azimuth_angle': azimuth_angle
                }

            if len(matches_dict) > 0:
                # 使用SAR优化的重建流程
                sfm_success = run_sar_sparse_reconstruction(
                    db_path,
                    os.path.join(args.source_path, "input"),
                    keypoints,  # 确保这个变量存在
                    matches_dict,
                    angle_info
                )
            else:
                print("❌ 没有足够的匹配对，无法进行重建")
                sfm_success = False
        else:
            print("❌ 特征提取失败，无法进行匹配和重建")
            sfm_success = False

        if not sfm_success:
            print("COLMAP SfM流程失败，将使用基于SAR几何的合成位姿")
    else:
        print("跳过特征匹配和SfM")

    # 在主程序中找到这部分代码并修复：
    if not sfm_success:
        # 如果SfM失败，才使用合成点云
        print("SfM重建失败，使用基于几何的合成点云")
        points_3d, point_colors = generate_sar_point_cloud(
            image_files, args.sar_height, args.target_height, args.target_base_height,
            args.shadow_height, args.background_height, args.target_density, args.background_density,
            args.point_cloud_scale
        )
    else:
        # SfM成功，点云已经在run_sar_sparse_reconstruction中生成
        # 我们需要从重建结果中加载点云
        print("SfM重建成功，从重建结果加载点云")
        reconstruction = load_reconstruction(os.path.join(args.source_path, "sparse/0"))

        if reconstruction['points']:
            points_list = []
            colors_list = []
            for point_id, point_data in reconstruction['points'].items():
                points_list.append([point_data['x'], point_data['y'], point_data['z']])
                colors_list.append([point_data['r'], point_data['g'], point_data['b']])
            points_3d = np.array(points_list).T
            point_colors = colors_list
        else:
            print("重建结果中没有点云，使用合成点云")
            points_3d, point_colors = generate_sar_point_cloud(
                image_files, args.sar_height, args.target_height, args.target_base_height,
                args.shadow_height, args.background_height, args.target_density, args.background_density,
                args.point_cloud_scale
            )
    # 保存点云为PLY格式
    ply_path = args.source_path + "/sparse/0/point_cloud.ply"
    save_point_cloud_ply(points_3d, point_colors, ply_path)

    # 第三步：如果SfM失败，创建基于SAR几何的合成位姿
    if not sfm_success:
        print("使用基于SAR几何的合成相机位姿...")
        camera_poses = create_synthetic_camera_poses(
            image_files, args.sar_height, args.depression_angle_scale, args.point_cloud_scale
        )

        # 创建COLMAP文件 - 使用新的保存函数替换
        save_sar_reconstruction(camera_poses, points_3d, point_colors,
                                os.path.join(args.source_path, "sparse", "0"))

        print("基于SAR几何的合成重建完成")
    else:
        print("SfM重建成功完成")
        
        # 加载重建结果并打印相机位置
        try:
            reconstruction = load_reconstruction(os.path.join(args.source_path, "sparse/0"))
            
            # 提取相机位姿
            camera_poses = {}
            for img_name, img_data in reconstruction['images'].items():
                camera_poses[img_name] = {
                    'qw': img_data['qw'], 'qx': img_data['qx'],
                    'qy': img_data['qy'], 'qz': img_data['qz'],
                    'tx': img_data['tx'], 'ty': img_data['ty'], 'tz': img_data['tz']
                }
            
            # 打印相机位置
            print_camera_positions(camera_poses, "SFM重建后的相机位置")
        except Exception as e:
            print(f"⚠️ 无法加载重建结果以打印相机位置: {e}")

    print("MSTAR SAR图像转换完成!")
    # 在当前SFM流程后添加SAR优化部分
    if sfm_success:
        print("应用SAR专用的后处理优化...")

        try:
            # 加载SFM结果
            reconstruction = load_reconstruction(os.path.join(args.source_path, "sparse/0"))

            # 提取相机位姿
            camera_poses = {}
            for img_name, img_data in reconstruction['images'].items():
                camera_poses[img_name] = {
                    'qw': img_data['qw'], 'qx': img_data['qx'],
                    'qy': img_data['qy'], 'qz': img_data['qz'],
                    'tx': img_data['tx'], 'ty': img_data['ty'], 'tz': img_data['tz']
                }
            
            # 打印优化前的相机位置
            print_camera_positions(camera_poses, "SAR优化前的相机位置")

            # 提取3D点
            if reconstruction['points']:
                points_list = []
                for point_id, point_data in reconstruction['points'].items():
                    points_list.append([point_data['x'], point_data['y'], point_data['z']])
                points_3d = np.array(points_list).T
            else:
                points_3d = np.zeros((3, 0))

            # 收集角度信息
            angle_info = {}
            for img_path in image_files:
                img_name = os.path.basename(img_path)
                depression_angle, azimuth_angle = parse_mstar_filename(img_name)
                angle_info[img_name] = {
                    'depression_angle': depression_angle,
                    'azimuth_angle': azimuth_angle
                }

            # 应用SAR几何约束 - 使用改进的函数
            optimized_poses, optimized_points = sar_bundle_adjustment(
                camera_poses,
                points_3d,
                matches_dict,
                args.sar_height,
                angle_info
            )

            # 保存优化后的结果 - 使用改进的保存函数
            save_optimized_reconstruction(
                optimized_poses,
                optimized_points,
                point_colors,  # 从重建结果中获取的颜色
                os.path.join(args.source_path, "sparse/1"),
                matches_dict,
                keypoints
            )

            print("✅ SAR优化完成")
            
            # 打印优化后的相机位置（已在save_optimized_reconstruction中打印，这里可选）
            # print_camera_positions(optimized_poses, "SAR优化后的相机位置")

        except Exception as e:
            print(f"❌ SAR优化失败: {e}")
            import traceback

            traceback.print_exc()


        except Exception as e:
            print(f"❌ SAR优化失败: {e}")
            import traceback

            traceback.print_exc()
            print("将使用原始重建结果")
            # 如果优化失败，复制原始结果到sparse/1
            import shutil

            src_dir = os.path.join(args.source_path, "sparse/0")
            dst_dir = os.path.join(args.source_path, "sparse/1")
            if os.path.exists(src_dir):
                shutil.copytree(src_dir, dst_dir, dirs_exist_ok=True)