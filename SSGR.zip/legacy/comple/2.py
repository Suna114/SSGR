import os
import logging
from argparse import ArgumentParser
import shutil
import glob
import sqlite3
import cv2
import numpy as np
from PIL import Image
import re
from scipy.spatial.transform import Rotation as R
import sys
from sar_sift_module import sar_sift_detect_and_compute
from custom_matcher import CustomMatcher  # 导入自定义匹配器
import concurrent.futures
from threading import Lock
import subprocess
from sar_sparse_reconstruction import SARSparseReconstructor
import multiprocessing as mp
from multiprocessing import Pool, Manager, cpu_count

# SAR图像专用转换器
parser = ArgumentParser("SAR Image converter")
parser.add_argument("--no_gpu", action='store_true',
                    help="完全禁用GPU（包括特征提取和COLMAP）")
parser.add_argument("--use_cpu", action='store_true', help="强制使用CPU（默认自动使用GPU加速）")
parser.add_argument("--skip_matching", action='store_true')
parser.add_argument("--source_path", "-s", required=True, type=str)
parser.add_argument("--camera", default="OPENCV", type=str)
parser.add_argument("--colmap_executable", default="", type=str)
parser.add_argument("--resize", action="store_true")
parser.add_argument("--magick_executable", default="", type=str)
parser.add_argument("--sar_height", type=float, default=10.0, help="SAR图像飞行高度（米）")
parser.add_argument("--target_height", type=float, default=3.0, help="目标高度（米）")
parser.add_argument("--target_base_height", type=float, default=0.0, help="目标基础高度（米）")
parser.add_argument("--shadow_height", type=float, default=0.0, help="阴影高度（米）- 现在视为地面")
parser.add_argument("--background_height", type=float, default=0.0, help="背景高度（米）")
parser.add_argument("--target_density", type=float, default=1.5, help="目标点云密度（0-1）")
parser.add_argument("--background_density", type=float, default=0.5, help="背景点云密度（0-1）")
parser.add_argument("--feature_type", type=str, default="SAR_SIFT",
                    choices=["SAR_SIFT"],  # 只保留SAR_SIFT
                    help="特征提取器类型")
parser.add_argument("--preprocess_sar", action="store_true", help="对SAR图像进行预处理（去噪、增强）")
parser.add_argument("--speckle_filter", action="store_true", help="应用斑点噪声滤波")
parser.add_argument("--contrast_enhance", action="store_true", help="应用对比度增强")
parser.add_argument("--point_cloud_scale", type=float, default=3.0, help="点云缩放因子")
parser.add_argument("--depression_angle_scale", type=float, default=1.0, help="俯视角缩放因子")
parser.add_argument("--force_sfm", action="store_true", help="强制使用SfM，即使特征匹配失败")
parser.add_argument("--max_features", type=int, default=50000, help="最大特征点数量")
parser.add_argument("--peak_threshold", type=float, default=0.001, help="SIFT峰值阈值")
parser.add_argument("--edge_threshold", type=float, default=2.0, help="SIFT边缘阈值")
parser.add_argument("--min_scale", type=float, default=0.3, help="最小尺度")
parser.add_argument("--max_ratio", type=float, default=0.8, help="匹配最大比率")
parser.add_argument("--clean_database", action="store_true", help="清理现有数据库重新开始")
parser.add_argument("--use_spatial_matching", action="store_true", help="使用空间匹配（知道相机大致位置）")
parser.add_argument("--image_scale", type=float, default=4.0, help="图像缩放因子，用于放大低分辨率图像")
parser.add_argument("--sar_sift_sigma", type=float, default=2.0, help="SAR-SIFT初始尺度")
parser.add_argument("--sar_sift_ratio", type=float, default=2 ** (1 / 3.), help="SAR-SIFT尺度比率")
parser.add_argument("--sar_sift_layers", type=int, default=8, help="SAR-SIFT尺度层数")
parser.add_argument("--sar_sift_d", type=float, default=0.04, help="SAR-SIFT Harris参数")
parser.add_argument("--sar_sift_harris_threshold", type=float, default=0.8, help="SAR-SIFT Harris函数阈值")
# 可视化参数 - 通过反向逻辑实现默认保存
parser.add_argument("--no_save_feature_images", action="store_true",
                    help="不保存特征点可视化图像")
parser.add_argument("--no_save_match_images", action="store_true",
                    help="不保存特征点匹配可视化图像")
parser.add_argument("--max_feature_images", type=int, default=20,
                    help="最多保存的特征点图像数量，默认20")
parser.add_argument("--max_match_pairs", type=int, default=15,
                    help="最多保存的匹配图像对数，默认15")
parser.add_argument("--ransac_iterations", type=int, default=800, help="RANSAC迭代次数")
parser.add_argument("--ransac_error_threshold", type=float, default=1.0, help="RANSAC误差阈值")
parser.add_argument("--gpu_backend", type=str, default="cupy",
                    choices=["cupy", "pytorch"],
                    help="GPU加速后端，默认cupy")
parser.add_argument("--num_threads", type=int, default=-1,
                    help="特征提取线程数，-1=自动设置，0=单线程，>0=指定线程数")
parser.add_argument("--max_pairs_per_image", type=int, default=30,
                    help="每张图像最多匹配的图像数")
parser.add_argument("--max_azimuth_diff", type=int, default=45,
                    help="最大方位角差异（度）")
parser.add_argument("--use_parallel_match", action="store_true",
                    help="使用并行匹配")
parser.add_argument("--parallel_workers", type=int, default=4,
                    help="并行匹配工作线程数")
parser.add_argument("--use_processes", action="store_true",
                    help="使用进程而不是线程进行并行匹配")
args = parser.parse_args()

# 在参数解析后设置正向标志
args.save_feature_images = not args.no_save_feature_images
args.save_match_images = not args.no_save_match_images

# 创建自定义匹配器实例
custom_matcher = CustomMatcher(
    max_ratio=args.max_ratio,
    ransac_iterations=args.ransac_iterations,
    ransac_error_threshold=args.ransac_error_threshold,
    use_gpu=not args.use_cpu  # 使用统一的GPU设置
)

# 打印可视化设置
print(f"可视化设置: 保存特征点图 = {args.save_feature_images}, 保存匹配图 = {args.save_match_images}")
# 在参数解析后立即添加
if args.gpu_backend == "cupy":
    print("⚠️ 检测到CuPy后端，由于已知的内存问题，自动切换到PyTorch后端")
    args.gpu_backend = "pytorch"


# 统一的GPU检测和设置
def check_gpu_availability():
    """
    检测GPU可用性，返回最佳可用的后端
    """
    gpu_info = {
        'cupy_available': False,
        'pytorch_available': False,
        'best_backend': 'cpu'
    }

    # 检测CuPy GPU
    try:
        import cupy as cp
        gpu_info['cupy_available'] = True
        gpu_info['best_backend'] = 'cupy'
        print(f"✓ CuPy GPU可用")
        # 测试CuPy功能
        test_array = cp.array([1, 2, 3])
        print(f"  CuPy测试成功: {cp.asnumpy(test_array)}")
    except ImportError:
        print("✗ CuPy未安装")
    except Exception as e:
        print(f"✗ CuPy测试失败: {e}")

    # 检测PyTorch GPU
    try:
        import torch
        if torch.cuda.is_available():
            gpu_info['pytorch_available'] = True
            if gpu_info['best_backend'] == 'cpu':  # 如果CuPy不可用，但PyTorch可用
                gpu_info['best_backend'] = 'pytorch'
            print(f"✓ PyTorch GPU可用: {torch.cuda.get_device_name(0)}")
            print(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024 ** 3:.1f} GB")
    except ImportError:
        print("✗ PyTorch未安装")

    if gpu_info['best_backend'] == 'cpu':
        print("ℹ 将使用CPU进行计算")

    return gpu_info


# 检测GPU可用性
gpu_info = check_gpu_availability()

# 统一的GPU使用设置
args.use_gpu = not args.use_cpu and gpu_info['best_backend'] != 'cpu'

# 自动选择最佳后端
if args.use_gpu and args.gpu_backend == "auto":
    args.gpu_backend = gpu_info['best_backend']

# 设置COLMAP GPU使用
use_gpu_colmap = 1 if args.use_gpu else 0

# 打印GPU设置
if args.use_gpu:
    print(f"🚀 启用GPU加速 (后端: {args.gpu_backend})")
else:
    print("💻 使用CPU模式")

colmap_command = '"{}"'.format(args.colmap_executable) if len(args.colmap_executable) > 0 else "colmap"
magick_command = '"{}"'.format(args.magick_executable) if len(args.magick_executable) > 0 else "magick"

# 设置默认的可视化选项
if not hasattr(args, 'save_feature_images'):
    args.save_feature_images = True
if not hasattr(args, 'save_match_images'):
    args.save_match_images = True

# 如果用户明确指定了不保存，则覆盖默认值
if args.no_save_feature_images:
    args.save_feature_images = False
if args.no_save_match_images:
    args.save_match_images = False

colmap_command = '"{}"'.format(args.colmap_executable) if len(args.colmap_executable) > 0 else "colmap"
magick_command = '"{}"'.format(args.magick_executable) if len(args.magick_executable) > 0 else "magick"
# 统一GPU设置逻辑
use_gpu = not (args.no_gpu or args.use_cpu)


def visualize_and_save_features(image_path, keypoints, output_dir, max_features_to_show=100):
    """
    可视化并保存特征点图像 - 处理重建的关键点对象
    """
    # 读取图像
    img = cv2.imread(image_path)
    if img is None:
        print(f"无法读取图像: {image_path}")
        return False

    # 创建彩色图像用于绘制
    if len(img.shape) == 2:
        img_color = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    else:
        img_color = img.copy()

    # 限制显示的特征点数量，避免图像过于拥挤
    if len(keypoints) > max_features_to_show:
        # 随机选择一部分特征点显示
        import random
        keypoints_to_draw = random.sample(keypoints, max_features_to_show)
        print(f"图像 {os.path.basename(image_path)}: 显示 {max_features_to_show}/{len(keypoints)} 个特征点")
    else:
        keypoints_to_draw = keypoints

    # 绘制特征点
    for kp in keypoints_to_draw:
        # 确保关键点属性存在
        x = int(kp.pt[0]) if hasattr(kp, 'pt') else 0
        y = int(kp.pt[1]) if hasattr(kp, 'pt') else 0
        size = int(kp.size) if hasattr(kp, 'size') and kp.size > 0 else 5

        # 根据响应值选择颜色
        response = kp.response if hasattr(kp, 'response') else 1.0
        if response > 0.1:
            color = (0, 255, 0)  # 高响应 - 绿色
        elif response > 0.01:
            color = (0, 255, 255)  # 中响应 - 黄色
        else:
            color = (0, 0, 255)  # 低响应 - 红色

        # 绘制关键点圆圈
        cv2.circle(img_color, (x, y), size, color, 1)

        # 如果有关键点方向，绘制方向线
        if hasattr(kp, 'angle') and kp.angle != -1:
            angle_rad = np.radians(kp.angle)
            length = size * 2
            end_x = int(x + length * np.cos(angle_rad))
            end_y = int(y + length * np.sin(angle_rad))
            cv2.line(img_color, (x, y), (end_x, end_y), color, 1)

    # 添加文本信息
    text = f"Features: {len(keypoints)} (showing {len(keypoints_to_draw)})"
    cv2.putText(img_color, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    cv2.putText(img_color, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 1)

    # 调整图像大小以便显示（如果太大）
    height, width = img_color.shape[:2]
    if width > 1200:
        scale = 1200.0 / width
        new_width = 1200
        new_height = int(height * scale)
        img_color = cv2.resize(img_color, (new_width, new_height))

    # 保存图像
    img_name = os.path.splitext(os.path.basename(image_path))[0]
    output_path = os.path.join(output_dir, f"features_{img_name}.png")
    cv2.imwrite(output_path, img_color)

    print(f"保存特征点图: {output_path}")
    return True


def save_feature_visualizations(image_paths, original_keypoints, output_dir, max_images=20):
    """
    为多张图像保存特征点可视化
    """
    print(f"保存特征点可视化图像到: {output_dir}")
    os.makedirs(output_dir, exist_ok=True)

    saved_count = 0
    for i, img_path in enumerate(image_paths):
        if saved_count >= max_images:
            break

        img_name = os.path.basename(img_path)
        if img_name in original_keypoints:
            success = visualize_and_save_features(img_path, original_keypoints[img_name], output_dir)
            if success:
                saved_count += 1

    print(f"总共保存了 {saved_count} 张特征点可视化图像")
    return saved_count


def parse_mstar_filename(filename):
    """
    解析MSTAR数据集文件名，提取俯视角和方位角
    格式: T72-15-007 或类似
    """
    # 移除文件扩展名
    basename = os.path.splitext(filename)[0]

    # 使用正则表达式匹配模式: 目标名-俯视角-方位角
    pattern = r'([A-Za-z0-9]+)-(\d+)-(\d+)'
    match = re.search(pattern, basename)

    if match:
        target_name = match.group(1)  # 目标名，如T72
        depression_angle = int(match.group(2))  # 俯视角，如15度
        azimuth_angle = int(match.group(3))  # 方位角，如007度

        print(f"解析文件名: {filename} -> 目标: {target_name}, 俯视角: {depression_angle}°, 方位角: {azimuth_angle}°")
        return depression_angle, azimuth_angle
    else:
        # 如果无法解析，使用默认值
        print(f"警告: 无法解析文件名 {filename}，使用默认角度")
        return 15, 0  # 默认15度俯视角，0度方位角


def preprocess_sar_image(image):
    """
    SAR图像预处理 - 与原始SAR-SIFT代码保持一致
    """
    # 确保图像是合适的类型
    if image.dtype != np.float64:
        image = image.astype(np.float64)

    # 归一化到0-1范围（与原始SAR-SIFT代码一致）
    if image.max() > 1.0:
        image = image / 255.0

    # 应用预处理（如果启用）
    if args.preprocess_sar:
        # 应用斑点噪声滤波
        if args.speckle_filter:
            # 使用中值滤波减少斑点噪声
            temp_img = (image * 255).astype(np.uint8)
            temp_img = cv2.medianBlur(temp_img, 3)
            image = temp_img.astype(np.float64) / 255.0

        # 应用对比度增强
        if args.contrast_enhance:
            # 直方图均衡化
            temp_img = (image * 255).astype(np.uint8)
            temp_img = cv2.equalizeHist(temp_img)
            image = temp_img.astype(np.float64) / 255.0

    return image


def clean_existing_database(source_path):
    """
    清理现有数据库和中间文件
    """
    db_path = os.path.join(source_path, "distorted", "database.db")
    if os.path.exists(db_path):
        os.remove(db_path)
        print(f"清理现有数据库: {db_path}")

    # 清理稀疏重建结果
    sparse_dirs = [
        os.path.join(source_path, "distorted", "sparse"),
        os.path.join(source_path, "sparse")
    ]

    for sparse_dir in sparse_dirs:
        if os.path.exists(sparse_dir):
            shutil.rmtree(sparse_dir)
            print(f"清理稀疏重建目录: {sparse_dir}")

    # 重新创建目录
    os.makedirs(os.path.join(source_path, "distorted", "sparse"), exist_ok=True)
    os.makedirs(os.path.join(source_path, "sparse", "0"), exist_ok=True)


def extract_single_image_features(img_path, feature_type, backend):
    """
    单张图像的特征提取函数 - 返回可序列化的数据
    """
    img_name = os.path.basename(img_path)

    # 读取图像
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"❌ 无法读取图像: {img_path}")
        return img_name, None, None, None

    # SAR图像预处理
    img = preprocess_sar_image(img)

    # 确保图像是合适的类型和范围
    if img.dtype != np.float32:
        img = img.astype(np.float32)

    if img.max() > 1.0:
        img = img / 255.0

    # 使用SAR-SIFT，强制使用CPU后端
    try:
        keypoints, descriptors = sar_sift_detect_and_compute(
            img,
            sigma=args.sar_sift_sigma,
            ratio=args.sar_sift_ratio,
            Mmax=args.sar_sift_layers,
            d=args.sar_sift_d,
            d_SH=args.sar_sift_harris_threshold,
            backend=backend
        )
    except Exception as e:
        print(f"❌ SAR-SIFT处理图像 {img_name} 时出错: {e}")
        return img_name, None, None, None

    if keypoints is None or descriptors is None or len(keypoints) == 0:
        print(f"⚠️ 在 {img_name} 中未找到SAR-SIFT特征点")
        return img_name, None, None, None

    # 将关键点转换为可序列化的字典格式
    keypoints_serializable = [safe_keypoint_to_dict(kp) for kp in keypoints]
    for kp in keypoints:
        kp_dict = {
            'pt': (float(kp.pt[0]), float(kp.pt[1])),
            'size': float(kp.size) if hasattr(kp, 'size') and kp.size > 0 else 1.0,
            'angle': float(kp.angle) if hasattr(kp, 'angle') else 0.0,
            'response': float(kp.response) if hasattr(kp, 'response') else 1.0,
            'octave': int(kp.octave) if hasattr(kp, 'octave') else 0
        }
        keypoints_serializable.append(kp_dict)

    # 转换为COLMAP格式
    colmap_keypoints = []
    for kp in keypoints:
        x = kp.pt[0]
        y = kp.pt[1]
        response = kp.response if hasattr(kp, 'response') else 1.0
        size = kp.size if hasattr(kp, 'size') else 1.0
        angle = kp.angle if hasattr(kp, 'angle') else 0.0

        colmap_kp = [x, y, response, size, angle, 0.0]
        colmap_keypoints.append(colmap_kp)

    colmap_keypoints_array = np.array(colmap_keypoints, dtype=np.float32)
    descriptors_array = descriptors.astype(np.float32)

    print(f"✅ 图像 {img_name}: 找到 {len(keypoints)} 个SAR-SIFT特征点")

    return img_name, keypoints_serializable, colmap_keypoints_array, descriptors_array


def extract_single_image_features_wrapper(args):
    """
    包装函数，用于多进程池
    """
    img_path, feature_type, backend = args
    return extract_single_image_features(img_path, feature_type, backend)


def extract_features_multiprocess(image_paths, feature_type="SAR_SIFT"):
    """
    使用多进程提取特征 - 处理可序列化的关键点数据
    """
    print(f"🎯 使用多进程提取 {feature_type} 特征...")

    if feature_type != "SAR_SIFT":
        print(f"⚠️ 只支持SAR_SIFT特征提取器，但收到 {feature_type}，将使用SAR_SIFT")
        feature_type = "SAR_SIFT"

    print("🔧 SAR-SIFT参数:")
    print(f"   sigma={args.sar_sift_sigma}, ratio={args.sar_sift_ratio}")
    print(f"   layers={args.sar_sift_layers}, d={args.sar_sift_d}")
    print(f"   harris_threshold={args.sar_sift_harris_threshold}")

    # 强制使用CPU后端
    backend = "cpu"
    print("💻 使用多进程CPU后端")

    # 清空全局字典
    all_keypoints = {}
    all_descriptors = {}
    all_original_keypoints = {}

    # ========== 进程数配置逻辑 ==========
    if args.num_threads == 0:
        # 单进程模式（用于调试）
        print("🔧 使用单进程模式（调试）")
        num_processes = 1
    elif args.num_threads > 0:
        # 用户指定进程数
        num_processes = min(args.num_threads, len(image_paths), cpu_count())
        print(f"🔧 使用用户指定进程数: {num_processes}")
    else:
        # 自动设置进程数
        available_cpus = cpu_count()

        # 根据图像数量和系统资源自动调整
        if len(image_paths) <= 4:
            num_processes = min(len(image_paths), available_cpus)
        elif len(image_paths) <= 16:
            num_processes = min(available_cpus, 8)
        else:
            num_processes = min(available_cpus, 12)  # 限制最大进程数

        print(f"🔧 自动设置进程数: {num_processes} (CPU核心数: {available_cpus}, 图像数: {len(image_paths)})")

    # 如果只有1张图像，强制单进程
    if len(image_paths) <= 1:
        num_processes = 1
        print("🔧 只有1张图像，使用单进程")

    # 准备任务参数
    task_args = [(img_path, feature_type, backend) for img_path in image_paths]

    processed_count = 0
    total_count = len(image_paths)

    # 使用多进程池并行处理
    print(f"🚀 启动 {num_processes} 个进程处理 {total_count} 张图像...")

    try:
        with Pool(processes=num_processes) as pool:
            # 使用imap_unordered获取完成的任务（更高效）
            for i, result in enumerate(pool.imap_unordered(extract_single_image_features_wrapper, task_args)):
                img_name, keypoints_serializable, colmap_kp, descriptors = result

                if img_name and keypoints_serializable is not None:
                    # 将序列化的关键点数据转换回 cv2.KeyPoint 对象
                    original_keypoints = []
                    for kp_dict in keypoints_serializable:
                        kp = cv2.KeyPoint()
                        kp.pt = kp_dict['pt']
                        kp.size = kp_dict['size']
                        kp.angle = kp_dict['angle']
                        kp.response = kp_dict['response']
                        kp.octave = kp_dict['octave']
                        original_keypoints.append(kp)

                    all_original_keypoints[img_name] = original_keypoints
                    all_keypoints[img_name] = colmap_kp
                    all_descriptors[img_name] = descriptors

                processed_count += 1
                if processed_count % max(1, total_count // 10) == 0:  # 每10%进度报告一次
                    print(f"📊 进度: {processed_count}/{total_count} ({processed_count / total_count * 100:.1f}%)")

    except Exception as e:
        print(f"❌ 多进程处理失败: {e}")
        # 回退到单进程处理
        print("🔄 回退到单进程处理...")
        for task_arg in task_args:
            result = extract_single_image_features_wrapper(task_arg)
            img_name, keypoints_serializable, colmap_kp, descriptors = result
            if img_name and keypoints_serializable is not None:
                # 将序列化的关键点数据转换回 cv2.KeyPoint 对象
                original_keypoints = [dict_to_keypoint(kp_dict) for kp_dict in keypoints_serializable]
                for kp_dict in keypoints_serializable:
                    kp = cv2.KeyPoint()
                    kp.pt = kp_dict['pt']
                    kp.size = kp_dict['size']
                    kp.angle = kp_dict['angle']
                    kp.response = kp_dict['response']
                    kp.octave = kp_dict['octave']
                    original_keypoints.append(kp)

                all_original_keypoints[img_name] = original_keypoints
                all_keypoints[img_name] = colmap_kp
                all_descriptors[img_name] = descriptors

    print(f"✅ 特征提取完成: 成功处理 {len(all_keypoints)}/{total_count} 张图像")

    return all_keypoints, all_descriptors, all_original_keypoints


def match_features_custom(keypoints, descriptors, original_keypoints, image_paths, feature_type="SAR_SIFT"):
    """
    使用自定义匹配方法进行特征匹配 - 基于封装的CustomMatcher
    """
    print(f"使用自定义匹配方法进行 {feature_type} SAR图像特征匹配...")

    matches_dir = os.path.join(args.source_path, "feature_matches")
    if args.save_match_images:
        os.makedirs(matches_dir, exist_ok=True)
        print(f"特征匹配图将保存到: {matches_dir}")

    # 使用自定义匹配器进行匹配
    matches_dict = custom_matcher.match_features(
        keypoints=keypoints,
        descriptors=descriptors,
        original_keypoints=original_keypoints,
        image_paths=image_paths,
        save_match_images=args.save_match_images,
        matches_dir=matches_dir,
        max_match_pairs=args.max_match_pairs
    )

    return matches_dict


def create_colmap_database_from_features(source_path, keypoints, descriptors, camera_model="OPENCV",
                                         feature_type="SAR_SIFT"):
    """
    从OpenCV提取的特征创建COLMAP数据库 - 完全兼容COLMAP标准格式
    """
    print("创建COLMAP标准格式数据库...")

    db_path = os.path.join(source_path, "distorted", "database.db")

    # 清理现有数据库
    if os.path.exists(db_path):
        os.remove(db_path)

    # 连接数据库
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 创建表 - 使用COLMAP标准表结构
    cursor.execute('''
                   CREATE TABLE cameras
                   (
                       camera_id          INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                       model              INTEGER NOT NULL,
                       width              INTEGER NOT NULL,
                       height             INTEGER NOT NULL,
                       params             BLOB,
                       prior_focal_length INTEGER NOT NULL
                   )
                   ''')

    cursor.execute('''
                   CREATE TABLE images
                   (
                       image_id  INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                       name      TEXT    NOT NULL UNIQUE,
                       camera_id INTEGER NOT NULL,
                       prior_qw  REAL,
                       prior_qx  REAL,
                       prior_qy  REAL,
                       prior_qz  REAL,
                       prior_tx  REAL,
                       prior_ty  REAL,
                       prior_tz  REAL,
                       timestamp INTEGER,
                       CONSTRAINT images_id_key UNIQUE (image_id),
                       FOREIGN KEY (camera_id) REFERENCES cameras (camera_id)
                   )
                   ''')

    cursor.execute('''
                   CREATE TABLE keypoints
                   (
                       image_id INTEGER NOT NULL,
                       rows     INTEGER NOT NULL,
                       cols     INTEGER NOT NULL,
                       data     BLOB,
                       FOREIGN KEY (image_id) REFERENCES images (image_id) ON DELETE CASCADE
                   )
                   ''')

    cursor.execute('''
                   CREATE TABLE descriptors
                   (
                       image_id INTEGER NOT NULL,
                       rows     INTEGER NOT NULL,
                       cols     INTEGER NOT NULL,
                       data     BLOB,
                       FOREIGN KEY (image_id) REFERENCES images (image_id) ON DELETE CASCADE
                   )
                   ''')

    cursor.execute('''
                   CREATE TABLE matches
                   (
                       pair_id INTEGER PRIMARY KEY NOT NULL,
                       rows    INTEGER             NOT NULL,
                       cols    INTEGER             NOT NULL,
                       data    BLOB
                   )
                   ''')

    cursor.execute('''
                   CREATE TABLE two_view_geometries
                   (
                       pair_id INTEGER PRIMARY KEY NOT NULL,
                       rows    INTEGER             NOT NULL,
                       cols    INTEGER             NOT NULL,
                       data    BLOB,
                       config  INTEGER             NOT NULL,
                       F       BLOB,
                       E       BLOB,
                       H       BLOB
                   )
                   ''')

    # 创建索引以提高查询性能
    cursor.execute('CREATE INDEX IF NOT EXISTS keypoints_image_id_idx ON keypoints(image_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS descriptors_image_id_idx ON descriptors(image_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS matches_pair_id_idx ON matches(pair_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS two_view_geometries_pair_id_idx ON two_view_geometries(pair_id)')

    # 添加COLMAP需要的额外索引
    cursor.execute('CREATE INDEX IF NOT EXISTS images_name_idx ON images(name)')
    cursor.execute('CREATE INDEX IF NOT EXISTS images_camera_id_idx ON images(camera_id)')

    # 添加相机 - 使用升采样后的图像尺寸
    original_width, original_height = 128, 128  # MSTAR图像原始尺寸
    upscaled_width = int(original_width * args.image_scale)
    upscaled_height = int(original_height * args.image_scale)

    print(f"使用升采样后的图像尺寸: {upscaled_width}x{upscaled_height}")

    # 使用PINHOLE模型，这是最常用的模型
    # 参数: [fx, fy, cx, cy]
    focal_length = 600.0 * args.image_scale  # 焦距也需要相应缩放
    camera_params = np.array([
        focal_length,  # fx
        focal_length,  # fy (假设fx = fy)
        upscaled_width / 2,  # cx
        upscaled_height / 2  # cy
    ], dtype=np.float64)
    model_id = 1  # PINHOLE模型ID，需要4个参数

    cursor.execute(
        "INSERT INTO cameras (model, width, height, params, prior_focal_length) VALUES (?, ?, ?, ?, ?)",
        (model_id, upscaled_width, upscaled_height, camera_params.tobytes(), 1)
    )
    camera_id = cursor.lastrowid

    # 添加图像和特征点
    image_ids = {}
    for img_name in keypoints.keys():
        # 添加图像
        cursor.execute(
            "INSERT INTO images (name, camera_id, timestamp) VALUES (?, ?, ?)",
            (img_name, camera_id, 0)  # timestamp设为0
        )
        image_id = cursor.lastrowid
        image_ids[img_name] = image_id

        # 添加关键点
        kp_data = keypoints[img_name]
        rows, cols = kp_data.shape
        kp_data = kp_data.astype(np.float32)

        cursor.execute(
            "INSERT INTO keypoints (image_id, rows, cols, data) VALUES (?, ?, ?, ?)",
            (image_id, rows, cols, kp_data.tobytes())
        )

        # 添加描述符 - 检查维度
        desc_data = descriptors[img_name]
        rows, cols = desc_data.shape

        # 检查描述符维度，如果不是128维则调整或警告
        if cols != 128:
            print(f"警告: 图像 {img_name} 的描述符维度为 {cols}，不是COLMAP标准的128维")
            # 如果需要，可以在这里调整描述符维度
            # 例如：desc_data = adjust_descriptor_dimension(desc_data, 128)

        desc_data = desc_data.astype(np.float32)

        cursor.execute(
            "INSERT INTO descriptors (image_id, rows, cols, data) VALUES (?, ?, ?, ?)",
            (image_id, rows, cols, desc_data.tobytes())
        )

    conn.commit()
    conn.close()

    print(f"数据库创建完成: {db_path}")
    print(f"添加了 {len(keypoints)} 张图像的特征点")

    return db_path, image_ids


def save_matches_to_database(db_path, matches_dict, image_ids):
    """将匹配结果保存到数据库 - 使用COLMAP标准格式"""
    print("保存匹配结果到数据库...")

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 获取图像总数
    cursor.execute("SELECT COUNT(*) FROM images")
    num_images = cursor.fetchone()[0]
    print(f"图像总数: {num_images}")

    match_count = 0
    for (img1_name, img2_name), match_data in matches_dict.items():
        if img1_name not in image_ids or img2_name not in image_ids:
            continue

        image_id1 = image_ids[img1_name]
        image_id2 = image_ids[img2_name]

        # COLMAP标准的pair_id计算方式: 2147483647 * min_id + max_id
        if image_id1 > image_id2:
            image_id1, image_id2 = image_id2, image_id1
            # 注意：如果交换了图像ID，也需要交换匹配索引
            match_data = match_data[:, [1, 0]]  # 交换列顺序

        pair_id = 2147483647 * image_id1 + image_id2

        if match_data.size > 0:
            rows, cols = match_data.shape

            # 确保匹配数据是uint32类型
            match_data = match_data.astype(np.uint32)

            cursor.execute(
                "INSERT OR REPLACE INTO matches (pair_id, rows, cols, data) VALUES (?, ?, ?, ?)",
                (pair_id, rows, cols, match_data.tobytes())
            )
            match_count += 1

            print(
                f"保存匹配对: {img1_name}({image_id1}) - {img2_name}({image_id2}) -> pair_id: {pair_id}, 匹配数: {rows}")

    conn.commit()
    conn.close()

    print(f"总共保存了 {match_count} 组匹配到数据库")


def check_database_content(db_path):
    """
    检查数据库内容，确保格式正确
    """
    print(f"检查数据库: {db_path}")

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 检查表是否存在
    tables = ['cameras', 'images', 'keypoints', 'descriptors', 'matches', 'two_view_geometries']
    for table in tables:
        cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
        if cursor.fetchone():
            print(f"✓ 表 {table} 存在")
        else:
            print(f"✗ 表 {table} 不存在")

    # 检查数据量
    cursor.execute("SELECT COUNT(*) FROM cameras")
    print(f"相机数量: {cursor.fetchone()[0]}")

    cursor.execute("SELECT COUNT(*) FROM images")
    num_images = cursor.fetchone()[0]
    print(f"图像数量: {num_images}")

    cursor.execute("SELECT COUNT(*) FROM keypoints")
    print(f"关键点记录数: {cursor.fetchone()[0]}")

    cursor.execute("SELECT COUNT(*) FROM descriptors")
    print(f"描述子记录数: {cursor.fetchone()[0]}")

    cursor.execute("SELECT COUNT(*) FROM matches")
    num_matches = cursor.fetchone()[0]
    print(f"匹配对数量: {num_matches}")

    cursor.execute("SELECT COUNT(*) FROM two_view_geometries")
    num_geometries = cursor.fetchone()[0]
    print(f"几何验证数量: {num_geometries}")

    # 检查匹配数据的格式
    cursor.execute("SELECT pair_id, rows, cols FROM matches LIMIT 10")
    matches_samples = cursor.fetchall()
    print("匹配数据样本 (前10个):")
    for pair_id, rows, cols in matches_samples:
        # 解析pair_id
        image_id2 = pair_id % num_images
        image_id1 = (pair_id - image_id2) // num_images
        print(f"  pair_id: {pair_id} -> 图像对: ({image_id1}, {image_id2}), 匹配数: {rows}")

    # 检查关键点数据格式
    cursor.execute("SELECT image_id, rows, cols FROM keypoints LIMIT 5")
    keypoints_samples = cursor.fetchall()
    print("关键点数据样本 (前5个):")
    for image_id, rows, cols in keypoints_samples:
        print(f"  图像 {image_id}: {rows} 个关键点, 每个 {cols} 维")

    conn.close()

    # 检查匹配连通性
    if num_matches > 0 and num_geometries > 0:
        print("✓ 数据库包含匹配和几何验证数据")
    else:
        print("✗ 数据库缺少匹配或几何验证数据")


def create_synthetic_camera_poses(image_files, sar_height, depression_scale=1.0, point_cloud_scale=1.0):
    """
    创建合成的相机位姿（当SfM失败时使用）
    基于SAR几何生成合理的相机位姿
    """
    print("创建基于SAR几何的合成相机位姿...")

    camera_poses = {}

    for i, img_path in enumerate(image_files):
        img_name = os.path.basename(img_path)

        # 从文件名解析俯视角和方位角
        depression_angle_deg, azimuth_angle_deg = parse_mstar_filename(img_name)

        # 转换为弧度并应用缩放
        depression_angle = np.radians(depression_angle_deg) * depression_scale
        azimuth_angle = np.radians(azimuth_angle_deg)

        # SAR几何计算
        slant_range = sar_height / np.sin(depression_angle)
        ground_range = np.sqrt(slant_range ** 2 - sar_height ** 2)

        # 计算相机位置（在XZ平面上的圆环分布，COLMAP坐标系）
        radius = ground_range * point_cloud_scale
        x = radius * np.cos(azimuth_angle)
        z = radius * np.sin(azimuth_angle)
        y = -sar_height  # 飞行高度在Y轴负方向（COLMAP约定）

        # 计算看向原点的旋转
        # 简化版本：假设相机始终看向原点
        forward = np.array([-x, -y, -z])
        forward = forward / np.linalg.norm(forward)

        # 计算右向量（COLMAP坐标系：Y轴负方向为高度正方向）
        right = np.cross(forward, np.array([0, -1, 0]))  # COLMAP约定
        right = right / np.linalg.norm(right)

        # 计算上向量
        up = np.cross(right, forward)

        # 构建旋转矩阵
        rotation_matrix = np.column_stack([right, up, -forward])

        # 转换为四元数
        rotation = R.from_matrix(rotation_matrix)
        quat = rotation.as_quat()  # [x, y, z, w]

        camera_poses[img_name] = {
            'qw': quat[3], 'qx': quat[0], 'qy': quat[1], 'qz': quat[2],
            'tx': x, 'ty': y, 'tz': z,
            'depression_angle': depression_angle_deg,
            'azimuth_angle': azimuth_angle_deg
        }

    print(f"生成了 {len(camera_poses)} 个合成相机位姿")
    return camera_poses


def validate_colmap_database(db_path):
    """
    验证COLMAP数据库的完整性
    """
    print(f"验证数据库完整性: {db_path}")

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # 检查关键数据结构
        tables_to_check = ['cameras', 'images', 'keypoints', 'descriptors', 'matches']

        for table in tables_to_check:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            count = cursor.fetchone()[0]
            print(f"  {table}: {count} 条记录")

            # 检查数据格式
            if table == 'keypoints':
                cursor.execute("SELECT image_id, rows, cols FROM keypoints LIMIT 1")
                result = cursor.fetchone()
                if result:
                    image_id, rows, cols = result
                    print(f"    关键点格式: 图像 {image_id}, {rows} 点, {cols} 维")

            elif table == 'descriptors':
                cursor.execute("SELECT image_id, rows, cols FROM descriptors LIMIT 1")
                result = cursor.fetchone()
                if result:
                    image_id, rows, cols = result
                    print(f"    描述子格式: 图像 {image_id}, {rows} 描述子, {cols} 维")

        conn.close()
        return True

    except Exception as e:
        print(f"数据库验证失败: {e}")
        return False


def generate_sar_point_cloud(image_files, sar_height, target_height, target_base_height,
                             shadow_height, background_height, target_density, background_density,
                             scale_factor=1.0):
    """
    生成SAR专用的点云 - 基于SAR几何和图像信息
    """
    print("生成SAR专用点云...")

    all_points = []
    all_colors = []

    # 目标尺寸（米）- 应用缩放
    target_length = 8.0 * scale_factor
    target_width = 3.0 * scale_factor
    target_height_val = 2.5 * scale_factor

    # 生成目标点云
    target_samples = int(target_length * target_width * target_density * 50)
    print(f"生成 {target_samples} 个目标点")

    for i in range(target_samples):
        # 在目标体积内随机生成点
        x = np.random.uniform(-target_length / 2, target_length / 2)
        z = np.random.uniform(-target_width / 2, target_width / 2)
        y = np.random.uniform(target_base_height, target_base_height + target_height_val)

        # 根据位置调整高度 - 模拟目标形状
        norm_x = x / (target_length / 2)
        norm_z = z / (target_width / 2)
        distance = np.sqrt(norm_x ** 2 + norm_z ** 2)

        base_y = target_base_height

        if distance < 0.7:  # 中心区域
            height_factor = 1.0 - distance
            y = base_y + target_height_val * height_factor
        else:  # 边缘区域
            height_factor = 0.5 * (1.0 - min(distance, 1.0))
            y = base_y + target_height_val * 0.3 * height_factor

        # 添加随机微小变化
        y += np.random.normal(0, 0.03 * scale_factor)

        # 目标颜色
        if y > target_base_height + target_height_val * 0.6:
            base_r, base_g, base_b = 200, 100, 80  # 上部 - 偏红
        else:
            base_r, base_g, base_b = 160, 140, 100  # 下部 - 偏黄

        # 颜色变化
        color_variation = np.random.randint(-15, 15, 3)
        color_r = max(0, min(255, base_r + color_variation[0]))
        color_g = max(0, min(255, base_g + color_variation[1]))
        color_b = max(0, min(255, base_b + color_variation[2]))

        all_points.append([x, y, z])
        all_colors.append([color_r, color_g, color_b])

    # 生成地面点云
    ground_size = max(target_length * 4, 50.0) * scale_factor
    ground_samples = int(ground_size * ground_size * background_density * 3)

    print(f"生成 {ground_samples} 个地面点，地面大小: {ground_size:.1f}米")

    for i in range(ground_samples):
        # 在地面范围内生成点
        x = np.random.uniform(-ground_size / 2, ground_size / 2)
        z = np.random.uniform(-ground_size / 2, ground_size / 2)
        y = background_height + np.random.normal(0, 0.01 * scale_factor)

        # 地面颜色（偏灰）
        base_intensity = np.random.randint(100, 180)
        color_variation = np.random.randint(-10, 10, 3)
        color_r = max(0, min(255, base_intensity + color_variation[0]))
        color_g = max(0, min(255, base_intensity + color_variation[1]))
        color_b = max(0, min(255, base_intensity + color_variation[2]))

        all_points.append([x, y, z])
        all_colors.append([color_r, color_g, color_b])

    # 转换为numpy数组
    if all_points:
        points_3d = np.array(all_points).T
        print(f"总点数: {len(all_points)}")
        print(f"点云范围: X[{np.min(points_3d[0]):.2f}, {np.max(points_3d[0]):.2f}], "
              f"Y[{np.min(points_3d[1]):.2f}, {np.max(points_3d[1]):.2f}], "
              f"Z[{np.min(points_3d[2]):.2f}, {np.max(points_3d[2]):.2f}]")

        return points_3d, all_colors
    else:
        print("错误: 未能生成任何点")
        return np.zeros((3, 0)), []


def save_point_cloud_ply(points_3d, point_colors, filename):
    """
    将点云保存为PLY格式
    """
    if points_3d.size == 0:
        print(f"警告: 没有点云数据可保存到 {filename}")
        return

    if points_3d.shape[0] != 3:
        points_3d = points_3d.T

    num_points = points_3d.shape[1]

    if len(point_colors) != num_points:
        print(f"警告: 点云颜色数量 ({len(point_colors)}) 与点数量 ({num_points}) 不匹配")
        point_colors = [[255, 255, 255] for _ in range(num_points)]

    with open(filename, 'w') as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"element vertex {num_points}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        f.write("property uchar red\n")
        f.write("property uchar green\n")
        f.write("property uchar blue\n")
        f.write("end_header\n")

        for i in range(num_points):
            x, y, z = points_3d[:, i]
            r, g, b = point_colors[i] if i < len(point_colors) else (255, 255, 255)
            f.write(f"{x:.6f} {y:.6f} {z:.6f} {int(r)} {int(g)} {int(b)}\n")

    print(f"点云已保存为PLY格式: {filename} (包含 {num_points} 个点)")


def create_colmap_files_from_synthetic_poses(source_path, camera_poses, points_3d, point_colors):
    """
    从合成位姿创建COLMAP文件
    """
    print("从合成位姿创建COLMAP文件...")

    # 使用升采样后的图像尺寸
    original_width, original_height = 128, 128  # MSTAR图像原始尺寸
    upscaled_width = int(original_width * args.image_scale)
    upscaled_height = int(original_height * args.image_scale)

    # 创建相机参数文件
    cameras_txt_path = source_path + "/sparse/0/cameras.txt"
    with open(cameras_txt_path, 'w') as f:
        f.write("# Camera list with one line of data per camera:\n")
        f.write("#   CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]\n")
        f.write("# Number of cameras: 1\n")
        # 使用PINHOLE模型，参数: [fx, fy, cx, cy]
        focal_length = 600.0 * args.image_scale
        f.write(
            f"1 PINHOLE {upscaled_width} {upscaled_height} {focal_length} {focal_length} {upscaled_width / 2} {upscaled_height / 2}\n")
    # 创建images.txt文件
    images_txt_path = source_path + "/sparse/0/images.txt"
    with open(images_txt_path, 'w') as f:
        f.write("# Image list with two lines of data per image:\n")
        f.write("#   IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n")
        f.write("#   POINTS2D[] as (X, Y, POINT3D_ID)\n")

        image_files = []
        for ext in ['*.jpg', '*.jpeg', '*.png', '*.tif', '*.tiff']:
            image_files.extend(glob.glob(os.path.join(source_path, "images", ext)))

        f.write(f"# Number of images: {len(image_files)}\n")

        for i, img_path in enumerate(image_files):
            img_name = os.path.basename(img_path)

            if img_name in camera_poses:
                pose = camera_poses[img_name]
                f.write(f"{i + 1} {pose['qw']:.6f} {pose['qx']:.6f} {pose['qy']:.6f} {pose['qz']:.6f} "
                        f"{pose['tx']:.6f} {pose['ty']:.6f} {pose['tz']:.6f} 1 {img_name}\n")
            else:
                # 默认位姿
                f.write(f"{i + 1} 1.0 0.0 0.0 0.0 10.0 10.0 10.0 1 {img_name}\n")

            # 空的特征点行
            f.write("\n")

    # 创建points3D.txt文件
    points3d_txt_path = source_path + "/sparse/0/points3D.txt"
    with open(points3d_txt_path, 'w') as f:
        f.write("# 3D point list with one line of data per point:\n")
        f.write("#   POINT3D_ID, X, Y, Z, R, G, B, ERROR, TRACK[] as (IMAGE_ID, POINT2D_IDX)\n")

        if points_3d.size > 0:
            f.write(f"# Number of points: {points_3d.shape[1]}\n")
            for i in range(points_3d.shape[1]):
                x, y, z = points_3d[:, i]
                r, g, b = point_colors[i] if i < len(point_colors) else (255, 255, 255)
                f.write(f"{i + 1} {x:.6f} {y:.6f} {z:.6f} {int(r)} {int(g)} {int(b)} 0\n")
        else:
            f.write("# Number of points: 0\n")

    print("COLMAP文件创建完成")


def select_promising_pairs(image_paths, max_pairs_per_image=None, max_azimuth_diff=None):
    """
    基于方位角信息选择有希望匹配的图像对
    避免O(n²)的全局匹配，大幅减少匹配时间
    """
    # 使用args中的参数，如果没有传入则使用args的默认值
    if max_pairs_per_image is None:
        max_pairs_per_image = args.max_pairs_per_image
    if max_azimuth_diff is None:
        max_azimuth_diff = args.max_azimuth_diff

    print(f"🔍 基于方位角选择有希望的图像对...")
    print(f"   每张图像最多匹配 {max_pairs_per_image} 个相邻图像")
    print(f"   最大方位角差异: {max_azimuth_diff}°")

    # 解析所有图像的方位角
    image_angles = {}

    for img_path in image_paths:
        img_name = os.path.basename(img_path)
        _, azimuth_angle = parse_mstar_filename(img_name)
        image_angles[img_name] = azimuth_angle

    # 获取所有角度并排序
    all_angles = sorted(image_angles.values())
    print(f"   图像方位角范围: {min(all_angles)}° - {max(all_angles)}°")

    promising_pairs = set()

    # 为每张图像选择角度相近的图像进行匹配
    for img_name, current_angle in image_angles.items():
        # 找到角度相近的图像
        candidate_images = []

        # 检查当前角度附近的范围
        for candidate_name, candidate_angle in image_angles.items():
            if candidate_name == img_name:
                continue

            angle_diff = min(
                abs(candidate_angle - current_angle),
                360 - abs(candidate_angle - current_angle)  # 处理360°环绕
            )

            if angle_diff <= max_azimuth_diff:
                candidate_images.append((candidate_name, angle_diff))

        # 按角度差排序，选择最接近的几个
        candidate_images.sort(key=lambda x: x[1])
        selected_candidates = candidate_images[:max_pairs_per_image]

        # 添加到匹配对（确保不重复）
        for candidate_img, angle_diff in selected_candidates:
            pair = tuple(sorted([img_name, candidate_img]))  # 排序确保唯一性
            promising_pairs.add(pair)

    # 转换为列表
    promising_pairs = list(promising_pairs)

    # 计算减少的比例
    total_possible_pairs = len(image_paths) * (len(image_paths) - 1) // 2
    reduction_ratio = (total_possible_pairs - len(promising_pairs)) / total_possible_pairs * 100

    print(f"✅ 图像对选择完成:")
    print(f"   总图像数: {len(image_paths)}")
    print(f"   可能的总匹配对数: {total_possible_pairs}")
    print(f"   选定的匹配对数: {len(promising_pairs)}")
    print(f"   匹配对数减少: {reduction_ratio:.1f}%")

    return promising_pairs


def match_selected_pairs_custom(keypoints, descriptors, original_keypoints,
                                image_paths, selected_pairs, feature_type="SAR_SIFT"):
    """
    只对选定的图像对进行匹配
    """
    print(f"🎯 对选定的 {len(selected_pairs)} 个图像对进行特征匹配...")

    matches_dir = os.path.join(args.source_path, "feature_matches")
    if args.save_match_images:
        os.makedirs(matches_dir, exist_ok=True)
        print(f"   特征匹配图将保存到: {matches_dir}")

    # 创建图像路径映射
    img_path_map = {}
    for img_path in image_paths:
        img_name = os.path.basename(img_path)
        img_path_map[img_name] = img_path

    matches_dict = {}
    saved_pairs = 0

    # 只匹配选定的图像对
    for img1_name, img2_name in selected_pairs:
        # 检查两个图像都有特征点
        if img1_name not in descriptors or img2_name not in descriptors:
            continue

        desc1 = descriptors[img1_name]
        desc2 = descriptors[img2_name]

        # 获取关键点位置
        kp1_locations = []
        kp2_locations = []

        for kp in original_keypoints[img1_name]:
            kp1_locations.append([kp.pt[0], kp.pt[1]])

        for kp in original_keypoints[img2_name]:
            kp2_locations.append([kp.pt[0], kp.pt[1]])

        kp1_locations = np.array(kp1_locations)
        kp2_locations = np.array(kp2_locations)

        try:
            # 使用深度匹配进行初始匹配
            good_kp1, good_kp2 = custom_matcher.deep_match(
                kp1_locations, kp2_locations, desc1, desc2, args.max_ratio
            )

            if len(good_kp1) > 0:
                # 使用RANSAC进一步优化匹配
                better_kp1, better_kp2 = custom_matcher.ransac_matching(good_kp1, good_kp2)

                if len(better_kp1) > 0:
                    # 转换为COLMAP格式: [idx1, idx2] 对
                    match_pairs = []

                    # 查找匹配点在原始关键点列表中的索引
                    for kp1, kp2 in zip(better_kp1, better_kp2):
                        # 在kp1_locations中查找kp1的索引
                        idx1 = -1
                        for idx, loc in enumerate(kp1_locations):
                            if abs(loc[0] - kp1[0]) < 1e-5 and abs(loc[1] - kp1[1]) < 1e-5:
                                idx1 = idx
                                break

                        # 在kp2_locations中查找kp2的索引
                        idx2 = -1
                        for idx, loc in enumerate(kp2_locations):
                            if abs(loc[0] - kp2[0]) < 1e-5 and abs(loc[1] - kp2[1]) < 1e-5:
                                idx2 = idx
                                break

                        if idx1 != -1 and idx2 != -1:
                            match_pairs.append([idx1, idx2])

                    if len(match_pairs) > 0:
                        pair_key = (img1_name, img2_name)
                        matches_dict[pair_key] = np.array(match_pairs, dtype=np.uint32)

                        print(
                            f"   ✅ {img1_name} - {img2_name}: 初始匹配 {len(good_kp1)} 个, RANSAC后 {len(better_kp1)} 个")

                        # 保存匹配可视化图像
                        if args.save_match_images and matches_dir is not None and saved_pairs < args.max_match_pairs:
                            img1_path = img_path_map[img1_name]
                            img2_path = img_path_map[img2_name]
                            kp1 = original_keypoints[img1_name]
                            kp2 = original_keypoints[img2_name]

                            # 将匹配点转换为OpenCV格式
                            opencv_matches = []
                            for match_pair in match_pairs[:50]:  # 限制显示数量
                                match_obj = cv2.DMatch()
                                match_obj.queryIdx = match_pair[0]
                                match_obj.trainIdx = match_pair[1]
                                opencv_matches.append(match_obj)

                            custom_matcher.visualize_and_save_matches(
                                img1_path, img2_path, kp1, kp2, opencv_matches, matches_dir, saved_pairs
                            )
                            saved_pairs += 1
                else:
                    print(f"   ⚠️ {img1_name} - {img2_name}: RANSAC后无有效匹配")
            else:
                print(f"   ❌ {img1_name} - {img2_name}: 无初始匹配")

        except Exception as e:
            print(f"   💥 匹配 {img1_name} - {img2_name} 时出错: {e}")
            continue

    print(f"🎯 匹配完成: 总共找到 {len(matches_dict)} 对有效图像匹配")
    return matches_dict


def match_selected_pairs_multiprocess(keypoints, descriptors, original_keypoints,
                                      image_paths, selected_pairs, feature_type="SAR_SIFT"):
    """
    多进程版本的特征匹配
    """
    print(f"🎯 使用多进程对选定的 {len(selected_pairs)} 个图像对进行特征匹配...")

    matches_dir = os.path.join(args.source_path, "feature_matches")
    if args.save_match_images:
        os.makedirs(matches_dir, exist_ok=True)
        print(f"   特征匹配图将保存到: {matches_dir}")

    # 创建图像路径映射
    img_path_map = {}
    for img_path in image_paths:
        img_name = os.path.basename(img_path)
        img_path_map[img_name] = img_path

    matches_dict = {}

    # 使用进程池并行匹配
    num_processes = min(args.parallel_workers, len(selected_pairs), cpu_count())

    # 准备任务参数
    match_tasks = []
    for img1_name, img2_name in selected_pairs:
        if img1_name in descriptors and img2_name in descriptors:
            match_tasks.append((img1_name, img2_name, descriptors[img1_name], descriptors[img2_name],
                                original_keypoints[img1_name], original_keypoints[img2_name],
                                img_path_map.get(img1_name), img_path_map.get(img2_name)))

    print(f"🔧 使用 {num_processes} 个进程并行匹配 {len(match_tasks)} 个图像对")

    with Pool(processes=num_processes) as pool:
        results = pool.map(process_single_pair_match, match_tasks)

    # 处理结果
    saved_pairs = 0
    for (img1_name, img2_name), match_pairs in results:
        if match_pairs is not None and len(match_pairs) > 0:
            matches_dict[(img1_name, img2_name)] = match_pairs

            # 保存匹配可视化图像
            if args.save_match_images and saved_pairs < args.max_match_pairs:
                img1_path = img_path_map[img1_name]
                img2_path = img_path_map[img2_name]
                kp1 = original_keypoints[img1_name]
                kp2 = original_keypoints[img2_name]

                opencv_matches = []
                for match_pair in match_pairs[:50]:
                    match_obj = cv2.DMatch()
                    match_obj.queryIdx = match_pair[0]
                    match_obj.trainIdx = match_pair[1]
                    opencv_matches.append(match_obj)

                custom_matcher.visualize_and_save_matches(
                    img1_path, img2_path, kp1, kp2, opencv_matches, matches_dir, saved_pairs
                )
                saved_pairs += 1

    print(f"🎯 匹配完成: 总共找到 {len(matches_dict)} 对有效图像匹配")
    return matches_dict


def process_single_pair_match(args):
    """
    处理单个图像对匹配 - 用于多进程
    """
    img1_name, img2_name, desc1, desc2, kp1_orig, kp2_orig, img1_path, img2_path = args

    try:
        # 获取关键点位置
        kp1_locations = np.array([[kp.pt[0], kp.pt[1]] for kp in kp1_orig])
        kp2_locations = np.array([[kp.pt[0], kp.pt[1]] for kp in kp2_orig])

        # 使用深度匹配进行初始匹配
        good_kp1, good_kp2 = custom_matcher.deep_match(kp1_locations, kp2_locations, desc1, desc2, args.max_ratio)

        if len(good_kp1) > 0:
            # 使用RANSAC进一步优化匹配
            better_kp1, better_kp2 = custom_matcher.ransac_matching(good_kp1, good_kp2)

            if len(better_kp1) > 0:
                # 转换为COLMAP格式: [idx1, idx2] 对
                match_pairs = []

                for kp1, kp2 in zip(better_kp1, better_kp2):
                    # 查找匹配点在原始关键点列表中的索引
                    idx1 = find_point_index(kp1_locations, kp1)
                    idx2 = find_point_index(kp2_locations, kp2)

                    if idx1 != -1 and idx2 != -1:
                        match_pairs.append([idx1, idx2])

                if len(match_pairs) > 0:
                    return (img1_name, img2_name), np.array(match_pairs, dtype=np.uint32)

    except Exception as e:
        print(f"   💥 匹配 {img1_name} - {img2_name} 时出错: {e}")

    return (img1_name, img2_name), None


def find_point_index(point_locations, target_point, tolerance=1e-5):
    """在点列表中查找目标点的索引"""
    for idx, loc in enumerate(point_locations):
        if abs(loc[0] - target_point[0]) < tolerance and abs(loc[1] - target_point[1]) < tolerance:
            return idx
    return -1


def safe_keypoint_to_dict(kp):
    """将关键点安全转换为字典"""
    return {
        'pt': (float(kp.pt[0]), float(kp.pt[1])) if hasattr(kp, 'pt') else (0.0, 0.0),
        'size': float(kp.size) if hasattr(kp, 'size') and kp.size > 0 else 1.0,
        'angle': float(kp.angle) if hasattr(kp, 'angle') and kp.angle != -1 else 0.0,
        'response': float(kp.response) if hasattr(kp, 'response') else 1.0,
        'octave': int(kp.octave) if hasattr(kp, 'octave') else 0,
        'class_id': int(kp.class_id) if hasattr(kp, 'class_id') else -1
    }


def dict_to_keypoint(kp_dict):
    """将字典转换回关键点"""
    kp = cv2.KeyPoint()
    kp.pt = kp_dict['pt']
    kp.size = kp_dict['size']
    kp.angle = kp_dict['angle']
    kp.response = kp_dict['response']
    kp.octave = kp_dict['octave']
    kp.class_id = kp_dict['class_id']
    return kp


def analyze_match_statistics(matches_dict, min_matches_threshold=5):
    """
    分析匹配统计信息
    显示有多少张不同的图片具有指定数目以上的相同特征点

    Args:
        matches_dict: 匹配字典
        min_matches_threshold: 最小匹配数阈值
    """
    print(f"\n🔍 匹配统计分析 (最小匹配数阈值: {min_matches_threshold})")
    print("=" * 60)

    # 统计每张图像的匹配连接数
    image_connections = {}
    image_match_counts = {}

    for (img1, img2), matches in matches_dict.items():
        match_count = len(matches)

        # 统计满足阈值的匹配对
        if match_count >= min_matches_threshold:
            # 更新图像连接数
            image_connections[img1] = image_connections.get(img1, 0) + 1
            image_connections[img2] = image_connections.get(img2, 0) + 1

            # 记录匹配数量
            if img1 not in image_match_counts:
                image_match_counts[img1] = []
            if img2 not in image_match_counts:
                image_match_counts[img2] = []

            image_match_counts[img1].append((img2, match_count))
            image_match_counts[img2].append((img1, match_count))

    # 统计结果
    total_images = len(image_connections)
    total_pairs = sum(image_connections.values()) // 2  # 因为每对计算了两次

    print(f"📊 总体统计:")
    print(f"   - 具有至少{min_matches_threshold}个匹配点的图像数量: {total_images}")
    print(f"   - 满足条件的图像对数量: {total_pairs}")
    print(f"   - 总匹配对数: {len(matches_dict)}")

    # 显示连接最多的图像
    if image_connections:
        print(f"\n🏆 连接最多的图像 (前10名):")
        sorted_images = sorted(image_connections.items(), key=lambda x: x[1], reverse=True)[:10]

        for i, (img_name, connection_count) in enumerate(sorted_images, 1):
            # 计算平均匹配数
            matches_with_this_image = image_match_counts.get(img_name, [])
            avg_matches = sum(match_count for _, match_count in matches_with_this_image) / len(
                matches_with_this_image) if matches_with_this_image else 0

            print(f"   {i:2d}. {img_name}: {connection_count}个连接, 平均{avg_matches:.1f}个匹配点")

    # 显示最强的匹配对
    print(f"\n💪 最强的匹配对 (前15名):")
    strong_pairs = []

    for (img1, img2), matches in matches_dict.items():
        match_count = len(matches)
        if match_count >= min_matches_threshold:
            strong_pairs.append((img1, img2, match_count))

    # 按匹配数排序
    strong_pairs.sort(key=lambda x: x[2], reverse=True)

    for i, (img1, img2, match_count) in enumerate(strong_pairs[:15], 1):
        print(f"   {i:2d}. {img1} ↔ {img2}: {match_count}个匹配点")

    # 连接性分析
    print(f"\n📈 连接性分析:")
    if total_images > 0:
        connection_counts = list(image_connections.values())
        max_connections = max(connection_counts)
        min_connections = min(connection_counts)
        avg_connections = sum(connection_counts) / len(connection_counts)

        print(f"   - 最大连接数: {max_connections}")
        print(f"   - 最小连接数: {min_connections}")
        print(f"   - 平均连接数: {avg_connections:.1f}")

        # 连接分布
        connection_ranges = {
            "1-2个连接": 0,
            "3-5个连接": 0,
            "6-10个连接": 0,
            "10+个连接": 0
        }

        for count in connection_counts:
            if count <= 2:
                connection_ranges["1-2个连接"] += 1
            elif count <= 5:
                connection_ranges["3-5个连接"] += 1
            elif count <= 10:
                connection_ranges["6-10个连接"] += 1
            else:
                connection_ranges["10+个连接"] += 1

        print(f"   - 连接分布:")
        for range_name, count in connection_ranges.items():
            percentage = (count / total_images) * 100
            print(f"     * {range_name}: {count}张图像 ({percentage:.1f}%)")

    print("=" * 60)

    return {
        'total_images': total_images,
        'total_pairs': total_pairs,
        'image_connections': image_connections,
        'strong_pairs': strong_pairs
    }


print("开始处理MSTAR SAR图像...")
print(f"使用SAR-SIFT特征提取器")
print(f"SAR-SIFT参数: sigma={args.sar_sift_sigma}, ratio={args.sar_sift_ratio}, "
      f"layers={args.sar_sift_layers}, d={args.sar_sift_d}, "
      f"harris_threshold={args.sar_sift_harris_threshold}")
print(
    f"匹配参数: 最大比率={args.max_ratio}, RANSAC迭代={args.ransac_iterations}, RANSAC误差阈值={args.ransac_error_threshold}")
print(f"图像缩放因子: {args.image_scale}")
print(f"GPU设置: 使用GPU={args.use_gpu}, 后端={args.gpu_backend}")  # 添加这一行
# 在文件的最末尾添加以下代码：

if __name__ == "__main__":
    # 多进程保护 - 必须放在最外层
    mp.freeze_support()  # 对于Windows平台很重要

    print("开始处理MSTAR SAR图像...")
    print(f"使用多进程SAR-SIFT特征提取器")

    # 创建必要的目录结构
    os.makedirs(args.source_path + "/sparse/0", exist_ok=True)
    os.makedirs(args.source_path + "/images", exist_ok=True)
    os.makedirs(args.source_path + "/input", exist_ok=True)

    # 将输入图像复制到input目录
    input_dir = args.source_path + "/input_images"  # 假设原始图像在这里
    if os.path.exists(input_dir):
        for img_file in os.listdir(input_dir):
            if img_file.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.tif')):
                shutil.copy2(os.path.join(input_dir, img_file),
                             os.path.join(args.source_path, "input", img_file))
                # 同时复制到images目录
                shutil.copy2(os.path.join(input_dir, img_file),
                             os.path.join(args.source_path, "images", img_file))

    # 收集所有图像文件并解析角度信息
    image_files = []
    angle_info = {}
    for ext in ['*.jpg', '*.jpeg', '*.png', '*.tif', '*.tiff']:
        for img_path in glob.glob(os.path.join(args.source_path, "input", ext)):
            image_files.append(img_path)
            img_name = os.path.basename(img_path)
            depression_angle, azimuth_angle = parse_mstar_filename(img_name)
            angle_info[img_name] = {
                'depression_angle': depression_angle,
                'azimuth_angle': azimuth_angle
            }

    print(f"找到 {len(image_files)} 张SAR图像")

    # 第一步：尝试使用自定义特征运行COLMAP SfM流程
    sfm_success = False
    if not args.skip_matching:
        # 使用多进程提取特征
        keypoints, descriptors, original_keypoints = extract_features_multiprocess(image_files, "SAR_SIFT")

        # 如果特征提取成功，进行匹配
        if len(keypoints) > 0:
            # 选择有希望的图像对进行匹配
            selected_pairs = select_promising_pairs(image_files)

            # 使用自定义匹配器进行匹配
            matches_dict = match_selected_pairs_custom(keypoints, descriptors, original_keypoints, image_files,
                                                       selected_pairs, "SAR_SIFT")

            # 创建数据库并保存特征和匹配
            db_path, image_ids = create_colmap_database_from_features(args.source_path, keypoints, descriptors,
                                                                      args.camera, "SAR_SIFT")
            save_matches_to_database(db_path, matches_dict, image_ids)

            # 添加匹配统计分析
            if matches_dict:
                match_stats = analyze_match_statistics(matches_dict, min_matches_threshold=5)
            else:
                print("❌ 没有找到任何匹配对")
                match_stats = None

            # 运行COLMAP稀疏重建 - 使用已经创建的数据库
            from sar_sparse_reconstruction import SARSparseReconstructor

            reconstructor = SARSparseReconstructor(
                source_path=args.source_path,
                colmap_executable=args.colmap_executable,
                camera_model=args.camera,
                use_gpu=not (args.no_gpu or args.use_cpu),
                image_scale=args.image_scale,
                max_features=args.max_features,
                max_ratio=args.max_ratio,
                ransac_iterations=args.ransac_iterations,
                ransac_error_threshold=args.ransac_error_threshold
            )

            # 直接运行稀疏重建，使用已有的数据库
            db_path = os.path.join(args.source_path, "distorted", "database.db")
            image_dir = os.path.join(args.source_path, "input")

            # 验证数据库内容
            check_database_content(db_path)

            # 运行重建
            sfm_success = reconstructor.run_sparse_reconstruction(db_path, image_dir)
        else:
            print("❌ 特征提取失败，无法进行匹配和重建")
            sfm_success = False

        if not sfm_success:
            print("COLMAP SfM流程失败，将使用基于SAR几何的合成位姿")
    else:
        print("跳过特征匹配和SfM")

    # 第二步：生成SAR专用点云
    points_3d, point_colors = generate_sar_point_cloud(
        image_files, args.sar_height, args.target_height, args.target_base_height,
        args.shadow_height, args.background_height, args.target_density, args.background_density,
        args.point_cloud_scale
    )

    # 保存点云为PLY格式
    ply_path = args.source_path + "/sparse/0/point_cloud.ply"
    save_point_cloud_ply(points_3d, point_colors, ply_path)

    # 第三步：如果SfM失败，创建基于SAR几何的合成位姿
    if not sfm_success:
        print("使用基于SAR几何的合成相机位姿...")
        camera_poses = create_synthetic_camera_poses(
            image_files, args.sar_height, args.depression_angle_scale, args.point_cloud_scale
        )

        # 创建COLMAP文件
        create_colmap_files_from_synthetic_poses(args.source_path, camera_poses, points_3d, point_colors)

        print("基于SAR几何的合成重建完成")
    else:
        print("SfM重建成功完成")

    print("MSTAR SAR图像转换完成!")
    if sfm_success:
        print("✓ 使用SfM生成的相机位姿")
    else:
        print("✓ 使用基于SAR几何的合成相机位姿")
    print("✓ SAR专用点云已生成")
    if args.save_match_images:
        print(f"✓ 特征匹配图已保存到: {args.source_path}/feature_matches/")