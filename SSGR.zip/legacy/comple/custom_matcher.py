# custom_matcher.py - 完整PyTorch GPU加速版本
import numpy as np
import cv2
import random
import math
import torch
import torch.nn.functional as F
import os
from typing import List, Tuple, Dict, Optional  # 确保这行存在
class CustomMatcher:
    """自定义特征匹配器 - 完整PyTorch GPU加速版本"""

    def __init__(self, max_ratio: float = 0.7, ransac_iterations: int = 500,
                 ransac_error_threshold: float = 2.0, use_gpu: bool = True):
        """
        初始化自定义匹配器
        
        Args:
            max_ratio: 匹配比率阈值
            ransac_iterations: RANSAC迭代次数
            ransac_error_threshold: RANSAC误差阈值
            use_gpu: 是否使用GPU加速
        """
        self.max_ratio = max_ratio
        self.ransac_iterations = ransac_iterations
        self.ransac_error_threshold = ransac_error_threshold
        self.use_gpu = use_gpu and torch.cuda.is_available()
        
        # 设置设备
        if self.use_gpu:
            self.device = torch.device('cuda')
            print("✅ 使用PyTorch GPU加速进行特征匹配")
        else:
            self.device = torch.device('cpu')
            print("💻 使用CPU进行特征匹配")
    
    def des_distance(self, deep_des1: np.ndarray, deep_des2: np.ndarray) -> np.ndarray:
        """计算描述符之间的距离矩阵 - GPU加速版本"""
        if self.use_gpu:
            return self._des_distance_gpu(deep_des1, deep_des2)
        else:
            return self._des_distance_cpu(deep_des1, deep_des2)
    
    def _des_distance_gpu(self, deep_des1: np.ndarray, deep_des2: np.ndarray) -> np.ndarray:
        """GPU加速的描述符距离计算"""
        # 转换为PyTorch张量
        des1_tensor = torch.from_numpy(deep_des1).float().to(self.device)  # [N1, D]
        des2_tensor = torch.from_numpy(deep_des2).float().to(self.device)  # [N2, D]
        
        # 使用广播计算所有对之间的距离矩阵
        des1_expanded = des1_tensor.unsqueeze(1)  # [N1, 1, D]
        des2_expanded = des2_tensor.unsqueeze(0)  # [1, N2, D]
        
        # 计算欧氏距离
        error = des1_expanded - des2_expanded
        distances = torch.sqrt(torch.sum(error ** 2, dim=2))  # [N1, N2]
        
        return distances.cpu().numpy()
    
    def _des_distance_cpu(self, deep_des1: np.ndarray, deep_des2: np.ndarray) -> np.ndarray:
        """CPU版本的描述符距离计算"""
        distances = np.zeros((len(deep_des1), len(deep_des2)))
        for i in range(len(deep_des1)):
            for j in range(len(deep_des2)):
                error = deep_des1[i] - deep_des2[j]
                distances[i, j] = np.sqrt(np.sum(error ** 2))
        return distances
    
    def deep_match(self, kp1_location: np.ndarray, kp2_location: np.ndarray, 
                   deep_des1: np.ndarray, deep_des2: np.ndarray, 
                   ratio: Optional[float] = None) -> Tuple[List, List]:
        """使用深度匹配方法进行特征匹配 - GPU加速版本"""
        if ratio is None:
            ratio = self.max_ratio
        
        if self.use_gpu:
            return self._deep_match_gpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio)
        else:
            return self._deep_match_cpu(kp1_location, kp2_location, deep_des1, deep_des2, ratio)
    
    def _deep_match_gpu(self, kp1_location: np.ndarray, kp2_location: np.ndarray,
                       deep_des1: np.ndarray, deep_des2: np.ndarray, 
                       ratio: float) -> Tuple[List, List]:
        """GPU加速的深度匹配"""
        # 计算距离矩阵
        distances = self._des_distance_gpu(deep_des1, deep_des2)
        
        deep_kp1 = []
        deep_kp2 = []
        
        for i in range(len(deep_des1)):
            # 获取当前描述符与所有目标描述符的距离
            dist_i = distances[i]
            
            # 找到两个最近邻
            if len(dist_i) >= 2:
                # 使用PyTorch在GPU上排序
                dist_tensor = torch.from_numpy(dist_i).to(self.device)
                sorted_dist, sorted_indices = torch.sort(dist_tensor)
                
                dist1 = sorted_dist[0].item()
                dist2 = sorted_dist[1].item()
                
                # 比率测试
                if dist1 < dist2 * ratio:
                    best_match_idx = sorted_indices[0].item()
                    deep_kp1.append((kp1_location[i][0], kp1_location[i][1]))
                    deep_kp2.append((kp2_location[best_match_idx][0], 
                                   kp2_location[best_match_idx][1]))
        
        return deep_kp1, deep_kp2
    
    def _deep_match_cpu(self, kp1_location: np.ndarray, kp2_location: np.ndarray,
                       deep_des1: np.ndarray, deep_des2: np.ndarray, 
                       ratio: float) -> Tuple[List, List]:
        """CPU版本的深度匹配"""
        deep_kp1 = []
        deep_kp2 = []
        
        for i in range(deep_des1.shape[0]):
            des = np.tile(deep_des1[i], (deep_des2.shape[0], 1))
            error = des - deep_des2
            RMSE = np.sqrt(np.sum(np.square(error), axis=1) / float(error.shape[1]))
            small_index = np.argsort(RMSE, axis=0)
            
            if RMSE[small_index[0]] < RMSE[small_index[1]] * ratio:
                deep_kp1.append((kp1_location[i][0], kp1_location[i][1]))
                deep_kp2.append((kp2_location[small_index[0]][0], kp2_location[small_index[0]][1]))
        
        return deep_kp1, deep_kp2
    
    def match_sift_keypoints(self, kp1_location: np.ndarray, kp2_location: np.ndarray, 
                            deep_des1: np.ndarray, deep_des2: np.ndarray, 
                            ratio: Optional[float] = None) -> Tuple[List, List]:
        """匹配SIFT关键点 - GPU加速版本"""
        if ratio is None:
            ratio = self.max_ratio
        
        # 使用相同的深度匹配方法
        return self.deep_match(kp1_location, kp2_location, deep_des1, deep_des2, ratio)
    
    def ransac_matching(self, kp1: List, kp2: List, 
                       error_threshold: Optional[float] = None) -> Tuple[List, List]:
        """RANSAC匹配算法 - GPU加速版本"""
        if error_threshold is None:
            error_threshold = self.ransac_error_threshold
        
        if self.use_gpu:
            return self._ransac_matching_gpu(kp1, kp2, error_threshold)
        else:
            return self._ransac_matching_cpu(kp1, kp2, error_threshold)
    
    def _ransac_matching_gpu(self, kp1: List, kp2: List, 
                           error_threshold: float) -> Tuple[List, List]:
        """GPU加速的RANSAC匹配"""
        iterations = self.ransac_iterations
        n = 3  # affine transform
        
        # 转换为PyTorch张量
        kp1_tensor = torch.tensor(kp1, dtype=torch.float32, device=self.device)  # [N, 2]
        kp2_tensor = torch.tensor(kp2, dtype=torch.float32, device=self.device)  # [N, 2]
        
        kp_num = len(kp1)
        most_consensus_number = 0
        better_kp1 = []
        better_kp2 = []
        best_M = None
        
        # 添加齐次坐标
        kp1_homo = torch.cat([kp1_tensor, torch.ones(kp_num, 1, device=self.device)], dim=1).T  # [3, N]
        kp2_homo = torch.cat([kp2_tensor, torch.ones(kp_num, 1, device=self.device)], dim=1).T  # [3, N]
        
        for i in range(iterations):
            # 随机选择3个不重复的点
            indices = torch.randperm(kp_num, device=self.device)[:n]
            
            kp1_rand = kp1_tensor[indices]  # [3, 2]
            kp2_rand = kp2_tensor[indices]  # [3, 2]
            
            try:
                # 计算仿射变换矩阵
                # 构建线性系统: A * M = B
                A = torch.ones((3, 3), device=self.device)
                A[:, :2] = kp1_rand
                
                # 计算变换矩阵 M = A^{-1} * B
                # 对于x坐标
                B_x = kp2_rand[:, 0:1]
                M_x = torch.linalg.solve(A, B_x)
                
                # 对于y坐标  
                B_y = kp2_rand[:, 1:2]
                M_y = torch.linalg.solve(A, B_y)
                
                # 构建完整的变换矩阵
                M = torch.cat([M_x.T, M_y.T], dim=0)  # [2, 3]
                M_stack = torch.cat([M, torch.tensor([[0, 0, 1]], device=self.device)], dim=0)  # [3, 3]
                
                # 变换所有点
                kp1_transform = torch.mm(M_stack, kp1_homo)  # [3, N]
                
                # 计算误差 (只考虑前两维)
                error = kp2_homo[:2] - kp1_transform[:2]  # [2, N]
                
                # 计算每个点的误差范数
                point_errors = torch.sqrt(torch.sum(error ** 2, dim=0))  # [N]
                
                # 找到内点
                inlier_mask = point_errors < error_threshold
                consensus_num = torch.sum(inlier_mask).item()
                
                # 更新最佳结果
                if consensus_num > most_consensus_number:
                    most_consensus_number = consensus_num
                    best_M = M_stack
                    
                    # 保存内点
                    inlier_indices = torch.where(inlier_mask)[0]
                    better_kp1 = kp1_tensor[inlier_indices].cpu().numpy().tolist()
                    better_kp2 = kp2_tensor[inlier_indices].cpu().numpy().tolist()
                    
            except Exception as e:
                # 如果矩阵不可逆，跳过这次迭代
                continue
        
        return better_kp1, better_kp2
    
    def _ransac_matching_cpu(self, kp1: List, kp2: List, 
                           error_threshold: float) -> Tuple[List, List]:
        """CPU版本的RANSAC匹配"""
        iterations = self.ransac_iterations
        n = 3  # affine transform

        most_consensus_number = 0  # correspond keypoint counter
        kp_num = len(kp1)

        # list to matrix
        kp1_matrix = np.zeros((3, kp_num), dtype="f")
        kp2_matrix = np.zeros((3, kp_num), dtype="f")
        for m in range(kp_num):
            kp1_matrix[0][m] = kp1[m][0]
            kp1_matrix[1][m] = kp1[m][1]
            kp1_matrix[2][m] = 1
            kp2_matrix[0][m] = kp2[m][0]
            kp2_matrix[1][m] = kp2[m][1]
            kp2_matrix[2][m] = 1

        better_kp1 = []
        better_kp2 = []
        parameter = None

        for i in range(iterations):
            kp1_rand = np.zeros((n, 2), dtype="f")
            kp2_rand = np.zeros((n, 2), dtype="f")

            # 确保选择的点不重复
            while np.array_equal(kp1_rand[0], kp1_rand[1]) or np.array_equal(kp1_rand[0],
                                                                             kp1_rand[2]) or np.array_equal(kp1_rand[1],
                                                                                                            kp1_rand[2]):
                for j in range(n):
                    rand = random.randint(0, kp_num - 1)
                    kp1_rand[j, 0] = kp1[rand][0]
                    kp1_rand[j, 1] = kp1[rand][1]
                    kp2_rand[j, 0] = kp2[rand][0]
                    kp2_rand[j, 1] = kp2[rand][1]

            # use 3 keypoint to compute transform matrix
            M = cv2.getAffineTransform(kp1_rand, kp2_rand)
            M_stack = np.row_stack((M, [0, 0, 1]))  # transform matrix[a,b,c;d,e,f;0,0,1]

            # transform all kp1 by the matrix
            kp1_transform = np.dot(M_stack, kp1_matrix)
            error = kp2_matrix - kp1_transform
            error = error[0:2].transpose()

            # compute mean square
            mean_square = np.sqrt(np.sum(np.square(error), axis=1) / 2.)
            index = np.where(mean_square < error_threshold)  # return tuple,there is an array in tuple
            consensus_num = index[0].shape[0]

            # update parameter and least_mean_square
            if consensus_num > most_consensus_number:
                better_kp1 = []
                better_kp2 = []
                most_consensus_number = consensus_num
                parameter = M  # select optimal parameter
                for order in range(consensus_num):
                    better_kp1.append(kp1[index[0][order]])
                    better_kp2.append(kp2[index[0][order]])

        return better_kp1, better_kp2
    
    def delete_duplications(self, kp1: np.ndarray, kp2: np.ndarray, 
                           des1: np.ndarray, des2: np.ndarray) -> Tuple:
        """删除重复的关键点"""
        temp_index = []
        for i in range(kp1.shape[0]):
            for j in range(i + 1, kp1.shape[0], 1):
                if i != j and (kp1[i] == kp1[j]).all():
                    temp_index.append(j)
        temp = list(set(temp_index))
        kp1_ = np.delete(kp1, temp, 0)
        des1_ = np.delete(des1, temp, 0)

        temp_index = []
        for k in range(kp2.shape[0]):
            for l in range(k + 1, kp2.shape[0], 1):
                if k != l and (kp2[k] == kp2[l]).all():
                    temp_index.append(l)
        temp = list(set(temp_index))
        kp2_ = np.delete(kp2, temp, 0)
        des2_ = np.delete(des2, temp, 0)
        
        return kp1_, kp2_, des1_, des2_
    
    def least_square_transform(self, kp1: List, kp2: List) -> Tuple[np.ndarray, float]:
        """最小二乘变换计算"""
        kp_num = len(kp1)
        # list to matrix
        kp1_matrix = np.zeros((3, kp_num), dtype="f")
        kp2_matrix = np.zeros((3, kp_num), dtype="f")
        for m in range(kp_num):
            kp1_matrix[0][m] = kp1[m][0]
            kp1_matrix[1][m] = kp1[m][1]
            kp1_matrix[2][m] = 1
            kp2_matrix[0][m] = kp2[m][0]
            kp2_matrix[1][m] = kp2[m][1]
            kp2_matrix[2][m] = 1

        X = kp1_matrix.T
        Y = kp2_matrix.T
        M = np.dot(np.dot(np.linalg.inv(np.dot(X.T, X)), X.T), Y)
        S = M.T

        kp1_transform = np.dot(S, kp1_matrix)
        error = kp2_matrix - kp1_transform
        error = error[0:2].transpose()
        # compute mean square
        mean_square = np.sum(np.square(error), axis=1)
        rmse = np.sqrt(np.sum(mean_square) / float(kp_num))
        solution = S[0:2]

        return solution, rmse
    
    def match_features(self, keypoints: Dict, descriptors: Dict, original_keypoints: Dict, 
                      image_paths: List[str], save_match_images: bool = False, 
                      matches_dir: Optional[str] = None, max_match_pairs: int = 15) -> Dict:
        """
        使用自定义匹配方法进行特征匹配 - 主入口函数
        
        Args:
            keypoints: 关键点数据
            descriptors: 描述符数据
            original_keypoints: 原始关键点
            image_paths: 图像路径列表
            save_match_images: 是否保存匹配图像
            matches_dir: 匹配图像保存目录
            max_match_pairs: 最大保存匹配对数

        Returns:
            matches_dict: 匹配字典
        """
        print("使用自定义匹配方法进行 SAR图像特征匹配...")
        
        # 创建匹配可视化目录
        if save_match_images and matches_dir is not None:
            os.makedirs(matches_dir, exist_ok=True)
            print(f"特征匹配图将保存到: {matches_dir}")

        img_path_map = {}
        for img_path in image_paths:
            img_name = os.path.basename(img_path)
            img_path_map[img_name] = img_path

        matches_dict = {}
        saved_pairs = 0

        img_names = list(descriptors.keys())

        for i in range(len(img_names)):
            img1_name = img_names[i]

            for j in range(i + 1, len(img_names)):
                img2_name = img_names[j]

                # 检查两个图像都有特征点
                if img1_name not in descriptors or img2_name not in descriptors:
                    continue

                desc1 = descriptors[img1_name]
                desc2 = descriptors[img2_name]

                # 获取关键点位置
                kp1_locations = []
                kp2_locations = []

                for kp in original_keypoints[img1_name]:
                    kp1_locations.append([kp.pt[0], kp.pt[1]])

                for kp in original_keypoints[img2_name]:
                    kp2_locations.append([kp.pt[0], kp.pt[1]])

                kp1_locations = np.array(kp1_locations)
                kp2_locations = np.array(kp2_locations)

                try:
                    # 使用深度匹配进行初始匹配
                    good_kp1, good_kp2 = self.deep_match(kp1_locations, kp2_locations, desc1, desc2)

                    if len(good_kp1) > 0:
                        # 使用RANSAC进一步优化匹配
                        better_kp1, better_kp2 = self.ransac_matching(good_kp1, good_kp2)

                        if len(better_kp1) > 0:
                            # 转换为COLMAP格式: [idx1, idx2] 对
                            match_pairs = []

                            # 查找匹配点在原始关键点列表中的索引
                            for kp1, kp2 in zip(better_kp1, better_kp2):
                                # 在kp1_locations中查找kp1的索引
                                idx1 = -1
                                for idx, loc in enumerate(kp1_locations):
                                    if abs(loc[0] - kp1[0]) < 1e-5 and abs(loc[1] - kp1[1]) < 1e-5:
                                        idx1 = idx
                                        break

                                # 在kp2_locations中查找kp2的索引
                                idx2 = -1
                                for idx, loc in enumerate(kp2_locations):
                                    if abs(loc[0] - kp2[0]) < 1e-5 and abs(loc[1] - kp2[1]) < 1e-5:
                                        idx2 = idx
                                        break

                                if idx1 != -1 and idx2 != -1:
                                    match_pairs.append([idx1, idx2])

                            if len(match_pairs) > 0:
                                pair_key = (img1_name, img2_name)
                                matches_dict[pair_key] = np.array(match_pairs, dtype=np.uint32)

                                print(f"图像对 {img1_name} - {img2_name}: 初始匹配 {len(good_kp1)} 个, RANSAC后 {len(better_kp1)} 个")

                                # 保存匹配可视化图像
                                if save_match_images and matches_dir is not None and saved_pairs < max_match_pairs:
                                    img1_path = img_path_map[img1_name]
                                    img2_path = img_path_map[img2_name]
                                    kp1 = original_keypoints[img1_name]
                                    kp2 = original_keypoints[img2_name]

                                    # 将匹配点转换为OpenCV格式
                                    opencv_matches = []
                                    for match_pair in match_pairs[:50]:  # 限制显示数量
                                        match_obj = cv2.DMatch()
                                        match_obj.queryIdx = match_pair[0]
                                        match_obj.trainIdx = match_pair[1]
                                        opencv_matches.append(match_obj)

                                    self.visualize_and_save_matches(img1_path, img2_path, kp1, kp2,
                                                                    opencv_matches, matches_dir, saved_pairs)
                                    saved_pairs += 1

                except Exception as e:
                    print(f"匹配 {img1_name} - {img2_name} 时出错: {e}")
                    continue

        print(f"匹配完成: 总共找到 {len(matches_dict)} 对图像匹配")
        return matches_dict

    def visualize_and_save_matches(self, img1_path: str, img2_path: str,
                                   keypoints1: List[cv2.KeyPoint], keypoints2: List[cv2.KeyPoint],
                                   matches: List[cv2.DMatch], output_dir: str, pair_id: int) -> str:
        """
        可视化并保存特征点匹配图

        Args:
            img1_path: 第一张图像路径
            img2_path: 第二张图像路径
            keypoints1: 第一张图像的关键点
            keypoints2: 第二张图像的关键点
            matches: 匹配列表
            output_dir: 输出目录
            pair_id: 匹配对ID

        Returns:
            保存的图像路径
        """
        try:
            img1 = cv2.imread(img1_path)
            img2 = cv2.imread(img2_path)

            if img1 is None or img2 is None:
                print(f"⚠️ 无法读取图像: {img1_path} 或 {img2_path}")
                return ""

            def resize_image_if_needed(img, max_size=800):
                height, width = img.shape[:2]
                if max(height, width) > max_size:
                    scale = max_size / max(height, width)
                    new_width = int(width * scale)
                    new_height = int(height * scale)
                    return cv2.resize(img, (new_width, new_height))
                return img

            img1 = resize_image_if_needed(img1)
            img2 = resize_image_if_needed(img2)

            # 绘制匹配结果
            match_img = cv2.drawMatches(img1, keypoints1, img2, keypoints2, matches, None,
                                        flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS,
                                        matchColor=(0, 255, 0),
                                        singlePointColor=(255, 0, 0),
                                        matchesMask=None)

            # 添加文本信息
            text = f"Matches: {len(matches)}"
            cv2.putText(match_img, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.putText(match_img, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 1)

            img1_name = os.path.splitext(os.path.basename(img1_path))[0]
            img2_name = os.path.splitext(os.path.basename(img2_path))[0]
            name_text = f"{img1_name} vs {img2_name}"
            cv2.putText(match_img, name_text, (10, match_img.shape[0] - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
            cv2.putText(match_img, name_text, (10, match_img.shape[0] - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)

            # 保存图像
            output_path = os.path.join(output_dir, f"matches_{pair_id:04d}_{img1_name}_vs_{img2_name}.png")
            success = cv2.imwrite(output_path, match_img)

            if success:
                print(f"✅ 保存匹配图: {output_path} (匹配数: {len(matches)})")
                return output_path
            else:
                print(f"❌ 保存匹配图失败: {output_path}")
                return ""

        except Exception as e:
            print(f"❌ 可视化匹配时出错: {e}")
            return ""

# 便捷函数
def create_custom_matcher(max_ratio: float = 0.8, ransac_iterations: int = 800,
                         ransac_error_threshold: float = 1.0, use_gpu: bool = True) -> CustomMatcher:
    """
    创建自定义匹配器的便捷函数
    
    Args:
        max_ratio: 匹配比率阈值
        ransac_iterations: RANSAC迭代次数
        ransac_error_threshold: RANSAC误差阈值
        use_gpu: 是否使用GPU加速
        
    Returns:
        CustomMatcher实例
    """
    return CustomMatcher(max_ratio, ransac_iterations, ransac_error_threshold, use_gpu)


# 测试代码
if __name__ == "__main__":
    # 测试自定义匹配器
    print("测试自定义匹配器...")
    
    # 创建测试数据
    np.random.seed(42)
    kp1 = np.random.rand(100, 2) * 100
    kp2 = kp1 + np.random.randn(100, 2) * 2  # 添加一些噪声
    
    # 创建测试描述符
    desc1 = np.random.rand(100, 128)
    desc2 = desc1 + np.random.randn(100, 128) * 0.1  # 添加一些噪声
    
    # 创建匹配器
    matcher = CustomMatcher(max_ratio=0.8, ransac_iterations=100, use_gpu=True)
    
    # 测试匹配
    good_kp1, good_kp2 = matcher.deep_match(kp1, kp2, desc1, desc2)
    print(f"深度匹配找到 {len(good_kp1)} 个匹配")
    
    if len(good_kp1) > 0:
        better_kp1, better_kp2 = matcher.ransac_matching(good_kp1, good_kp2)
        print(f"RANSAC优化后剩下 {len(better_kp1)} 个匹配")
    
    print("测试完成!")