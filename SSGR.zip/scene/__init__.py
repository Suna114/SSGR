#
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use 
# under the terms of the LICENSE.md file.
#
# For inquiries contact  george.drettakis@inria.fr
#

import os
import random
import json
import math
import numpy as np
import torch
from utils.system_utils import searchForMaxIteration
from scene.dataset_readers import sceneLoadTypeCallbacks
from scene.gaussian_model import GaussianModel
from arguments import ModelParams
from utils.camera_utils import cameraList_from_camInfos, camera_to_JSON

class Scene:

    gaussians : GaussianModel

    def __init__(self, args : ModelParams, gaussians : GaussianModel, load_iteration=None, shuffle=True, resolution_scales=[1.0]):
        """b
        :param path: Path to colmap scene main folder.
        """
        self.model_path = args.model_path
        self.loaded_iter = None
        self.gaussians = gaussians
        # 训练参数快照（用于 save 时 target_only 综合过滤）
        self._loading_args = args
        # 保存目标亮度阈值（从args中获取，如果可用）
        self._target_brightness_threshold = getattr(args, 'target_brightness_threshold', 0.5)

        if load_iteration:
            if load_iteration == -1:
                self.loaded_iter = searchForMaxIteration(os.path.join(self.model_path, "point_cloud"))
            else:
                self.loaded_iter = load_iteration
            print("Loading trained model at iteration {}".format(self.loaded_iter))

        self.train_cameras = {}
        self.test_cameras = {}

        # COLMAP/SfM 外参不重算；sar_mode 下仍加载 sar_params，供 SDGR（--no_sar_fast_mode）附加 R_world_to_radar
        use_sar_geometry = False
        sar_params = None

        if getattr(args, "sar_mode", False):
            try:
                from sar_geometry import DEFAULT_SAR_PARAMS
                sar_params = DEFAULT_SAR_PARAMS.copy()

                if hasattr(args, "sar_camera_height"):
                    sar_params["camera_height"] = args.sar_camera_height
                if hasattr(args, "sar_depression_angle"):
                    sar_params["sita0"] = np.deg2rad(args.sar_depression_angle)
                if hasattr(args, "sar_radius_scale"):
                    sar_params["radius_scale"] = args.sar_radius_scale
                if hasattr(args, "sar_platform_velocity"):
                    sar_params["Va"] = args.sar_platform_velocity
                if hasattr(args, "sar_prf"):
                    sar_params["prf"] = args.sar_prf
                if hasattr(args, "sar_bandwidth"):
                    sar_params["B"] = args.sar_bandwidth
                if hasattr(args, "sar_image_size_azimuth"):
                    sar_params["Na"] = args.sar_image_size_azimuth
                if hasattr(args, "sar_image_size_range"):
                    sar_params["Nr"] = args.sar_image_size_range
                if hasattr(args, "sar_scene_scale"):
                    sar_params["scene_scale"] = args.sar_scene_scale
                if hasattr(args, "sar_camera_distribution_mode"):
                    sar_params["camera_distribution_mode"] = args.sar_camera_distribution_mode
                if hasattr(args, "sar_mstar_filename_depression_convention"):
                    sar_params["mstar_filename_depression_convention"] = (
                        args.sar_mstar_filename_depression_convention
                    )

                mapping_file = os.path.join(args.source_path, "depression_angle_mapping.json")
                depression_angle_mapping = None

                if os.path.exists(mapping_file):
                    print(f"\n发现俯视角映射文件: {mapping_file}")
                    try:
                        with open(mapping_file, "r", encoding="utf-8") as f:
                            depression_angle_mapping = json.load(f)
                        print(f"   加载了 {len(depression_angle_mapping)} 个图像的俯视角映射")
                    except Exception as e:
                        print(f"   加载映射文件失败: {e}")
                        depression_angle_mapping = None
                else:
                    print(f"\n未找到俯视角映射文件: {mapping_file}（将使用文件名俯视角）")

                sar_params["depression_angle_mapping"] = depression_angle_mapping

                scale_params_file = os.path.join(args.source_path, "sar_scale_params.json")
                if os.path.exists(scale_params_file):
                    print(f"\n发现SAR尺度参数文件: {scale_params_file}")
                    try:
                        with open(scale_params_file, "r", encoding="utf-8") as f:
                            scale_params = json.load(f)

                        if "unified_radius_scale" in scale_params:
                            radius_scale = scale_params["unified_radius_scale"]
                            print(f"   使用统一半径缩放: {radius_scale:.4f}")
                        elif "estimated_radius_scale" in scale_params:
                            radius_scale = scale_params["estimated_radius_scale"]
                            print(f"   使用估算半径缩放: {radius_scale:.4f}")
                        else:
                            radius_scale = 1.0

                        sar_params["radius_scale"] = radius_scale
                        sar_params["default_radius_scale"] = radius_scale

                        if "unified_focal_azimuth" in scale_params:
                            sar_params["unified_focal_azimuth"] = scale_params["unified_focal_azimuth"]
                            sar_params["unified_focal_range"] = scale_params["unified_focal_range"]
                            sar_params["unified_cx"] = scale_params["unified_cx"]
                            sar_params["unified_cy"] = scale_params["unified_cy"]
                        if "camera_height" in scale_params:
                            try:
                                ch = float(scale_params["camera_height"])
                                if math.isfinite(ch) and 1e-9 < ch < 1e7:
                                    sar_params["camera_height"] = ch
                                    print(f"   使用SfM尺度文件 camera_height(场景单位): {ch:.4f}")
                            except (TypeError, ValueError):
                                pass
                        if "camera_distribution_mode" in scale_params:
                            mode = str(scale_params["camera_distribution_mode"]).strip().lower()
                            if mode in ("ring", "sphere"):
                                sar_params["camera_distribution_mode"] = mode
                        if "range_pixel_spacing" in scale_params:
                            sar_params["range_pixel_spacing"] = float(scale_params["range_pixel_spacing"])
                        if "azimuth_pixel_spacing" in scale_params:
                            sar_params["azimuth_pixel_spacing"] = float(scale_params["azimuth_pixel_spacing"])
                        if "scene_scale" in scale_params:
                            sar_params["scene_scale"] = float(scale_params["scene_scale"])
                    except Exception as e:
                        print(f"   加载尺度参数失败: {e}")
                else:
                    print(f"\n未找到SAR尺度参数文件: {scale_params_file}（使用默认 radius_scale）")

                if use_sar_geometry:
                    distribution_mode = sar_params.get("camera_distribution_mode", "sphere")
                    print(f"\n使用SAR几何重算位姿，相机高度: {sar_params['camera_height']:.1f}m")
                    print(f"相机分布模式: {distribution_mode}")
                else:
                    print(
                        "\n[SAR] 保留 COLMAP/SfM 外参；为每视角附加 R_world_to_radar（供 --no_sar_fast_mode / SDGR）"
                    )
            except ImportError:
                print("警告: SAR几何模块未找到，SAR模式将不可用")
                sar_params = None
                use_sar_geometry = False

        mstar_nosfm = getattr(args, "mstar_nosfm", False)
        if mstar_nosfm:
            img_sub = "images" if args.images in (None, "") else args.images
            if not os.path.isdir(os.path.join(args.source_path, img_sub)):
                assert False, (
                    f"mstar_nosfm: 未找到图像目录 {os.path.join(args.source_path, img_sub)}；"
                    "请放置 MSTAR 式命名图像(如 T72-15-001.bmp)"
                )
            llff = 8
            if "360" in str(args.source_path) and args.eval:
                llff = 8
            print(
                "\n[Scene] 使用 MSTAR 无 SfM 数据加载: 位姿仅由文件名(目标-俯视角-方位角)与 sar_geometry 生成, "
                "不读取 sparse/0"
            )
            scene_info = sceneLoadTypeCallbacks["MstarNoSfM"](
                args.source_path, args.images, args.eval, args.train_test_exp, llff, args
            )
        elif os.path.exists(os.path.join(args.source_path, "sparse")):
            scene_info = sceneLoadTypeCallbacks["Colmap"](
                args.source_path, args.images, args.depths, args.eval, args.train_test_exp,
                sar_params=sar_params, use_sar_geometry=use_sar_geometry,
                scattering_masks=getattr(args, "scattering_masks", None),
            )
        elif os.path.exists(os.path.join(args.source_path, "transforms_train.json")):
            print("Found transforms_train.json file, assuming Blender data set!")
            scene_info = sceneLoadTypeCallbacks["Blender"](args.source_path, args.white_background, args.depths, args.eval)
        else:
            assert False, (
                "Could not recognize scene type! 若仅有多视图 SAR 图而无 COLMAP, 请使用 train_sar_complete_nosfm.py "
                "或命令行加 --mstar_nosfm"
            )

        if not self.loaded_iter:
            with open(scene_info.ply_path, 'rb') as src_file, open(os.path.join(self.model_path, "input.ply") , 'wb') as dest_file:
                dest_file.write(src_file.read())
            json_cams = []
            camlist = []
            if scene_info.test_cameras:
                camlist.extend(scene_info.test_cameras)
            if scene_info.train_cameras:
                camlist.extend(scene_info.train_cameras)
            for id, cam in enumerate(camlist):
                json_cams.append(camera_to_JSON(id, cam))
            with open(os.path.join(self.model_path, "cameras.json"), 'w') as file:
                json.dump(json_cams, file)

        if shuffle:
            random.shuffle(scene_info.train_cameras)  # Multi-res consistent random shuffling
            random.shuffle(scene_info.test_cameras)  # Multi-res consistent random shuffling

        self.cameras_extent = scene_info.nerf_normalization["radius"]

        for resolution_scale in resolution_scales:
            print("Loading Training Cameras")
            self.train_cameras[resolution_scale] = cameraList_from_camInfos(scene_info.train_cameras, resolution_scale, args, scene_info.is_nerf_synthetic, False)
            print("Loading Test Cameras")
            self.test_cameras[resolution_scale] = cameraList_from_camInfos(scene_info.test_cameras, resolution_scale, args, scene_info.is_nerf_synthetic, True)

        if self.loaded_iter:
            self.gaussians.load_ply(os.path.join(self.model_path,
                                                           "point_cloud",
                                                           "iteration_" + str(self.loaded_iter),
                                                           "point_cloud.ply"), args.train_test_exp)
        else:
            self.gaussians.create_from_pcd(scene_info.point_cloud, scene_info.train_cameras, self.cameras_extent)

    def _mean_training_camera_center(self):
        """用于 target_only 视图相关着色：训练相机中心的平均值（世界坐标，与 gaussians 同 device）。"""
        if not getattr(self, "train_cameras", None):
            return None
        scales = list(self.train_cameras.keys())
        if not scales:
            return None
        scale_key = 1.0 if 1.0 in self.train_cameras else scales[0]
        cams = self.train_cameras[scale_key]
        centers = []
        for cam in cams:
            c = cam.camera_center
            if isinstance(c, torch.Tensor):
                centers.append(c.detach().reshape(1, 3))
            else:
                centers.append(
                    torch.as_tensor(
                        c, dtype=torch.float32, device=self.gaussians.get_xyz.device
                    ).reshape(1, 3)
                )
        if not centers:
            return None
        return torch.cat(centers, dim=0).mean(dim=0)

    def _build_target_only_mask(self):
        """
        point_cloud_target_only.ply：默认仅按球谐 DC 亮度去掉偏黑背景点（brightness >= target_brightness_threshold）。
        可选 target_ply_min_peak_rgb：要求 max(R,G,B) 足够大，剔除整体仍偏黑的点。
        可选 target_ply_min_floor_rgb：要求 min(R,G,B) 不低于阈值，去掉任一路过低而发灰/发黑外观的点。
        可选 target_ply_max_chroma：限制 RGB 色散。棕偏黑 vs 棕偏白主要靠亮度：用 target_ply_drop_darkest_percent
        （或 target_ply_brightness_tight_percentile）去掉当前掩码里最暗的一段，保留更亮的棕。
        主体周稀疏同色杂点：target_ply_sparse_trim_percent（掩码内 kNN，需 scipy）。
        target_ply_use_view_dependent_color：按完整 SH 在「相机中心→点」方向的颜色过滤（对齐 gaussian_renderer 中 convert_SHs_python 的 eval_sh+0.5），
        用于 DC 仍偏亮、但高阶项使训练视角下观感发黑的高斯（PLY 顶点色仍为 DC，与过滤所用颜色可不一致）。
        """
        from utils.sh_utils import SH2RGB, eval_sh

        a = self._loading_args
        dc_rgb = torch.clamp(SH2RGB(self.gaussians._features_dc.squeeze(1)), 0.0, 1.0)

        use_view_color = bool(getattr(a, "target_ply_use_view_dependent_color", False))
        color_mode_note = "DC(与 PLY 顶点色一致)"
        rgb_t = dc_rgb
        if use_view_color:
            mean_cc = self._mean_training_camera_center()
            if mean_cc is not None:
                mean_cc = mean_cc.to(device=self.gaussians.get_xyz.device, dtype=self.gaussians.get_xyz.dtype)
                xyz_t = self.gaussians.get_xyz
                dir_pp = xyz_t - mean_cc.unsqueeze(0)
                dir_n = dir_pp / dir_pp.norm(dim=1, keepdim=True).clamp_min(1e-9)
                sh_deg = int(self.gaussians.active_sh_degree)
                shs = self.gaussians.get_features.transpose(1, 2).contiguous()
                rgb_t = torch.clamp(eval_sh(sh_deg, shs, dir_n) + 0.5, 0.0, 1.0)
                color_mode_note = "视图相关 SH(训练相机中心→点)"
            else:
                color_mode_note = "DC(无训练相机，回退)"

        rgb_colors = rgb_t.detach().cpu().numpy()
        brightness = (
            0.299 * rgb_colors[:, 0]
            + 0.587 * rgb_colors[:, 1]
            + 0.114 * rgb_colors[:, 2]
        )

        thr = float(getattr(a, "target_brightness_threshold", 0.5))
        if bool(getattr(a, "sar_mode", False)):
            cap = float(getattr(a, "sar_target_only_ply_luma_cap", 0.22))
            thr_eff = min(thr, cap)
            if thr_eff < thr - 1e-9:
                stats_lines_extra = f"（SAR 上限 cap={cap:.2f}，有效阈值={thr_eff:.3f}）"
            else:
                stats_lines_extra = ""
            thr = thr_eff
        else:
            stats_lines_extra = ""
        mask = brightness >= thr
        stats_lines = [
            f"颜色模式: {color_mode_note}",
            f"去暗背景(亮度>={thr:.2f}){stats_lines_extra}: {np.count_nonzero(mask)} / {len(mask)}",
        ]

        peak_min = float(getattr(a, "target_ply_min_peak_rgb", 0.0) or 0.0)
        if peak_min > 0.0:
            peak = np.max(rgb_colors, axis=1)
            mask &= peak >= peak_min
            stats_lines.append(f"去近黑(max(R,G,B)>={peak_min:.2f}): {np.count_nonzero(mask)}")

        floor_rgb = float(getattr(a, "target_ply_min_floor_rgb", 0.0) or 0.0)
        if floor_rgb > 0.0:
            mask &= np.min(rgb_colors, axis=1) >= floor_rgb
            stats_lines.append(f"去单通道过低(min(R,G,B)>={floor_rgb:.2f}): {np.count_nonzero(mask)}")

        chroma_max = float(getattr(a, "target_ply_max_chroma", 0.0) or 0.0)
        if chroma_max > 0.0:
            spread = np.max(rgb_colors, axis=1) - np.min(rgb_colors, axis=1)
            mask &= spread <= chroma_max
            stats_lines.append(f"去有色杂点(max(RGB差)<={chroma_max:.2f}): {np.count_nonzero(mask)}")

        drop_pct = float(getattr(a, "target_ply_drop_darkest_percent", 0.0) or 0.0)
        if drop_pct <= 0.0:
            drop_pct = float(getattr(a, "target_ply_brightness_tight_percentile", 0.0) or 0.0)
        if drop_pct > 0.0 and np.count_nonzero(mask) > 1:
            sub = brightness[mask].astype(np.float64)
            q = min(99.5, max(0.5, drop_pct))
            cut = float(np.percentile(sub, q))
            mask &= brightness >= cut
            stats_lines.append(
                f"去偏暗棕(亮度<{q:.0f}%分位≈{cut:.3f}，留偏白棕): {np.count_nonzero(mask)}"
            )

        min_o = float(getattr(a, "target_ply_min_opacity", 0.0) or 0.0)
        if min_o > 0.0:
            op = self.gaussians.get_opacity.detach().cpu().numpy().reshape(-1)
            mask &= op >= min_o
            stats_lines.append(f"不透明度>={min_o:.3f}: {np.count_nonzero(mask)}")

        use_scale = bool(getattr(a, "target_ply_use_scale_filter", False))
        if use_scale:
            max_s = float(getattr(a, "max_scale_threshold", 0.5) or 0.5)
            scales = self.gaussians.get_scaling.detach().cpu().numpy()
            max_scales = scales.max(axis=1)
            mask &= max_scales <= max_s
            stats_lines.append(f"max尺度<={max_s:.3f}: {np.count_nonzero(mask)}")

        xyz = self.gaussians._xyz.detach().cpu().numpy()
        N = xyz.shape[0]
        k_neighbors = int(getattr(a, "density_k_neighbors", 10) or 10)
        do_density = bool(getattr(a, "target_ply_density_filter", False)) and N > k_neighbors

        if do_density:
            try:
                from scipy.spatial import KDTree
            except ImportError:
                do_density = False
                stats_lines.append("密度过滤: 跳过(未安装 scipy)")

        if do_density and np.count_nonzero(mask) > k_neighbors:
            density_pct = float(getattr(a, "density_threshold_percentile", 20.0) or 20.0)
            tree = KDTree(xyz)
            distances, _ = tree.query(xyz, k=k_neighbors + 1)
            avg_distances = np.mean(distances[:, 1:], axis=1)
            dist_cut = np.percentile(avg_distances, 100.0 - density_pct)
            density_ok = avg_distances <= dist_cut
            mask &= density_ok
            stats_lines.append(f"KNN密度(>{100-density_pct:.0f}%): {np.count_nonzero(mask)}")

        use_dist = bool(getattr(a, "target_ply_use_distance_filter", False))
        dist_pct = float(getattr(a, "distance_threshold_percentile", 70.0) or 70.0)
        if use_dist and dist_pct < 100.0 and np.count_nonzero(mask) > 0:
            valid_xyz = xyz[mask]
            center = np.mean(valid_xyz, axis=0)
            dist_c = np.linalg.norm(xyz - center, axis=1)
            valid_d = dist_c[mask]
            d_cut = np.percentile(valid_d, dist_pct)
            mask &= dist_c <= d_cut
            stats_lines.append(f"距中心<={dist_pct:.0f}%分位: {np.count_nonzero(mask)}")

        sparse_trim = float(getattr(a, "target_ply_sparse_trim_percent", 0.0) or 0.0)
        k_loc = int(getattr(a, "target_ply_local_k_neighbors", 8) or 8)
        if sparse_trim > 0.0 and np.count_nonzero(mask) > k_loc + 2:
            try:
                from scipy.spatial import KDTree as _KDTreeSparse
            except ImportError:
                stats_lines.append("去稀疏杂点: 跳过(需 pip install scipy)")
            else:
                idx = np.flatnonzero(mask)
                sub_xyz = xyz[idx]
                tloc = _KDTreeSparse(sub_xyz)
                d_nn, _ = tloc.query(sub_xyz, k=min(k_loc + 1, sub_xyz.shape[0]))
                if d_nn.ndim == 1:
                    d_nn = d_nn.reshape(-1, 1)
                local_mean = np.mean(d_nn[:, 1:], axis=1)
                st = min(99.0, max(0.5, sparse_trim))
                thr_loc = float(np.percentile(local_mean, 100.0 - st))
                keep_local = local_mean <= thr_loc
                mask_sparse = np.zeros(N, dtype=bool)
                mask_sparse[idx] = keep_local
                mask &= mask_sparse
                stats_lines.append(
                    f"去主体周稀疏点(掩码内{k_loc}NN,删最孤立{st:.0f}%): {np.count_nonzero(mask)}"
                )

        if N > 0 and np.count_nonzero(mask) == 0:
            pct = float(getattr(a, "target_only_fallback_percentile", 32.0))
            pct = min(95.0, max(1.0, pct))
            thr_fb = float(np.percentile(brightness.astype(np.float64), pct))
            mask = brightness >= thr_fb
            stats_lines.append(
                f"前述规则无保留点 → 自动回退：亮度≥{thr_fb:.4f}（{pct:.0f}%分位，削约最暗{pct:.0f}%）: "
                f"{np.count_nonzero(mask)} / {N}"
            )
            min_o_fb = float(getattr(a, "target_ply_min_opacity", 0.0) or 0.0)
            if min_o_fb > 0.0:
                op = self.gaussians.get_opacity.detach().cpu().numpy().reshape(-1)
                mask &= op >= min_o_fb
                stats_lines.append(
                    f"回退后仍应用不透明度>={min_o_fb:.3f}: {np.count_nonzero(mask)}"
                )
        if N > 0 and np.count_nonzero(mask) == 0:
            mask[:] = True
            stats_lines.append(
                "回退后仍为空（亮度几乎无分散），已保留全部点写入 target_only；"
                "建议检查训练或改用 --target_brightness_threshold / --sar_target_only_ply_luma_cap"
            )

        return mask, stats_lines

    def save(self, iteration):
        point_cloud_path = os.path.join(self.model_path, "point_cloud/iteration_{}".format(iteration))
        # 与原版 3DGS / SIBR_gaussianViewer 一致：不写 red/green/blue，避免查看器 CUDA 侧按固定布局读 PLY 越界
        self.gaussians.save_ply(
            os.path.join(point_cloud_path, "point_cloud.ply"),
            include_vertex_rgb=False,
        )
        
        # point_cloud_target_only：默认仅按亮度去黑背景；加强过滤请用 target_ply_* / --target_ply_use_scale_filter 等
        try:
            a = self._loading_args
            _chroma = float(getattr(a, "target_ply_max_chroma", 0.0) or 0.0)
            _chroma_s = f"{_chroma:.3f}" if _chroma > 0.0 else "关"
            _view = bool(getattr(a, "target_ply_use_view_dependent_color", False))
            print(
                f"   [target_only 参数] view_SH={_view} "
                f"luma>={getattr(a, 'target_brightness_threshold', '?')} "
                f"peak>={getattr(a, 'target_ply_min_peak_rgb', '?')} "
                f"floor>={getattr(a, 'target_ply_min_floor_rgb', '?')} "
                f"chroma<={_chroma_s}"
            )
            target_mask, filter_stats = self._build_target_only_mask()
            num_target_points = int(np.sum(target_mask))
            num_background_points = len(target_mask) - num_target_points
            
            if num_target_points > 0:
                print(f"\n🎯 目标点云（去暗背景，迭代 {iteration}):")
                for line in filter_stats:
                    print(f"   · {line}")
                print(
                    f"   · 最终保留: {num_target_points} ({100*num_target_points/len(target_mask):.1f}%), "
                    f"滤除: {num_background_points}"
                )
                target_point_cloud_path = os.path.join(point_cloud_path, "point_cloud_target_only.ply")
                self.gaussians.save_ply_filtered(target_point_cloud_path, target_mask)
                print(f"   ✅ 目标点云已保存: {target_point_cloud_path}")
            else:
                print(
                    f"\n⚠️ 警告: 按当前条件过滤后无剩余点（可调低 --target_brightness_threshold / "
                    f"--target_ply_drop_darkest_percent / --target_ply_sparse_trim_percent，或放宽其它阈值）"
                )
        except Exception as e:
            print(f"⚠️ 保存目标点云时出错: {e}")
            import traceback
            traceback.print_exc()
        
        exposure_dict = {
            image_name: self.gaussians.get_exposure_from_name(image_name).detach().cpu().numpy().tolist()
            for image_name in self.gaussians.exposure_mapping
        }

        with open(os.path.join(self.model_path, "exposure.json"), "w") as f:
            json.dump(exposure_dict, f, indent=2)
        
        # 🔧 新增：在训练完成后，根据相机到场景中心的距离重新计算焦距
        # 这可以解决不同距离相机使用相同焦距导致的分层问题
        self._update_camera_focal_lengths_based_on_distance(iteration)

    def getTrainCameras(self, scale=1.0):
        return self.train_cameras[scale]

    def getTestCameras(self, scale=1.0):
        return self.test_cameras[scale]
    
    def _update_camera_focal_lengths_based_on_distance(self, iteration):
        """
        根据相机到场景中心的距离重新计算焦距
        解决不同距离相机使用相同焦距导致的分层问题
        
        原理：
        - 焦距应该与相机到场景的距离成正比
        - 距离越远，焦距应该越大（保持相同的FOV）
        - 使用公式: focal_new = focal_base * (distance / distance_base)
        """
        try:
            from utils.graphics_utils import fov2focal, focal2fov
            
            # 计算场景中心（使用高斯点云的中心）
            gaussian_xyz = self.gaussians.get_xyz.detach().cpu().numpy()
            scene_center = np.mean(gaussian_xyz, axis=0)
            
            # 获取所有相机
            camlist = []
            if hasattr(self, 'train_cameras') and self.train_cameras:
                camlist.extend(list(self.train_cameras.values())[0])  # 获取第一个分辨率的相机
            if hasattr(self, 'test_cameras') and self.test_cameras:
                camlist.extend(list(self.test_cameras.values())[0])
            
            if len(camlist) == 0:
                print("⚠️ 警告: 没有找到相机，跳过焦距更新")
                return
            
            # 计算每个相机到场景中心的距离
            camera_distances = []
            camera_positions = []
            
            for cam in camlist:
                # 计算相机位置（世界坐标系）
                # R是相机旋转矩阵（从世界到相机），T是平移向量
                # 相机位置 = -R^T * T
                R = cam.R  # 3x3 旋转矩阵
                T = cam.T  # 3x1 平移向量
                cam_pos = -np.dot(R.T, T)
                
                # 计算距离
                distance = np.linalg.norm(cam_pos - scene_center)
                camera_distances.append(distance)
                camera_positions.append(cam_pos)
            
            camera_distances = np.array(camera_distances)
            camera_positions = np.array(camera_positions)
            
            # 计算基准距离（使用中位数，更稳健）
            base_distance = np.median(camera_distances)
            
            # 获取基准焦距（使用当前焦距的中位数）
            base_focal_x = []
            base_focal_y = []
            for cam in camlist:
                fx = fov2focal(cam.FoVx, cam.image_width)
                fy = fov2focal(cam.FoVy, cam.image_height)
                base_focal_x.append(fx)
                base_focal_y.append(fy)
            
            base_focal_x = np.median(base_focal_x)
            base_focal_y = np.median(base_focal_y)
            
            print(f"\n📐 更新相机焦距（基于距离，迭代 {iteration}）:")
            print(f"   场景中心: [{scene_center[0]:.2f}, {scene_center[1]:.2f}, {scene_center[2]:.2f}]")
            print(f"   基准距离: {base_distance:.2f}")
            print(f"   基准焦距: fx={base_focal_x:.2f}, fy={base_focal_y:.2f}")
            print(f"   距离范围: [{np.min(camera_distances):.2f}, {np.max(camera_distances):.2f}]")
            
            # 更新每个相机的焦距并创建JSON条目
            updated_count = 0
            json_cams = []
            
            for id, cam in enumerate(camlist):
                # 计算当前相机到场景中心的距离
                distance = camera_distances[id]
                
                # 计算距离比例
                distance_ratio = distance / base_distance if base_distance > 0 else 1.0
                
                # 计算新焦距（根据距离调整）
                # 使用距离比例直接缩放焦距
                new_fx = base_focal_x * distance_ratio
                new_fy = base_focal_y * distance_ratio
                
                # 更新相机的FOV（从新焦距计算）
                new_fovx = focal2fov(new_fx, cam.image_width)
                new_fovy = focal2fov(new_fy, cam.image_height)
                
                # 检查是否有变化
                old_fx = fov2focal(cam.FoVx, cam.image_width)
                if abs(new_fx - old_fx) > 0.01:
                    updated_count += 1
                
                # 创建JSON条目
                # 计算相机位置（用于JSON输出）
                R = cam.R
                T = cam.T
                cam_pos = -np.dot(R.T, T)
                
                camera_entry = {
                    "id": id,
                    "img_name": cam.image_name,
                    "width": cam.image_width,
                    "height": cam.image_height,
                    "position": cam_pos.tolist(),
                    "rotation": R.tolist(),
                    "fx": float(new_fx),
                    "fy": float(new_fy)
                }
                json_cams.append(camera_entry)
            
            # 保存更新后的cameras.json
            cameras_file = os.path.join(self.model_path, "cameras.json")
            with open(cameras_file, 'w') as file:
                json.dump(json_cams, file)
            
            print(f"   ✅ 已更新 {updated_count}/{len(camlist)} 个相机的焦距")
            print(f"   ✅ 已保存更新后的cameras.json: {cameras_file}")
            
            # 显示焦距统计
            focal_x_values = [c['fx'] for c in json_cams]
            focal_y_values = [c['fy'] for c in json_cams]
            print(f"   焦距范围: fx=[{min(focal_x_values):.2f}, {max(focal_x_values):.2f}], "
                  f"fy=[{min(focal_y_values):.2f}, {max(focal_y_values):.2f}]")
            print(f"   焦距均值: fx={np.mean(focal_x_values):.2f}, fy={np.mean(focal_y_values):.2f}")
            
        except Exception as e:
            print(f"⚠️ 更新相机焦距时出错: {e}")
            import traceback
            traceback.print_exc()
