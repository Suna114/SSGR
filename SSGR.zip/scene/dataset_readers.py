#
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use 
# under the terms of the LICENSE.md file.
#
# For inquiries contact  george.drettakis@inria.fr
#

import os
import sys
import glob
from PIL import Image
from typing import NamedTuple
from scene.colmap_loader import read_extrinsics_text, read_intrinsics_text, qvec2rotmat, \
    read_extrinsics_binary, read_intrinsics_binary, read_points3D_binary, read_points3D_text
from utils.graphics_utils import getWorld2View2, focal2fov, fov2focal
import numpy as np
import json
from pathlib import Path
from plyfile import PlyData, PlyElement
from utils.sh_utils import SH2RGB
from scene.gaussian_model import BasicPointCloud

# SAR几何模型支持
try:
    from sar_geometry import compute_sar_camera_pose, DEFAULT_SAR_PARAMS
    from sar_utils import parse_mstar_filename, parse_mstar_filename_quiet
    SAR_GEOMETRY_AVAILABLE = True
except ImportError:
    SAR_GEOMETRY_AVAILABLE = False
    print("警告: SAR几何模块未找到，SAR相机位姿计算将不可用")
    parse_mstar_filename_quiet = None  # type: ignore


def _resolve_depression_azimuth(image_name: str, sar_params: dict):
    """从 MSTAR 式文件名 + 可选映射得到俯仰/方位角（度）。"""
    if parse_mstar_filename_quiet is not None:
        _tgt, depression_angle_original, azimuth_angle = parse_mstar_filename_quiet(image_name)
    else:
        depression_angle_original, azimuth_angle = parse_mstar_filename(image_name)
    depression_angle = depression_angle_original
    mapping = sar_params.get("depression_angle_mapping") if sar_params else None
    if mapping:
        if image_name in mapping:
            depression_angle = mapping[image_name]
        else:
            stem = os.path.splitext(image_name)[0]
            if stem in mapping:
                depression_angle = mapping[stem]
    return depression_angle, azimuth_angle


def _attach_sar_radar_metadata(image_name: str, width: int, height: int, sar_params: dict):
    """在保留 COLMAP 外参时，为 SDGR 附加 R_world_to_radar 与 per-view sar_params。"""
    depression_angle, azimuth_angle = _resolve_depression_azimuth(image_name, sar_params)
    R_sar, _T_sar, _K_sar = compute_sar_camera_pose(depression_angle, azimuth_angle, sar_params)
    cam_sar_params = sar_params.copy()
    cam_sar_params["Na"] = width
    cam_sar_params["Nr"] = height
    return R_sar, True, cam_sar_params


class CameraInfo(NamedTuple):
    uid: int
    R: np.array
    T: np.array
    FovY: np.array
    FovX: np.array
    depth_params: dict
    image_path: str
    image_name: str
    depth_path: str
    width: int
    height: int
    is_test: bool
    # SAR相关参数（可选）
    R_world_to_radar: np.array = None
    use_sar_rendering: bool = False
    sar_params: dict = None
    # 与 convert/feature_extraction 一致的语义掩码（0 背景 / 1 目标含原边缘 / 3 阴影；不再输出 2），可选
    scattering_mask: np.array = None

class SceneInfo(NamedTuple):
    point_cloud: BasicPointCloud
    train_cameras: list
    test_cameras: list
    nerf_normalization: dict
    ply_path: str
    is_nerf_synthetic: bool

def getNerfppNorm(cam_info):
    def get_center_and_diag(cam_centers):
        cam_centers = np.hstack(cam_centers)
        avg_cam_center = np.mean(cam_centers, axis=1, keepdims=True)
        center = avg_cam_center
        dist = np.linalg.norm(cam_centers - center, axis=0, keepdims=True)
        diagonal = np.max(dist)
        return center.flatten(), diagonal

    cam_centers = []

    for cam in cam_info:
        W2C = getWorld2View2(cam.R, cam.T)
        C2W = np.linalg.inv(W2C)
        cam_centers.append(C2W[:3, 3:4])

    center, diagonal = get_center_and_diag(cam_centers)
    radius = diagonal * 1.1

    translate = -center

    return {"translate": translate, "radius": radius}


def _lookup_scattering_mask(scattering_masks: dict, image_name: str):
    """按完整文件名或去扩展名匹配预处理得到的掩码字典。"""
    if not scattering_masks:
        return None
    if image_name in scattering_masks:
        return scattering_masks[image_name]
    stem = os.path.splitext(image_name)[0]
    if stem in scattering_masks:
        return scattering_masks[stem]
    for k, v in scattering_masks.items():
        if os.path.splitext(k)[0] == stem:
            return v
    return None


IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp")


def _resolve_image_path(images_folder: str, image_name: str) -> str:
    image_path = os.path.join(images_folder, image_name)
    if os.path.exists(image_path):
        return image_path

    stem, ext = os.path.splitext(image_name)
    candidates = []
    if ext:
        candidates.extend([stem + ext.lower(), stem + ext.upper()])
    candidates.extend(stem + candidate_ext for candidate_ext in IMAGE_EXTS)
    candidates.extend(stem + candidate_ext.upper() for candidate_ext in IMAGE_EXTS)

    for candidate_name in candidates:
        candidate_path = os.path.join(images_folder, candidate_name)
        if os.path.exists(candidate_path):
            return candidate_path

    matches = [
        p
        for p in glob.glob(os.path.join(images_folder, stem + ".*"))
        if os.path.splitext(p)[1].lower() in IMAGE_EXTS
    ]
    if matches:
        return sorted(matches)[0]
    return image_path


def readColmapCameras(
    cam_extrinsics,
    cam_intrinsics,
    depths_params,
    images_folder,
    depths_folder,
    test_cam_names_list,
    sar_params=None,
    use_sar_geometry=False,
    scattering_masks=None,
):
    """
    读取COLMAP相机参数，支持SAR几何模型
    
    Args:
        cam_extrinsics: COLMAP外参
        cam_intrinsics: COLMAP内参
        depths_params: 深度参数
        images_folder: 图像文件夹路径
        depths_folder: 深度图文件夹路径
        test_cam_names_list: 测试相机名称列表
        sar_params: SAR系统参数字典（可选）
        use_sar_geometry: 是否使用SAR几何模型重新计算相机位姿
        scattering_masks: 可选 {image_name: ndarray}，与 train 预处理掩码对齐
    """
    cam_infos = []
    
    # 如果启用SAR几何模型，准备SAR参数
    if use_sar_geometry and SAR_GEOMETRY_AVAILABLE:
        if sar_params is None:
            sar_params = DEFAULT_SAR_PARAMS.copy()
        # 从第一张图像获取图像尺寸并更新SAR参数
        if len(cam_extrinsics) > 0:
            first_extr = cam_extrinsics[list(cam_extrinsics.keys())[0]]
            first_intr = cam_intrinsics[first_extr.camera_id]
            sar_params['Na'] = first_intr.width
            sar_params['Nr'] = first_intr.height
            print(f"\n使用SAR几何模型，图像尺寸: {first_intr.width} x {first_intr.height}")
    
    for idx, key in enumerate(cam_extrinsics):
        sys.stdout.write('\r')
        # the exact output you're looking for:
        sys.stdout.write("Reading camera {}/{}".format(idx+1, len(cam_extrinsics)))
        sys.stdout.flush()

        extr = cam_extrinsics[key]
        intr = cam_intrinsics[extr.camera_id]
        height = intr.height
        width = intr.width

        uid = intr.id
        
        # SAR几何模型：根据文件名重新计算相机位姿
        if use_sar_geometry and SAR_GEOMETRY_AVAILABLE:
            try:
                # 从文件名解析俯视角和方位角
                if parse_mstar_filename_quiet is not None:
                    _tgt, depression_angle_original, azimuth_angle = parse_mstar_filename_quiet(extr.name)
                else:
                    depression_angle_original, azimuth_angle = parse_mstar_filename(extr.name)
                
                # ========== 新增：优先使用映射中的俯视角 ==========
                depression_angle_mapping = sar_params.get('depression_angle_mapping', None)
                depression_angle = depression_angle_original  # 默认值
                mapping_key = None
                
                if depression_angle_mapping:
                    # 尝试匹配：先尝试完整文件名，再尝试去掉扩展名
                    if extr.name in depression_angle_mapping:
                        mapping_key = extr.name
                    else:
                        # 尝试去掉扩展名匹配（映射文件可能只保存了文件名，没有扩展名）
                        name_without_ext = os.path.splitext(extr.name)[0]
                        if name_without_ext in depression_angle_mapping:
                            mapping_key = name_without_ext
                    
                    if mapping_key:
                        # 使用SfM阶段分配的循环俯视角
                        depression_angle = depression_angle_mapping[mapping_key]
                        if idx == 0:  # 只打印一次
                            print(f"\n✅ 使用俯视角映射（确保与SfM位姿一致）")
                            print(f"   示例: {extr.name}")
                            print(f"   - 文件名俯视角: {depression_angle_original}°")
                            print(f"   - 映射俯视角: {depression_angle}° (SfM使用的循环俯视角)")
                    else:
                        # 回退到文件名中的俯视角
                        if idx == 0:
                            print(f"\n⚠️  未找到映射: {extr.name} (尝试了: {extr.name}, {os.path.splitext(extr.name)[0]})")
                            print(f"   使用文件名俯视角，这可能导致与SfM位姿不一致！")
                else:
                    # 没有映射文件
                    if idx == 0:
                        print(f"\n⚠️  未使用俯视角映射，使用文件名俯视角")
                        print(f"   这可能导致与SfM位姿不一致！")
                # ========== 新增结束 ==========
                
                # 使用SAR几何模型计算相机位姿
                R_sar, T_sar, K_sar = compute_sar_camera_pose(
                    depression_angle, azimuth_angle, sar_params
                )
                
                # 使用SAR计算的位姿
                R = R_sar
                T = T_sar.flatten()  # 确保T是一维数组
                
                # 从SAR的K矩阵计算FOV
                # SAR的K矩阵: [[fx, 0, cx], [0, fy, cy], [0, 0, 1]]
                focal_length_x = K_sar[0, 0]
                focal_length_y = K_sar[1, 1]
                FovY = focal2fov(focal_length_y, height)
                FovX = focal2fov(focal_length_x, width)
                
                if idx == 0:  # 只在第一张图像时打印
                    print(f"\n使用SAR几何模型重新计算相机位姿")
                    print(f"  俯视角: {depression_angle}°, 方位角: {azimuth_angle}°")
                    print(f"  焦距: fx={focal_length_x:.2f}, fy={focal_length_y:.2f}")
                
            except Exception as e:
                print(f"\n警告: 无法为图像 {extr.name} 计算SAR位姿，使用COLMAP位姿: {e}")
                # 回退到COLMAP位姿
                R = np.transpose(qvec2rotmat(extr.qvec))
                T = np.array(extr.tvec)
                
                if intr.model=="SIMPLE_PINHOLE":
                    focal_length_x = intr.params[0]
                    FovY = focal2fov(focal_length_x, height)
                    FovX = focal2fov(focal_length_x, width)
                elif intr.model=="PINHOLE":
                    focal_length_x = intr.params[0]
                    focal_length_y = intr.params[1]
                    FovY = focal2fov(focal_length_y, height)
                    FovX = focal2fov(focal_length_x, width)
                else:
                    assert False, "Colmap camera model not handled: only undistorted datasets (PINHOLE or SIMPLE_PINHOLE cameras) supported!"
        else:
            # 标准COLMAP位姿读取
            R = np.transpose(qvec2rotmat(extr.qvec))
            T = np.array(extr.tvec)

            if intr.model=="SIMPLE_PINHOLE":
                focal_length_x = intr.params[0]
                FovY = focal2fov(focal_length_x, height)
                FovX = focal2fov(focal_length_x, width)
            elif intr.model=="PINHOLE":
                focal_length_x = intr.params[0]
                focal_length_y = intr.params[1]
                FovY = focal2fov(focal_length_y, height)
                FovX = focal2fov(focal_length_x, width)
            else:
                assert False, "Colmap camera model not handled: only undistorted datasets (PINHOLE or SIMPLE_PINHOLE cameras) supported!"

        n_remove = len(extr.name.split('.')[-1]) + 1
        depth_params = None
        if depths_params is not None:
            try:
                depth_params = depths_params[extr.name[:-n_remove]]
            except:
                print("\n", key, "not found in depths_params")

        image_path = _resolve_image_path(images_folder, extr.name)
        image_name = extr.name
        depth_path = os.path.join(depths_folder, f"{extr.name[:-n_remove]}.png") if depths_folder != "" else ""
        sem_mask = _lookup_scattering_mask(scattering_masks, image_name)
        if sem_mask is not None:
            try:
                from sar.semantic_mask_config import normalize_scattering_mask_array
                sem_mask = normalize_scattering_mask_array(sem_mask)
            except ImportError:
                sem_mask = np.asarray(sem_mask)

        # SAR 渲染：附加 R_world_to_radar（--no_sar_fast_mode / SDGR）；与是否重算 COLMAP 外参无关
        R_world_to_radar = None
        use_sar_rendering = False
        cam_sar_params = None

        if SAR_GEOMETRY_AVAILABLE and sar_params is not None:
            try:
                R_world_to_radar, use_sar_rendering, cam_sar_params = _attach_sar_radar_metadata(
                    extr.name, width, height, sar_params,
                )
            except Exception:
                pass

        cam_info = CameraInfo(
            uid=uid,
            R=R,
            T=T,
            FovY=FovY,
            FovX=FovX,
            depth_params=depth_params,
            image_path=image_path,
            image_name=image_name,
            depth_path=depth_path,
            width=width,
            height=height,
            is_test=image_name in test_cam_names_list,
            R_world_to_radar=R_world_to_radar,
            use_sar_rendering=use_sar_rendering,
            sar_params=cam_sar_params,
            scattering_mask=sem_mask,
        )
        cam_infos.append(cam_info)

    sys.stdout.write('\n')
    if SAR_GEOMETRY_AVAILABLE and parse_mstar_filename_quiet is not None and len(cam_infos) > 0:
        parsed = sum(
            1 for ci in cam_infos if parse_mstar_filename_quiet(ci.image_name)[0] is not None
        )
        if parsed > 0:
            ex = cam_infos[0]
            _t0, d0, a0 = parse_mstar_filename_quiet(ex.image_name)
            print(
                f"[SAR] 文件名俯仰/方位: 已解析 {parsed}/{len(cam_infos)} 张"
                f"（示例 {ex.image_name}: {d0}° / {a0}°）"
            )
    return cam_infos

def fetchPly(path):
    plydata = PlyData.read(path)
    vertices = plydata['vertex']
    positions = np.vstack([vertices['x'], vertices['y'], vertices['z']]).T
    colors = np.vstack([vertices['red'], vertices['green'], vertices['blue']]).T / 255.0
    normals = np.vstack([vertices['nx'], vertices['ny'], vertices['nz']]).T
    return BasicPointCloud(points=positions, colors=colors, normals=normals)

def storePly(path, xyz, rgb):
    # Define the dtype for the structured array
    dtype = [('x', 'f4'), ('y', 'f4'), ('z', 'f4'),
            ('nx', 'f4'), ('ny', 'f4'), ('nz', 'f4'),
            ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')]
    
    normals = np.zeros_like(xyz)

    elements = np.empty(xyz.shape[0], dtype=dtype)
    attributes = np.concatenate((xyz, normals, rgb), axis=1)
    elements[:] = list(map(tuple, attributes))

    # Create the PlyData object and write to file
    vertex_element = PlyElement.describe(elements, 'vertex')
    ply_data = PlyData([vertex_element])
    ply_data.write(path)

def readColmapSceneInfo(
    path,
    images,
    depths,
    eval,
    train_test_exp,
    llffhold=8,
    sar_params=None,
    use_sar_geometry=False,
    scattering_masks=None,
):
    """
    读取COLMAP场景信息，支持SAR几何模型
    
    Args:
        path: 场景路径
        images: 图像文件夹名称
        depths: 深度图文件夹名称
        eval: 是否评估模式
        train_test_exp: 训练测试实验标志
        llffhold: LLFF保持参数
        sar_params: SAR系统参数字典（可选）
        use_sar_geometry: 是否使用SAR几何模型重新计算相机位姿
        scattering_masks: 可选，{image_name: ndarray} 训练前预处理掩码
    """
    try:
        cameras_extrinsic_file = os.path.join(path, "sparse/0", "images.bin")
        cameras_intrinsic_file = os.path.join(path, "sparse/0", "cameras.bin")
        cam_extrinsics = read_extrinsics_binary(cameras_extrinsic_file)
        cam_intrinsics = read_intrinsics_binary(cameras_intrinsic_file)
    except:
        cameras_extrinsic_file = os.path.join(path, "sparse/0", "images.txt")
        cameras_intrinsic_file = os.path.join(path, "sparse/0", "cameras.txt")
        cam_extrinsics = read_extrinsics_text(cameras_extrinsic_file)
        cam_intrinsics = read_intrinsics_text(cameras_intrinsic_file)

    depth_params_file = os.path.join(path, "sparse/0", "depth_params.json")
    ## if depth_params_file isnt there AND depths file is here -> throw error
    depths_params = None
    if depths != "":
        try:
            with open(depth_params_file, "r") as f:
                depths_params = json.load(f)
            all_scales = np.array([depths_params[key]["scale"] for key in depths_params])
            if (all_scales > 0).sum():
                med_scale = np.median(all_scales[all_scales > 0])
            else:
                med_scale = 0
            for key in depths_params:
                depths_params[key]["med_scale"] = med_scale

        except FileNotFoundError:
            print(f"Error: depth_params.json file not found at path '{depth_params_file}'.")
            sys.exit(1)
        except Exception as e:
            print(f"An unexpected error occurred when trying to open depth_params.json file: {e}")
            sys.exit(1)

    if eval:
        if "360" in path:
            llffhold = 8
        if llffhold:
            print("------------LLFF HOLD-------------")
            cam_names = [cam_extrinsics[cam_id].name for cam_id in cam_extrinsics]
            cam_names = sorted(cam_names)
            test_cam_names_list = [name for idx, name in enumerate(cam_names) if idx % llffhold == 0]
        else:
            with open(os.path.join(path, "sparse/0", "test.txt"), 'r') as file:
                test_cam_names_list = [line.strip() for line in file]
    else:
        test_cam_names_list = []

    reading_dir = "images" if images == None else images
    cam_infos_unsorted = readColmapCameras(
        cam_extrinsics=cam_extrinsics, cam_intrinsics=cam_intrinsics, depths_params=depths_params,
        images_folder=os.path.join(path, reading_dir), 
        depths_folder=os.path.join(path, depths) if depths != "" else "", 
        test_cam_names_list=test_cam_names_list,
        sar_params=sar_params,
        use_sar_geometry=use_sar_geometry,
        scattering_masks=scattering_masks,
    )
    cam_infos = sorted(cam_infos_unsorted.copy(), key = lambda x : x.image_name)

    train_cam_infos = [c for c in cam_infos if train_test_exp or not c.is_test]
    test_cam_infos = [c for c in cam_infos if c.is_test]

    nerf_normalization = getNerfppNorm(train_cam_infos)

    ply_path = os.path.join(path, "sparse/0/points3D.ply")
    bin_path = os.path.join(path, "sparse/0/points3D.bin")
    txt_path = os.path.join(path, "sparse/0/points3D.txt")
    if not os.path.exists(ply_path):
        print("Converting point3d.bin to .ply, will happen only the first time you open the scene.")
        try:
            xyz, rgb, _ = read_points3D_binary(bin_path)
        except:
            xyz, rgb, _ = read_points3D_text(txt_path)
        storePly(ply_path, xyz, rgb)
    try:
        pcd = fetchPly(ply_path)
    except:
        pcd = None

    scene_info = SceneInfo(point_cloud=pcd,
                           train_cameras=train_cam_infos,
                           test_cameras=test_cam_infos,
                           nerf_normalization=nerf_normalization,
                           ply_path=ply_path,
                           is_nerf_synthetic=False)
    return scene_info

def readCamerasFromTransforms(path, transformsfile, depths_folder, white_background, is_test, extension=".png"):
    cam_infos = []

    with open(os.path.join(path, transformsfile)) as json_file:
        contents = json.load(json_file)
        fovx = contents["camera_angle_x"]

        frames = contents["frames"]
        for idx, frame in enumerate(frames):
            cam_name = os.path.join(path, frame["file_path"] + extension)

            # NeRF 'transform_matrix' is a camera-to-world transform
            c2w = np.array(frame["transform_matrix"])
            # change from OpenGL/Blender camera axes (Y up, Z back) to COLMAP (Y down, Z forward)
            c2w[:3, 1:3] *= -1

            # get the world-to-camera transform and set R, T
            w2c = np.linalg.inv(c2w)
            R = np.transpose(w2c[:3,:3])  # R is stored transposed due to 'glm' in CUDA code
            T = w2c[:3, 3]

            image_path = os.path.join(path, cam_name)
            image_name = Path(cam_name).stem
            image = Image.open(image_path)

            im_data = np.array(image.convert("RGBA"))

            bg = np.array([1,1,1]) if white_background else np.array([0, 0, 0])

            norm_data = im_data / 255.0
            arr = norm_data[:,:,:3] * norm_data[:, :, 3:4] + bg * (1 - norm_data[:, :, 3:4])
            image = Image.fromarray(np.array(arr*255.0, dtype=np.byte), "RGB")

            fovy = focal2fov(fov2focal(fovx, image.size[0]), image.size[1])
            FovY = fovy 
            FovX = fovx

            depth_path = os.path.join(depths_folder, f"{image_name}.png") if depths_folder != "" else ""

            cam_infos.append(CameraInfo(uid=idx, R=R, T=T, FovY=FovY, FovX=FovX,
                            image_path=image_path, image_name=image_name,
                            width=image.size[0], height=image.size[1], depth_path=depth_path, depth_params=None, is_test=is_test))
            
    return cam_infos

def readNerfSyntheticInfo(path, white_background, depths, eval, extension=".png"):

    depths_folder=os.path.join(path, depths) if depths != "" else ""
    print("Reading Training Transforms")
    train_cam_infos = readCamerasFromTransforms(path, "transforms_train.json", depths_folder, white_background, False, extension)
    print("Reading Test Transforms")
    test_cam_infos = readCamerasFromTransforms(path, "transforms_test.json", depths_folder, white_background, True, extension)
    
    if not eval:
        train_cam_infos.extend(test_cam_infos)
        test_cam_infos = []

    nerf_normalization = getNerfppNorm(train_cam_infos)

    ply_path = os.path.join(path, "points3d.ply")
    if not os.path.exists(ply_path):
        # Since this data set has no colmap data, we start with random points
        num_pts = 100_000
        print(f"Generating random point cloud ({num_pts})...")
        
        # We create random points inside the bounds of the synthetic Blender scenes
        xyz = np.random.random((num_pts, 3)) * 2.6 - 1.3
        shs = np.random.random((num_pts, 3)) / 255.0
        pcd = BasicPointCloud(points=xyz, colors=SH2RGB(shs), normals=np.zeros((num_pts, 3)))

        storePly(ply_path, xyz, SH2RGB(shs) * 255)
    try:
        pcd = fetchPly(ply_path)
    except:
        pcd = None

    scene_info = SceneInfo(point_cloud=pcd,
                           train_cameras=train_cam_infos,
                           test_cameras=test_cam_infos,
                           nerf_normalization=nerf_normalization,
                           ply_path=ply_path,
                           is_nerf_synthetic=True)
    return scene_info


def _build_sar_params_from_mstar_nosfm_args(args, image_width: int, image_height: int) -> dict:
    """与训练 args 中 SAR 参数一致，供 compute_sar_camera_pose 使用（与论文中已知俯视角/方位角建轨一致）。"""
    if not SAR_GEOMETRY_AVAILABLE:
        return DEFAULT_SAR_PARAMS.copy()
    sp = DEFAULT_SAR_PARAMS.copy()
    sp['Na'] = int(image_width)
    sp['Nr'] = int(image_height)
    if hasattr(args, 'sar_camera_height') and args.sar_camera_height is not None:
        sp['camera_height'] = float(args.sar_camera_height)
    if hasattr(args, 'sar_platform_velocity') and args.sar_platform_velocity is not None:
        sp['Va'] = float(args.sar_platform_velocity)
    if hasattr(args, 'sar_prf') and args.sar_prf is not None:
        sp['prf'] = float(args.sar_prf)
    if hasattr(args, 'sar_bandwidth') and args.sar_bandwidth is not None:
        B = float(args.sar_bandwidth)
        sp['B'] = B
        sp['fs'] = 1.1 * B
        tao = sp.get('tao', 3.5e-7)
        sp['kr'] = B / tao
    if hasattr(args, 'sar_scene_scale') and args.sar_scene_scale is not None:
        sp['scene_scale'] = float(args.sar_scene_scale)
    mode = getattr(args, 'sar_camera_distribution_mode', 'sphere')
    sp['camera_distribution_mode'] = mode
    if getattr(args, 'sar_radius_scale', None) is not None:
        sp['radius_scale'] = float(args.sar_radius_scale)
    # cfg_args 中若显式为 None（旧实验/合并参数），getattr 仍得 None，str(None).lower() → 'none' 会误伤 geometry
    _dep_conv = getattr(args, "sar_mstar_filename_depression_convention", "horizon")
    if _dep_conv is None or str(_dep_conv).strip().lower() in ("", "none"):
        _dep_conv = "horizon"
    else:
        _dep_conv = str(_dep_conv).strip().lower()
    if _dep_conv not in ("horizon", "zenith"):
        print(
            f"[MSTAR 无 SfM] 警告: sar_mstar_filename_depression_convention={_dep_conv!r} 非 horizon/zenith，回退为 horizon"
        )
        _dep_conv = "horizon"
    sp["mstar_filename_depression_convention"] = _dep_conv
    return sp


def readMstarNoSfMSceneInfo(path, images, eval, train_test_exp, llffhold, args) -> SceneInfo:
    """
    无 COLMAP、无 SfM：仅扫描 <path>/<images> 下图像，按 MSTAR 式文件名「目标-俯视角-方位角」
    （如 T72-15-001：第二段常为相对水平俯角 φ°，与天底夹角为 90°-φ°，默认见 sar_geometry 约定）
    用 compute_sar_camera_pose 生成位姿。
    初值点云写入 path/mstar_nosfm_init/points3D.ply（随机、seed=0，可复现）。
    """
    if not SAR_GEOMETRY_AVAILABLE or parse_mstar_filename_quiet is None:
        raise RuntimeError("readMstarNoSfMSceneInfo 需要 sar_geometry 与 parse_mstar_filename_quiet")
    reading_dir = "images" if images is None else images
    images_dir = os.path.join(path, reading_dir)
    if not os.path.isdir(images_dir):
        raise FileNotFoundError(f"mstar_nosfm: 图像目录不存在: {images_dir}")
    patterns = ("*.png", "*.jpg", "*.jpeg", "*.bmp", "*.tif", "*.tiff")
    image_files = []
    for pat in patterns:
        image_files.extend(glob.glob(os.path.join(images_dir, pat)))
    image_files = sorted({os.path.normpath(f) for f in image_files}, key=lambda p: os.path.basename(p).lower())
    if len(image_files) == 0:
        raise FileNotFoundError(f"mstar_nosfm: 在 {images_dir} 下未找到任何图像")
    print(f"\n[MSTAR 无 SfM] 共 {len(image_files)} 张图；位姿 = 文件名解析 + compute_sar_camera_pose (无 SfM/COLMAP 外参)")
    basenames = [os.path.basename(f) for f in image_files]
    if eval and llffhold:
        print("------------LLFF HOLD (mstar_nosfm)-------------")
        sorted_names = sorted(basenames, key=str.lower)
        test_cam_names = {sorted_names[i] for i in range(0, len(sorted_names), llffhold)}
    else:
        test_cam_names = set()
    cam_infos = []
    for idx, fpath in enumerate(image_files):
        name = os.path.basename(fpath)
        with Image.open(fpath) as im:
            w, h = im.size
        _tgt, dep, azi = parse_mstar_filename_quiet(name)
        sp = _build_sar_params_from_mstar_nosfm_args(args, w, h)
        R_sar, T_sar, K_sar = compute_sar_camera_pose(int(dep), int(azi), sp)
        R = R_sar
        T = np.asarray(T_sar, dtype=np.float64).reshape(-1)
        focal_x = K_sar[0, 0]
        focal_y = K_sar[1, 1]
        FovY = focal2fov(focal_y, h)
        FovX = focal2fov(focal_x, w)
        cam_sar = sp.copy()
        cam_sar['depression_angle'] = float(dep)
        cam_sar['Na'] = w
        cam_sar['Nr'] = h
        is_test = name in test_cam_names
        sem_mask = _lookup_scattering_mask(getattr(args, "scattering_masks", None), name)
        if sem_mask is not None:
            sem_mask = np.asarray(sem_mask)
        cam_info = CameraInfo(
            uid=idx,
            R=R,
            T=T,
            FovY=FovY,
            FovX=FovX,
            depth_params=None,
            image_path=fpath,
            image_name=name,
            depth_path="",
            width=w,
            height=h,
            is_test=is_test,
            R_world_to_radar=R,
            use_sar_rendering=True,
            sar_params=cam_sar,
            scattering_mask=sem_mask,
        )
        cam_infos.append(cam_info)
    train_cam_infos = [c for c in cam_infos if train_test_exp or not c.is_test]
    test_cam_infos = [c for c in cam_infos if c.is_test]
    nerf_normalization = getNerfppNorm(train_cam_infos)
    init_dir = os.path.join(path, "mstar_nosfm_init")
    os.makedirs(init_dir, exist_ok=True)
    ply_path = os.path.join(init_dir, "points3D.ply")
    n_init = int(getattr(args, "mstar_nosfm_init_points", 100_000))
    r = max(float(nerf_normalization["radius"]), 1.0)
    scale = 0.05 * r
    if not os.path.exists(ply_path):
        np.random.seed(0)
        xyz = (np.random.rand(n_init, 3).astype(np.float32) - 0.5) * (2.0 * scale)
        shs = np.random.random((n_init, 3)) / 255.0
        storePly(ply_path, xyz, SH2RGB(shs) * 255.0)
        print(f"[MSTAR 无 SfM] 已写入随机初值点云: {ply_path} ({n_init} 点, 立方体半边约 {scale:.4f} 场景单位)")
    try:
        pcd = fetchPly(ply_path)
    except Exception as e:
        print(f"警告: 无法读取 {ply_path}，点云为 None: {e}")
        pcd = None
    return SceneInfo(
        point_cloud=pcd,
        train_cameras=train_cam_infos,
        test_cameras=test_cam_infos,
        nerf_normalization=nerf_normalization,
        ply_path=ply_path,
        is_nerf_synthetic=True,
    )


sceneLoadTypeCallbacks = {
    "Colmap": readColmapSceneInfo,
    "Blender" : readNerfSyntheticInfo,
    "MstarNoSfM": readMstarNoSfMSceneInfo,
}
