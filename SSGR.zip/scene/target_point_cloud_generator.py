#
# 目标点云生成模块
# 基于SAR图像的长宽比和阴影计算的长宽高比，生成目标点云
# 作为高斯泼溅的子模块，用于替代point_cloud_target_only.ply输出
#

import numpy as np
import os
from plyfile import PlyData, PlyElement


def generate_target_point_cloud_from_dimensions(
    target_length=None,
    target_width=None,
    target_height=None,
    target_base_height=0.0,
    target_density=1.5,
    scale_factor=1.0,
    center_x=0.0,
    center_y=0.0,
    center_z=0.0,
    shape_type='box',  # 'box' 或 'ellipsoid'
    add_noise=True,
    noise_scale=0.02
):
    """
    根据目标尺寸生成目标点云
    
    参数:
        target_length: 目标长度（米），如果为None则使用默认值
        target_width: 目标宽度（米），如果为None则使用默认值
        target_height: 目标高度（米），如果为None则使用默认值
        target_base_height: 目标基础高度（米），默认0.0
        target_density: 目标点云密度，默认1.5
        scale_factor: 缩放因子，默认1.0
        center_x, center_y, center_z: 目标中心位置，默认(0, 0, 0)
        shape_type: 形状类型，'box'（长方体）或'ellipsoid'（椭球体），默认'box'
        add_noise: 是否添加噪声，默认True
        noise_scale: 噪声尺度，默认0.02
    
    返回:
        points_3d: (3, N) numpy数组，点云坐标
        colors: (N, 3) numpy数组，点云颜色（RGB，0-255）
    """
    # 使用默认值（如果未提供）
    if target_length is None:
        target_length = 8.0 * scale_factor
    else:
        target_length = target_length * scale_factor
    
    if target_width is None:
        target_width = 3.0 * scale_factor
    else:
        target_width = target_width * scale_factor
    
    if target_height is None:
        target_height = 2.5 * scale_factor
    else:
        target_height = target_height * scale_factor
    
    target_base_height = target_base_height * scale_factor
    
    # 计算目标点数量
    target_samples = int(target_length * target_width * target_density * 50)
    
    print(f"🎯 生成目标点云:")
    print(f"   尺寸: {target_length:.2f}m × {target_width:.2f}m × {target_height:.2f}m")
    print(f"   基础高度: {target_base_height:.2f}m")
    print(f"   中心位置: ({center_x:.2f}, {center_y:.2f}, {center_z:.2f})")
    print(f"   形状类型: {shape_type}")
    print(f"   点数: {target_samples}")
    
    all_points = []
    all_colors = []
    
    for i in range(target_samples):
        if shape_type == 'box':
            # 长方体形状
            x = np.random.uniform(-target_length / 2, target_length / 2)
            z = np.random.uniform(-target_width / 2, target_width / 2)
            y = np.random.uniform(target_base_height, target_base_height + target_height)
        elif shape_type == 'ellipsoid':
            # 椭球体形状（更符合SAR目标特征）
            # 使用球坐标系生成点，然后变换到椭球体
            u = np.random.uniform(0, 1)
            v = np.random.uniform(0, 1)
            w = np.random.uniform(0, 1)
            
            # 椭球体参数
            a = target_length / 2.0
            b = target_width / 2.0
            c = target_height / 2.0
            
            # 使用均匀分布的椭球体采样
            theta = 2 * np.pi * u
            phi = np.arccos(2 * v - 1)
            r = w ** (1/3)  # 均匀分布
            
            x = a * r * np.sin(phi) * np.cos(theta)
            z = b * r * np.sin(phi) * np.sin(theta)
            y = target_base_height + target_height / 2.0 + c * r * np.cos(phi)
        else:
            raise ValueError(f"未知的形状类型: {shape_type}")
        
        # 根据位置调整高度 - 模拟目标形状（中心高，边缘低）
        if shape_type == 'box':
            norm_x = x / (target_length / 2)
            norm_z = z / (target_width / 2)
            distance = np.sqrt(norm_x ** 2 + norm_z ** 2)
            
            base_y = target_base_height
            
            if distance < 0.7:  # 中心区域
                height_factor = 1.0 - distance
                y = base_y + target_height * height_factor
            else:  # 边缘区域
                height_factor = 0.5 * (1.0 - min(distance, 1.0))
                y = base_y + target_height * 0.3 * height_factor
        
        # 添加随机噪声（如果启用）
        if add_noise:
            x += np.random.normal(0, noise_scale * scale_factor)
            y += np.random.normal(0, noise_scale * scale_factor)
            z += np.random.normal(0, noise_scale * scale_factor)
        
        # 平移到目标中心位置
        x += center_x
        y += center_y
        z += center_z
        
        # 目标颜色（根据高度变化）
        if y > target_base_height + target_height * 0.6:
            base_r, base_g, base_b = 200, 100, 80  # 上部 - 偏红
        else:
            base_r, base_g, base_b = 160, 140, 100  # 下部 - 偏黄
        
        # 颜色变化
        color_variation = np.random.randint(-15, 15, 3)
        color_r = max(0, min(255, base_r + color_variation[0]))
        color_g = max(0, min(255, base_g + color_variation[1]))
        color_b = max(0, min(255, base_b + color_variation[2]))
        
        all_points.append([x, y, z])
        all_colors.append([color_r, color_g, color_b])
    
    # 转换为numpy数组
    if all_points:
        points_3d = np.array(all_points).T  # (3, N)
        colors = np.array(all_colors)  # (N, 3)
        
        print(f"   ✅ 成功生成 {len(all_points)} 个目标点")
        print(f"   点云范围: X[{np.min(points_3d[0]):.2f}, {np.max(points_3d[0]):.2f}], "
              f"Y[{np.min(points_3d[1]):.2f}, {np.max(points_3d[1]):.2f}], "
              f"Z[{np.min(points_3d[2]):.2f}, {np.max(points_3d[2]):.2f}]")
        
        return points_3d, colors
    else:
        print("   ⚠️ 警告: 未能生成任何目标点")
        return np.zeros((3, 0)), np.zeros((0, 3))


def save_target_point_cloud_ply(points_3d, colors, filename):
    """
    将目标点云保存为PLY格式
    
    参数:
        points_3d: (3, N) numpy数组，点云坐标
        colors: (N, 3) numpy数组，点云颜色（RGB，0-255）
        filename: 输出文件名
    """
    if points_3d.size == 0:
        print(f"⚠️ 警告: 没有点云数据可保存到 {filename}")
        return
    
    if points_3d.shape[0] != 3:
        points_3d = points_3d.T
    
    num_points = points_3d.shape[1]
    
    if len(colors) != num_points:
        print(f"⚠️ 警告: 点云颜色数量 ({len(colors)}) 与点数量 ({num_points}) 不匹配，使用默认颜色")
        colors = np.full((num_points, 3), 255, dtype=np.uint8)
    
    # 确保颜色在0-255范围内
    colors = np.clip(colors, 0, 255).astype(np.uint8)
    
    # 创建PLY数据
    vertices = np.empty(num_points, dtype=[('x', 'f4'), ('y', 'f4'), ('z', 'f4'),
                                           ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')])
    vertices['x'] = points_3d[0, :]
    vertices['y'] = points_3d[1, :]
    vertices['z'] = points_3d[2, :]
    vertices['red'] = colors[:, 0]
    vertices['green'] = colors[:, 1]
    vertices['blue'] = colors[:, 2]
    
    # 保存PLY文件
    el = PlyElement.describe(vertices, 'vertex')
    PlyData([el]).write(filename)
    
    print(f"✅ 目标点云已保存: {filename} (包含 {num_points} 个点)")


def load_sfm_target_points(source_path, scene_center=None, brightness_threshold=200):
    """
    从SFM结果中提取目标点云
    
    参数:
        source_path: 数据源路径（包含sparse/0/points3D.txt或points3D.bin）
        scene_center: 场景中心位置，用于过滤目标点
        brightness_threshold: 亮度阈值，用于识别目标点（0-255）
    
    返回:
        points_3d: (3, N) numpy数组，点云坐标，如果没有找到则返回None
        colors: (N, 3) numpy数组，点云颜色（RGB，0-255），如果没有找到则返回None
    """
    try:
        from scene.colmap_loader import read_points3D_binary, read_points3D_text
        
        bin_path = os.path.join(source_path, "sparse/0/points3D.bin")
        txt_path = os.path.join(source_path, "sparse/0/points3D.txt")
        
        if os.path.exists(bin_path):
            xyz, rgb, _ = read_points3D_binary(bin_path)
        elif os.path.exists(txt_path):
            xyz, rgb, _ = read_points3D_text(txt_path)
        else:
            return None, None
        
        if xyz.shape[1] == 0:
            return None, None
        
        # 计算亮度（用于识别目标点）
        brightness = 0.299 * rgb[:, 0] + 0.587 * rgb[:, 1] + 0.114 * rgb[:, 2]
        
        # 过滤出高亮点（可能是目标点）
        target_mask = brightness >= brightness_threshold
        
        if np.sum(target_mask) == 0:
            # 如果没有高亮点，使用亮度分位数
            brightness_threshold = np.percentile(brightness, 90.0)
            target_mask = brightness >= brightness_threshold
        
        if np.sum(target_mask) > 0:
            target_points = xyz[:, target_mask]
            target_colors = rgb[target_mask, :]
            
            print(f"   📊 从SFM结果中提取了 {target_points.shape[1]} 个目标点（亮度>={brightness_threshold:.1f}）")
            return target_points, target_colors
        else:
            return None, None
            
    except Exception as e:
        print(f"   ⚠️ 加载SFM目标点失败: {e}")
        return None, None


def refine_target_point_cloud_with_sfm(base_points_3d, base_colors, sfm_points_3d, sfm_colors, 
                                       refinement_ratio=0.3, density_multiplier=2.0):
    """
    在SFM结果的基础上细化目标点云
    
    参数:
        base_points_3d: 基础生成的点云 (3, N)
        base_colors: 基础点云颜色 (N, 3)
        sfm_points_3d: SFM提取的点云 (3, M)
        sfm_colors: SFM点云颜色 (M, 3)
        refinement_ratio: SFM点云在最终结果中的比例，默认0.3
        density_multiplier: 在SFM点附近增加密度的倍数，默认2.0
    
    返回:
        refined_points_3d: 细化后的点云 (3, K)
        refined_colors: 细化后的颜色 (K, 3)
    """
    if sfm_points_3d is None or sfm_points_3d.shape[1] == 0:
        return base_points_3d, base_colors
    
    # 计算SFM点云的边界框
    sfm_min = np.min(sfm_points_3d, axis=1)
    sfm_max = np.max(sfm_points_3d, axis=1)
    sfm_center = (sfm_min + sfm_max) / 2.0
    sfm_size = sfm_max - sfm_min
    
    # 在SFM点附近增加密度
    num_refinement_points = int(sfm_points_3d.shape[1] * density_multiplier)
    refinement_points = []
    refinement_colors = []
    
    for i in range(num_refinement_points):
        # 随机选择一个SFM点作为中心
        sfm_idx = np.random.randint(0, sfm_points_3d.shape[1])
        center_point = sfm_points_3d[:, sfm_idx]
        center_color = sfm_colors[sfm_idx, :]
        
        # 在中心点附近生成新点（使用较小的随机偏移）
        offset_scale = np.min(sfm_size) * 0.05  # 5%的尺寸作为偏移范围
        offset = np.random.normal(0, offset_scale, 3)
        new_point = center_point + offset
        new_color = center_color + np.random.randint(-10, 10, 3)
        new_color = np.clip(new_color, 0, 255)
        
        refinement_points.append(new_point)
        refinement_colors.append(new_color)
    
    # 合并基础点云和细化点云
    refinement_points_3d = np.array(refinement_points).T  # (3, num_refinement_points)
    refinement_colors = np.array(refinement_colors)  # (num_refinement_points, 3)
    
    # 按比例合并
    num_sfm_points = int(sfm_points_3d.shape[1] * refinement_ratio)
    num_base_points = base_points_3d.shape[1] - num_sfm_points
    
    # 选择部分SFM点
    sfm_indices = np.random.choice(sfm_points_3d.shape[1], num_sfm_points, replace=False)
    selected_sfm_points = sfm_points_3d[:, sfm_indices]
    selected_sfm_colors = sfm_colors[sfm_indices, :]
    
    # 选择部分基础点
    base_indices = np.random.choice(base_points_3d.shape[1], num_base_points, replace=False)
    selected_base_points = base_points_3d[:, base_indices]
    selected_base_colors = base_colors[base_indices, :]
    
    # 合并
    refined_points_3d = np.hstack([selected_sfm_points, selected_base_points, refinement_points_3d])
    refined_colors = np.vstack([selected_sfm_colors, selected_base_colors, refinement_colors])
    
    print(f"   🔧 细化完成: SFM点 {num_sfm_points}, 基础点 {num_base_points}, 细化点 {num_refinement_points}")
    
    return refined_points_3d, refined_colors


def generate_target_point_cloud_from_dataset(dataset, scene_center=None, cameras=None, 
                                             source_path=None, use_sfm_refinement=True, **kwargs):
    """
    从dataset中获取目标尺寸信息，生成目标点云（利用方位角和俯视角信息，可选SFM细化）
    
    参数:
        dataset: 数据集对象，应该包含target_length, target_width, target_height等属性
        scene_center: 场景中心位置，如果为None则使用(0, 0, 0)
        cameras: 相机列表，用于提取方位角和俯视角信息
        source_path: 数据源路径，用于加载SFM结果
        use_sfm_refinement: 是否使用SFM结果进行细化，默认True
        **kwargs: 其他参数传递给generate_target_point_cloud_from_dimensions
    
    返回:
        points_3d: (3, N) numpy数组，点云坐标
        colors: (N, 3) numpy数组，点云颜色（RGB，0-255）
    """
    # 从dataset中获取目标尺寸信息
    target_length = getattr(dataset, 'target_length', None)
    target_width = getattr(dataset, 'target_width', None)
    target_height = getattr(dataset, 'target_height', None)
    target_base_height = getattr(dataset, 'target_base_height', 0.0)
    background_height = getattr(dataset, 'background_height', 0.0)
    
    # 如果target_base_height未设置，使用background_height
    if target_base_height == 0.0 and background_height != 0.0:
        target_base_height = background_height
    
    # 计算场景中心（如果未提供）
    if scene_center is None:
        center_x, center_y, center_z = 0.0, 0.0, 0.0
    else:
        if isinstance(scene_center, (list, tuple, np.ndarray)):
            center_x, center_y, center_z = scene_center[0], scene_center[1], scene_center[2]
        else:
            center_x, center_y, center_z = 0.0, 0.0, 0.0
    
    # 🔧 改进1：从cameras中提取方位角和俯视角信息
    azimuth_angle = None
    depression_angles = []
    
    if cameras is not None:
        azimuth_angles_list = []
        depression_angles_list = []
        
        # 处理不同类型的cameras输入
        if isinstance(cameras, dict):
            camera_list = list(cameras.values())
        elif isinstance(cameras, (list, tuple)):
            camera_list = cameras
        else:
            camera_list = [cameras]
        
        for cam in camera_list:
            # 尝试从Camera对象或CameraInfo中获取角度信息
            if hasattr(cam, 'azimuth_angle') and cam.azimuth_angle is not None:
                azimuth_angles_list.append(cam.azimuth_angle)
            if hasattr(cam, 'depression_angle') and cam.depression_angle is not None:
                depression_angles_list.append(cam.depression_angle)
        
        # 计算平均方位角（用于确定目标朝向）
        if azimuth_angles_list:
            azimuth_angles_rad = [np.radians(a) for a in azimuth_angles_list]
            cos_sum = np.sum([np.cos(a) for a in azimuth_angles_rad])
            sin_sum = np.sum([np.sin(a) for a in azimuth_angles_rad])
            avg_azimuth_rad = np.arctan2(sin_sum, cos_sum)
            azimuth_angle = np.degrees(avg_azimuth_rad)
            print(f"   📐 平均方位角: {azimuth_angle:.1f}° (基于{len(azimuth_angles_list)}个视角)")
        
        # 收集所有俯视角
        if depression_angles_list:
            depression_angles = depression_angles_list
            print(f"   📐 俯视角范围: {min(depression_angles):.1f}° - {max(depression_angles):.1f}° ({len(depression_angles)}个视角)")
    
    # 🔧 改进2：根据俯视角调整点云密度
    # 多个视角时，增加点云密度以获得更细致的重建
    target_density = kwargs.get('target_density', 1.5)
    if depression_angles and len(depression_angles) > 1:
        view_multiplier = 1.0 + 0.3 * min(len(depression_angles) / 10.0, 1.0)  # 最多增加30%的点
        target_density = target_density * view_multiplier
        print(f"   📊 根据{len(depression_angles)}个视角，点云密度调整为: {target_density:.2f}")
    
    # 从kwargs中获取其他参数
    scale_factor = kwargs.get('scale_factor', 1.0)
    shape_type = kwargs.get('shape_type', 'box')
    
    print(f"\n🎯 从dataset生成目标点云（细致版）:")
    if target_length is not None:
        print(f"   目标长度: {target_length:.2f}m")
    if target_width is not None:
        print(f"   目标宽度: {target_width:.2f}m")
    if target_height is not None:
        print(f"   目标高度: {target_height:.2f}m")
    print(f"   目标基础高度: {target_base_height:.2f}m")
    
    # 🔧 改进3：根据方位角旋转目标（如果需要）
    rotation_angle = 0.0
    if azimuth_angle is not None:
        rotation_angle = np.radians(azimuth_angle)
        print(f"   目标朝向: {azimuth_angle:.1f}°")
    
    # 生成基础目标点云
    base_points_3d, base_colors = generate_target_point_cloud_from_dimensions(
        target_length=target_length,
        target_width=target_width,
        target_height=target_height,
        target_base_height=target_base_height,
        target_density=target_density,
        scale_factor=scale_factor,
        center_x=center_x,
        center_y=center_y,
        center_z=center_z,
        shape_type=shape_type,
        **{k: v for k, v in kwargs.items() if k not in ['target_density', 'scale_factor', 'shape_type']}
    )
    
    # 🔧 改进4：根据方位角旋转目标点云
    if rotation_angle != 0.0:
        cos_a = np.cos(rotation_angle)
        sin_a = np.sin(rotation_angle)
        # 绕Y轴旋转（方位角是在XZ平面上的）
        x_rot = base_points_3d[0, :] * cos_a - base_points_3d[2, :] * sin_a
        z_rot = base_points_3d[0, :] * sin_a + base_points_3d[2, :] * cos_a
        base_points_3d[0, :] = x_rot
        base_points_3d[2, :] = z_rot
        print(f"   🔄 已旋转目标点云到方位角 {azimuth_angle:.1f}°")
    
    # 🔧 改进5：使用SFM结果进行细化（如果可用）
    if use_sfm_refinement and source_path is not None:
        sfm_points_3d, sfm_colors = load_sfm_target_points(source_path, scene_center)
        if sfm_points_3d is not None and sfm_points_3d.shape[1] > 0:
            print(f"   🔧 使用SFM结果进行细化...")
            base_points_3d, base_colors = refine_target_point_cloud_with_sfm(
                base_points_3d, base_colors, sfm_points_3d, sfm_colors
            )
    
    return base_points_3d, base_colors

