#
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use 
# under the terms of the LICENSE.md file.
#
# For inquiries contact  george.drettakis@inria.fr
#

import torch
import numpy as np
from utils.general_utils import inverse_sigmoid, get_expon_lr_func, build_rotation
from torch import nn
import os
import json
from utils.system_utils import mkdir_p
from plyfile import PlyData, PlyElement
from utils.sh_utils import RGB2SH, SH2RGB
from simple_knn._C import distCUDA2
from utils.graphics_utils import BasicPointCloud
from utils.general_utils import strip_symmetric, build_scaling_rotation

try:
    from diff_gaussian_rasterization import SparseGaussianAdam
except:
    pass

class GaussianModel:

    def setup_functions(self):
        def build_covariance_from_scaling_rotation(scaling, scaling_modifier, rotation):
            L = build_scaling_rotation(scaling_modifier * scaling, rotation)
            actual_covariance = L @ L.transpose(1, 2)
            symm = strip_symmetric(actual_covariance)
            return symm
        
        self.scaling_activation = torch.exp
        self.scaling_inverse_activation = torch.log

        self.covariance_activation = build_covariance_from_scaling_rotation

        self.opacity_activation = torch.sigmoid
        self.inverse_opacity_activation = inverse_sigmoid

        self.rotation_activation = torch.nn.functional.normalize


    def __init__(self, sh_degree, optimizer_type="default"):
        self.active_sh_degree = 0
        self.optimizer_type = optimizer_type
        self.max_sh_degree = sh_degree  
        self._xyz = torch.empty(0)
        self._features_dc = torch.empty(0)
        self._features_rest = torch.empty(0)
        self._scaling = torch.empty(0)
        self._rotation = torch.empty(0)
        self._opacity = torch.empty(0)
        self.max_radii2D = torch.empty(0)
        self.xyz_gradient_accum = torch.empty(0)
        self.denom = torch.empty(0)
        self.optimizer = None
        self.percent_dense = 0
        self.spatial_lr_scale = 0
        self.setup_functions()

    def capture(self):
        return (
            self.active_sh_degree,
            self._xyz,
            self._features_dc,
            self._features_rest,
            self._scaling,
            self._rotation,
            self._opacity,
            self.max_radii2D,
            self.xyz_gradient_accum,
            self.denom,
            self.optimizer.state_dict(),
            self.spatial_lr_scale,
        )
    
    def restore(self, model_args, training_args):
        (self.active_sh_degree, 
        self._xyz, 
        self._features_dc, 
        self._features_rest,
        self._scaling, 
        self._rotation, 
        self._opacity,
        self.max_radii2D, 
        xyz_gradient_accum, 
        denom,
        opt_dict, 
        self.spatial_lr_scale) = model_args
        self.training_setup(training_args)
        self.xyz_gradient_accum = xyz_gradient_accum
        self.denom = denom
        self.optimizer.load_state_dict(opt_dict)

    @property
    def get_scaling(self):
        return self.scaling_activation(self._scaling)
    
    @property
    def get_rotation(self):
        return self.rotation_activation(self._rotation)
    
    @property
    def get_xyz(self):
        return self._xyz
    
    @property
    def get_features(self):
        features_dc = self._features_dc
        features_rest = self._features_rest
        return torch.cat((features_dc, features_rest), dim=1)
    
    @property
    def get_features_dc(self):
        return self._features_dc
    
    @property
    def get_features_rest(self):
        return self._features_rest
    
    @property
    def get_opacity(self):
        return self.opacity_activation(self._opacity)

    def get_dc_luminosity(self) -> torch.Tensor:
        """
        SH DC 经 SH2RGB 后的标量亮度（RGB 均值），形状 (N,)，与渲染中散射强度通道一致的可微函数。
        用于 refine 下限制「新增高斯」不得亮过初始目标上沿。
        """
        if self._features_dc.numel() == 0:
            d = self._features_dc.device
            return torch.zeros((0,), device=d, dtype=torch.float32)
        rgb = torch.clamp(SH2RGB(self._features_dc.squeeze(1)), 0.0, 1.0)
        return rgb.mean(dim=1)
    
    @property
    def get_exposure(self):
        return self._exposure

    def get_exposure_from_name(self, image_name):
        if self.pretrained_exposures is None:
            return self._exposure[self.exposure_mapping[image_name]]
        else:
            return self.pretrained_exposures[image_name]
    
    def get_covariance(self, scaling_modifier = 1):
        return self.covariance_activation(self.get_scaling, scaling_modifier, self._rotation)

    def oneupSHdegree(self):
        if self.active_sh_degree < self.max_sh_degree:
            self.active_sh_degree += 1

    def create_from_pcd(self, pcd : BasicPointCloud, cam_infos : int, spatial_lr_scale : float):
        self.spatial_lr_scale = spatial_lr_scale
        fused_point_cloud = torch.tensor(np.asarray(pcd.points)).float().cuda()
        fused_color = RGB2SH(torch.tensor(np.asarray(pcd.colors)).float().cuda())
        features = torch.zeros((fused_color.shape[0], 3, (self.max_sh_degree + 1) ** 2)).float().cuda()
        features[:, :3, 0 ] = fused_color
        features[:, 3:, 1:] = 0.0

        print("Number of points at initialisation : ", fused_point_cloud.shape[0])

        dist2 = torch.clamp_min(distCUDA2(torch.from_numpy(np.asarray(pcd.points)).float().cuda()), 0.0000001)
        scales = torch.log(torch.sqrt(dist2))[...,None].repeat(1, 3)
        # 优化：限制初始尺度的范围，避免过大或过小，减少视角移动时的分层问题
        scales = torch.clamp(scales, min=-10.0, max=1.0)
        rots = torch.zeros((fused_point_cloud.shape[0], 4), device="cuda")
        rots[:, 0] = 1

        # 优化：增加初始不透明度，从0.1改为0.3，提高连续性，减少分层
        opacities = self.inverse_opacity_activation(0.3 * torch.ones((fused_point_cloud.shape[0], 1), dtype=torch.float, device="cuda"))

        self._xyz = nn.Parameter(fused_point_cloud.requires_grad_(True))
        self._features_dc = nn.Parameter(features[:,:,0:1].transpose(1, 2).contiguous().requires_grad_(True))
        self._features_rest = nn.Parameter(features[:,:,1:].transpose(1, 2).contiguous().requires_grad_(True))
        self._scaling = nn.Parameter(scales.requires_grad_(True))
        self._rotation = nn.Parameter(rots.requires_grad_(True))
        self._opacity = nn.Parameter(opacities.requires_grad_(True))
        self.max_radii2D = torch.zeros((self.get_xyz.shape[0]), device="cuda")
        self.exposure_mapping = {cam_info.image_name: idx for idx, cam_info in enumerate(cam_infos)}
        self.pretrained_exposures = None
        exposure = torch.eye(3, 4, device="cuda")[None].repeat(len(cam_infos), 1, 1)
        self._exposure = nn.Parameter(exposure.requires_grad_(True))

    def training_setup(self, training_args):
        self.percent_dense = training_args.percent_dense
        self.xyz_gradient_accum = torch.zeros((self.get_xyz.shape[0], 1), device="cuda")
        self.denom = torch.zeros((self.get_xyz.shape[0], 1), device="cuda")

        l = [
            {'params': [self._xyz], 'lr': training_args.position_lr_init * self.spatial_lr_scale, "name": "xyz"},
            {'params': [self._features_dc], 'lr': training_args.feature_lr, "name": "f_dc"},
            {'params': [self._features_rest], 'lr': training_args.feature_lr / 20.0, "name": "f_rest"},
            {'params': [self._opacity], 'lr': training_args.opacity_lr, "name": "opacity"},
            {'params': [self._scaling], 'lr': training_args.scaling_lr, "name": "scaling"},
            {'params': [self._rotation], 'lr': training_args.rotation_lr, "name": "rotation"}
        ]

        if self.optimizer_type == "default":
            self.optimizer = torch.optim.Adam(l, lr=0.0, eps=1e-15)
        elif self.optimizer_type == "sparse_adam":
            try:
                self.optimizer = SparseGaussianAdam(l, lr=0.0, eps=1e-15)
            except:
                # A special version of the rasterizer is required to enable sparse adam
                self.optimizer = torch.optim.Adam(l, lr=0.0, eps=1e-15)

        self.exposure_optimizer = torch.optim.Adam([self._exposure])

        self.xyz_scheduler_args = get_expon_lr_func(lr_init=training_args.position_lr_init*self.spatial_lr_scale,
                                                    lr_final=training_args.position_lr_final*self.spatial_lr_scale,
                                                    lr_delay_mult=training_args.position_lr_delay_mult,
                                                    max_steps=training_args.position_lr_max_steps)
        
        self.exposure_scheduler_args = get_expon_lr_func(training_args.exposure_lr_init, training_args.exposure_lr_final,
                                                        lr_delay_steps=training_args.exposure_lr_delay_steps,
                                                        lr_delay_mult=training_args.exposure_lr_delay_mult,
                                                        max_steps=training_args.iterations)

    def update_learning_rate(self, iteration):
        ''' Learning rate scheduling per step '''
        if self.pretrained_exposures is None:
            for param_group in self.exposure_optimizer.param_groups:
                param_group['lr'] = self.exposure_scheduler_args(iteration)

        for param_group in self.optimizer.param_groups:
            if param_group["name"] == "xyz":
                lr = self.xyz_scheduler_args(iteration)
                param_group['lr'] = lr
                return lr

    def construct_list_of_attributes(self, include_vertex_rgb=False):
        l = ['x', 'y', 'z', 'nx', 'ny', 'nz']
        if include_vertex_rgb:
            l.extend(['red', 'green', 'blue'])
        # All channels except the 3 DC
        for i in range(self._features_dc.shape[1]*self._features_dc.shape[2]):
            l.append('f_dc_{}'.format(i))
        for i in range(self._features_rest.shape[1]*self._features_rest.shape[2]):
            l.append('f_rest_{}'.format(i))
        l.append('opacity')
        for i in range(self._scaling.shape[1]):
            l.append('scale_{}'.format(i))
        for i in range(self._rotation.shape[1]):
            l.append('rot_{}'.format(i))
        return l

    def save_ply(self, path, include_vertex_rgb=False):
        mkdir_p(os.path.dirname(path))

        xyz = self._xyz.detach().cpu().numpy()
        normals = np.zeros_like(xyz)
        f_dc = self._features_dc.detach().transpose(1, 2).flatten(start_dim=1).contiguous().cpu().numpy()
        f_rest = self._features_rest.detach().transpose(1, 2).flatten(start_dim=1).contiguous().cpu().numpy()
        opacities = self._opacity.detach().cpu().numpy()
        scale = self._scaling.detach().cpu().numpy()
        rotation = self._rotation.detach().cpu().numpy()

        attr_names = self.construct_list_of_attributes(include_vertex_rgb=include_vertex_rgb)
        dtype_full = [(a, 'u1') if a in ('red', 'green', 'blue') else (a, 'f4') for a in attr_names]
        elements = np.empty(xyz.shape[0], dtype=dtype_full)
        elements['x'] = xyz[:, 0].astype(np.float32)
        elements['y'] = xyz[:, 1].astype(np.float32)
        elements['z'] = xyz[:, 2].astype(np.float32)
        elements['nx'] = normals[:, 0].astype(np.float32)
        elements['ny'] = normals[:, 1].astype(np.float32)
        elements['nz'] = normals[:, 2].astype(np.float32)
        if include_vertex_rgb:
            rgb = torch.clamp(SH2RGB(self._features_dc.squeeze(1)), 0.0, 1.0)
            rgb_u8 = (rgb * 255.0).round().clamp(0, 255).to(torch.uint8).cpu().numpy()
            elements['red'] = rgb_u8[:, 0]
            elements['green'] = rgb_u8[:, 1]
            elements['blue'] = rgb_u8[:, 2]
        for i in range(f_dc.shape[1]):
            elements[f'f_dc_{i}'] = f_dc[:, i].astype(np.float32)
        for i in range(f_rest.shape[1]):
            elements[f'f_rest_{i}'] = f_rest[:, i].astype(np.float32)
        elements['opacity'] = opacities[:, 0].astype(np.float32)
        for i in range(scale.shape[1]):
            elements[f'scale_{i}'] = scale[:, i].astype(np.float32)
        for i in range(rotation.shape[1]):
            elements[f'rot_{i}'] = rotation[:, i].astype(np.float32)
        el = PlyElement.describe(elements, 'vertex')
        PlyData([el]).write(path)
    
    def save_ply_filtered(self, path, mask, include_vertex_rgb=False):
        """
        保存过滤后的点云（只包含mask为True的点）
        
        Args:
            path: 保存路径
            mask: 布尔数组，True表示保留该点
            include_vertex_rgb: 是否写入 red/green/blue（由 SH DC 得到的近似漫反射色，便于查看器着色）
        """
        mkdir_p(os.path.dirname(path))

        xyz = self._xyz.detach().cpu().numpy()[mask]
        normals = np.zeros_like(xyz)
        f_dc = self._features_dc.detach().transpose(1, 2).flatten(start_dim=1).contiguous().cpu().numpy()[mask]
        f_rest = self._features_rest.detach().transpose(1, 2).flatten(start_dim=1).contiguous().cpu().numpy()[mask]
        opacities = self._opacity.detach().cpu().numpy()[mask]
        scale = self._scaling.detach().cpu().numpy()[mask]
        rotation = self._rotation.detach().cpu().numpy()[mask]

        attr_names = self.construct_list_of_attributes(include_vertex_rgb=include_vertex_rgb)
        dtype_full = [(a, 'u1') if a in ('red', 'green', 'blue') else (a, 'f4') for a in attr_names]
        elements = np.empty(xyz.shape[0], dtype=dtype_full)
        elements['x'] = xyz[:, 0].astype(np.float32)
        elements['y'] = xyz[:, 1].astype(np.float32)
        elements['z'] = xyz[:, 2].astype(np.float32)
        elements['nx'] = normals[:, 0].astype(np.float32)
        elements['ny'] = normals[:, 1].astype(np.float32)
        elements['nz'] = normals[:, 2].astype(np.float32)
        if include_vertex_rgb:
            rgb = torch.clamp(SH2RGB(self._features_dc.squeeze(1)[mask]), 0.0, 1.0)
            rgb_u8 = (rgb * 255.0).round().clamp(0, 255).to(torch.uint8).cpu().numpy()
            elements['red'] = rgb_u8[:, 0]
            elements['green'] = rgb_u8[:, 1]
            elements['blue'] = rgb_u8[:, 2]
        for i in range(f_dc.shape[1]):
            elements[f'f_dc_{i}'] = f_dc[:, i].astype(np.float32)
        for i in range(f_rest.shape[1]):
            elements[f'f_rest_{i}'] = f_rest[:, i].astype(np.float32)
        elements['opacity'] = opacities[:, 0].astype(np.float32)
        for i in range(scale.shape[1]):
            elements[f'scale_{i}'] = scale[:, i].astype(np.float32)
        for i in range(rotation.shape[1]):
            elements[f'rot_{i}'] = rotation[:, i].astype(np.float32)
        el = PlyElement.describe(elements, 'vertex')
        PlyData([el]).write(path)

    def reset_opacity(self):
        # 优化：使用更高的最小不透明度阈值（从0.01改为0.02），减少分层
        opacities_new = self.inverse_opacity_activation(torch.min(self.get_opacity, torch.ones_like(self.get_opacity)*0.02))
        optimizable_tensors = self.replace_tensor_to_optimizer(opacities_new, "opacity")
        self._opacity = optimizable_tensors["opacity"]
    
    def clamp_scaling(self, min_scale=-10.0, max_scale=1.0):
        """
        限制高斯点的尺度范围，避免过大或过小
        有助于减少视角移动时的分层问题
        """
        with torch.no_grad():
            self._scaling.data = torch.clamp(self._scaling.data, min=min_scale, max=max_scale)

    def _zero_optimizer_state_at_mask(self, param: torch.nn.Parameter, row_mask: torch.Tensor) -> None:
        """row_mask: (N,) bool，与 param 第 0 维对齐。"""
        state = self.optimizer.state.get(param, None)
        if state is None or not row_mask.any():
            return
        row_mask = row_mask.reshape(-1)
        for key in ("exp_avg", "exp_avg_sq"):
            buf = state.get(key)
            if buf is not None and buf.shape[0] == row_mask.shape[0]:
                buf[row_mask] = 0

    def _finite_row_mask(self, param: torch.nn.Parameter) -> torch.Tensor:
        if param.numel() == 0:
            return torch.zeros(0, dtype=torch.bool, device=param.device)
        if param.dim() == 1:
            return torch.isfinite(param)
        return torch.isfinite(param).reshape(param.shape[0], -1).all(dim=1)

    def _fallback_xyz(self, param: torch.nn.Parameter) -> torch.Tensor:
        good = self._finite_row_mask(param)
        if good.any():
            return param.data[good].median(dim=0).values
        return torch.zeros(3, device=param.device, dtype=param.dtype)

    def sanitize_nonfinite_parameters(self, reset_optimizer: bool = True) -> int:
        """将 NaN/Inf 参数按高斯整行重置，并同步清零 Adam 动量。"""
        fixed = 0
        identity_quat = None
        with torch.no_grad():
            for group in self.optimizer.param_groups:
                name = group.get("name")
                param = group["params"][0]
                if param.numel() == 0:
                    continue

                bad_rows = ~self._finite_row_mask(param)
                if not bad_rows.any():
                    continue

                n_bad = int(bad_rows.sum().item())
                if name == "rotation":
                    fixed += n_bad * param.shape[-1]
                    if identity_quat is None:
                        identity_quat = torch.tensor(
                            [1.0, 0.0, 0.0, 0.0], device=param.device, dtype=param.dtype,
                        )
                    param.data[bad_rows] = identity_quat
                elif name == "xyz":
                    fixed += n_bad * param.shape[-1]
                    fallback = self._fallback_xyz(param)
                    param.data[bad_rows] = fallback
                elif name == "scaling":
                    fixed += n_bad * param.shape[-1]
                    param.data[bad_rows] = -5.0
                elif name == "opacity":
                    fixed += n_bad * param.shape[-1]
                    fill = self.inverse_opacity_activation(
                        torch.tensor(0.1, device=param.device, dtype=param.dtype),
                    )
                    param.data[bad_rows] = fill
                elif name in ("f_dc", "f_rest"):
                    fixed += int((~torch.isfinite(param)).sum().item())
                    param.data[bad_rows] = 0.0
                else:
                    fixed += int((~torch.isfinite(param)).sum().item())
                    param.data[bad_rows] = 0.0

                if reset_optimizer:
                    self._zero_optimizer_state_at_mask(param, bad_rows)
        return fixed

    def load_ply(self, path, use_train_test_exp = False):
        plydata = PlyData.read(path)
        if use_train_test_exp:
            exposure_file = os.path.join(os.path.dirname(path), os.pardir, os.pardir, "exposure.json")
            if os.path.exists(exposure_file):
                with open(exposure_file, "r") as f:
                    exposures = json.load(f)
                self.pretrained_exposures = {image_name: torch.FloatTensor(exposures[image_name]).requires_grad_(False).cuda() for image_name in exposures}
                print(f"Pretrained exposures loaded.")
            else:
                print(f"No exposure to be loaded at {exposure_file}")
                self.pretrained_exposures = None

        xyz = np.stack((np.asarray(plydata.elements[0]["x"]),
                        np.asarray(plydata.elements[0]["y"]),
                        np.asarray(plydata.elements[0]["z"])),  axis=1)
        # newaxis 可能在部分 NumPy/PLY 组合下得到非 C 连续视图，torch.tensor 会报 strides 错误
        opacities = np.ascontiguousarray(
            np.asarray(plydata.elements[0]["opacity"])[..., np.newaxis]
        )

        features_dc = np.zeros((xyz.shape[0], 3, 1))
        features_dc[:, 0, 0] = np.asarray(plydata.elements[0]["f_dc_0"])
        features_dc[:, 1, 0] = np.asarray(plydata.elements[0]["f_dc_1"])
        features_dc[:, 2, 0] = np.asarray(plydata.elements[0]["f_dc_2"])

        extra_f_names = [p.name for p in plydata.elements[0].properties if p.name.startswith("f_rest_")]
        extra_f_names = sorted(extra_f_names, key = lambda x: int(x.split('_')[-1]))
        assert len(extra_f_names)==3*(self.max_sh_degree + 1) ** 2 - 3
        features_extra = np.zeros((xyz.shape[0], len(extra_f_names)))
        for idx, attr_name in enumerate(extra_f_names):
            features_extra[:, idx] = np.asarray(plydata.elements[0][attr_name])
        # Reshape (P,F*SH_coeffs) to (P, F, SH_coeffs except DC)
        features_extra = features_extra.reshape((features_extra.shape[0], 3, (self.max_sh_degree + 1) ** 2 - 1))

        scale_names = [p.name for p in plydata.elements[0].properties if p.name.startswith("scale_")]
        scale_names = sorted(scale_names, key = lambda x: int(x.split('_')[-1]))
        scales = np.zeros((xyz.shape[0], len(scale_names)))
        for idx, attr_name in enumerate(scale_names):
            scales[:, idx] = np.asarray(plydata.elements[0][attr_name])

        rot_names = [p.name for p in plydata.elements[0].properties if p.name.startswith("rot")]
        rot_names = sorted(rot_names, key = lambda x: int(x.split('_')[-1]))
        rots = np.zeros((xyz.shape[0], len(rot_names)))
        for idx, attr_name in enumerate(rot_names):
            rots[:, idx] = np.asarray(plydata.elements[0][attr_name])

        self._xyz = nn.Parameter(
            torch.as_tensor(np.ascontiguousarray(xyz), dtype=torch.float, device="cuda").requires_grad_(True)
        )
        self._features_dc = nn.Parameter(
            torch.as_tensor(np.ascontiguousarray(features_dc), dtype=torch.float, device="cuda")
            .transpose(1, 2)
            .contiguous()
            .requires_grad_(True)
        )
        self._features_rest = nn.Parameter(
            torch.as_tensor(np.ascontiguousarray(features_extra), dtype=torch.float, device="cuda")
            .transpose(1, 2)
            .contiguous()
            .requires_grad_(True)
        )
        self._opacity = nn.Parameter(
            torch.as_tensor(np.ascontiguousarray(opacities), dtype=torch.float, device="cuda").requires_grad_(True)
        )
        self._scaling = nn.Parameter(
            torch.as_tensor(np.ascontiguousarray(scales), dtype=torch.float, device="cuda").requires_grad_(True)
        )
        self._rotation = nn.Parameter(
            torch.as_tensor(np.ascontiguousarray(rots), dtype=torch.float, device="cuda").requires_grad_(True)
        )

        self.active_sh_degree = self.max_sh_degree

    def replace_tensor_to_optimizer(self, tensor, name):
        optimizable_tensors = {}
        for group in self.optimizer.param_groups:
            if group["name"] == name:
                stored_state = self.optimizer.state.get(group['params'][0], None)
                stored_state["exp_avg"] = torch.zeros_like(tensor)
                stored_state["exp_avg_sq"] = torch.zeros_like(tensor)

                del self.optimizer.state[group['params'][0]]
                group["params"][0] = nn.Parameter(tensor.requires_grad_(True))
                self.optimizer.state[group['params'][0]] = stored_state

                optimizable_tensors[group["name"]] = group["params"][0]
        return optimizable_tensors

    def _prune_optimizer(self, mask):
        optimizable_tensors = {}
        for group in self.optimizer.param_groups:
            stored_state = self.optimizer.state.get(group['params'][0], None)
            if stored_state is not None:
                stored_state["exp_avg"] = stored_state["exp_avg"][mask]
                stored_state["exp_avg_sq"] = stored_state["exp_avg_sq"][mask]

                del self.optimizer.state[group['params'][0]]
                group["params"][0] = nn.Parameter((group["params"][0][mask].requires_grad_(True)))
                self.optimizer.state[group['params'][0]] = stored_state

                optimizable_tensors[group["name"]] = group["params"][0]
            else:
                group["params"][0] = nn.Parameter(group["params"][0][mask].requires_grad_(True))
                optimizable_tensors[group["name"]] = group["params"][0]
        return optimizable_tensors

    def prune_points(self, mask):
        valid_points_mask = ~mask
        optimizable_tensors = self._prune_optimizer(valid_points_mask)

        self._xyz = optimizable_tensors["xyz"]
        self._features_dc = optimizable_tensors["f_dc"]
        self._features_rest = optimizable_tensors["f_rest"]
        self._opacity = optimizable_tensors["opacity"]
        self._scaling = optimizable_tensors["scaling"]
        self._rotation = optimizable_tensors["rotation"]

        self.xyz_gradient_accum = self.xyz_gradient_accum[valid_points_mask]

        self.denom = self.denom[valid_points_mask]
        self.max_radii2D = self.max_radii2D[valid_points_mask]
        self.tmp_radii = self.tmp_radii[valid_points_mask]

    def cat_tensors_to_optimizer(self, tensors_dict):
        optimizable_tensors = {}
        for group in self.optimizer.param_groups:
            assert len(group["params"]) == 1
            extension_tensor = tensors_dict[group["name"]]
            stored_state = self.optimizer.state.get(group['params'][0], None)
            if stored_state is not None:

                stored_state["exp_avg"] = torch.cat((stored_state["exp_avg"], torch.zeros_like(extension_tensor)), dim=0)
                stored_state["exp_avg_sq"] = torch.cat((stored_state["exp_avg_sq"], torch.zeros_like(extension_tensor)), dim=0)

                del self.optimizer.state[group['params'][0]]
                group["params"][0] = nn.Parameter(torch.cat((group["params"][0], extension_tensor), dim=0).requires_grad_(True))
                self.optimizer.state[group['params'][0]] = stored_state

                optimizable_tensors[group["name"]] = group["params"][0]
            else:
                group["params"][0] = nn.Parameter(torch.cat((group["params"][0], extension_tensor), dim=0).requires_grad_(True))
                optimizable_tensors[group["name"]] = group["params"][0]

        return optimizable_tensors

    def densification_postfix(self, new_xyz, new_features_dc, new_features_rest, new_opacities, new_scaling, new_rotation, new_tmp_radii):
        d = {"xyz": new_xyz,
        "f_dc": new_features_dc,
        "f_rest": new_features_rest,
        "opacity": new_opacities,
        "scaling" : new_scaling,
        "rotation" : new_rotation}

        optimizable_tensors = self.cat_tensors_to_optimizer(d)
        self._xyz = optimizable_tensors["xyz"]
        self._features_dc = optimizable_tensors["f_dc"]
        self._features_rest = optimizable_tensors["f_rest"]
        self._opacity = optimizable_tensors["opacity"]
        self._scaling = optimizable_tensors["scaling"]
        self._rotation = optimizable_tensors["rotation"]

        self.tmp_radii = torch.cat((self.tmp_radii, new_tmp_radii))
        self.xyz_gradient_accum = torch.zeros((self.get_xyz.shape[0], 1), device="cuda")
        self.denom = torch.zeros((self.get_xyz.shape[0], 1), device="cuda")
        self.max_radii2D = torch.zeros((self.get_xyz.shape[0]), device="cuda")

    def densify_and_split(self, grads, grad_threshold, scene_extent, N=2, grad_thresh_mult=None):
        n_init_points = self.get_xyz.shape[0]
        padded_grad = torch.zeros((n_init_points), device="cuda")
        padded_grad[:grads.shape[0]] = grads.squeeze()
        eff_t = padded_grad.new_full((n_init_points,), float(grad_threshold))
        if grad_thresh_mult is not None:
            m = grad_thresh_mult.to(dtype=eff_t.dtype, device=eff_t.device)
            if m.shape[0] < n_init_points:
                m = torch.cat(
                    [
                        m,
                        torch.ones(
                            n_init_points - m.shape[0], dtype=m.dtype, device=m.device,
                        ),
                    ],
                    dim=0,
                )
            elif m.shape[0] > n_init_points:
                m = m[:n_init_points]
            eff_t = eff_t * m
        selected_pts_mask = torch.where(padded_grad >= eff_t, True, False)
        selected_pts_mask = torch.logical_and(selected_pts_mask,
                                              torch.max(self.get_scaling, dim=1).values > self.percent_dense*scene_extent)

        stds = self.get_scaling[selected_pts_mask].repeat(N,1)
        means =torch.zeros((stds.size(0), 3),device="cuda")
        samples = torch.normal(mean=means, std=stds)
        rots = build_rotation(self._rotation[selected_pts_mask]).repeat(N,1,1)
        new_xyz = torch.bmm(rots, samples.unsqueeze(-1)).squeeze(-1) + self.get_xyz[selected_pts_mask].repeat(N, 1)
        new_scaling = self.scaling_inverse_activation(self.get_scaling[selected_pts_mask].repeat(N,1) / (0.8*N))
        new_rotation = self._rotation[selected_pts_mask].repeat(N,1)
        new_features_dc = self._features_dc[selected_pts_mask].repeat(N,1,1)
        new_features_rest = self._features_rest[selected_pts_mask].repeat(N,1,1)
        new_opacity = self._opacity[selected_pts_mask].repeat(N,1)
        new_tmp_radii = self.tmp_radii[selected_pts_mask].repeat(N)

        self.densification_postfix(new_xyz, new_features_dc, new_features_rest, new_opacity, new_scaling, new_rotation, new_tmp_radii)

        prune_filter = torch.cat((selected_pts_mask, torch.zeros(N * selected_pts_mask.sum(), device="cuda", dtype=bool)))
        self.prune_points(prune_filter)

    def densify_and_clone(self, grads, grad_threshold, scene_extent, grad_thresh_mult=None):
        gn = torch.norm(grads, dim=-1).squeeze(-1)
        n_pts = gn.shape[0]
        eff_t = grads.new_full((n_pts,), float(grad_threshold))
        if grad_thresh_mult is not None:
            m = grad_thresh_mult.to(dtype=eff_t.dtype, device=eff_t.device)
            if m.shape[0] < n_pts:
                m = torch.cat(
                    [m, torch.ones(n_pts - m.shape[0], dtype=m.dtype, device=m.device)], dim=0
                )
            elif m.shape[0] > n_pts:
                m = m[:n_pts]
            eff_t = eff_t * m
        selected_pts_mask = gn >= eff_t
        selected_pts_mask = torch.logical_and(selected_pts_mask,
                                              torch.max(self.get_scaling, dim=1).values <= self.percent_dense*scene_extent)
        
        new_xyz = self._xyz[selected_pts_mask]
        new_features_dc = self._features_dc[selected_pts_mask]
        new_features_rest = self._features_rest[selected_pts_mask]
        new_opacities = self._opacity[selected_pts_mask]
        new_scaling = self._scaling[selected_pts_mask]
        new_rotation = self._rotation[selected_pts_mask]

        new_tmp_radii = self.tmp_radii[selected_pts_mask]

        self.densification_postfix(new_xyz, new_features_dc, new_features_rest, new_opacities, new_scaling, new_rotation, new_tmp_radii)

    def densify_and_prune(self, max_grad, min_opacity, extent, max_screen_size, radii, grad_thresh_mult=None):
        n = self.get_xyz.shape[0]
        if n == 0:
            self.tmp_radii = None
            return

        grads = self.xyz_gradient_accum / self.denom
        grads[grads.isnan()] = 0.0

        self.tmp_radii = radii
        gm = grad_thresh_mult
        if gm is not None:
            if gm.shape[0] < n:
                gm = torch.cat(
                    [
                        gm,
                        torch.ones(
                            n - gm.shape[0], dtype=gm.dtype, device=gm.device,
                        ),
                    ],
                    dim=0,
                )
            elif gm.shape[0] > n:
                gm = gm[:n]
        self.densify_and_clone(grads, max_grad, extent, gm)
        gm_split = None
        if gm is not None:
            gm_split = gm
            nc = self.get_xyz.shape[0]
            gap = nc - gm.shape[0]
            if gap > 0:
                gm_split = torch.cat(
                    [
                        gm,
                        torch.ones(
                            gap, dtype=gm.dtype, device=gm.device,
                        ),
                    ],
                    dim=0,
                )
        self.densify_and_split(grads, max_grad, extent, grad_thresh_mult=gm_split)

        prune_mask = (self.get_opacity < min_opacity).squeeze()
        if prune_mask.dim() == 0:
            prune_mask = prune_mask.unsqueeze(0)
        if max_screen_size:
            big_points_vs = self.max_radii2D > max_screen_size
            big_points_ws = self.get_scaling.max(dim=1).values > 0.1 * extent
            prune_mask = torch.logical_or(torch.logical_or(prune_mask, big_points_vs), big_points_ws)
        # 全部被标记裁剪时会导致 N=0，diff_gaussian_rasterization 反传将出现
        # grad_sh 形状 [0,0,3] 与期望 [0,16,3] 不匹配而崩溃。
        n_after = self.get_xyz.shape[0]
        if n_after > 0 and int(prune_mask.sum().item()) >= n_after:
            k = min(16, n_after)
            opacity = self.get_opacity.squeeze()
            if opacity.dim() == 0:
                opacity = opacity.unsqueeze(0)
            _, keep_idx = torch.topk(opacity, k)
            prune_mask = torch.ones(n_after, device=prune_mask.device, dtype=torch.bool)
            prune_mask[keep_idx] = False
        self.prune_points(prune_mask)
        tmp_radii = self.tmp_radii
        self.tmp_radii = None

        torch.cuda.empty_cache()

    def ensure_densification_buffers(self) -> None:
        """保证 densify 辅助 buffer 与当前高斯数量一致。"""
        n = int(self.get_xyz.shape[0])
        if n <= 0:
            return
        dev = self.get_xyz.device
        if self.xyz_gradient_accum.shape[0] != n:
            self.xyz_gradient_accum = torch.zeros((n, 1), device=dev)
            self.denom = torch.zeros((n, 1), device=dev)
        if self.max_radii2D.shape[0] != n:
            old = self.max_radii2D
            self.max_radii2D = torch.zeros((n,), device=dev)
            if old.numel() > 0:
                c = min(n, int(old.numel()))
                self.max_radii2D[:c] = old[:c]

    def add_densification_stats(self, viewspace_point_tensor, update_filter):
        if viewspace_point_tensor.grad is None or update_filter is None:
            return
        self.ensure_densification_buffers()
        n = int(self.get_xyz.shape[0])
        n_vs = int(viewspace_point_tensor.shape[0])
        n_eff = min(n, n_vs, int(self.xyz_gradient_accum.shape[0]))
        if n_eff <= 0:
            return
        flat = update_filter.reshape(-1).long().detach()
        valid = (flat >= 0) & (flat < n_eff)
        if flat.numel() == 0 or not bool(valid.any().cpu().item()):
            return
        sel = torch.unique(flat[valid])
        grad = viewspace_point_tensor.grad
        if grad.shape[0] < n_eff:
            return
        self.xyz_gradient_accum[sel] += torch.norm(grad[sel, :2], dim=-1, keepdim=True)
        self.denom[sel] += 1
