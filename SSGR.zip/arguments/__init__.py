#
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use 
# under the terms of the LICENSE.md file.
#
# For inquiries contact  george.drettakis@inria.fr
#

from argparse import ArgumentParser, Namespace
import sys
import os
import glob

class GroupParams:
    pass

class ParamGroup:
    def __init__(self, parser: ArgumentParser, name : str, fill_none = False):
        group = parser.add_argument_group(name)
        for key, value in vars(self).items():
            shorthand = False
            if key.startswith("_"):
                shorthand = True
                key = key[1:]
            t = type(value)
            value = value if not fill_none else None 
            if shorthand:
                if t == bool:
                    group.add_argument("--" + key, ("-" + key[0:1]), default=value, action="store_true")
                else:
                    group.add_argument("--" + key, ("-" + key[0:1]), default=value, type=t)
            else:
                if t == bool:
                    group.add_argument("--" + key, default=value, action="store_true")
                else:
                    group.add_argument("--" + key, default=value, type=t)

    def extract(self, args):
        group = GroupParams()
        for arg in vars(args).items():
            if arg[0] in vars(self) or ("_" + arg[0]) in vars(self):
                setattr(group, arg[0], arg[1])
        return group

class ModelParams(ParamGroup): 
    def __init__(self, parser, sentinel=False):
        self.sh_degree = 3
        self._source_path = ""
        self._model_path = ""
        self._images = "images"
        self._depths = ""
        self._resolution = -1
        self._white_background = False
        self.train_test_exp = False
        self.data_device = "cuda"
        self.eval = False
        # SAR模式和相关参数（默认启用SAR模式）
        # 注意：sar_mode不在这里定义，而是在super().__init__之后手动添加，以便设置默认值为True
        # 注意：这些参数值应与config.py中的默认值保持一致
        # 注意：sar_image_size_azimuth和sar_image_size_range不应硬编码，应从实际图像读取
        self.sar_camera_height = 12000.0  # SAR相机/平台高度 (m) - 与config.py一致
        self.sar_platform_velocity = 250.0  # 平台速度 (m/s)，与 sar_geometry.DEFAULT_SAR_PARAMS['Va'] 一致
        self.sar_prf = 2500.0  # 脉冲重复频率 (Hz)，与 sar_geometry.DEFAULT_SAR_PARAMS['prf'] 一致
        self.sar_bandwidth = 500e6  # 带宽 (Hz)，MSTAR 距离向约 0.3m 时常用 ~500 MHz
        self.sar_depression_angle = 17.0  # SAR中心下视角 (度) - MSTAR训练基准17°
        # 默认 horizon：文件名为相对水平俯角 φ（MSTAR/OSU），几何内换乘与天底夹角 θ；段值已是 θ 时请设 zenith
        self.sar_mstar_filename_depression_convention = "horizon"
        self.sar_radius_scale = 1.0  # 相机半径缩放因子
        # 注意：图像尺寸不应硬编码，应从实际图像读取（在sfm.py中会自动读取）
        # 这里设置默认值仅作为兜底，实际值会在sfm.py中从图像读取后更新
        self.sar_image_size_azimuth = 128  # SAR图像方位向采样点数（默认值，实际会从图像读取）
        self.sar_image_size_range = 128  # SAR图像距离向采样点数（默认值，实际会从图像读取）
        self.sar_camera_distribution_mode = "ring"  # SAR相机分布模式：'ring'（水平圆环，推荐，避免球状点云）或'sphere'（球面分布）
        self.target_brightness_threshold = 0.5  # 目标点亮度阈值（0-1）：默认只用它从 target_only PLY 去掉暗/黑背景点
        # SAR：SH2RGB(DC) 整体偏暗，光学默认 0.5 常导致 target_only 掩码全空；用 min(threshold, cap) 限制首步上限
        self.sar_target_only_ply_luma_cap = 0.22
        # target_only 经全部规则后仍无点：改用「全体亮度该分位数」为阈（约保留最亮的 100-p%）
        self.target_only_fallback_percentile = 32.0
        # 以下为 target_only 的「额外」过滤，默认全关，避免误删主体；需要时再传对应参数打开
        self.target_ply_min_opacity = 0.0  # >0 时去掉不透明度过低的点
        # 0=关。要求 max(R,G,B)≥该值，压整体仍偏黑的点（须在 Parser 中注册，否则 CLI 不生效）
        self.target_ply_min_peak_rgb = 0.0
        # 在当前掩码内去掉亮度低于「该分位数」的点（0-100，0=关）。如 40 ≈去掉最暗的约 40%，专分棕偏黑/棕偏白
        self.target_ply_drop_darkest_percent = 0.0
        self.target_ply_brightness_tight_percentile = 0.0  # 与 drop_darkest 二选一：若两者均>0 以 drop_darkest 为准
        self.target_ply_density_filter = False  # True 且已安装 scipy 时做 KNN 密度过滤
        self.target_ply_use_scale_filter = False  # True 时用 max_scale_threshold 去掉尺度过大的高斯
        self.target_ply_use_distance_filter = False  # True 时用 distance_threshold_percentile 去掉离群点
        # 0=关。限制 max(R,G,B)-min(R,G,B)，压有色杂点；SAR 近灰主体可试 0.12~0.45
        self.target_ply_max_chroma = 0.0
        # 0=关。在已通过颜色等条件的掩码内做 kNN，去掉局部最孤立的一段（主体周稀疏同色杂点，需 scipy）
        self.target_ply_sparse_trim_percent = 0.0
        self.target_ply_local_k_neighbors = 8  # 与 sparse_trim 配套：掩码内 kNN 邻居数
        # 0=关。要求 min(R,G,B)≥该值，去掉任一路过低的发灰/发黑点（比单看 max 更严）
        self.target_ply_min_floor_rgb = 0.0
        # True：用「训练相机中心→点」方向的完整 SH 颜色做阈值（与渲染视角一致）；PLY 顶点色仍是 DC，若黑点来自高阶 SH 请选择此项
        self.target_ply_use_view_dependent_color = False
        self.max_scale_threshold = 0.5  # 高斯尺度阈值（过滤尺度过大的球状外层点）
        self.filter_negative_z = False  # 是否过滤Z坐标负值的点（SAR目标应在地面上，默认True）
        self.filter_symmetric_points = False  # 是否过滤对称异常点（默认True）
        # 新增：点云密度和距离过滤参数
        self.enable_density_filter = True  # 启用密度过滤（去除孤立点）
        self.enable_distance_filter = True  # 启用距离过滤（去除离群点）
        self.density_k_neighbors = 10  # KNN邻居数（密度过滤用）
        self.density_threshold_percentile = 20.0  # 密度阈值分位数（过滤底部x%低密度点）
        self.distance_threshold_percentile = 70.0  # 距离阈值分位数（保留前x%近中心的点）
        # 新增：统计离群点过滤参数
        self.filter_outliers = True  # 是否启用统计离群点过滤（默认True）
        self.outlier_k = 20  # 统计离群点过滤的最近邻数量（默认20）
        self.outlier_std_ratio = 2.0  # 统计离群点过滤的标准差倍数（默认2.0）
        # 新增：点云密集化参数
        self.densify_points = True  # 是否密集化初始点云（默认True）
        self.densify_multiplier = 2.0  # 点云密集化倍数（默认2.0，即点数翻倍）
        self.densify_method = "knn_interpolation"  # 密集化方法（'knn_interpolation'或'uniform_sampling'）
        # 新增：物理尺寸验证参数
        self.validate_physical_size = True  # 是否验证物理尺寸（默认True）
        self.validate_proportions_only = True  # 仅验证长宽高比例（默认True）；False=验证绝对尺寸
        self.target_type = "tank"  # 目标类型（'tank', 'vehicle', 'small_object'，默认'tank'）
        # 无 SfM / 无 COLMAP：仅从 images/ 与 MSTAR 式文件名 构建相机位姿（与 --mstar_nosfm 联用，对照 SfM 训练）
        self.mstar_nosfm = False
        self.mstar_nosfm_init_points = 100_000
        super().__init__(parser, "Loading Parameters", sentinel)
        
        # 手动添加SAR模式参数，默认启用
        group = parser._action_groups[-1]  # 获取当前参数组
        group.add_argument("--sar_mode", action="store_true", default=True, 
                         help="启用SAR几何模型（默认启用）")
        group.add_argument("--no_sar_mode", dest="sar_mode", action="store_false",
                         help="禁用SAR几何模型")
        group.add_argument("--sar_fast_mode", default=True, action="store_true",
                         help="SAR快速模式：用CUDA光栅化器加速训练（默认启用）")
        group.add_argument("--no_sar_fast_mode", dest="sar_fast_mode", action="store_false",
                         help="禁用SAR快速模式，使用Python SAR光栅化器（慢但更符合论文）")

    def extract(self, args):
        """
        先写入 ModelParams 模板默认值，再用 args 覆盖。
        避免 GroupParams 缺字段时 getattr(..., 0) 导致 CLI 上 target_ply_*「看起来传了但未生效」。
        """
        g = GroupParams()
        for key, val in vars(self).items():
            if key.startswith("_"):
                continue
            setattr(g, key, val)
        for arg_name, arg_val in vars(args).items():
            if arg_name in vars(self) or ("_" + arg_name) in vars(self):
                setattr(g, arg_name, arg_val)
        g.source_path = os.path.abspath(g.source_path)
        g.sar_mode = getattr(args, "sar_mode", True)
        return g

class PipelineParams(ParamGroup):
    def __init__(self, parser):
        self.convert_SHs_python = False
        self.compute_cov3D_python = False
        self.debug = False
        self.antialiasing = False
        self.sar_rendering = True  # SAR渲染（默认启用，与train.py中的配置一致）
        self.sar_sig3dgs_visibility = True  # 论文 SIG-3DGS Eq.18 阴影可见性
        self.sar_shadow_detach_grad = True  # 阴影乘积不回传梯度，防 CUDA backward 数值爆炸
        self.sar_sdgr_cuda = True  # SDGR 散射/阴影 alpha 混合默认 CUDA（与光学 3DGS 一致；失败自动降级 Python）
        # sar_fast_mode 在 ModelParams 中定义，extract 时从 args 复制
        super().__init__(parser, "Pipeline Parameters")
        group = parser._action_groups[-1]
        group.add_argument(
            "--no_sar_sdgr_cuda", dest="sar_sdgr_cuda", action="store_false",
            help="强制 SDGR 使用 Python alpha 混合（更稳但更慢；等价于 set SAR_SDGR_FORCE_PYTHON=1）",
        )

    def extract(self, args):
        import os
        g = super().extract(args)
        g.sar_fast_mode = getattr(args, 'sar_fast_mode', True)
        g.sar_sig3dgs_visibility = getattr(args, 'sar_sig3dgs_visibility', True)  # 论文SIG-3DGS Eq.18可见性公式
        g.sar_shadow_detach_grad = getattr(args, 'sar_shadow_detach_grad', True)
        g.sar_sdgr_cuda = bool(getattr(args, 'sar_sdgr_cuda', True))
        try:
            from diff_sar_rasterization import SAR_RASTERIZATION_AVAILABLE
            if not SAR_RASTERIZATION_AVAILABLE:
                g.sar_sdgr_cuda = False
        except ImportError:
            g.sar_sdgr_cuda = False
        if os.environ.get("SAR_SDGR_FORCE_PYTHON", "").strip().lower() in ("1", "true", "yes"):
            g.sar_sdgr_cuda = False
        elif os.environ.get("SAR_SDGR_CUDA", "").strip().lower() in ("1", "true", "yes"):
            g.sar_sdgr_cuda = True
        return g

class OptimizationParams(ParamGroup):
    def __init__(self, parser):
        self.iterations = 30_000
        self.position_lr_init = 0.00012  # 降低位置学习率，更稳定的收敛（原0.00016）
        self.position_lr_final = 0.0000016
        self.position_lr_delay_mult = 0.01
        self.position_lr_max_steps = 30_000
        self.feature_lr = 0.0025
        self.opacity_lr = 0.05  # 增加opacity学习率，让透明高斯更快被剪枝（原0.025）
        self.scaling_lr = 0.003  # 降低缩放学习率，防止高斯变得过大或过小（原0.005）
        self.rotation_lr = 0.001
        self.exposure_lr_init = 0.01
        self.exposure_lr_final = 0.001
        self.exposure_lr_delay_steps = 0
        self.exposure_lr_delay_mult = 0.0
        self.percent_dense = 0.01  # 恢复密集化百分比，增加点云密度
        self.lambda_dssim = 0.10  # SAR train_sar_complete 默认配方（exp15-5）
        self.lambda_lpips = 0.0  # LPIPS损失权重（默认0.0，在SAR_OPTIMIZED_CONFIG中设置为0.1）
        self.densification_interval = 100  # 恢复间隔，提高密集化频率
        self.opacity_reset_interval = 3000  # 适当降低重置频率
        self.densify_from_iter = 500
        self.densify_until_iter = 15000  # 延长密集化周期，增加细节（由配置覆盖）
        self.densify_grad_threshold = 0.0003  # 降低阈值，允许更多点密集化
        self.depth_l1_weight_init = 1.0
        self.depth_l1_weight_final = 0.01
        self.random_background = False
        # 删除此行：self.sar_mode = False
        self.sar_texture_weight = 0.1  # Weight for texture preservation in SAR
        self.sar_contrast_weight = 0.05  # Weight for contrast enhancement in SAR
        # SAR形状约束参数（防止点云塌陷和分层）
        self.sar_shape_constraint_weight = 0.02  # 增强形状约束权重，防止分层
        self.sar_shape_constraint_start_iter = 500  # 更早开始约束
        self.sar_shape_constraint_end_iter = 25000  # 延长约束周期
        # SAR背景地面约束参数（防止背景点云包裹目标形成球状）
        # 背景压平面损失权重：>0 时对暗且较低的高斯惩罚 Z 方向方差（默认 0 保持与旧版行为一致）
        self.sar_ground_constraint_weight = 0.0
        self.sar_ground_constraint_start_iter = 500  # 开始约束的迭代
        self.sar_ground_constraint_end_iter = 25000  # 结束约束的迭代
        self.sar_background_brightness_threshold = 0.2  # 背景点云亮度阈值（回退值，实际使用每幅图像的分位数）
        self.sar_background_percentile = 1.0  # 背景点云散射强度分位数（1%，与SFM一致，每幅图像单独计算）
        self.sar_ground_height_tolerance = 0.3  # 地面高度容差（米，适中约束避免过度惩罚）
        # 背景压平面：仅对高度坐标处于全场该分位数以下的点施加 Z 方差惩罚（0~1，如 0.45 表示下半部分）
        self.sar_ground_plane_z_quantile = 0.45
        self.sar_ground_plane_min_points = 32  # 参与该损失的最少高斯数，过少则跳过
        # SAR铺开约束参数（防止背景点云形成碗状，鼓励水平方向铺开）
        self.sar_spread_constraint_weight = 0.5  # 铺开约束权重（增强以解决旋转视角无背景问题）
        self.sar_spread_constraint_start_iter = 500  # 从500迭代开始应用铺开约束（提前开始）
        self.sar_spread_constraint_end_iter = 25000  # 结束约束的迭代
        self.sar_spread_min_radius = 10.0  # 最小铺开半径（米），背景点云应该至少铺开到这个范围（增大以确保覆盖）
        # 铺开损失里：暗点半径下限 also max(该比例×全场景 XY 对角线, min_radius×√2)；适度增大可改善背景留白
        self.sar_spread_scene_fraction = 0.50
        self.sar_background_max_scaling = 0.05  # 背景点最大scaling（降低以更严格限制）
        self.sar_background_max_opacity = 0.5  # 背景点最大不透明度（防止背景点过度密集）
        self.sar_target_max_scaling = 0.15  # 目标点最大scaling（防止单个点覆盖太大区域）
        # SAR目标高度压缩约束参数（类似SFM中的高度/长度比例约束）
        self.sar_target_height_constraint_weight = 10.0  # 目标高度压缩约束权重（大幅提高）
        self.sar_target_height_constraint_start_iter = 200  # 开始约束的迭代（提前开始）
        self.sar_target_height_constraint_end_iter = 29500  # 结束约束的迭代（持续到最后）
        # 目标尺寸约束参数（基于SFM计算的目标高度/长度比例约束）
        self.sar_target_dimension_constraint_weight = 50.0  # 目标尺寸约束权重（大幅加大以控制高度过度扩展）
        self.sar_target_dimension_constraint_start_iter = 200  # 开始约束的迭代（大幅提前）
        self.sar_target_dimension_constraint_end_iter = 29500  # 结束约束的迭代（持续到最后）
        self.sar_target_expected_height = 2.5  # 目标期望高度（米，T72坦克约2.5m）  
        self.sar_target_height_weight_factor = 2.0  # 目标高度约束权重因子（适中约束强度）
        self.sar_target_height_scale_threshold = 0.1  # 目标高度比例约束阈值（10%容差，更容易触发）
        self.sar_target_height_length_ratio = 0.3  # 目标高度/长度比例阈值（默认0.3，即高度不应超过长度的30%）
        # 整体点云尺度约束参数（基于SAR图像分辨率和目标尺寸）
        self.sar_scale_constraint_weight = 1.0  # 整体点云尺度约束权重
        self.sar_scale_constraint_start_iter = 0  # 开始约束的迭代（从开始就约束）
        self.sar_scale_constraint_end_iter = 29500  # 结束约束的迭代（持续到最后）
        self.sar_scale_constraint_tolerance = 0.1  # 尺度约束容差（默认10%）
        # 🔧 新的目标高度约束参数（基于SAR图像尺寸和SFM目标检测）
        self.sar_height_constraint_weight = 1.0  # 目标高度约束权重
        self.sar_height_constraint_start_iter = 500  # 开始约束的迭代（在尺度约束之后）
        self.sar_height_constraint_end_iter = 29500  # 结束约束的迭代（持续到最后）
        self.sar_height_constraint_tolerance = 0.1  # 高度约束容差（默认10%）
        self.sar_target_brightness_threshold = 0.5  # 目标点云亮度阈值（回退值，实际使用每幅图像的分位数）
        self.sar_target_percentile = 99.0  # 目标点云散射强度分位数（99%，与SFM一致，每幅图像单独计算）
        # 目标点云过滤参数（在高度抑制前过滤，类似SFM）
        self.sar_target_filter_opacity_threshold = 0.01  # 不透明度阈值（低于此值的点被过滤）
        self.sar_target_filter_scale_threshold = 0.001  # 缩放阈值（小于此值的点被过滤）
        # 保存中间结果参数
        self.sar_save_intermediate_results = True  # 是否保存中间结果（背景过滤、高度抑制前等）
        # 散射强度掩码损失权重参数（用于train_sar_complete.py）
        # 散射强度掩码损失权重：进一步提高目标/边缘、压低背景/阴影，减轻「黑背景盖过亮目标、点云塌成圆环」
        self.background_loss_weight = 0.18
        self.target_loss_weight = 4.5
        # 散射掩码 2（轮廓像素）的 L1 权重：train.py 中 (2) 用本项、(1) 用 target_loss_weight；merge 边缘并入 (1) 后常无类别 2
        self.edge_loss_weight = 5.0
        self.shadow_loss_weight = 0.6
        # True：散射掩码存在时 L1 对 0/1/2/3 区域均等权重（用于 ablation / train_sar_complete 精调预设）
        self.sar_uniform_region_loss = False
        # 目标区（默认掩码 1∪2，稀少时退回非背景）灰度 Sobel 梯度幅值 L1：GT 整幅略糊时仍约束局部对比与轮廓
        self.sar_target_gradient_l1_weight = 0.08
        self.sar_target_gradient_start_iter = 0
        self.sar_target_gradient_end_iter = 100_000
        self.sar_target_gradient_include_shadow = False  # True 时在 1∪2∪3 上计算梯度项
        # 梯度项中对轮廓的额外权重：>1 时 sm==2 像素乘 eb；若无类别 2 则用目标前景二值边界的 Sobel 高分分位像素作为「软轮廓」加权
        self.sar_target_gradient_edge_boost = 2.5
        self.sar_target_gradient_edge_quantile = 0.88  # 仅 fallback 轮廓带：mb 上分位阈值，越高带越窄
        self.sar_target_gradient_loss_scale = 1.0  # 对整项乘系数；过强致「只剩高对比结构」时可试 0.2～0.5
        self.sar_target_depth_order_weight = 0.30  # 兼容旧脚本：同时为阴影/背景的默认深度权（可被下面两项拆分覆盖）
        self.sar_shadow_depth_order_weight = (
            -1.0  # <0：与 sar_target_depth_order_weight 相同；≥0：仅阴影-目标顺序项权重（压住「整块遮光」可先试 0.05～0.12）
        )
        self.sar_background_depth_order_weight = (
            -1.0  # <0：与 sar_target_depth_order_weight 相同；≥0：仅背景-目标顺序项权重（稳住背景分层可保持 0.25～0.35）
        )
        self.sar_target_depth_order_margin = 5e-4
        # SAR 深度顺序项：对各区域(mask)内像素深度做聚合；median 对部分视角掩码不净时更稳健
        self.sar_depth_order_reduce = "mean"  # mean | median（CLI：--sar_depth_order_reduce median）
        # SAR densify（可选）：按 SH DC 亮度粗分两档缩放 clone/split 梯度阈值；
        # 中暗背景 mult 小而更易加密；最暗阴影 mult 大而难于增生（另见 sar_dense_shadow_scaling_log_cap 压更小椭球）。
        self.sar_dense_by_dc_luminance = False  # train_sar_complete 可加 --sar_dense_by_dc_luminance
        self.sar_dense_lumi_shadow_upper = 0.09  # lum ≤：最暗一档（常为阴影）；按数据调高/低
        self.sar_dense_lumi_background_upper = 0.28  # (shadow_upper, background_upper]：中暗一档（常为杂波背景）
        self.sar_dense_shadow_grad_thresh_mult = 1.70  # × densify_grad_threshold；越大越少增生
        self.sar_dense_background_grad_thresh_mult = 0.55  # × 阈值；越小越易增生细化
        # densify_and_prune+clamp_scaling 后对最暗档 _scaling(log)逐轴 capped max；≤-900 表示关闭（默认）
        self.sar_dense_shadow_scaling_log_cap = -999.0
        # True：阴影区(3)深度应近于相机一侧（先于目标），贴合 SAR 叠掩「阴影盖住目标局部」；False：阴影视作在目标后方（旧默认）
        self.sar_shadow_depth_before_target = False
        # 分阶段 SAR 损失：先「只拟合目标区」，再拟合全图（背景+阴影），与仅目标训练更一致
        # until_iter>0 时：在第 1～until_iter 次迭代内，L1 只在目标(+可选边缘)像素上平均；深度顺序项为 0；可选关闭 SSIM
        self.sar_target_only_loss_until_iter = 15000  # 0=关闭；train_sar_complete 默认 exp15-5
        self.sar_target_only_loss_include_edge = True  # True：掩码 1+2；False：仅目标内部 1
        self.sar_target_only_phase_disable_ssim = True  # 目标-only 阶段将 DSSIM 权重视为 0，避免全图结构项拉背景
        # 按方位均衡训练：先均匀选方位 bin，再在该 bin 内随机选相机（需 sar_mode 且相机可解析方位角）
        self.sar_stratify_azimuth = True  # train_sar_complete 默认开启方位分层均衡抽样
        self.sar_azimuth_bins = 0  # ≤0 时在 train.py 中取 len(训练相机)，与视角数对齐
        # 相邻训练方位插值位姿上的双邻域软监督（见 sar/sar_interp_soft_supervision.py）
        self.sar_interp_soft_supervision = False
        self.sar_interp_soft_every = 500
        self.sar_interp_soft_weight = 0.2
        self.sar_interp_soft_start_iter = 500
        self.sar_interp_soft_end_iter = 0  # 0=不限制结束迭代
        self.sar_interp_soft_samples_per_step = 1
        self.sar_interp_soft_t_values = "0.25,0.5,0.75"
        self.sar_interp_soft_azimuth_space = "filename"
        self.sar_interp_soft_use_blend_target = False  # False=双邻域 L1；True=L1(render, w0*I0+w1*I1)
        # 表示能力：球谐阶数提升间隔（迭代），越小则越早用满 max_sh_degree
        self.sh_degree_interval = 1000
        # SFM阴影约束参数
        self.sar_shadow_constraint_weight = 2.0  # SFM阴影约束权重（增强到2.0以产生更强的影响）
        self.sar_shadow_constraint_start_iter = 500  # 更早开始阴影约束（与形状约束同步）
        self.sar_shadow_constraint_end_iter = 25000  # 结束阴影约束的迭代
        self.sar_shadow_constraint_tolerance = 0.01  # 阴影约束容差（从5%降低到1%，更严格的控制）
        self.sar_shadow_enable_direct_height = True  # 是否启用直接高度约束（更强的控制）
        self.sar_shadow_direct_height_weight = 1.0  # 直接高度约束权重

        # 阴影约束前的点云过滤参数
        self.sar_shadow_filter_max_scale = 0.5  # 最大高斯尺度阈值（过滤过大的异常高斯）
        self.sar_shadow_filter_min_opacity = 0.01  # 最小不透明度阈值（过滤透明高斯）
        self.sar_shadow_filter_distance_percentile = 95.0  # 距离过滤百分位数（保留95%近中心点）
        self.sar_shadow_filter_enable_density = True  # 是否启用密度过滤
        self.sar_shadow_filter_density_k = 10  # KNN密度计算的邻居数
        self.sar_shadow_filter_density_percentile = 90.0  # 密度过滤百分位数（保留90%高密度点）

        # 高级过滤参数（针对SAR目标的几何特性）
        self.sar_shadow_filter_enable_clustering = True  # 是否启用聚类过滤（识别主要目标集群）
        self.sar_shadow_filter_cluster_min_size = 50  # 最小集群大小（点数）
        self.sar_shadow_filter_cluster_distance_threshold = 5.0  # 聚类距离阈值（像素）
        self.sar_shadow_filter_keep_top_clusters = 1  # 保留最大的N个集群（通常目标只有一个主要集群）
        # 多视角一致性约束参数（确保不同视角重建同一个3D结构）
        self.sar_multiview_consistency_weight = 0.05  # 多视角一致性约束权重
        self.sar_multiview_consistency_start_iter = 1000  # 开始约束的迭代（早期让模型先适应单个视角）
        self.sar_multiview_consistency_end_iter = 25000  # 结束约束的迭代
        self.sar_multiview_sample_probability = 0.3  # 每次迭代采样另一个视角进行一致性约束的概率（0.3表示30%的概率）
        self.optimizer_type = "default"
        # refine：固定目标初值下抑制「过亮背景壳」与目标混淆（见 train.py L_refine_brightness_cap）
        self.sar_refine_target_bg = True  # train_sar_complete 默认 exp15-5；关闭请用 --no_sar_refine_target_bg
        self.sar_refine_brightness_cap_weight = 0.15  # 配合 sar_refine_target_bg；train 内若为 0 可回落默认 0.12
        self.sar_refine_brightness_cap_disable = False  # True=完全关闭亮度帽（即使 refine）
        self.sar_refine_brightness_cap_quantile = 0.99  # 初始点云 DC 亮度分位数作上沿（目标上沿）
        self.sar_refine_brightness_cap_margin = 0.02  # 上沿下浮，禁止与上沿同亮或更亮
        # >0 时：新增点亮度上限取 min(分位帽, 初始中位亮度−此项)，强制比典型目标暗一截（便于背景/地面）
        self.sar_refine_brightness_cap_median_margin = 0.04
        # refine：与 train_sar_complete 一致；extract 后 train.py 可读（否则仅出现在外层 Namespace 会丢失）
        self.sar_refine_light_densify = True
        # refine + 关闭 densify：在目标 AABB 外自动铺背景/遮光板（见 sar/sar_seed_refine_bg_shadow.py）
        self.sar_refine_seed_bg_shadow_plates = True
        # camera_ray（默认）：均值训练相机→目标质心视线，背景远、阴影近；world_axis：世界轴铺板（sar_refine_seed_vertical_*）
        self.sar_refine_seed_placement_mode = "camera_ray"
        self.sar_refine_seed_vertical_axis = "y"  # world_axis 模式：铺在 x/y/z 哪一根轴的法平面上
        self.sar_refine_seed_vertical_flip = False  # True 时在各自模式下交换阴影/背景的「近/远侧」赋值
        self.sar_refine_seed_bbox_margin_frac = 0.12  # 板面内向外的切向边距系数（× 目标包络对角线）
        self.sar_refine_seed_below_extent_frac = 0.06  # camera_ray：背景沿 ω 更远侧偏移系数；world_axis：背景侧偏移
        self.sar_refine_seed_above_extent_frac = 0.026  # camera_ray：shadow_origin = centroid − frac·diag·ω（↓frac → 薄片更贴近目标 → 整体上离相机更远）；world_axis：阴影侧偏移
        self.sar_refine_seed_bg_plane_resolution = 12
        self.sar_refine_seed_bg_plane_resolution_v = 12
        self.sar_refine_seed_shadow_plane_resolution = 10
        self.sar_refine_seed_shadow_plane_resolution_v = 10
        self.sar_refine_seed_bg_brightness_scale = 0.88  # × 目标 DC 中位亮度
        self.sar_refine_seed_shadow_brightness_scale = 0.32
        self.sar_refine_seed_plane_gaussian_scale_mult = 1.45  # camera_ray：板切向两轴尺度；world_axis：面内两轴
        self.sar_refine_seed_slab_thin_scale_mult = 0.42  # 沿薄片法向（camera_ray：ω）压薄系数
        self.sar_refine_seed_bg_initial_opacity = 0.28  # sigmoid 前用 inverse 激活，此处为「表观」不透明度初值
        self.sar_refine_seed_shadow_initial_opacity = 0.45
        # BG/阴影 NVS refine（见 sar/sar_refine_target_bg.py、sar/sar_refine_bg_shadow_train.py）
        self.sar_refine_freeze_target_gaussians = False
        self.sar_refine_bg_shadow_only_loss = False
        self.sar_refine_bg_shadow_target_anchor_weight = 0.0
        self.sar_refine_new_point_max_luma_fraction = 0.0
        self.sar_refine_new_point_luma_cap_weight = 0.0
        self.sar_refine_disable_clamp_scaling = False
        self.sar_refine_shadow_over_occlusion_weight = 0.0
        self.sar_refine_shadow_under_occlusion_weight = 0.0
        self.sar_refine_shadow_occlusion_margin = 0.04
        self.sar_refine_bg_ground_plane_weight = 0.0
        self.sar_refine_bg_ground_plane_tol_frac = 0.04
        self.sar_refine_seed_ground_axis = "z"
        self.sar_refine_seed_ground_bottom_quantile = 0.10
        self.sar_refine_seed_shadow_depth_fracs = "0.022"
        super().__init__(parser, "Optimization Parameters")
        parser.add_argument(
            "--no_sar_refine_target_bg",
            dest="sar_refine_target_bg",
            action="store_false",
            help="关闭 sar_refine_target_bg（OptimizationParams 默认为开启）",
        )
        parser.add_argument(
            "--no_sar_stratify_azimuth",
            dest="sar_stratify_azimuth",
            action="store_false",
            help="关闭按方位角分桶均衡抽样（默认开启）",
        )
        parser.add_argument(
            "--no_sar_shadow_depth_before_target",
            dest="sar_shadow_depth_before_target",
            action="store_false",
            help="关闭「阴影先于目标」的深度正则（refine 预设默认开启此项）",
        )
        parser.add_argument(
            "--no_sar_refine_light_densify",
            dest="sar_refine_light_densify",
            action="store_false",
            help="refine：关闭轻量 densify（与预设 densify_until_iter=0 一致；无 densify 时默认自动铺背景/遮光板，可用 --no_sar_refine_seed_bg_shadow_plates 关闭）",
        )
        parser.add_argument(
            "--no_sar_refine_seed_bg_shadow_plates",
            dest="sar_refine_seed_bg_shadow_plates",
            action="store_false",
            help="refine + 关闭 densify 时：禁用自动两片板状高斯（默认沿相机→目标深度分层；改用 world_axis 时见 vertical_*）",
        )

def _strip_scattering_masks_blob_from_cfg_str(s: str) -> str:
    """
    训练写入的 cfg_args 若含 scattering_masks，多为 numpy 的截断 repr（含 ...、shape=），无法用 eval 还原。
    将整个 scattering_masks={...} 替换为 None；掩码改从 source_path/scattering_masks/run_*/*_mask.npy 加载。
    """
    key = "scattering_masks="
    i = 0
    while True:
        i = s.find(key, i)
        if i < 0:
            return s
        j = i + len(key)
        while j < len(s) and s[j] in " \t\n\r":
            j += 1
        if j >= len(s) or s[j] != "{":
            i = j
            continue
        depth = 0
        k = j
        while k < len(s):
            c = s[k]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    s = s[:i] + "scattering_masks=None" + s[k + 1 :]
                    i = i + len("scattering_masks=None")
                    break
            k += 1
        else:
            return s


def _reload_scattering_masks_from_source(source_path: str, images_rel: str):
    """从 scattering_masks/from_convert/ 或 run_<id>/*_mask.npy 恢复字典（键为带扩展名的图像名）。"""
    import numpy as np

    images_folder = os.path.join(source_path, images_rel or "images")
    if not os.path.isdir(images_folder):
        for alt in ("input", "imgs", "image"):
            alt_path = os.path.join(source_path, alt)
            if os.path.isdir(alt_path):
                images_folder = alt_path
                break
    if not os.path.isdir(images_folder):
        return None

    try:
        from sar.semantic_mask_config import load_convert_scattering_masks

        loaded = load_convert_scattering_masks(source_path, images_folder)
        if loaded is not None:
            masks, _ = loaded
            return masks
    except Exception:
        pass

    sm_root = os.path.join(source_path, "scattering_masks")
    if not os.path.isdir(sm_root):
        return None
    runs = [d for d in glob.glob(os.path.join(sm_root, "run_*")) if os.path.isdir(d)]
    if not runs:
        return None
    runs.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    stem_to_fname = {}
    for f in os.listdir(images_folder):
        fp = os.path.join(images_folder, f)
        if os.path.isfile(fp):
            stem_to_fname[os.path.splitext(f)[0]] = f
    for run in runs:
        npys = glob.glob(os.path.join(run, "*_mask.npy"))
        if not npys:
            continue
        masks = {}
        for p in npys:
            base = os.path.basename(p)
            if not base.endswith("_mask.npy"):
                continue
            stem = base[: -len("_mask.npy")]
            fname = stem_to_fname.get(stem)
            if fname:
                masks[fname] = np.load(p)
        if masks:
            return masks
    return None


def get_combined_args(parser : ArgumentParser):
    cmdlne_string = sys.argv[1:]
    cfgfile_string = "Namespace()"
    args_cmdline = parser.parse_args(cmdlne_string)

    try:
        cfgfilepath = os.path.join(args_cmdline.model_path, "cfg_args")
        print("Looking for config file in", cfgfilepath)
        with open(cfgfilepath) as cfg_file:
            print("Config file found: {}".format(cfgfilepath))
            cfgfile_string = cfg_file.read()
    except TypeError:
        print("Config file not found at")
        pass
    except FileNotFoundError as e:
        mp = args_cmdline.model_path
        extra = ""
        if mp and isinstance(mp, str):
            low = mp.replace("\\", "/").lower()
            if "nfsm" in low and "nsfm" not in low:
                extra = "  提示: 目录名是否将 **nsfm** 误写为 **nfsm**？\n"
        raise FileNotFoundError(
            f"未找到训练配置: {cfgfilepath}\n"
            f"  请检查 -m / --model_path 是否写对，且该目录为训练输出目录、内含训练生成的 cfg_args。\n"
            f"{extra}"
        ) from e
    cfgfile_string = _strip_scattering_masks_blob_from_cfg_str(cfgfile_string)
    args_cfgfile = eval(cfgfile_string, {"__builtins__": __builtins__, "Namespace": Namespace})

    merged_dict = vars(args_cfgfile).copy()
    cmd = vars(args_cmdline)
    for k, v in cmd.items():
        if v is not None:
            merged_dict[k] = v
    # 命令行里为 None 的项（如 --output_dir 默认）不会进入上一循环，但 cfg 里也可能没有该键
    #（例如 render_novel_sar_views 仅存在于当前脚本的参数），需补全，否则 Namespace 缺属性。
    for k, v in cmd.items():
        if k not in merged_dict:
            merged_dict[k] = v
    if merged_dict.get("scattering_masks") is None:
        sp = merged_dict.get("source_path")
        if sp:
            img_rel = merged_dict.get("images")
            if img_rel in (None, ""):
                img_rel = "images"
            loaded = _reload_scattering_masks_from_source(sp, img_rel)
            if loaded:
                merged_dict["scattering_masks"] = loaded
                print(f"已从数据目录重新加载 scattering_masks（{len(loaded)} 张）: {sp}")
    return Namespace(**merged_dict)