#
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use 
# under the terms of the LICENSE.md file.
#
# For inquiries contact  george.drettakis@inria.fr
#

import os
import torch
from random import randint
from utils.loss_utils import l1_loss, ssim
from gaussian_renderer import render, network_gui
import sys
from scene import Scene, GaussianModel
from utils.general_utils import safe_state, get_expon_lr_func
import uuid
from tqdm import tqdm
from utils.image_utils import psnr
from argparse import ArgumentParser, Namespace
from arguments import ModelParams, PipelineParams, OptimizationParams
import numpy as np
from plyfile import PlyData, PlyElement
from scipy.spatial import cKDTree


# ============================================================================
# 高度压缩相关函数
# ============================================================================

# ============================================================================
# SAR-GS默认配置（MSTAR数据集推荐参数）
# ============================================================================
SAR_DEFAULT_CONFIG = {
    # SAR模式开关
    'use_sar_mode': True,              # 是否启用SAR模式（设为False使用标准3D-GS）
    'use_sar_rendering': True,         # 是否使用SAR渲染器（Python版SDGR）
    
    # MSTAR数据集标准参数
    'sar_camera_height': 12000.0,      # SAR平台高度（米）- MSTAR典型值
    'sar_platform_velocity': 250.0,    # 平台速度（m/s）- MSTAR典型值
    'sar_prf': 2500.0,                 # 脉冲重复频率（Hz）- MSTAR典型值
    'sar_bandwidth': 500e6,            # 带宽（Hz）- MSTAR典型值：500 MHz
    'sar_image_size_azimuth': 512,     # 方位向图像尺寸
    'sar_image_size_range': 512,       # 距离向图像尺寸
    
    # 相机分布和几何
    'sar_camera_distribution_mode': 'sphere',  # 球面分布（推荐）或'ring'水平圆环
    'sar_depression_angle': 17.0,       # 中心俯视角（度）- MSTAR训练基准17°
    'sar_radius_scale': 1.0,           # 相机半径缩放因子
    
    # 形状约束（防止点云塌陷成2D圆饼）
    'sar_shape_constraint_weight': 0.1,       # 形状约束权重（增强10倍，约束Z方向）
    'sar_shape_constraint_start_iter': 500,   # 提前开始（从500迭代）
    'sar_shape_constraint_end_iter': 25000,   # 延长约束时间
    
    # 训练参数
    'iterations': 30000,               # 总训练迭代次数（SAR图像建议30000）
    'position_lr_init': 0.00016,       # 位置学习率初始值
    'lambda_dssim': 0.2,               # SSIM损失权重
    'densify_until_iter': 15000,       # 密集化停止迭代
}

# 快速配置预设（用于测试和调试）
SAR_FAST_CONFIG = {
    **SAR_DEFAULT_CONFIG,
    'iterations': 5000,
    'densify_until_iter': 2500,
    'sar_shape_constraint_end_iter': 3000,
}

# 高质量配置预设（用于最终结果）
SAR_HIGH_QUALITY_CONFIG = {
    **SAR_DEFAULT_CONFIG,
    'iterations': 50000,
    'densify_until_iter': 25000,
    'sar_shape_constraint_end_iter': 35000,
    'position_lr_init': 0.00012,  # 降低学习率以获得更稳定的结果
}

# 选择使用的配置（修改这里来切换配置）
# ACTIVE_SAR_CONFIG = SAR_FAST_CONFIG   
ACTIVE_SAR_CONFIG = SAR_DEFAULT_CONFIG  # 可改为 SAR_FAST_CONFIG 或 SAR_HIGH_QUALITY_CONFIG
# ACTIVE_SAR_CONFIG = SAR_HIGH_QUALITY_CONFIG
def print_sar_config():
    """打印当前SAR配置"""
    print("\n" + "="*70)
    print("当前SAR配置")
    print("="*70)
    
    if not ACTIVE_SAR_CONFIG['use_sar_mode']:
        print("⚠️  SAR模式已禁用，使用标准3D Gaussian Splatting")
        return
    
    print(f"✅ SAR模式: 启用")
    print(f"✅ SAR渲染器: {'启用 (Python版SDGR)' if ACTIVE_SAR_CONFIG['use_sar_rendering'] else '禁用'}")
    print(f"\n【MSTAR数据集参数】")
    print(f"  平台高度: {ACTIVE_SAR_CONFIG['sar_camera_height']:.1f} m")
    print(f"  平台速度: {ACTIVE_SAR_CONFIG['sar_platform_velocity']:.1f} m/s")
    print(f"  脉冲重复频率: {ACTIVE_SAR_CONFIG['sar_prf']:.1f} Hz")
    print(f"  带宽: {ACTIVE_SAR_CONFIG['sar_bandwidth']/1e6:.0f} MHz")
    print(f"  图像尺寸: {ACTIVE_SAR_CONFIG['sar_image_size_azimuth']}×{ACTIVE_SAR_CONFIG['sar_image_size_range']}")
    print(f"\n【几何参数】")
    print(f"  相机分布: {ACTIVE_SAR_CONFIG['sar_camera_distribution_mode']}")
    print(f"  中心俯视角: {ACTIVE_SAR_CONFIG['sar_depression_angle']:.2f}°")
    print(f"\n【形状约束】")
    print(f"  约束权重: {ACTIVE_SAR_CONFIG['sar_shape_constraint_weight']}")
    print(f"  约束迭代: {ACTIVE_SAR_CONFIG['sar_shape_constraint_start_iter']} - {ACTIVE_SAR_CONFIG['sar_shape_constraint_end_iter']}")
    print(f"\n【训练参数】")
    print(f"  总迭代次数: {ACTIVE_SAR_CONFIG['iterations']}")
    print(f"  位置学习率: {ACTIVE_SAR_CONFIG['position_lr_init']}")
    print(f"  密集化截止: {ACTIVE_SAR_CONFIG['densify_until_iter']}")
    print("="*70 + "\n")

def apply_sar_config_to_args(args):
    """将SAR配置应用到命令行参数"""
    
    # 只有在参数未被命令行显式设置时才应用默认值
    # 注意：这里假设ModelParams和OptimizationParams的属性可以直接访问
    
    # SAR模式参数
    if hasattr(args, 'sar_mode') and args.sar_mode is None:
        args.sar_mode = ACTIVE_SAR_CONFIG['use_sar_mode']
    
    # SAR系统参数
    sar_param_mapping = {
        'sar_camera_height': 'sar_camera_height',
        'sar_platform_velocity': 'sar_platform_velocity',
        'sar_prf': 'sar_prf',
        'sar_bandwidth': 'sar_bandwidth',
        'sar_image_size_azimuth': 'sar_image_size_azimuth',
        'sar_image_size_range': 'sar_image_size_range',
        'sar_camera_distribution_mode': 'sar_camera_distribution_mode',
        'sar_depression_angle': 'sar_depression_angle',
        'sar_radius_scale': 'sar_radius_scale',
        'sar_shape_constraint_weight': 'sar_shape_constraint_weight',
        'sar_shape_constraint_start_iter': 'sar_shape_constraint_start_iter',
        'sar_shape_constraint_end_iter': 'sar_shape_constraint_end_iter',
    }
    
    for config_key, arg_key in sar_param_mapping.items():
        if hasattr(args, arg_key) and config_key in ACTIVE_SAR_CONFIG:
            # 如果参数值等于arguments/__init__.py中的默认值，则使用配置文件的值
            # 这样可以让配置文件的值覆盖默认值，但不覆盖用户在命令行设置的值
            setattr(args, arg_key, ACTIVE_SAR_CONFIG[config_key])
    
    # 训练参数（只在未明确设置时应用）
    if hasattr(args, 'iterations') and 'iterations' in ACTIVE_SAR_CONFIG:
        # 检查是否是默认值（30000），如果是则使用配置
        if args.iterations == 30000:  # OptimizationParams中的默认值
            args.iterations = ACTIVE_SAR_CONFIG['iterations']
    
    if hasattr(args, 'position_lr_init') and 'position_lr_init' in ACTIVE_SAR_CONFIG:
        if args.position_lr_init == 0.00016:  # 默认值
            args.position_lr_init = ACTIVE_SAR_CONFIG['position_lr_init']
    
    if hasattr(args, 'densify_until_iter') and 'densify_until_iter' in ACTIVE_SAR_CONFIG:
        if args.densify_until_iter == 15000:  # 默认值
            args.densify_until_iter = ACTIVE_SAR_CONFIG['densify_until_iter']
    
    return args
# ============================================================================
try:
    from torch.utils.tensorboard import SummaryWriter
    TENSORBOARD_FOUND = True
except ImportError:
    TENSORBOARD_FOUND = False

try:
    from fused_ssim import fused_ssim
    FUSED_SSIM_AVAILABLE = True
except:
    FUSED_SSIM_AVAILABLE = False

try:
    from diff_gaussian_rasterization import SparseGaussianAdam
    SPARSE_ADAM_AVAILABLE = True
except:
    SPARSE_ADAM_AVAILABLE = False

def training(dataset, opt, pipe, testing_iterations, saving_iterations, checkpoint_iterations, checkpoint, debug_from, args=None):

    if not SPARSE_ADAM_AVAILABLE and opt.optimizer_type == "sparse_adam":
        sys.exit(f"Trying to use sparse adam but it is not installed, please install the correct rasterizer using pip install [3dgs_accel].")

    first_iter = 0
    tb_writer = prepare_output_and_logger(dataset)
    gaussians = GaussianModel(dataset.sh_degree, opt.optimizer_type)
    scene = Scene(dataset, gaussians)
    gaussians.training_setup(opt)
    if checkpoint:
        (model_params, first_iter) = torch.load(checkpoint)
        gaussians.restore(model_params, opt)

    bg_color = [1, 1, 1] if dataset.white_background else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device="cuda")

    # ========== 加载目标尺寸约束 ==========
    target_constraints = None
    scale_constraint_params = None  # 整体点云尺度约束参数
    if getattr(dataset, 'sar_mode', False):
        # 尝试从多个位置加载目标尺寸约束文件
        possible_paths = [
            os.path.join(dataset.source_path, 'target_dimension_constraints_summary.txt'),
            os.path.join(dataset.source_path, 'adaptive_threshold_visualization', 'target_dimension_constraints_summary.txt'),
            os.path.join(dataset.source_path, 'feature_output', 'target_dimension_constraints_summary.txt'),
            os.path.join(dataset.model_path, 'target_dimension_constraints_summary.txt'),
            'target_dimension_constraints_summary.txt'  # 当前目录
        ]

        summary_file = None
        for path in possible_paths:
            if os.path.exists(path):
                summary_file = path
                break

        if summary_file:
            print(f"\n📋 发现目标尺寸约束文件: {summary_file}")
            try:
                import re
                from feature_extraction import load_target_dimension_constraints_from_summary
                target_constraints = load_target_dimension_constraints_from_summary(summary_file)
                if target_constraints:
                    print("   ✅ 成功加载目标尺寸约束")
                else:
                    print("   ⚠️ 加载失败，将不使用目标尺寸约束")
                
                # 🔧 加载整体点云尺度约束参数
                try:
                    with open(summary_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # 从汇总文件中提取分辨率
                    resolution_pattern = r'分辨率[：:]\s*([\d.]+)\s*米/像素'
                    resolution_match = re.search(resolution_pattern, content)
                    
                    # 从"目标尺寸统计（像素单位）"中提取长度和宽度的均值
                    length_pattern = r'长度\s*\(L\)[：:]\s*均值=([\d.]+)'
                    width_pattern = r'宽度\s*\(W\)[：:]\s*均值=([\d.]+)'
                    
                    length_match = re.search(length_pattern, content)
                    width_match = re.search(width_pattern, content)
                    
                    # 🔧 从汇总文件中提取高度/长度比例（H/L ratio，来自阴影计算）
                    # 尝试匹配"推荐高度/长度比例"或"高度/长度比例 (H/L): 均值=..."
                    height_length_ratio_patterns = [
                        r'推荐高度/长度比例[：:]\s*([\d.]+)',  # 推荐值
                        r'高度/长度比例\s*\(H/L\)[：:]\s*均值=([\d.]+)',  # 均值
                        r'高度/长度比例\s*\(H/L\)[：:]\s*([\d.]+)'  # 单个值
                    ]
                    height_length_ratio_match = None
                    for pattern in height_length_ratio_patterns:
                        height_length_ratio_match = re.search(pattern, content)
                        if height_length_ratio_match:
                            break
                    
                    # 从"分辨率计算的目标尺寸"中提取SAR图像尺寸
                    pixel_width_pattern = r'像素尺寸[：:]\s*([\d.]+)\s*×\s*([\d.]+)\s*像素'
                    pixel_match = re.search(pixel_width_pattern, content)
                    
                    # 🔧 如果汇总文件中没有分辨率，尝试从config.py或dataset参数中获取
                    if not resolution_match:
                        # 从dataset参数中获取分辨率（如果可用）
                        resolution = getattr(dataset, 'sfm_scale_constraint_resolution', None)
                        if resolution is None:
                            # 从config.py默认值获取
                            resolution = 0.3  # 默认0.3米/像素
                            print(f"   ⚠️ 汇总文件中未找到分辨率，使用默认值: {resolution} 米/像素")
                        else:
                            print(f"   ℹ️ 从dataset参数获取分辨率: {resolution} 米/像素")
                    else:
                        resolution = float(resolution_match.group(1))
                    
                    # 🔧 如果汇总文件中没有SAR图像尺寸，尝试从dataset参数中获取
                    if not pixel_match:
                        image_width = getattr(dataset, 'sar_image_size_azimuth', 128)
                        image_height = getattr(dataset, 'sar_image_size_range', 128)
                        print(f"   ⚠️ 汇总文件中未找到SAR图像尺寸，使用默认值: {image_width}×{image_height} 像素")
                    else:
                        image_width = float(pixel_match.group(1))
                        image_height = float(pixel_match.group(2))
                    
                    if length_match and width_match:
                        # resolution已在上面获取（从汇总文件或dataset参数）
                        target_length_pixels = float(length_match.group(1))
                        target_width_pixels = float(width_match.group(1))
                        
                        # 计算目标尺寸（物理单位：米）
                        target_length_meters = target_length_pixels * resolution
                        target_width_meters = target_width_pixels * resolution
                        
                        # 🔧 获取高度/长度比例（H/L ratio）
                        if height_length_ratio_match:
                            height_length_ratio = float(height_length_ratio_match.group(1))
                        else:
                            # 如果汇总文件中没有，尝试从target_constraints中获取
                            height_length_ratio = target_constraints.get('height_length_ratio', None) if target_constraints else None
                            if height_length_ratio is None:
                                print(f"   ⚠️ 未找到高度/长度比例，将无法进行高度约束")
                                height_length_ratio = None
                        
                        # 🔧 计算目标高度（基于目标长度和H/L比例）
                        if height_length_ratio is not None:
                            target_height_meters = target_length_meters * height_length_ratio
                        else:
                            target_height_meters = None
                        
                        # 🔧 SAR图像尺寸已在上面获取（从汇总文件或dataset参数）
                        
                        # 计算SAR图像覆盖范围
                        sar_image_coverage_length = image_width * resolution
                        sar_image_coverage_width = image_height * resolution
                        
                        scale_constraint_params = {
                            'resolution': resolution,
                            'image_width': image_width,
                            'image_height': image_height,
                            'sar_image_coverage_length': sar_image_coverage_length,
                            'sar_image_coverage_width': sar_image_coverage_width,
                            'target_length_pixels': target_length_pixels,
                            'target_width_pixels': target_width_pixels,
                            'target_length_meters': target_length_meters,
                            'target_width_meters': target_width_meters,
                            'height_length_ratio': height_length_ratio,  # 🔧 新增：H/L比例
                            'target_height_meters': target_height_meters,  # 🔧 新增：目标高度
                        }
                        
                        print(f"\n   ✅ 加载整体点云尺度约束参数:")
                        print(f"      SAR图像覆盖范围: {sar_image_coverage_length:.2f}m × {sar_image_coverage_width:.2f}m")
                        print(f"      目标尺寸（像素）: {target_length_pixels:.2f} × {target_width_pixels:.2f} 像素")
                        print(f"      目标尺寸（物理）: {target_length_meters:.4f}m × {target_width_meters:.4f}m")
                        if height_length_ratio is not None:
                            print(f"      高度/长度比例（H/L）: {height_length_ratio:.4f}")
                            print(f"      目标高度（计算）: {target_height_meters:.4f}m")
                        else:
                            print(f"      ⚠️ 高度/长度比例: 未找到")
                    else:
                        print(f"   ⚠️ 汇总文件中未找到完整的分辨率和目标尺寸信息")
                except Exception as e:
                    print(f"   ⚠️ 加载整体点云尺度约束参数时出错: {e}")
                    import traceback
                    traceback.print_exc()
            except Exception as e:
                print(f"   ⚠️ 加载目标尺寸约束时出错: {e}")
                print("   将不使用目标尺寸约束")
                import traceback
                traceback.print_exc()
        else:
            print(f"\n⚠️ 未找到目标尺寸约束文件，将不使用目标尺寸约束")
            print(f"   搜索路径: {[os.path.basename(p) for p in possible_paths]}")

    iter_start = torch.cuda.Event(enable_timing = True)
    iter_end = torch.cuda.Event(enable_timing = True)

    use_sparse_adam = opt.optimizer_type == "sparse_adam" and SPARSE_ADAM_AVAILABLE 
    depth_l1_weight = get_expon_lr_func(opt.depth_l1_weight_init, opt.depth_l1_weight_final, max_steps=opt.iterations)

    viewpoint_stack = scene.getTrainCameras().copy()
    viewpoint_indices = list(range(len(viewpoint_stack)))
    ema_loss_for_log = 0.0
    ema_Ll1depth_for_log = 0.0
    ema_Lshape_for_log = 0.0
    ema_Lscale_for_log = 0.0  # 整体点云尺度约束损失
    ema_Lheight_for_log = 0.0  # 🔧 目标高度约束损失
    ema_Lmultiview_for_log = 0.0

    progress_bar = tqdm(range(first_iter, opt.iterations), desc="Training progress", dynamic_ncols=True, leave=True)
    first_iter += 1
    for iteration in range(first_iter, opt.iterations + 1):
        if network_gui.conn == None:
            network_gui.try_connect()
        while network_gui.conn != None:
            try:
                net_image_bytes = None
                custom_cam, do_training, pipe.convert_SHs_python, pipe.compute_cov3D_python, keep_alive, scaling_modifer = network_gui.receive()
                if custom_cam != None:
                    use_sar_mode = getattr(dataset, 'sar_mode', False) and getattr(pipe, 'sar_rendering', False)
                    net_image = render(custom_cam, gaussians, pipe, background, scaling_modifier=scaling_modifer, use_trained_exp=dataset.train_test_exp, separate_sh=SPARSE_ADAM_AVAILABLE, sar_mode=use_sar_mode)["render"]
                    net_image_bytes = memoryview((torch.clamp(net_image, min=0, max=1.0) * 255).byte().permute(1, 2, 0).contiguous().cpu().numpy())
                network_gui.send(net_image_bytes, dataset.source_path)
                if do_training and ((iteration < int(opt.iterations)) or not keep_alive):
                    break
            except Exception as e:
                network_gui.conn = None

        iter_start.record()

        gaussians.update_learning_rate(iteration)

        # Every 1000 its we increase the levels of SH up to a maximum degree
        if iteration % 1000 == 0:
            gaussians.oneupSHdegree()

        # Pick a random Camera
        if not viewpoint_stack:
            viewpoint_stack = scene.getTrainCameras().copy()
            viewpoint_indices = list(range(len(viewpoint_stack)))
            # 🔧 调试：打印视角使用情况（每1000次迭代）
            if iteration % 1000 == 0:
                print(f"\n[ITER {iteration}] 训练视角数量: {len(viewpoint_stack)}")
                # 统计不同方位角的视角数量
                azimuth_counts = {}
                for cam in viewpoint_stack:
                    if hasattr(cam, 'image_name'):
                        # 尝试从图像名称中提取方位角（例如：T72-15-002 -> 002）
                        img_name = cam.image_name
                        if 'azimuth' in img_name.lower() or any(char.isdigit() for char in img_name[-3:]):
                            # 提取最后3位数字作为方位角标识
                            try:
                                azimuth_id = img_name[-7:-4] if len(img_name) >= 7 else img_name[-3:]
                                azimuth_counts[azimuth_id] = azimuth_counts.get(azimuth_id, 0) + 1
                            except:
                                pass
                if azimuth_counts:
                    print(f"  方位角分布: {azimuth_counts}")
        rand_idx = randint(0, len(viewpoint_indices) - 1)
        viewpoint_cam = viewpoint_stack.pop(rand_idx)
        vind = viewpoint_indices.pop(rand_idx)
        
        # 🔧 调试：记录当前使用的视角（每100次迭代）
        if iteration % 100 == 0:
            current_view_name = getattr(viewpoint_cam, 'image_name', f'view_{vind}')
            print(f"[ITER {iteration}] 使用视角: {current_view_name}")

        # Render
        if (iteration - 1) == debug_from:
            pipe.debug = True

        bg = torch.rand((3), device="cuda") if opt.random_background else background

        # ========== SAR渲染模式 ==========
        # 检查是否使用SAR渲染模式（使用SDGR - SAR Differentiable Gaussian Splatting Rasterizer）
        use_sar_mode = (getattr(dataset, 'sar_mode', False) and 
                       getattr(viewpoint_cam, 'use_sar_rendering', False) and
                       ACTIVE_SAR_CONFIG.get('use_sar_rendering', False))
        
        # 🔧 检查：确保SAR模式下使用SAR投影矩阵而不是透视投影
        if use_sar_mode:
            if not (hasattr(viewpoint_cam, 'use_sar_rendering') and viewpoint_cam.use_sar_rendering):
                print(f"⚠️ 警告: SAR模式已启用，但相机 {viewpoint_cam.image_name} 未设置use_sar_rendering=True")
            if not (hasattr(viewpoint_cam, 'R_world_to_radar') and viewpoint_cam.R_world_to_radar is not None):
                print(f"⚠️ 警告: SAR模式已启用，但相机 {viewpoint_cam.image_name} 缺少R_world_to_radar参数")
        
        # 渲染（使用SDGR或标准渲染器）
        render_pkg = render(viewpoint_cam, gaussians, pipe, bg, 
                          use_trained_exp=dataset.train_test_exp, 
                          separate_sh=SPARSE_ADAM_AVAILABLE, 
                          sar_mode=use_sar_mode)
        image, viewspace_point_tensor, visibility_filter, radii = render_pkg["render"], render_pkg["viewspace_points"], render_pkg["visibility_filter"], render_pkg["radii"]

        # 🔧 应用alpha掩码（如果有）
        # 注意：train_test_exp模式下，alpha_mask用于裁剪图像的一半（用于曝光补偿实验）
        # 但如果不正确设置，可能导致左侧或右侧是黑色的
        if viewpoint_cam.alpha_mask is not None:
            alpha_mask = viewpoint_cam.alpha_mask.cuda()
            # 🔧 检查alpha_mask是否全为1（未裁剪），如果是则不需要应用
            if alpha_mask.min() < 1.0:  # 只有当alpha_mask有裁剪时才应用
                image *= alpha_mask
            # 否则，alpha_mask全为1，不需要应用（避免不必要的计算）

        # ========== 计算损失函数 ==========
        gt_image = viewpoint_cam.original_image.cuda()
        
        # SAR模式：可选地应用散射强度掩码来只在目标区域计算损失
        if use_sar_mode and hasattr(viewpoint_cam, 'scattering_mask') and viewpoint_cam.scattering_mask is not None:
            # 将散射强度掩码转换为损失权重
            # 掩码值：0=背景(权重低), 1=目标(权重高), 2=目标边缘(权重最高)
            scattering_mask = viewpoint_cam.scattering_mask
            if isinstance(scattering_mask, type(np.array([])).__class__):
                scattering_mask = torch.from_numpy(scattering_mask).float().cuda()
            else:
                scattering_mask = scattering_mask.float().cuda()
            
            # 调整掩码尺寸以匹配图像
            if scattering_mask.shape != image.shape[1:]:
                import torch.nn.functional as F
                scattering_mask = F.interpolate(
                    scattering_mask.unsqueeze(0).unsqueeze(0), 
                    size=image.shape[1:], 
                    mode='nearest'
                ).squeeze()
            
            # 创建权重: 背景=0.5（增加以更好约束背景）, 目标=1.0, 边缘=1.5
            # 注意：背景权重从0.1增加到0.5，确保背景区域也被正确重建
            background_weight = getattr(opt, 'background_loss_weight', 0.5)
            target_weight = getattr(opt, 'target_loss_weight', 1.0)
            edge_weight = getattr(opt, 'edge_loss_weight', 1.5)
            
            loss_weight = torch.ones_like(scattering_mask)
            loss_weight[scattering_mask == 0] = background_weight  # 背景：增加权重以更好约束
            loss_weight[scattering_mask == 1] = target_weight  # 目标：正常权重
            loss_weight[scattering_mask == 2] = edge_weight  # 边缘：高权重
            
            # 归一化权重
            loss_weight = loss_weight / loss_weight.mean()
            
            # 应用权重到损失计算
            Ll1 = (torch.abs(image - gt_image) * loss_weight.unsqueeze(0)).mean()
        else:
            # 标准L1损失
            Ll1 = l1_loss(image, gt_image)
        if FUSED_SSIM_AVAILABLE:
            ssim_value = fused_ssim(image.unsqueeze(0), gt_image.unsqueeze(0))
        else:
            ssim_value = ssim(image, gt_image)

        loss = (1.0 - opt.lambda_dssim) * Ll1 + opt.lambda_dssim * (1.0 - ssim_value)

        # ========== 多视角一致性约束 ==========
        # 🔧 确保不同视角重建同一个3D结构，防止"心形"重建结果
        Lmultiview = 0.0
        sar_mode_enabled = getattr(dataset, 'sar_mode', False)
        
        if (sar_mode_enabled and 
            hasattr(opt, 'sar_multiview_consistency_weight') and 
            opt.sar_multiview_consistency_weight > 0 and
            opt.sar_multiview_consistency_start_iter <= iteration <= opt.sar_multiview_consistency_end_iter):
            
            # 以一定概率采样另一个视角进行一致性约束（避免每次都计算，节省计算资源）
            import random
            if random.random() < getattr(opt, 'sar_multiview_sample_probability', 0.3):
                # 获取所有训练视角
                all_train_cameras = scene.getTrainCameras()
                if len(all_train_cameras) > 1:
                    # 随机选择另一个视角（不同于当前视角）
                    other_viewpoint_idx = random.randint(0, len(all_train_cameras) - 1)
                    # 确保选择的视角不同于当前视角
                    while other_viewpoint_idx == vind and len(all_train_cameras) > 1:
                        other_viewpoint_idx = random.randint(0, len(all_train_cameras) - 1)
                    
                    other_viewpoint_cam = all_train_cameras[other_viewpoint_idx]
                    
                    # 检查另一个视角是否也使用SAR渲染
                    other_use_sar_mode = (sar_mode_enabled and 
                                         getattr(other_viewpoint_cam, 'use_sar_rendering', False) and
                                         ACTIVE_SAR_CONFIG.get('use_sar_rendering', False))
                    
                    # 渲染另一个视角（不计算梯度，只用于一致性检查）
                    with torch.no_grad():
                        other_render_pkg = render(other_viewpoint_cam, gaussians, pipe, bg, 
                                                use_trained_exp=dataset.train_test_exp, 
                                                separate_sh=SPARSE_ADAM_AVAILABLE, 
                                                sar_mode=other_use_sar_mode)
                        other_image = other_render_pkg["render"]
                        other_gt_image = other_viewpoint_cam.original_image.cuda()
                    
                    # 计算两个视角的渲染一致性损失
                    # 方法1：计算两个视角的L1损失（确保渲染结果一致）
                    multiview_l1 = l1_loss(image, other_image.detach())
                    
                    # 方法2：计算当前视角渲染结果与另一个视角GT的一致性
                    # （如果两个视角看到的是同一个目标，它们的渲染应该相似）
                    # 但这个方法可能不太准确，因为SAR不同视角看到的是不同侧面
                    
                    # 方法3：计算3D点投影一致性（更准确）
                    # 获取当前视角的3D点位置
                    xyz = gaussians.get_xyz  # (N, 3)
                    if xyz.shape[0] > 0:
                        # 将3D点投影到另一个视角
                        # 使用另一个视角的投影矩阵
                        other_world_view_transform = other_viewpoint_cam.world_view_transform
                        other_projection_matrix = other_viewpoint_cam.projection_matrix
                        other_full_proj_transform = other_world_view_transform.unsqueeze(0).bmm(other_projection_matrix.unsqueeze(0)).squeeze(0)
                        
                        # 将3D点转换为齐次坐标
                        xyz_homogeneous = torch.cat([xyz, torch.ones(xyz.shape[0], 1, device=xyz.device)], dim=1)  # (N, 4)
                        
                        # 投影到另一个视角的屏幕空间
                        projected_points = other_full_proj_transform @ xyz_homogeneous.T  # (4, N)
                        projected_points = projected_points.T  # (N, 4)
                        
                        # 归一化（透视除法）
                        projected_points_2d = projected_points[:, :2] / (projected_points[:, 3:4] + 1e-8)  # (N, 2)
                        
                        # 检查投影点是否在图像范围内
                        H, W = other_viewpoint_cam.image_height, other_viewpoint_cam.image_width
                        valid_mask = ((projected_points_2d[:, 0] >= 0) & 
                                     (projected_points_2d[:, 0] < W) &
                                     (projected_points_2d[:, 1] >= 0) & 
                                     (projected_points_2d[:, 1] < H) &
                                     (projected_points[:, 3] > 0))  # 深度为正
                        
                        if valid_mask.sum() > 0:
                            # 对于有效的投影点，计算它们在另一个视角下的渲染值
                            # 这里我们使用一个简化的方法：计算投影位置的渲染一致性
                            # 更准确的方法是使用双线性插值从另一个视角的渲染结果中采样
                            import torch.nn.functional as F
                            
                            # 归一化到[-1, 1]范围（用于grid_sample）
                            projected_points_normalized = projected_points_2d[valid_mask]  # (M, 2)
                            projected_points_normalized[:, 0] = 2.0 * projected_points_normalized[:, 0] / W - 1.0
                            projected_points_normalized[:, 1] = 2.0 * projected_points_normalized[:, 1] / H - 1.0
                            
                            # 从另一个视角的渲染结果中采样
                            other_image_sampled = F.grid_sample(
                                other_image.unsqueeze(0),  # (1, C, H, W)
                                projected_points_normalized.unsqueeze(0).unsqueeze(0),  # (1, 1, M, 2)
                                mode='bilinear',
                                padding_mode='border',
                                align_corners=False
                            ).squeeze()  # (C, M)
                            
                            # 从当前视角的渲染结果中采样相同3D点对应的位置
                            # 获取当前视角的3D点投影位置（从render_pkg中获取means2D）
                            # 注意：我们需要获取当前视角的投影位置，而不是viewspace_point_tensor
                            # 使用当前视角的投影矩阵计算3D点的投影位置
                            current_world_view_transform = viewpoint_cam.world_view_transform
                            current_projection_matrix = viewpoint_cam.projection_matrix
                            current_full_proj_transform = current_world_view_transform.unsqueeze(0).bmm(current_projection_matrix.unsqueeze(0)).squeeze(0)
                            
                            # 获取当前视角的3D点投影位置
                            current_projected_points_3d = current_full_proj_transform @ xyz_homogeneous.T  # (4, N)
                            current_projected_points_3d = current_projected_points_3d.T  # (N, 4)
                            current_projected_points_2d = current_projected_points_3d[:, :2] / (current_projected_points_3d[:, 3:4] + 1e-8)  # (N, 2)
                            
                            # 只使用有效投影的点
                            current_projected_points_valid = current_projected_points_2d[valid_mask]  # (M, 2)
                            current_H, current_W = viewpoint_cam.image_height, viewpoint_cam.image_width
                            
                            # 归一化到[-1, 1]范围
                            current_projected_points_normalized = current_projected_points_valid.clone()
                            current_projected_points_normalized[:, 0] = 2.0 * current_projected_points_normalized[:, 0] / current_W - 1.0
                            current_projected_points_normalized[:, 1] = 2.0 * current_projected_points_normalized[:, 1] / current_H - 1.0
                            
                            current_image_sampled = F.grid_sample(
                                image.unsqueeze(0),  # (1, C, H, W)
                                current_projected_points_normalized.unsqueeze(0).unsqueeze(0),  # (1, 1, M, 2)
                                mode='bilinear',
                                padding_mode='border',
                                align_corners=False
                            ).squeeze()  # (C, M)
                            
                            # 计算一致性损失（两个视角在相同3D点位置的渲染应该相似）
                            multiview_consistency = torch.abs(current_image_sampled - other_image_sampled.detach()).mean()
                            
                            # 结合方法1和方法3
                            Lmultiview = opt.sar_multiview_consistency_weight * (multiview_l1 + 0.5 * multiview_consistency)
                            loss += Lmultiview
                            
                            # 每1000次迭代打印一次调试信息
                            if iteration % 1000 == 0:
                                current_view_name = getattr(viewpoint_cam, 'image_name', f'view_{vind}')
                                other_view_name = getattr(other_viewpoint_cam, 'image_name', f'view_{other_viewpoint_idx}')
                                print(f"[ITER {iteration}] 多视角一致性约束: "
                                      f"视角1={current_view_name}, 视角2={other_view_name}, "
                                      f"有效投影点数={valid_mask.sum().item()}, "
                                      f"一致性损失={Lmultiview.item():.5f}")
                        else:
                            # 如果没有有效的投影点，使用方法1（渲染一致性）
                            Lmultiview = opt.sar_multiview_consistency_weight * multiview_l1
                            loss += Lmultiview
                            
                            if iteration % 1000 == 0:
                                current_view_name = getattr(viewpoint_cam, 'image_name', f'view_{vind}')
                                other_view_name = getattr(other_viewpoint_cam, 'image_name', f'view_{other_viewpoint_idx}')
                                print(f"[ITER {iteration}] 多视角一致性约束（无有效投影点）: "
                                      f"视角1={current_view_name}, 视角2={other_view_name}, "
                                      f"渲染一致性损失={Lmultiview.item():.5f}")

        # 🔧 统一获取高斯参数（避免重复计算）
        xyz = gaussians.get_xyz  # (N, 3)
        scales = gaussians.get_scaling  # (N, 3)
        opacities = gaussians.get_opacity  # (N, 1)

        # Depth regularization
        Ll1depth_pure = 0.0
        if depth_l1_weight(iteration) > 0 and viewpoint_cam.depth_reliable:
            invDepth = render_pkg["depth"]
            mono_invdepth = viewpoint_cam.invdepthmap.cuda()
            depth_mask = viewpoint_cam.depth_mask.cuda()

            Ll1depth_pure = torch.abs((invDepth  - mono_invdepth) * depth_mask).mean()
            Ll1depth = depth_l1_weight(iteration) * Ll1depth_pure
            loss += Ll1depth
            Ll1depth = Ll1depth.item()
        else:
            Ll1depth = 0

        # 🔧 整体点云尺度约束（已禁用）
        # ⚠️ 注意：SAR图像在不同方位角下拍摄的是同一个目标，但拍摄的地面范围不同
        # 因此，基于SAR图像覆盖范围的整体约束是不合理的，已禁用
        # 只保留目标尺寸约束（基于目标检测的长宽）和高度约束（基于H/L比例）
        Lscale = torch.tensor(0.0, device=xyz.device) if xyz.shape[0] > 0 else 0.0
        
        # 🔧 目标尺寸约束（基于目标检测的长宽，不依赖SAR图像覆盖范围）
        if scale_constraint_params is not None and xyz.shape[0] > 0:
            # 获取约束参数
            target_length_meters = scale_constraint_params.get('target_length_meters')
            target_width_meters = scale_constraint_params.get('target_width_meters')
            
            # 只有当目标尺寸信息可用时才应用约束
            if target_length_meters is not None and target_width_meters is not None:
                # 计算当前点云在XZ平面上的范围（长宽方向）
                x_coords = xyz[:, 0]  # X坐标
                z_coords = xyz[:, 2]  # Z坐标
                
                x_range = x_coords.max() - x_coords.min()
                z_range = z_coords.max() - z_coords.min()
                
                # 确定哪个方向是长度，哪个是宽度（较大的为长度，较小的为宽度）
                current_length = max(x_range.item(), z_range.item())
                current_width = min(x_range.item(), z_range.item())
                
                # 约束权重（从opt读取，如果没有则使用默认值）
                scale_constraint_weight = getattr(opt, 'sar_scale_constraint_weight', 1.0)
                scale_constraint_start_iter = getattr(opt, 'sar_scale_constraint_start_iter', 0)
                scale_constraint_end_iter = getattr(opt, 'sar_scale_constraint_end_iter', opt.iterations)
                scale_constraint_tolerance = getattr(opt, 'sar_scale_constraint_tolerance', 0.1)  # 默认10%容差
                
                # 只在指定迭代范围内应用约束
                if (scale_constraint_weight > 0 and 
                    scale_constraint_start_iter <= iteration <= scale_constraint_end_iter):
                    
                    # 🔧 计算当前点云相对于目标尺寸的偏差（不依赖SAR图像覆盖范围）
                    length_deviation_ratio = abs(current_length - target_length_meters) / (target_length_meters + 1e-6)
                    width_deviation_ratio = abs(current_width - target_width_meters) / (target_width_meters + 1e-6)
                    
                    # 如果偏差超过容差，应用约束
                    if length_deviation_ratio > scale_constraint_tolerance:
                        Lscale += scale_constraint_weight * length_deviation_ratio
                    
                    if width_deviation_ratio > scale_constraint_tolerance:
                        Lscale += scale_constraint_weight * width_deviation_ratio
                    
                    if Lscale > 0:
                        loss += Lscale
                        
                        # 打印信息（限制频率）
                        if iteration % 100 == 0 or iteration <= 10:
                            print(f"[ITER {iteration}] 🎯 目标尺寸约束（基于目标检测）:")
                            print(f"  当前范围: {current_length:.2f}m × {current_width:.2f}m")
                            print(f"  目标尺寸: {target_length_meters:.2f}m × {target_width_meters:.2f}m")
                            print(f"  长度偏差: {length_deviation_ratio*100:.1f}%, 宽度偏差: {width_deviation_ratio*100:.1f}%")
                            print(f"  约束损失: {Lscale.item():.6f}")
                            print(f"  ✅ 约束已生效（不依赖SAR图像覆盖范围）")

        # SAR形状约束（防止点云塌陷成圆饼状，同时防止内陷）
        # 🔧 修复：只针对目标点云，不包括背景，避免背景边缘向上弯折
        Lshape = 0.0
        if (hasattr(opt, 'sar_shape_constraint_weight') and
            opt.sar_shape_constraint_weight > 0 and
            opt.sar_shape_constraint_start_iter <= iteration <= opt.sar_shape_constraint_end_iter):
            # 🔧 获取目标点云（基于亮度分类，与地面约束一致）
            if xyz.shape[0] > 0:
                from utils.sh_utils import SH2RGB
                f_dc = gaussians._features_dc.detach()  # (N, 1, 3)
                f_dc_reshaped = f_dc.reshape(-1, 3)  # (N, 3)
                rgb_colors = SH2RGB(f_dc_reshaped)  # (N, 3)
                rgb_colors = torch.clamp(rgb_colors, 0.0, 1.0)
                brightness = 0.299 * rgb_colors[:, 0] + 0.587 * rgb_colors[:, 1] + 0.114 * rgb_colors[:, 2]
                brightness_threshold = torch.quantile(brightness, 0.85)  # 85%分位数作为目标阈值
                target_mask_for_shape = brightness >= brightness_threshold
                
                # 只对目标点云应用形状约束
                if target_mask_for_shape.sum() > 0:
                    target_xyz = xyz[target_mask_for_shape]
                    target_y_coords = target_xyz[:, 1]  # Y坐标（高度方向）
                    target_x_coords = target_xyz[:, 0]
                    target_z_coords = target_xyz[:, 2]
                    
                    target_y_mean = target_y_coords.mean()
                    target_y_var = ((target_y_coords - target_y_mean) ** 2).mean()
                    
                    # 🔧 检查目标点云是否内陷（只针对目标，不包括背景）
                    target_center_x = target_x_coords.mean()
                    target_center_z = target_z_coords.mean()
                    
                    # 计算每个目标点到目标中心的距离
                    dist_to_target_center = torch.sqrt((target_x_coords - target_center_x) ** 2 + (target_z_coords - target_center_z) ** 2)
                    max_target_dist = dist_to_target_center.max()
                    
                    # 将目标点云分为中心和边缘区域
                    if max_target_dist > 1e-6:
                        target_center_mask = dist_to_target_center < (max_target_dist * 0.3)  # 中心30%区域
                        target_edge_mask = dist_to_target_center > (max_target_dist * 0.7)     # 边缘30%区域
                        
                        if target_center_mask.sum() > 0 and target_edge_mask.sum() > 0:
                            target_center_y_mean = target_y_coords[target_center_mask].mean()
                            target_edge_y_mean = target_y_coords[target_edge_mask].mean()
                            
                            # 🔧 防止内陷：如果中心高度低于边缘高度，说明目标内陷了
                            # 在COLMAP坐标系中，Y值越大越接近地面，所以如果center_y_mean > edge_y_mean，说明中心更接近地面（内陷）
                            if target_center_y_mean > target_edge_y_mean:
                                # 惩罚内陷：鼓励中心点在地面上方（Y值较小）
                                depression_amount = target_center_y_mean - target_edge_y_mean
                                Lshape += opt.sar_shape_constraint_weight * 5.0 * depression_amount  # 大幅惩罚内陷

                    # 形状约束：鼓励高度方向的方差（防止塌陷成2D圆饼）
                    # 如果方差太小，说明目标在Y方向塌陷了，需要惩罚
                    min_y_var = 0.1  # 最小方差阈值
                    if target_y_var < min_y_var:
                        Lshape += opt.sar_shape_constraint_weight * (min_y_var - target_y_var)
                
                if Lshape > 0:
                    loss += Lshape

        # 🎯 目标尺寸约束已移除 - 改为训练后直接压缩以提升性能
        # 🎯 性能优化：降低尺寸约束计算频率，避免每个迭代都进行耗时的几何过滤

        # === 增强的地面约束 ===
        Lground = 0.0

        # 地面约束：防止背景点云形成球状分布
        if (hasattr(opt, 'sar_ground_constraint_weight') and
            opt.sar_ground_constraint_weight > 0 and
            hasattr(opt, 'sar_ground_constraint_start_iter') and
            hasattr(opt, 'sar_ground_constraint_end_iter') and
            opt.sar_ground_constraint_start_iter <= iteration <= opt.sar_ground_constraint_end_iter):

            # 获取当前图像的散射强度掩码
            scattering_mask = None
            if hasattr(args, 'scattering_masks') and args.scattering_masks is not None:
                image_name = getattr(viewpoint_cam, 'image_name', None)
                if image_name and image_name in args.scattering_masks:
                    scattering_mask = args.scattering_masks[image_name]

            if scattering_mask is not None and xyz.shape[0] > 0:
                # 将掩码转换为tensor
                scattering_mask_tensor = torch.from_numpy(scattering_mask).cuda().float()
                # 确保掩码大小与图像匹配
                H, W = viewpoint_cam.image_height, viewpoint_cam.image_width
                if scattering_mask_tensor.shape != (H, W):
                    scattering_mask_tensor = torch.nn.functional.interpolate(
                        scattering_mask_tensor.unsqueeze(0).unsqueeze(0),
                        size=(H, W), mode='nearest'
                    ).squeeze()

                # 背景掩码：散射强度较低的区域
                background_threshold = getattr(opt, 'sar_background_brightness_threshold', 0.2)
                background_mask = scattering_mask_tensor < background_threshold

                # 目标掩码：散射强度较高的区域
                target_mask = scattering_mask_tensor >= background_threshold

                # === 正确区分目标和背景点云 ===
                # 注意：散射强度掩码是2D图像，但我们需要将其映射到3D点云
                # 这里使用简化的方法：假设高亮度区域对应目标点云

                # 获取所有点的Y坐标（高度方向）
                # ⚠️ COLMAP坐标系：Y轴向下，Y值增大=向下靠近地面，Y值减小=向上远离地面
                all_y_coords = xyz[:, 1]  # 所有点的Y坐标
                
                # 🔧 改进：基于亮度进行更精确的目标/背景分类
                # 获取高斯点的DC分量（平均颜色）来计算亮度
                from utils.sh_utils import SH2RGB
                f_dc = gaussians._features_dc.detach()  # (N, 1, 3)
                f_dc_reshaped = f_dc.reshape(-1, 3)  # (N, 3)
                rgb_colors = SH2RGB(f_dc_reshaped)  # (N, 3)
                rgb_colors = torch.clamp(rgb_colors, 0.0, 1.0)
                # 计算亮度：0.299*R + 0.587*G + 0.114*B
                brightness = 0.299 * rgb_colors[:, 0] + 0.587 * rgb_colors[:, 1] + 0.114 * rgb_colors[:, 2]
                
                # 🔧 使用亮度阈值来区分目标和背景点
                brightness_threshold = torch.quantile(brightness, 0.85)  # 85%分位数作为目标阈值
                target_brightness_mask = brightness >= brightness_threshold
                background_brightness_mask = brightness < brightness_threshold

                # 🔧 改进：使用背景点的Y坐标计算地面高度，而不是所有点
                # 这样可以避免目标点影响地面高度计算
                # 先基于亮度初步分类背景点
                brightness_threshold_preliminary = torch.quantile(brightness, 0.70)  # 70%分位数作为初步阈值
                background_preliminary_mask = brightness < brightness_threshold_preliminary
                
                if background_preliminary_mask.sum() > 10:  # 确保有足够的背景点
                    background_y_preliminary = all_y_coords[background_preliminary_mask]
                    ground_height = torch.quantile(background_y_preliminary, 0.75)  # 75%分位数作为地面
                else:
                    # 如果背景点太少，使用所有点的75%分位数
                    ground_height = torch.quantile(all_y_coords, 0.75)  # 75%分位数作为地面

                # 计算点云的高度范围
                y_min = torch.min(all_y_coords)
                y_max = torch.max(all_y_coords)
                y_range = y_max - y_min

                # 动态调整分类阈值：基于点云的实际分布
                if y_range > 5.0:  # 如果点云高度范围很大，使用相对阈值
                    target_height_threshold = ground_height - min(2.0, y_range * 0.3)
                else:  # 如果点云高度范围正常，使用固定阈值
                    target_height_threshold = ground_height - 1.0

                # 确保阈值不会低于点云的最小值太多
                target_height_threshold = max(target_height_threshold, y_min + 0.1)

                # 🔧 改进的目标/背景分类：结合亮度和高度信息
                # 目标：高亮度 + 在地面上方（Y值相对较小）
                # 背景：低亮度 + 在地面附近（Y值相对较大）
                # 混合点：高亮度但在地面附近，或低亮度但在地面上方 -> 根据主要特征分类
                
                # 基于高度的初步分类
                height_target_mask = all_y_coords < target_height_threshold
                height_background_mask = all_y_coords >= target_height_threshold
                
                # 🔧 结合亮度和高度进行综合分类
                # 目标点：高亮度且在地面上方，或中等亮度但明显在地面上方
                target_points_mask = (target_brightness_mask & height_target_mask) | \
                                    (brightness >= torch.quantile(brightness, 0.70)) & (all_y_coords < target_height_threshold - 0.5)
                
                # 背景点：低亮度且在地面附近，或中等亮度但明显在地面附近
                background_points_mask = (background_brightness_mask & height_background_mask) | \
                                        (brightness < torch.quantile(brightness, 0.70)) & (all_y_coords >= target_height_threshold - 0.5)
                
                # 🔧 确保每个点都被分类（避免遗漏）
                unclassified_mask = ~(target_points_mask | background_points_mask)
                if unclassified_mask.sum() > 0:
                    # 未分类的点根据亮度主要特征分类
                    unclassified_brightness = brightness[unclassified_mask]
                    unclassified_y = all_y_coords[unclassified_mask]
                    # 如果亮度较高，倾向于分类为目标；否则为背景
                    unclassified_target = unclassified_brightness >= brightness_threshold
                    target_points_mask[unclassified_mask] = unclassified_target
                    background_points_mask[unclassified_mask] = ~unclassified_target

                # 额外保护：如果分类结果不合理，进行修正
                target_ratio = target_points_mask.sum().float() / len(all_y_coords)
                background_ratio = background_points_mask.sum().float() / len(all_y_coords)

                # 调试信息
                if iteration % 1000 == 0:
                    print(f"[DEBUG] 地面分类 - 总点数:{len(all_y_coords)}, 地面高度:{ground_height.item():.3f}, 阈值:{target_height_threshold:.3f}")
                    print(f"[DEBUG] 地面分类 - 目标点:{target_points_mask.sum().item()}({target_ratio:.1%}), 背景点:{background_points_mask.sum().item()}({background_ratio:.1%})")
                    print(f"[DEBUG] Y范围: [{torch.min(all_y_coords).item():.3f}, {torch.max(all_y_coords).item():.3f}]")

                if target_ratio < 0.1:  # 目标点太少，使用中位数重新分类
                    median_height = torch.median(all_y_coords)
                    target_points_mask = all_y_coords < median_height
                    background_points_mask = all_y_coords >= median_height
                    if iteration % 1000 == 0:
                        print(f"[DEBUG] 重新分类: 使用中位数 {median_height.item():.3f}")
                elif target_ratio > 0.9:  # 目标点太多，使用25%分位数重新分类
                    target_height_threshold = torch.quantile(all_y_coords, 0.25)
                    target_points_mask = all_y_coords < target_height_threshold
                    background_points_mask = all_y_coords >= target_height_threshold
                    if iteration % 1000 == 0:
                        print(f"[DEBUG] 重新分类: 使用25%分位数 {target_height_threshold:.3f}")

                # 获取目标和背景点云的Y坐标
                target_y = all_y_coords[target_points_mask] if target_points_mask.sum() > 0 else torch.tensor([], device=xyz.device)
                background_y = all_y_coords[background_points_mask] if background_points_mask.sum() > 0 else torch.tensor([], device=xyz.device)

                # 地面高度容差
                height_tolerance = getattr(opt, 'sar_ground_height_tolerance', 0.2)

                # 1. 地面约束：确保背景点云贴近地面（平面约束，防止球状分布）
                # 🔧 修复：对所有背景点都应用约束，无论位置，防止范围外形成弧面
                Lground_basic = torch.tensor(0.0, device=xyz.device)
                if background_points_mask.sum() > 0:
                    # 获取背景点的XZ坐标，用于距离加权
                    background_x_coords = xyz[background_points_mask, 0]
                    background_z_coords = xyz[background_points_mask, 2]
                    
                    # 计算背景点到原点的距离（用于距离加权）
                    background_dist_to_origin = torch.sqrt(background_x_coords ** 2 + background_z_coords ** 2)
                    
                    # 🔧 改进：使用距离加权，确保远距离的背景点也受到强约束
                    # 远距离的点更容易形成弧面，需要更强的约束
                    # 权重：距离越远，权重越大（最大权重=2.0，最小权重=1.0）
                    max_background_dist = background_dist_to_origin.max() if background_dist_to_origin.numel() > 0 else 1.0
                    if max_background_dist > 1e-6:
                        # 归一化距离到[0, 1]，然后映射到权重[1.0, 2.0]
                        normalized_dist = background_dist_to_origin / max_background_dist
                        distance_weights = 1.0 + normalized_dist  # 权重范围[1.0, 2.0]
                    else:
                        distance_weights = torch.ones_like(background_dist_to_origin)
                    
                    # 🔧 新增：方向加权 - 对x和z正方向的背景点施加更强的约束
                    # 因为这些方向的弧面更多，需要更强的约束来防止弯折
                    # 计算每个背景点的方向（相对于原点）
                    background_angles = torch.atan2(background_z_coords, background_x_coords)  # 方位角
                    
                    # x和z正方向（0-90度）的权重更大
                    # 权重：x和z正方向=2.0，其他方向=1.0
                    angle_weights = torch.ones_like(background_angles)
                    # x正方向（-22.5°到22.5°）和z正方向（67.5°到112.5°）
                    pi_over_8 = torch.tensor(np.pi / 8.0, device=background_angles.device)
                    pi_3_over_8 = torch.tensor(3.0 * np.pi / 8.0, device=background_angles.device)
                    pi_5_over_8 = torch.tensor(5.0 * np.pi / 8.0, device=background_angles.device)
                    x_positive_mask = (background_angles >= -pi_over_8) & (background_angles <= pi_over_8)
                    z_positive_mask = (background_angles >= pi_3_over_8) & (background_angles <= pi_5_over_8)
                    angle_weights[x_positive_mask] = 2.0
                    angle_weights[z_positive_mask] = 2.0
                    
                    # 组合距离权重和方向权重
                    combined_weights = distance_weights * angle_weights
                    
                    # 计算背景点云到地面的距离
                    # 在COLMAP坐标系中，Y值越大越接近地面
                    background_to_ground_dist = ground_height - background_y  # 正值表示在地面上方

                    # 惩罚背景点云偏离地面的情况（应该在地面附近）
                    # 🔧 使用距离和方向加权，远距离和x/z正方向的点受到更强的约束
                    excess_ground_dist = torch.clamp(background_to_ground_dist - height_tolerance, min=0.0)
                    weighted_excess = excess_ground_dist * combined_weights
                    Lground_basic = opt.sar_ground_constraint_weight * weighted_excess.mean()
                    
                    # 🔧 改进：平面约束 - 对所有背景点都应用，无论位置
                    # SAR图像中背景应该是平面，不应该有高度方向的分散
                    # 使用距离和方向加权，确保远距离和x/z正方向的背景点也形成平面
                    background_y_var_per_point = (background_y - ground_height) ** 2
                    weighted_y_var = (background_y_var_per_point * combined_weights).mean()
                    max_ground_var = height_tolerance ** 2  # 允许的最大方差（基于容差）
                    if weighted_y_var > max_ground_var:
                        # 惩罚过大的高度方差，强制背景点云形成平面
                        # 远距离的点受到更强的约束
                        plane_penalty = opt.sar_ground_constraint_weight * 2.0 * (weighted_y_var - max_ground_var)
                        Lground_basic += plane_penalty

                # 2. 目标位置约束：确保目标在地面上方合理位置
                Lground_target = torch.tensor(0.0, device=xyz.device)
                if target_points_mask.sum() > 0:
                    target_max_y = torch.max(target_y)  # 目标的最低点（Y值最大）

                    # 确保目标在地面上方合理位置
                    target_to_ground_dist = ground_height - target_max_y  # 目标顶部到地面的距离
                    if target_to_ground_dist < 0.5:  # 目标离地面太近
                        Lground_target = opt.sar_ground_constraint_weight * 3.0 * (0.5 - target_to_ground_dist)

                # 3. 防止背景点云侵入目标区域
                Lground_intrusion = torch.tensor(0.0, device=xyz.device)
                if target_points_mask.sum() > 0 and background_points_mask.sum() > 0:
                    target_max_y = torch.max(target_y)  # 目标的最低点（Y值最大）

                    # 惩罚背景点云进入目标区域下方
                    background_in_target_zone = background_y < (target_max_y + height_tolerance)
                    if background_in_target_zone.sum() > 0:
                        intrusion_amount = (target_max_y + height_tolerance) - background_y[background_in_target_zone]
                        Lground_intrusion = opt.sar_ground_constraint_weight * 5.0 * intrusion_amount.mean()

                Lground = Lground_basic + Lground_target + Lground_intrusion
                loss += Lground

                # 调试信息
                if iteration % 1000 == 0:
                    target_count = target_points_mask.sum().item() if target_points_mask.sum() > 0 else 0
                    background_count = background_points_mask.sum().item() if background_points_mask.sum() > 0 else 0
                    print(f"[ITER {iteration}] 地面约束: "
                          f"地面高度(Y)={ground_height.item():.3f}, 容差={height_tolerance:.3f}, "
                          f"点数=[目标={target_count}, 背景={background_count}], "
                          f"损失=[背景={Lground_basic.item() if hasattr(Lground_basic, 'item') else Lground_basic:.5f}, "
                          f"目标={Lground_target.item() if hasattr(Lground_target, 'item') else Lground_target:.5f}, "
                          f"侵入={Lground_intrusion.item() if hasattr(Lground_intrusion, 'item') else Lground_intrusion:.5f}], "
                          f"总权重={opt.sar_ground_constraint_weight}")

        # 🔧 目标高度约束：基于SFM目标检测和阴影计算的H/L比例
        # 约束顺序：1. 目标尺寸约束（长宽，基于目标检测） 2. 目标高度约束（高度，基于H/L比例）
        Lheight = torch.tensor(0.0, device=xyz.device) if xyz.shape[0] > 0 else 0.0
        
        if scale_constraint_params is not None and xyz.shape[0] > 0:
            height_length_ratio = scale_constraint_params.get('height_length_ratio')
            target_length_meters = scale_constraint_params.get('target_length_meters')
            target_height_meters = scale_constraint_params.get('target_height_meters')
            
            # 🔧 检查约束参数是否完整
            if height_length_ratio is not None and target_length_meters is not None and target_height_meters is not None:
                # 获取约束权重和迭代范围
                height_constraint_weight = getattr(opt, 'sar_height_constraint_weight', 1.0)
                height_constraint_start_iter = getattr(opt, 'sar_height_constraint_start_iter', 0)
                height_constraint_end_iter = getattr(opt, 'sar_height_constraint_end_iter', opt.iterations)
                
                # 只在指定迭代范围内应用约束
                if (height_constraint_weight > 0 and 
                    height_constraint_start_iter <= iteration <= height_constraint_end_iter):
                    
                    # 🔧 基于亮度进行目标点分类
                    from utils.sh_utils import SH2RGB
                    f_dc = gaussians._features_dc.detach()  # (N, 1, 3)
                    f_dc_reshaped = f_dc.reshape(-1, 3)  # (N, 3)
                    rgb_colors = SH2RGB(f_dc_reshaped)  # (N, 3)
                    rgb_colors = torch.clamp(rgb_colors, 0.0, 1.0)
                    brightness = 0.299 * rgb_colors[:, 0] + 0.587 * rgb_colors[:, 1] + 0.114 * rgb_colors[:, 2]
                    
                    # 使用85%分位数作为目标点阈值
                    brightness_threshold = torch.quantile(brightness, 0.85)
                    target_mask = brightness >= brightness_threshold
                    
                    if target_mask.sum() > 0:
                        # 获取目标点的Y坐标（高度方向）
                        target_y_coords = xyz[target_mask, 1]  # Y坐标
                        
                        # 计算目标点云的高度范围
                        target_y_min = torch.min(target_y_coords)
                        target_y_max = torch.max(target_y_coords)
                        target_y_range = target_y_max - target_y_min  # 当前高度范围
                        
                        # 🔧 计算当前目标点云的长度（XZ平面）
                        target_x_coords = xyz[target_mask, 0]
                        target_z_coords = xyz[target_mask, 2]
                        target_x_range = target_x_coords.max() - target_x_coords.min()
                        target_z_range = target_z_coords.max() - target_z_coords.min()
                        current_target_length = max(target_x_range.item(), target_z_range.item())
                        
                        # 🔧 计算当前高度/长度比例
                        current_h_l_ratio = target_y_range.item() / (current_target_length + 1e-6)
                        
                        # 🔧 计算目标高度（基于当前长度和H/L比例）
                        target_height_based_on_current_length = current_target_length * height_length_ratio
                        
                        # 🔧 高度约束：鼓励目标点云的高度接近目标高度
                        height_deviation = abs(target_y_range.item() - target_height_based_on_current_length)
                        height_deviation_ratio = height_deviation / (target_height_based_on_current_length + 1e-6)
                        
                        # 🔧 如果偏差超过10%，应用约束
                        if height_deviation_ratio > 0.1:
                            Lheight = height_constraint_weight * height_deviation_ratio
                            loss += Lheight
                            
                            # 🔧 打印约束信息（限制频率）
                            if iteration % 100 == 0 or iteration <= 10:
                                print(f"[ITER {iteration}] 🎯 目标高度约束:")
                                print(f"  当前目标长度: {current_target_length:.4f}m")
                                print(f"  当前目标高度范围: {target_y_range.item():.4f}m")
                                print(f"  当前H/L比例: {current_h_l_ratio:.4f}")
                                print(f"  目标H/L比例: {height_length_ratio:.4f}")
                                print(f"  目标高度（基于当前长度）: {target_height_based_on_current_length:.4f}m")
                                print(f"  高度偏差: {height_deviation:.4f}m ({height_deviation_ratio*100:.1f}%)")
                                print(f"  约束损失: {Lheight.item() if isinstance(Lheight, torch.Tensor) else Lheight:.6f}")
                                print(f"  ✅ 约束已生效（顺序：1.目标尺寸约束 2.目标高度约束）")

        loss.backward()

        iter_end.record()

        with torch.no_grad():
            # Progress bar
            ema_loss_for_log = 0.4 * loss.item() + 0.6 * ema_loss_for_log
            ema_Ll1depth_for_log = 0.4 * Ll1depth + 0.6 * ema_Ll1depth_for_log
            ema_Lshape_for_log = 0.4 * Lshape + 0.6 * ema_Lshape_for_log
            ema_Lscale_for_log = 0.4 * Lscale.item() if isinstance(Lscale, torch.Tensor) else 0.4 * Lscale + 0.6 * ema_Lscale_for_log
            ema_Lheight_for_log = 0.4 * Lheight.item() if isinstance(Lheight, torch.Tensor) else 0.4 * Lheight + 0.6 * ema_Lheight_for_log
            ema_Lmultiview_for_log = 0.4 * Lmultiview + 0.6 * ema_Lmultiview_for_log

            if iteration % 10 == 0:
                postfix_dict = {"Loss": f"{ema_loss_for_log:.{7}f}", "Depth Loss": f"{ema_Ll1depth_for_log:.{7}f}"}
                if Lshape > 0:
                    postfix_dict["Shape"] = f"{ema_Lshape_for_log:.{5}f}"
                if Lscale > 0:
                    postfix_dict["Scale"] = f"{ema_Lscale_for_log:.{5}f}"
                if Lheight > 0:
                    postfix_dict["Height"] = f"{ema_Lheight_for_log:.{5}f}"
                if Lmultiview > 0:
                    postfix_dict["MultiView"] = f"{ema_Lmultiview_for_log:.{5}f}"
                progress_bar.set_postfix(postfix_dict)
                progress_bar.update(10)
            if iteration == opt.iterations:
                progress_bar.close()

            # Log and save
            training_report(tb_writer, iteration, Ll1, loss, l1_loss, iter_start.elapsed_time(iter_end), testing_iterations, scene, render, (pipe, background, 1., SPARSE_ADAM_AVAILABLE, None, dataset.train_test_exp), dataset.train_test_exp, Lscale=Lscale, Lheight=Lheight)
            if (iteration in saving_iterations):
                print("\n[ITER {}] Saving Gaussians".format(iteration))
                scene.save(iteration, save_target_cloud=False)  # 训练过程中不保存目标点云，提升性能

                # 🎯 训练完成后自动执行高度压缩（只对目标点云文件）
                if iteration == opt.iterations and target_constraints is not None:
                    try:
                        print("\n" + "="*78)
                        print("🎯 自动执行目标几何压缩...")
                        print("="*78)

                        # 先保存目标点云，然后对其进行压缩
                        print("   📝 先保存目标点云...")
                        scene.save(iteration, save_target_cloud=True)  # 保存目标点云

                        # 导入压缩脚本
                        import subprocess
                        import sys

                        # 构建压缩命令 - 现在只压缩point_cloud_target_only.ply
                        compress_script = os.path.join(os.path.dirname(__file__), 'compress_target_height.py')
                        model_path = scene.model_path
                        target_h_l = target_constraints.get('height_length_ratio', 0.3460)

                        cmd = [
                            sys.executable,
                            compress_script,
                            '--model_path', model_path,
                            '--target_h_l_ratio', str(target_h_l),
                            '--iteration', str(iteration),
                            '--target_only'  # 新参数：只压缩目标点云
                        ]

                        # 宽度压缩已禁用，只进行高度压缩

                        print(f"执行命令: {' '.join(cmd)}")

                        # 执行压缩（设置UTF-8环境避免编码问题）
                        env = os.environ.copy()
                        env['PYTHONIOENCODING'] = 'utf-8'
                        result = subprocess.run(cmd, capture_output=True, text=False, env=env)

                        # 解码输出（处理编码问题）
                        def decode_output(data):
                            if data is None:
                                return ""
                            try:
                                return data.decode('utf-8')
                            except UnicodeDecodeError:
                                try:
                                    return data.decode('gbk')  # Windows中文编码
                                except UnicodeDecodeError:
                                    return data.decode('utf-8', errors='replace')  # 最后的后备方案

                        stdout_text = decode_output(result.stdout)
                        stderr_text = decode_output(result.stderr)

                        # 显示压缩结果
                        if result.returncode == 0:
                            print("\n[SUCCESS] 几何压缩执行成功!")
                            print("压缩输出:")
                            print(stdout_text)

                            # 🎯 压缩成功后，显示最终训练成果播报
                            print("\n" + "="*78)
                            print("最后播报：Gaussian Splatting训练最终成果")
                            print("="*78)

                            # ========== 使用压缩后的目标点云重新计算最终尺寸 ==========
                            compressed_ply_path = os.path.join(model_path, 'point_cloud', f'iteration_{iteration}', 'point_cloud_target_only_compressed.ply')

                            if os.path.exists(compressed_ply_path):
                                try:
                                    # 读取压缩后的PLY文件来计算最终尺寸
                                    from plyfile import PlyData
                                    compressed_plydata = PlyData.read(compressed_ply_path)
                                    compressed_vertices = compressed_plydata['vertex']

                                    # 获取坐标
                                    if hasattr(compressed_vertices, 'data'):
                                        compressed_xyz = np.column_stack([
                                            compressed_vertices.data['x'],
                                            compressed_vertices.data['y'],
                                            compressed_vertices.data['z']
                                        ])
                                    else:
                                        compressed_xyz = np.column_stack([
                                            compressed_vertices['x'],
                                            compressed_vertices['y'],
                                            compressed_vertices['z']
                                        ])

                                    # 计算边界框
                                    compressed_min = compressed_xyz.min(axis=0)
                                    compressed_max = compressed_xyz.max(axis=0)
                                    compressed_bbox_size = compressed_max - compressed_min

                                    # 与SFM一致：基于XOZ面的几何形状确定长度和宽度
                                    compressed_x_size = compressed_bbox_size[0]
                                    compressed_z_size = compressed_bbox_size[2]
                                    compressed_height = compressed_bbox_size[1]

                                    if compressed_x_size >= compressed_z_size:
                                        compressed_length = compressed_x_size
                                        compressed_width = compressed_z_size
                                        compressed_orientation = "X-长度，Z-宽度"
                                    else:
                                        compressed_length = compressed_z_size
                                        compressed_width = compressed_x_size
                                        compressed_orientation = "Z-长度，X-宽度"

                                    # 计算比例
                                    eps = 1e-8
                                    compressed_h_l_ratio = abs(compressed_height) / (compressed_length + eps)
                                    compressed_point_count = len(compressed_xyz)

                                    # 获取约束目标值
                                    target_h_l = target_constraints.get('height_length_ratio', 0.4577)

                                    print("🎯 核心指标 - 高度/长度比例 (H/L): {:.4f}".format(compressed_h_l_ratio))
                                    print("🎯 SFM约束目标值 (H/L): {:.4f}".format(target_h_l))
                                    print("🎯 约束匹配度: {:.1%}".format(1.0 - min(abs(compressed_h_l_ratio - target_h_l) / target_h_l, 1.0)))
                                    print()
                                    print("📈 完整尺寸成果:")
                                    print("   目标尺寸: 高度={:.3f}, 长度={:.3f}, 宽度={:.3f}".format(abs(compressed_height), compressed_length, compressed_width))
                                    print("   几何方向: {}".format(compressed_orientation))
                                    print("   最终点数: {:,} 个".format(compressed_point_count))

                                except Exception as e:
                                    print(f"⚠️ 读取压缩后PLY文件失败: {e}")
                                    print("将使用完整点云计算尺寸...")
                                    # 回退到使用完整点云
                                    final_xyz = gaussians.get_xyz
                                    if final_xyz.shape[0] > 0:
                                        final_min = final_xyz.min(dim=0)[0]
                                        final_max = final_xyz.max(dim=0)[0]
                                        final_bbox_size = final_max - final_min
                                        final_point_count = final_xyz.shape[0]

                                        xoz_size_x = final_bbox_size[0].item()
                                        xoz_size_z = final_bbox_size[2].item()
                                        final_height = final_bbox_size[1].item()

                                        if xoz_size_x >= xoz_size_z:
                                            final_length = xoz_size_x
                                            final_width = xoz_size_z
                                            final_orientation = "X-长度，Z-宽度"
                                        else:
                                            final_length = xoz_size_z
                                            final_width = xoz_size_x
                                            final_orientation = "Z-长度，X-宽度"

                                        eps = 1e-8
                                        final_h_l_ratio = abs(final_height) / (final_length + eps)
                                        target_h_l = target_constraints.get('height_length_ratio', 0.4577)

                                        print("🎯 核心指标 - 高度/长度比例 (H/L): {:.4f}".format(final_h_l_ratio))
                                        print("🎯 SFM约束目标值 (H/L): {:.4f}".format(target_h_l))
                                        print("🎯 约束匹配度: {:.1%}".format(1.0 - min(abs(final_h_l_ratio - target_h_l) / target_h_l, 1.0)))
                                        print()
                                        print("📈 完整尺寸成果:")
                                        print("   目标尺寸: 高度={:.3f}, 长度={:.3f}, 宽度={:.3f}".format(abs(final_height), final_length, final_width))
                                        print("   几何方向: {}".format(final_orientation))
                                        print("   最终点数: {:,} 个".format(final_point_count))
                            else:
                                print(f"⚠️ 压缩后的PLY文件不存在: {compressed_ply_path}")
                                print("将使用完整点云计算尺寸...")

                            print("="*78 + "🎤")

                        else:
                            print("\n[FAILED] 几何压缩执行失败!")
                            print("错误信息:")
                            if stderr_text.strip():
                                print(stderr_text)
                            else:
                                print("(无详细错误信息)")
                            print("标准输出:")
                            if stdout_text.strip():
                                print(stdout_text)
                            else:
                                print("(无输出信息)")

                        print("="*78)

                    except Exception as e:
                        print(f"⚠️ 自动几何压缩失败: {e}")
                        print(f"请手动运行: python compress_target_height.py --model_path {scene.model_path} --target_h_l_ratio {target_constraints.get('height_length_ratio', 0.3460)} --target_only")

            # Densification
            if iteration < opt.densify_until_iter:
                # Keep track of max radii in image-space for pruning
                gaussians.max_radii2D[visibility_filter] = torch.max(gaussians.max_radii2D[visibility_filter], radii[visibility_filter])
                gaussians.add_densification_stats(viewspace_point_tensor, visibility_filter)

                if iteration > opt.densify_from_iter and iteration % opt.densification_interval == 0:
                    size_threshold = 20 if iteration > opt.opacity_reset_interval else None
                    # 🔧 改进的后期杂点控制：根据训练阶段调整参数
                    if iteration <= 10000:
                        # 早期：标准参数，促进点云增长
                        min_opacity = 0.005
                        grad_threshold = opt.densify_grad_threshold
                    elif iteration <= 20000:
                        # 中期：中等控制，平衡质量和杂点
                        min_opacity = 0.01
                        grad_threshold = opt.densify_grad_threshold * 1.2
                    else:
                        # 后期：严格控制，减少杂点
                        min_opacity = 0.02
                        grad_threshold = opt.densify_grad_threshold * 1.5

                    gaussians.densify_and_prune(grad_threshold, min_opacity, scene.cameras_extent, size_threshold, radii)

                    # 🔧 后期额外杂点清理：每5000次迭代进行一次深度清理
                    if iteration > 15000 and iteration % 5000 == 0:
                        print(f"[ITER {iteration}] 执行深度杂点清理...")
                        # 使用更严格的参数进行额外清理
                        extra_min_opacity = min_opacity * 1.5  # 更严格的不透明度阈值
                        extra_grad_threshold = grad_threshold * 1.2  # 更严格的梯度阈值

                        # 获取当前点云状态
                        current_xyz = gaussians.get_xyz
                        current_opacities = gaussians.get_opacity

                        # 计算额外清理掩码
                        extra_prune_mask = current_opacities.squeeze() < extra_min_opacity

                        if extra_prune_mask.sum() > 0:
                            print(f"   深度清理: 移除 {extra_prune_mask.sum()} 个低不透明度点")
                            gaussians.prune_points(extra_prune_mask)

                    # 优化：在densification后限制尺度范围，避免过大或过小的高斯点
                    gaussians.clamp_scaling()
                
                if iteration % opt.opacity_reset_interval == 0 or (dataset.white_background and iteration == opt.densify_from_iter):
                    gaussians.reset_opacity()

            # Optimizer step
            if iteration < opt.iterations:
                gaussians.exposure_optimizer.step()
                gaussians.exposure_optimizer.zero_grad(set_to_none = True)
                if use_sparse_adam:
                    visible = radii > 0
                    gaussians.optimizer.step(visible, radii.shape[0])
                    gaussians.optimizer.zero_grad(set_to_none = True)
                else:
                    gaussians.optimizer.step()
                    gaussians.optimizer.zero_grad(set_to_none = True)

            if (iteration in checkpoint_iterations):
                print("\n[ITER {}] Saving Checkpoint".format(iteration))
                torch.save((gaussians.capture(), iteration), scene.model_path + "/chkpnt" + str(iteration) + ".pth")



def prepare_output_and_logger(args):    
    if not args.model_path:
        if os.getenv('OAR_JOB_ID'):
            unique_str=os.getenv('OAR_JOB_ID')
        else:
            unique_str = str(uuid.uuid4())
        args.model_path = os.path.join("./output/", unique_str[0:10])
        
    # Set up output folder
    print("Output folder: {}".format(args.model_path))
    os.makedirs(args.model_path, exist_ok = True)
    with open(os.path.join(args.model_path, "cfg_args"), 'w') as cfg_log_f:
        cfg_log_f.write(str(Namespace(**vars(args))))

    # Create Tensorboard writer
    tb_writer = None
    if TENSORBOARD_FOUND:
        tb_writer = SummaryWriter(args.model_path)
    else:
        print("Tensorboard not available: not logging progress")
    return tb_writer

def training_report(tb_writer, iteration, Ll1, loss, l1_loss, elapsed, testing_iterations, scene : Scene, renderFunc, renderArgs, train_test_exp, Lscale=0.0, Lheight=0.0):
    if tb_writer:
        tb_writer.add_scalar('train_loss_patches/l1_loss', Ll1.item(), iteration)
        tb_writer.add_scalar('train_loss_patches/total_loss', loss.item(), iteration)
        if Lscale > 0:
            tb_writer.add_scalar('train_loss_patches/scale_constraint', Lscale.item() if isinstance(Lscale, torch.Tensor) else Lscale, iteration)
        if Lheight > 0:
            tb_writer.add_scalar('train_loss_patches/height_constraint', Lheight.item() if isinstance(Lheight, torch.Tensor) else Lheight, iteration)
        tb_writer.add_scalar('iter_time', elapsed, iteration)

    # Report test and samples of training set
    if iteration in testing_iterations:
        torch.cuda.empty_cache()
        validation_configs = ({'name': 'test', 'cameras' : scene.getTestCameras()}, 
                              {'name': 'train', 'cameras' : [scene.getTrainCameras()[idx % len(scene.getTrainCameras())] for idx in range(5, 30, 5)]})

        for config in validation_configs:
            if config['cameras'] and len(config['cameras']) > 0:
                l1_test = 0.0
                psnr_test = 0.0
                for idx, viewpoint in enumerate(config['cameras']):
                    image = torch.clamp(renderFunc(viewpoint, scene.gaussians, *renderArgs)["render"], 0.0, 1.0)
                    gt_image = torch.clamp(viewpoint.original_image.to("cuda"), 0.0, 1.0)
                    if train_test_exp:
                        image = image[..., image.shape[-1] // 2:]
                        gt_image = gt_image[..., gt_image.shape[-1] // 2:]
                    if tb_writer and (idx < 5):
                        tb_writer.add_images(config['name'] + "_view_{}/render".format(viewpoint.image_name), image[None], global_step=iteration)
                        if iteration == testing_iterations[0]:
                            tb_writer.add_images(config['name'] + "_view_{}/ground_truth".format(viewpoint.image_name), gt_image[None], global_step=iteration)
                    l1_test += l1_loss(image, gt_image).mean().double()
                    psnr_test += psnr(image, gt_image).mean().double()
                psnr_test /= len(config['cameras'])
                l1_test /= len(config['cameras'])          
                print("\n[ITER {}] Evaluating {}: L1 {} PSNR {}".format(iteration, config['name'], l1_test, psnr_test))
                if tb_writer:
                    tb_writer.add_scalar(config['name'] + '/loss_viewpoint - l1_loss', l1_test, iteration)
                    tb_writer.add_scalar(config['name'] + '/loss_viewpoint - psnr', psnr_test, iteration)

        if tb_writer:
            tb_writer.add_histogram("scene/opacity_histogram", scene.gaussians.get_opacity, iteration)
            tb_writer.add_scalar('total_points', scene.gaussians.get_xyz.shape[0], iteration)
        torch.cuda.empty_cache()

if __name__ == "__main__":
    # Set up command line argument parser
    parser = ArgumentParser(description="Training script parameters")
    lp = ModelParams(parser)
    op = OptimizationParams(parser)
    pp = PipelineParams(parser)
    parser.add_argument('--ip', type=str, default="127.0.0.1")
    parser.add_argument('--port', type=int, default=6009)
    parser.add_argument('--debug_from', type=int, default=-1)
    parser.add_argument('--detect_anomaly', action='store_true', default=False)
    parser.add_argument("--test_iterations", nargs="+", type=int, default=[7_000, 30_000])
    parser.add_argument("--save_iterations", nargs="+", type=int, default=[7_000, 30_000])
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument('--disable_viewer', action='store_true', default=False)
    parser.add_argument("--checkpoint_iterations", nargs="+", type=int, default=[])
    parser.add_argument("--start_checkpoint", type=str, default = None)
    
    # SAR配置参数
    parser.add_argument("--use_default_sar_config", action="store_true", default=True,
                       help="使用train.py中的SAR默认配置（MSTAR参数）")
    parser.add_argument("--no_default_sar_config", dest="use_default_sar_config", 
                       action="store_false",
                       help="禁用默认SAR配置，使用命令行参数或arguments/__init__.py中的默认值")
    parser.add_argument("--show_sar_config", action="store_true",
                       help="显示当前SAR配置并退出")
    
    args = parser.parse_args(sys.argv[1:])
    
    # 如果只是查看配置，打印后退出
    if args.show_sar_config:
        print_sar_config()
        sys.exit(0)
    
    # 应用SAR默认配置（如果启用）
    if args.use_default_sar_config:
        print("\n🎯 应用SAR默认配置（MSTAR数据集参数）")
        print("   （可通过 --no_default_sar_config 禁用）")
        args = apply_sar_config_to_args(args)
        print_sar_config()
    else:
        print("\n⚠️  使用命令行参数或默认配置（未应用MSTAR预设）")
    
    args.save_iterations.append(args.iterations)


    print("Optimizing " + args.model_path)

    # Initialize system state (RNG)
    safe_state(args.quiet)

    # Start GUI server, configure and run training
    if not args.disable_viewer:
        network_gui.init(args.ip, args.port)
    torch.autograd.set_detect_anomaly(args.detect_anomaly)
    training(lp.extract(args), op.extract(args), pp.extract(args), args.test_iterations, args.save_iterations, args.checkpoint_iterations, args.start_checkpoint, args.debug_from)

    # All done
    print("\nTraining complete.")

