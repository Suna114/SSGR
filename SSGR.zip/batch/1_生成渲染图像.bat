@echo off
chcp 65001 >nul
cd /d "%~dp0.."
setlocal

REM ============================================================
REM 步骤一：仅生成渲染图像（不与对比流程耦合）
REM ============================================================
REM 使用前请修改下方变量。
REM 生成完成后，可将不同俯视角的图像放入对应 renders/gt 目录，
REM 再运行 2_结果对比评估.bat 进行对比。
REM ============================================================

set MODEL_PATH=output/sar_bmp2
set ITERATION=50000

REM 俯视角列表（度），空格分隔；稍后导入其他俯视角图像后可单独做对比
set DEPRESSION_ANGLES=17 20 30 45

echo.
echo ============================================================
echo 步骤一：生成渲染图像
echo ============================================================
echo 模型路径: %MODEL_PATH%
echo 迭代次数: %ITERATION%
echo 俯视角: %DEPRESSION_ANGLES%
echo ============================================================
echo.

REM 仅渲染：训练视角 + 新视角（按俯视角子文件夹）+ 训练集对应视角（便于对比）
python scripts\rendering\render_and_save.py -m %MODEL_PATH% --iteration %ITERATION% --render_train --render_novel_views --depression_angles "%DEPRESSION_ANGLES%"
if errorlevel 1 (
    echo 渲染失败，已退出。
    pause
    exit /b 1
)

echo.
echo ============================================================
echo 图像生成完成（未执行对比）
echo ============================================================
echo 输出目录: %MODEL_PATH%\rendered_images\
echo   - train/              训练视角 renders + gt
echo   - novel_views/        新视角（按俯视角分子文件夹）
echo     - depression_17/   俯视角 17°
echo     - depression_20/   俯视角 20°
echo     - ...
echo     - train_angles/    训练集对应视角 renders + gt
echo.
echo 导入其他俯视角图像后，请运行: 2_结果对比评估.bat
echo ============================================================
pause
