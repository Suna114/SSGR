@echo off
chcp 65001 >nul
cd /d "%~dp0.."
setlocal

REM ============================================================
REM SAR-GS 训练 → 渲染 → 对比评估 完整流程
REM ============================================================
REM 图像生成与结果对比已拆分为独立步骤：
REM   - 仅生成图像：运行 1_生成渲染图像.bat
REM   - 仅结果对比：运行 2_结果对比评估.bat（可稍后导入不同俯视角图像再对比）
REM 使用前请修改下方变量：
REM   DATA_PATH    - 数据集路径（需含 images/ 和 sparse/）
REM   MODEL_PATH   - 模型输出路径
REM   ITERATION    - 训练迭代次数（渲染与评估使用同一迭代）
REM ============================================================

set DATA_PATH=data/MSTAR_BMP2
set MODEL_PATH=output/sar_bmp2
set ITERATION=50000

REM 渲染输出在模型目录下：%MODEL_PATH%/rendered_images/train 或 test
set RENDER_TRAIN_DIR=%MODEL_PATH%/rendered_images/train
set RENDER_TEST_DIR=%MODEL_PATH%/rendered_images/test
set COMPARISON_DIR=%MODEL_PATH%/comparison_results

echo.
echo ============================================================
echo 步骤1: 训练模型
echo ============================================================
python train_sar_complete.py -s %DATA_PATH% -m %MODEL_PATH% --iterations %ITERATION%
if errorlevel 1 (
    echo 训练失败，已退出。
    pause
    exit /b 1
)

echo.
echo ============================================================
echo 步骤2: 渲染训练视角 + 测试视角
echo ============================================================
python scripts\rendering\render_and_save.py -m %MODEL_PATH% --iteration %ITERATION% --render_train
if errorlevel 1 (
    echo 渲染失败，已退出。
    pause
    exit /b 1
)

echo.
echo ============================================================
echo 步骤3（可选）: 对比训练视角并计算指标
echo    若稍后导入不同俯视角图像再对比，可跳过此步，改运行 2_结果对比评估.bat
echo ============================================================
python scripts\evaluation\compare_render_gt.py ^
    --render_dir "%RENDER_TRAIN_DIR%/renders" ^
    --gt_dir "%RENDER_TRAIN_DIR%/gt" ^
    --output_dir "%COMPARISON_DIR%/train" ^
    --sar_metrics
if errorlevel 1 (
    echo 对比失败，已退出。
    pause
    exit /b 1
)

echo.
echo ============================================================
echo 步骤4: 显示训练视角对比报告
echo ============================================================
if exist "%COMPARISON_DIR%\train\comparison_report.txt" (
    type "%COMPARISON_DIR%\train\comparison_report.txt"
) else (
    echo 未找到报告文件，请检查路径: %COMPARISON_DIR%\train\
)

echo.
echo ============================================================
echo 全部完成
echo ============================================================
echo 模型与点云: %MODEL_PATH%\point_cloud\
echo 渲染图像:   %MODEL_PATH%\rendered_images\
echo 对比报告:   %COMPARISON_DIR%\train\
echo ============================================================
pause
