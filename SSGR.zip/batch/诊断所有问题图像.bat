@echo off
cd /d "%~dp0.."
REM 批量诊断所有表现较差的图像（PSNR < 20 或 SSIM < 0.5）

echo ================================================================================
echo 批量诊断问题图像
echo ================================================================================

REM 诊断 T72-15-074.png (PSNR=17.10, SSIM=0.405)
echo.
echo [1/4] 诊断 T72-15-074.png...
python diagnose_image_difference.py --render_path my_renders\train\renders\T72-15-074.png --gt_path my_renders\train\gt\T72-15-074.png --output_dir my_renders\train\diagnosis_074

REM 诊断 T72-15-319.png (PSNR=17.15, SSIM=0.438)
echo.
echo [2/4] 诊断 T72-15-319.png...
python diagnose_image_difference.py --render_path my_renders\train\renders\T72-15-319.png --gt_path my_renders\train\gt\T72-15-319.png --output_dir my_renders\train\diagnosis_319

REM 诊断 T72-15-033.png (PSNR=19.42, SSIM=0.584)
echo.
echo [3/4] 诊断 T72-15-033.png...
python diagnose_image_difference.py --render_path my_renders\train\renders\T72-15-033.png --gt_path my_renders\train\gt\T72-15-033.png --output_dir my_renders\train\diagnosis_033

REM 诊断 T72-15-299.png (PSNR=20.02, SSIM=0.536)
echo.
echo [4/4] 诊断 T72-15-299.png...
python diagnose_image_difference.py --render_path my_renders\train\renders\T72-15-299.png --gt_path my_renders\train\gt\T72-15-299.png --output_dir my_renders\train\diagnosis_299

echo.
echo ================================================================================
echo 诊断完成！
echo ================================================================================
echo 诊断结果保存在:
echo   - my_renders\train\diagnosis_074\
echo   - my_renders\train\diagnosis_319\
echo   - my_renders\train\diagnosis_033\
echo   - my_renders\train\diagnosis_299\
echo.
pause
