@echo off
cd /d "%~dp0.."
REM SAR-GS快速测试脚本
REM 使用标准数据集快速验证训练脚本能否正常运行

echo ======================================================================
echo SAR-GS训练脚本快速测试
echo ======================================================================
echo.

REM 检查是否有测试数据
if not exist "data\tandt_db\tandt\train" (
    echo [错误] 找不到测试数据: data\tandt_db\tandt\train
    echo.
    echo 请使用您自己的数据集路径，例如：
    echo python train_sar_complete.py -s data\your_dataset -m output\test --iterations 100
    echo.
    pause
    exit /b 1
)

echo [步骤1] 使用标准数据集进行100迭代快速测试...
echo.

python train_sar_complete.py -s data\tandt_db\tandt\train -m output\quick_test --iterations 100

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ======================================================================
    echo 测试成功！训练脚本可以正常运行
    echo ======================================================================
    echo.
    echo 生成的文件：
    dir /b output\quick_test
    echo.
    echo [下一步] 使用您的SAR数据集进行完整训练：
    echo python train_sar_complete.py -s ^<SAR数据路径^> -m output\sar_full --iterations 30000
    echo.
) else (
    echo.
    echo ======================================================================
    echo 测试失败！请检查错误信息
    echo ======================================================================
    echo.
)

pause

