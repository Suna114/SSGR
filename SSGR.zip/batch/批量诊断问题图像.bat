@echo off
cd /d "%~dp0.."
REM 批量诊断所有表现较差的图像

echo ================================================================================
echo 批量诊断问题图像（自动对齐验证）
echo ================================================================================

REM 设置路径
set RENDER_DIR=my_renders\train\renders
set GT_DIR=my_renders\train\gt
set OUTPUT_BASE=my_renders\train\diagnosis

echo.
echo 渲染结果目录: %RENDER_DIR%
echo 原始图像目录: %GT_DIR%
echo 输出目录: %OUTPUT_BASE%
echo.

REM 诊断最差的4张图像
echo [1/4] 诊断 T72-15-074.png (SSIM=0.405, 最差)...
python diagnose_image_difference.py --render_path %RENDER_DIR%\T72-15-074.png --gt_path %GT_DIR%\T72-15-074.png --output_dir %OUTPUT_BASE%_074

echo.
echo [2/4] 诊断 T72-15-319.png (SSIM=0.438, 第二差)...
python diagnose_image_difference.py --render_path %RENDER_DIR%\T72-15-319.png --gt_path %GT_DIR%\T72-15-319.png --output_dir %OUTPUT_BASE%_319

echo.
echo [3/4] 诊断 T72-15-033.png (SSIM=0.584, 第三差)...
python diagnose_image_difference.py --render_path %RENDER_DIR%\T72-15-033.png --gt_path %GT_DIR%\T72-15-033.png --output_dir %OUTPUT_BASE%_033

echo.
echo [4/4] 诊断 T72-15-299.png (SSIM=0.536, 第四差)...
python diagnose_image_difference.py --render_path %RENDER_DIR%\T72-15-299.png --gt_path %GT_DIR%\T72-15-299.png --output_dir %OUTPUT_BASE%_299

echo.
echo ================================================================================
echo 诊断完成！
echo ================================================================================
echo 诊断结果保存在:
echo   - %OUTPUT_BASE%_074\
echo   - %OUTPUT_BASE%_319\
echo   - %OUTPUT_BASE%_033\
echo   - %OUTPUT_BASE%_299\
echo.
echo 💡 提示: 查看"问题图像诊断总结.md"了解详细分析和改进建议
echo.
pause
