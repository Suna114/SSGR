@echo off
cd /d "%~dp0.."
REM 诊断表现最差的图像

echo ================================================================================
echo 诊断问题图像
echo ================================================================================

REM 诊断 T72-15-074.png (最差)
echo.
echo [1/2] 诊断 T72-15-074.png (PSNR=17.10, SSIM=0.405)...
python diagnose_image_difference.py ^
    --render_path my_renders\train\renders\T72-15-074.png ^
    --gt_path my_renders\train\gt\T72-15-074.png ^
    --output_dir my_renders\train\diagnosis_074

REM 诊断 T72-15-319.png (第二差)
echo.
echo [2/2] 诊断 T72-15-319.png (PSNR=17.15, SSIM=0.438)...
python diagnose_image_difference.py ^
    --render_path my_renders\train\renders\T72-15-319.png ^
    --gt_path my_renders\train\gt\T72-15-319.png ^
    --output_dir my_renders\train\diagnosis_319

echo.
echo ================================================================================
echo 诊断完成！
echo ================================================================================
echo 诊断结果保存在:
echo   - my_renders\train\diagnosis_074\
echo   - my_renders\train\diagnosis_319\
echo.
pause
