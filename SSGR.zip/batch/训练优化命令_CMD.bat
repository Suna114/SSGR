@echo off
cd /d "%~dp0.."
REM SAR-GS 优化训练命令（Windows CMD 格式）
REM 使用方法：修改下面的路径后直接运行此批处理文件，或在CMD中复制命令执行

python train_sar_complete.py -s <你的数据集路径> -m output\你的模型名_optimized --iterations 40000 --lambda_dssim 0.4 --sar_radius_scale 0.62 --target_percentile 95.0 --background_percentile 5.0 --test_iterations 7000 15000 30000 40000 --save_iterations 7000 15000 30000 40000

REM 或者使用换行格式（使用 ^ 符号）：
REM python train_sar_complete.py ^
REM     -s <你的数据集路径> ^
REM     -m output\你的模型名_optimized ^
REM     --iterations 40000 ^
REM     --lambda_dssim 0.4 ^
REM     --sar_radius_scale 0.62 ^
REM     --target_percentile 95.0 ^
REM     --background_percentile 5.0 ^
REM     --test_iterations 7000 15000 30000 40000 ^
REM     --save_iterations 7000 15000 30000 40000

pause
