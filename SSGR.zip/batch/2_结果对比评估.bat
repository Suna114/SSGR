@echo off
chcp 65001 >nul
cd /d "%~dp0.."
setlocal

REM ============================================================
REM 步骤二：仅做结果对比评估（与图像生成分离）
REM ============================================================
REM 使用前请修改下方变量，指向已有的 renders 与 gt 目录。
REM 可对 1_生成渲染图像.bat 的输出做对比，或对导入的其他俯视角图像做对比。
REM ============================================================

set MODEL_PATH=output/sar_bmp2
set RENDER_DIR=%MODEL_PATH%/rendered_images/novel_views/train_angles/renders
set GT_DIR=%MODEL_PATH%/rendered_images/novel_views/train_angles/gt
set COMPARISON_OUTPUT=%MODEL_PATH%/rendered_images/novel_views/train_angles/comparison

REM 若要对其他目录对比，可改为例如：
REM   train 视角:     .../rendered_images/train/renders 与 train/gt
REM   某俯视角新视角: 需先将该俯视角的 renders 与 gt 放到同一目录下，再改本脚本中三行 set

echo.
echo ============================================================
echo 步骤二：结果对比评估
echo ============================================================
echo 渲染目录: %RENDER_DIR%
echo 原图目录: %GT_DIR%
echo 对比输出: %COMPARISON_OUTPUT%
echo ============================================================
echo.

python scripts\evaluation\compare_render_gt.py --render_dir "%RENDER_DIR%" --gt_dir "%GT_DIR%" --output_dir "%COMPARISON_OUTPUT%" --sar_metrics
if errorlevel 1 (
    echo 对比失败，已退出。
    pause
    exit /b 1
)

echo.
echo ============================================================
echo 对比完成
echo ============================================================
echo 报告与 JSON: %COMPARISON_OUTPUT%
if exist "%COMPARISON_OUTPUT%\comparison_report.txt" (
    echo.
    type "%COMPARISON_OUTPUT%\comparison_report.txt"
)
echo ============================================================
pause
