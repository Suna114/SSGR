@echo off
chcp 65001 >nul
cd /d "%~dp0.."
echo ============================================================
echo 点云与T72模型对比工具（手动缩放）
echo ============================================================
echo.
echo 提示: 如果点云太小，可以尝试以下缩放因子:
echo   --scale-factor 0.001  (缩小模型1000倍)
echo   --scale-factor 0.01   (缩小模型100倍)
echo   --scale-factor 0.1    (缩小模型10倍)
echo.
set /p SCALE="请输入缩放因子 (直接回车使用0.001): "
if "%SCALE%"=="" set SCALE=0.001

echo.
echo 使用缩放因子: %SCALE%
echo.

python compare_pointcloud_with_model.py ^
    --pointcloud "F:\3dgs\gaussian-splatting\output\V4\point_cloud\iteration_30000\point_cloud_target_only_compressed.ply" ^
    --model "F:\raysar\T-72.obj" ^
    --scale-factor %SCALE%

pause

