@echo off
chcp 65001 >nul
cd /d "%~dp0.."
echo ========================================
echo Install SAR CUDA Rasterization Extension
echo (diff-sar-rasterization)
echo ========================================
echo.

where conda >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] conda not found. Please install Anaconda/Miniconda first.
    pause
    exit /b 1
)

echo [1] Activating conda env: 3dgs ...
call conda activate 3dgs
if %errorlevel% neq 0 (
    echo [INFO] Env 3dgs not found, trying gaussian_splatting ...
    call conda activate gaussian_splatting
)
if %errorlevel% neq 0 (
    echo [ERROR] Please activate your conda env manually, then run: pip install -e submodules/diff-sar-rasterization
    pause
    exit /b 1
)

echo.
echo [2] 设置 Visual Studio 编译环境 (x64) ...
if exist "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" (
    call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" x64
) else if exist "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat" (
    call "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat" x64
) else if exist "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat" (
    call "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat" x64
) else (
    echo [WARN] 未找到 vcvarsall.bat。若编译失败，请用 "x64 Native Tools Command Prompt for VS 2022" 运行。
)

echo.
echo [3] cd to diff-sar-rasterization ...
cd /d "%~dp0..\submodules\diff-sar-rasterization"
if %errorlevel% neq 0 (
    echo [ERROR] Path submodules\diff-sar-rasterization not found
    pause
    exit /b 1
)

echo.
echo [4] pip install -e . --no-build-isolation ...
echo     (--no-build-isolation: use current env torch, required for CUDA build)
pip install -e . --no-build-isolation

if %errorlevel% equ 0 (
    echo.
    echo ========================================
    echo SUCCESS! Use --no_sar_fast_mode to enable SAR rasterizer
    echo ========================================
) else (
    echo.
    echo [ERROR] Install failed. Common causes:
    echo   - PyTorch with CUDA not installed in current env
    echo   - diff-gaussian-rasterization not installed
    echo   - CUDA version mismatch
    echo   - Path contains Chinese chars: move project to ASCII path e.g. D:\gaussian-splatting
    echo.
    echo Install diff-gaussian-rasterization first:
    echo   pip install -e submodules/diff-gaussian-rasterization
)

echo.
pause
