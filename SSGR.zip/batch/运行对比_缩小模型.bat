@echo off
chcp 65001 >nul
cd /d "%~dp0.."
echo ============================================================
echo 点云与T72模型对比工具（强制缩小模型）
echo ============================================================
echo.
echo 此模式会强制缩小模型以匹配点云大小
echo.

python compare_pointcloud_with_model.py ^
    --pointcloud "F:\3dgs\gaussian-splatting\output\V4\point_cloud\iteration_30000\point_cloud_target_only_compressed.ply" ^
    --model "F:\raysar\T-72.obj" ^
    --scale-mode fit ^
    --scale-what model

pause

