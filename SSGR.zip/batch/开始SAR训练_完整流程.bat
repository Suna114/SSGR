@echo off
cd /d "%~dp0.."
REM SAR-GS完整训练启动脚本
REM 自动激活环境并开始训练

echo ======================================================================
echo SAR-GS训练启动脚本
echo ======================================================================
echo.

REM 检查conda环境
echo [步骤1] 激活conda环境...
call conda activate 3dgs
if %ERRORLEVEL% NEQ 0 (
    echo 错误: 无法激活3dgs环境
    echo 请确保conda已安装且3dgs环境存在
    pause
    exit /b 1
)

echo ✅ 环境已激活
echo.

REM 检查图像文件
echo [步骤2] 验证图像文件...
set /a IMAGE_COUNT=0
for %%f in (data\24\images\*.jpg) do set /a IMAGE_COUNT+=1

echo ✅ 找到 %IMAGE_COUNT% 张图像
echo.

REM 检查映射文件
echo [步骤3] 检查映射文件...
if not exist "data\24\depression_angle_mapping.json" (
    echo ⚠️  映射文件不存在，将使用原始角度
) else (
    python -c "import json; m=json.load(open('data/24/depression_angle_mapping.json')); print(f'✅ 映射文件: {len(m)}条记录')"
)
echo.

REM 提供训练选项
echo [步骤4] 选择训练模式...
echo.
echo 请选择:
echo   1. 快速测试（100迭代，约5-10分钟）
echo   2. 中等测试（1000迭代，约1-2小时）
echo   3. 完整训练（30000迭代，约2-3天）
echo   4. 自定义迭代次数
echo.

set /p choice="请输入选择 (1-4): "

if "%choice%"=="1" (
    set ITERATIONS=100
    set OUTPUT_DIR=output\quick_test_100
) else if "%choice%"=="2" (
    set ITERATIONS=1000
    set OUTPUT_DIR=output\test_1000
) else if "%choice%"=="3" (
    set ITERATIONS=30000
    set OUTPUT_DIR=output\full_30000
) else if "%choice%"=="4" (
    set /p ITERATIONS="请输入迭代次数: "
    set OUTPUT_DIR=output\custom_%ITERATIONS%
) else (
    echo 无效选择，使用默认值100迭代
    set ITERATIONS=100
    set OUTPUT_DIR=output\quick_test
)

echo.
echo ✅ 训练配置:
echo   - 数据集: data\24
echo   - 输出目录: %OUTPUT_DIR%
echo   - 迭代次数: %ITERATIONS%
echo.

REM 开始训练
echo [步骤5] 开始训练...
echo ======================================================================
echo.

python train_sar_complete.py -s data/24 -m %OUTPUT_DIR% --iterations %ITERATIONS%

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ======================================================================
    echo ✅ 训练完成！
    echo ======================================================================
    echo.
    echo 结果保存在: %OUTPUT_DIR%
    echo.
    echo 查看点云:
    dir /b %OUTPUT_DIR%\point_cloud\
    echo.
) else (
    echo.
    echo ======================================================================
    echo ❌ 训练失败
    echo ======================================================================
    echo.
    echo 请检查错误信息
    echo.
)

pause

