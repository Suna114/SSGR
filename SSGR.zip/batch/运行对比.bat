@echo off
chcp 65001 >nul
cd /d "%~dp0.."
echo ============================================================
echo 点云与T72模型对比工具
echo ============================================================
echo.

echo 步骤1: 检查并安装依赖...
python -m pip install open3d numpy --quiet
if errorlevel 1 (
    echo 警告: 依赖安装可能失败，请手动运行: pip install open3d numpy
    pause
)

echo.
echo 步骤2: 运行对比工具（自动缩放模式，会自动缩小模型如果模型太大）...
echo.
python compare_pointcloud_with_model.py ^
    --pointcloud "F:\3dgs\gaussian-splatting\output\V4\point_cloud\iteration_30000\point_cloud_target_only_compressed.ply" ^
    --model "F:\raysar\T-72.obj" ^
    --scale-mode fit ^
    --scale-what auto

if errorlevel 1 (
    echo.
    echo ============================================================
    echo 如果出现依赖错误，请手动安装:
    echo   pip install open3d numpy
    echo ============================================================
    pause
)

