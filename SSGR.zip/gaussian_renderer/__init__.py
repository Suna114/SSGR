#
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use 
# under the terms of the LICENSE.md file.
#
# For inquiries contact  george.drettakis@inria.fr
#

import torch
import math
from diff_gaussian_rasterization import GaussianRasterizationSettings, GaussianRasterizer
from scene.gaussian_model import GaussianModel
from utils.sh_utils import eval_sh

def render(viewpoint_camera, pc : GaussianModel, pipe, bg_color : torch.Tensor, scaling_modifier = 1.0, separate_sh = False, override_color = None, use_trained_exp=False, sar_mode=False):
    """
    Render the scene. 
    
    Background tensor (bg_color) must be on GPU!
    
    Args:
        sar_mode: 如果为True，使用SAR渲染模式
    """
    
    # SAR模式：sar_fast_mode=True 用光学透视(快)；False 用 SAR投影+SDGR/SAR光栅化(符合论文)
    sar_fast_mode = getattr(pipe, 'sar_fast_mode', True)
    use_sar_rasterizer = (sar_mode and not sar_fast_mode
                          and hasattr(viewpoint_camera, 'use_sar_rendering') 
                          and viewpoint_camera.use_sar_rendering
                          and hasattr(viewpoint_camera, 'R_world_to_radar') 
                          and viewpoint_camera.R_world_to_radar is not None)
    if use_sar_rasterizer:
        # 优先使用 SDGR（完整 MPA 散射公式），失败时回退到 sar_rasterizer
        return render_sar(viewpoint_camera, pc, pipe, bg_color, scaling_modifier, override_color, separate_sh, use_trained_exp)
 
    # Create zero tensor. We will use it to make pytorch return gradients of the 2D (screen-space) means
    screenspace_points = torch.zeros_like(pc.get_xyz, dtype=pc.get_xyz.dtype, requires_grad=True, device="cuda") + 0
    try:
        screenspace_points.retain_grad()
    except:
        pass

    # Set up rasterization configuration
    tanfovx = math.tan(viewpoint_camera.FoVx * 0.5)
    tanfovy = math.tan(viewpoint_camera.FoVy * 0.5)

    raster_settings = GaussianRasterizationSettings(
        image_height=int(viewpoint_camera.image_height),
        image_width=int(viewpoint_camera.image_width),
        tanfovx=tanfovx,
        tanfovy=tanfovy,
        bg=bg_color,
        scale_modifier=scaling_modifier,
        viewmatrix=viewpoint_camera.world_view_transform,
        projmatrix=viewpoint_camera.full_proj_transform,
        sh_degree=pc.active_sh_degree,
        campos=viewpoint_camera.camera_center,
        prefiltered=False,
        debug=pipe.debug,
        antialiasing=pipe.antialiasing
    )

    rasterizer = GaussianRasterizer(raster_settings=raster_settings)

    means3D = pc.get_xyz
    means2D = screenspace_points
    opacity = pc.get_opacity

    # If precomputed 3d covariance is provided, use it. If not, then it will be computed from
    # scaling / rotation by the rasterizer.
    scales = None
    rotations = None
    cov3D_precomp = None

    if pipe.compute_cov3D_python:
        cov3D_precomp = pc.get_covariance(scaling_modifier)
    else:
        scales = pc.get_scaling
        rotations = pc.get_rotation

    # If precomputed colors are provided, use them. Otherwise, if it is desired to precompute colors
    # from SHs in Python, do it. If not, then SH -> RGB conversion will be done by rasterizer.
    shs = None
    colors_precomp = None
    if override_color is None:
        if pipe.convert_SHs_python:
            shs_view = pc.get_features.transpose(1, 2).view(-1, 3, (pc.max_sh_degree+1)**2)
            dir_pp = (pc.get_xyz - viewpoint_camera.camera_center.repeat(pc.get_features.shape[0], 1))
            dir_pp_normalized = dir_pp/dir_pp.norm(dim=1, keepdim=True)
            sh2rgb = eval_sh(pc.active_sh_degree, shs_view, dir_pp_normalized)
            colors_precomp = torch.clamp_min(sh2rgb + 0.5, 0.0)
        else:
            if separate_sh:
                dc, shs = pc.get_features_dc, pc.get_features_rest
            else:
                shs = pc.get_features
    else:
        colors_precomp = override_color

    # Rasterize visible Gaussians to image, obtain their radii (on screen). 
    if separate_sh:
        rendered_image, radii, depth_image = rasterizer(
            means3D = means3D,
            means2D = means2D,
            dc = dc,
            shs = shs,
            colors_precomp = colors_precomp,
            opacities = opacity,
            scales = scales,
            rotations = rotations,
            cov3D_precomp = cov3D_precomp)
    else:
        rendered_image, radii, depth_image = rasterizer(
            means3D = means3D,
            means2D = means2D,
            shs = shs,
            colors_precomp = colors_precomp,
            opacities = opacity,
            scales = scales,
            rotations = rotations,
            cov3D_precomp = cov3D_precomp)
        
    # Apply exposure to rendered image (training only)
    if use_trained_exp:
        exposure = pc.get_exposure_from_name(viewpoint_camera.image_name)
        rendered_image = torch.matmul(rendered_image.permute(1, 2, 0), exposure[:3, :3]).permute(2, 0, 1) + exposure[:3, 3,   None, None]

    # Those Gaussians that were frustum culled or had a radius of 0 were not visible.
    # They will be excluded from value updates used in the splitting criteria.
    rendered_image = rendered_image.clamp(0, 1)
    out = {
        "render": rendered_image,
        "viewspace_points": screenspace_points,
        "visibility_filter" : (radii > 0).nonzero(),
        "radii": radii,
        "depth" : depth_image
        }
    
    return out


def render_sar_standalone(viewpoint_camera, pc: GaussianModel, pipe, bg_color: torch.Tensor, 
                         scaling_modifier=1.0, separate_sh=False, override_color=None, use_trained_exp=False):
    """
    使用 SAR 光栅化器渲染（基于 diff-gaussian-rasterization CUDA 架构）
    sar_rasterizer: Python SAR 投影 + diff-sar-rasterization CUDA 光栅化
    """
    try:
        from sar_rasterizer import (
            SARGaussianRasterizationSettings,
            SARGaussianRasterizer,
            get_sar_raster_settings_from_camera,
            _project_sar,
        )
    except ImportError as e:
        print(f"警告: SAR光栅化器未找到 ({e})，回退到标准渲染")
        return render(viewpoint_camera, pc, pipe, bg_color, scaling_modifier, separate_sh, override_color, use_trained_exp, sar_mode=False)
    
    prefer_cuda = bool(getattr(pipe, "sar_sdgr_cuda", True))
    raster_settings = get_sar_raster_settings_from_camera(
        viewpoint_camera, bg_color, scaling_modifier, prefer_cuda=prefer_cuda,
    )
    raster_settings = raster_settings._replace(sh_degree=pc.active_sh_degree, debug=pipe.debug)
    
    rasterizer = SARGaussianRasterizer(raster_settings=raster_settings)
    rs = raster_settings
    
    means3D = pc.get_xyz
    opacity = pc.get_opacity
    scales = None
    rotations = None
    cov3D_precomp = None
    if pipe.compute_cov3D_python:
        cov3D_precomp = pc.get_covariance(scaling_modifier)
    else:
        scales = pc.get_scaling
        rotations = pc.get_rotation
    
    # SAR 光栅化器需要预计算颜色（不支持内部 SH）
    colors_precomp = None
    if override_color is not None:
        colors_precomp = override_color
    else:
        shs_view = pc.get_features.transpose(1, 2).view(-1, 3, (pc.max_sh_degree+1)**2)
        dir_pp = (pc.get_xyz - viewpoint_camera.camera_center.repeat(pc.get_features.shape[0], 1))
        dir_pp_normalized = dir_pp / (dir_pp.norm(dim=1, keepdim=True) + 1e-8)
        colors_precomp = eval_sh(pc.active_sh_degree, shs_view, dir_pp_normalized)
        colors_precomp = torch.clamp_min(colors_precomp + 0.5, 0.0)
    
    means2D_proj, depths = _project_sar(
        means3D, rs.R_world_to_radar, rs.camera_center_world,
        int(rs.image_width), int(rs.image_height),
        rs.range_pixel_spacing, rs.azimuth_pixel_spacing,
    )
    viewspace_points = torch.cat([
        means2D_proj,
        torch.zeros(means2D_proj.shape[0], 1, device=means2D_proj.device, dtype=means2D_proj.dtype),
    ], dim=1)
    try:
        viewspace_points.retain_grad()
    except Exception:
        pass
    
    rendered_image, radii, depth_image, _ = rasterizer(
        means3D=means3D,
        means2D=viewspace_points[:, :2],
        opacities=opacity,
        colors_precomp=colors_precomp,
        scales=scales,
        rotations=rotations,
        cov3D_precomp=cov3D_precomp,
        means2D_precomp=viewspace_points[:, :2],
        depths_precomp=depths,
    )
    
    if use_trained_exp:
        exposure = pc.get_exposure_from_name(viewpoint_camera.image_name)
        rendered_image = torch.matmul(rendered_image.permute(1, 2, 0), exposure[:3, :3]).permute(2, 0, 1) + exposure[:3, 3, None, None]
    
    rendered_image = rendered_image.clamp(0, 1)
    
    return {
        "render": rendered_image,
        "viewspace_points": viewspace_points,
        "visibility_filter": (radii > 0).nonzero().squeeze(-1) if radii.numel() > 0 else torch.empty(0, dtype=torch.long, device="cuda"),
        "radii": radii,
        "depth": depth_image,
    }


def render_sar(viewpoint_camera, pc: GaussianModel, pipe, bg_color: torch.Tensor, scaling_modifier=1.0, override_color=None, separate_sh=False, use_trained_exp=False):
    """
    SAR模式渲染函数
    使用SAR Differentiable Gaussian Splatting Rasterizer (SDGR)
    基于论文中的Mapping and Projection Algorithm实现散射强度计算
    
    Args:
        viewpoint_camera: 包含SAR几何参数的相机
        pc: 高斯点云模型
        pipe: 渲染管线参数
        bg_color: 背景颜色
        scaling_modifier: 尺度修正因子
        override_color: 覆盖颜色（可选）
    
    Returns:
        渲染结果字典，包含：
        - render: 渲染的SAR图像
        - viewspace_points: 屏幕空间点（用于梯度）
        - visibility_filter: 可见点的索引
        - radii: 高斯半径
        - depth: 深度图
    """
    try:
        from sar_sdgr_renderer import get_cached_sdgr_rasterizer
        import numpy as np
    except ImportError as e:
        print(f"警告: SAR SDGR渲染器未找到 ({e})，回退到 SAR 光栅化器")
        return render_sar_standalone(viewpoint_camera, pc, pipe, bg_color, scaling_modifier, separate_sh, override_color, use_trained_exp)
    
    # 检查相机是否有SAR几何参数
    if not hasattr(viewpoint_camera, 'R_world_to_radar') or viewpoint_camera.R_world_to_radar is None:
        print("警告: 相机缺少 R_world_to_radar 参数，回退到 SAR 光栅化器")
        return render_sar_standalone(viewpoint_camera, pc, pipe, bg_color, scaling_modifier, separate_sh, override_color, use_trained_exp)
    
    # 转换R_world_to_radar为numpy数组（如果是torch.Tensor）
    if isinstance(viewpoint_camera.R_world_to_radar, torch.Tensor):
        R_world_to_radar_np = viewpoint_camera.R_world_to_radar.cpu().numpy()
    else:
        R_world_to_radar_np = np.array(viewpoint_camera.R_world_to_radar)
    
    # 获取SAR参数和俯视角（用于投影参数）
    sar_params = None
    depression_angle = None
    if hasattr(viewpoint_camera, 'sar_params'):
        sar_params = viewpoint_camera.sar_params
    # 注意：如果使用了循环俯视角（cyclic depression angle），
    # viewpoint_camera中的depression_angle应该已经是映射后的循环俯视角
    # （在dataset_readers.py中通过depression_angle_mapping处理）
    if hasattr(viewpoint_camera, 'depression_angle'):
        depression_angle = viewpoint_camera.depression_angle  # 应该已经是循环俯视角（如果使用了映射）
    elif hasattr(viewpoint_camera, 'angle_info') and viewpoint_camera.angle_info:
        depression_angle = viewpoint_camera.angle_info.get('depression_angle', None)
    
    # 🔧 从SFM结果中获取相机中心位置（而不是使用配置中的固定高度）
    # camera_center 是从 world_view_transform 计算出来的，已经经过SFM的缩放和变换
    camera_center_world = None
    if hasattr(viewpoint_camera, 'camera_center'):
        camera_center_world = viewpoint_camera.camera_center
        # 如果是tensor，转换为numpy数组
        if isinstance(camera_center_world, torch.Tensor):
            camera_center_world = camera_center_world.detach().cpu().numpy()
        elif isinstance(camera_center_world, np.ndarray):
            pass  # 已经是numpy数组
        else:
            camera_center_world = np.array(camera_center_world)
    
    # 获取scene_scale（如果有的话，用于NDC转换）
    scene_scale = None
    if sar_params is not None and 'scene_scale' in sar_params:
        scene_scale = sar_params['scene_scale']
    
    # 获取像素间距（与 sar_rasterizer 一致，用于2D协方差 Jacobian）
    range_ps = 0.2021
    azimuth_ps = 0.2031
    if sar_params is not None:
        range_ps = float(sar_params.get('range_pixel_spacing', range_ps))
        azimuth_ps = float(sar_params.get('azimuth_pixel_spacing', azimuth_ps))
    
    # 创建SAR渲染器（使用论文SIG-3DGS中的SDGR方法）
    # use_sig3dgs_visibility: 论文Eq.18 可见性公式 f_i = τ_i/(2π√|Σ''|)*exp(-0.5*d²)
    use_sig3dgs = getattr(pipe, 'sar_sig3dgs_visibility', True)
    shadow_detach = getattr(pipe, 'sar_shadow_detach_grad', True)
    sdgr_cuda = bool(getattr(pipe, 'sar_sdgr_cuda', True))
    rasterizer = get_cached_sdgr_rasterizer(
        image_height=int(viewpoint_camera.image_height),
        image_width=int(viewpoint_camera.image_width),
        R_world_to_radar=R_world_to_radar_np,
        camera_center_world=camera_center_world,
        scene_scale=scene_scale,
        use_attenuation=True,
        use_sig3dgs_visibility=use_sig3dgs,
        shadow_detach_grad=shadow_detach,
        prefer_cuda=sdgr_cuda,
        range_pixel_spacing=range_ps,
        azimuth_pixel_spacing=azimuth_ps,
        device=torch.device("cuda"),
    )
    
    # 获取高斯参数
    means3D = pc.get_xyz
    scales = pc.get_scaling * scaling_modifier
    rotations = pc.get_rotation
    opacities = pc.get_opacity
    
    # 获取颜色/散射强度
    if override_color is None:
        if pipe.convert_SHs_python:
            # 从球谐函数计算颜色（作为散射强度的基础）
            shs_view = pc.get_features.transpose(1, 2).view(-1, 3, (pc.max_sh_degree+1)**2)
            dir_pp = (pc.get_xyz - viewpoint_camera.camera_center.repeat(pc.get_features.shape[0], 1))
            dir_pp_normalized = dir_pp / (dir_pp.norm(dim=1, keepdim=True) + 1e-8)
            sh2rgb = eval_sh(pc.active_sh_degree, shs_view, dir_pp_normalized)
            colors = torch.clamp_min(sh2rgb + 0.5, 0.0)
        else:
            # DC → 非负散射强度（与标准 SH 着色一致，避免 raw DC 无界导致 NaN）
            from utils.sh_utils import SH2RGB
            colors = torch.clamp_min(SH2RGB(pc.get_features[:, :, 0]), 0.0)
    else:
        colors = override_color
    
    # 与标准 render 一致：screenspace_points 参与前向，densify 依赖其 .grad
    screenspace_points = torch.zeros_like(means3D, dtype=means3D.dtype, requires_grad=True, device="cuda")
    try:
        screenspace_points.retain_grad()
    except Exception:
        pass

    # 使用SDGR渲染（应用Mapping and Projection Algorithm）
    output = rasterizer(
        means3D=means3D,
        scales=scales,
        rotations=rotations,
        opacities=opacities,
        colors=colors,
        background=bg_color,
        viewspace_points=screenspace_points,
    )
    
    # 构建输出（兼容标准render接口）
    rendered_image = output["render"]
    if use_trained_exp:
        exposure = pc.get_exposure_from_name(viewpoint_camera.image_name)
        rendered_image = torch.matmul(
            rendered_image.permute(1, 2, 0), exposure[:3, :3],
        ).permute(2, 0, 1) + exposure[:3, 3, None, None]
    means2D = output["means2D"]
    depths = output.get("depths", torch.zeros(means3D.shape[0], device="cuda"))
    screenspace_points = output.get("viewspace_points", screenspace_points)
    
    # 计算可见性过滤器（与标准 render 一致：radii>0 且在视锥内）
    H, W = int(viewpoint_camera.image_height), int(viewpoint_camera.image_width)
    n_gs = means3D.shape[0]
    visible = (means2D[:, 0] >= 0) & (means2D[:, 0] < W) & \
              (means2D[:, 1] >= 0) & (means2D[:, 1] < H) & \
              (depths > 0)  # 深度必须为正
    
    # 3σ 半径（与 Python/CUDA 光栅化一致），离屏点置 0
    from sar.rasterizer import _cov2d_to_radii
    if "cov2D" in output:
        radii = _cov2d_to_radii(output["cov2D"])
    else:
        radii = torch.zeros(n_gs, device=means3D.device, dtype=means2D.dtype)
    radii = torch.where(visible, radii, torch.zeros_like(radii))
    if visible.any():
        vis_idx = visible.nonzero(as_tuple=True)[0]
        vis_idx = vis_idx[(vis_idx >= 0) & (vis_idx < n_gs)]
    else:
        vis_idx = torch.empty(0, dtype=torch.long, device=means3D.device)

    depth_map = output.get("depth")
    if depth_map is not None and depth_map.dim() == 2:
        depth_out = depth_map
    else:
        depth_out = None

    out = {
        "render": rendered_image.clamp(0, 1),
        "viewspace_points": screenspace_points,
        "visibility_filter": vis_idx,
        "radii": radii,
        "depth": depth_out,
        "depths_per_gaussian": depths,
    }
    
    return out
